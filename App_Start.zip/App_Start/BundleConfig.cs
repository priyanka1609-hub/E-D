﻿using System.Web;
using System.Web.Optimization;

namespace Edistrict
{
    public class BundleConfig
    {
        // For more information on Bundling, visit http://go.microsoft.com/fwlink/?LinkId=254725
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryui").Include(
                        "~/Scripts/jquery-ui-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.unobtrusive*",
                        "~/Scripts/jquery.validate*"));

            bundles.Add(new ScriptBundle("~/bundles/JqueryValidation").Include(
                          "~/Scripts/Validate.js",
                          "~/Scripts/ValidateUid.js"));

            bundles.Add(new ScriptBundle("~/bundles/Encryption").Include(
                         "~/Scripts/md5.js",
                         "~/Scripts/aes.js",
                         "~/Scripts/pbkdf2.js",
                         "~/Scripts/Sha512.js"));

            bundles.Add(new ScriptBundle("~/bundles/JqueryDesign").Include(
                          "~/Scripts/popup.js",
                          "~/Scripts/imageslider.js",
                          "~/Scripts/ddsmoothmenu.js",
                          "~/Scripts/ddsmoothmenumark.js"));

            bundles.Add(new ScriptBundle("~/bundles/custom").Include(
                         "~/Scripts/custom.js"));

            bundles.Add(new ScriptBundle("~/bundles/HighChart").Include(
                       "~/Scripts/exporting.js",
                       "~/Scripts/highcharts.js"));

            bundles.Add(new ScriptBundle("~/bundles/HindiKeyboard").Include(
                       "~/Scripts/Support.js",
                       "~/Scripts/LanguagesArray.js"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/DownExcel").Include(
                        "~/Scripts/jquery.table2excel.js",
                        "~/Scripts/tooltip.js"));






            bundles.Add(new StyleBundle("~/Content/css").Include(
                        "~/Content/site.css",        
                        "~/Content/popup.css",
                        "~/Content/imageslider.css",
                        "~/Content/table.css",
                        "~/Content/themes/base/jquery-ui.css"));

            bundles.Add(new StyleBundle("~/Content/css/HindiKeyboard").Include(
                        "~/Content/HindiFloatingKeyboard.css"));

            bundles.Add(new StyleBundle("~/Content/themes/base/css").Include(
                        "~/Content/themes/base/accordion.css",
                        "~/Content/themes/base/all.css",
                        "~/Content/themes/base/autocomplete.css",
                        "~/Content/themes/base/base.css",
                        "~/Content/themes/base/button.css",
                        "~/Content/themes/base/core.css",
                        "~/Content/themes/base/datepicker.css",
                        "~/Content/themes/base/dialog.css",
                        "~/Content/themes/base/draggable.css",
                        "~/Content/themes/base/jquery-ui.css",
                        "~/Content/themes/base/jquery-ui.min.css",
                        "~/Content/themes/base/menu.css",
                        "~/Content/themes/base/printit.txt",
                        "~/Content/themes/base/progressbar.css",
                        "~/Content/themes/base/resizable.css",
                        "~/Content/themes/base/selectable.css",
                        "~/Content/themes/base/selectmenu.css",
                        "~/Content/themes/base/slider.css",
                        "~/Content/themes/base/sortable.css",
                        "~/Content/themes/base/spinner.css",
                        "~/Content/themes/base/tabs.css",
                        "~/Content/themes/base/theme.css",
                        "~/Content/themes/base/tooltip.css"));

            bundles.Add(new StyleBundle("~/Content/DownExcel/css").Include(
                      "~/Content/tooltip.css")); 

        }
    }
}