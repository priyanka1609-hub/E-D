﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using Edistrict.Models.ApplicationService;
using Edistrict.Models;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.Entities;
using System.Data;
using System.Web.UI;
using Npgsql;
using System.Collections;
using Edistrict.Models.CustomClass;

namespace Edistrict.Controllers
{
    [Authorize(Roles = CustomRoles.R108)]
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class VerifierController : Controller
    {
        [EncryptedActionParameter]
        public ActionResult SearchAppForAction(int sid)
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.VERF).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

            GetData data = new GetData();
            VerifierModels model = new VerifierModels();
            model.StatusId = sid.ToString();
            string Qry = "select StatusName from dbo.StatusMaster where StatusId=@StatusId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@StatusId", model.StatusId);
            ViewBag.ListTitle = data.SelectColumns(Cmd)[0];

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        public ActionResult PendingApplicationCount()
        {
            GetData data = new GetData();
            string Qry = string.Empty;
            VerifierModels model = new VerifierModels();
            model.StatusId = ((int)Status.VERSENT).ToString();

            if (Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept007).ToString() || Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept016).ToString()) { Qry = "select SM.ServiceCode,SM.ServiceName,COALESCE(RS.AppCount,0) as AppCount from dbo.ServiceMaster SM inner join (select ServiceCode,COUNT(AD.ApplicationNo) as AppCount FROM dbo.ApplicationDetails AD inner join dbo.UserMaster UM on UM.userid=@UserId inner join dgen.lbrliftinspectionmaster VA on VA.inspectedby::integer=UM.Uid and VA.Applicationno=AD.Applicationno and VA.WhetherActive=@WhetherActive  where applicationdistrictcode=@applicationdistrictcode and applicationsubdivcode in (@ParamSubDivCode) and ApplicationStatusId=@ApplicationStatusId group by ServiceCode) RS on RS.ServiceCode=SM.ServiceCode where DeptCode=@ParamDeptCode and SM.ServiceCode in (@ParamServiceCode)"; }
            else { Qry = "select SM.ServiceCode,SM.ServiceName,COALESCE(RS.AppCount,0) as AppCount from dbo.ServiceMaster SM left outer join (select ServiceCode,COUNT(AD.ApplicationNo) as AppCount FROM dbo.ApplicationDetails AD inner join dbo.UserMaster UM on UM.userid=@UserId inner join dbo.VerifierApplicationDetails VA on VA.SentTo=UM.Uid and VA.Applicationno=AD.Applicationno  where applicationdistrictcode=@applicationdistrictcode and applicationsubdivcode in (@ParamSubDivCode)  and ApplicationStatusId=@ApplicationStatusId group by ServiceCode) RS on RS.ServiceCode=SM.ServiceCode where DeptCode=@ParamDeptCode and SM.ServiceCode in (@ParamServiceCode)"; }
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@applicationdistrictcode", Sessions.getEmployeeUser().DistrictCode);
            Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.StatusId);
            Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
            model.data = data.GetDataTable(Cmd);
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult PendingVerificationDetails(int sid, int service)
        {
            string Qry = string.Empty;
            GetData data = new GetData();
            VerifierModels model = new VerifierModels();
            

            if (service == (int)ServiceList.GrantOfPassengerLift || service == (int)ServiceList.InstallationOfLift || service == (int)ServiceList.RenewalOfPassengerLift || service == (int)ServiceList.CEA1 || service == (int)ServiceList.CEA2 || service == (int)ServiceList.CEA3)
            { Qry = "SELECT AD.ApplicationNo,SM.ServiceCode,SM.ServiceName,AD.ApplicantName,AD.ApplicantGender,AD.RegistrationId,AD.ApplicantFatherName,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate FROM dbo.ApplicationDetails AD inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.UserMaster UM on UM.userid=@UserId inner join dgen.lbrliftinspectionmaster VA on VA.inspectedby::integer=UM.Uid and VA.Applicationno=AD.Applicationno and VA.WhetherActive=@WhetherActive  where AD.applicationdistrictcode=@applicationdistrictcode and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId"; }
            else
            { Qry = "SELECT AD.ApplicationNo,SM.ServiceCode,SM.ServiceName,AD.ApplicantName,AD.ApplicantGender,AD.RegistrationId,AD.ApplicantFatherName,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate FROM dbo.ApplicationDetails AD inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.UserMaster UM on UM.userid=@UserId inner join dbo.VerifierApplicationDetails VA on VA.SentTo=UM.Uid and VA.Applicationno=AD.Applicationno  where AD.applicationdistrictcode=@applicationdistrictcode and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId"; }
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ServiceCode", service);
            Cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            Cmd.Parameters.AddWithValue("@applicationdistrictcode", Sessions.getEmployeeUser().DistrictCode);
            Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
            model.data = data.GetDataTable(Cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult PendingApplicationDetails(VerifierModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationNo, model.StatusId });
                return RedirectToAction("PendingApplicationDetails", "Verifier", new { q = QueryString });
            }
            return View("SerachAppForAction", model);
        }
        [EncryptedActionParameter]
        public ActionResult PendingApplicationDetails(Int64 AppNo)
        {
            GetData data = new GetData();
            VerifierModels model = new VerifierModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();

            string Qry = "select AD.ServiceCode,AD.ApplicationStatusId from dbo.ApplicationDetails AD inner join dbo.UserMaster UM on UM.userid=@UserId inner join dbo.VerifierApplicationDetails VA on VA.SentTo=UM.Uid and VA.Applicationno=AD.Applicationno  where AD.ApplicationNo=@ApplicationNo";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
            string[] GetValues = data.SelectColumns(Cmd);
            model.ApplicationDetails.ServiceCode = GetValues[0];
            model.ApplicationDetails.ApplicationStatusId = GetValues[1];

            if (string.IsNullOrEmpty(model.ApplicationDetails.ApplicationStatusId)) { model.ApplicationDetails.ApplicationStatusId = ((int)CountList.Type000).ToString(); }
            if (model.ApplicationDetails.ApplicationStatusId != ((int)Status.VERSENT).ToString())
            {
                PreserveModelState(Constant._ActionMessage, "Application Not Found, Kindly Check Your Application No.", false, true);
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.VERSENT).ToString() });
                return RedirectToAction("SearchAppForAction", "Verifier", new { q = QueryString });
            }

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.data = Utility.GetEnclosureDetails(string.Empty, string.Empty, string.Empty, string.Empty, model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());

            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Domicile)
            {
                model.ApplicationDetailsDomicile = Utility.GetDomicileDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Handicapped)
            {
                model.ApplicationHandicappedDetails = Utility.GetHandicappedDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.OldAge)
            {
                model.ApplicationOldAgeDetails = Utility.GetOldAgeDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Widow)
            {
                model.ApplicationWidowDetails = Utility.GetWidowDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Nationality)
            {
                model.ApplicationDetailsNationality = Utility.GetNationalityDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Solvency)
            {
                model.ApplicationDetailsSolvency = Utility.GetSolvencyDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Disability)
            {
                model.ApplicationDetailsDisability = Utility.GetDisabilityDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Birth)
            {
                model.ApplicationDetailsBirth = Utility.GetBirthDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Death)
            {
                model.ApplicationDetailsDeath = Utility.GetDeathDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Income)
            {
                model.ApplicationDetailsIncome = Utility.GetIncomeDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.SCST)
            {
                model.ApplicationDetailsSCST = Utility.GetSCSTDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                model.ApplicationLetterDetailsModel = Utility.GetApplicationLetterDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.ST)
            {
                model.ApplicationDetailsST = Utility.GetSTDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                model.ApplicationLetterDetailsModel = Utility.GetApplicationLetterDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.NT)
            {
                model.ApplicationDetailsNT = Utility.GetNTDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                model.ApplicationLetterDetailsModel = Utility.GetApplicationLetterDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.OBC)
            {
                model.ApplicationDetailsOBC = Utility.GetOBCDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                model.ApplicationDetailsOBC.OBCIncomeDetails = Utility.GetOBCIncomeDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.ApplicationLetterDetailsModel = Utility.GetApplicationLetterDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.LalDora)
            {
                model.ApplicationDetailsLalDora = Utility.GetLalDoraDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Surviving)
            {
                model.ApplicationDetailsSurviving = Utility.GetSurvivingDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            }
            else
            {
                return RedirectToAction("BadRequest", "Error");
            }
        

            Qry = "select AED.enclosureid,AED.applicationno,AED.servicecode,AED.documenttypeid,AED.documentid,AED.departmentid,AED.otherdepartment,dbo.udf_general_decrypt(AED.documentno) as documentno,AED.documentdetails,AED.documentdata,AED.contenttype,AED.relatedid,AED.referenceenclosureid,AED.objdetailid,AED.whethermandatory,AED.whetherseen,AED.whetherphysicallyrecieved,AED.whetherverified,AED.whetheractive,DM.DocumentName,DTM.DocumentTypeName from dbo.ApplicationEnclosureDetails AED inner join dbo.DocumentMaster DM on DM.DocumentId=AED.DocumentId inner join dbo.DocumentTypeMaster DTM on DTM.DocumentTypeId=AED.DocumentTypeId where ApplicationNo=@ApplicationNo and WhetherVerified=@WhetherVerified";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@applicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.FALSE.ToString());
            DataTable VerData = data.GetDataTable(Cmd);
            model.VerifierVerificationReport = new List<VerifierVerificationReport>();
            for (int i = 0; i < VerData.Rows.Count; i++)
            {
                model.VerifierVerificationReport.Add(new VerifierVerificationReport() { RowNumber = (i + 1).ToString(), EnclosureId = VerData.Rows[i]["EnclosureId"].ToString(), DocumentName = VerData.Rows[i]["DocumentName"].ToString(), DocumentTypeName = VerData.Rows[i]["DocumentTypeName"].ToString() });
            }
            model.VerifierWitnessMaster = new List<VerifierWitnessMaster>();
            for (int i = 0; i < 2; i++)
            {
                model.VerifierWitnessMaster.Add(new VerifierWitnessMaster() { RowNumber = (i + 1).ToString(), ServiceCode = model.ApplicationDetails.ServiceCode });
            }

            model.ServiceSpecificVerificationDetails = new ServiceSpecificVerificationDetails();
            model.ServiceSpecificVerificationDetails.ServiceCode = model.ApplicationDetails.ServiceCode;

            Qry = "select * from dbo.VerifierHeadingMaster where ServiceCode=@ServiceCode and WhetherActive=@WhetherActive";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ServiceCode", model.ApplicationDetails.ServiceCode);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
            model.ServiceSpecificVerificationDetails.data = data.GetDataTable(Cmd);

            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SaveVerificationDetails(VerifierModels model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                int LastStatus = Utility.SaveOldStatusBeforeVerification(model.ApplicationDetails.ApplicationNo, CustomText.FALSE.ToString());
                
                int Sts = 0;
                if (LastStatus > 0) { Sts = LastStatus; } else { Sts = (int)Status.TEHSPEN; }

                if (!Utility.CheckCurrentStatusBeforeUpdate(model.ApplicationDetails.ApplicationNo, Sts, (int)CountList.Type001))
                {
                    ViewData["message"] = "Application is not pending at this level anymore!";
                    return View("message");
                }

                string Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,WhetherDocumentSeen=@WhetherDocumentSeen,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo;";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", Sts);
                Cmd.Parameters.AddWithValue("@WhetherDocumentSeen", model.OriginalSeen);
                Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationDetails.ApplicationNo, Sts, (int)CountList.Type001, DB.LS.ToString()));
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "update dbo.VerifierApplicationDetails set VerifierRemarks=@VerifierRemarks,WhetherVerified=@WhetherVerified,VerificationDate=now() where ApplicationNo=@ApplicationNo and WhetherLastVerification=@WhetherLastVerification;";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@VerifierRemarks", model.VerifierRemarks);
                Cmd.Parameters.AddWithValue("@WhetherLastVerification", CustomText.TRUE.ToString());
                cmdList.Add(Cmd);

                if (model.VerifierVerificationReport != null)
                {
                    foreach (VerifierVerificationReport verification in model.VerifierVerificationReport)
                    {
                        Qry = "insert into dbo.VerifierVerificationReport (ApplicationNo,VerifierDocumentID,SelectValueId,VerifiedRemarks,userid,ipaddress,actiondatetime) values (@ApplicationNo,@VerifierDocumentID,@SelectValueId,@VerifiedRemarks,@userid,@ipaddress,now())";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@VerifierDocumentID", verification.EnclosureId);
                        Cmd.Parameters.AddWithValue("@SelectValueId", verification.SelectValueId);
                        Cmd.Parameters.AddWithValue("@VerifiedRemarks", verification.Remarks);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        Qry = "update dbo.ApplicationEnclosureDetails set WhetherSeen=@WhetherSeen,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where EnclosureId=@EnclosureId";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@WhetherSeen", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@EnclosureId", verification.EnclosureId);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                }

                int count = 0;
                while (frm["ServiceSpecificVerificationDetails.HeadingId" + count] != null)
                {
                    string HeadingValue = string.Empty, HeadingId = string.Empty;

                    HeadingId = frm["ServiceSpecificVerificationDetails.HeadingId" + count].ToString();
                    if (Convert.ToInt16(frm["ServiceSpecificVerificationDetails.ControlId" + count]) == (int)ControlType.txt)
                    {
                        HeadingValue = frm["txt" + count].ToString();
                    }
                    else if (Convert.ToInt16(frm["ServiceSpecificVerificationDetails.ControlId" + count]) == (int)ControlType.ddl)
                    {
                        HeadingValue = frm["ddl" + count].ToString();
                    }
                    Qry = "insert into dbo.VerifierServiceSpecificDetails (ApplicationNo,HeadingId,HeadingValue,userid,ipaddress,actiondatetime) values (@ApplicationNo,@HeadingId,@HeadingValue,@userid,@ipaddress,now())";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@HeadingId", HeadingId);
                    Cmd.Parameters.AddWithValue("@HeadingValue", HeadingValue);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                    count++;
                }

                int i = 0;
                foreach (VerifierWitnessMaster witness in model.VerifierWitnessMaster)
                {
                    Qry = "insert into dbo.VerifierWitnessMaster (ApplicationNo,WitnessName,WitnessGender,HouseNo,StreetNo,SubLocality,LocalityId,SubDivCode,DistrictCode,StateId,CountryId,PinCode,RelationId,DocumentId,DocumentNo,Photo,Enclosure,userid,ipaddress,actiondatetime) values (@ApplicationNo,@WitnessName,@WitnessGender,@HouseNo,@StreetNo,@SubLocality,@LocalityId,@SubDivCode,@DistrictCode,@StateId,@CountryId,@PinCode,@RelationId,@DocumentId,dbo.udf_general_encrypt(@DocumentNo),@Photo,@Enclosure,@userid,@ipaddress,now())";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@WitnessName", witness.WitnessName);
                    Cmd.Parameters.AddWithValue("@WitnessGender", witness.WitnessGender);
                    Cmd.Parameters.AddWithValue("@HouseNo", witness.HouseNo);
                    Cmd.Parameters.AddWithValue("@StreetNo", witness.StreetNo);
                    Cmd.Parameters.AddWithValue("@SubLocality", witness.SubLocality);
                    Cmd.Parameters.AddWithValue("@LocalityId", witness.LocalityId);
                    Cmd.Parameters.AddWithValue("@SubDivCode", witness.SubDivCode);
                    Cmd.Parameters.AddWithValue("@DistrictCode", witness.DistrictCode);
                    Cmd.Parameters.AddWithValue("@StateId", witness.StateId); ;
                    Cmd.Parameters.AddWithValue("@CountryId", witness.CountryId);
                    Cmd.Parameters.AddWithValue("@PinCode", witness.PinCode);
                    Cmd.Parameters.AddWithValue("@RelationId", witness.RelationId);
                    Cmd.Parameters.AddWithValue("@DocumentId", witness.DocumentId);
                    Cmd.Parameters.AddWithValue("@DocumentNo", witness.DocumentNo);
                    Cmd.Parameters.AddWithValue("@Enclosure", Utility.CompareFileCapturePhotoData(null, System.Web.HttpContext.Current.Request.Files[i]));
                    Cmd.Parameters.AddWithValue("@Photo", Utility.CompareFileCapturePhotoData(null, System.Web.HttpContext.Current.Request.Files[i + 1]));
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    i = i + 2;
                }

                cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG016, model.VerifierRemarks, (int)ApplicationSource.Window, null));       

                data.SaveData(cmdList);

                PreserveModelState(Constant._ModelStateParent, null, false, true);
                PreserveModelState(Constant._LastActionId, Constant._LastActionId, false, true);
                PreserveModelState(Constant._ActionMessage, "Your verification for the application [" + model.ApplicationDetails.ApplicationNo + "] has been saved successfully.", false, true);
                return RedirectToAction("PendingApplicationCount");
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PendingApplicationDetails", (VerifierModels)TempData[Constant._ModelStateParent]);
        }

        #region module for recommandation of addtional verifier for CEA (Labour)
        [EncryptedActionParameter]
        public ActionResult PendingAdditionalVerificationDetails()
        {
            string Qry = string.Empty;
            GetData data = new GetData();
            VerifierModels model = new VerifierModels();

            Qry = "SELECT AD.ApplicationNo,SM.ServiceCode,SM.ServiceName,AD.ApplicantName,AD.ApplicantGender,AD.RegistrationId,AD.ApplicantFatherName,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,VA.inspectionid FROM dbo.ApplicationDetails AD inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.UserMaster UM on UM.userid=@UserId inner join dgen.lbradditionalverifierdetails lav on lav.inspectedby::integer=UM.Uid and lav.whetheractive=@WhetherActive inner join dgen.lbrliftinspectionmaster VA on VA.Applicationno=AD.Applicationno and VA.whetherinspected=@WhetherActive and VA.WhetherActive=@WhetherActive and lav.inspectionid=va.inspectionid  where AD.applicationdistrictcode=@applicationdistrictcode and AD.applicationsubdivcode in (@ParamSubDivCode)  and AD.ApplicationStatusId=@ApplicationStatusId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSPEN);
            Cmd.Parameters.AddWithValue("@applicationdistrictcode", Sessions.getEmployeeUser().DistrictCode);
            Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
            model.data = data.GetDataTable(Cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [ValidateOnlyIncomingValues]
        [EncryptedActionParameter]
        public ActionResult PendingInspectionAdditionalVerificationDetails(Int64 AppNo, Int32 InsId)
        {
            VerifierModels model = new VerifierModels();
            model.data = Utility.GetLBRLiftInspectionDetails(AppNo.ToString(), InsId);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingInspectionAdditionalVerificationDetails(VerifierModels model, FormCollection frm)
        {
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            if (ModelState.IsValid)
            {
                string Qry = string.Empty;

                Qry = "select inspectionid,inspectedby from dgen.lbradditionalverifierdetails  inner join dbo.usermaster um on uid=inspectedby where um.userid=@userid";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                string[] inspectiondetails = data.SelectColumns(Cmd);



                Qry = "update dgen.lbradditionalverifierdetails  set inspectedon=now(),whetherinspected=@whetherinspected,inspectionRemarks=@inspectionremarks,whethersatisfactory=@whethersatisfactory where inspectedby=@inspectedby and inspectionid=@inspectionid;";
                Cmd = new NpgsqlCommand(Qry);

                Cmd.Parameters.AddWithValue("@whetherinspected", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@inspectionRemarks", model.VerifierRemarks);
                Cmd.Parameters.AddWithValue("@whethersatisfactory", model.WhetherSatisfactory);
                Cmd.Parameters.AddWithValue("@inspectionid", inspectiondetails[0]);
                Cmd.Parameters.AddWithValue("@inspectedby", inspectiondetails[1]);

                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);
            }


            data.SaveData(cmdList);

            PreserveModelState(Constant._ModelStateParent, null, false, true);
            PreserveModelState(Constant._LastActionId, Constant._LastActionId, false, true);
            PreserveModelState(Constant._ActionMessage, "Your verification for the application  has been saved successfully.", false, true);
            return RedirectToAction("PendingApplicationCount");

        }
        #endregion

        //method for preserve model state
        public void PreserveModelState(string Key, object obj, bool IsKeep, bool IsRemove)
        {
            if (IsRemove == true) { TempData.Remove(Key); }
            if (obj != null) { TempData[Key] = obj; }
            if (IsKeep == true) { TempData.Keep(Key); }
        }
    }
}