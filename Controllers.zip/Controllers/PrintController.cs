﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models;
using System.Data.SqlClient;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using ReportManagement;
using System.Data;
using System.Web.UI;
using Npgsql;
using System.Collections;

namespace Edistrict.Controllers
{
    [Authorize]
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class PrintController : PdfViewController
    {
        #region Action method for display & print acknowledgement slip
        [AllowAnonymous]
        [EncryptedActionParameter]
        public ActionResult PubRegistrationReciept(int UserId, int? IsPrint = 0)
        {
            PrintModels model = new PrintModels();
            model.ApplicantUserId = UserId;
            model.IsPrint = IsPrint; 
            
            GetData data = new GetData();
            string Qry = "select RegistrationID,dbo.udf_general_decrypt(DocumentNo) as ApplicantAadhaarNo,ApplicantName,case ApplicantGender when 'F' then 'Female' else 'Male' end as ApplicantGender,ApplicantMobileNo,to_char(RegistrationDate,'DD/MM/YYYY') as RegistrationDate,to_char(ApplicantDob,'DD/MM/YYYY') as ApplicantDob,ApplicantEmail  from web.RegistrationMaster where RegistrationId=@RegistrationId;";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@RegistrationId", Convert.ToString(model.ApplicantUserId));
            model.dataa = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                if (model.IsPrint == 0) { model.CssClass = CssClass.DisplayForm.ToString(); }
                if (model.IsPrint == 1) { return this.ViewPdf("", "PubRegistrationReciept", model); }
                return View(model);
            }
            else
            {
                ViewData["message"] = "Regsitration not exist in e-District Delhi, kindly check the no. and try again";
                return View("message");
            }
        }

        [EncryptedActionParameter]
        public ActionResult RevenueApplicationReciept(int? AppId, Int64? AppNo, int? IsPrint = 0)
        {
            PrintModels model = new PrintModels();
            if (AppId == null)
            {
                if (AppNo == null)
                {
                    return RedirectToAction("BadRequest", "Error");
                }
                else
                {
                    model.ApplicationNo = AppNo;
                }
            }
            else
            {
                model.ApplicationId = AppId;
            }
            model.IsPrint = IsPrint;
            GetData data = new GetData();
            NpgsqlCommand Cmd = new NpgsqlCommand();
            string Qry = string.Empty;

            if (AppNo != null) { model.ServiceCode = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationNo.ToString())[0]; }
            if (AppId != null) { model.ServiceCode = Utility.SelectColumnsValue("web.ApplicationDetails", "ServiceCode", "ApplicationId", model.ApplicationId.ToString())[0]; }
            if (model.ServiceCode == ((int)ServiceList.RenewalOfContractor).ToString())
            {
                if (AppId != null) { Qry = "Select Whetherapplamend,Whetherapplrenewal from wgen.applicationdetailsrenewalcontractor where ApplicationId=@ApplicationId"; }
                if (AppNo != null) { Qry = "select Whetherapplamend,Whetherapplrenewal from dgen.applicationdetailsrenewalcontractor where ApplicationNo=@ApplicationNo"; }
                Cmd = new NpgsqlCommand(Qry);
                if (AppId != null) { Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationId); }
                if (AppNo != null) { Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo); }
                model.datad = data.GetDataTable(Cmd);
            }

            if (AppId != null) { Qry = "SELECT NULL as ApplicationNo,AD.RegistrationId,AD.ApplicationId,AD.ServiceCode,SM.ServiceName as AppliedFor,AD.ApplicantName,case AD.ApplicantGender when 'F' then 'Female' else 'Male' end as ApplicantGender,dbo.udf_general_decrypt(RM.DocumentNo) as DocumentNo,AD.ApplicantMobileNo,AD.ApplicationStatusId,ST.StatusName as ApplicationStatus,to_char(ApplicationDate,'DD/MM/YYYY') as ApplicationDate,(SD.SubDivDescription||' '||SD.SubDivAddress) as ApplicationSubmitAt,SM.ProcessingDays,NULL as PaymentMode,NULL as ServiceFeeAmount,NULL as TransactionId,NULL as PaymentModeId,SM.DeptCode,DeptName FROM web.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode inner join web.RegistrationMaster RM on RM.RegistrationId=AD.RegistrationId inner join Deptmaster DM on DM.DeptCode=SM.DeptCode where ApplicationId=@ApplicationId"; }
            if (AppNo != null) { Qry = "SELECT AD.ApplicationNo,AD.RegistrationId,AD.ApplicationId,AD.ServiceCode,SM.ServiceName as AppliedFor,AD.ApplicantName,case AD.ApplicantGender when 'F' then 'Female' else 'Male' end as ApplicantGender,dbo.udf_general_decrypt(RM.DocumentNo) as DocumentNo,AD.ApplicantMobileNo,AD.ApplicationStatusId,ST.StatusName as ApplicationStatus,to_char(ApplicationDate,'DD/MM/YYYY') as ApplicationDate,(SD.SubDivDescription||' '||SD.SubDivAddress) as ApplicationSubmitAt,SM.ProcessingDays,NULL as TransactionId,to_char(add_days_to_timestamp(ApplicationDate,SM.ProcessingDays),'DD/MM/YYYY') as proposeddate,SM.DeptCode,DeptName FROM dbo.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode inner join web.RegistrationMaster RM on RM.RegistrationId=AD.RegistrationId inner join Deptmaster DM on DM.DeptCode=SM.DeptCode where AD.ApplicationNo=@ApplicationNo"; }
            Cmd = new NpgsqlCommand(Qry);
            if (AppId != null) { Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationId); }
            if (AppNo != null) { Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo); }
            model.dataa = data.GetDataTable(Cmd);

            if (model.ServiceCode == ((int)ServiceList.TirthYatraYojna).ToString())
            {
                if (AppId != null) { Qry = "select ValueName as RouteName,constituencyName from wgen.applicationdetailstirthyatrayojana ADTY inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid where ADTY.ApplicationId=@ApplicationId"; }
                if (AppNo != null) { Qry = "select ValueName as RouteName,constituencyName from dgen.applicationdetailstirthyatrayojana ADTY inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid where ADTY.ApplicationNo=@ApplicationNo"; }
                Cmd = new NpgsqlCommand(Qry);
                if (AppId != null) { Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationId); }
                if (AppNo != null) { Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo); }
                model.datac = data.GetDataTable(Cmd);
            }

            if (model.dataa.Rows.Count == 1)
            {
                string Paymentstatus = " and APR.paymentstatusid=@SbiEpaySuccess ";
                if (model.dataa.Rows[0]["ServiceCode"].ToString() == ((int)ServiceList.GrantOfPassengerLift).ToString() || model.dataa.Rows[0]["ServiceCode"].ToString() == ((int)ServiceList.BOCW).ToString() || model.dataa.Rows[0]["ServiceCode"].ToString() == ((int)ServiceList.Contractors).ToString() || model.dataa.Rows[0]["ServiceCode"].ToString() == ((int)ServiceList.ContractLabour).ToString() || model.dataa.Rows[0]["ServiceCode"].ToString() == ((int)ServiceList.RenewalOfPassengerLift).ToString() || model.dataa.Rows[0]["ServiceCode"].ToString() == ((int)ServiceList.RenewalOfContractor).ToString() || model.dataa.Rows[0]["ServiceCode"].ToString() == ((int)ServiceList.ConstructionWorker).ToString() || model.dataa.Rows[0]["ServiceCode"].ToString() == ((int)ServiceList.RenewalConsWorker).ToString() || model.dataa.Rows[0]["ServiceCode"].ToString() == ((int)ServiceList.ECLicence).ToString() || model.dataa.Rows[0]["ServiceCode"].ToString() == ((int)ServiceList.CompCertificate).ToString())
                { 
                    Qry = "select PaymentModeId from applicationpaymentrequest where ApplicationNo=@ApplicationNo and paymentstatusid=@SbiEpaySuccess";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("SbiEpaySuccess", (int)ValueId.SbiEpaySuccess);
                    string PMode = data.SelectColumns(Cmd)[0];
                    if (string.IsNullOrEmpty(PMode)) 
                    {
                        Paymentstatus = " and APR.paymentstatusid=@SbiEpayNew ";
                        model.Message = Utility.WhetherDocumentVerified(model.ApplicationNo.ToString(), DB.LS.ToString());
                    } 
                }

                if (AppId != null) { Qry = "select SF.Servicefeetype,PaymentAmount as servicefeeamount from applicationpaymentrequest APR inner join applicationpaymentdescription APD on APD.PaymentId=APR.PaymentId inner join servicefeetypemaster SF on SF.Servicefeetypeid=APD.PaymentTypeId where APR.ApplicationId=@ApplicationId and APR.paymentstatusid=(case when APR.paymentmodeid=@paymentmodeid then @SbiEpaySuccess else @SbiEpayNew end)  order by PaymentAmount desc"; }
                if (AppNo != null) { Qry = "select SF.Servicefeetype,APD.PaymentAmount as servicefeeamount,APS.GatewayReferenceId,APS.Transactioncin,APS.Paymentamount as totalamount,to_char(transactiondate,'DD/MM/YYYY') as Paymentdate,APS.transactionid  from applicationpaymentrequest APR inner join applicationpaymentdescription APD on APD.PaymentId=APR.PaymentId inner join servicefeetypemaster SF on SF.Servicefeetypeid=APD.PaymentTypeId  left outer join applicationpaymentresponse APS on APS.PaymentId=APR.PaymentId where APR.ApplicationNo=@ApplicationNo " + Paymentstatus + " order by APD.PaymentAmount desc"; }
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("paymentmodeid", (int)PaymentMode.Online);
                Cmd.Parameters.AddWithValue("SbiEpaySuccess", (int)ValueId.SbiEpaySuccess);
                Cmd.Parameters.AddWithValue("SbiEpayNew", (int)ValueId.SbiEpayNewPayment);
                if (AppId != null) { Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationId); }
                if (AppNo != null) { Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo); }
                model.datab = data.GetDataTable(Cmd);
                if (Sessions.getCurrentUser() != null)
                {
                    if (AppId != null)
                    {
                        string Result = Utility.WhetherDocumentVerified(AppId.ToString(), DB.RS.ToString());
                        if (Result != CustomText.TRUE.ToString()) { if (string.IsNullOrEmpty(model.Message)) { model.Message = Result; } }
                    }
                    if (AppNo != null)
                    {
                        string Result = Utility.WhetherDocumentVerified(AppNo.ToString(), DB.LS.ToString());
                        if (Result != CustomText.TRUE.ToString()) { if (string.IsNullOrEmpty(model.Message)) { model.Message = Result; } }
                    }
                }
                else if (Sessions.getEmployeeUser() != null)
                {
                    model.UserName = Utility.SelectColumnsValue("usermaster", "username", "userid", Sessions.getEmployeeUser().UserId)[0];
                }

                if (model.IsPrint == 0) { model.CssClass = CssClass.InputForm.ToString(); }
                if (model.IsPrint == 1) { return this.ViewPdf("", "RevenueApplicationReciept", model); }
                return View(model);
            }
            else { return RedirectToAction("OperationalError", "Error"); }
        }

        [EncryptedActionParameter]
        public ActionResult MarriageApplicationReciept(int? AppId, Int64? AppNo, int? IsPrint = 0)
        {
            PrintModels model = new PrintModels();
            if (AppId == null)
            {
                if (AppNo == null)
                {
                    return RedirectToAction("BadRequest", "Error");
                }
                else
                {
                    model.ApplicationNo = AppNo;
                }
            }
            else
            {
                model.ApplicationId = AppId;
            }
            model.IsPrint = IsPrint;

            string ServiceCode = string.Empty;
            if (AppId != null) { ServiceCode = Utility.SelectColumnsValue("web.applicationdetails", "ServiceCode", "ApplicationId", AppId.ToString())[0]; }
            if (AppNo != null) { ServiceCode = Utility.SelectColumnsValue("applicationdetails", "ServiceCode", "ApplicationNo", AppNo.ToString())[0]; }

            string Qry = string.Empty;
            GetData data = new GetData();
            if (ServiceCode == ((int)ServiceList.Solemnization).ToString())
            {
                if (AppId != null) { Qry = "SELECT NULL as ApplicationNo,AD.ApplicationId,SM.ServiceName as AppliedFor,AD.ApplicantName,case AD.ApplicantGender when 'F' then 'Female' else 'Male' end as ApplicantGender,AD.RegistrationId,AD.ApplicantMobileNo,AD.ApplicationStatusId,ST.StatusName as ApplicationStatus,to_char(ApplicationDate,'DD/MM/YYYY') as ApplicationDate,(SS.subdivdescription ||' '||SS.subdivaddress) as ApplicationSubmitAt,AT.AppointmentType,to_char(AM.AppointmentDate,'DD/MM/YYYY') as AppointmentDate,(cast(AppointmentTimeFrom as varchar)||'.00 AM') as AppointmentTime,SM.ProcessingDays,NULL as PaymentMode,NULL as ServiceFeeAmount,NULL as TransactionId FROM web.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode inner join wgen.applicationmarriagesolemnizationdetails MD on MD.ApplicationId=AD.ApplicationId inner join dbo.AppointmentTypeMaster AT on AT.AppointmentTypeId=MD.AppointmentTypeId inner join dbo.AppointmentMaster AM on AM.AppointmentId=MD.AppointmentId inner join (select subdivcode,subdivdescription,subdivaddress from subdivmaster union all select srcode as subdivcode,srname as subdivdescription,sraddress as subdivaddress from srofficemaster) SS on SS.subdivcode=AM.subdivcode where AD.ApplicationId=@ApplicationId"; }
                if (AppNo != null) { Qry = "SELECT AD.ApplicationNo,AD.ApplicationId,SM.ServiceName as AppliedFor,AD.ApplicantName,case AD.ApplicantGender when 'F' then 'Female' else 'Male' end as ApplicantGender,AD.RegistrationId,AD.ApplicantMobileNo,AD.ApplicationStatusId,ST.StatusName as ApplicationStatus,to_char(ApplicationDate,'DD/MM/YYYY') as ApplicationDate,(SS.subdivdescription ||' '||SS.subdivaddress) as ApplicationSubmitAt,AT.AppointmentType,to_char(AM.AppointmentDate,'DD/MM/YYYY') as AppointmentDate,(cast(AppointmentTimeFrom as varchar)||'.00 AM') as AppointmentTime,SM.ProcessingDays,NULL as TransactionId FROM dbo.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode inner join dgen.applicationmarriagesolemnizationdetails MD on MD.ApplicationNo=AD.ApplicationNo inner join dbo.AppointmentTypeMaster AT on AT.AppointmentTypeId=MD.AppointmentTypeId inner join dbo.AppointmentMaster AM on AM.AppointmentId=MD.AppointmentId inner join (select subdivcode,subdivdescription,subdivaddress from subdivmaster union all select srcode as subdivcode,srname as subdivdescription,sraddress as subdivaddress from srofficemaster) SS on SS.subdivcode=AM.subdivcode where AD.ApplicationNo=@ApplicationNo"; }
            }
            else
            {
                if (AppId != null) { Qry = "SELECT NULL as ApplicationNo,AD.ApplicationId,SM.ServiceName as AppliedFor,AD.ApplicantName,case AD.ApplicantGender when 'F' then 'Female' else 'Male' end as ApplicantGender,AD.RegistrationId,AD.ApplicantMobileNo,AD.ApplicationStatusId,ST.StatusName as ApplicationStatus,to_char(ApplicationDate,'DD/MM/YYYY') as ApplicationDate,(SS.subdivdescription ||' '||SS.subdivaddress) as ApplicationSubmitAt,AT.AppointmentType,to_char(AM.AppointmentDate,'DD/MM/YYYY') as AppointmentDate,(cast(AppointmentTimeFrom as varchar)||'.00 AM') as AppointmentTime,SM.ProcessingDays,NULL as PaymentMode,NULL as ServiceFeeAmount,NULL as TransactionId FROM web.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode inner join wgen.ApplicationMarriageDetails MD on MD.ApplicationId=AD.ApplicationId inner join dbo.AppointmentTypeMaster AT on AT.AppointmentTypeId=MD.AppointmentTypeId inner join dbo.AppointmentMaster AM on AM.AppointmentId=MD.AppointmentId inner join (select subdivcode,subdivdescription,subdivaddress from subdivmaster union all select srcode as subdivcode,srname as subdivdescription,sraddress as subdivaddress from srofficemaster) SS on SS.subdivcode=AM.subdivcode where AD.ApplicationId=@ApplicationId"; }
                if (AppNo != null) { Qry = "SELECT AD.ApplicationNo,AD.ApplicationId,SM.ServiceName as AppliedFor,AD.ApplicantName,case AD.ApplicantGender when 'F' then 'Female' else 'Male' end as ApplicantGender,AD.RegistrationId,AD.ApplicantMobileNo,AD.ApplicationStatusId,ST.StatusName as ApplicationStatus,to_char(ApplicationDate,'DD/MM/YYYY') as ApplicationDate,(SS.subdivdescription ||' '||SS.subdivaddress) as ApplicationSubmitAt,AT.AppointmentType,to_char(AM.AppointmentDate,'DD/MM/YYYY') as AppointmentDate,(cast(AppointmentTimeFrom as varchar)||'.00 AM') as AppointmentTime,SM.ProcessingDays,NULL as TransactionId FROM dbo.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode inner join dgen.ApplicationMarriageDetails MD on MD.ApplicationNo=AD.ApplicationNo inner join dbo.AppointmentTypeMaster AT on AT.AppointmentTypeId=MD.AppointmentTypeId inner join dbo.AppointmentMaster AM on AM.AppointmentId=MD.AppointmentId inner join (select subdivcode,subdivdescription,subdivaddress from subdivmaster union all select srcode as subdivcode,srname as subdivdescription,sraddress as subdivaddress from srofficemaster) SS on SS.subdivcode=AM.subdivcode where AD.ApplicationNo=@ApplicationNo"; }
            }
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            if (AppId != null) { Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationId); }
            if (AppNo != null) { Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo); }
            model.dataa = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                if (AppId != null) { Qry = "select  PMM.PaymentMode,PMM.PaymentModeid,SF.Servicefeetype,PaymentAmount as servicefeeamount from applicationpaymentrequest APR inner join applicationpaymentdescription APD on APD.PaymentId=APR.PaymentId inner join servicefeetypemaster SF on SF.Servicefeetypeid=APD.PaymentTypeId inner join PaymentModeMaster PMM on PMM.PaymentModeId=APR.PaymentModeId where ApplicationId=@ApplicationId and paymentstatusid=(case when APR.paymentmodeid=@paymentmodeid then @SbiEpaySuccess else @SbiEpayNew end) order by PaymentAmount desc"; }
                if (AppNo != null) { Qry = "select  PMM.PaymentMode,PMM.PaymentModeid,SF.Servicefeetype,APD.PaymentAmount as servicefeeamount,APS.GatewayReferenceId,APS.Transactioncin,APS.Paymentamount as totalamount,to_char(transactiondate,'DD/MM/YYYY') as Paymentdate,APS.transactionid  from applicationpaymentrequest APR inner join applicationpaymentdescription APD on APD.PaymentId=APR.PaymentId inner join PaymentModeMaster PMM on PMM.PaymentModeId=APR.PaymentModeId inner join servicefeetypemaster SF on SF.Servicefeetypeid=APD.PaymentTypeId  left outer join applicationpaymentresponse APS on APS.PaymentId=APR.PaymentId where APR.ApplicationNo=@ApplicationNo and APR.paymentstatusid=@SbiEpaySuccess order by APD.PaymentAmount desc"; }
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("paymentmodeid", (int)PaymentMode.Online);
                Cmd.Parameters.AddWithValue("SbiEpaySuccess", (int)ValueId.SbiEpaySuccess);
                Cmd.Parameters.AddWithValue("SbiEpayNew", (int)ValueId.SbiEpayNewPayment);
                if (AppId != null) { Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationId); }
                if (AppNo != null) { Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo); }
                model.datab = data.GetDataTable(Cmd);
                if (Sessions.getCurrentUser() != null)
                {
                    if (AppId != null)
                    {
                        string Result = Utility.WhetherDocumentVerified(AppId.ToString(), DB.RS.ToString());
                        if (Result != CustomText.TRUE.ToString()) { model.Message = Result; }
                    }
                    if (AppNo != null)
                    {
                        string Result = Utility.WhetherDocumentVerified(AppNo.ToString(), DB.LS.ToString());
                        if (Result != CustomText.TRUE.ToString()) { model.Message = Result; }
                    }
                }
                else if (Sessions.getEmployeeUser() != null)
                {
                    model.UserName = Utility.SelectColumnsValue("usermaster", "username", "userid", Sessions.getEmployeeUser().UserId)[0];
                }
                if (model.IsPrint == 0) { model.CssClass = CssClass.InputForm.ToString(); }
                if (model.IsPrint == 1) { return this.ViewPdf("", "MarriageApplicationReciept", model); }
                return View(model);
            }
            else { return RedirectToAction("OperationalError", "Error"); }
        }

        [EncryptedActionParameter]
        public ActionResult SocialWelfareApplicationReciept(int? AppId, Int64? AppNo, int? IsPrint = 0)
        {
            PrintModels model = new PrintModels();
            if (AppId == null)
            {
                if (AppNo == null)
                {
                    return RedirectToAction("BadRequest", "Error");
                }
                else
                {
                    model.ApplicationNo = AppNo;
                }
            }
            else
            {
                model.ApplicationId = AppId;
            }
            model.IsPrint = IsPrint;
            GetData data = new GetData();
            string Qry = string.Empty;
            if (AppId != null) { Qry = "SELECT NULL as ApplicationNo,AD.RegistrationId,AD.ApplicationId,SM.ServiceCode,SM.ServiceName as AppliedFor,AD.ApplicantName,AD.ApplicantName,AD.ApplicantFatherName,AD.ApplicantMotherNameAD.ApplicantHusbandName,,case AD.ApplicantGender when 'F' then 'Female' else 'Male' end as ApplicantGender,to_char(AD.Applicantdob,'DD/MM/YYYY') as Applicantdob,(to_char(now(),'YYYYMMDD')::date-to_char(AD.Applicantdob,'YYYYMMDD')::date)/ 365  as Age,AD.RegistrationId,dbo.udf_general_decrypt(RM.DocumentNo) as DocumentNo,AD.ApplicantMobileNo,RM.applicantemail,AD.ApplicationStatusId,ST.StatusName as ApplicationStatus,to_char(ApplicationDate,'DD/MM/YYYY') as ApplicationDate,(SD.SubDivDescription||' '||SD.SubDivAddress) as ApplicationSubmitAt,SD.SubDivDescription,SM.ProcessingDays,NULL as PaymentMode,NULL as ServiceFeeAmount,NULL as TransactionId,NULL as PaymentModeId,ADW.ConstituencyId FROM web.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode inner join web.RegistrationMaster RM on RM.RegistrationId=AD.RegistrationId left outer join wgen.applicationdetailswidow ADW on ADW.ApplicationId=AD.ApplicationId where ApplicationId=@ApplicationId"; }
            if (AppNo != null) { Qry = "SELECT AD.ApplicationNo,AD.RegistrationId,AD.ApplicationId,SM.ServiceCode,SM.ServiceName as AppliedFor,AD.ApplicantName,AD.ApplicantFatherName,AD.ApplicantMotherName,AD.ApplicantHusbandName,case AD.ApplicantGender when 'F' then 'Female' else 'Male' end as ApplicantGender,to_char(AD.Applicantdob,'DD/MM/YYYY') as Applicantdob,(to_char(now(),'YYYYMMDD')::date-to_char(AD.Applicantdob,'YYYYMMDD')::date)/ 365  as Age,AD.RegistrationId,dbo.udf_general_decrypt(RM.DocumentNo) as DocumentNo,AD.ApplicantMobileNo,RM.applicantemail,AD.ApplicationStatusId,ST.StatusName as ApplicationStatus,to_char(ApplicationDate,'DD/MM/YYYY') as ApplicationDate,(SD.SubDivDescription||' '||SD.SubDivAddress) as ApplicationSubmitAt,SD.SubDivDescription,SM.ProcessingDays,NULL as TransactionId,to_char(add_days_to_timestamp(ApplicationDate,SM.ProcessingDays),'DD/MM/YYYY') as proposeddate,ADW.ConstituencyId FROM dbo.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode inner join web.RegistrationMaster RM on RM.RegistrationId=AD.RegistrationId left outer join dgen.applicationdetailswidow ADW on ADW.Applicationno=AD.Applicationno where AD.ApplicationNo=@ApplicationNo"; }
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            if (AppId != null) { Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationId); }
            if (AppNo != null) { Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo); }
            model.dataa = data.GetDataTable(Cmd);
            if (model.dataa.Rows.Count == 1)
            {
                if (AppId != null) { Qry = "select SF.Servicefeetype,PaymentAmount as servicefeeamount from applicationpaymentrequest APR inner join applicationpaymentdescription APD on APD.PaymentId=APR.PaymentId inner join servicefeetypemaster SF on SF.Servicefeetypeid=APD.PaymentTypeId where ApplicationId=@ApplicationId and paymentstatusid=(case when APR.paymentmodeid=@paymentmodeid then @SbiEpaySuccess else @SbiEpayNew end)  order by PaymentAmount desc"; }
                if (AppNo != null) { Qry = "select SF.Servicefeetype,APD.PaymentAmount as servicefeeamount,APS.GatewayReferenceId,APS.Transactioncin,APS.Paymentamount as totalamount,to_char(transactiondate,'DD/MM/YYYY') as Paymentdate,APS.transactionid  from applicationpaymentrequest APR inner join applicationpaymentdescription APD on APD.PaymentId=APR.PaymentId inner join servicefeetypemaster SF on SF.Servicefeetypeid=APD.PaymentTypeId  left outer join applicationpaymentresponse APS on APS.PaymentId=APR.PaymentId where APR.ApplicationNo=@ApplicationNo and APR.paymentstatusid=@SbiEpaySuccess order by APD.PaymentAmount desc"; }
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("paymentmodeid", (int)PaymentMode.Online);
                Cmd.Parameters.AddWithValue("SbiEpaySuccess", (int)ValueId.SbiEpaySuccess);
                Cmd.Parameters.AddWithValue("SbiEpayNew", (int)ValueId.SbiEpayNewPayment);
                if (AppId != null) { Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationId); }
                if (AppNo != null) { Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo); }
                model.datab = data.GetDataTable(Cmd);
                if (Sessions.getCurrentUser() != null)
                {
                    if (AppId != null)
                    {
                        string Result = Utility.WhetherDocumentVerified(AppId.ToString(), DB.RS.ToString());
                        if (Result != CustomText.TRUE.ToString()) { model.Message = Result; }
                    }
                    if (AppNo != null)
                    {
                        string Result = Utility.WhetherDocumentVerified(AppNo.ToString(), DB.LS.ToString());
                        if (Result != CustomText.TRUE.ToString()) { model.Message = Result; }
                    }
                }
                else if (Sessions.getEmployeeUser() != null)
                {
                    model.UserName = Utility.SelectColumnsValue("usermaster", "username", "userid", Sessions.getEmployeeUser().UserId)[0];
                }

                if (model.IsPrint == 0) { model.CssClass = CssClass.InputForm.ToString(); }
                if (model.IsPrint == 1) { return this.ViewPdf("", "SocialWelfareApplicationReciept", model); }
                return View(model);
            }
            else { return RedirectToAction("OperationalError", "Error"); }
        }

        [EncryptedActionParameter]
        public ActionResult ConstrcutionWorkerApplicationReciept(int? AppId, Int64? AppNo, int? IsPrint = 0)
        {
            PrintModels model = new PrintModels();
            if (AppId == null)
            {
                if (AppNo == null)
                {
                    return RedirectToAction("BadRequest", "Error");
                }
                else
                {
                    model.ApplicationNo = AppNo;
                }
            }
            else
            {
                model.ApplicationId = AppId;
            }
            model.IsPrint = IsPrint;

            string ServiceCode = string.Empty;
            if (AppId != null) { ServiceCode = Utility.SelectColumnsValue("web.applicationdetails", "ServiceCode", "ApplicationId", AppId.ToString())[0]; }
            if (AppNo != null) { ServiceCode = Utility.SelectColumnsValue("applicationdetails", "ServiceCode", "ApplicationNo", AppNo.ToString())[0]; }

            string Qry = string.Empty;
            GetData data = new GetData();
            if (ServiceCode == ((int)ServiceList.ConstructionWorker).ToString() || ServiceCode == ((int)ServiceList.RenewalConsWorker).ToString())
            {
                if (AppId != null) { Qry = "SELECT NULL as ApplicationNo,AD.RegistrationId,AD.ApplicationId,AD.ServiceCode,SM.ServiceName as AppliedFor,AD.ApplicantName,case AD.ApplicantGender when 'F' then 'Female' else 'Male' end as ApplicantGender,dbo.udf_general_decrypt(RM.DocumentNo) as DocumentNo,AD.ApplicantMobileNo,AD.ApplicationStatusId,ST.StatusName as ApplicationStatus,to_char(ApplicationDate,'DD/MM/YYYY') as ApplicationDate,(SD.SubDivDescription||' '||SD.SubDivAddress) as ApplicationSubmitAt,SM.ProcessingDays,NULL as PaymentMode,NULL as ServiceFeeAmount,NULL as TransactionId,NULL as PaymentModeId,SM.DeptCode,DeptName FROM web.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode inner join web.RegistrationMaster RM on RM.RegistrationId=AD.RegistrationId inner join Deptmaster DM on DM.DeptCode=SM.DeptCode where ApplicationId=@ApplicationId"; }
                if (AppNo != null) { Qry = "SELECT AD.ApplicationNo,AD.RegistrationId,AD.ApplicationId,AD.ServiceCode,SM.ServiceName as AppliedFor,AD.ApplicantName,case AD.ApplicantGender when 'F' then 'Female' else 'Male' end as ApplicantGender,dbo.udf_general_decrypt(RM.DocumentNo) as DocumentNo,AD.ApplicantMobileNo,AD.ApplicationStatusId,ST.StatusName as ApplicationStatus,to_char(ApplicationDate,'DD/MM/YYYY') as ApplicationDate,(SD.SubDivDescription||' '||SD.SubDivAddress) as ApplicationSubmitAt,SM.ProcessingDays,NULL as TransactionId,to_char(add_days_to_timestamp(ApplicationDate,SM.ProcessingDays),'DD/MM/YYYY') as proposeddate,SM.DeptCode,DeptName FROM dbo.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode inner join web.RegistrationMaster RM on RM.RegistrationId=AD.RegistrationId inner join Deptmaster DM on DM.DeptCode=SM.DeptCode where AD.ApplicationNo=@ApplicationNo"; }
            }

            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            if (AppId != null) { Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationId); }
            if (AppNo != null) { Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo); }
            model.dataa = data.GetDataTable(Cmd);

            if (ServiceCode == ((int)ServiceList.ConstructionWorker).ToString() || ServiceCode == ((int)ServiceList.RenewalConsWorker).ToString())
            {
                if (AppId != null) { Qry = "SELECT case when whetherregisterworker=false and whetheruploadvolunteerdata=false then 'APPLICATION FOR REGISTRATION AS CONSTRUCTION WORKER' when whetherregisterworker=true and whetheruploadvolunteerdata=false then 'APPLICATION FOR RENEWAL OF MEMBERSHIP OF REGISTERED CONSTRUCTION WORKER' when whetherregisterworker=true and whetheruploadvolunteerdata=true then 'APPLICATIONN FOR VOLUNTARY DATA UPDATION / RENEWAL OF EXISTING MANUAL REGISTRATION' end as APPLIED FROM wgen.applicationdetailsregconstructionworker  where ApplicationId=@ApplicationId"; }
                if (AppNo != null) { Qry = "SELECT case when whetherregisterworker=false and whetheruploadvolunteerdata=false then 'APPLICATION FOR REGISTRATION AS CONSTRUCTION WORKER' when whetherregisterworker=true and whetheruploadvolunteerdata=false then 'APPLICATION FOR RENEWAL OF MEMBERSHIP OF REGISTERED CONSTRUCTION WORKER' when whetherregisterworker=true and whetheruploadvolunteerdata=true then 'APPLICATIONN FOR VOLUNTARY DATA UPDATION / RENEWAL OF EXISTING MANUAL REGISTRATION' end as APPLIED FROM dgen.applicationdetailsregconstructionworker  where ApplicationNo=@ApplicationNo"; }
            }
            Cmd = new NpgsqlCommand(Qry);
            if (AppId != null) { Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationId); }
            if (AppNo != null) { Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo); }
            model.AppliedMessage = data.SelectColumns(Cmd)[0];

            if (model.dataa.Rows.Count == 1)
            {
                if (AppId != null) { Qry = "select  PMM.PaymentMode,PMM.PaymentModeid,SF.Servicefeetype,PaymentAmount as servicefeeamount from applicationpaymentrequest APR inner join applicationpaymentdescription APD on APD.PaymentId=APR.PaymentId inner join servicefeetypemaster SF on SF.Servicefeetypeid=APD.PaymentTypeId inner join PaymentModeMaster PMM on PMM.PaymentModeId=APR.PaymentModeId where ApplicationId=@ApplicationId and paymentstatusid=(case when APR.paymentmodeid=@paymentmodeid then @SbiEpaySuccess else @SbiEpayNew end) order by PaymentAmount desc"; }
                if (AppNo != null) { Qry = "select  PMM.PaymentMode,PMM.PaymentModeid,SF.Servicefeetype,APD.PaymentAmount as servicefeeamount,APS.Paymentamount as totalamount,to_char(Paymentdate,'DD/MM/YYYY') as Paymentdate  from applicationpaymentrequest APR inner join applicationpaymentdescription APD on APD.PaymentId=APR.PaymentId inner join PaymentModeMaster PMM on PMM.PaymentModeId=APR.PaymentModeId inner join servicefeetypemaster SF on SF.Servicefeetypeid=APD.PaymentTypeId  left outer join applicationpaymentresponse APS on APS.PaymentId=APR.PaymentId where APR.ApplicationNo=@ApplicationNo and APR.paymentstatusid=@SbiEpaySuccess order by APD.PaymentAmount desc"; }
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("paymentmodeid", (int)PaymentMode.Online);
                Cmd.Parameters.AddWithValue("SbiEpaySuccess", (int)ValueId.SbiEpaySuccess);
                Cmd.Parameters.AddWithValue("SbiEpayNew", (int)ValueId.SbiEpayNewPayment);
                if (AppId != null) { Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationId); }
                if (AppNo != null) { Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo); }
                model.datab = data.GetDataTable(Cmd);
                if (Sessions.getCurrentUser() != null)
                {
                    if (AppId != null)
                    {
                        string Result = Utility.WhetherDocumentVerified(AppId.ToString(), DB.RS.ToString());
                        if (Result != CustomText.TRUE.ToString()) { model.Message = Result; }
                    }
                    if (AppNo != null)
                    {
                        string Result = Utility.WhetherDocumentVerified(AppNo.ToString(), DB.LS.ToString());
                        if (Result != CustomText.TRUE.ToString()) { model.Message = Result; }
                    }
                }
                else if (Sessions.getEmployeeUser() != null)
                {
                    model.UserName = Utility.SelectColumnsValue("usermaster", "username", "userid", Sessions.getEmployeeUser().UserId)[0];
                }
                if (model.IsPrint == 0) { model.CssClass = CssClass.InputForm.ToString(); }
                if (model.IsPrint == 1) { return this.ViewPdf("", "ConstrcutionWorkerApplicationReciept", model); }
                return View(model);
            }
            else { return RedirectToAction("OperationalError", "Error"); }
        }
        #endregion Action method for display & print acknowledgement slip

        #region Action method for display & print verification letter
        [EncryptedActionParameter]
        public ActionResult GenerateGazettedVerificationLetter(Int64? AppNo)
        {
            PrintModels model = new PrintModels();
            if (AppNo == null)
            {
                if (TempData[Constant._UniqueId] == null)
                {
                    return RedirectToAction("BadRequest", "Error");
                }
                else
                {
                    model.ApplicationNo = (Int64)TempData[Constant._UniqueId];
                }
            }
            else
            {
                model.ApplicationNo = AppNo;
            }

            string Qry = string.Empty;
            GetData data = new GetData();
            model.ServiceCode = Utility.SelectColumnsValue("dbo.ApplicationDetails", "Servicecode", "ApplicationNo", model.ApplicationNo.ToString())[0];
            if (model.ServiceCode == Convert.ToString((int)ServiceList.Domicile))
            {
                Qry = "select @ServiceCode as ServiceCode,DOM.OfficerAddress,SM1.StateName as OfficerStateName,DM1.DistrictName as OfficerDistrictName,DOM.GazettedOfficerName,DOM.OfficerGender,DOM.Designation,AD.ApplicationNo,AD.ApplicantGender,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,AD.ApplicantName,to_char(now(),'DD/MM/YYYY') as Today,AD.ApplicantFatherName,AD.ApplicantMotherName,SD.SubDivDescription,SD.SubDivAddress,DM.DistrictName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode ,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress from dbo.ApplicationDetails AD inner join drev.ApplicationDetailsDomicile DOM on DOM.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.applicationdistrictcode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode left outer join dbo.StateMaster SM1 on SM1.StateId=DOM.OfficerStateId left outer join dbo.DistrictMaster DM1 on DM1.DistrictCode=DOM.OfficerDistrictCode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
            }
            if (model.ServiceCode == Convert.ToString((int)ServiceList.SCST))
            {
                Qry = "select @ServiceCode as ServiceCode,LD.OfficerAddress,LD.TypeValueId,LD.OfficerName as GazettedOfficerName,LD.OfficerDesignation as Designation,AD.ApplicationNo,AD.ApplicantGender,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,AD.ApplicantName,to_char(now(),'DD/MM/YYYY') as Today,AD.ApplicantFatherName,AD.ApplicantMotherName,SD.SubDivDescription,SD.SubDivAddress,DM.DistrictName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode ,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress from dbo.ApplicationDetails AD inner join drev.ApplicationLetterDetails LD on LD.ApplicationNo=AD.ApplicationNo inner join drev.ApplicationDetailsscst SC on SC.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.applicationdistrictcode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
            }
            if (model.ServiceCode == Convert.ToString((int)ServiceList.ST))
            {
                Qry = "select @ServiceCode as ServiceCode,LD.OfficerAddress,LD.TypeValueId,LD.OfficerName as GazettedOfficerName,LD.OfficerDesignation as Designation,AD.ApplicationNo,AD.ApplicantGender,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,AD.ApplicantName,to_char(now(),'DD/MM/YYYY') as Today,AD.ApplicantFatherName,AD.ApplicantMotherName,SD.SubDivDescription,SD.SubDivAddress,DM.DistrictName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode ,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress from dbo.ApplicationDetails AD inner join drev.ApplicationLetterDetails LD on LD.ApplicationNo=AD.ApplicationNo inner join drev.ApplicationDetailsst ST on ST.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.applicationdistrictcode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
            }
            if (model.ServiceCode == Convert.ToString((int)ServiceList.NT))
            {
                Qry = "select @ServiceCode as ServiceCode,LD.OfficerAddress,LD.TypeValueId,LD.OfficerName as GazettedOfficerName,LD.OfficerDesignation as Designation,AD.ApplicationNo,AD.ApplicantGender,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,AD.ApplicantName,to_char(now(),'DD/MM/YYYY') as Today,AD.ApplicantFatherName,AD.ApplicantMotherName,SD.SubDivDescription,SD.SubDivAddress,DM.DistrictName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode ,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress from dbo.ApplicationDetails AD inner join drev.ApplicationLetterDetails LD on LD.ApplicationNo=AD.ApplicationNo inner join drev.ApplicationDetailsnt ST on ST.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.applicationdistrictcode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
            }
            if (model.ServiceCode == Convert.ToString((int)ServiceList.OBC))
            {
                Qry = "select @ServiceCode as ServiceCode,LD.OfficerAddress,LD.TypeValueId,LD.OfficerName as GazettedOfficerName,LD.OfficerDesignation as Designation,AD.ApplicationNo,AD.ApplicantGender,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,AD.ApplicantName,to_char(now(),'DD/MM/YYYY') as Today,AD.ApplicantFatherName,AD.ApplicantMotherName,SD.SubDivDescription,SD.SubDivAddress,DM.DistrictName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode ,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress from dbo.ApplicationDetails AD inner join drev.ApplicationLetterDetails LD on LD.ApplicationNo=AD.ApplicationNo inner join drev.ApplicationDetailsOBC OBC on OBC.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.applicationdistrictcode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
            }
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            Cmd.Parameters.AddWithValue("@StatusId", (int)Status.VERLGAZ);
            Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
            Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
            model.dataa = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count >= 1)
            {
                return this.ViewPdf("", "GenerateGazettedVerificationLetter", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not pending for gazetted verification letter in E-District Delhi.";
                return View("message");
            }
        }
        [EncryptedActionParameter]
        public ActionResult GenerateOtherStateVerificationLetter(Int64? AppNo)
        {
            PrintModels model = new PrintModels();
            if (AppNo == null)
            {
                if (TempData[Constant._UniqueId] == null)
                {
                    return RedirectToAction("BadRequest", "Error");
                }
                else
                {
                    model.ApplicationNo = (Int64)TempData[Constant._UniqueId];
                }
            }
            else
            {
                model.ApplicationNo = AppNo;
            }
            string Qry = string.Empty;
            model.ServiceCode = Utility.SelectColumnsValue("dbo.ApplicationDetails", "Servicecode", "ApplicationNo", model.ApplicationNo.ToString())[0];
            GetData data = new GetData();
            if (model.ServiceCode == Convert.ToString((int)ServiceList.OBC))
            {
                Qry = "select @ServiceCode as ServiceCode,OBC.Issuingauthority,CM.CasteName,SM.StateNAme as RStateName,AD.ApplicationNo,AD.ApplicantGender,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate, to_char( AD.ApprovedDate, 'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,to_char(now(),'DD/MM/YYYY') as Today,AD.ApplicantFatherName,AD.ApplicantMotherName,UM.UserName,UM.Designation,SD.SubDivDescription,SD.SubDivAddress,DM.DistrictName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress ,OBC.CertificateNo,OBC.RAddress,OBC.CertificateHolderName,to_char(OBC.OBCCertificateIssueDate,'DD/MM/YYYY') as CertificateIssueDate,SVM.valuename as CertificateHolderRelation from dbo.ApplicationDetails AD inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.applicationdistrictcode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode inner join drev.ApplicationDetailsOBC OBC on obc.ApplicationNo=AD.ApplicationNo inner join dbo.StateMaster SM on SM.StateId=OBC.StateId inner join dbo.castemaster CM on CM.CasteId=OBC.CasteId inner join dbo.selectmastervaluedetails SVM on SVM.valueid=OBC.certificateholderrelationid inner join dbo.UserMaster UM on UM.UserId=@UserId where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
            }
            else if (model.ServiceCode == Convert.ToString((int)ServiceList.SCST))
            {
                Qry = "select @ServiceCode as ServiceCode,SC.rissueaddress as Issuingauthority,CM.CasteName,SM.StateName,SM1.StateName as RStateName,AD.ApplicationNo,AD.ApplicantGender,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate, to_char( AD.ApprovedDate, 'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,to_char(now(),'DD/MM/YYYY') as Today,AD.ApplicantFatherName,AD.ApplicantMotherName,UM.UserName,UM.Designation,SD.SubDivDescription,SD.SubDivAddress,DM.DistrictName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress ,SC.CertificateNo,SC.RAddress,SC.rname as CertificateHolderName,to_char(SC.RIssueDate,'DD/MM/YYYY') as CertificateIssueDate,SVM.valuename as CertificateHolderRelation from dbo.ApplicationDetails AD inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.applicationdistrictcode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode inner join drev.ApplicationDetailsSCST SC on SC.ApplicationNo=AD.ApplicationNo inner join dbo.StateMaster SM on SM.StateId=SC.StateId inner join dbo.StateMaster SM1 on SM1.StateId=SC.RStateId inner join dbo.castemaster CM on CM.CasteId=SC.CasteId inner join dbo.selectmastervaluedetails SVM on SVM.valueid=SC.rwithapplicantid inner join dbo.UserMaster UM on UM.UserId=@UserId where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
            }
            else if (model.ServiceCode == Convert.ToString((int)ServiceList.ST))
            {
                Qry = "select @ServiceCode as ServiceCode,ST.rissueaddress as Issuingauthority,CM.CasteName,SM.StateName,SM1.StateName as RStateName,AD.ApplicationNo,AD.ApplicantGender,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate, to_char( AD.ApprovedDate, 'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,to_char(now(),'DD/MM/YYYY') as Today,AD.ApplicantFatherName,AD.ApplicantMotherName,UM.UserName,UM.Designation,SD.SubDivDescription,SD.SubDivAddress,DM.DistrictName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,ST.CertificateNo,ST.RAddress,ST.rname as CertificateHolderName,to_char(ST.RIssueDate,'DD/MM/YYYY') as CertificateIssueDate,SVM.valuename as CertificateHolderRelation from dbo.ApplicationDetails AD inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.applicationdistrictcode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode inner join drev.ApplicationDetailsST ST on ST.ApplicationNo=AD.ApplicationNo inner join dbo.StateMaster SM on SM.StateId=ST.StateId inner join dbo.StateMaster SM1 on SM1.StateId=ST.RStateId inner join dbo.castemaster CM on CM.CasteId=ST.CasteId inner join dbo.selectmastervaluedetails SVM on SVM.valueid=ST.rwithapplicantid inner join dbo.UserMaster UM on UM.UserId=@UserId where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
            }
            else if (model.ServiceCode == Convert.ToString((int)ServiceList.NT))
            {
                Qry = "select @ServiceCode as ServiceCode,ST.rissueaddress as Issuingauthority,CM.CasteName,SM.StateName,SM1.StateName as RStateName,AD.ApplicationNo,AD.ApplicantGender,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate, to_char( AD.ApprovedDate, 'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,to_char(now(),'DD/MM/YYYY') as Today,AD.ApplicantFatherName,AD.ApplicantMotherName,UM.UserName,UM.Designation,SD.SubDivDescription,SD.SubDivAddress,DM.DistrictName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,ST.CertificateNo,ST.RAddress,ST.rname as CertificateHolderName,to_char(ST.RIssueDate,'DD/MM/YYYY') as CertificateIssueDate,SVM.valuename as CertificateHolderRelation from dbo.ApplicationDetails AD inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.applicationdistrictcode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode inner join drev.ApplicationDetailsNT ST on ST.ApplicationNo=AD.ApplicationNo inner join dbo.StateMaster SM on SM.StateId=ST.StateId inner join dbo.StateMaster SM1 on SM1.StateId=ST.RStateId inner join dbo.castemaster CM on CM.CasteId=ST.CasteId inner join dbo.selectmastervaluedetails SVM on SVM.valueid=ST.rwithapplicantid inner join dbo.UserMaster UM on UM.UserId=@UserId where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
            }
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            Cmd.Parameters.AddWithValue("@StatusId", (int)Status.VERLOTHS);
            Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
            Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
            model.dataa = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count >= 1)
            {
                return this.ViewPdf("", "GenerateOtherStateVerificationLetter", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not pending for verification letter in E-District Delhi.";
                return View("message");
            }
        }
        [EncryptedActionParameter]
        public ActionResult PrintSolemnizationVerificationLetter(Int32? LetterDetailsId)
        {
            PrintModels model = new PrintModels();
            model.ApplicationNo = Convert.ToInt64(Utility.SelectColumnsValue("dgen.SolemnizationLetterDetails", "ApplicationNo", "LetterDetailsId", LetterDetailsId.ToString())[0]);
            if (string.IsNullOrEmpty(model.ApplicationNo.ToString()) || model.ApplicationNo == 0)
            {
                if (TempData[Constant._UniqueId] == null)
                {
                    return RedirectToAction("BadRequest", "Error");
                }
                else
                {
                    model.ApplicationNo = (Int64)TempData[Constant._UniqueId];
                }
            }

            string Qry = string.Empty;
            GetData data = new GetData();
            Qry = "select to_char(now(),'DD/MM/YYYY') as Today,SL.LetterDetailsId,SL.IssuingAuthority,SL.IssuingAuthorityAddress,AMD.ApplicationNo,AD.ApplicationStatusId,AMD.HName,AMD.HFatherName,AMD.HMotherName,to_char(AMD.HDOB,'DD/MM/YYYY') as HDOB,UM.UserName,UM.Designation,SD.SubDivDescription,SD.SubDivAddress,DM.DistrictName,dbo.displaycompleteaddressfromid(AMD.Hpshousenumber,AMD.Hpsstreetnumber,AMD.Hpssublocality,AMD.Hpslocalityid,AMD.HpsSubDivCode,AMD.Hpsdistrictcode,AMD.Hpsstateid,AMD.Hpscountryid,AMD.Hpspincode) as HPresentAddress,AMD.WName,AMD.WFatherName,AMD.WMotherName,to_char(AMD.WDOB,'DD/MM/YYYY') as WDOB,dbo.displaycompleteaddressfromid(AMD.Wpshousenumber,AMD.Wpsstreetnumber,AMD.Wpssublocality,AMD.Wpslocalityid,AMD.WpsSubDivCode,AMD.Wpsdistrictcode,AMD.Wpsstateid,AMD.Wpscountryid,AMD.Wpspincode) as WPresentAddress,dbo.displaycompleteaddressfromid(AMD.Hpmhousenumber,AMD.Hpmstreetnumber,AMD.Hpmsublocality,AMD.Hpmlocalityid,AMD.HpmSubDivCode,AMD.Hpmdistrictcode,AMD.Hpmstateid,AMD.Hpmcountryid,AMD.Hpmpincode) as HPermanentAddress,dbo.displaycompleteaddressfromid(AMD.Wpmhousenumber,AMD.Wpmstreetnumber,AMD.Wpmsublocality,AMD.Wpmlocalityid,AMD.WpmSubDivCode,AMD.Wpmdistrictcode,AMD.Wpmstateid,AMD.Wpmcountryid,AMD.Wpmpincode) as WPermanentAddress,to_char(AMD.SolemnizationDate,'DD/MM/YYYY') as  SolemnizationDate from dgen.ApplicationMarriageSolemnizationDetails AMD inner join dbo.ApplicationDetails AD on AD.ApplicationNo=AMD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.applicationdistrictcode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode inner join dgen.solemnizationletterdetails SL on SL.ApplicationNo=AMD.ApplicationNo inner join dbo.UserMaster UM on UM.UserId=@UserId  where AMD.ApplicationNo=@ApplicationNo and SL.LetterDetailsId=@LetterDetailsId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@LetterDetailsId", LetterDetailsId);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            Cmd.Parameters.AddWithValue("@StatusId", (int)Status.NOTIACT);
            Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
            model.dataa = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "PrintSolemnizationVerificationLetter", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not pending for gazetted verification letter in E-District Delhi.";
                return View("message");
            }
        }
        [EncryptedActionParameter]
        public ActionResult PrintSolemnizationNotice(Int32? LetterDetailsId)
        {
            PrintModels model = new PrintModels();
            model.ApplicationNo = Convert.ToInt64(Utility.SelectColumnsValue("dgen.SolemnizationLetterDetails", "ApplicationNo", "LetterDetailsId", LetterDetailsId.ToString())[0]);
            if (string.IsNullOrEmpty(model.ApplicationNo.ToString()) || model.ApplicationNo == 0)
            {
                if (TempData[Constant._UniqueId] == null)
                {
                    return RedirectToAction("BadRequest", "Error");
                }
                else
                {
                    model.ApplicationNo = (Int64)TempData[Constant._UniqueId];
                }
            }

            string Qry = string.Empty;
            GetData data = new GetData();
            Qry = "select to_char(now(),'DD/MM/YYYY') as Today,SL.LetterDetailsId,SL.IssuingAuthority,SL.IssuingAuthorityAddress,AMD.ApplicationNo,AD.ApplicationStatusId,AMD.HName,AMD.HFatherName,AMD.HMotherName,to_char(AMD.HDOB,'DD/MM/YYYY') as HDOB,UM.UserName,UM.Designation,SD.SubDivDescription,SD.SubDivAddress,DM.DistrictName,dbo.displaycompleteaddressfromid(AMD.Hpshousenumber,AMD.Hpsstreetnumber,AMD.Hpssublocality,AMD.Hpslocalityid,AMD.HpsSubDivCode,AMD.Hpsdistrictcode,AMD.Hpsstateid,AMD.Hpscountryid,AMD.Hpspincode) as HPresentAddress,AMD.WName,AMD.WFatherName,AMD.WMotherName,to_char(AMD.WDOB,'DD/MM/YYYY') as WDOB,dbo.displaycompleteaddressfromid(AMD.Wpshousenumber,AMD.Wpsstreetnumber,AMD.Wpssublocality,AMD.Wpslocalityid,AMD.WpsSubDivCode,AMD.Wpsdistrictcode,AMD.Wpsstateid,AMD.Wpscountryid,AMD.Wpspincode) as WPresentAddress,to_char(AMD.SolemnizationDate,'DD/MM/YYYY') as  SolemnizationDate from dgen.ApplicationMarriageSolemnizationDetails AMD inner join dbo.ApplicationDetails AD on AD.ApplicationNo=AMD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.applicationdistrictcode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode inner join dgen.solemnizationletterdetails SL on SL.ApplicationNo=AMD.ApplicationNo inner join dbo.UserMaster UM on UM.UserId=@UserId  where AMD.ApplicationNo=@ApplicationNo and SL.LetterDetailsId=@LetterDetailsId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@LetterDetailsId", LetterDetailsId);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            Cmd.Parameters.AddWithValue("@StatusId", (int)Status.NOTIACT);
            Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
            model.dataa = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "PrintSolemnizationNotice", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not pending for gazetted verification letter in E-District Delhi.";
                return View("message");
            }
        }
        [EncryptedActionParameter]
        public ActionResult PrintSolemnizationApplicantNotice(int? AppId, Int64? AppNo)
        {
            PrintModels model = new PrintModels();
            GetData data = new GetData();
            string Qry = string.Empty;

            if (AppNo != null) { Qry = "select case when (EXTRACT(DAY FROM AD.ApplicationDate))=1 then '1st' else case when (EXTRACT(DAY FROM AD.ApplicationDate))=2 then '2nd' else case when (EXTRACT(DAY FROM AD.ApplicationDate))=3 then '3rd' else (EXTRACT(DAY FROM AD.ApplicationDate))||'th' end end end as Day,to_char(to_timestamp ((EXTRACT(Month FROM AD.ApplicationDate))::text, 'MM'), 'Month') as Month,EXTRACT(YEAR FROM AD.ApplicationDate) as Year,AMD.ApplicationNo,NULL as ApplicationId,AD.ApplicationStatusId,AMD.HName,AMD.HFatherName,to_char(AMD.HDOB,'DD/MM/YYYY') as HDOB,OM.OccupationType as HOccupationName,OM1.OccupationType as WOccupationName,AMD.HResidenceYears,AMD.HOccupationId,AMD.WOccupationId,AMD.WResidenceYears,HMS.MaritalStatusName as HMaritalStatusId,dbo.displaycompleteaddressfromid(AMD.Hpmhousenumber,AMD.Hpmstreetnumber,AMD.Hpmsublocality,AMD.Hpmlocalityid,AMD.HpmSubDivCode,AMD.Hpmdistrictcode,AMD.Hpmstateid,AMD.Hpmcountryid,AMD.Hpmpincode) as HPermanentAddress,dbo.displaycompleteaddressfromid(AMD.Hpshousenumber,AMD.Hpsstreetnumber,AMD.Hpssublocality,AMD.Hpslocalityid,AMD.HpsSubDivCode,AMD.Hpsdistrictcode,AMD.Hpsstateid,AMD.Hpscountryid,AMD.Hpspincode) as HPresentAddress,AMD.WName,AMD.WFatherName,to_char(AMD.WDOB,'DD/MM/YYYY') as WDOB,WMS.MaritalStatusName as WMaritalStatusId,dbo.displaycompleteaddressfromid(AMD.Wpmhousenumber,AMD.Wpmstreetnumber,AMD.Wpmsublocality,AMD.Wpmlocalityid,AMD.WpmSubDivCode,AMD.Wpmdistrictcode,AMD.Wpmstateid,AMD.Wpmcountryid,AMD.Wpmpincode) as WPermanentAddress,dbo.displaycompleteaddressfromid(AMD.Wpshousenumber,AMD.Wpsstreetnumber,AMD.Wpssublocality,AMD.Wpslocalityid,AMD.WpsSubDivCode,AMD.Wpsdistrictcode,AMD.Wpsstateid,AMD.Wpscountryid,AMD.Wpspincode) as WPresentAddress,AMD.MarriageActId,ValueName as MarriageActName,SD.subdivdescription  from dgen.ApplicationMarriageSolemnizationDetails AMD inner join dbo.MaritalStatusMaster HMS on HMS.MaritalStatusId=AMD.HMaritalStatusId inner join dbo.MaritalStatusMaster WMS on WMS.MaritalStatusId=AMD.WMaritalStatusId inner join dbo.ApplicationDetails AD on AD.ApplicationNo=AMD.ApplicationNo left outer join SelectMasterValueDetails SMVD on SMVD.ValueId=AMD.MarriageActId inner join subdivmaster SD on SD.subdivcode=AD.applicationsubdivcode inner join OccupationMaster OM on OM.OccupationId=AMD.HOccupationId inner join OccupationMaster OM1 on OM1.OccupationId=AMD.WOccupationId where AMD.ApplicationNo=@ApplicationNo"; }
            else if (AppId != null) { Qry = "select case when (EXTRACT(DAY FROM AD.ApplicationDate))=1 then '1st' else case when (EXTRACT(DAY FROM AD.ApplicationDate))=2 then '2nd' else case when (EXTRACT(DAY FROM AD.ApplicationDate))=3 then '3rd' else (EXTRACT(DAY FROM AD.ApplicationDate))||'th' end end end as Day,to_char(to_timestamp ((EXTRACT(Month FROM AD.ApplicationDate))::text, 'MM'), 'Month') as Month,EXTRACT(YEAR FROM AD.ApplicationDate) as Year,NULL as ApplicationNo,AMD.ApplicationId,AD.ApplicationStatusId,AMD.HName,AMD.HFatherName,to_char(AMD.HDOB,'DD/MM/YYYY') as HDOB,OM.OccupationType as HOccupationName,OM1.OccupationType as WOccupationName,AMD.HResidenceYears,AMD.HOccupationId,AMD.WOccupationId,AMD.WResidenceYears,HMS.MaritalStatusName as HMaritalStatusId,dbo.displaycompleteaddressfromid(AMD.Hpmhousenumber,AMD.Hpmstreetnumber,AMD.Hpmsublocality,AMD.Hpmlocalityid,AMD.HpmSubDivCode,AMD.Hpmdistrictcode,AMD.Hpmstateid,AMD.Hpmcountryid,AMD.Hpmpincode) as HPermanentAddress,dbo.displaycompleteaddressfromid(AMD.Hpshousenumber,AMD.Hpsstreetnumber,AMD.Hpssublocality,AMD.Hpslocalityid,AMD.HpsSubDivCode,AMD.Hpsdistrictcode,AMD.Hpsstateid,AMD.Hpscountryid,AMD.Hpspincode) as HPresentAddress,AMD.WName,AMD.WFatherName,to_char(AMD.WDOB,'DD/MM/YYYY') as WDOB,WMS.MaritalStatusName as WMaritalStatusId,dbo.displaycompleteaddressfromid(AMD.Wpmhousenumber,AMD.Wpmstreetnumber,AMD.Wpmsublocality,AMD.Wpmlocalityid,AMD.WpmSubDivCode,AMD.Wpmdistrictcode,AMD.Wpmstateid,AMD.Wpmcountryid,AMD.Wpmpincode) as WPermanentAddress,dbo.displaycompleteaddressfromid(AMD.Wpshousenumber,AMD.Wpsstreetnumber,AMD.Wpssublocality,AMD.Wpslocalityid,AMD.WpsSubDivCode,AMD.Wpsdistrictcode,AMD.Wpsstateid,AMD.Wpscountryid,AMD.Wpspincode) as WPresentAddress,AMD.MarriageActId,ValueName as MarriageActName,SD.subdivdescription from wgen.ApplicationMarriageSolemnizationDetails AMD inner join dbo.MaritalStatusMaster HMS on HMS.MaritalStatusId=AMD.HMaritalStatusId inner join dbo.MaritalStatusMaster WMS on WMS.MaritalStatusId=AMD.WMaritalStatusId inner join web.ApplicationDetails AD on AD.ApplicationId=AMD.ApplicationId left outer join SelectMasterValueDetails SMVD on SMVD.ValueId=AMD.MarriageActId inner join subdivmaster SD on SD.subdivcode=AD.applicationsubdivcode inner join OccupationMaster OM on OM.OccupationId=AMD.HOccupationId inner join OccupationMaster OM1 on OM1.OccupationId=AMD.WOccupationId where AMD.ApplicationId=@ApplicationId"; }
            else { return View(model); }
            if (Sessions.getEmployeeUser() != null) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
            if (Sessions.getCurrentUser() != null) { Qry += " and AD.RegistrationId=@RegistrationId"; }
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            if (AppNo != null) { Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo); }
            else if (AppId != null) { Cmd.Parameters.AddWithValue("@ApplicationId", AppId); }
            if (Sessions.getCurrentUser() != null) { Cmd.Parameters.AddWithValue("@RegistrationId", Sessions.getCurrentUser().RegistrationId); }

            model.dataa = data.GetDataTable(Cmd);
            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "PrintSolemnizationApplicantNotice", model);
            }
            else
            {
                ViewData["message"] = "Entered No is not avialable for printing in e-District Delhi.";
                return View("message");
            }
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PrintSolemnizationApplicantNotice(PrintModels model)
        {
            if (model.ApplicationNo == null) { return View(model); }

            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationNo.ToString() });
            return RedirectToAction("PrintSolemnizationApplicantNotice", "Print", new { q = QueryString });
        }
        [EncryptedActionParameter]
        public ActionResult PrintSolemnizationWitnessNotice(Int64? AppNo)
        {
            PrintModels model = new PrintModels();
            if (AppNo == null) { return View(model); }
            GetData data = new GetData();
            string Qry = "select distinct ROW_NUMBER() OVER (ORDER BY WDL.WitnessId) AS RowNumber,dbo.displaycompleteaddressfromid(M.Hpmhousenumber,M.Hpmstreetnumber,M.Hpmsublocality,M.Hpmlocalityid,M.HpmSubDivCode,M.Hpmdistrictcode,M.Hpmstateid,M.Hpmcountryid,M.Hpmpincode) as HPermanentAddress,AD.ApplicationStatusId,M.Hname,M.Wname,to_char(M.SolemnizationDate,'DD/MM/YYYY') as SolemnizationDate,SD.subdivaddress,SD.subdivdescription,WDL.WitnessId,WDL.ApplicationNo,NULL as ApplicationId,WDL.witnessname,WDL.witnessfathername,WI.witnessidentitytype,dbo.udf_general_decrypt(WDL.witnessidentificationno) as witnessidentificationno,dbo.displaycompleteaddressfromid(WDL.witnesshousenumber,WDL.witnessstreetnumber,WDL.witnesssublocality,WDL.witnesslocalityid,WDL.witnesssubdivcode,WDL.witnessdistrictcode,WDL.witnessstateid,WDL.witnesscountryid,WDL.witnesspincode) as WitnessAddress,dbo.displaycompleteaddressfromid(M.Wpmhousenumber,M.Wpmstreetnumber,M.Wpmsublocality,M.Wpmlocalityid,M.WpmSubDivCode,M.Wpmdistrictcode,M.Wpmstateid,M.Wpmcountryid,M.Wpmpincode) as WPermanentAddress,HFathername,WFathername from dgen.marriagewitnessmaster WDL inner join dbo.witnessidentitytypemaster WI on WDL.witnessidentitytypeid=WI.witnessidentitytypeid inner join dbo.ApplicationDetails AD on AD.ApplicationNo=WDL.ApplicationNo inner join dgen.applicationmarriagesolemnizationdetails M on M.ApplicationNo=WDL.ApplicationNo inner join subdivmaster SD on AD.ApplicationSubdivcode=SD.subdivcode where WDL.ApplicationNo=@ApplicationNo order by RowNumber";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            model.dataa = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count > 0)
            {
                return this.ViewPdf("", "PrintSolemnizationWitnessNotice", model);
            }
            else
            {
                ViewData["message"] = "Entered No is not avialable for printing in e-District Delhi.";
                return View("message");
            }
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PrintSolemnizationWitnessNotice(PrintModels model)
        {
            if (model.ApplicationNo == null) { return View(model); }

            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationNo.ToString() });
            return RedirectToAction("PrintSolemnizationWitnessNotice", "Print", new { q = QueryString });
        }
        [EncryptedActionParameter]
        public ActionResult PrintCDVolunteerVerificationLetter(Int32? LetterDetailsId)
        {
            PrintModels model = new PrintModels();
            model.ApplicationNo = Convert.ToInt64(Utility.SelectColumnsValue("dgen.SolemnizationLetterDetails", "ApplicationNo", "LetterDetailsId", LetterDetailsId.ToString())[0]);
            if (string.IsNullOrEmpty(model.ApplicationNo.ToString()) || model.ApplicationNo == 0)
            {
                if (TempData[Constant._UniqueId] == null)
                {
                    return RedirectToAction("BadRequest", "Error");
                }
                else
                {
                    model.ApplicationNo = (Int64)TempData[Constant._UniqueId];
                }
            }

            string Qry = string.Empty;
            GetData data = new GetData();
            Qry = "select to_char(now(),'DD/MM/YYYY') as Today,SL.LetterDetailsId,SL.IssuingAuthority,SL.IssuingAuthorityAddress,ADCDV.ApplicationNo,AD.ApplicationStatusId,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantFatherName,to_char(AD.ApplicantDOb,'DD/MM/YYYY') as DOB,UM.UserName,UM.Designation,SD.SubDivDescription,SD.SubDivAddress,DM.DistrictName,dbo.displaycompleteaddressfromid(AD.ApplicantHouseNumber,AD.ApplicantStreetNumber,AD.ApplicantSublocality,AD.ApplicantLocalityId,AD.ApplicantSubDivCode,AD.ApplicantDistrictCode,AD.StateId,AD.CountryId,AD.ApplicantPinCode) as HPresentAddress from dgen.applicationdetailscdv ADCDV inner join dbo.ApplicationDetails AD on AD.ApplicationNo=ADCDV.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.applicationdistrictcode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicationsubdivcode inner join dgen.solemnizationletterdetails SL on SL.ApplicationNo=ADCDV.ApplicationNo inner join dbo.UserMaster UM on UM.UserId=@UserId  where ADCDV.ApplicationNo=@ApplicationNo and SL.LetterDetailsId=@LetterDetailsId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@LetterDetailsId", LetterDetailsId);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            Cmd.Parameters.AddWithValue("@StatusId", (int)Status.NOTIACT);
            Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
            model.dataa = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "PrintCDVolunteerVerificationLetter", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not pending for gazetted verification letter in E-District Delhi.";
                return View("message");
            }
        }
        #endregion Action method for display & print verification letter

        #region Action method for print other details
        [EncryptedActionParameter]
        public ActionResult PrintSelfDeclarationForm(Int32? AppId, Int64? AppNo)
        {
            PrintModels model = new PrintModels();

            if (!string.IsNullOrEmpty(AppId.ToString()))
            {
                model.SelfDeclarationDetails = Utility.GetSelfDeclarationDetails(AppId.ToString(), DB.RS.ToString());

            }
            else
            {
                model.SelfDeclarationDetails = Utility.GetSelfDeclarationDetails(AppNo.ToString(), DB.LS.ToString());
            }

            return this.ViewPdf("", "PrintSelfDeclarationForm", model);

        }
        [EncryptedActionParameter]
        public ActionResult PrintPoliceVerifcationForm(Int64 AppNo)
        {
            PrintModels model = new PrintModels();
            GetData data = new GetData();
            string Qry = "select dbo.udf_general_decrypt(AD.DocumentNo) as DocumentNo,AD.DocumentId,dbo.udf_general_decrypt(Aadhaarno) as Aadhaarno, AD.ApplicationNo,AD.ApplicantName,AD.ApplicantFatherName,case when  AD.ApplicantGender='M' then 'Male' when AD.ApplicantGender='F' then 'Female'when AD.ApplicantGender='T' then 'Transgender' end as ApplicantGender,to_char(AD.ApplicantDOB,'DD/MM/YYYY') as DOB,IdentificationMark,heightfeet,heightinch,weight,chest,AD.ApplicantMobileNo,ApplicantEmail,AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantLocalityId,LocalityName,AD.applicantSubDivcode,SubDivdescription,AD.applicantdistrictcode,districtname,DM.aaddress,DM.acontact,DM.aemail,AD.stateid,StateName,AD.countryid,CountryName,AD.applicantpincode,equalificationId,ValueName as Qualification from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsCDV  ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo inner join web.RegistrationMaster RM on RM.RegistrationId=AD.RegistrationId inner join dbo.LocalityMaster LM on LM.LocalityId=AD.applicantLocalityId inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.applicantdistrictcode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.applicantSubDivcode inner join dbo.StateMaster SM on SM.StateId=AD.stateid inner join dbo.CountryMaster CM on CM.CountryId=AD.countryid inner join selectmastervaluedetails SMVD on SMVD.ValueId=ADCDV.equalificationId where AD.ApplicationNo=@ApplicationNo";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
            model.dataa = data.GetDataTable(Cmd);
            byte[] PdfBuffer = null;
            if (model.dataa != null)
            {
                PdfBufferGenerator objBuffer = new PdfBufferGenerator();
                PdfBuffer = objBuffer.GetPdfBuffer(this, string.Empty, "PrintPoliceVerifcationForm", model);
            }
            //// send email to police verification
            //string FilePath = Utility.SaveAndDisplayFileForCDVLetter(AppNo.ToString(), PdfBuffer);

            //Dictionary<string, string> EmailDic = new Dictionary<string, string>();
            //EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
            //EmailDic.Add("ParamApplicationNo", AppNo.ToString());
            //EmailDic.Add("ParamAttachFilePath", FilePath);

            //NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type004, EmailDic);

            return this.ViewPdf("", "PrintPoliceVerifcationForm", model);

        }
        [EncryptedActionParameter]
        public ActionResult PrintAffidavitForm(Int32? AppId, Int64? AppNo)
        {
            PrintModels model = new PrintModels();
            if (!string.IsNullOrEmpty(AppId.ToString()))
            {
                model.ServiceCode = Utility.SelectColumnsValue("web.ApplicationDetails", "Servicecode", "ApplicationId", AppId.ToString())[0];
                model.AffidavitDetails = Utility.GetAffidavitDetails(AppId.ToString(), DB.RS.ToString(), model.ServiceCode);

            }
            else
            {
                model.ServiceCode = Utility.SelectColumnsValue("dbo.ApplicationDetails", "Servicecode", "ApplicationNo", AppNo.ToString())[0];
                model.AffidavitDetails = Utility.GetAffidavitDetails(AppNo.ToString(), DB.LS.ToString(), model.ServiceCode);
            }

            return this.ViewPdf("", "PrintAffidavitForm", model);
        }
        [EncryptedActionParameter]
        public ActionResult PrintCinemaInitiateInspectionLetter(Int64? AppNo, int? CId)
        {
            GetData data = new GetData();
            PrintModels model = new PrintModels();
            string Qry = string.Empty;
            if (AppNo != null)
            {
                Qry = "select E.CinemaAddress,E.cinemaname,to_char(now(),'DD/MM/YYYY') as Today,NULL as CId,AI.ApplicationNo,to_char(AI.Inspectiondate,'DD/MM/YYYY') as Inspectiondate,SV.valuename as AuthorityType,T.OfficerName,T.OfficerDesignation,T.OfficerContactNo,T.OfficerAddress,T.AuthorityName,T.AuthorityAddress from dgen.inspectionteammemberdetails T inner join dgen.ApplicationInspectionDetails AI on AI.InspectionId=T.InspectionId inner join selectmastervaluedetails SV on SV.valueid=T.AuthorityTypeId inner join dgen.applicationdetailscinematograph E on E.applicationno=AI.applicationno where AI.ApplicationNo=@ApplicationNo and AI.WhetherActive=@WhetherActive and WhetherSDMInspected=@WhetherSDMInspected";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                Cmd.Parameters.AddWithValue("@WhetherSDMInspected", CustomText.False.ToString());
                model.dataa = data.GetDataTable(Cmd);
            }
            else
            {
                Qry = "select E.CinemaAddress,E.cinemaname,to_char(now(),'DD/MM/YYYY') as Today,NULL as ApplicationNo,AI.CId,to_char(AI.Inspectiondate,'DD/MM/YYYY') as Inspectiondate,SV.valuename as AuthorityType,T.OfficerName,T.OfficerDesignation,T.OfficerContactNo,T.OfficerAddress,T.AuthorityName,T.AuthorityAddress from dgen.inspectionteammemberdetails T inner join dgen.ApplicationInspectionDetails AI on AI.InspectionId=T.InspectionId inner join selectmastervaluedetails SV on SV.valueid=T.AuthorityTypeId inner join dgen.applicationdetailsexistingcinema E on E.cid=AI.cid where AI.CId=@CId and AI.WhetherActive=@WhetherActive and WhetherSDMInspected=@WhetherSDMInspected";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@CId", CId.ToString());
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                Cmd.Parameters.AddWithValue("@WhetherSDMInspected", CustomText.False.ToString());
                model.dataa = data.GetDataTable(Cmd);
            }
            return this.ViewPdf("", "PrintCinemaInitiateInspectionLetter", model);
        }
        [EncryptedActionParameter]
        public ActionResult PrintCinemaObjectionLetter(Int64? AppNo, int? CId)
        {
            GetData data = new GetData();
            PrintModels model = new PrintModels();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            string Qry = string.Empty;
            if (AppNo != null)
            {
                Qry = "select NULL as CId,ADC.ApplicationNo,AD.ServiceCode,to_char(AD.applicationdate,'DD/MM/YYYY') as applicationdate,to_char(now(),'DD/MM/YYYY') as today,CinemaOwner,CinemaOwnerAddress,CinemaName,CinemaAddress from dgen.ApplicationDetailsCinematograph ADC inner join dbo.ApplicationDetails AD on ADC.ApplicationNo=AD.ApplicationNo where ADC.ApplicationNo=@ApplicationNo";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
                model.dataa = data.GetDataTable(Cmd);

                Qry = "select I.ObservationDC,to_char(I.Inspectedon,'DD/MM/YYYY') as Inspectedon,I.BPlanRemarksDC,I.DDMARemarksDC,I.MCDRemarksDC,I.FDRemarksDC,I.EDRemarksDC,I.ODoc1RemarksDC,I.ODoc2RemarksDC,I.siteplanremarksdc,I.tclearanceremarksdc,I.charcertremarksdc,I.whetherbplanobjectiondc,I.whetherddmaobjectiondc,I.whethermcdobjectiondc,I.whetherfdobjectiondc,I.whetheredobjectiondc,I.whethersiteplanobjectiondc,I.whethertclearanceobjectiondc,I.whethercharcertobjectiondc,I.whetherodoc1objectiondc,I.whetherodoc2objectiondc from dgen.InspectionDetails I inner join dgen.ApplicationInspectionDetails AI on AI.InspectionId=I.InspectionId where AI.ApplicationNo=@ApplicationNo and AI.WhetherActive=@WhetherActive and AI.WhetherDCInspected=@WhetherDCInspected";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                Cmd.Parameters.AddWithValue("@WhetherDCInspected", CustomText.True.ToString());
                model.datab = data.GetDataTable(Cmd);

                Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,UserId=@UserId,Ipaddress=@Ipaddress,LastActionDate=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSOBJ);
                Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                cmdList.Add(Utility.InsertDepartmentAuditTrail(AppNo.ToString(), (int)ApplicationHistoryMessage.MSG018, "", (int)ApplicationSource.Window, null));

                data.SaveData(cmdList);
            }
            else
            {
                Qry = "select NULL as ApplicationNo,AI.CId,to_char(AI.InspectionDate,'DD/MM/YYYY') as InspectionDate,to_char(now(),'DD/MM/YYYY') as today,ADC.CinemaOwnerName,ADC.CinemaName,ADC.CinemaAddress from dgen.applicationdetailsexistingcinema ADC inner join dgen.applicationinspectiondetails  AI on AI.CId=ADC.CId where ADC.CId=@CId and AI.WhetherActive=@WhetherActive";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@CId", CId.ToString());
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                model.dataa = data.GetDataTable(Cmd);

                Qry = "select I.ObservationDC,to_char(I.Inspectedon,'DD/MM/YYYY') as Inspectedon,I.BPlanRemarksDC,I.DDMARemarksDC,I.MCDRemarksDC,I.FDRemarksDC,I.EDRemarksDC,I.ODoc1RemarksDC,I.ODoc2RemarksDC,I.siteplanremarksdc,I.tclearanceremarksdc,I.charcertremarksdc,I.whetherbplanobjectiondc,I.whetherddmaobjectiondc,I.whethermcdobjectiondc,I.whetherfdobjectiondc,I.whetheredobjectiondc,I.whethersiteplanobjectiondc,I.whethertclearanceobjectiondc,I.whethercharcertobjectiondc,I.whetherodoc1objectiondc,I.whetherodoc2objectiondc from dgen.InspectionDetails I inner join dgen.ApplicationInspectionDetails AI on AI.InspectionId=I.InspectionId where AI.CId=@CId and AI.WhetherActive=@WhetherActive";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@CId", CId.ToString());
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                model.datab = data.GetDataTable(Cmd);
            }
            return this.ViewPdf("", "PrintCinemaObjectionLetter", model);
        }
        [EncryptedActionParameter]
        public ActionResult PrintHeSelfDeclarationForm(Int32? AppId, Int64? AppNo)
        {
            PrintModels model = new PrintModels();

            if (!string.IsNullOrEmpty(AppId.ToString()))
            {
                model.SelfDeclarationDetails = Utility.GetHeSelfDeclarationDetails(AppId.ToString(), DB.RS.ToString());

            }
            else
            {
                model.SelfDeclarationDetails = Utility.GetHeSelfDeclarationDetails(AppNo.ToString(), DB.LS.ToString());
            }

            return this.ViewPdf("", "PrintHeSelfDeclarationForm", model);

        }
        [EncryptedActionParameter]
        public ActionResult PrintFormIIIDeclaration(Int32? AppId, Int64? AppNo)
        {
            PrintModels model = new PrintModels();
            GetData data = new GetData();
            string Qry = string.Empty;

            if (!string.IsNullOrEmpty(AppId.ToString())) { Qry = "select AD.ApplicationId as ApplicationNo,AD.ApplicantName,to_char(MarriageDate,'DD/MM/YYYY') as MarriageDate,MarriagePlace from web.ApplicationDetails AD inner join wgen.applicationmarriagedetails AMD on AMD.ApplicationId=AD.ApplicationId where AD.ApplicationId=@ApplicationId"; }
            else { Qry = "select AD.ApplicationNo,AD.ApplicantName,to_char(MarriageDate,'DD/MM/YYYY') as MarriageDate,MarriagePlace from dbo.ApplicationDetails AD inner join dgen.applicationmarriagedetails AMD on AMD.ApplicationNo=AD.ApplicationNo where AD.ApplicationNo=@ApplicationNo"; }
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            if (!string.IsNullOrEmpty(AppId.ToString())) { Cmd.Parameters.AddWithValue("@ApplicationId", AppId.ToString()); }
            else { Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString()); }
            model.dataa = data.GetDataTable(Cmd);

            return this.ViewPdf("", "PrintFormIIIDeclaration", model);
        }
        [EncryptedActionParameter]
        public ActionResult PrintAddPaymentLetter(int ServiceCode, int AcademicSession)
        {
            GetData data = new GetData();
            PrintModels model = new PrintModels();

            string Qry = @"select AD.ApplicationNo,ApplicantName,SMVD.ValueName as CategoryId,PAP.AcademicSession,ServiceName,SchoolName,SchoolAddress,coalesce(sum(case when feeinitiateby=@Applicant then Feeamount else 0 end),0) as ApplicantFilled ,coalesce(sum(case when feeinitiateby=@Department and FeetypeBy<>@RemaningFees then Feeamount else 0 end),0) as AlreadyRecomended,coalesce(sum(case when FeetypeBy=@RemaningFees then Feeamount else 0 end),0) as AdditionalPaymentRecomended from applicationdetails AD inner join dgen.prematapplicationprocess  PAP on AD.ApplicationNo=PAP.ApplicationNo inner Join dgen.PrematSchoolMaster PSM on PSM.SchoolId=PAP.SchoolId inner join ServiceMaster SM on SM.ServiceCOde=AD.ServiceCode inner join SelectMasterValueDetails SMVD on SMVD.ValueId=PAP.CategoryId inner join dgen.scstfeedetails  SCSTFD on SCSTFD.applicationNo=AD.ApplicationNo where PAP.SchoolId=@AuthorizationId and addpaymenttypeid=@addpaymenttypeid and PAP.AcademicSession=@AcademicSession and AD.ServiceCode=@ServiceCode group by AD.ApplicationNo,SMVD.ValueName,PAP.AcademicSession,ServiceName,SchoolName,SchoolAddress order by AD.ApplicationNo";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            cmd.Parameters.AddWithValue("@addpaymenttypeid", (int)ValueId.AdditionalPaymentEntry);
            cmd.Parameters.AddWithValue("@RemaningFees", (int)ValueId.RemaningFees);
            cmd.Parameters.AddWithValue("@Applicant", (int)ValueId.Applicant);
            cmd.Parameters.AddWithValue("@Department", (int)ValueId.Department);
            cmd.Parameters.AddWithValue("@AuthorizationId", Sessions.getEmployeeUser().AuthorizationId);
            model.dataa = data.GetDataTable(cmd);

            if (model.dataa.Rows.Count > 0)
            {
                return this.ViewPdf("", "PrintAddPaymentLetter", model);

            }
            else
            {
                ViewData["message"] = "Not available for Print.";
                return View("message");
            }
        }
        [EncryptedActionParameter]
        public ActionResult PrintTirthSelfDeclarationForm(Int32? AppId, Int64? AppNo)
        {
            PrintModels model = new PrintModels();

            if (!string.IsNullOrEmpty(AppId.ToString()))
            {
                model.SelfDeclarationDetails = Utility.GetSelfDeclarationDetails(AppId.ToString(), DB.RS.ToString());

            }
            else
            {
                model.SelfDeclarationDetails = Utility.GetSelfDeclarationDetails(AppNo.ToString(), DB.LS.ToString());
            }

            return this.ViewPdf("", "PrintTirthSelfDeclarationForm", model);

        }
        [EncryptedActionParameter]
        public ActionResult PrintTirthMLACertificateForm(Int32? AppId, Int64? AppNo)
        {
            PrintModels model = new PrintModels();
            GetData data = new GetData();
            string Qry = string.Empty;

            if (!string.IsNullOrEmpty(AppId.ToString())) { Qry = "select ApplicantName,ConstituencyName,RM.DocumentId, udf_general_decrypt(RM.DocumentNo) as DocumentNo,whetherappyingwithspouse,spousename,to_char(spousedob,'DD/MM/YYYY') as spousedob,spousegender,udf_general_decrypt(spousedocumentno) as spousedocumentno,optingforattendant,attendantname,to_char(attendantdob,'DD/MM/YYYY') as attendantdob,attendantgender,udf_general_decrypt(attendantdocumentno) as attendantdocumentno from web.applicationdetails AD inner join wgen.applicationdetailstirthyatrayojana ADTY on ADTY.ApplicationId=AD.ApplicationId inner join assemblyconstituencymaster ACM on ACM.constituencyid=ADTY.constituencyid inner join registrationtodocumentmaster RM on RM.RegistrationId=AD.RegistrationId  where AD.ApplicationId=@ApplicationId  and AD.servicecode=@ServiceCode and RM.DocuMentId=@DocumentId"; }
            else { Qry = "select ApplicantName,ConstituencyName,RM.DocumentId, udf_general_decrypt(RM.DocumentNo) as DocumentNo,whetherappyingwithspouse,spousename,to_char(spousedob,'DD/MM/YYYY') as spousedob,spousegender,udf_general_decrypt(spousedocumentno) as spousedocumentno,optingforattendant,attendantname,to_char(attendantdob,'DD/MM/YYYY') as attendantdob,attendantgender,udf_general_decrypt(attendantdocumentno) as attendantdocumentno from applicationdetails AD inner join dgen.applicationdetailstirthyatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo inner join assemblyconstituencymaster ACM on ACM.constituencyid=ADTY.constituencyid inner join registrationtodocumentmaster RM on RM.RegistrationId=AD.RegistrationId  where AD.ApplicationNo=@ApplicationNo and servicecode=@ServiceCode and RM.DocuMentId=@DocumentId"; }
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.TirthYatraYojna);
            Cmd.Parameters.AddWithValue("@DocumentId", (int)DocumentId.VoterID);
            if (!string.IsNullOrEmpty(AppId.ToString())) { Cmd.Parameters.AddWithValue("@ApplicationId", AppId.ToString()); }
            else { Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString()); }
            model.dataa = data.GetDataTable(Cmd);
            return this.ViewPdf("", "PrintTirthMLACertificateForm", model);

        }
        #endregion

        #region Print CDV certificates
        [EncryptedActionParameter]
        public ActionResult PrintCDVLetter(Int64? AppNo)
        {
            PrintModels model = new PrintModels();
            if (AppNo == null)
            {
                if (TempData[Constant._UniqueId] == null)
                {
                    return RedirectToAction("BadRequest", "Error");
                }
                else
                {
                    model.ApplicationNo = (Int64)TempData[Constant._UniqueId];
                }
            }
            else
            {
                model.ApplicationNo = AppNo;
            }

            GetData data = new GetData();
            string StatusId = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ApplicationStatusId", "ApplicationNo", model.ApplicationNo.ToString())[0];

            string Qry = "select AD.ApplicationNo,to_char(now(), 'DD/MM/YYYY') as ApprovedDate,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,  AD.ApplicantName,AD.ApplicantFatherName,AD.ApplicantGender,to_char(AD.ApplicantDOB,'DD/MM/YYYY') as DOB,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,enrollmentNo,to_char(EnrollmentDate,'DD/MM/YYYY') as EnrollmentDate,to_char((EnrollmentDate + interval '3 year'::interval),'DD/MM/YYYY') as EnrollmentToDate,cdvsubdivname,NationalityName,IdentificationMark from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsCDV  ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo inner join cdvsubdivmaster CDVSDM on CDVSDM.cdvsubdivcode=ADCDV.cdvsubdivcode inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode inner join NationalityMaster NM on NM.NationalityId=AD.ApplicantNationality where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSREC);
            model.dataa = data.GetDataTable(Cmd);


            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "PrintCDVLetter", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not avialable for printing in e-District Delhi.";
                return View("message");
            }
        }

        [EncryptedActionParameter]
        public ActionResult BasicTrainingCompletionCertificate(Int64? AppNo)
        {
            PrintModels model = new PrintModels();
            if (AppNo == null)
            {
                if (TempData[Constant._UniqueId] == null)
                {
                    return RedirectToAction("BadRequest", "Error");
                }
                else
                {
                    model.ApplicationNo = (Int64)TempData[Constant._UniqueId];
                }
            }
            else
            {
                model.ApplicationNo = AppNo;
            }

            GetData data = new GetData();
            string StatusId = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ApplicationStatusId", "ApplicationNo", model.ApplicationNo.ToString())[0];

            //string Qry = "select AD.ApplicationNo,to_char(now(), 'DD/MM/YYYY') as ApprovedDate,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,  AD.ApplicantName,AD.ApplicantFatherName,AD.ApplicantGender,to_char(AD.ApplicantDOB,'DD/MM/YYYY') as DOB,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,enrollmentNo,to_char(EnrollmentDate,'DD/MM/YYYY') as EnrollmentDate,cdvsubdivname,to_char(min(trainingDate),'DD/MM/YYYY') as FromDate ,to_char(max(trainingDate),'DD/MM/YYYY') as ToDate ,VenueName from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsCDV  ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo inner join dgen.CDVApplicantTrainingDetails CDVATD on CDVATD.ApplicationNo=ADCDV.ApplicationNo inner join dgen.cdvattendancedetails  CDVAD on CDVAD.TrainingId=CDVATD.TrainingId inner join cdvsubdivmaster CDVSDM on CDVSDM.cdvsubdivcode=ADCDV.cdvsubdivcode inner join VenueMaster VM on VM.VenueID=CDVATD.VenueID inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId group by AD.ApplicationNo, ApprovedDate,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,  AD.ApplicantName,AD.ApplicantFatherName,AD.ApplicantGender,DOB,applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode,enrollmentNo, EnrollmentDate,cdvsubdivname,VenueName";
            string Qry = "select AD.ApplicationNo,to_char(now(), 'DD/MM/YYYY') as ApprovedDate,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,  AD.ApplicantName,AD.ApplicantFatherName,AD.ApplicantGender,to_char(AD.ApplicantDOB,'DD/MM/YYYY') as DOB,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,enrollmentNo,to_char(EnrollmentDate,'DD/MM/YYYY') as EnrollmentDate,cdvsubdivname,to_char(min(trainingDate),'DD/MM/YYYY') as FromDate ,to_char(max(trainingDate),'DD/MM/YYYY') as ToDate ,VenueName,coalesce(sum(case when WhetherBasicTrainingComplete=True and whetherPresent='246' then 1 end),0)as TrainingdaysCount from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsCDV  ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo inner join dgen.CDVApplicantTrainingDetails CDVATD on CDVATD.ApplicationNo=ADCDV.ApplicationNo inner join dgen.cdvattendancedetails  CDVAD on CDVAD.TrainingId=CDVATD.TrainingId inner join cdvsubdivmaster CDVSDM on CDVSDM.cdvsubdivcode=ADCDV.cdvsubdivcode inner join VenueMaster VM on VM.VenueID=CDVATD.VenueID inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId group by AD.ApplicationNo, ApprovedDate,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,  AD.ApplicantName,AD.ApplicantFatherName,AD.ApplicantGender,DOB,applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode,enrollmentNo, EnrollmentDate,cdvsubdivname,VenueName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            Cmd.Parameters.AddWithValue("@StatusId", (int)Status.ISSUCER);
            model.dataa = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "BasicTrainingCompletionCertificate", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not avialable for printing in e-District Delhi.";
                return View("message");
            }
        }
        #endregion

        #region Labour Department Process
        [EncryptedActionParameter]
        public ActionResult FirmInspectionNotice(int GId)
        {
            PrintModels model = new PrintModels();

            GetData data = new GetData();
            string Qry = "select LI.InspectionId,to_char(LI.InspectionDate,'DD/MM/YYYY')as InspectionDate,LI.InspectionDate::time as InspectionTime,LG.ServiceCode,SM.ServiceName,LI.ManagementName,LI.ManagementAddress,LI.ManagementDesignation,LI.ManagementEmail,LI.ManagementMobile,LNP.NoticepointId,LP.NoticepointDetails from dgen.lbrnoticepointdetails LNP left outer join dgen.lbrnoticepointmaster LP on LP.NoticepointId=LNP.NoticepointId left outer join dgen.lbrgrievancedetails LG on LG.servicecode=LP.servicecode left outer join dgen.lbrinspectionmaster LI on LI.grievanceid=LG.grievanceid left outer join dbo.Servicemaster SM on LG.servicecode=SM.servicecode where LI.GrievanceId=@GrievanceId";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@GrievanceId", GId);
            model.dataa = data.GetDataTable(cmd);
            if (model.dataa.Rows[0]["ServiceCode"].ToString() == "5080")
            {
                return this.ViewPdf("", "FirmInspectionNotice", model);
            }
            else if (model.dataa.Rows[0]["ServiceCode"].ToString() == "5081")
            {
                return this.ViewPdf("", "BonusActFirmInspectionNotice", model);
            }
            else if (model.dataa.Rows[0]["ServiceCode"].ToString() == "5082" || model.dataa.Rows[0]["ServiceCode"].ToString() == "5087")
            {
                return this.ViewPdf("", "MinWagesFirmInspectionNotice", model);
            }
            else if (model.dataa.Rows[0]["ServiceCode"].ToString() == "5086")
            {
                model.CLActInspectionTarget = Utility.SelectColumnsValue("dgen.lbrgrievancedetails", "CLActComplaintTarget", "GrievanceId", GId.ToString())[0];
                string Id = Utility.SelectColumnsValue("dgen.lbrinspectionmaster", "InspectionId", "GrievanceId", GId.ToString())[0];
                Qry = "select columnid,columnvalue from dgen.LBRInspectionDetails where InspectionId=@InspectionId and columnid in (@MaxWorker,@StartDate,@EndDate,@DetailsOfWork,@NameAddressOFConOffice,@NameAddressOFPEOffice,@NameAddressOFConSite,@NameAddressOFPESite) order by 1";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@InspectionId", Id);
                cmd.Parameters.AddWithValue("@MaxWorker", (int)LBRInspectionNoticeFields.MaxWorker);
                cmd.Parameters.AddWithValue("@StartDate", (int)LBRInspectionNoticeFields.StartDate);
                cmd.Parameters.AddWithValue("@EndDate", (int)LBRInspectionNoticeFields.EndDate);
                cmd.Parameters.AddWithValue("@DetailsOfWork", (int)LBRInspectionNoticeFields.DetailsOfWork);
                cmd.Parameters.AddWithValue("@NameAddressOFConOffice", (int)LBRInspectionNoticeFields.NameAddressOFConOffice);
                cmd.Parameters.AddWithValue("@NameAddressOFPEOffice", (int)LBRInspectionNoticeFields.NameAddressOFPEOffice);
                cmd.Parameters.AddWithValue("@NameAddressOFConSite", (int)LBRInspectionNoticeFields.NameAddressOFConSite);
                cmd.Parameters.AddWithValue("@NameAddressOFPESite", (int)LBRInspectionNoticeFields.NameAddressOFPESite);
                model.datab = data.GetDataTable(cmd);
                DataTable dt = new DataTable();
                DataRow dr = dt.NewRow();
                for (int i = 0; i < model.datab.Rows.Count; i++)
                {
                    dt.Columns.Add(i.ToString(), typeof(System.String));
                    dr[i] = model.datab.Rows[i]["columnvalue"].ToString();
                }
                dt.Rows.Add(dr);
                model.datab = dt;
                return this.ViewPdf("", "CLActFirmInspectionNotice", model);
            }
            else { return this.ViewPdf("", "OtherLBRNoticeTemp", model); }
        }
        [EncryptedActionParameter]
        public ActionResult GenerateLBRChallan(Int64 AppNo)
        {
            GetData data = new GetData();
            PrintModels model = new PrintModels();
            NpgsqlCommand cmd = new NpgsqlCommand();
            string Qry = string.Empty, whereCondition = string.Empty;
            int Scode = Convert.ToInt32(Utility.SelectColumnsValue("applicationdetails", "servicecode", "applicationno", AppNo.ToString())[0].ToString());

            if (Scode == (int)ServiceList.BOCW)
            {
                Qry = "select AD.applicationno,AD.servicecode,maxworkers,nameofest as lname,addressofest as laddress,SM.servicename,SD.subdivdescription from dbo.applicationdetails AD  inner join dgen.applicationdetailsbocwact BC on BC.applicationno=AD.applicationno inner join servicemaster SM on SM.servicecode=AD.servicecode inner join subdivmaster SD on SD.subdivcode=AD.applicationsubdivcode where AD.applicationno=@applicationno";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@applicationno", AppNo);
                model.dataa = data.GetDataTable(cmd);
            }
            else if (Scode == (int)ServiceList.ContractLabour)
            {
                Qry = "select AD.applicationno,AD.servicecode,nameofest as lname,addressofest as laddress,SM.servicename,SD.subdivdescription from dbo.applicationdetails AD  inner join dgen.applicationdetailsclact BC on BC.applicationno=AD.applicationno inner join servicemaster SM on SM.servicecode=AD.servicecode inner join subdivmaster SD on SD.subdivcode=AD.applicationsubdivcode where AD.applicationno=@applicationno";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@applicationno", AppNo);
                model.dataa = data.GetDataTable(cmd);

                Qry = "select maxworkers,contractorname from dgen.clactcontractordetails where applicationno=@applicationno";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@applicationno", AppNo);
                model.datab = data.GetDataTable(cmd);
            }
            else if (Scode == (int)ServiceList.Contractors)
            {
                Qry = "select AD.applicationno,AD.servicecode,maxworkers,pename,nameofestcontractor as lname,addressofcontractor as laddress,SM.servicename,SD.subdivdescription from dbo.applicationdetails AD  inner join dgen.applicationdetailscontractor BC on BC.applicationno=AD.applicationno inner join servicemaster SM on SM.servicecode=AD.servicecode inner join subdivmaster SD on SD.subdivcode=AD.applicationsubdivcode where AD.applicationno=@applicationno";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@applicationno", AppNo);
                model.dataa = data.GetDataTable(cmd);
                model.SecurityDepositFee = (Utility.GetContractorSecurityDepositFee(AppNo.ToString(), DB.LS.ToString())).ToString();
                model.FeeWords2 = Utility.ConvertNumbertoWords(Convert.ToInt32(model.SecurityDepositFee));
            }
            else if (Scode == (int)ServiceList.RenewalOfContractor)
            {
                string[] GetFeeTypes = Utility.SelectColumnsValue("dgen.ApplicationDetailsRenewalContractor", "WhetherWorkerIncreased,WhetherApplRenewal,WhetherApplAmend", "ApplicationNo", AppNo.ToString());
                model.WhetherWorkerIncreased = GetFeeTypes[0];
                model.WhetherApplRenewal = GetFeeTypes[1];
                model.WhetherApplAmend = GetFeeTypes[2];

                Qry = "select AD.applicationno,AD.servicecode,maxworkers,increasedworker,pename,nameofcon as lname,addressofcon as laddress,SM.servicename,SD.subdivdescription from dbo.applicationdetails AD  inner join dgen.applicationdetailsrenewalcontractor BC on BC.applicationno=AD.applicationno inner join servicemaster SM on SM.servicecode=AD.servicecode inner join subdivmaster SD on SD.subdivcode=AD.applicationsubdivcode where AD.applicationno=@applicationno";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@applicationno", AppNo);
                model.dataa = data.GetDataTable(cmd);

                bool WhetherRenewal = Utility.CheckRenewal(model.WhetherApplRenewal, model.WhetherApplAmend);
                if (WhetherRenewal.ToString().ToUpper() == CustomText.TRUE.ToString())
                {
                    if (model.WhetherApplRenewal == CustomText.True.ToString())
                    {
                        model.RenewalDepositFee = (Utility.GetContractorRenewalDepositFee(AppNo.ToString(), DB.LS.ToString())).ToString();
                        model.FeeWords1 = Utility.ConvertNumbertoWords(Convert.ToInt32(model.RenewalDepositFee));

                        string ApprovedDate = string.Empty;
                        string Today = DateTime.Now.ToString("dd/MM/yyyy");
                        ApprovedDate = Utility.SelectColumnsValue("dgen.applicationdetailsrenewalcontractor", "OldCertificateDate", "ApplicationNo", AppNo.ToString())[0];
                        model.OldCertificateDate = (Convert.ToDateTime(ApprovedDate)).ToString("dd/MM/yyyy");

                        if (Convert.ToDateTime(Today) > Convert.ToDateTime(model.OldCertificateDate))
                        {
                            model.PenaltyFee = (Utility.GetContractorRenewalPenaltyFee(AppNo.ToString(), DB.LS.ToString())).ToString();
                            model.FeeWords2 = Utility.ConvertNumbertoWords(Convert.ToInt32(model.RenewalDepositFee));
                        }
                    }
                    if (model.WhetherApplAmend == CustomText.True.ToString())
                    {
                        if (model.WhetherWorkerIncreased == CustomText.True.ToString())
                        {
                            model.SecurityDepositFee = (Utility.GetContractorSecurityDepositFee(AppNo.ToString(), DB.LS.ToString())).ToString();
                            model.FeeWords3 = Utility.ConvertNumbertoWords(Convert.ToInt32(model.SecurityDepositFee));

                            model.AmendmentDepositFee = (Utility.GetContractorAmendmentDepositFee(AppNo.ToString(), DB.LS.ToString())).ToString();
                            model.FeeWords4 = Utility.ConvertNumbertoWords(Convert.ToInt32(model.AmendmentDepositFee));
                        }
                    }
                    //if (model.WhetherWorkerIncreased == CustomText.True.ToString())
                    //{
                    //    model.SecurityDepositFee = (Utility.GetContractorSecurityDepositFee(AppNo.ToString(), DB.LS.ToString())).ToString();
                    //    model.FeeWords3 = Utility.ConvertNumbertoWords(Convert.ToInt32(model.SecurityDepositFee));
                    //}
                    //if (model.WhetherApplAmend == CustomText.True.ToString())
                    //{
                    //    model.AmendmentDepositFee = (Utility.GetContractorAmendmentDepositFee(AppNo.ToString(), DB.LS.ToString())).ToString();
                    //    model.FeeWords4 = Utility.ConvertNumbertoWords(Convert.ToInt32(model.AmendmentDepositFee));
                    //}
                }
                //else
                //{
                //    model.RenewalDepositFee = (Utility.GetContractorRenewalDepositFee(AppNo.ToString(), DB.LS.ToString())).ToString();
                //    model.FeeWords1 = Utility.ConvertNumbertoWords(Convert.ToInt32(model.RenewalDepositFee));

                //    string ApprovedDate = string.Empty;
                //    string Today = DateTime.Now.ToString("dd/MM/yyyy");
                //    ApprovedDate = Utility.SelectColumnsValue("dgen.applicationdetailsrenewalcontractor", "OldCertificateDate", "ApplicationNo", AppNo.ToString())[0];
                //    model.OldCertificateDate = (Convert.ToDateTime(ApprovedDate)).ToString("dd/MM/yyyy");

                //    if (Convert.ToDateTime(Today) > Convert.ToDateTime(model.OldCertificateDate))
                //    {
                //        model.PenaltyFee = (Utility.GetContractorRenewalPenaltyFee(AppNo.ToString(), DB.LS.ToString())).ToString();
                //        model.FeeWords2 = Utility.ConvertNumbertoWords(Convert.ToInt32(model.RenewalDepositFee));
                //    }
                //}                
            }
            else if (Scode == (int)ServiceList.GrantOfPassengerLift)
            {
                Qry = "select AD.applicationno,AD.servicecode,nameofowner as lname,maxspeed,addrofowner as laddress,SM.servicename,SD.subdivdescription from dbo.applicationdetails AD  inner join dgen.ApplicationDetailsGrantOfPassengerLift BC on BC.applicationno=AD.applicationno inner join servicemaster SM on SM.servicecode=AD.servicecode inner join subdivmaster SD on SD.subdivcode=AD.applicationsubdivcode where AD.applicationno=@applicationno";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@applicationno", AppNo);
                model.dataa = data.GetDataTable(cmd);
            }
            else if (Scode == (int)ServiceList.RenewalOfPassengerLift)
            {
                Qry = "select AD.applicationno,AD.servicecode,nameofowner as lname,maxspeed,addrofowner as laddress,SM.servicename,SD.subdivdescription from dbo.applicationdetails AD  inner join dgen.ApplicationDetailsRenewalOfPassengerLift BC on BC.applicationno=AD.applicationno inner join servicemaster SM on SM.servicecode=AD.servicecode inner join subdivmaster SD on SD.subdivcode=AD.applicationsubdivcode where AD.applicationno=@applicationno";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@applicationno", AppNo);
                model.dataa = data.GetDataTable(cmd);
            }
            else if (Scode == (int)ServiceList.ECLicence)
            {
                Qry = "select AD.ApplicationNo,AD.servicecode,NameofApplicant as lname,AddressofApplicant as laddress,SM.servicename,SD.subdivdescription from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsEC EC on EC.ApplicationNo=AD.ApplicationNo inner join servicemaster SM on SM.servicecode=AD.servicecode inner join subdivmaster SD on SD.subdivcode=AD.applicationsubdivcode where AD.applicationno=@applicationno";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@applicationno", AppNo);
                model.dataa = data.GetDataTable(cmd);
            }
            else if (Scode == (int)ServiceList.CompCertificate)
            {
                Qry = "select AD.ApplicationNo,AD.servicecode,AD.ApplicantName as lname,AD.ApplicantPermanentAddress as laddress,SM.servicename,SD.subdivdescription from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsCompCertificate EC on EC.ApplicationNo=AD.ApplicationNo inner join servicemaster SM on SM.servicecode=AD.servicecode inner join subdivmaster SD on SD.subdivcode=AD.applicationsubdivcode where AD.applicationno=@applicationno";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@applicationno", AppNo);
                model.dataa = data.GetDataTable(cmd);
            }


            if (Scode != (int)ServiceList.RenewalOfContractor)
            {
                model.ChallanFee = (Utility.GetConditionalFee(AppNo.ToString(), DB.LS.ToString())).ToString();
                model.FeeWords1 = Utility.ConvertNumbertoWords(Convert.ToInt32(model.ChallanFee));
            }


            if (model.WhetherApplRenewal == CustomText.True.ToString())
            {
                whereCondition = ",@challantype3";
            }
            if (model.WhetherApplAmend == CustomText.True.ToString())
            {
                whereCondition = ",@challantype4";
            }

            Qry = "select applicationno from dgen.lbrapplicationpaymentdetails where applicationno=@applicationno and challantype in (@challantype1,@challantype2" + whereCondition + ")";
            cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@applicationno", AppNo);
            cmd.Parameters.AddWithValue("@challantype1", (int)ChallanType.LicenseFee);
            cmd.Parameters.AddWithValue("@challantype2", (int)ChallanType.SecurityDeposit);
            if (model.WhetherApplRenewal == CustomText.True.ToString()) { cmd.Parameters.AddWithValue("@challantype3", (int)ChallanType.RenewalDeposit); }
            if (model.WhetherApplAmend == CustomText.True.ToString()) { cmd.Parameters.AddWithValue("@challantype4", (int)ChallanType.AmendmentDeposit); }
            string check = data.SelectColumns(cmd)[0];
            if (string.IsNullOrEmpty(check))
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                if (Convert.ToInt32(model.ChallanFee) > 0)
                {
                    if (Scode != (int)ServiceList.RenewalOfContractor)
                    {
                        Qry = "insert into dgen.lbrapplicationpaymentdetails(applicationno,challantype,whetherchallan,userid,ipaddress,lastactiondate) VALUES (@applicationno,@challantype,@whetherchallan,@userid,@ipaddress,now())";
                        cmd = new NpgsqlCommand(Qry);
                        cmd.Parameters.AddWithValue("@applicationno", AppNo);
                        cmd.Parameters.AddWithValue("@challantype", (int)ChallanType.LicenseFee);
                        cmd.Parameters.AddWithValue("@whetherchallan", CustomText.TRUE.ToString());
                        cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser() != null ? Sessions.getEmployeeUser().UserId : Sessions.getCurrentUser().RegistrationId);
                        cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(cmd);
                    }
                }

                model.ServiceCode = Scode.ToString();
                if (Scode == (int)ServiceList.Contractors)
                {
                    Qry = "insert into dgen.lbrapplicationpaymentdetails(applicationno,challantype,whetherchallan,userid,ipaddress,lastactiondate) VALUES (@applicationno,@challantype,@whetherchallan,@userid,@ipaddress,now())";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@applicationno", AppNo);
                    cmd.Parameters.AddWithValue("@challantype", (int)ChallanType.SecurityDeposit);
                    cmd.Parameters.AddWithValue("@whetherchallan", CustomText.TRUE.ToString());
                    cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser() != null ? Sessions.getEmployeeUser().UserId : Sessions.getCurrentUser().RegistrationId);
                    cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(cmd);
                }
                else if (Scode == (int)ServiceList.RenewalOfContractor)
                {
                    bool WhetherRenewal = Utility.CheckRenewal(model.WhetherApplRenewal, model.WhetherApplAmend);
                    if (WhetherRenewal.ToString().ToUpper() == CustomText.TRUE.ToString())
                    {
                        if (model.WhetherApplRenewal == CustomText.True.ToString())
                        {
                            Qry = "insert into dgen.lbrapplicationpaymentdetails(applicationno,challantype,whetherchallan,userid,ipaddress,lastactiondate) VALUES (@applicationno,@challantype,@whetherchallan,@userid,@ipaddress,now())";
                            cmd = new NpgsqlCommand(Qry);
                            cmd.Parameters.AddWithValue("@applicationno", AppNo);
                            cmd.Parameters.AddWithValue("@challantype", (int)ChallanType.RenewalDeposit);
                            cmd.Parameters.AddWithValue("@whetherchallan", CustomText.TRUE.ToString());
                            cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser() != null ? Sessions.getEmployeeUser().UserId : Sessions.getCurrentUser().RegistrationId);
                            cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                            cmdList.Add(cmd);
                        }
                        //if (model.WhetherWorkerIncreased.ToUpper() == CustomText.TRUE.ToString())
                        //{
                        //    Qry = "insert into dgen.lbrapplicationpaymentdetails(applicationno,challantype,whetherchallan,userid,ipaddress,lastactiondate) VALUES (@applicationno,@challantype,@whetherchallan,@userid,@ipaddress,now())";
                        //    cmd = new NpgsqlCommand(Qry);
                        //    cmd.Parameters.AddWithValue("@applicationno", AppNo);
                        //    cmd.Parameters.AddWithValue("@challantype", (int)ChallanType.SecurityDeposit);
                        //    cmd.Parameters.AddWithValue("@whetherchallan", CustomText.TRUE.ToString());
                        //    cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser() != null ? Sessions.getEmployeeUser().UserId : Sessions.getCurrentUser().RegistrationId);
                        //    cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        //    cmdList.Add(cmd);
                        //}
                        if (model.WhetherApplAmend == CustomText.True.ToString())
                        {
                            if (model.WhetherWorkerIncreased.ToUpper() == CustomText.TRUE.ToString())
                            {
                                Qry = "insert into dgen.lbrapplicationpaymentdetails(applicationno,challantype,whetherchallan,userid,ipaddress,lastactiondate) VALUES (@applicationno,@challantype,@whetherchallan,@userid,@ipaddress,now())";
                                cmd = new NpgsqlCommand(Qry);
                                cmd.Parameters.AddWithValue("@applicationno", AppNo);
                                cmd.Parameters.AddWithValue("@challantype", (int)ChallanType.SecurityDeposit);
                                cmd.Parameters.AddWithValue("@whetherchallan", CustomText.TRUE.ToString());
                                cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser() != null ? Sessions.getEmployeeUser().UserId : Sessions.getCurrentUser().RegistrationId);
                                cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                cmdList.Add(cmd);

                                Qry = "insert into dgen.lbrapplicationpaymentdetails(applicationno,challantype,whetherchallan,userid,ipaddress,lastactiondate) VALUES (@applicationno,@challantype,@whetherchallan,@userid,@ipaddress,now())";
                                cmd = new NpgsqlCommand(Qry);
                                cmd.Parameters.AddWithValue("@applicationno", AppNo);
                                cmd.Parameters.AddWithValue("@challantype", (int)ChallanType.LicenseFee);
                                cmd.Parameters.AddWithValue("@whetherchallan", CustomText.TRUE.ToString());
                                cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser() != null ? Sessions.getEmployeeUser().UserId : Sessions.getCurrentUser().RegistrationId);
                                cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                cmdList.Add(cmd);
                            }
                        }
                    }
                    //else
                    //{
                    //    Qry = "insert into dgen.lbrapplicationpaymentdetails(applicationno,challantype,whetherchallan,userid,ipaddress,lastactiondate) VALUES (@applicationno,@challantype,@whetherchallan,@userid,@ipaddress,now())";
                    //    cmd = new NpgsqlCommand(Qry);
                    //    cmd.Parameters.AddWithValue("@applicationno", AppNo);
                    //    cmd.Parameters.AddWithValue("@challantype", (int)ChallanType.RenewalDeposit);
                    //    cmd.Parameters.AddWithValue("@whetherchallan", CustomText.TRUE.ToString());
                    //    cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser() != null ? Sessions.getEmployeeUser().UserId : Sessions.getCurrentUser().RegistrationId);
                    //    cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    //    cmdList.Add(cmd);
                    //}
                }

                cmdList.Add(Utility.InsertDepartmentAuditTrail(AppNo.ToString(), (int)ApplicationHistoryMessage.MSG038, null, (int)ApplicationSource.Window, null));
                data.SaveData(cmdList);
                return this.ViewPdf("", "GenerateLBRChallan", model);
            }
            return this.ViewPdf("", "GenerateLBRChallan", model);
        }
        //[EncryptedActionParameter]
        //public ActionResult GenerateLBRDemandSlip(Int64 AppNo)
        //{
        //    PrintModels model = new PrintModels();
        //    GetData data = new GetData();
        //    NpgsqlCommand cmd = new NpgsqlCommand();
        //    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
        //    string Qry = string.Empty;
        //    int Scode = Convert.ToInt32(Utility.SelectColumnsValue("applicationdetails", "servicecode", "applicationno", AppNo.ToString())[0].ToString());
        //    if (Scode == (int)ServiceList.ConstructionWorker)
        //    {
        //        //if (Scode == (int)ServiceList.ConstructionWorker)
        //        //{
        //        Qry = "select Ad.servicecode,AD.applicationno,applicantname,to_char(applicationdate,'DD/MM/YYYY') as applicationdate,dbo.displaycompleteaddressfromid(ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,ad.ApplicantLocalityId,ad.ApplicantSubDivCode,ad.ApplicantDistrictCode,ad.StateId,ad.CountryId,ApplicantPinCode) as ApplicantAddress from dbo.applicationdetails AD inner join  dgen.applicationdetailsregconstructionworker ADRCW on AD.applicationno=ADRCW.applicationno where AD.applicationno=@applicationno";
        //        cmd = new NpgsqlCommand(Qry);
        //        cmd.Parameters.AddWithValue("@applicationno", AppNo);
        //        model.dataa = data.GetDataTable(cmd);
        //        //}
        //        //if (Scode == (int)ServiceList.ConstructionWorker)
        //        //{
        //        Qry = "select applicationno from dgen.lbrapplicationpaymentdetails where applicationno=@applicationno and challantype in (@challantype)";
        //        cmd = new NpgsqlCommand(Qry);
        //        cmd.Parameters.AddWithValue("@applicationno", AppNo);
        //        cmd.Parameters.AddWithValue("@challantype", (int)ChallanType.DemandSlip);
        //        string check = data.SelectColumns(cmd)[0];
        //        if (string.IsNullOrEmpty(check))
        //        {

        //            Qry = "insert into dgen.lbrapplicationpaymentdetails(applicationno,challantype,whetherchallan,userid,ipaddress,lastactiondate) VALUES (@applicationno,@challantype,@whetherchallan,@userid,@ipaddress,now())";
        //            cmd = new NpgsqlCommand(Qry);
        //            cmd.Parameters.AddWithValue("@applicationno", AppNo);
        //            cmd.Parameters.AddWithValue("@challantype", (int)ChallanType.DemandSlip);
        //            cmd.Parameters.AddWithValue("@whetherchallan", CustomText.TRUE.ToString());
        //            cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser() != null ? Sessions.getEmployeeUser().UserId : Sessions.getCurrentUser().RegistrationId);
        //            cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
        //            cmdList.Add(cmd);

        //            //}

        //        }
        //    }
        //    else if (Scode == (int)ServiceList.RenewalConsWorker)
        //    {
        //        //if (Scode == (int)ServiceList.ConstructionWorker)
        //        //{
        //        Qry = "select Ad.servicecode,AD.applicationno,applicantname,to_char(applicationdate,'DD/MM/YYYY') as applicationdate,latefees ,dbo.displaycompleteaddressfromid(ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,ad.ApplicantLocalityId,ad.ApplicantSubDivCode,ad.ApplicantDistrictCode,ad.StateId,ad.CountryId,ApplicantPinCode) as ApplicantAddress from dbo.applicationdetails AD inner join  dgen.applicationdetailsrenewalconsworker ADRCW on AD.applicationno=ADRCW.applicationno where AD.applicationno=@applicationno";
        //        cmd = new NpgsqlCommand(Qry);
        //        cmd.Parameters.AddWithValue("@applicationno", AppNo);
        //        model.dataa = data.GetDataTable(cmd);
        //        //}
        //        //if (Scode == (int)ServiceList.ConstructionWorker)
        //        //{
        //        Qry = "select applicationno from dgen.lbrapplicationpaymentdetails where applicationno=@applicationno and challantype in (@challantype)";
        //        cmd = new NpgsqlCommand(Qry);
        //        cmd.Parameters.AddWithValue("@applicationno", AppNo);
        //        cmd.Parameters.AddWithValue("@challantype", (int)ChallanType.DemandSlip);
        //        string check = data.SelectColumns(cmd)[0];
        //        if (string.IsNullOrEmpty(check))
        //        {

        //            Qry = "insert into dgen.lbrapplicationpaymentdetails(applicationno,challantype,whetherchallan,userid,ipaddress,lastactiondate) VALUES (@applicationno,@challantype,@whetherchallan,@userid,@ipaddress,now())";
        //            cmd = new NpgsqlCommand(Qry);
        //            cmd.Parameters.AddWithValue("@applicationno", AppNo);
        //            cmd.Parameters.AddWithValue("@challantype", (int)ChallanType.DemandSlip);
        //            cmd.Parameters.AddWithValue("@whetherchallan", CustomText.TRUE.ToString());
        //            cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser() != null ? Sessions.getEmployeeUser().UserId : Sessions.getCurrentUser().RegistrationId);
        //            cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
        //            cmdList.Add(cmd);

        //            //}

        //        }
        //    }
        //    data.SaveData(cmdList);
        //    return this.ViewPdf("", "GenerateLBRDemandSlip", model);
        //}
        [EncryptedActionParameter]
        public ActionResult GenerateLBRDeficiency(Int64 AppNo, int InsId = 0)
        {
            string Qry = string.Empty;
            GetData data = new GetData();
            PrintModels model = new PrintModels();
            NpgsqlCommand cmd = new NpgsqlCommand();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

            int Scode = Convert.ToInt32(Utility.SelectColumnsValue("applicationdetails", "servicecode", "applicationno", AppNo.ToString())[0].ToString());

            //if (Scode == (int)ServiceList.CEA1 || Scode == (int)ServiceList.CEA2 || Scode == (int)ServiceList.CEA3)
            //{
                if (Scode == (int)ServiceList.CEA1)
                {
                    Qry = "select CEA1.ApplicationNo,AD.ApplicationStatusId,CEA1.Nameofins,CEA1.Addofins,CEA1.Detailsofins,CEA1.Localityofins,CEA1.Nameofowner,CEA1.Addrofowner,CEA1.Mobilenoofowner,CEA1.Emailofowner,CEA1.Nameofconcerned,CEA1.Addrofconcerned,CEA1.Mobilenoofconcerned,CEA1.Emailofconcerned,CEA1.Faultlevelofins,CEA1.Interruptingcap,CEA1.Mingrndclearance,CEA1.Whetherrpcomplied,CEA1.Whethercompleted,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,AD.ServiceCode from dgen.ApplicationDetailsCEA1 CEA1 inner join dbo.ApplicationDetails AD on CEA1.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where CEA1.ApplicationNo=@ApplicationNo  and AD.ApplicationStatusId=@ApplicationStatusId";//changes1206
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                    if (Sessions.getEmployeeUser() != null)// When citizen takes print these queries willn't work at citizen level
                    {
                        cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSPEN);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.SCOM047);
                    }
                    model.dataa = data.GetDataTable(cmd);

                    Qry = "select m.* from (select um.username,to_char(inspectedon,'DD/MM/YYYY') as inspectedon from dgen.lbrliftinspectionmaster a  inner join usermaster um on um.uid=a.inspectedby  where a.applicationno=@applicationno order by 1 desc limit 1) m union all select um.username,to_char(inspectedon,'DD/MM/YYYY') as inspectedon from dgen.lbradditionalverifierdetails lavd inner join (select a.inspectionid from dgen.lbrliftinspectionmaster a  where a.applicationno=@applicationno  order by 1 desc limit 1 )llim on  llim.inspectionid=lavd.inspectionid   inner join usermaster um on um.uid=lavd.inspectedby";//changes1206
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                    if (Sessions.getEmployeeUser() != null)// When citizen takes print these queries willn't work at citizen level
                    {
                        cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSPEN);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.SCOM047);
                    }
                    model.datac = data.GetDataTable(cmd);

                    Qry = "Select ID.DetailsId,SID.ApplicationNo,ID.ColumnId,case when ID.ColumnValue='True' then 'Yes' else 'No' end as ColumnValue,ID.WhetherDeficiency,ICD.ColumnName from dgen.lbrinspectioncolumnmaster ICD inner join dgen.LBRliftInspectionDetails ID on ID.ColumnId=ICD.ColumnId inner join dgen.lbrliftinspectionmaster SID on  SID.InspectionId= ID.InspectionId where SID.ApplicationNo=@ApplicationNo  and  ID.WhetherDeficiency =@WhetherDeficiency and ID.InspectionId=@InspectionId";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                    cmd.Parameters.AddWithValue("@WhetherDeficiency", CustomText.True.ToString());
                    cmd.Parameters.AddWithValue("@InspectionId", InsId);
                    model.datab = data.GetDataTable(cmd);
                }
                else if (Scode == (int)ServiceList.CEA2)
                {
                    Qry = "select CEA2.ApplicationNo,AD.ApplicationStatusId,CEA2.Nameofohline,CEA2.Locationofohline,CEA2.Localityofins,CEA2.Nameofowner,CEA2.AddrofOwner,CEA2.Nameofconcerned,CEA2.Addrofconcerned,CEA2.Mobilenoofconcerned,CEA2.Emailofconcerned,CEA2.Whetherinscompleted,to_char(CEA2.DateofInspection,'DD/MM/YYYY') as DateofInspection,to_char(CEA2.TargetDate,'DD/MM/YYYY') as TargetDate,to_char(CEA2.ProbDateofInsp,'DD/MM/YYYY') as ProbDateofInsp,CEA2.Feedeposit,CEA2.Singleciruit,CEA2.Doubleciruit,CEA2.Totalroutelen,CEA2.Conductor,CEA2.Groundwire,CEA2.Average,CEA2.Minimum,CEA2.Maximum,CEA2.NormalSpan,CEA2.Nhighway,CEA2.Shighway,CEA2.Otherroad,CEA2.Pl800kv,CEA2.Pl400kv,CEA2.Pl220kv,CEA2.Pl132kv,CEA2.Pl66kv,CEA2.Pl33kv,CEA2.Pl11kv,CEA2.Ltlines,CEA2.Railwaycrossing,CEA2.Rivercrossing,CEA2.Specialcrossing,CEA2.Factofsafety,CEA2.Whetherduly,CEA2.Toweracd,CEA2.Dangernb,CEA2.Lightningfaults,CEA2.Groundfaults,CEA2.Snappedconductors,CEA2.Otherprotection,CEA2.Volregulation,CEA2.Whetherceaprov,CEA2.Whetherinspsubstation,CEA2.Maxheightoftower,CEA2.Neardistofline,CEA2.Nameofsubstation,CEA2.BayNo,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,AD.ServiceCode from dgen.ApplicationDetailsCEA2 CEA2 inner join dbo.ApplicationDetails AD on CEA2.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where CEA2.ApplicationNo=@ApplicationNo  and AD.ApplicationStatusId=@ApplicationStatusId";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                    cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSPEN);
                    model.dataa = data.GetDataTable(cmd);

                    Qry = "Select SID.ApplicationNo,ID.ColumnId,case when ID.ColumnValue='True' then 'Yes' else 'No' end as ColumnValue,ID.WhetherDeficiency,ICD.ColumnName from dgen.lbrinspectioncolumnmaster ICD inner join dgen.LBRliftInspectionDetails ID on ID.ColumnId=ICD.ColumnId inner join dgen.lbrliftinspectionmaster SID on  SID.InspectionId= ID.InspectionId where SID.ApplicationNo=@ApplicationNo  and  ID.WhetherDeficiency =@WhetherDeficiency and ID.InspectionId=@InspectionId";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                    cmd.Parameters.AddWithValue("@WhetherDeficiency", CustomText.True.ToString());
                    cmd.Parameters.AddWithValue("@InspectionId", InsId);
                    model.datab = data.GetDataTable(cmd);
                }
                else if (Scode == (int)ServiceList.CEA3)
                {
                    Qry = "select AD.ApplicationNo,AD.ApplicationStatusId,CEA3.Nameofinstall,CEA3.NameofIns,CEA3.WhetherPertainEI,CEA3.Localityofins,CEA3.Nameofowner,CEA3.Addrofowner,CEA3.Nameofconcerned,CEA3.Addrofconcerned,CEA3.Mobilenoofconcerned,CEA3.Emailofconcerned,CEA3.Whetherrelprovcea,CEA3.Whetherappliedforown,to_char(CEA3.Dateofreceiptofinsp,'DD/MM/YYYY') as DateofReceiptofInsp,to_char(CEA3.Dateofreg43,'DD/MM/YYYY') as DateofReg43,to_char(CEA3.Dateofreg30,'DD/MM/YYYY') as DateofReg30,CEA3.Feedeposit,CEA3.Whetherobslastinsp,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,AD.ServiceCode from dgen.ApplicationDetailsCEA3 CEA3 inner join dbo.ApplicationDetails AD on CEA3.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where CEA3.ApplicationNo=@ApplicationNo  and AD.ApplicationStatusId=@ApplicationStatusId";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                    cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSPEN);
                    model.dataa = data.GetDataTable(cmd);

                    Qry = "Select SID.ApplicationNo,ID.ColumnId,case when ID.ColumnValue='True' then 'Yes' else 'No' end as ColumnValue,ID.WhetherDeficiency,ICD.ColumnName from dgen.lbrinspectioncolumnmaster ICD inner join dgen.LBRliftInspectionDetails ID on ID.ColumnId=ICD.ColumnId inner join dgen.lbrliftinspectionmaster SID on  SID.InspectionId= ID.InspectionId where SID.ApplicationNo=@ApplicationNo  and  ID.WhetherDeficiency =@WhetherDeficiency and ID.InspectionId=@InspectionId";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                    cmd.Parameters.AddWithValue("@WhetherDeficiency", CustomText.True.ToString());
                    cmd.Parameters.AddWithValue("@InspectionId", InsId);
                    model.datab = data.GetDataTable(cmd);
                }
                else { return RedirectToAction("BadRequest", "Error"); }

                Qry = "Insert into dgen.LBRCEADEFICIENCYMASTER (InspectionId,DefGeneratedDate,DefGeneratedBy,DefIpaddress) Values(@InspectionId,now(),@DefGeneratedBy,@DefIpaddress)";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@InspectionId", InsId);
                cmd.Parameters.AddWithValue("@DefGeneratedBy", Sessions.getEmployeeUser().UserId);
                cmd.Parameters.AddWithValue("@DefIpaddress", Utility.GetIP4Address());
                cmdList.Add(cmd);

                Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
                cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.SCOM047);
                cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(AppNo.ToString(), (int)Status.SCOM047, (int)CountList.Type001, DB.LS.ToString()));
                cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(cmd);

                Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,userid=@userid,IpAddress=@IpAddress,ActionDateTime=now() where ApplicationNo=@ApplicationNo";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
                cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.SCOM047);
                cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                cmdList.Add(cmd);

                data.SaveData(cmdList);
                ViewData["message"] = "Defeciency has been raised successfully on Application [" + AppNo.ToString() + "]";
            //}
            return this.ViewPdf("", "GenerateLBRDeficiency", model);
        }
        #endregion

        #region Action method for print Application Form
        [EncryptedActionParameter]
        public ActionResult PrintOnlineApplication(Int64 AppNo)
        {
            PrintModels model = new PrintModels();
            GetData data = new GetData();
            string[] GetValue = Utility.SelectColumnsValue("dbo.ApplicationDetails", "Servicecode,ApplicationDistrictCode", "ApplicationNo", AppNo.ToString());
            model.ServiceCode = GetValue[0];
            model.DistrictCode = GetValue[1];

            model.ApplicantDetails = Utility.GetApplicantDetails(AppNo.ToString(), DB.LS.ToString());

            string[] GetValues = Utility.SelectColumnsValue("dbo.districtmaster", "districtname,daddress", "districtcode", model.DistrictCode);
            model.DistrictName = GetValues[0];
            model.DAddress = GetValues[1];

            TempData[KeyName._Key01] = true;
            if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.Handicapped)
            {
                model.ApplicationHandicappedDetails = Utility.GetHandicappedDetails(AppNo.ToString(), DB.LS.ToString());
                model.ApplicationHandicappedDetails.TableWidth = 100;
            }
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.OldAge)
            {
                model.ApplicationOldAgeDetails = Utility.GetOldAgeDetails(AppNo.ToString(), DB.LS.ToString());
                model.ApplicationOldAgeDetails.TableWidth = 100;
            }
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.Widow)
            {
                model.ApplicationWidowDetails = Utility.GetWidowDetails(AppNo.ToString(), DB.LS.ToString());
                model.ApplicationWidowDetails.TableWidth = 100;
            }
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.Ladli)
            {
                model.ApplicationDetailsLadli = Utility.GetLadliDetails(AppNo.ToString(), DB.LS.ToString());
                model.ApplicationDetailsLadli.TableWidth = 100;
            }
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.NFSNewRc)
            {
                model.NfsApplicationDetails = Utility.GetNfsNewRc(AppNo.ToString(), DB.LS.ToString());
                model.NfsApplicationDetails.TableWidth = 100;
            }
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.DFBScheme)
            {
                model.ApplicationDetailsDFBScheme = Utility.GetDFBSchemeDetails(AppNo.ToString(), DB.LS.ToString());
                model.ApplicationDetailsDFBScheme.TableWidth = 100;
            }
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.HigherEducationSKGS)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { Convert.ToInt64(AppNo) });
                return RedirectToAction("PrintHigherEducationSKGSForm", "Print", new { q = QueryString });
            }
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.MeritscholarshipProfessional || Convert.ToInt16(model.ServiceCode) == (int)ServiceList.PostmatricScholarshipOBC || Convert.ToInt16(model.ServiceCode) == (int)ServiceList.PostmatricSC)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo", "ServiceCode" }, new ArrayList() { Convert.ToInt64(AppNo), model.ServiceCode });
                return RedirectToAction("PrintPreMatSCApplicationReciept", "Print", new { q = QueryString });
            }
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.PrematricScholarshipSC)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { Convert.ToInt64(AppNo) });
                return RedirectToAction("PrintTutionFeeApplication", "Print", new { q = QueryString });
            }
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.FinancialAssistanceStationery)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { Convert.ToInt64(AppNo) });
                return RedirectToAction("PrintFinancialAssistanceApplication", "Print", new { q = QueryString });
            }
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.MeritscholarshipSchool)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { Convert.ToInt64(AppNo) });
                return RedirectToAction("PrintMeritSchoolApplication", "Print", new { q = QueryString });
            }
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.DrbrAmbedkarToppers)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { Convert.ToInt64(AppNo) });
                return RedirectToAction("PrintBRAmbedkarApplication", "Print", new { q = QueryString });
            }
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.PrematricScholarshipOBC)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { Convert.ToInt64(AppNo) });
                return RedirectToAction("PrintPreMatricApplication", "Print", new { q = QueryString });
            }
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.PrematricSC)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { Convert.ToInt64(AppNo) });
                return RedirectToAction("PrintPreMatricSCApplication", "Print", new { q = QueryString });
            }
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.HeFinancialAssistance)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { Convert.ToInt64(AppNo) });
                return RedirectToAction("PrintHeFinancialAssistance", "Print", new { q = QueryString });
            }
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.ECLicence)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { Convert.ToInt64(AppNo) });
                return RedirectToAction("PrintECLicenceDetails", "Print", new { q = QueryString });
            }
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.CompCertificate)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { Convert.ToInt64(AppNo) });
                return RedirectToAction("PrintCompetencyDetails", "Print", new { q = QueryString });
            }
            else
            {
                ViewData["message"] = "Printing of Application Form For This Service is Not Available in e-District Delhi.";
                return View("message");
            }

            model.datab = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "ApplicationPhotoDetails", string.Empty, string.Empty, AppNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.SelfDeclarationDetails = Utility.GetSelfDeclarationDetails(AppNo.ToString(), DB.LS.ToString());
            string Qry = "select case when AED.DepartmentId=1 then AED.OtherDepartment else ED.DeptName end as DeptName,DTM.DocumentTypeName,case when AED.DocumentId is null then '--' else (case when AED.DocumentDetails is not null then DM.DocumentName || ' (' || AED.DocumentDetails || ')' else DM.DocumentName end) end as DocumentName,case when AED.DocumentNo is null then '--' else dbo.udf_general_decrypt(AED.DocumentNo) end as DocumentNo,case when AE.verifyvalueid=58 then 'Yes' else 'No' end as VerifyValueName from dbo.ApplicationEnclosureDetails AED inner join dbo.ApplicationDetails AD on AD.ApplicationNo=AED.ApplicationNo inner join dbo.DocumentTypeMaster DTM on DTM.DocumentTypeID=AED.DocumentTypeId left outer join dbo.DocumentMaster DM on DM.DocumentID=AED.DocumentId left outer join dbo.servicetodocumentmaster STDM on STDM.servicecode=AED.servicecode and STDM.DocumentTypeId=AED.DocumentTypeId left outer join dbo.applicantenclosuredetails AE on AE.enclosureid=AED.referenceenclosureid and AE.registrationId=AD.registrationId left outer join selectmastervaluedetails SMV on SMV.valueid=AE.verifyvalueid left outer join dbo.enclosuredepartmentmaster ED on ED.DepartmentId=AED.DepartmentId where AED.ApplicationNo=@ApplicationNo and AE.documentdata is not null order by STDM.displayorder,DTM.DocumentTypeName,DM.DocumentName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            model.dataa = data.GetDataTable(Cmd);

            return View(model);
        }

        [EncryptedActionParameter]
        public ActionResult PrintHigherEducationSKGSForm(Int64? AppNo)
        {
            PrintModels model = new PrintModels();
            if (AppNo == null)
            {
                if (TempData[Constant._UniqueId] == null)
                {
                    return RedirectToAction("BadRequest", "Error");
                }
                else
                {
                    model.ApplicationNo = (Int64)TempData[Constant._UniqueId];
                }
            }
            else
            {
                model.ApplicationNo = AppNo;
            }

            GetData data = new GetData();
            string StatusId = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ApplicationStatusId", "ApplicationNo", model.ApplicationNo.ToString())[0];

            string Qry = "select AD.ApplicationNo,AD.ApplicationStatusId,DistM.DistrictName,SD.SubDivAddress,AD.ApplicantGender,AD.ApplicantName,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,AD.ApplicantMobileNo,HSDS. UniversityId,UniversityName,HSDS.InstitutionId , InstituitonName as Institution,CollegeName,CollegeAddress,SSM.StateName as CollegeState,OutUniversityName,HSDS.CourseId,CourseName as CourseType,HSDS.CoursePeriod,HSDS.Course, QualificationRequired, SMVDD.ValueName as QualificationRequiredType, WhetherDelhiGovtEmp,HSDS.RelationId,RelM.ValueName as RelationName,ParentName,DepartmentName,PostedSince,ParentPermanentAddress,ParentPinCode,SMM.StateName as ParentState,WhetherExistingLoan,BankId,BM.BankName ,BankDetails,LoanType,LoanAmount,OutSandingAmount,WhetherPhysicallyChallange,CasteId,CM.ValueName as CasteName,HSDS.ReligionId,ReligionName,StudentPANNo,GuardianName,RelationStudentId,RMM.ValueName as RelationStudent,to_char(GuardianDob,'DD/MM/YYYY') as GuardianDob,GuardianGender,WhetherTaxPayable,GuardianPANNo,GuardianIdProof,DocumentName as GuardianProofType,GuardianIdProofNo,GuardianPsAdress,PsPinCode,WhetherSamePs,GuardianPmAddress,PmPinCode,GuardianContactNo,GuardianEmail,ResidingTypeId,SMD.ValueName as ResidingType,ResidingPeriod,WhetherSalaried,OrganizationName,OffcieAddress,OfficePinCode,OfficeContactNo,OfficeEmail,OrganizationTypeId,SMDD.ValueName as OrganizationType,DesignationType,LoanBankId,HBM.BankName as LoanBank,BranchId, BranchName,BranchAddress,BranchEmail,BranchContactNo,InterestRate as BaseInterestRate from dbo.ApplicationDetails AD inner join  dgen.HeSkillDevelopmentScheme  HSDS on   HSDS.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DistM on DistM.DistrictCode=AD.ApplicantDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicantSubDivCode inner join HeUniversityMaster HUM on HUM.UniversityId=HSDS.UniversityId inner join HeInstitutionMaster HIM on HIM.InstituitonId=HSDS.InstitutionId inner join SelectMasterValueDetails SMVDD on SMVDD.ValueId=HSDS.QualificationRequired inner join SelectMasterValueDetails CM on CM.ValueId=HSDS.CasteId  inner join SelectMasterValueDetails RMM on RMM.ValueId=HSDS.RelationStudentId  inner join DocumentMaster DM on DM.DocumentId=HSDS.GuardianIdProof inner join SelectMasterValueDetails SMD on SMD.ValueId=HSDS.ResidingTypeId  inner join HeBankMaster HBM on HBM.HeBankCode=HSDS.LoanBankId inner join HeBankBranchMaster HBBM on HBBM.HeBranchCode=HSDS.BranchId inner join HeCourseMaster HCM on HCM.HeCourseid=HSDS.Courseid left outer join SelectMasterValueDetails RelM on RelM.valueId=HSDS.RelationId left outer join BankMaster BM on BM.BankCode=HSDS.BankId left outer join SelectMasterValueDetails SMDD on SMDD.ValueId=HSDS.OrganizationTypeId Left Outer join ReligionMaster RM on RM.ReligionId=HSDS.ReligionId  Left outer join StateMaster SMM on SMM.StateId=HSDS.ParentState Left outer join StateMaster SSM on SSM.StateId=HSDS.CollegeState where AD.ApplicationNo=@ApplicationIdNo";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationIdNo", model.ApplicationNo);
            model.dataa = data.GetDataTable(Cmd);
            Qry = "select ApplicationNo,ExaminationId,SMVD.valueName as ExaminationType,InstitutionId,SchoolName as InstitutionType,InstitutionDetails,HED.BoardId,SMB.ValueName as BoardType,BoardDetails,HED.SchoolCategoryId,RelM.valueName as SchoolCategoryType from dgen.HeEducationalDetails HED inner join SelectMasterValueDetails SMVD on SMVD.ValueId=HED.ExaminationId left Outer join HeSchoolMaster SMVDD on SMVDD.SchoolID=HED.InstitutionId left outer join SelectMasterValueDetails RelM on RelM.valueId=HED.SchoolCategoryId left outer join SelectMasterValueDetails SMB on SMB.valueId=HED.BoardId where HED.ApplicationNo=@ApplicationIdNo";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationIdNo", model.ApplicationNo);
            model.datab = data.GetDataTable(Cmd);

            Qry = "select ApplicationNo,RequirementFor,PayableFees,ExaminationFees,CostofBooks,CautiondePosits,AnyOtherExpense from  dgen.HeEducationalExpenditure where ApplicationNo=@ApplicationIdNo";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationIdNo", model.ApplicationNo);
            model.datac = data.GetDataTable(Cmd);

            Qry = "select ApplicationNo,LoanPeriodFor,LoanAmount,OwnSource,Scholarship from dgen.hefinancedetails where ApplicationNo=@ApplicationIdNo";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationIdNo", model.ApplicationNo);
            model.datad = data.GetDataTable(Cmd);

            Qry = "select ApplicationNo,ReferenceName,ReferenceAddress,ReferenceContact from dgen.HeReferenceDetails where ApplicationNo=@ApplicationIdNo";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationIdNo", model.ApplicationNo);
            model.datae = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                return View(model);
            }
            else
            {
                ViewData["message"] = "Entered Application not avialable for printing in e-District Delhi.";
                return View("message");
            }
        }

        [EncryptedActionParameter]
        public ActionResult PrintTutionFeeApplication(Int64? AppNo)
        {
            PrintModels model = new PrintModels();

            string Qry = string.Empty;
            GetData data = new GetData();
            Qry = "select dbo.displaycompleteaddressfromid(AD.ApplicantHouseNumber,AD.ApplicantStreetNumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.Applicantsubdivcode,AD.Applicantdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as Address,AD.ApplicantName,to_char(AD.ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,AD.ApplicantGender,AD.ApplicantFatherName,AD.applicantmobileno,dbo.udf_general_decrypt(RM.documentno) as documentno,AD.ServiceCode,SR.servicename,(AcademicSession::integer ||'-'||AcademicSession::integer + 1) as yearrange,SC.ApplicationNo,SC.Annualincome,SV.valuename as ApplyingFor,case when SC.WhetherPANNo=true then 'Yes' else 'No' end as WhetherPANNo,SC.Panno,case when SC.WhetherCollegeInDelhi=true then 'Yes' else 'No' end as WhetherCollegeInDelhi,SV1.valuename as CategoryId,SCH.schoolname as CollegeName,SCH.schooladdress as Collegeaddress,SCH.schoolaffiliationid as CollegeaffiliationId,SCH.pincode as CollegePincode,DM.districtname as CollegeDistrict,SM2.StateName as CollegeState,SM2.StateId as StateId,PA.valuename as Presentclass,PR.ValueName as Previousclass,SC.Yearclasspassed,SC.Attendancepercentage,SC.Markspercentage,SC.AccountholderName,SC.AccountNo,BM.BankName,BMP.BranchAddress as BankBranchName,BM.BankName as Bankcode,SC.Ifsccode,SC.Micrcode,AD.ApplicationStatusId,SV4.ValueName as Declaration from dgen.applicationdetailsprematssc SC  inner join dbo.applicationdetails AD on AD.ApplicationNo=SC.ApplicationNo  inner join bankmaster BM on BM.bankcode=SC.bankcode inner join bankmappingmaster BMP on BMP.IFSCCode=SC.IFSCCode and BMP.bankcode=SC.bankcode  inner join selectmastervaluedetails PA on PA.valueid=SC.Presentclass  inner join selectmastervaluedetails SV on SV.valueid=SC.ApplyingFor  inner join selectmastervaluedetails SV1 on SV1.valueid=SC.CategoryId inner join web.registrationmaster RM on RM.registrationid=AD.registrationid inner join servicemaster SR on SR.servicecode=AD.servicecode left outer join selectmastervaluedetails PR on PR.valueid=SC.Previousclass left outer join dgen.prematschoolmaster SCH on SCH.SchoolId=SC.SchoolId left outer join districtmaster DM on DM.districtcode=SCH.district   left outer join statemaster SM2 on SM2.StateId=SCH.State left outer join selectmastervaluedetails SV4 on SV4.valueid=SC.DeclarationId   where SC.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId in (@DEALOLR,@OBSPEND)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            Cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            Cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            Cmd.Parameters.AddWithValue("@Other", (int)NatureOfEstLbr.Other);
            model.dataa = data.GetDataTable(Cmd);

            Qry = "select ApplicationNo,FeeInitiateBy,SMVD.ValueName as FeeInitiate,FeeTypeBy,SMVD1.ValueName as FeeType,FeeAmount from dgen.ScStFeeDetails SD  inner join SelectMasterValueDetails SMVD on SMVD.ValueId=SD.FeeInitiateBy inner join SelectMasterValueDetails SMVD1 on SMVD1.ValueId=SD.FeeTypeBy  where ApplicationNo=@ApplicationNo and SD.FeeInitiateBy=@FeeInitiateBy order by feetypeby";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            Cmd.Parameters.AddWithValue("@FeeInitiateBy", (int)ValueId.Applicant);
            model.datab = data.GetDataTable(Cmd);
            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "PrintTutionFeeApplication", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not available for Print.";
                return View("message");
            }
        }
        [EncryptedActionParameter]
        public ActionResult PrintFinancialAssistanceApplication(Int64? AppNo)
        {
            PrintModels model = new PrintModels();

            string Qry = string.Empty;
            GetData data = new GetData();
            Qry = "select dbo.displaycompleteaddressfromid(AD.ApplicantHouseNumber,AD.ApplicantStreetNumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.Applicantsubdivcode,AD.Applicantdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as Address,AD.ApplicantName,to_char(AD.ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,AD.ApplicantGender,AD.ApplicantFatherName,AD.applicantmobileno,dbo.udf_general_decrypt(RM.documentno) as documentno,AD.ServiceCode,SR.servicename,(AcademicSession::integer ||'-'||AcademicSession::integer + 1) as yearrange,SC.ApplicationNo,SC.Annualincome,SV.valuename as ApplyingFor,case when SC.WhetherPANNo=true then 'Yes' else 'No' end as WhetherPANNo,SC.Panno,case when SC.WhetherCollegeInDelhi=true then 'Yes' else 'No' end as WhetherCollegeInDelhi,SV1.valuename as CategoryId,SCH.schoolname as CollegeName,SCH.schooladdress as Collegeaddress,SCH.schoolaffiliationid as CollegeaffiliationId,SCH.pincode as CollegePincode,DM.districtname as CollegeDistrict,SM2.StateName as CollegeState,SM2.StateId as StateId,PA.valuename as Presentclass,PR.ValueName as Previousclass,SC.Yearclasspassed,SC.Attendancepercentage,SC.AccountholderName,SC.AccountNo,BM.BankName,BMP.BranchAddress as BankBranchName,BM.BankName as Bankcode,SC.Ifsccode,SC.Micrcode,AD.ApplicationStatusId,SV4.ValueName as Declaration from dgen.applicationdetailsfinancialassistance SC  inner join dbo.applicationdetails AD on AD.ApplicationNo=SC.ApplicationNo  inner join bankmaster BM on BM.bankcode=SC.bankcode inner join bankmappingmaster BMP on BMP.IFSCCode=SC.IFSCCode and BMP.bankcode=SC.bankcode  inner join selectmastervaluedetails PA on PA.valueid=SC.Presentclass  inner join selectmastervaluedetails SV on SV.valueid=SC.ApplyingFor  inner join selectmastervaluedetails SV1 on SV1.valueid=SC.CategoryId inner join web.registrationmaster RM on RM.registrationid=AD.registrationid inner join servicemaster SR on SR.servicecode=AD.servicecode left outer join selectmastervaluedetails PR on PR.valueid=SC.Previousclass left outer join dgen.prematschoolmaster SCH on SCH.SchoolId=SC.SchoolId left outer join districtmaster DM on DM.districtcode=SCH.district   left outer join statemaster SM2 on SM2.StateId=SCH.State left outer join selectmastervaluedetails SV4 on SV4.valueid=SC.DeclarationId  where SC.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId in (@DEALOLR,@OBSPEND)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            Cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            Cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            Cmd.Parameters.AddWithValue("@Other", (int)NatureOfEstLbr.Other);
            model.dataa = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "PrintFinancialAssistanceApplication", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not available for Print.";
                return View("message");
            }
        }
        [EncryptedActionParameter]
        public ActionResult PrintMeritSchoolApplication(Int64? AppNo)
        {
            PrintModels model = new PrintModels();

            string Qry = string.Empty;
            GetData data = new GetData();
            Qry = "select dbo.displaycompleteaddressfromid(AD.ApplicantHouseNumber,AD.ApplicantStreetNumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.Applicantsubdivcode,AD.Applicantdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as Address,AD.ApplicantName,to_char(AD.ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,AD.ApplicantGender,AD.ApplicantFatherName,AD.applicantmobileno,dbo.udf_general_decrypt(RM.documentno) as documentno,AD.ServiceCode,SR.servicename,(AcademicSession::integer ||'-'||AcademicSession::integer + 1) as yearrange,SC.ApplicationNo,SC.Annualincome,SV.valuename as ApplyingFor,case when SC.WhetherPANNo=true then 'Yes' else 'No' end as WhetherPANNo,SC.Panno,case when SC.WhetherCollegeInDelhi=true then 'Yes' else 'No' end as WhetherCollegeInDelhi,SV1.valuename as CategoryId,MarksPercentage,SCH.schoolname as CollegeName,SCH.schooladdress as Collegeaddress,SCH.schoolaffiliationid as CollegeaffiliationId,SCH.pincode as CollegePincode,DM.districtname as CollegeDistrict,SM2.StateName as CollegeState,SM2.StateId as StateId,PA.valuename as Presentclass,PR.ValueName as Previousclass,SC.Yearclasspassed,SC.Attendancepercentage,SC.AccountholderName,SC.AccountNo,BM.BankName,BMP.BranchAddress as BankBranchName,BM.BankName as Bankcode,SC.Ifsccode,SC.Micrcode,AD.ApplicationStatusId,SV4.ValueName as Declaration from dgen.applicationdetailsmeritscholarshipschool SC  inner join dbo.applicationdetails AD on AD.ApplicationNo=SC.ApplicationNo  inner join bankmaster BM on BM.bankcode=SC.bankcode inner join bankmappingmaster BMP on BMP.IFSCCode=SC.IFSCCode and BMP.bankcode=SC.bankcode  inner join selectmastervaluedetails PA on PA.valueid=SC.Presentclass  inner join selectmastervaluedetails SV on SV.valueid=SC.ApplyingFor  inner join selectmastervaluedetails SV1 on SV1.valueid=SC.CategoryId inner join web.registrationmaster RM on RM.registrationid=AD.registrationid inner join servicemaster SR on SR.servicecode=AD.servicecode left outer join selectmastervaluedetails PR on PR.valueid=SC.Previousclass left outer join dgen.prematschoolmaster SCH on SCH.SchoolId=SC.SchoolId left outer join districtmaster DM on DM.districtcode=SCH.district   left outer join statemaster SM2 on SM2.StateId=SCH.State left outer join selectmastervaluedetails SV4 on SV4.valueid=SC.DeclarationId  where SC.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId in (@DEALOLR,@OBSPEND)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            Cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            Cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            Cmd.Parameters.AddWithValue("@Other", (int)NatureOfEstLbr.Other);
            model.dataa = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "PrintMeritSchoolApplication", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not available for Print.";
                return View("message");
            }
        }
        [EncryptedActionParameter]
        public ActionResult PrintBRAmbedkarApplication(Int64? AppNo)
        {
            PrintModels model = new PrintModels();

            string Qry = string.Empty;
            GetData data = new GetData();
            Qry = "select dbo.displaycompleteaddressfromid(AD.ApplicantHouseNumber,AD.ApplicantStreetNumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.Applicantsubdivcode,AD.Applicantdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as Address,AD.ApplicantName,to_char(AD.ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,AD.ApplicantGender,AD.ApplicantFatherName,AD.applicantmobileno,dbo.udf_general_decrypt(RM.documentno) as documentno,AD.ServiceCode,SR.servicename,(AcademicSession::integer ||'-'||AcademicSession::integer + 1) as yearrange,SC.ApplicationNo,SC.Annualincome,SV.valuename as ApplyingFor,case when SC.WhetherPANNo=true then 'Yes' else 'No' end as WhetherPANNo,SC.Panno,case when SC.WhetherCollegeInDelhi=true then 'Yes' else 'No' end as WhetherCollegeInDelhi,SV1.valuename as CategoryId,MarksPercentage,SCH.schoolname as CollegeName,SCH.schooladdress as Collegeaddress,SCH.schoolaffiliationid as CollegeaffiliationId,SCH.pincode as CollegePincode,DM.districtname as CollegeDistrict,SM2.StateName as CollegeState,SM2.StateId as StateId,PA.valuename as Presentclass,PR.ValueName as Previousclass,SC.Yearclasspassed,SC.Attendancepercentage,SC.AccountholderName,SC.AccountNo,BM.BankName,BMP.BranchAddress as BankBranchName,BM.BankName as Bankcode,SC.Ifsccode,SC.Micrcode,AD.ApplicationStatusId,SV4.ValueName as Declaration from dgen.applicationdetailsbrambedkar SC  inner join dbo.applicationdetails AD on AD.ApplicationNo=SC.ApplicationNo  inner join bankmaster BM on BM.bankcode=SC.bankcode inner join bankmappingmaster BMP on BMP.IFSCCode=SC.IFSCCode and BMP.bankcode=SC.bankcode  inner join selectmastervaluedetails PA on PA.valueid=SC.Presentclass  inner join selectmastervaluedetails PR on PR.valueid=SC.Previousclass  inner join selectmastervaluedetails SV on SV.valueid=SC.ApplyingFor  inner join selectmastervaluedetails SV1 on SV1.valueid=SC.CategoryId inner join web.registrationmaster RM on RM.registrationid=AD.registrationid inner join servicemaster SR on SR.servicecode=AD.servicecode left outer join dgen.prematschoolmaster SCH on SCH.SchoolId=SC.SchoolId left outer join districtmaster DM on DM.districtcode=SCH.district   left outer join statemaster SM2 on SM2.StateId=SCH.State left outer join selectmastervaluedetails SV4 on SV4.valueid=SC.DeclarationId where SC.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId in (@DEALOLR,@OBSPEND)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            Cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            Cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            Cmd.Parameters.AddWithValue("@Other", (int)NatureOfEstLbr.Other);
            model.dataa = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "PrintBRAmbedkarApplication", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not available for Print.";
                return View("message");
            }
        }
        [EncryptedActionParameter]
        public ActionResult PrintPreMatricApplication(Int64? AppNo)
        {
            PrintModels model = new PrintModels();

            string Qry = string.Empty;
            GetData data = new GetData();
            Qry = "select dbo.displaycompleteaddressfromid(AD.ApplicantHouseNumber,AD.ApplicantStreetNumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.Applicantsubdivcode,AD.Applicantdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as Address,AD.ApplicantName,to_char(AD.ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,AD.ApplicantGender,AD.ApplicantFatherName,AD.applicantmobileno,dbo.udf_general_decrypt(RM.documentno) as documentno,AD.ServiceCode,SR.servicename,(AcademicSession::integer ||'-'||AcademicSession::integer + 1) as yearrange,SC.ApplicationNo,SC.Annualincome,SV.valuename as ApplyingFor,case when SC.WhetherPANNo=true then 'Yes' else 'No' end as WhetherPANNo,SC.Panno,case when SC.WhetherCollegeInDelhi=true then 'Yes' else 'No' end as WhetherCollegeInDelhi,SV1.valuename as CategoryId,SCH.schoolname as CollegeName,SCH.schooladdress as Collegeaddress,SCH.schoolaffiliationid as CollegeaffiliationId,SCH.pincode as CollegePincode,DM.districtname as CollegeDistrict,SM2.StateName as CollegeState,SM2.StateId as StateId,PA.valuename as Presentclass,PR.ValueName as Previousclass,SC.Yearclasspassed,SC.AccountholderName,SC.AccountNo,BM.BankName,BMP.BranchAddress as BankBranchName,BM.BankName as Bankcode,SC.Ifsccode,SC.Micrcode,AD.ApplicationStatusId,SV4.ValueName as Declaration from dgen.applicationdetailsprematobc SC  inner join dbo.applicationdetails AD on AD.ApplicationNo=SC.ApplicationNo  inner join bankmaster BM on BM.bankcode=SC.bankcode inner join bankmappingmaster BMP on BMP.IFSCCode=SC.IFSCCode and BMP.bankcode=SC.bankcode  inner join selectmastervaluedetails PA on PA.valueid=SC.Presentclass  inner join selectmastervaluedetails PR on PR.valueid=SC.Previousclass  inner join selectmastervaluedetails SV on SV.valueid=SC.ApplyingFor  inner join selectmastervaluedetails SV1 on SV1.valueid=SC.CategoryId inner join web.registrationmaster RM on RM.registrationid=AD.registrationid inner join servicemaster SR on SR.servicecode=AD.servicecode left outer join dgen.prematschoolmaster SCH on SCH.SchoolId=SC.SchoolId left outer join districtmaster DM on DM.districtcode=SCH.district   left outer join statemaster SM2 on SM2.StateId=SCH.State left outer join selectmastervaluedetails SV4 on SV4.valueid=SC.DeclarationId where SC.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId in (@DEALOLR,@OBSPEND)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            Cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            Cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            Cmd.Parameters.AddWithValue("@Other", (int)NatureOfEstLbr.Other);
            model.dataa = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "PrintPreMatricApplication", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not available for Print.";
                return View("message");
            }
        }
        [EncryptedActionParameter]
        public ActionResult PrintPreMatricSCApplication(Int64? AppNo)
        {
            PrintModels model = new PrintModels();

            string Qry = string.Empty;
            GetData data = new GetData();
            Qry = "select dbo.displaycompleteaddressfromid(AD.ApplicantHouseNumber,AD.ApplicantStreetNumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.Applicantsubdivcode,AD.Applicantdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as Address,AD.ApplicantName,to_char(AD.ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,AD.ApplicantGender,AD.ApplicantFatherName,AD.applicantmobileno,dbo.udf_general_decrypt(RM.documentno) as documentno,AD.ServiceCode,SR.servicename,(AcademicSession::integer ||'-'||AcademicSession::integer + 1) as yearrange,SC.ApplicationNo,SC.Annualincome,SV.valuename as ApplyingFor,case when SC.WhetherPANNo=true then 'Yes' else 'No' end as WhetherPANNo,SC.Panno,case when SC.WhetherCollegeInDelhi=true then 'Yes' else 'No' end as WhetherCollegeInDelhi,SV1.valuename as CategoryId,SCH.schoolname as CollegeName,SCH.schooladdress as Collegeaddress,SCH.schoolaffiliationid as CollegeaffiliationId,SCH.pincode as CollegePincode,DM.districtname as CollegeDistrict,SM2.StateName as CollegeState,SM2.StateId as StateId,PA.valuename as Presentclass,PR.ValueName as Previousclass,SC.Yearclasspassed,SC.AccountholderName,SC.AccountNo,BM.BankName,BMP.BranchAddress as BankBranchName,BM.BankName as Bankcode,SC.Ifsccode,SC.Micrcode,AD.ApplicationStatusId,SV4.ValueName as Declaration from dgen.applicationdetailsprematscssd SC  inner join dbo.applicationdetails AD on AD.ApplicationNo=SC.ApplicationNo  inner join bankmaster BM on BM.bankcode=SC.bankcode inner join bankmappingmaster BMP on BMP.IFSCCode=SC.IFSCCode and BMP.bankcode=SC.bankcode  inner join selectmastervaluedetails PA on PA.valueid=SC.Presentclass  inner join selectmastervaluedetails PR on PR.valueid=SC.Previousclass  inner join selectmastervaluedetails SV on SV.valueid=SC.ApplyingFor  inner join selectmastervaluedetails SV1 on SV1.valueid=SC.CategoryId inner join web.registrationmaster RM on RM.registrationid=AD.registrationid inner join servicemaster SR on SR.servicecode=AD.servicecode left outer join dgen.prematschoolmaster SCH on SCH.SchoolId=SC.SchoolId left outer join districtmaster DM on DM.districtcode=SCH.district   left outer join statemaster SM2 on SM2.StateId=SCH.State left outer join selectmastervaluedetails SV4 on SV4.valueid=SC.DeclarationId where SC.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId in (@DEALOLR,@OBSPEND)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            Cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            Cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            Cmd.Parameters.AddWithValue("@Other", (int)NatureOfEstLbr.Other);
            model.dataa = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "PrintPreMatricSCApplication", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not available for Print.";
                return View("message");
            }
        }
        [EncryptedActionParameter]
        public ActionResult PrintPreMatSCApplicationReciept(Int64? AppNo, int ServiceCode)
        {
            PrintModels model = new PrintModels();

            string Qry = string.Empty;
            GetData data = new GetData();
            if (ServiceCode == (int)ServiceList.MeritscholarshipProfessional)
            {
                Qry = "select dbo.displaycompleteaddressfromid(AD.ApplicantHouseNumber,AD.ApplicantStreetNumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.Applicantsubdivcode,AD.Applicantdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as Address,AD.ApplicantName,to_char(AD.ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,AD.ApplicantGender,AD.ApplicantFatherName,AD.applicantmobileno,dbo.udf_general_decrypt(RM.documentno) as documentno,AD.ServiceCode,SR.servicename,(AcademicSession::integer ||'-'||AcademicSession::integer + 1) as yearrange,SC.ApplicationNo,SC.Annualincome,SV.valuename as ApplyingFor,case when SC.WhetherPANNo=true then 'Yes' else 'No' end as WhetherPANNo,SC.Panno,case when SC.WhetherCollegeInDelhi=true then 'Yes' else 'No' end as WhetherCollegeInDelhi,SV1.valuename as CategoryId,case when SC.schoolid is null then SC.CollegeName else SCH.schoolname end as CollegeName,case when SC.schoolid is null then SC.Collegeaddress else SCH.schooladdress end as Collegeaddress,case when SC.schoolid is null then SC.CollegeaffiliationId else SCH.schoolaffiliationid end as CollegeaffiliationId,case when SC.schoolid is null then SC.CollegePincode else SCH.pincode end as CollegePincode,case when SC.schoolid is null then SC.CollegeDistrict else DM.districtname end as CollegeDistrict,case when SC.schoolid is null then SM1.StateName else SM2.StateName end as CollegeState,case when SC.schoolid is null then SM1.StateId else SM2.StateId end as StateId,PA.valuename as Presentclass,SC.PresentCourse,PR.ValueName as Previousclass,SC.PreviousCourse,SC.Yearclasspassed,SC.Attendancepercentage,SC.Markspercentage,SC.AccountholderName,SC.AccountNo,BM.BankName,BMP.BranchAddress as BankBranchName,BM.BankName as Bankcode,SC.Ifsccode,SC.Micrcode,AD.ApplicationStatusId, case when SC.WhetherHostler=true then 'Yes' else 'No' end as WhetherHostler,SV4.ValueName as Declaration from dgen.applicationdetailsmeritprofessional SC  inner join dbo.applicationdetails AD on AD.ApplicationNo=SC.ApplicationNo  inner join bankmaster BM on BM.bankcode=SC.bankcode inner join bankmappingmaster BMP on BMP.IFSCCode=SC.IFSCCode and BMP.bankcode=SC.bankcode  inner join selectmastervaluedetails PA on PA.valueid=SC.Presentclass  inner join selectmastervaluedetails PR on PR.valueid=SC.Previousclass  inner join selectmastervaluedetails SV on SV.valueid=SC.ApplyingFor  inner join selectmastervaluedetails SV1 on SV1.valueid=SC.CategoryId inner join web.registrationmaster RM on RM.registrationid=AD.registrationid inner join servicemaster SR on SR.servicecode=AD.servicecode left outer join dgen.prematschoolmaster SCH on SCH.SchoolId=SC.SchoolId left outer join districtmaster DM on DM.districtcode=SCH.district left outer join statemaster SM1 on SM1.StateId=SC.CollegeState  left outer join statemaster SM2 on SM2.StateId=SCH.State left outer join selectmastervaluedetails SV4 on SV4.valueid=SC.DeclarationId   where SC.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId in (@DEALOLR,@OBSPEND)";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                Cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
                Cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
                Cmd.Parameters.AddWithValue("@Other", (int)NatureOfEstLbr.Other);
                model.dataa = data.GetDataTable(Cmd);
            }
            else if (ServiceCode == (int)ServiceList.PostmatricScholarshipOBC)
            {
                Qry = "select dbo.displaycompleteaddressfromid(AD.ApplicantHouseNumber,AD.ApplicantStreetNumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.Applicantsubdivcode,AD.Applicantdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as Address,AD.ApplicantName,to_char(AD.ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,AD.ApplicantGender,AD.ApplicantFatherName,AD.applicantmobileno,dbo.udf_general_decrypt(RM.documentno) as documentno,AD.ServiceCode,SR.servicename,(AcademicSession::integer ||'-'||AcademicSession::integer + 1) as yearrange,SC.ApplicationNo,SC.Annualincome,SV.valuename as ApplyingFor,case when SC.WhetherPANNo=true then 'Yes' else 'No' end as WhetherPANNo,SC.Panno,case when SC.WhetherCollegeInDelhi=true then 'Yes' else 'No' end as WhetherCollegeInDelhi,SV1.valuename as CategoryId,case when SC.schoolid is null then SC.CollegeName else SCH.schoolname end as CollegeName,case when SC.schoolid is null then SC.Collegeaddress else SCH.schooladdress end as Collegeaddress,case when SC.schoolid is null then SC.CollegeaffiliationId else SCH.schoolaffiliationid end as CollegeaffiliationId,case when SC.schoolid is null then SC.CollegePincode else SCH.pincode end as CollegePincode,case when SC.schoolid is null then SC.CollegeDistrict else DM.districtname end as CollegeDistrict,case when SC.schoolid is null then SM1.StateName else SM2.StateName end as CollegeState,case when SC.schoolid is null then SM1.StateId else SM2.StateId end as StateId,PA.valuename as Presentclass,SC.PresentCourse,PR.ValueName as Previousclass,SC.PreviousCourse,SC.Yearclasspassed,SC.Attendancepercentage,SC.Markspercentage,SC.AccountholderName,SC.AccountNo,BM.BankName,BMP.BranchAddress as BankBranchName,BM.BankName as Bankcode,SC.Ifsccode,SC.Micrcode,AD.ApplicationStatusId, case when SC.WhetherHostler=true then 'Yes' else 'No' end as WhetherHostler,SV4.ValueName as Declaration from dgen.applicationdetailspostmatobc SC  inner join dbo.applicationdetails AD on AD.ApplicationNo=SC.ApplicationNo  inner join bankmaster BM on BM.bankcode=SC.bankcode inner join bankmappingmaster BMP on BMP.IFSCCode=SC.IFSCCode and BMP.bankcode=SC.bankcode  inner join selectmastervaluedetails PA on PA.valueid=SC.Presentclass  inner join selectmastervaluedetails PR on PR.valueid=SC.Previousclass  inner join selectmastervaluedetails SV on SV.valueid=SC.ApplyingFor  inner join selectmastervaluedetails SV1 on SV1.valueid=SC.CategoryId inner join web.registrationmaster RM on RM.registrationid=AD.registrationid inner join servicemaster SR on SR.servicecode=AD.servicecode left outer join dgen.prematschoolmaster SCH on SCH.SchoolId=SC.SchoolId left outer join districtmaster DM on DM.districtcode=SCH.district left outer join statemaster SM1 on SM1.StateId=SC.CollegeState  left outer join statemaster SM2 on SM2.StateId=SCH.State left outer join selectmastervaluedetails SV4 on SV4.valueid=SC.DeclarationId   where SC.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId in (@DEALOLR,@OBSPEND)";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                Cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
                Cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
                Cmd.Parameters.AddWithValue("@Other", (int)NatureOfEstLbr.Other);
                model.dataa = data.GetDataTable(Cmd);
            }
            else if (ServiceCode == (int)ServiceList.PostmatricSC)
            {
                Qry = "select dbo.displaycompleteaddressfromid(AD.ApplicantHouseNumber,AD.ApplicantStreetNumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.Applicantsubdivcode,AD.Applicantdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as Address,AD.ApplicantName,to_char(AD.ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,AD.ApplicantGender,AD.ApplicantFatherName,AD.applicantmobileno,dbo.udf_general_decrypt(RM.documentno) as documentno,AD.ServiceCode,SR.servicename,(AcademicSession::integer ||'-'||AcademicSession::integer + 1) as yearrange,SC.ApplicationNo,SC.Annualincome,SV.valuename as ApplyingFor,case when SC.WhetherPANNo=true then 'Yes' else 'No' end as WhetherPANNo,SC.Panno,case when SC.WhetherCollegeInDelhi=true then 'Yes' else 'No' end as WhetherCollegeInDelhi,SV1.valuename as CategoryId,case when SC.schoolid is null then SC.CollegeName else SCH.schoolname end as CollegeName,case when SC.schoolid is null then SC.Collegeaddress else SCH.schooladdress end as Collegeaddress,case when SC.schoolid is null then SC.CollegeaffiliationId else SCH.schoolaffiliationid end as CollegeaffiliationId,case when SC.schoolid is null then SC.CollegePincode else SCH.pincode end as CollegePincode,case when SC.schoolid is null then SC.CollegeDistrict else DM.districtname end as CollegeDistrict,case when SC.schoolid is null then SM1.StateName else SM2.StateName end as CollegeState,case when SC.schoolid is null then SM1.StateId else SM2.StateId end as StateId,PA.valuename as Presentclass,SC.PresentCourse,PR.ValueName as Previousclass,SC.PreviousCourse,SC.Yearclasspassed,SC.Attendancepercentage,SC.Markspercentage,SC.AccountholderName,SC.AccountNo,BM.BankName,BMP.BranchAddress as BankBranchName,BM.BankName as Bankcode,SC.Ifsccode,SC.Micrcode,AD.ApplicationStatusId, case when SC.WhetherHostler=true then 'Yes' else 'No' end as WhetherHostler,SV4.ValueName as Declaration from dgen.applicationdetailspostmatscssd SC  inner join dbo.applicationdetails AD on AD.ApplicationNo=SC.ApplicationNo  inner join bankmaster BM on BM.bankcode=SC.bankcode inner join bankmappingmaster BMP on BMP.IFSCCode=SC.IFSCCode and BMP.bankcode=SC.bankcode  inner join selectmastervaluedetails PA on PA.valueid=SC.Presentclass  inner join selectmastervaluedetails PR on PR.valueid=SC.Previousclass  inner join selectmastervaluedetails SV on SV.valueid=SC.ApplyingFor  inner join selectmastervaluedetails SV1 on SV1.valueid=SC.CategoryId inner join web.registrationmaster RM on RM.registrationid=AD.registrationid inner join servicemaster SR on SR.servicecode=AD.servicecode left outer join dgen.prematschoolmaster SCH on SCH.SchoolId=SC.SchoolId left outer join districtmaster DM on DM.districtcode=SCH.district left outer join statemaster SM1 on SM1.StateId=SC.CollegeState  left outer join statemaster SM2 on SM2.StateId=SCH.State left outer join selectmastervaluedetails SV4 on SV4.valueid=SC.DeclarationId   where SC.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId in (@DEALOLR,@OBSPEND)";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                Cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
                Cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
                Cmd.Parameters.AddWithValue("@Other", (int)NatureOfEstLbr.Other);
                model.dataa = data.GetDataTable(Cmd);
            }

            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "PrintPreMatSCApplicationReciept", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not available for Print.";
                return View("message");
            }
        }




        [EncryptedActionParameter]
        public ActionResult PrintVerifiedApplication(int ServiceCode, int AcademicSession, string checkboxvalue)
        {
            GetData data = new GetData();
            PrintModels model = new PrintModels();

            string Qry = "select coalesce(sum(Feeamount),0) as Recomended ,AD.ServiceCode,ServiceName,AD.ApplicationNo,ApplicantName,to_char(VerificationDate,'DD/MM/YYYY') as VerifiedDate,SMV.ValueName as PresentClassName,PresentClass,SMVV.ValueName as PreviousClassName,PreviousClass,PAP.CategoryId,SMVD.ValueName as Category from dbo.ApplicationDetails AD inner join (select ApplicationNo,PresentClass,PreviousClass from dgen.applicationdetailsfinancialassistance union all select ApplicationNo,PresentClass,PreviousClass  from dgen.applicationdetailsprematssc union all select ApplicationNo,PresentClass,PreviousClass  from dgen.applicationdetailsmeritscholarshipschool union all select ApplicationNo,PresentClass,PreviousClass  from dgen.applicationdetailsbrambedkar union all select ApplicationNo,PresentClass,PreviousClass  from dgen.applicationdetailsmeritprofessional union all select ApplicationNo,PresentClass,PreviousClass  from dgen.applicationdetailsprematobc union all select ApplicationNo,PresentClass,PreviousClass  from dgen.applicationdetailspostmatobc Union all select ApplicationNo,PresentClass,PreviousClass  from dgen.applicationdetailspostmatscssd Union all select ApplicationNo,PresentClass,PreviousClass  from dgen.applicationdetailsprematscssd ) ADSC on AD.ApplicationNo=ADSC.ApplicationNo inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=ADSC.ApplicationNo inner join dgen.prematschoolmaster PSM on PSM.SchoolId=PAP.SchoolId inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode inner join dbo.SelectMasterValueDetails SMV on SMV.ValueId=ADSC.PresentClass inner join dbo.SelectMasterValueDetails SMVD on SMVD.ValueId=PAP.CategoryId inner join dgen.scstfeedetails  SCSTFee on SCSTFee.ApplicationNo=AD.ApplicationNo left outer join dbo.SelectMasterValueDetails SMVV on SMVV.ValueId=ADSC.PreviousClass  where SC.deptcode=@ParamDeptCode and AD.ServiceCode in (@ServiceCode) and PAP.SchoolId in (@ParamAuthorizationId) and processStatusId<>@processStatusId  and feeinitiateby=@feeinitiateby and PAP.Academicsession=@Academicsession and PAP.ApplicationNo in (" + checkboxvalue + ") group by  AD.ServiceCode,ServiceName,AD.ApplicationNo,ApplicantName,ApplicantFatherName,VerificationDate,PresentClass,PresentClassName,PreviousClassName,PreviousClass,PAP.CategoryId,Category order by ServiceName ";//Changes20180327
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.TRUE.ToString());
            cmd.Parameters.AddWithValue("@feeinitiateby", (int)ValueId.Department);
            cmd.Parameters.AddWithValue("@processStatusId", (int)ValueId.PendingVerification);
            cmd.Parameters.AddWithValue("@Academicsession", AcademicSession);
            model.dataa = data.GetDataTable(cmd);

            Qry = "select SchoolName, Schooladdress,NodalOfficer,MobileNo from dgen.prematschoolmaster where schoolid in (@ParamAuthorizationId) and whetheractive=@whetheractive ";
            cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
            model.datab = data.GetDataTable(cmd);


            if (model.dataa.Rows.Count > 0)
            {
                return this.ViewPdf("", "PrintVerifiedApplication", model);

            }
            else
            {
                ViewData["message"] = "Not available for Print.";
                return View("message");
            }
        }
        [EncryptedActionParameter]
        public ActionResult PrintSCSTApprovedApp(int ServiceCode, int SchoolId, int AcademicSession, string checkboxvalue)
        {
            GetData data = new GetData();
            PrintModels model = new PrintModels();
            string WhetherCondition = string.Empty;

            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition += " and ( PAP.DepartmentId in (@Code) or PSM.District in (@Code) or PSM.SubDivision in (@Code))"; }
            string Qry = @"select PAP.SchoolId,SchoolName, PAP.DepartmentId,SMVD1.ValueName as Department, AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantMobileNo,ServiceName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as DOB,AD.ApplicationStatusId,coalesce(sum(Feeamount),0) as Recomended,to_char(AD.ApprovedDate,'DD/MM/YYYY') as ApprovedDate,SMVD.ValueName as Category  from dbo.ApplicationDetails AD inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo inner join (select ApplicationNo,null as CollegeName from dgen.applicationdetailsfinancialassistance union all select ApplicationNo,null as CollegeName from dgen.applicationdetailsprematssc union all select ApplicationNo,null as CollegeName from dgen.applicationdetailsmeritscholarshipschool union all select ApplicationNo,null as CollegeName from dgen.applicationdetailsbrambedkar union all select ApplicationNo,CollegeName from dgen.applicationdetailsmeritprofessional union all select ApplicationNo,null as CollegeName from dgen.applicationdetailsprematobc union all select ApplicationNo,CollegeName from dgen.applicationdetailspostmatobc union all select ApplicationNo,CollegeName from dgen.applicationdetailspostmatscssd union all select ApplicationNo,null asCollegeName from dgen.applicationdetailsprematscssd) ADSC on AD.ApplicationNo=ADSC.ApplicationNo inner join dgen.scstfeedetails  SCSTFD on SCSTFD.applicationNo=AD.ApplicationNo inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode inner join SelectMasterValueDetails SMVD on SMVD.ValueId=PAP.CategoryId left outer join dgen.prematschoolmaster PSM on PSM.SchoolId=PAP.SchoolId left outer join SelectMasterValueDetails SMVD1 on SMVD1.ValueId=PAP.DepartmentId  where AD.ServiceCode in (@ServiceCode) and AD.ApplicationStatusId=@ApplicationStatusId  and FeeinitiateBy=@FeeinitiateBy and PAP.AcademicSession=@AcademicSession  and PAP.ApplicationNo in (" + checkboxvalue + ")  " + WhetherCondition + " group by AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,ApplicantAddress,AD.ApplicantDob,AD.ApplicationStatusId,Category,AD.ApprovedDate,PAP.SchoolId,CollegeName,SchoolName,PAP.DepartmentId,SMVD1.ValueName  order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@SchoolId", SchoolId);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
            cmd.Parameters.AddWithValue("@Code", Sessions.getEmployeeUser().AuthorizationId);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.dataa = data.GetDataTable(cmd);

            if (model.dataa.Rows.Count > 0)
            {
                return this.ViewPdf("", "PrintSCSTApprovedApp", model);

            }
            else
            {
                ViewData["message"] = "Not available for Print.";
                return View("message");
            }
        }
        [EncryptedActionParameter]
        public ActionResult PrintHeFinancialAssistance(Int64? AppNo)
        {
            PrintModels model = new PrintModels();

            string Qry = string.Empty;
            GetData data = new GetData();
            Qry = "select dbo.displaycompleteaddressfromid(AD.ApplicantHouseNumber,AD.ApplicantStreetNumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.Applicantsubdivcode,AD.Applicantdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as Address,AD.ApplicantName,to_char(AD.ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,AD.ApplicantGender,AD.ApplicantFatherName,AD.applicantmobileno,dbo.udf_general_decrypt(RM.documentno) as documentno,AD.ServiceCode,HEMCM.ApplicationNo,ApplicationStatusId,AcademicSession,(EXTRACT(YEAR FROM now())-1||'-'|| (SUBSTR((EXTRACT(YEAR FROM now()))::varchar,3,2))) as yearrange,(AcademicSession ||'-'||AcademicSession + 1) as AcademicSessionType,NameAsPerSchool,SV.valuename as ApplyingFor,SV1.valuename as Category,CategoryId,StateName as CerIssueState,CertificateIssueState,AnnualIncome,case when WhetherNFSSscheme='True' then 'YES' else 'No' end as WhetherNFSSscheme,NFSSCardNo,SV2.ValueName as FinancialAssistanceCategory,FinancialAssistanceCategoryId,SR.servicename,HEMCM.UniversityId,UniversityName,HEMCM.InstitutionId,InstituitonName as InstitutionName,InstitutionAddress,affiliationcode as InstitutionAffiliationId,LevelOfCourse,SV3.ValueName as CourseType,CourseId,CourseName,CurrentStudyingClass,SV4.ValueName as PresentClass,PreviousClassPassed,SV5.ValueName as PreviousClass,(PreviousClassPassedYear ||'-'||PreviousClassPassedYear + 1) as PreviousClassPassedYear,Marks,AccountHolderName,AccountNo,BM.BankName,BMP.BranchAddress as BankBranchName,HEMCM.bankcode as Bankcode,HEMCM.IFSCCode,HEMCM.MICRCode,dbo.udf_general_decrypt(AadhaarNo) as AadhaarNo,SV6.ValueName as Declaration,DeclarationId,CastecerNo,WhetherCasteVerified from dgen.HeMCMFinancialAssistance HEMCM inner join dbo.applicationdetails AD on AD.ApplicationNo=HEMCM.ApplicationNo  inner join selectmastervaluedetails SV on SV.valueid=HEMCM.ApplyingFor inner join selectmastervaluedetails SV1 on SV1.valueid=HEMCM.CategoryId inner join selectmastervaluedetails SV2 on SV2.valueid=HEMCM.FinancialAssistanceCategoryId inner join HeUniversityMaster HUM on HUM.UniversityId=HEMCM.UniversityId inner join HeInstitutionMaster HIM on HIM.InstituitonId=HEMCM.InstitutionId inner join selectmastervaluedetails SV3 on SV3.valueid=HEMCM.LevelOfCourse inner join HeCourseMaster HCM on HCM.HeCourseId=HEMCM.CourseId inner join selectmastervaluedetails SV4 on SV4.valueid=HEMCM.CurrentStudyingClass inner join selectmastervaluedetails SV5 on SV5.valueid=HEMCM.PreviousClassPassed inner join bankmaster BM on BM.bankcode=HEMCM.bankcode inner join web.registrationmaster RM on RM.registrationid=AD.registrationid inner join servicemaster SR on SR.servicecode=AD.servicecode inner join bankmappingmaster BMP on BMP.IFSCCode=HEMCM.IFSCCode and BMP.bankcode=HEMCM.bankcode left outer join selectmastervaluedetails SV6 on SV6.valueid=HEMCM.DeclarationId left outer join StateMaster SM on SM.StateId=HEMCM.CertificateIssueState where HEMCM.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId in (@DEALOLR,@OBSPEND)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            Cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            Cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            Cmd.Parameters.AddWithValue("@Other", (int)NatureOfEstLbr.Other);
            model.dataa = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "PrintHeFinancialAssistance", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not available for Print.";
                return View("message");
            }
        }
        [EncryptedActionParameter]
        public ActionResult PrintECLicenceDetails(Int64? AppNo)
        {
            PrintModels model = new PrintModels();

            string Qry = string.Empty;
            GetData data = new GetData();
            Qry = "select AD.ApplicationNo,AD.ApplicationStatusId,EC.Nameofapplicant,SR.ServiceName,EC.Localityofins,LM.LocalityName,EC.Addressofapplicant,EC.Nameofauthsignatory,dbo.displaycompleteaddressfromid(AD.ApplicantHouseNumber,AD.ApplicantStreetNumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.Applicantsubdivcode,AD.Applicantdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as ApplicantAddress,Case when EC.Gender='M' THEN 'Male' ELSE 'Female' end as Gender,to_char(EC.DateofBirth,'DD/MM/YYYY') as DateofBirth,dbo.udf_general_decrypt(EC.Adharnoofauthsign) as Adharnoofauthsign,EC.Resaddofauthsign,EC.ConstitutionId,EC.Detailsofprevlicence,EC.Feedeposit,SMV.ValueName as ConstitutionName from dgen.ApplicationDetailsEC EC inner join dbo.applicationdetails AD on AD.ApplicationNo=@ApplicationNo inner join localitymaster LM on LM.localityid=EC.Localityofins inner join dbo.selectmastervaluedetails SMV on SMV.Valueid=EC.ConstitutionId inner join servicemaster SR on SR.servicecode=AD.servicecode  where EC.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId in (@DEALOLR,@OBSPEND)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            Cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            Cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            model.dataa = data.GetDataTable(Cmd);

            Qry = "select PID.PId,PID.ApplicationNo,PID.Nameofprop,PID.Resaddressofprop,dbo.udf_general_decrypt(PID.Adharnoprop) as Adharnoprop from dgen.ecpartnershipdetails PID where PID.ApplicationNo=@ApplicationNo";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            model.datab = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "PrintECLicenceDetails", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not available for Print.";
                return View("message");
            }
        }
        [EncryptedActionParameter]
        public ActionResult PrintCompetencyDetails(Int64? AppNo)
        {
            PrintModels model = new PrintModels();

            string Qry = string.Empty;
            GetData data = new GetData();
            Qry = "select AD.ApplicationNo,AD.ApplicationStatusId,CO.EduqualiId,CO.AcademicQualification,SR.ServiceName,CO.CourseType,CO.Yearofpassing,CO.PassingMonth,CO.Feedeposit,dbo.displaycompleteaddressfromid(AD.ApplicantHouseNumber,AD.ApplicantStreetNumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.Applicantsubdivcode,AD.Applicantdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as ApplicantAddress,SMV.ValueName as EduQualiName,SMV1.ValueName as AcademicQualificationName,SMV2.ValueName as CourseTypeName from dgen.applicationdetailscompcertificate CO inner join dbo.applicationdetails AD on AD.ApplicationNo=@ApplicationNo inner join localitymaster LM on LM.localityid=CO.Localityofins inner join dbo.selectmastervaluedetails SMV on SMV.Valueid=CO.EduQualiId inner join dbo.selectmastervaluedetails SMV1 on SMV1.Valueid=CO.AcademicQualification inner join dbo.selectmastervaluedetails SMV2 on SMV2.Valueid=CO.CourseType inner join servicemaster SR on SR.servicecode=AD.servicecode where CO.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId in (@DEALOLR,@OBSPEND)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            Cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            Cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            model.dataa = data.GetDataTable(Cmd);

            Qry = "select EXP.EId,EXP.ApplicationNo,EXP.Nameoffirm,EXP.Natureofwork,to_char(EXP.Dateofjoining,'DD/MM/YYYY') as Dateofjoining,to_char(EXP.Dateofleaving,'DD/MM/YYYY') as Dateofleaving from dgen.ExperienceDetails EXP  where EXP.ApplicationNo=@ApplicationNo";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            model.datab = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "PrintCompetencyDetails", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not available for Print.";
                return View("message");
            }
        }
        #endregion

        #region Action method for print labour recovery Notice/Certificate

        [EncryptedActionParameter]
        public ActionResult GenerateLBRRecoveryNotice(Int64? AppNo, int? NId)
        {
            PrintModels model = new PrintModels();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            NpgsqlCommand Cmd = null;
            string Qry = string.Empty;
            GetData data = new GetData();
            if (AppNo != null)
            {
                Qry = "select NId from dgen.recoverynoticedetails where ApplicationNo=@ApplicationNo and TypeId=@TypeId and ProceedingDetails is null";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                Cmd.Parameters.AddWithValue("@TypeId", (int)ValueId.Notice);
                string[] Val = data.SelectColumns(Cmd);
                if (string.IsNullOrEmpty(Val[0]))
                {
                    Cmd = new NpgsqlCommand("insert into dgen.recoverynoticedetails(ApplicationNo,ServiceCode,TypeId,Whethergenerated,Generatedby,GenerateDate,userid,ipaddress,lastactiondate) values (@ApplicationNo,@ServiceCode,@TypeId,@Whethergenerated,@Generatedby,now(),@userid,@ipaddress,now()) ");
                    Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                    Cmd.Parameters.AddWithValue("@Whethergenerated", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@TypeId", (int)ValueId.Notice);
                    Cmd.Parameters.AddWithValue("@Generatedby", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.LbrRecovery);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(AppNo.ToString(), (int)ApplicationHistoryMessage.MSG047, null, (int)ApplicationSource.Window, null));
                    data.SaveData(cmdList);
                }

                Qry = "select LB.ApplicationNo,LB.AwardAmount,LB.CaseNo,to_char(RN.GenerateDate,'DD/MM/YYYY') as Today,LB.CaseNo from dgen.RecoveryNoticeDetails RN inner join dgen.applicationdetailslbrrecovery LB on LB.ApplicationNo=RN.ApplicationNo  where LB.ApplicationNo=@ApplicationNo and TypeId=@TypeId and RN.ProceedingDetails is null";
            }
            if (NId != null) { Qry = "select LB.ApplicationNo,LB.AwardAmount,LB.CaseNo,to_char(RN.GenerateDate,'DD/MM/YYYY') as Today,LB.CaseNo from dgen.RecoveryNoticeDetails RN inner join dgen.applicationdetailslbrrecovery LB on LB.ApplicationNo=RN.ApplicationNo  where RN.NId=@NId"; }
            Cmd = new NpgsqlCommand(Qry);
            if (AppNo != null)
            {
                Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                Cmd.Parameters.AddWithValue("@TypeId", (int)ValueId.Notice);
            }
            if (NId != null) { Cmd.Parameters.AddWithValue("@NId", NId); }
            model.dataa = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "GenerateLBRRecoveryNotice", model);
            }
            else
            {
                ViewData["message"] = "Notice not pending for printing in E-District Delhi.";
                return View("message");
            }
        }

        [EncryptedActionParameter]
        public ActionResult GenerateLBRRecoveryCertificate(Int64? AppNo)
        {
            PrintModels model = new PrintModels();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            string Qry = string.Empty;
            GetData data = new GetData();

            //if (model.dataa.Rows.Count == 1)
            //{
            return this.ViewPdf("", "GenerateLBRRecoveryCertificate", model);
            //}
            //else
            //{
            //    ViewData["message"] = "Notice not pending for printing in E-District Delhi.";
            //    return View("message");
            //}
        }

        #endregion

        #region Action method for print recovery Notice/Warrant
        [EncryptedActionParameter]
        public ActionResult PrintRecoveryNotice(int? NId)
        {
            PrintModels model = new PrintModels();

            string Qry = string.Empty;
            GetData data = new GetData();
            Qry = "select RN.ApplicationNo,RN.TypeId,RN.ServiceCharge,RN.RName,to_char(RN.IssueDate,'DD/MM/YYYY') as IssueDate,to_char(RN.ExpiryDate,'DD/MM/YYYY') as ExpiryDate,RN.Remarks,to_char(now(),'DD/MM/YYYY') as Today,AR.recoveryno,AR.CaseNo,AR.amount,SV.valuename as RecoveryType,RDM.DeptName,SV2.valuename as Servedby,RD.Dname,RD.Fname,RD.address,PM.policestationname from dgen.RecoveryNoticeDetails RN inner join dbo.ApplicationDetails AD on AD.ApplicationNo=RN.ApplicationNo inner join dgen.applicationdetailsrecovery AR on AR.ApplicationNo=RN.ApplicationNo inner join dgen.recoverydefaulterdetails RD on RD.Did=RN.Did inner join selectmastervaluedetails SV on SV.valueid=AR.recoverytypeid inner join recoverydeptmaster RDM on RDM.deptcode=AR.deptid left outer join selectmastervaluedetails SV2 on SV2.valueid=RN.Servedby left outer join policestationmaster PM on PM.policestationid=RN.policestationid where NId=@NId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@NId", NId);
            model.dataa = data.GetDataTable(Cmd);

            Qry = "select BName,FName,Address from dgen.recoverybeneficiarydetails where ApplicationNo=@ApplicationNo";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.dataa.Rows[0]["ApplicationNo"].ToString());
            model.datab = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                if (model.dataa.Rows[0]["TypeId"].ToString() == ((int)ValueId.Notice).ToString() || model.dataa.Rows[0]["TypeId"].ToString() == ((int)ValueId.Reminder).ToString() || model.dataa.Rows[0]["TypeId"].ToString() == ((int)ValueId.FinalNotice).ToString())
                { return this.ViewPdf("", "PrintRecoveryNotice", model); }
                else if (model.dataa.Rows[0]["TypeId"].ToString() == ((int)ValueId.AttachmentWarrant).ToString() || model.dataa.Rows[0]["TypeId"].ToString() == ((int)ValueId.ArrestWarrant).ToString() || model.dataa.Rows[0]["TypeId"].ToString() == ((int)ValueId.AttachmentWarrantNonMove).ToString() || model.dataa.Rows[0]["TypeId"].ToString() == ((int)ValueId.NonBailableArrestWarrant).ToString())
                { return this.ViewPdf("", "PrintRecoveryWarrant", model); }
                else { return RedirectToAction("BadRequest", "Error"); }
            }
            else
            {
                ViewData["message"] = "Notice/Warrant not pending for printing in E-District Delhi.";
                return View("message");
            }
        }
        #endregion Action method for print recovery Notice/Warrant

        [EncryptedActionParameter]
        public ActionResult PrintCRForm(int RequestId)
        {
            PrintModels model = new PrintModels();

            GetData data = new GetData();
            string Qry = "select RequestId,ValueName as ProjectName,ProjectUrl,CRD.DepartmentId, DeptName as DepartmentName,NodalOfficer,ChangeTitle,ChangeDetails,case when WhetherFlowAttached=true then 'YES' else 'NO' end as WhetherFlowAttached,FlowDetails,case when WhetherNodalApproved=true then 'YES' else 'NO' end as WhetherNodalApproved ,to_char(RequestedDate,'DD/MM/YYYY') as RequestedDate,case when WhetherComplete=true then 'YES' else 'NO' end as WhetherComplete ,to_char(CompletionDate,'DD/MM/YYYY') as CompletionDate,to_char(UatDate,'DD/MM/YYYY') as UatDate,to_char(ReleaseDate,'DD/MM/YYYY') as ReleaseDate,Remarks,OfficerName,OfficerDesignation,case when WhetherDetailsChecked=true then 'YES' else 'NO' end as WhetherDetailsChecked ,case when WhetherResultWorking=true then 'YES' else 'NO' end as WhetherResultWorking ,case when WhetherDeploymentReady=true then 'YES' else 'NO' end as WhetherDeploymentReady ,UatRemarks from  CRRequestDetails CRD inner join SelectMasterValueDetails SMVD on SMVD.ValueId=CRD.ProjectId inner join DeptMaster DM on  DM.DeptCode=CRD.DepartmentId   where RequestId=@RequestId order by RequestId ";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@RequestId", RequestId);
            model.dataa = data.GetDataTable(Cmd);


            if (model.dataa.Rows.Count == 1)
            {
                return View(model);
            }
            else
            {
                ViewData["message"] = "Entered No is not avialable for printing in e-District Delhi.";
                return View("message");
            }
        }
        [AllowAnonymous]
        [EncryptedActionParameter]
        public ActionResult PrintUserEntryGeneratedForm(int pcode, int? DeptCode = 0)
        {
            GetData data = new GetData();
            PrintModels model = new PrintModels();

            string Qry = "select SM.servicename,DM.Deptname,DPM.whetherentryallowed,DPM.whetherdistrequired,DPM.whethersubdivrequired from ServiceMaster SM inner join DeptMaster DM on DM.deptcode=SM.deptcode inner join depttopermissionmaster DPM on DPM.deptcode=DM.deptcode where SM.DeptCode=@DeptCode and DPM.pcode = @pcode order by 1";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@pcode", pcode);

            if (DeptCode != (int)CountList.Type000) { Cmd.Parameters.AddWithValue("@DeptCode", DeptCode); }
            else { Cmd.Parameters.AddWithValue("@DeptCode", Sessions.getEmployeeUser().DeptCode); }

            model.dataa = data.GetDataTable(Cmd);

            Qry = "select distinct DTPM.Pcode,PName from depttopermissionmaster DTPM inner join PermissionMaster PM on PM.Pcode::integer=DTPM.Pcode where deptcode=@DeptCode and WhetherEntryAllowed=@WhetherEntryAllowed and DTPM.WhetherActive =@WhetherActive order by PName";
            Cmd = new NpgsqlCommand(Qry);
            if (DeptCode != (int)CountList.Type000) { Cmd.Parameters.AddWithValue("@DeptCode", DeptCode); }
            else { Cmd.Parameters.AddWithValue("@DeptCode", Sessions.getEmployeeUser().DeptCode); }
            Cmd.Parameters.AddWithValue("@WhetherEntryAllowed", CustomText.True.ToString());
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
            model.datab = data.GetDataTable(Cmd);

            return this.ViewPdf("", "PrintUserEntryGeneratedForm", model);
        }

        #region temp
        [EncryptedActionParameter]
        public ActionResult PrintCinematographApplication(Int64? AppNo)
        {
            PrintModels model = new PrintModels();

            string Qry = string.Empty;
            GetData data = new GetData();
            string SCode = Utility.SelectColumnsValue("applicationdetails", "servicecode", "applicationno", AppNo.ToString())[0];

            Qry = "select ADC.ApplicationNo,AD.ServiceCode,ApplicantName,NM.nationalityname,ApplicantFatherName,dbo.displaycompleteaddressfromid(ApplicantHouseNumber,ApplicantStreetNumber,Applicantsublocality,Applicantlocalityid,Applicantsubdivcode,Applicantdistrictcode,stateid,countryid,Applicantpincode) as Address,CinemaName,CinemaAddress,yearslicenseneeded,FinancialPosition,ApplicantMobileNo,case when WhetherConvicted=true then 'Yes' else 'No' end as WhetherConvicted,ConvictedDetails,PanNo,YearofConstruction,NoOfScreens,ProLicenseNo,to_char(ProLicenseDate,'DD/MM/YYYY') as ProLicenseDate,AD.ApplicationStatusId,LM.LocalityName as CinemaLocality,OM.OccupationType as PresentOccupation,SVM.ValueName as EducationalQualification from dgen.ApplicationDetailsCinematograph ADC inner join dbo.ApplicationDetails AD on ADC.ApplicationNo=AD.ApplicationNo inner join nationalitymaster NM on NM.nationalityid=ADC.nationalityid inner join LocalityMaster LM on LM.LocalityId=ADC.CinemaLocalityId inner join occupationmaster OM on OM.occupationid=ADC.presentoccupation inner join selectmastervaluedetails SVM on SVM.valueid=ADC.educationalqualification where ADC.ApplicationNo=@ApplicationNo and ApplicationStatusId=@ApplicationStatusId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            if (SCode == ((int)ServiceList.ProvisionalCinema).ToString())
            {
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.OBSPEND);
            }
            else
            {
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.STRTINS);
            }
            model.dataa = data.GetDataTable(Cmd);

            if (model.dataa.Rows.Count == 1)
            {
                return this.ViewPdf("", "PrintCinematographApplication", model);
            }
            else
            {
                ViewData["message"] = "Entered Application not available for Print.";
                return View("message");
            }
        }
        [EncryptedActionParameter]
        public ActionResult PrintCinemaProvisional()
        {
            PrintModels model = new PrintModels();
            return this.ViewPdf("", "PrintCinemaProvisional", model);
        }
        #endregion



        
    }
}
