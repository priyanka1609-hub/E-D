﻿using System;
using System.Web;
using System.Data.SqlClient;
using System.Web.Mvc;
using System.Web.UI;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.CustomClass;
using Edistrict.Models.DataService;
using System.Data;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using Npgsql;
using Edistrict.Models.Entities;
using Edistrict.NfsVerificationService;
using Edistrict.TransportService;
using System.Text;
using System.Web.Security;
using System.Collections;
using System.Text.RegularExpressions;

namespace Edistrict.Controllers
{
    [Authorize]
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class AjaxController : Controller
    {
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetApplicantDetailsFromAadhaar(string uid)
        {
            if (string.IsNullOrEmpty(uid)) { return null; }
            AadhaarResponse result = Utility.GetAdharDetails(uid);
            if (result == null || string.IsNullOrEmpty(result.Name) || string.IsNullOrEmpty(result.AadhaarNo))
                return null;
            if (result.AadhaarNo.Length != 12)
                return null;
            return Json(result);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetDetailAppInfowithJson(string idno)
        {
            GetData data = new GetData();
            ApplicantDetails App = new ApplicantDetails();
            return Json(App);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult AjaxProcessingSheet(string idno)
        {
            GetData objData = new GetData();
            string Qry = "select tlogindetail,tipno,allowedmacaddress,allowedbiosaddress,tactiondetail,tdatetime,tremarks from trail where tidno =" + idno + " order by tdatetime";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            DataTable dt = objData.GetDataTable(Cmd);
            var list = new List<Dictionary<string, object>>();
            foreach (DataRow row in dt.Rows)
            {
                var dict = new Dictionary<string, object>();

                foreach (DataColumn col in dt.Columns)
                {
                    dict[col.ColumnName] = row[col];
                }
                list.Add(dict);
            }
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            serializer.Serialize(list);
            return Json(list);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetLocalityID(string LocalityName)
        {
            if (string.IsNullOrEmpty(LocalityName)) { return null; }
            GetData objData = new GetData();
            string Qry = "select lm.localityid from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and lm.LocalityName=@LocalityName and LS.WhetherActive=@WhetherActive";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
            Cmd.Parameters.AddWithValue("@LocalityName", LocalityName.Trim());
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
            DataTable dt = objData.GetDataTable(Cmd);
            string result = string.Empty;
            if (dt != null && dt.Rows.Count > 0)
            {
                result = dt.Rows[0]["LocalityID"].ToString();
            }
            return Json(result);

        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult IsPasswordValid(string password)
        {
            password = RijndaelSimple.DecryptStringAES(password);
            if (string.IsNullOrEmpty(password)) { return null; }

            bool result = true;
            const string lower = "abcdefghijklmnopqrstuvwxyz";
            const string upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const string digits = "0123456789";
            string allChars = lower + upper + digits;

            result &= (password.IndexOfAny(lower.ToCharArray()) >= 0);
            result &= (password.IndexOfAny(upper.ToCharArray()) >= 0);
            result &= (password.IndexOfAny(digits.ToCharArray()) >= 0);
            result &= (password.Trim(allChars.ToCharArray()).Length > 0);
            return Json(result);
        }
        public JsonResult GetBankDetailsMICR(string MICRCode)
        {
            MICRResponse model = new MICRResponse();
            if (string.IsNullOrEmpty(MICRCode)) { return null; }
            GetData objData = new GetData();
            string Qry = "select BM.BankName,BMM.BankCode,BMM.BranchAddress,BMM.IFSCCode from dbo.BankMappingMaster as BMM inner join dbo.BankMaster as BM on BMM.BankCode=BM.BankCode where BMM.MICRCode=@MICRCode";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@MICRCode", MICRCode.Trim());
            DataTable dt = objData.GetDataTable(Cmd);
            if (dt != null && dt.Rows.Count > 0)
            {
                model.BranchAddress = dt.Rows[0]["BranchAddress"].ToString();
                model.BankName = dt.Rows[0]["BankName"].ToString();
                model.BankCode = dt.Rows[0]["BankCode"].ToString();
                model.IFSCCode = dt.Rows[0]["IFSCCode"].ToString();
                model.MICRCode = MICRCode.ToString();
            }
            return Json(model);
        }
        public JsonResult GetBankDetailsIFSC(string IFSCCode)
        {
            MICRResponse model = new MICRResponse();
            if (string.IsNullOrEmpty(IFSCCode)) { return null; }
            GetData objData = new GetData();
            string Qry = "select BM.BankName,BMM.BankCode,BMM.BranchAddress,BMM.MICRCode from dbo.BankMappingMaster as BMM inner join dbo.BankMaster as BM on BMM.BankCode=BM.BankCode where BMM.IFSCCode=@IFSCCode";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@IFSCCode", IFSCCode.Trim());
            DataTable dt = objData.GetDataTable(Cmd);
            if (dt != null && dt.Rows.Count > 0)
            {
                model.BranchAddress = dt.Rows[0]["BranchAddress"].ToString();
                model.BankName = dt.Rows[0]["BankName"].ToString();
                model.BankCode = dt.Rows[0]["BankCode"].ToString();
                model.MICRCode = dt.Rows[0]["MICRCode"].ToString();
                model.IFSCCode = IFSCCode.ToString();
            }

            return Json(model);
        }
        public ActionResult FillFPSAddress(string FPSID)
        {
            DataSet ds = (DataSet)TempData["FPSData"];
            DataRow result = ds.Tables[4].Select("fps_code=" + FPSID)[0];
            PreserveModelState("FPSData", null, true, false);
            NfsUpdateBasicDetails model = new NfsUpdateBasicDetails();
            model.FpsAddress = result["Fps_Address"].ToString();
            model.FpsLicenceNo = result["fps_license_auth_number"].ToString();

            return Json(model);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetDistrict(string LocalityId, string ServiceCode, string DeptCode, string AppNo)
        {
            GetData objData = new GetData();
            string PartialQry = string.Empty;
            DistrictResponse model = new DistrictResponse();
            if (string.IsNullOrEmpty(DeptCode)) { DeptCode = Utility.GetDeptCode(ServiceCode); }
            if (string.IsNullOrEmpty(AppNo)) { PartialQry = " and LS.WhetherActive=@WhetherActive"; }
            string Qry = "select LM.LocalityName,DM.districtcode,DM.districtname,SD.SubDivCode,SD.SubDivDescription,SM.stateid,SM.statename,C.countryid,C.countryname,LM.Pincode from dbo.districtmaster DM inner join dbo.SubDivMaster SD on SD.DistrictCode=DM.DistrictCode inner join localitytosubdivmaster LS on SD.SubDivCode=LS.SubDivCode inner join dbo.LocalityMaster LM on LM.localityid=LS.localityid inner join dbo.statemaster SM on SM.stateid=DM.stateid inner join dbo.countrymaster C on C.countryid=SM.countryid where LM.LocalityId=@LocalityId and DM.deptcode=@deptcode " + PartialQry;
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@deptcode", DeptCode);
            Cmd.Parameters.AddWithValue("@LocalityId", LocalityId);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
            DataTable dt = objData.GetDataTable(Cmd);
            if (dt != null && dt.Rows.Count > 0)
            {
                model.ApplicantDistrictName = dt.Rows[0]["districtname"].ToString();
                model.ApplicantSubDivDescription = dt.Rows[0]["subdivdescription"].ToString();
                model.StateName = dt.Rows[0]["statename"].ToString();
                model.CountryName = dt.Rows[0]["countryname"].ToString();
                model.ApplicantDistrictCode = dt.Rows[0]["districtcode"].ToString();
                model.ApplicantSubDivCode = dt.Rows[0]["SubDivCode"].ToString();
                model.StateId = dt.Rows[0]["stateid"].ToString();
                model.CountryId = dt.Rows[0]["countryid"].ToString();
                model.Pincode = dt.Rows[0]["pincode"].ToString();
                model.LocalityName = dt.Rows[0]["LocalityName"].ToString();
            }
            return Json(model);
        }
        public ActionResult FillDept(string DID, string AppIdNo)
        {
            string StateId = string.Empty;
            if (DID == ((int)DocumentId.CasteCertificate).ToString())
            {
                string ServiceCode = string.Empty;
                if (Sessions.getCurrentUser() != null)
                {
                    ServiceCode = Utility.SelectColumnsValue("web.ApplicationDetails", "ServiceCode", "ApplicationId", AppIdNo)[0];
                }
                else if (Sessions.getEmployeeUser() != null)
                {
                    ServiceCode = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ServiceCode", "ApplicationNo", AppIdNo)[0];
                }
                if (ServiceCode == ((int)ServiceList.OBC).ToString())
                {
                    if (Sessions.getCurrentUser() != null)
                    {
                        StateId = Utility.SelectColumnsValue("wrev.ApplicationDetailsOBC", "RStateId", "ApplicationId", AppIdNo)[0];
                    }
                    else if (Sessions.getEmployeeUser() != null)
                    {
                        StateId = Utility.SelectColumnsValue("drev.ApplicationDetailsOBC", "RStateId", "ApplicationNo", AppIdNo)[0];
                    }
                }
                else if (ServiceCode == ((int)ServiceList.ST).ToString())
                {
                    if (Sessions.getCurrentUser() != null)
                    {
                        StateId = Utility.SelectColumnsValue("wrev.ApplicationDetailsST", "RStateId", "ApplicationId", AppIdNo)[0];
                    }
                    else if (Sessions.getEmployeeUser() != null)
                    {
                        StateId = Utility.SelectColumnsValue("drev.ApplicationDetailsST", "RStateId", "ApplicationNo", AppIdNo)[0];
                    }
                }
            }
            string Qry = "select DTD.Departmentid as DId,ED.deptname as Dname from documenttodepartmentmaster DTD inner join documentmaster DM on DM.documentid=DTD.documentid inner join enclosuredepartmentmaster ED on ED.departmentid=DTD.departmentid where DTD.documentid=@documentid order by ED.deptname";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@documentid", DID);
            if (AppIdNo == ((int)CountList.Type000).ToString())
            {
                List<SelectListItem> DeptList = (List<SelectListItem>)GetDropdown(Cmd);
                DeptList.RemoveAll(c => c.Value == ((int)EnclosureDepartment.Other).ToString());
                return Json(DeptList, JsonRequestBehavior.AllowGet);
            }
            if (!string.IsNullOrEmpty(StateId))
            {
                List<SelectListItem> DeptList = (List<SelectListItem>)GetDropdown(Cmd);
                if (StateId == ((int)State.Haryana).ToString()) { DeptList.RemoveAll(c => c.Value != ((int)EnclosureDepartment.EdistrictHaryana).ToString()); }
                else if (StateId == ((int)State.UP).ToString()) { DeptList.RemoveAll(c => c.Value != ((int)EnclosureDepartment.EdistrictUP).ToString()); }
                else if (StateId == ((int)State.Mizoram).ToString()) { DeptList.RemoveAll(c => c.Value != ((int)EnclosureDepartment.EdistrictMizoram).ToString()); }
                return Json(DeptList, JsonRequestBehavior.AllowGet);
            }
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        [AllowAnonymous]
        public ActionResult FillService(string DeptCode)
        {
            string Qry = "select servicecode as DId,servicename as DName from servicemaster where Deptcode=@Deptcode and Whetheractive=@Whetheractive order by servicename";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@Deptcode", DeptCode);
            Cmd.Parameters.AddWithValue("@Whetheractive", CustomText.TRUE.ToString());
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillDistrict(string StateId, int? Service)
        {
            if (!string.IsNullOrEmpty(Service.ToString()))
            {
                string DeptCode = Utility.SelectColumnsValue("servicemaster", "deptcode", "servicecode", Service.ToString())[0];
                string Qry = "select DM.districtcode as DId,DM.districtname as Dname from dbo.districtmaster DM inner join dbo.statemaster SM on SM.stateid=DM.stateid where DM.deptcode=@deptcode and SM.stateid=@StateId order by DM.districtname ";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@deptcode", DeptCode);
                Cmd.Parameters.AddWithValue("@StateId", StateId);
                return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
            }
            if (Sessions.getEmployeeUser() != null)
            {
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DeptCode))
                {
                    string DeptCode = Sessions.getEmployeeUser().DeptCode;
                    string Qry = "select DM.districtcode as DId,DM.districtname as Dname from dbo.districtmaster DM inner join dbo.statemaster SM on SM.stateid=DM.stateid where DM.deptcode=@deptcode and SM.stateid=@StateId order by DM.districtname";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@deptcode", DeptCode);
                    Cmd.Parameters.AddWithValue("@StateId", StateId);
                    return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
                }
            }
            return null;
        }
        [AllowAnonymous]
        public ActionResult FillSubDivision(string DistrictCode)
        {
            string Qry = "select DM.districtcode, SDM.Subdivcode as DId,SDM.SubDivdescription as Dname from dbo.Subdivmaster SDM inner join dbo.districtmaster DM on DM.districtcode=SDM.districtcode where DM.districtcode=@DistrictCode";
            if (Sessions.getEmployeeUser() != null) { if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and SDM.SubDivCode in (@ParamSubDivCode)"; } }
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@DistrictCode", DistrictCode);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        [AllowAnonymous]
        public ActionResult FillRorSubDivision(string DistrictCode)
        {
            string Qry = "select DM.districtcode, SDM.Subdivcode as DId,SDM.SubDivdescription as Dname from dbo.Subdivmaster SDM inner join dbo.districtmaster DM on DM.districtcode=SDM.districtcode where DM.districtcode=@DistrictCode  and SDM.SubDivCode not in (@Gandhi,@Preet,@Rajouri,@Hauz,@Karol,@Kotwali,@Chanakya,@Cantonment,@Saraswati,@Vivek)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@DistrictCode", DistrictCode);
            Cmd.Parameters.AddWithValue("@Gandhi", 881);
            Cmd.Parameters.AddWithValue("@Preet", 882);
            Cmd.Parameters.AddWithValue("@Rajouri", 892);
            Cmd.Parameters.AddWithValue("@Hauz", 912);
            Cmd.Parameters.AddWithValue("@Karol", 922);
            Cmd.Parameters.AddWithValue("@Kotwali", 927);
            Cmd.Parameters.AddWithValue("@Chanakya", 931);
            Cmd.Parameters.AddWithValue("@Cantonment", 937);
            Cmd.Parameters.AddWithValue("@Saraswati", 953);
            Cmd.Parameters.AddWithValue("@Vivek", 983);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetSubDivFromVillage(string VillageId)
        {
            GetData objData = new GetData();
            DistrictResponse model = new DistrictResponse();
            string Qry = "select SD.SubDivCode,SD.SubDivDescription from dbo.VillageMaster VM inner join dbo.SubDivMaster SD on SD.SubDivCode=VM.SubDivCode where VM.VillageId=@VillageId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@VillageId", VillageId);
            DataTable dt = objData.GetDataTable(Cmd);
            if (dt != null && dt.Rows.Count > 0)
            {
                model.ApplicantSubDivDescription = dt.Rows[0]["subdivdescription"].ToString();
                model.ApplicantSubDivCode = dt.Rows[0]["SubDivCode"].ToString();
            }
            return Json(model);
        }
        public JsonResult VerifyDocumentAtDecision(string AppNo)
        {
            bool Result = false;
            GetData data = new GetData();
            string RId = Utility.SelectColumnsValue("ApplicationDetails", "RegistrationId", "ApplicationNo", AppNo)[0];
            string Qry = "select dbo.udf_general_decrypt(documentno) as documentno,documentid,applicantname,applicantgender,to_char(applicantdob,'DD/MM/YYYY') as applicantdob from web.registrationmaster where RegistrationId=@RegistrationId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            Cmd.Parameters.AddWithValue("@RegistrationId", RId);
            string[] ValArray = data.SelectColumns(Cmd);
            int DocStatusId = Utility.VerifyRegistrationDocument(ValArray[2], ValArray[3], ValArray[4], ValArray[0], Convert.ToInt32(ValArray[1]));
            if (DocStatusId == (int)WebServiceResponse.Verified)
            {
                Qry = "update web.registrationmaster set documentstatusid=@documentstatusid,Applicantipaddress=@Applicantipaddress,LastactionPerformed=now(),ActionPerformedBy=@ActionPerformedBy where RegistrationId=@RegistrationId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RegistrationId", RId);
                Cmd.Parameters.AddWithValue("@documentstatusid", (int)WebServiceResponse.Verified);
                Cmd.Parameters.AddWithValue("@ActionPerformedBy", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@Applicantipaddress", Utility.GetIP4Address());
                data.UpdateData(Cmd);
                Result = true;
            }
            return Json(Result);
        }
        public JsonResult VerifyAadharDocument(string AppNo)
        {
            bool Result = false;
            string ApplicantName = string.Empty, ApplicantGender = string.Empty, ApplicantDob = string.Empty;
            GetData data = new GetData();
            string Qry = "select referenceenclosureid,dbo.udf_general_decrypt(documentno) as documentno,DocumentId from applicationenclosuredetails where ApplicationNo=@ApplicationNo and DocumentId in (@AadhaarCard,@CopyofAadhaarCard)";
            NpgsqlCommand objCmd = new NpgsqlCommand(Qry);
            objCmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            objCmd.Parameters.AddWithValue("@AadhaarCard", (int)DocumentId.AadhaarCard);
            objCmd.Parameters.AddWithValue("@CopyofAadhaarCard", (int)DocumentId.AadhaarCardCopy);
            DataTable dt = data.GetDataTable(objCmd);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    Qry = "select verifyvalueid from applicantenclosuredetails where enclosureid=@enclosureid";
                    objCmd = new NpgsqlCommand(Qry);
                    objCmd.Parameters.AddWithValue("@enclosureid", dt.Rows[0]["referenceenclosureid"].ToString());
                    string ValueExist = data.SelectColumns(objCmd)[0];
                    if (!string.IsNullOrEmpty(ValueExist))
                    {
                        if (Convert.ToInt32(ValueExist) != (int)WebServiceResponse.Verified)
                        {
                            string[] Values = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ApplicantName,ApplicantGender,to_char(ApplicantDob,'DD/MM/YYYY') as ApplicantDob", "ApplicationNo", AppNo);
                            ApplicantName = Values[0];
                            ApplicantGender = Values[1];
                            ApplicantDob = Values[2];

                            string[] Values1 = Utility.SelectColumnsValue("dgen.scstupdatedapplicationdetail", "ApplicantName,ApplicantGender,to_char(ApplicantDob,'DD/MM/YYYY') as ApplicantDob", "ApplicationNo", AppNo);
                            if (Values1 != null)
                            {
                                if (!string.IsNullOrEmpty(Values1[0])) { ApplicantName = Values1[0]; }
                                if (!string.IsNullOrEmpty(Values1[1])) { ApplicantGender = Values1[1]; }
                                if (!string.IsNullOrEmpty(Values1[2])) { ApplicantDob = Values1[2]; }
                            }
                            int DocStatusId = Utility.VerifyAadharDocument(ApplicantName, ApplicantGender, ApplicantDob, dt.Rows[0]["documentno"].ToString(), Convert.ToInt32(dt.Rows[0]["DocumentId"].ToString()));
                            if (DocStatusId == (int)WebServiceResponse.Verified)
                            {
                                int rtrnresult = Utility.UpdateDocumentStatus(AppNo, dt.Rows[0]["documentno"].ToString(), dt.Rows[0]["DocumentId"].ToString(), Convert.ToString((int)EnclosureDepartment.UID), ApplicantName, ApplicantGender, ApplicantDob);
                                if (rtrnresult == (int)WebServiceResponse.Verified) { Result = true; }
                                else { Result = false; }
                            }
                        }
                    }
                }
            }
            return Json(Result);
        }
        [AllowAnonymous]
        public ActionResult FillVillage(string SubDivCode)
        {
            string Qry = "select SDM.Subdivcode,VM.VillageId as DId,VM.VillageName as Dname from dbo.Villagemaster VM inner join dbo.SubDivmaster SDM on SDM.SubDivcode=VM.SubDivcode where SDM.SubDivcode=@SubDivCode";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@SubDivCode", SubDivCode);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillDisPercentage(string DID)
        {
            string Qry = "select DPM.DPercentageName as Dname,DPM.DPercentageId as DId from dbo.DisabilityPercentageMaster DPM inner join dbo.DisabilityToPercentageMaster DTPM on DPM.DPercentageId=DTPM.DPercentageId inner join dbo.DisabilityTypeMaster DTM on DTM.DisabilityTypeId=DTPM.DisabilityTypeId where DTM.DisabilityTypeId=@DisabilityTypeId order By DPM.DPercentageId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DisabilityTypeId", DID);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillRelationId()
        {
            string Qry = "select SMVD.valueid as DId,SMVD.valuename as DName from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by SMVD.valuename";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.SurvivingMemberRelationship);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillNFSRelationId()
        {
            string Qry = "select SMVD.valueid as DId,SMVD.valuename as DName from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by SMVD.valuename";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.NFSMemberRelationship);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillGenderList()
        {
            List<SelectListItem> list = new List<SelectListItem>();
            list.Add(new SelectListItem() { Text = "Male", Value = "M" });
            list.Add(new SelectListItem() { Text = "Female", Value = "F" });
            return Json(list, JsonRequestBehavior.AllowGet);
        }        
        public ActionResult FillSurvivingDocumentId()
        {
            string Qry = "select DocumentId as DId,DocumentName as DName from dbo.DocumentMaster where DocumentId in (@DrivingLicense,@VoterID,@PANCard,@Passport,@RationCard,@AadhaarCard,@GovtDoc)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DrivingLicense", (int)DocumentId.DrivingLicense);
            Cmd.Parameters.AddWithValue("@VoterID", (int)DocumentId.VoterID);
            Cmd.Parameters.AddWithValue("@PANCard", (int)DocumentId.PANCard);
            Cmd.Parameters.AddWithValue("@Passport", (int)DocumentId.Passport);
            Cmd.Parameters.AddWithValue("@RationCard", (int)DocumentId.RationCard);
            Cmd.Parameters.AddWithValue("@AadhaarCard", (int)DocumentId.AadhaarCard);
            Cmd.Parameters.AddWithValue("@GovtDoc", (int)DocumentId.GovtRecDoc);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillFirmIdentityDocumentId()
        {
            string Qry = "select DocumentId as DId,DocumentName as DName from dbo.DocumentMaster where DocumentId in (@DrivingLicense,@VoterID,@PANCard,@Passport,@RationCard,@Other)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DrivingLicense", (int)DocumentId.DrivingLicense);
            Cmd.Parameters.AddWithValue("@VoterID", (int)DocumentId.VoterID);
            Cmd.Parameters.AddWithValue("@PANCard", (int)DocumentId.PANCard);
            Cmd.Parameters.AddWithValue("@Passport", (int)DocumentId.Passport);
            Cmd.Parameters.AddWithValue("@RationCard", (int)DocumentId.RationCard);
            Cmd.Parameters.AddWithValue("@Other", (int)DocumentId.Other);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillFirmResidentDocumentId()
        {
            string Qry = "select DocumentId as DId,DocumentName as DName from dbo.DocumentMaster where DocumentId in (@DrivingLicense,@VoterID,@Passport,@RationCard,@AadhaarCard)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DrivingLicense", (int)DocumentId.DrivingLicense);
            Cmd.Parameters.AddWithValue("@VoterID", (int)DocumentId.VoterID);
            Cmd.Parameters.AddWithValue("@Passport", (int)DocumentId.Passport);
            Cmd.Parameters.AddWithValue("@RationCard", (int)DocumentId.RationCard);
            Cmd.Parameters.AddWithValue("@AadhaarCard", (int)DocumentId.AadhaarCard);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillPermissionList()
        {
            string Qry = "select pcode  as DId,pname  as Dname from dbo.permissionmaster Where WhetherActive=True order by pname";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillUserList(string DistrictCode, string SubDivCode, string Pcode)
        {
            string Qry = "select UM.UserId as DId,UserName as Dname from dbo.UserMaster UM inner join UsertoSubDivmaster UTSDM on UTSDM.uid=UM.uid Where UM.WhetherActive=True and DistrictCode=@DistrictCode and SubDivCode=@SubDivCode and permission=@permission order by UserName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DistrictCode", DistrictCode);
            Cmd.Parameters.AddWithValue("@SubDivCode", SubDivCode);
            Cmd.Parameters.AddWithValue("@permission", Pcode);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillAllRelationId()
        {
            string Qry = "select RelationId as DId,RelationName as Dname from dbo.RelationMaster";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult UpdateUserDigitalMapping(string RowId, string UserId, int Flag)
        {
            string Qry = string.Empty;
            int result = 0, SaveCount = 0;
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            NpgsqlCommand Cmd = null;
            if (Flag == (int)CountList.Type001 || Flag == (int)CountList.Type003)
            {
                Qry = "Update UserDigitalMaster set WhetherActive=@WhetherActive,DeactivateDate=now(),ActionUserId=@ActionUserId,IpAddress=@IpAddress,ActionDateTime=now() where RowId=@RowId;";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RowId", RowId);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.FALSE.ToString());
                Cmd.Parameters.AddWithValue("@ActionUserId", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);
                SaveCount = data.SaveData(cmdList);
                if (SaveCount > 0)
                {
                    result = (int)CountList.Type001;
                }
            }
            else if (Flag == (int)CountList.Type002)
            {
                Qry = "Select UserId from Userdigitalmaster where  WhetherActive=@WhetherActive and UserId=@UserId order by WhetherActive desc ";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@UserId", UserId);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                string WhetherUserIdExist = data.SelectColumns(Cmd)[0];
                if (!string.IsNullOrEmpty(WhetherUserIdExist))
                {
                    result = (int)CountList.Type002;
                }
                else
                {
                    Qry = null;
                    Qry = "Update UserDigitalMaster set WhetherActive=@WhetherActive,ActionUserId=@ActionUserId,IpAddress=@IpAddress,ActionDateTime=now() where RowId=@RowId;";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@RowId", RowId);
                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@ActionUserId", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                    SaveCount = data.SaveData(cmdList);
                    if (SaveCount > 0)
                    {
                        result = (int)CountList.Type003;
                    }
                }
            }

            return Json(result);
        }
        public ActionResult FillTrainingDays(string TrainingTypeId, string CourseId)
        {
            GetData data = new GetData();
            string Qry = "select TrainingDays as DId,TrainingDays as Dname from CourseMaster  where ValueId=@TrainingTypeId and CourseId=@CourseId order by CourseName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@TrainingTypeId", TrainingTypeId);
            Cmd.Parameters.AddWithValue("@CourseId", CourseId);
            DataTable dt = data.GetDataTable(Cmd);
            string result = string.Empty;
            if (dt != null && dt.Rows.Count > 0)
            {
                result = dt.Rows[0]["DId"].ToString();
            }
            return Json(result);
        }
        public ActionResult FillInstitution(string CourseEligibilityId)
        {
            if (string.IsNullOrEmpty(CourseEligibilityId)) { return null; }

            string Qry = "select InstituitonId as DId,InstituitonName as Dname from HeInstitutionMaster where whetheractive=true and CourseEligibility=@CourseEligibilityId order by InstituitonName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@CourseEligibilityId", CourseEligibilityId);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillHeInstitution(string UniversityId)
        {
            string Qry = "select InstituitonId as DId,InstituitonName as Dname from HeInstitutionMaster where whetheractive=true and UniversityId=@UniversityId order by InstituitonName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@UniversityId", UniversityId);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillHeCourse(string InstitutionId)
        {
            string Qry = "select distinct HCM.HecourseId as DId,CourseName as Dname  from hecoursemaster HCM inner join institutetoclassfeesdetails ITCF on ITCF.HecourseId=HCM.HecourseId where InstitutionId=@InstitutionId and ITCF.whetheractive=@whetheractive and whetherapproved=@whetherapproved";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@InstitutionId", InstitutionId);
            Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
            Cmd.Parameters.AddWithValue("@whetherapproved", CustomText.TRUE.ToString());
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillHeFinancialAssistanceCategory(string AnnualIncome, string WhetherNFSS)
        {
            string ValueData = string.Empty;
            if (WhetherNFSS.ToUpper() == CustomText.TRUE.ToString())
            {
                ValueData = ((int)ValueId.HeCategory1).ToString();
            }
            else if (WhetherNFSS.ToUpper() == CustomText.FALSE.ToString() && Convert.ToInt64(AnnualIncome) <= 250000)
            {
                ValueData = ((int)ValueId.HeCategory2).ToString();
            }
            else if (WhetherNFSS.ToUpper() == CustomText.FALSE.ToString() && Convert.ToInt64(AnnualIncome) > 250000 && Convert.ToInt64(AnnualIncome) <= 600000)
            {
                ValueData = ((int)ValueId.HeCategory3).ToString();
            }
            string Qry = "select SMVD.valueId as DId, SMVD.valuename as Dname from  selectmastervaluedetails SMVD inner join selectmastervaluetodetails SMVTD  on SMVTD.valueid=SMVD.valueid where mastervalueid=@mastervalueid";
            if (!string.IsNullOrEmpty(ValueData))
            {
                Qry += " and SMVD.valueid=@valueid";
            }
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@valueid", ValueData);
            Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HEFinancialAssistanceCategory);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillHePresentClass(string CourseId)
        {
            string CoursePeriod = Utility.SelectColumnsValue("hecoursemaster", "CoursePeriod", "HeCourseId", CourseId)[0];
            string Qry = "select SMVD.valueId as DId, SMVD.valuename as Dname from  selectmastervaluedetails SMVD inner join selectmastervaluetodetails SMVTD  on SMVTD.valueid=SMVD.valueid where mastervalueid=@mastervalueid order by SMVD.valueId limit " + CoursePeriod;
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ClassId", CourseId);
            Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HECurrentStudyingClass);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillHePreviousClass(string PresentClass)
        {
            string Qry = "select SMVD.valueId as DId, SMVD.valuename as Dname from  selectmastervaluedetails SMVD inner join selectmastervaluetodetails SMVTD  on SMVTD.valueid=SMVD.valueid where mastervalueid=@mastervalueid and (SMVD.valueid < @ValueId or SMVD.valueid in (@HigherClass)) order by 2 desc";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ValueId", PresentClass);
            Cmd.Parameters.AddWithValue("@HigherClass", (int)ValueId.HigherclassorEquivalent);
            Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HEPreviousClassPassed);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillSchool(string SchoolCategoryId)
        {
            string Qry = "select schoolid as DId,schoolname as Dname from dbo.heschoolmaster where schoolcategoryid=@SchoolCategoryId order by schoolname";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@SchoolCategoryId", SchoolCategoryId);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillUniversity(string InstitutionId, string CourseEligibilityId)
        {
            string Qry = "select distinct HUM.UniversityId as DId,UniversityName as Dname from heuniversitymaster HUM inner join HeInstitutionMaster HIM on HIM.UniversityId=HUM.UniversityId  where HUM.whetheractive=true and InstituitonId=@InstitutionId and  CourseEligibility=@CourseEligibilityId  order by UniversityName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@InstitutionId", InstitutionId);
            Cmd.Parameters.AddWithValue("@CourseEligibilityId", CourseEligibilityId);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillCourseExamination(string CourseId, string InstitutionId)
        {
            GetData objData = new GetData();
            HeEducationalDetails model = new HeEducationalDetails();

            string Qry = "select valueid from selectmastervaluedetails where valueid in ( select courserequired from hecoursemaster HCM inner join  heinstitutiontocourse HIC on HIC.CourseId=HCM.HeCourseId  where CourseId =@CourseId  and institutionId=@institutionId)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@CourseId", CourseId);
            Cmd.Parameters.AddWithValue("@institutionId", InstitutionId);
            DataTable dt = objData.GetDataTable(Cmd);
            if (dt != null && dt.Rows.Count > 0)
            {
                model.ExaminationId = dt.Rows[0]["valueid"].ToString();
            }
            return Json(model);
        }
        public ActionResult FillWitness(string Witness)
        {

            string Qry = "select SMVD.valueid as DId,SMVD.valuename as Dname from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid and SMVD.valueid not in (@ValueId) order by SMVD.valuename";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.WidowWitness);
            Cmd.Parameters.AddWithValue("@ValueId", Witness);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillHeBankBranch(string HeBankCode)
        {
            string Qry = "select HeBranchCode as DId,BranchName as Dname  from dbo.HeBankBranchMaster where whetheractive=True and HeBankCode=@HeBankCode order by BranchName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@HeBankCode", HeBankCode);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillSCSTSchoolList(string SchoolType, string DepartmentId, int ServiceCode)
        {
            //string Qry = "select PSM.SchoolId as DId,SchoolName||','||SchoolAddress as DName from dgen.prematschoolmaster PSM where PSM.WhetherActive=@WhetherActive and SchoolTypeId=@SchoolTypeId";
            string Qry = "select PSM.SchoolId as DId,SchoolName||','||SchoolAddress || case when SchoolCode is null then '' else '(School ID:'|| SchoolCode||')' end  as DName from dgen.prematschoolmaster PSM where PSM.WhetherActive=@WhetherActive and SchoolTypeId=@SchoolTypeId";
            if (!string.IsNullOrEmpty(DepartmentId))
            {
                Qry += " and DepartmentId=@DepartmentId ";
            }
            Qry += " order by SchoolName ";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@SchoolTypeId", SchoolType);
            Cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            Cmd.Parameters.AddWithValue("@DepartmentId", DepartmentId);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillPrematSchoolDeptList(string SchoolType, string WhetherInDelhi = "True")
        {
            string WhetherCondition = string.Empty;
            if (SchoolType == ((int)ValueId.GovernmentSchool).ToString())
            {
                WhetherCondition += " and PSM.DepartmentId=@DepartmentId ";
            }
            string Qry = "select PSM.DepartmentId as DId,ValueName as DName from dgen.prematschooltypetodept PSM inner join selectmastervaluedetails SM on SM.ValueId=PSM.DepartmentId where PSM.WhetherActive=@WhetherActive and SchoolTypeId=@SchoolTypeId and whetherindelhi=@WhetherInDelhi " + WhetherCondition;
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@SchoolTypeId", SchoolType);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
            Cmd.Parameters.AddWithValue("@WhetherInDelhi", WhetherInDelhi);
            Cmd.Parameters.AddWithValue("@DepartmentId", (int)ValueId.KendriyaVidyalaya);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillSCSTSchlDeptList(string SchoolType, string WhetherInDelhi = "True")
        {
            GetData Data = new GetData();
            string Qry = string.Empty, AuthId = string.Empty;
            
            NpgsqlCommand Cmd = new NpgsqlCommand();
            if (Sessions.getEmployeeUser().AuthorizationId.ToString() != Convert.ToString((int)CountList.Type000))
            {
                Qry = "select DepartmentId from dgen.prematdistrictmaster PDM  left outer join dgen.prematzonemaster PZM on PZM.DistrictCode=PDM.DistrictId where ZoneId=@AuthId or DistrictId=@AuthId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@AuthId", Sessions.getEmployeeUser().AuthorizationId.ToString());
                string DepartmentId = Data.SelectColumns(Cmd)[0];
                if (!string.IsNullOrEmpty(DepartmentId))
                {
                    AuthId = DepartmentId;
                }
                else
                {
                    AuthId = Sessions.getEmployeeUser().AuthorizationId.ToString();
                }
            }

            Qry = "select PSM.DepartmentId as DId,ValueName as DName from dgen.prematschooltypetodept PSM inner join selectmastervaluedetails SM on SM.ValueId=PSM.DepartmentId where PSM.WhetherActive=@WhetherActive and SchoolTypeId=@SchoolTypeId and whetherindelhi=@WhetherInDelhi ";
            if (Sessions.getEmployeeUser() != null)
            {
                if (Sessions.getEmployeeUser().AuthorizationId.ToString() != Convert.ToString((int)CountList.Type000)) { Qry += " and ValueId=@AuthId "; }
            }
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@SchoolTypeId", SchoolType);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
            Cmd.Parameters.AddWithValue("@WhetherInDelhi", WhetherInDelhi);
            if (Sessions.getEmployeeUser() != null)
            {
                if (Sessions.getEmployeeUser().AuthorizationId.ToString() != Convert.ToString((int)CountList.Type000)) { Cmd.Parameters.AddWithValue("@AuthId", AuthId); }
            }
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillSCSTSchoolDeptList(string SchoolType, string WhetherInDelhi = "True")
        {
            string WhetherCondition = string.Empty;
            if (SchoolType == ((int)ValueId.PrivateSchool).ToString())
            {
                WhetherCondition += " and PSM.DepartmentId not in (@DepartmentId) ";
            }

            string Qry = "select PSM.DepartmentId as DId,ValueName as DName from dgen.prematschooltypetodept PSM inner join selectmastervaluedetails SM on SM.ValueId=PSM.DepartmentId where PSM.WhetherActive=@WhetherActive and SchoolTypeId=@SchoolTypeId and whetherindelhi=@WhetherInDelhi " + WhetherCondition;
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@SchoolTypeId", SchoolType);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
            Cmd.Parameters.AddWithValue("@WhetherInDelhi", WhetherInDelhi);
            Cmd.Parameters.AddWithValue("@DepartmentId", (int)ValueId.RehabilitationCouncilofIndia);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillKhataList(string VillageId)
        {
            return Json(Utility.FillKhataList(VillageId), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillVillageNoKhataNo(string VillageId, string KhataNo)
        {
            string[] str = new string[2];
            str[0] = VillageId;
            str[1] = KhataNo;
            TempData[KeyName._Key07] = str;
            return Json(str);
        }
        public ActionResult FillAllLocality(string SubDivCode)
        {
            string Qry = "select lm.localityid as DId,lm.localityname as DName from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@DeptCode and ls.whetheractive=@whetheractive and sd.SubDivCode in (@SubDivCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@SubDivCode", SubDivCode);
            Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
            Cmd.Parameters.AddWithValue("@DeptCode", Sessions.getEmployeeUser().DeptCode);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult FillLocalityList(string SubDivCode)
        {
            string Qry = "select LM.localityid as DId, LM.localityname as DName from localitymaster LM inner join localitytosubdivmaster LSM on LSM.localityid=LM.localityid inner join subdivmaster SM on SM.subdivcode=LSM.subdivcode inner join districtmaster DM on DM.districtcode=SM.districtcode where LSM.whetheractive=@whetheractive and SM.subdivcode in (@SubDivCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@SubDivCode", SubDivCode);
            Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public JsonResult FillConstituency(string Locality)
        {
            AssemblyConstituencyMaster model = new AssemblyConstituencyMaster();
            if (string.IsNullOrEmpty(Locality)) { return null; }
            GetData objData = new GetData();
            string Qry = "select b.ConstituencyId,ConstituencyName from assemblyconstituencymaster ACM inner join localitytoconstituencymaster b on b.constituencyid=ACM.constituencyid where localityId=@localityId and b.deptcode=@deptcode and b.whetheractive=true";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@localityId", Locality);
            Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
            DataTable dt = objData.GetDataTable(Cmd);
            if (dt != null && dt.Rows.Count > 0)
            {
                model.ConstituencyID = dt.Rows[0]["ConstituencyId"].ToString();
                model.ConstituencyName = dt.Rows[0]["ConstituencyName"].ToString();
            }

            return Json(model);
        }
        public ActionResult FillClassList(string ClassId, int ServiceCode)
        {
            string Qry = "select ClassId as DId,ValueName as DName from dgen.prematclasstoservice PCTS inner join SelectMasterValueDetails SMVD on SMVD.ValueId=PCTS.ClassId where ServiceCode=@ServiceCode and PCTS.Whetheractive=@WhetherActive and displayorder < (select displayorder from dgen.prematclasstoservice  where ServiceCode=@ServiceCode and Classid=@ClassId) order by displayorder desc";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            Cmd.Parameters.AddWithValue("@ClassId", ClassId);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillMenuEntryList(string DeptCode)
        {
            string Qry = "select PM.pcode as DId,pname as DName from dbo.permissionmaster PM inner join DeptToPermissionMaster DPM on DPM.pcode=PM.pcode::int where deptcode=@DeptCode order by pname";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DeptCode", DeptCode);
            Cmd.Parameters.AddWithValue("@WhetherEntryAllowed", CustomText.True.ToString());
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillNMRelationListForNominee()
        {
            NpgsqlCommand Cmd = new NpgsqlCommand("select relationid as DId,relationname as DName from relationmaster where relationid in(25,14,4,8,17,19,20,23) order by 2 desc");
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillNMRelationListForFamily()
        {
            NpgsqlCommand Cmd = new NpgsqlCommand("select relationid as DId,relationname as DName from relationmaster where relationid in(25,14,4,23) order by 2 desc");
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillClassListforLbr()
        {
            string Qry = "select  s1.ValueId as DId , s1.ValueName as DName, (case when char_length(s1.valuename)=4 then substring(s1.valuename from 0 for 3) else substring(s1.valuename from 0 for 2) end)::int as classvalue from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by  classvalue";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.lbrClassList);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetCasteExist(string CasteId, string CasteCerNo)
        {
            CasteDetails model = new CasteDetails();
            if (string.IsNullOrEmpty(CasteId) || string.IsNullOrEmpty(CasteCerNo)) { return null; }
            GetData objData = new GetData();
            string WhetherCon = string.Empty, Qry = string.Empty;
            if (CasteCerNo.Length == 14 && (Convert.ToInt32(CasteCerNo.Substring(4, 1)) < 8))
            {
                if (Convert.ToInt32(CasteId) == (int)ValueId.SC) { WhetherCon = " drev.applicationdetailsscst SC "; }
                else if (Convert.ToInt32(CasteId) == (int)ValueId.ST) { WhetherCon = " drev.applicationdetailsst SC "; }
                else if (Convert.ToInt32(CasteId) == (int)ValueId.OBC) { WhetherCon = " drev.applicationdetailsobc SC "; }
            }
            else
            {
                WhetherCon = " applicationdetailsepp SC ";
            }

            if (CasteCerNo.Length == 14 && (Convert.ToInt32(CasteCerNo.Substring(4, 1)) < 8))
            { Qry = "select  ServiceCode,AD.ApplicationNo,to_char(AD.lastactiondate,'DD/MM/YYYY') as SignedDate,'True' as WhetherCasteVerified from applicationdetails AD inner join " + WhetherCon + " on SC.ApplicationNo=AD.applicationNO where ApplicationStatusId=@ApplicationStatusId and AD.ApplicationNo=@ApplicationNo"; }
            else
            { Qry = "select ServiceCode,IdNo as ApplicationNo,to_char(dop,'DD/MM/YYYY') as SignedDate,'True' as WhetherCasteVerified from applicationdetailsepp where IdNo=@ApplicationNo and upper(Status)=@ApplicationStatusId"; }

            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", CasteCerNo);
            if (CasteCerNo.Length == 14 && (Convert.ToInt32(CasteCerNo.Substring(4, 1)) < 8)) { Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER); }
            else { Cmd.Parameters.AddWithValue("@ApplicationStatusId", CustomText.ISSUED.ToString()); }

            DataTable dt = objData.GetDataTable(Cmd);
            if (dt != null && dt.Rows.Count > 0)
            {
                model.ApplicationNo = dt.Rows[0]["ApplicationNo"].ToString();
                model.ServiceCode = dt.Rows[0]["ServiceCode"].ToString();
                model.IssuedDate = dt.Rows[0]["SignedDate"].ToString();
                model.WhetherCasteVerified = dt.Rows[0]["WhetherCasteVerified"].ToString();
                string getValue = CasteId + "," + CasteCerNo;
                TempData[KeyName._Key05] = getValue;
            }


            return Json(model);
        }
        public JsonResult GetSchoolDetailsForPreMat(string SchoolId)
        {
            PreMatricModel model = new PreMatricModel();
            if (string.IsNullOrEmpty(SchoolId)) { return null; }
            GetData objData = new GetData();
            string Qry = "select PM.SchoolId,PM.SchoolName,PM.SchoolAffiliationId,PM.PinCode,PM.SchoolAddress,PM.District,DM.DistrictName,SM.StateName,PM.State,SMV.ValueId as DepartmentId,ValueName as DepartmentType,ZoneName from dgen.prematschoolmaster PM inner join dgen.prematdistrictmaster DM on DM.Districtid=PM.District inner join statemaster SM on SM.stateid=PM.state inner join selectmastervaluedetails SMV on SMV.ValueId=PM.DepartmentId  left outer join dgen.prematZonemaster PZM on PZM.ZoneId=PM.subdivision where PM.SchoolId=@SchoolId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@SchoolId", SchoolId);
            DataTable dt = objData.GetDataTable(Cmd);
            if (dt != null && dt.Rows.Count > 0)
            {
                model.SchoolId = dt.Rows[0]["SchoolId"].ToString();
                model.SchoolAffiliationId = dt.Rows[0]["SchoolAffiliationId"].ToString();
                model.SchoolName = dt.Rows[0]["SchoolName"].ToString();
                model.SchoolAddress = dt.Rows[0]["SchoolAddress"].ToString();
                model.PinCode = dt.Rows[0]["PinCode"].ToString();
                model.SchoolState = dt.Rows[0]["StateName"].ToString();
                model.StateId = dt.Rows[0]["State"].ToString();
                model.District = dt.Rows[0]["DistrictName"].ToString();
                model.DistrictCode = dt.Rows[0]["District"].ToString();
                model.DepartmentId = dt.Rows[0]["DepartmentId"].ToString();
                model.DepartmentType = dt.Rows[0]["DepartmentType"].ToString();
                model.SubDivision = dt.Rows[0]["ZoneName"].ToString();
            }
            return Json(model);
        }
        public JsonResult GetHeBranchDetails(string BranchId)
        {
            HeBankBranchMaster model = new HeBankBranchMaster();
            if (string.IsNullOrEmpty(BranchId)) { return null; }
            GetData objData = new GetData();
            string Qry = "select BranchAddress,BranchEmail,BranchContactNo,BaseInterestRate from hebankbranchmaster where HeBranchCode=@HeBranchCode";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@HeBranchCode", BranchId);
            DataTable dt = objData.GetDataTable(Cmd);
            if (dt != null && dt.Rows.Count > 0)
            {
                model.BranchAddress = dt.Rows[0]["BranchAddress"].ToString();
                model.BranchEmail = dt.Rows[0]["BranchEmail"].ToString();
                model.BranchContactNo = dt.Rows[0]["BranchContactNo"].ToString();
                model.BaseInterestRate = dt.Rows[0]["BaseInterestRate"].ToString();
            }
            return Json(model);
        }
        public JsonResult GetHeBabkDetails(string BankId)
        {
            BankMaster model = new BankMaster();
            if (string.IsNullOrEmpty(BankId)) { return null; }
            GetData objData = new GetData();
            string Qry = "select BankAddress,BankEmail,BankContactNo from hebankmaster where HebankCode=@HebankCode";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@HebankCode", BankId);
            DataTable dt = objData.GetDataTable(Cmd);
            if (dt != null && dt.Rows.Count > 0)
            {
                model.BankAddress = dt.Rows[0]["BankAddress"].ToString();
                model.BankEmail = dt.Rows[0]["BankEmail"].ToString();
                model.BankContactNo = dt.Rows[0]["BankContactNo"].ToString();
            }
            return Json(model);
        }
        public JsonResult GetHeInstitutionDetails(string InstitutionId)
        {
            HeInstitutionMaster model = new HeInstitutionMaster();
            if (string.IsNullOrEmpty(InstitutionId)) { return null; }
            GetData objData = new GetData();
            string Qry = "select InstitutionAddress,AffiliationCode from heinstitutionmaster HIM where InstituitonId=@InstituitonId ";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@InstituitonId", InstitutionId);
            DataTable dt = objData.GetDataTable(Cmd);
            if (dt != null && dt.Rows.Count > 0)
            {
                model.InstitutionAddress = dt.Rows[0]["InstitutionAddress"].ToString();
                model.AffiliationCode = dt.Rows[0]["AffiliationCode"].ToString();
            }
            return Json(model);
        }
        public JsonResult GetHeCourseFee(string InstitutionId, string CourseId, string PresentClass, string AcademicSession)
        {
            HeInstitutionMaster model = new HeInstitutionMaster();
            if (string.IsNullOrEmpty(InstitutionId)) { return null; }
            GetData objData = new GetData();
            string Qry = "select feeamount from heinstitutionmaster HIM inner join institutetoclassfeesdetails ITCF on ITCF.InstitutionId=HIM.InstituitonId  where HecourseId=@HecourseId and  InstituitonId=@InstituitonId and HeCourseSession=@HeCourseSession and ITCF.whetheractive=@whetheractive and whetherapproved=@whetherapproved and AcademicSession=@AcademicSession";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@InstituitonId", InstitutionId);
            Cmd.Parameters.AddWithValue("@HecourseId", CourseId);
            Cmd.Parameters.AddWithValue("@HeCourseSession", PresentClass);
            Cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
            Cmd.Parameters.AddWithValue("@whetherapproved", CustomText.TRUE.ToString());
            DataTable dt = objData.GetDataTable(Cmd);
            if (dt != null && dt.Rows.Count > 0)
            {
                model.FeeAmount = dt.Rows[0]["feeamount"].ToString();
            }
            return Json(model);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult ServiceCodeWiseUniversityList(string ServiceCode)
        {
            string Qry = "select universityid as DId,universityname as DName from heuniversitymaster where servicecode=@servicecode and Whetheractive=@Whetheractive ";
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { Qry += " and universityid in (@ParamAuthorizationId) "; }
            Qry += " order by universityname";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@servicecode", ServiceCode);
            Cmd.Parameters.AddWithValue("@Whetheractive", CustomText.TRUE.ToString());

            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetVillageDetails(string VillageId)
        {
            VillageMaster model = new VillageMaster();
            if (string.IsNullOrEmpty(VillageId)) { return null; }
            GetData objData = new GetData();
            string Qry = "Select VM.SubDivCode,SubDivDescription,SDM.DistrictCode,DistrictName from villagemaster VM inner join SubDivMaster SDM on SDM.SubDivCode=VM.SubDivCode inner join DistrictMaster DM on DM.DistrictCode=SDM.DistrictCode where VillageId=@VillageId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@VillageId", VillageId);
            DataTable dt = objData.GetDataTable(Cmd);
            if (dt != null && dt.Rows.Count > 0)
            {
                model.SubDivCode = dt.Rows[0]["SubDivCode"].ToString();
                model.SubDivName = dt.Rows[0]["SubDivDescription"].ToString();
                model.DistrictCode = dt.Rows[0]["DistrictCode"].ToString();
                model.DistrictName = dt.Rows[0]["DistrictName"].ToString();
            }
            return Json(model);
        }
        public IEnumerable<SelectListItem> GetDropdown(NpgsqlCommand Cmd)
        {
            GetData data = new GetData();
            List<SelectListItem> type = new List<SelectListItem>();
            DataTable dt = data.GetDataTable(Cmd);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                SelectListItem item = new SelectListItem() { Text = dt.Rows[i]["DName"].ToString(), Value = dt.Rows[i]["DId"].ToString() };
                type.Add(item);
            }
            return type;
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult VerifyDocument(string DocumentNo, string DocumentId, string DepartmentId, string RegistrationId)
        {
            GetData data = new GetData();
            DataTable dt = new DataTable();
            string result = DocumentNo;

            try
            {
                int WebServiceMethodId = Utility.GetWebServiceMethodId(DocumentId, DepartmentId);
                result = Utility.WebServiceResult(WebServiceMethodId, DocumentNo, DocumentId, DepartmentId, RegistrationId, null);
                if (result == Convert.ToString((int)WebServiceResponse.WebServiceNotAvailable) || result == Convert.ToString((int)WebServiceResponse.NotVerified) || result == Convert.ToString((int)WebServiceResponse.VerificationPending))
                {
                    return Json(result);
                }
                TempData[KeyName._Key06] = result;
                string[] Arr = result.Split('|');
                result = Arr[0].ToString();
                if (string.IsNullOrEmpty(result)) { result = Convert.ToString((int)WebServiceResponse.ExceptionOccurred); }
            }
            catch { result = Convert.ToString((int)WebServiceResponse.ExceptionOccurred); }
            return Json(result);//2/60--already exist, 1/58--verified, 3/61--exeption occured while verification, 0/59--not verified



            //GetData data = new GetData();
            //DataTable dt = new DataTable();
            //string result = DocumentNo;

            //string Qry = "select verificationdataid,dbo.udf_general_decrypt(documentno) as documentno,receivedtid,name,dateofissue,issuedby,address,dateofvalid,dob,gender ,fathername,mothername,spousename,dbo.udf_general_decrypt(aadhaarno) as aadhaarno,photograph,deptlogid,userid,password,checksum,documentid,departmentid,transactionid,whetheractive,documentstatus,registrationid from dbo.verificationdatamaster where DocumentNo=@DocumentNo and DocumentId=@DocumentId and DepartmentId=@DepartmentId and WhetherActive=@WhetherActive";
            //NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            //Cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(DocumentNo.ToUpper()));
            //Cmd.Parameters.AddWithValue("@DocumentId", DocumentId);
            //Cmd.Parameters.AddWithValue("@DepartmentId", DepartmentId);
            //Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
            //dt = data.GetDataTable(Cmd);
            //if (dt.Rows.Count > 0)
            //{
            //    result = Convert.ToString((int)WebServiceResponse.AlreadyExist);
            //}
            //else
            //{
            //    int WebServiceMethodId = Utility.GetWebServiceMethodId(DocumentId, DepartmentId);
            //    try
            //    {
            //        result = Utility.WebServiceResult(WebServiceMethodId, DocumentNo, DocumentId, DepartmentId, RegistrationId, null);
            //        if (result == Convert.ToString((int)WebServiceResponse.WebServiceNotAvailable) || result == Convert.ToString((int)WebServiceResponse.NotVerified) || result == Convert.ToString((int)WebServiceResponse.VerificationPending))
            //        {
            //            return Json(result);
            //        }
            //        TempData[KeyName._Key06] = result;
            //        string[] Arr = result.Split('|');
            //        result = Arr[0].ToString();
            //        if (string.IsNullOrEmpty(result)) { result = Convert.ToString((int)WebServiceResponse.ExceptionOccurred); }
            //    }
            //    catch { result = Convert.ToString((int)WebServiceResponse.ExceptionOccurred); }
            //}
            //return Json(result);//2/60--already exist, 1/58--verified, 3/61--exeption occured while verification, 0/59--not verified
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult CheckAndVerifyEnclosure(string DocumentId, string DocumentNo, string RegId)
        {
            GetData data = new GetData();
            ApplicantEnclosureDetails model = new ApplicantEnclosureDetails();
            model.flag = false;
            string Qry = "select 'Copy of this document is already uploaded under MYDOC on '||to_char(AED.DocumentEntryDate,'DD/MM/YYYY') as DocumentEntryDate,AED.EnclosureId,DM.DocumentName as DocumentId,dbo.udf_general_decrypt(AED.DocumentNo) as DocumentNo,AED.WhetherVerified,SMV.ValueName as VerifyValue from applicantenclosuredetails AED inner join DocumentMaster DM on DM.DocumentId=AED.DocumentId left outer join selectmastervaluedetails SMV on SMV.valueid=AED.verifyvalueid where AED.DocumentId=@DocumentId and AED.RegistrationId=@RegistrationId and AED.WhetherActive=@WhetherActive";
            if (!string.IsNullOrEmpty(DocumentNo)) { Qry = Qry + " and DocumentNo=@DocumentNo"; }
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
            if (!string.IsNullOrEmpty(DocumentNo)) { Cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(DocumentNo.ToUpper())); }
            Cmd.Parameters.AddWithValue("@DocumentId", DocumentId);
            Cmd.Parameters.AddWithValue("@RegistrationId", RegId);
            DataTable dt = data.GetDataTable(Cmd);
            PreserveModelState(KeyName._Key02, DocumentId, false, true);
            if (dt.Rows.Count == 1)
            {
                model = ApplicantEnclosureDetails.Get<ApplicantEnclosureDetails>(new ApplicantEnclosureDetails(), Cmd);
                if (model != null)
                {
                    PreserveModelState(KeyName._Key02, DocumentId, false, true);
                    PreserveModelState(KeyName._Key03, model.EnclosureId, false, true);
                    return Json(model);
                }
                else { return null; }
            }
            else if (dt.Rows.Count > 1)
            {
                Qry = "select dbo.udf_general_decrypt(AED.DocumentNo) as DId,dbo.udf_general_decrypt(AED.DocumentNo) as DName from applicantenclosuredetails AED inner join DocumentMaster DM on DM.DocumentId=AED.DocumentId where AED.DocumentId=@DocumentId and AED.RegistrationId=@RegistrationId and AED.WhetherActive=@WhetherActive";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@DocumentId", DocumentId);
                Cmd.Parameters.AddWithValue("@RegistrationId", RegId);
                model.DocumentNoList = GetDropdown(Cmd);
                model.flag = true;
                return Json(model, JsonRequestBehavior.AllowGet);
            }
            else { return null; }
        }
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult SCSTSendSMS(string AppNo)
        {
            //send sms to applicant and insert record in table
            GetData objData = new GetData();
            string result = string.Empty;
            Dictionary<string, string> smsDic = new Dictionary<string, string>();
            smsDic.Add("ParamApplicationNo", AppNo);
            result = objData.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS029, smsDic)).ToString();
            return Json(result);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult SaveEnclosure(string EncId, string RefEncId, string ServerId, string DocTypeId, string DoccId, string ServiceId, string EncDeptId)
        {
            string Qry = string.Empty, ServiceCode = string.Empty, AppNoId = string.Empty, DocId = string.Empty, DeptId = string.Empty, WhetherVer = string.Empty;
            GetData data = new GetData();
            NpgsqlCommand Cmd = null;
            bool WhetherInsert = false, WhetherVerified = false, WhetherCompleted = false;

            bool rtnresult = Utility.CheckDocumentMapping(Convert.ToInt32(DocTypeId), Convert.ToInt32(DoccId), ServiceId, EncDeptId);
            if (rtnresult == false) { return Json(false); }

            if (ServerId == DB.LS.ToString())
            {
                AppNoId = Utility.SelectColumnsValue("dbo.applicationenclosuredetails", "ApplicationNo", "enclosureid", EncId.ToString())[0];

                Qry = "select DocumentId,DepartmentId,WhetherVerified from dbo.applicantenclosuredetails where enclosureid=@RefEnclosureId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RefEnclosureId", RefEncId);
                string[] getValue = data.SelectColumns(Cmd);
                DocId = getValue[0]; DeptId = getValue[1]; WhetherVer = getValue[2];
                if (WhetherVer.ToUpper() == CustomText.TRUE.ToString()) { WhetherVerified = true; }
            }
            else
            {
                AppNoId = Utility.SelectColumnsValue("web.applicationenclosuredetails", "ApplicationId", "enclosureid", EncId.ToString())[0];

                Qry = "select DocumentId,DepartmentId,WhetherVerified from dbo.applicantenclosuredetails where enclosureid=@RefEnclosureId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RefEnclosureId", RefEncId);
                string[] getValue = data.SelectColumns(Cmd);
                DocId = getValue[0]; DeptId = getValue[1]; WhetherVer = getValue[2];
                if (WhetherVer.ToUpper() == CustomText.TRUE.ToString()) { WhetherVerified = true; }
            }

            if (!string.IsNullOrEmpty(Utility.GetWhetherStopApplication(null, ServerId, DocId, DeptId, WhetherVer)))
            {
                return Json(false);
            }
            ServiceCode = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ServiceCode", "ApplicationNo", AppNoId.ToString())[0];

            if (ServerId == DB.LS.ToString()) { Qry = "update dbo.applicationenclosuredetails ANC set referenceenclosureid=ATC.enclosureid,documentid=ATC.documentid,departmentid=ATC.departmentid,otherdepartment=ATC.otherdepartment,documentno=ATC.documentno,contenttype=ATC.contenttype,documentdetails=ATC.documentdetails,whetherverified=ATC.whetherverified,whetheractive=ATC.whetheractive,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() from applicantenclosuredetails ATC where ATC.enclosureid=@RefEnclosureId and ANC.enclosureid=@TarEnclosureId"; }
            if (ServerId == DB.RS.ToString()) { Qry = "update web.applicationenclosuredetails ANC set referenceenclosureid=ATC.enclosureid,documentid=ATC.documentid,departmentid=ATC.departmentid,otherdepartment=ATC.otherdepartment,documentno=ATC.documentno,contenttype=ATC.contenttype,documentdetails=ATC.documentdetails,whetherverified=ATC.whetherverified,whetheractive=ATC.whetheractive,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() from applicantenclosuredetails ATC where ATC.enclosureid=@RefEnclosureId and ANC.enclosureid=@TarEnclosureId"; }
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@RefEnclosureId", RefEncId);
            Cmd.Parameters.AddWithValue("@TarEnclosureId", EncId);
            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
            if (ServerId == DB.LS.ToString())
            {
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
            }
            else
            {
                Cmd.Parameters.AddWithValue("@userid", Sessions.getCurrentUser().RegistrationId);
            }
            int InsertedRow = data.UpdateData(Cmd);
            if (InsertedRow > 0) { WhetherInsert = true; }
            string IsAllUpload = string.Empty;
            if (ServerId == DB.LS.ToString())
            {
                Qry = "select ApplicationNo from dbo.ApplicationEnclosureDetails AED inner join dbo.servicetodocumentmaster SDM on SDM.ServiceCode=AED.ServiceCode and AED.DocumentTypeId=SDM.DocumentTypeId  where SDM.Whetheroptional=false and  ApplicationNo=@ApplicationNo and DocumentData is null and AED.whethermandatory=TRUE and WhetherVerified=@WhetherVerified and AED.WhetherActive=@WhetherActive LIMIT 1";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", AppNoId);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.FALSE.ToString());
                Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.FALSE.ToString());
                IsAllUpload = data.SelectColumns(Cmd)[0];
            }
            else
            {
                Qry = "select ApplicationId from web.ApplicationEnclosureDetails AED inner join dbo.servicetodocumentmaster SDM on SDM.ServiceCode=AED.ServiceCode and AED.DocumentTypeId=SDM.DocumentTypeId  where SDM.Whetheroptional=false and  ApplicationId=@ApplicationId and DocumentData is null and AED.whethermandatory=TRUE and WhetherVerified=@WhetherVerified and AED.WhetherActive=@WhetherActive LIMIT 1";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationId", AppNoId);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.FALSE.ToString());
                Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.FALSE.ToString());
                IsAllUpload = data.SelectColumns(Cmd)[0];
            }
            if (string.IsNullOrEmpty(IsAllUpload))
            {
                WhetherCompleted = true;
            }
            var result = new { IsInsert = WhetherInsert, IsVerified = WhetherVerified, IsCompleted = WhetherCompleted };
            return Json(result);
        }
        public ActionResult FillSCSTCaste(string StateId)
        {
            string Qry = "select CM.CasteId as DId,CM.CasteName as DName from dbo.castemaster CM inner join dbo.statemaster SM on SM.stateid=CM.stateid where CM.whetheractive=TRUE and CM.stateid=@StateId and CM.servicecode=@ServiceCode order by Dname";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@StateId", StateId);
            Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.SCST);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillSTCaste(string StateId)
        {
            string Qry = "select CM.CasteId as DId,CM.CasteName as DName from dbo.castemaster CM inner join dbo.statemaster SM on SM.stateid=CM.stateid where CM.whetheractive=TRUE and CM.stateid=@StateId and CM.servicecode=@ServiceCode order by Dname";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@StateId", StateId);
            Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.ST);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillNTCaste(string StateId)
        {
            string Qry = "select CM.CasteId as DId,CM.CasteName as DName from dbo.castemaster CM inner join dbo.statemaster SM on SM.stateid=CM.stateid where CM.whetheractive=TRUE and CM.stateid=@StateId and CM.servicecode=@ServiceCode order by Dname";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@StateId", StateId);
            Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.NT);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillOBCCaste(string StateId)
        {
            string Qry = "select CM.CasteId as DId, CM.CasteName as Dname from dbo.castemaster CM inner join dbo.statemaster SM on SM.stateid=CM.stateid where CM.whetheractive=TRUE and SM.stateid=@StateId and CM.servicecode=@ServiceCode order by Dname";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@StateId", StateId);
            Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.OBC);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillOBCCentreCaste(string StateId)
        {
            string Qry = "select CM.CasteId as DId, CM.CasteName as Dname from dbo.castemaster CM inner join dbo.statemaster SM on SM.stateid=CM.stateid where CM.whetheractive=TRUE and SM.stateid=@StateId and CM.servicecode=@ServiceCode and CM.WhetherCentreCaste=@WhetherCentreCaste order by Dname";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@StateId", StateId);
            Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.OBC);
            Cmd.Parameters.AddWithValue("@WhetherCentreCaste", CustomText.True.ToString());
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillAllServiceCaste(string ServiceCode, string StateId, string WhetherCentreCaste)
        {
            string Qry = "select CM.CasteId as DId, CM.CasteName as Dname from dbo.castemaster CM inner join dbo.statemaster SM on SM.stateid=CM.stateid where CM.whetheractive=TRUE and SM.stateid=@StateId and CM.servicecode=@ServiceCode and CM.WhetherActive=@WhetherActive ";
            if (WhetherCentreCaste.ToUpper() == CustomText.TRUE.ToString()) { Qry += " and CM.WhetherCentreCaste=@WhetherCentreCaste "; }
            Qry += "  order by Dname ";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@StateId", StateId);
            Cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            Cmd.Parameters.AddWithValue("@WhetherCentreCaste", WhetherCentreCaste);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillFNMValueId()
        {
            string Qry = "select SMVD.valueid as DId,SMVD.valuename as DName from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by SMVD.valuename";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.FixedAndMoveableAssets);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillBankList()
        {
            string Qry = "select BankCode as DId,BankName as DName from dbo.BankMaster order by BankName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillDocumentId(string DocumentTypeId)
        {
            string Qry = "select case when DMS.DocumentId is null then 0 else DMS.DocumentId end as DId,case when DMS.DocumentName is null then DTM.DocumentTypeName else DMS.DocumentName end as DName from DocumentTypeMaster DTM left outer join dbo.DocumentToTypeMaster DTT on DTT.DocumentTypeId=DTM.DocumentTypeId left outer join DocumentMaster DMS on DMS.DocumentId=DTT.DocumentId where DTM.DocumentTypeId=@DocumentTypeId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DocumentTypeId", DocumentTypeId);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillDocNo(string DocumentId, string ApplicationNo)
        {
            GetData data = new GetData();
            ApplicantEnclosureDetails model = new ApplicantEnclosureDetails();
            string RID = Utility.SelectColumnsValue("dbo.ApplicationDetails", "RegistrationId", "ApplicationNo", ApplicationNo)[0];
            string Qry = "select dbo.udf_general_decrypt(DocumentNo) as DId,dbo.udf_general_decrypt(DocumentNo) as DName from dbo.applicantenclosuredetails where DocumentId=@DocumentId and RegistrationId=@RegistrationId and WhetherActive=@WhetherActive";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DocumentId", DocumentId);
            Cmd.Parameters.AddWithValue("@RegistrationId", RID);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
            DataTable dt = data.GetDataTable(Cmd);
            if (dt.Rows.Count == 0) { model.flag = false; }
            else { model.flag = true; model.DocumentNoList = GetDropdown(Cmd); }
            return Json(model, JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillDocNoDetails(string DocumentId, string DocumentNo, string ApplicationNo)
        {
            GetData data = new GetData();
            ApplicantEnclosureDetails model = new ApplicantEnclosureDetails();
            string RID = Utility.SelectColumnsValue("dbo.ApplicationDetails", "RegistrationId", "ApplicationNo", ApplicationNo)[0];
            //string Qry = "select EnclosureId, DepartmentId,OtherDepartment,dbo.udf_general_decrypt(DocumentNo) as DocumentNo,WhetherVerified,DocumentDetails from dbo.applicantenclosuredetails where DocumentId=@DocumentId and RegistrationId=@RegistrationId and dbo.udf_general_decrypt(DocumentNo)=@DocumentNo and WhetherActive=@WhetherActive LIMIT 1";
            string Qry = "select EnclosureId, DepartmentId,OtherDepartment,dbo.udf_general_decrypt(DocumentNo) as DocumentNo,WhetherVerified,DocumentDetails from dbo.applicantenclosuredetails where DocumentId=@DocumentId and RegistrationId=@RegistrationId and DocumentNo=@DocumentNo and WhetherActive=@WhetherActive LIMIT 1";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DocumentId", DocumentId);
            Cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(DocumentNo.ToUpper()));
            Cmd.Parameters.AddWithValue("@RegistrationId", RID);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
            DataTable dt = data.GetDataTable(Cmd);
            model.EnclosureId = Convert.ToInt32(dt.Rows[0]["EnclosureId"].ToString());
            model.DepartmentId = dt.Rows[0]["DepartmentId"].ToString();
            model.OtherDepartment = dt.Rows[0]["OtherDepartment"].ToString();
            model.DocumentNo = dt.Rows[0]["DocumentNo"].ToString();
            model.WhetherVerified = dt.Rows[0]["WhetherVerified"].ToString();
            model.DocumentDetails = dt.Rows[0]["DocumentDetails"].ToString();
            TempData[KeyName._Key03] = dt.Rows[0]["EnclosureId"].ToString();
            return Json(model, JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillTrainingCourse(string TrainingTypeId)
        {
            string Qry = "select CourseId as DId,CourseName as Dname from CourseMaster  where ValueId=@TrainingTypeId order by CourseName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@TrainingTypeId", TrainingTypeId);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillTrainingDuration(string TrainingTypeId)
        {
            string Qry = "select CourseId as DId,CourseName as Dname from CourseMaster  where ValueId=@TrainingTypeId order by CourseName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@TrainingTypeId", TrainingTypeId);

            List<SelectListItem> list = new List<SelectListItem>();
            if (TrainingTypeId != ((int)ValueId.BasicTraining).ToString())
            {
                for (int i = 0; i < 60; i++)
                {
                    list.Add(new SelectListItem() { Text = (i + 1).ToString(), Value = (i + 1).ToString() });
                }
            }
            else
            {
                for (int i = 8; i <= 8; i++)
                {
                    list.Add(new SelectListItem() { Text = (i).ToString(), Value = (i).ToString() });
                }
            }

            return Json(list, JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillCLDocList()
        {
            NpgsqlCommand Cmd = new NpgsqlCommand("select DocumentId as DId,DocumentName as DName from dbo.DocumentMaster where DocumentId in (@DrivingLicense,@VoterID,@PANCard,@Passport,@RationCard,@StudentId,@Birth)");
            Cmd.Parameters.AddWithValue("@DrivingLicense", (int)DocumentId.DrivingLicense);
            Cmd.Parameters.AddWithValue("@VoterID", (int)DocumentId.VoterID);
            Cmd.Parameters.AddWithValue("@PANCard", (int)DocumentId.PANCard);
            Cmd.Parameters.AddWithValue("@Passport", (int)DocumentId.Passport);
            Cmd.Parameters.AddWithValue("@RationCard", (int)DocumentId.RationCard);
            Cmd.Parameters.AddWithValue("@StudentId", (int)DocumentId.StudentId);
            Cmd.Parameters.AddWithValue("@Birth", (int)DocumentId.BirthCertificate);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult CheckUserId(string UserId)
        {
            bool flag = false;
            GetData data = new GetData();
            string Qry = "select UserId from dbo.usermaster where userid=@userid";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@userid", UserId);
            string WhetheruseridExist = data.SelectColumns(Cmd)[0];
            if (!string.IsNullOrEmpty(WhetheruseridExist))
            {
                flag = true;
            }
            return Json(flag);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult AddLocality(string localityname, string landmark, string pincode)
        {
            bool result = false;
            if (string.IsNullOrEmpty(localityname) || string.IsNullOrEmpty(landmark))
            {
                result = false;
                return Json(result);
            }
            GetData data = new GetData();
            string Qry = "select LocalityName from dbo.newlocalitydetails where lower(LocalityName) like lower(@LocalityName) and lower(landmark) like lower(@landmark)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@LocalityName", string.Format("%{0}%", localityname));
            Cmd.Parameters.AddWithValue("@landmark", string.Format("%{0}%", landmark));
            string check = data.SelectColumns(Cmd)[0];
            if (string.IsNullOrEmpty(check))
            {
                Qry = "insert into dbo.newlocalitydetails(localityname,landmark,pincode,UserId,IpAddress) values(@localityname,@landmark,@pincode,@UserId,@IpAddress) ";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@localityname", localityname);
                Cmd.Parameters.AddWithValue("@landmark", landmark);
                Cmd.Parameters.AddWithValue("@pincode", pincode);
                Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                if (Sessions.getCurrentUser() != null)
                {
                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getCurrentUser().RegistrationId);
                }
                else if (Sessions.getEmployeeUser() != null)
                {
                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                }
                else
                {
                    Cmd.Parameters.AddWithValue("@UserId", "CITIZEN");
                }
                int rowInserted = data.UpdateData(Cmd);

                if (rowInserted > 0)
                {
                    result = true;
                }
            }
            else { result = false; }
            return Json(result);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult PopulateAtCSC(string aadhaarno)
        {
            GetData data = new GetData();
            string qry = @"select dbo.udf_general_decrypt(aadhaarno) as aadhaarno,applicantname,applicantgender,applicantfathername,to_char(applicantdob,'DD/MM/YYYY') as ApplicantDob,applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantstateid,applicantcountryid,aadharapplicantpincode,applicantpincode,applicantlocalityid,applicantmobileno,applicantemail,applicantdistrictcode,applicantsubdivcode,applicantmothername,applicantspousename from web.registrationmaster where dbo.udf_general_decrypt(AadhaarNo)=@AadhaarNo";
            NpgsqlCommand Cmd = new NpgsqlCommand(qry);
            Cmd.Parameters.AddWithValue("@AadhaarNo", aadhaarno);
            RegistrationMaster model = RegistrationMaster.Get<RegistrationMaster>(new RegistrationMaster(), Cmd);
            if (model == null) { return null; }
            return Json(model);
        }
        [AllowAnonymous]
        public JsonResult PieChart()
        {
            GetData data = new GetData();
            List<PieChartValues> PieChartValues = new List<PieChartValues>();
            DataTable dt = new DataTable();

            StringBuilder Qry = new StringBuilder(@"select field1 as ""RegisteredUsers"",field2 as  ""ApplicationsReceived"",field3 as ""CertificatesDownloaded"" from staticdatamaster  where StableId=@StableId");
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry.ToString());
            Cmd.Parameters.AddWithValue("@StableId", ((int)StaticTableMaster.GraphReportForHomePage));
            dt = data.GetDataTable(Cmd);
            if (dt.Rows.Count > 0)
            {
                PieChartValues.Add(new PieChartValues { Name = "Registered Users", Value = Convert.ToInt32(dt.Rows[0]["RegisteredUsers"]) });
                PieChartValues.Add(new PieChartValues { Name = "Applications Received", Value = Convert.ToInt32(dt.Rows[0]["ApplicationsReceived"]) });
                PieChartValues.Add(new PieChartValues { Name = "Certificates Downloaded", Value = Convert.ToInt32(dt.Rows[0]["CertificatesDownloaded"]) });
            }
            return Json(PieChartValues, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetAllLocality()
        {
            //used for department purpose only
            string Qry = "select LM.LocalityId as DId,LM.LocalityName as Dname from LocalityMaster LM inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join dbo.SubDivMaster SD on SD.SubDivCode=LS.SubDivCode inner join dbo.DistrictMaster DM on DM.DistrictCode=SD.DistrictCode where DM.deptcode=@deptcode and DM.StateId=@StateId and LS.whetheractive=@whetheractive order by LM.LocalityName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
            Cmd.Parameters.AddWithValue("@StateId", (int)State.Delhi);
            Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetOtherStateLocality()
        {
            //used for department purpose only
            string Qry = "select LM.LocalityId as DId,LM.LocalityName as Dname from LocalityMaster LM inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join dbo.SubDivMaster SD on SD.SubDivCode=LS.SubDivCode inner join dbo.DistrictMaster DM on DM.DistrictCode=SD.DistrictCode where DM.deptcode=@deptcode and DM.StateId <> @StateId and ls.whetheractive=@whetheractive order by LM.LocalityName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
            Cmd.Parameters.AddWithValue("@StateId", (int)State.Delhi);
            Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        [AllowAnonymous]
        public JsonResult ReceivedSmsCount()
        {
            GetData data = new GetData();
            List<PieChartValues> SmsCountValues = new List<PieChartValues>();
            DataTable dt = new DataTable();
            StringBuilder Qry = new StringBuilder(@"select field1 as SentSms from staticdatamaster where StableId=@StableId");
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry.ToString());
            Cmd.Parameters.AddWithValue("@StableId", ((int)StaticTableMaster.SMSCountForHomePage));
            dt = data.GetDataTable(Cmd);
            if (dt.Rows.Count > 0)
            {
                foreach (DataColumn dc in dt.Columns)
                {

                    SmsCountValues.Add(new PieChartValues { Value = Convert.ToInt32(dt.Rows[0][dc.ColumnName.ToString()]) });
                }
            }
            return Json(SmsCountValues, JsonRequestBehavior.AllowGet);
        }
        [AllowAnonymous]
        public JsonResult LoggedInUsers()
        {
            GetData data = new GetData();
            List<PieChartValues> LoggedInUserValues = new List<PieChartValues>();
            DataTable dt = new DataTable();
            StringBuilder Qry = new StringBuilder(@"select count(userid) as LoggedInUser from useronlinedetails ");
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry.ToString());
            dt = data.GetDataTable(Cmd);
            if (dt.Rows.Count > 0)
            {
                foreach (DataColumn dc in dt.Columns)
                {

                    LoggedInUserValues.Add(new PieChartValues { Value = Convert.ToInt32(dt.Rows[0][dc.ColumnName.ToString()]) });
                }
            }
            return Json(LoggedInUserValues, JsonRequestBehavior.AllowGet);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetFilledDocument(string ApplicationNo, string ApplicantDOB)
        {
            string ApplicantDocumentName = string.Empty;
            GetData objData = new GetData();
            DataTable dt1 = null;
            DataTable dt2 = null;

            string Qry = "select RegistrationId from ApplicationDetails where ApplicationNo=@ApplicationNo and to_char(ApplicantDOB,'YYYYMMDD')::date=@ApplicantDOB";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", ApplicationNo);
            Cmd.Parameters.AddWithValue("@ApplicantDOB", Utility.ConvertDateSequenceForDatabase(ApplicantDOB, '/', true));
            DataTable dt = objData.GetDataTable(Cmd);

            if (dt.Rows.Count > 0)
            {
                Qry = "select DocumentId from web.RegistrationMaster where RegistrationId=@RegistrationId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RegistrationId", dt.Rows[0]["RegistrationId"].ToString());
                dt1 = objData.GetDataTable(Cmd);
                if (dt1.Rows.Count > 0)
                {
                    Qry = "select DocumentName from DocumentMaster where DocumentId=@DocumentId";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@DocumentId", dt1.Rows[0]["DocumentId"].ToString());
                    dt2 = objData.GetDataTable(Cmd);
                }

            }
            string code = string.Empty;
            if (dt2 != null && dt2.Rows.Count > 0)
            {
                ApplicantDocumentName = dt2.Rows[0]["DocumentName"].ToString();
            }

            return Json(ApplicantDocumentName);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult EditIncomeSalary(string AppNo, string NewSalary)
        {
            GetData data = new GetData();
            string Qry = "update drev.ApplicationDetailsIncome set AnnualIncome=@AnnualIncome where ApplicationNo=@ApplicationNo";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@AnnualIncome", NewSalary);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            int insertedRow = data.UpdateData(Cmd);
            if (insertedRow > 0)
            {
                data.UpdateData(Utility.InsertDepartmentAuditTrail(AppNo, (int)ApplicationHistoryMessage.MSG026, null, (int)ApplicationSource.Window, null));
                return Json(true);
            }
            return Json(false);
        }
        public JsonResult FillColumnList(string TableId)
        {
            string TableName = Utility.SelectColumnsValue("dbo.MasterTableMaster", "tablename", "tableid", TableId)[0].ToLower();
            string Qry = "select column_name as DId,column_name as Dname from information_schema.columns WHERE table_schema='dbo' AND table_name=@TableName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@TableName", TableName);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        [AllowAnonymous]
        public JsonResult FillSubCourt(string CourtId)
        {
            return Json(WebService.FillSubCourtList(CourtId), JsonRequestBehavior.AllowGet);
        }
        public JsonResult FillSubDiv(string DistrictCode)
        {
            if (DistrictCode == ((int)State.Delhi).ToString())
            {
                string Qry = "select DM.districtcode, SDM.Subdivcode as DId,SDM.SubDivdescription as Dname from dbo.Subdivmaster SDM inner join dbo.districtmaster DM on DM.districtcode=SDM.districtcode inner join statemaster sm on sm.stateid=DM.stateid where DM.deptcode=@deptcode and sm.stateid=@stateid order by SDM.SubDivdescription";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
            }
            else
            {
                string Qry = "select DM.districtcode, SDM.Subdivcode as DId,SDM.SubDivdescription as Dname from dbo.Subdivmaster SDM inner join dbo.districtmaster DM on DM.districtcode=SDM.districtcode inner join statemaster sm on sm.stateid=DM.stateid where DM.deptcode=@deptcode and sm.stateid<>@stateid order by SDM.SubDivdescription";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
            }
        }
        [AllowAnonymous]
        public JsonResult FillLocality(string WhetherOtherState)
        {
            //used for birth service only
            if (WhetherOtherState == ((int)State.Delhi).ToString())
            {
                string Qry = "select DM.districtcode,LM.LocalityId as DId,LM.LocalityName as Dname from dbo.LocalityMaster LM inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join dbo.subdivmaster SDM on SDM.subdivcode=LS.subdivcode inner join dbo.districtmaster DM on DM.districtcode=SDM.districtcode inner join statemaster sm on sm.stateid=DM.stateid where DM.deptcode=@deptcode and sm.stateid=@stateid and ls.whetheractive=@whetheractive order by LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
            }
            else
            {
                string Qry = "select DM.districtcode,LM.LocalityId as DId,LM.LocalityName as Dname from dbo.LocalityMaster LM inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join dbo.subdivmaster SDM on SDM.subdivcode=LS.subdivcode inner join dbo.districtmaster DM on DM.districtcode=SDM.districtcode inner join statemaster sm on sm.stateid=DM.stateid where DM.deptcode=@deptcode and sm.stateid<>@stateid and ls.whetheractive=@whetheractive order by LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult FillLanguageList()
        {
            string Qry = "select SMVD.valueid as DId,SMVD.valuename as DName from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.LanguageKnown);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillTQualificationList()
        {
            string Qry = "select SMVD.valueid as DId,SMVD.valuename as DName from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.TechnicalQualification);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillStateWiseDistrict(string StateId)
        {
            string Qry = "select DistrictCode as DId,DistrictName as DName from dbo.DistrictMaster where StateId=@StateId order by DistrictName ";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@StateId", StateId);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        [AllowAnonymous]
        public ActionResult FillGeneralCaste(string StateId, string ServiceCode, string WhetherCenter)
        {
            string WC = string.Empty;
            if (!string.IsNullOrEmpty(WhetherCenter) && WhetherCenter != ((int)CountList.Type000).ToString()) { WC = " and WhetherCentreCaste=@WhetherCentre "; }
            string Qry = "select CM.CasteId as DId, CM.CasteName as Dname from dbo.castemaster CM inner join dbo.statemaster SM on SM.stateid=CM.stateid where CM.whetheractive=TRUE and SM.stateid=@StateId and CM.servicecode=@ServiceCode " + WC + " order by Dname";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@StateId", StateId);
            Cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            if (!string.IsNullOrEmpty(WhetherCenter) && WhetherCenter != ((int)CountList.Type000).ToString()) { Cmd.Parameters.AddWithValue("@WhetherCentre", WhetherCenter); }
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult FillVenuAddress(string VenuId)
        {
            GetData objData = new GetData();
            VenueMaster model = new VenueMaster();
            string Qry = "select VenueId as DId,VenueAddress as Dname from VenueMaster  where VenueId=@VenueId order by VenueAddress";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@VenueId", VenuId);
            DataTable dt = objData.GetDataTable(Cmd);
            if (dt != null && dt.Rows.Count > 0)
            {
                model.VenueAddress = dt.Rows[0]["Dname"].ToString();
            }
            return Json(model);
        }        
        [AllowAnonymous]
        public JsonResult DisposalPieChart(Int32 servicecode, Int32 distcode, Int32 flag)
        {
            GetData data = new GetData();
            List<PieChartReports> PieChartReports = new List<PieChartReports>();
            DataTable dt = new DataTable();
            if (flag == 1)
            {

                string Qry = @"select coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays<1 then 1 end),0) as ""Disposed In Time"",coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>0 and AD.sladays<=10 then 1 end),0) as ""SLA 10+ Days"",coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>10 and AD.sladays<=20 then 1 end),0) as ""SLA 20+ Days"",coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>20 then 1 end),0) as ""SLA 30+ Days"" from (select applicationno,AD.ApplicationStatusId,DM.DistrictCode,DM.DistrictName,SDM.subdivcode,SDM.SubDivDescription,SM.oldprocessingdays,SM.processingdays,DATE_PART('day',AD.signeddate-AD.applicationdate) as diifdays,DATE_PART('day',AD.signeddate-AD.applicationdate)-(case when AD.applicationdate<'2015-12-01' then SM.oldprocessingdays else SM.processingdays end) as sladays from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode inner join SubDivMaster SDM on SDM.SubDivCode=AD.SubDivCode where DM.deptcode=@ParamDeptCode";
                if (servicecode != 0) { Qry = Qry + " and AD.servicecode=@servicecode "; }
                Qry = Qry + " ) AD";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@statusid", ((int)Status.ISSUCER));
                if (servicecode != 0) { Cmd.Parameters.AddWithValue("@servicecode", servicecode); }
                dt = data.GetDataTable(Cmd);
                if (dt.Rows.Count > 0)
                {
                    foreach (DataColumn dc in dt.Columns)
                    {

                        PieChartReports.Add(new PieChartReports { Name = dc.ColumnName.ToString(), Value = Convert.ToInt32(dt.Rows[0][dc.ColumnName.ToString()]) });
                    }
                }
            }
            if (flag == 2)
            {
                string Qry = @"select DistrictCode,DistrictName,coalesce(count(AD.ApplicationNo),0) TotalReceived,coalesce(sum(case when AD.applicationstatusid=@statusid then 1 end),0) as TotalDisposed,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays<1 then 1 end),0) as DisposedInTime,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>0 and AD.sladays<=10 then 1 end),0) as sla10days,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>10 and AD.sladays<=20 then 1 end),0) as sla20days,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>20 then 1 end),0) as sla30days from (select applicationno,AD.ApplicationStatusId,DM.DistrictCode,DM.DistrictName,SDM.subdivcode,SDM.SubDivDescription,SM.oldprocessingdays,SM.processingdays,DATE_PART('day',AD.signeddate-AD.applicationdate) as diifdays,DATE_PART('day',AD.signeddate-AD.applicationdate)-(case when AD.applicationdate<'2015-12-01' then SM.oldprocessingdays else SM.processingdays end) as sladays from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode inner join SubDivMaster SDM on SDM.SubDivCode=AD.SubDivCode where DM.deptcode=@ParamDeptCode";
                if (servicecode != 0) { Qry = Qry + " and AD.servicecode=@servicecode "; }
                if (distcode != 0) { Qry = Qry + " and AD.districtcode=@districtcode "; }
                Qry += " ) AD group by DistrictCode,DistrictName order by DistrictName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@statusid", ((int)Status.ISSUCER));
                if (servicecode != 0) { Cmd.Parameters.AddWithValue("@servicecode", servicecode); }
                if (distcode != 0) { Cmd.Parameters.AddWithValue("@districtcode", distcode); }
                dt = data.GetDataTable(Cmd);
                if (dt.Rows.Count > 0)
                {
                    PieChartReports.Add(new PieChartReports { VarName = dt.Rows[0]["DistrictName"].ToString(), VarCode = Convert.ToInt32(dt.Rows[0]["DistrictCode"]), Name = "Disposed In Time", Value = Convert.ToInt32(dt.Rows[0]["DisposedInTime"]) });
                    PieChartReports.Add(new PieChartReports { VarName = dt.Rows[0]["DistrictName"].ToString(), VarCode = Convert.ToInt32(dt.Rows[0]["DistrictCode"]), Name = "SLA 10+ Days", Value = Convert.ToInt32(dt.Rows[0]["SLA10Days"]) });
                    PieChartReports.Add(new PieChartReports { VarName = dt.Rows[0]["DistrictName"].ToString(), VarCode = Convert.ToInt32(dt.Rows[0]["DistrictCode"]), Name = "SLA 20+ Days", Value = Convert.ToInt32(dt.Rows[0]["SLA20Days"]) });
                    PieChartReports.Add(new PieChartReports { VarName = dt.Rows[0]["DistrictName"].ToString(), VarCode = Convert.ToInt32(dt.Rows[0]["DistrictCode"]), Name = "SLA 30+ Days", Value = Convert.ToInt32(dt.Rows[0]["SLA30Days"]) });
                }
            }
            if (flag == 3)
            {
                string Qry = @"select SubDivCode,SubDivDescription,coalesce(count(AD.ApplicationNo),0) TotalReceived,coalesce(sum(case when AD.applicationstatusid=@statusid then 1 end),0) as TotalDisposed,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays<1 then 1 end),0) as DisposedInTime,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>0 and AD.sladays<=10 then 1 end),0) as sla10days,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>10 and AD.sladays<=20 then 1 end),0) as sla20days,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>20 then 1 end),0) as sla30days from (select applicationno,AD.ApplicationStatusId,DM.DistrictCode,DM.DistrictName,SDM.subdivcode,SDM.SubDivDescription,SM.oldprocessingdays,SM.processingdays,DATE_PART('day',AD.signeddate-AD.applicationdate) as diifdays,DATE_PART('day',AD.signeddate-AD.applicationdate)-(case when AD.applicationdate<'2015-12-01' then SM.oldprocessingdays else SM.processingdays end) as sladays from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode inner join SubDivMaster SDM on SDM.SubDivCode=AD.SubDivCode where DM.deptcode=@ParamDeptCode";
                if (servicecode != 0) { Qry = Qry + " and AD.servicecode=@servicecode "; }
                if (distcode != 0) { Qry = Qry + " and AD.districtcode=@districtcode "; }
                Qry += " ) AD group by SubDivCode,SubDivDescription order by SubDivDescription";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@statusid", ((int)Status.ISSUCER));
                if (servicecode != 0) { Cmd.Parameters.AddWithValue("@servicecode", servicecode); }
                if (distcode != 0) { Cmd.Parameters.AddWithValue("@districtcode", distcode); }
                dt = data.GetDataTable(Cmd);

                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        PieChartReports.Add(new PieChartReports { VarName = dt.Rows[i]["SubDivDescription"].ToString(), VarCode = Convert.ToInt32(dt.Rows[i]["SubDivCode"]), Name = "Disposed In Time", Value = Convert.ToInt32(dt.Rows[i]["DisposedInTime"]) });
                        PieChartReports.Add(new PieChartReports { VarName = dt.Rows[i]["SubDivDescription"].ToString(), VarCode = Convert.ToInt32(dt.Rows[i]["SubDivCode"]), Name = "SLA 10+ Days", Value = Convert.ToInt32(dt.Rows[i]["SLA10Days"]) });
                        PieChartReports.Add(new PieChartReports { VarName = dt.Rows[i]["SubDivDescription"].ToString(), VarCode = Convert.ToInt32(dt.Rows[i]["SubDivCode"]), Name = "SLA 20+ Days", Value = Convert.ToInt32(dt.Rows[i]["SLA20Days"]) });
                        PieChartReports.Add(new PieChartReports { VarName = dt.Rows[i]["SubDivDescription"].ToString(), VarCode = Convert.ToInt32(dt.Rows[i]["SubDivCode"]), Name = "SLA 30+ Days", Value = Convert.ToInt32(dt.Rows[i]["SLA30Days"]) });
                    }
                }

            }
            return Json(PieChartReports, JsonRequestBehavior.AllowGet);
        }
        [AllowAnonymous]
        public JsonResult PendingApplicationPieChart(Int32 servicecode, Int32 distcode, Int32 flag)
        {
            GetData data = new GetData();
            List<PieChartReports> PieChartReports = new List<PieChartReports>();
            DataTable dt = new DataTable();
            if (flag == 1)
            {
                string Qry = @"SELECT coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid in (@GreenZone,@YellowZone,@RedZone) then 1 end),0) as ""Pending In Time"",sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays <= 10 then 1 else 0 end) as ""SLA 10+ Days"",sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays >10 and AD.sladays <= 20 then 1 else 0 end) as ""SLA 20+ Days"",sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays >20 then 1 else 0 end) as ""SLA 30+ Days"" from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode inner join SubDivMaster SDM on SDM.SubDivCode=AD.SubDivCode where DM.deptcode=@ParamDeptCode";
                if (servicecode != 0) { Qry = Qry + " and AD.servicecode=@servicecode "; }
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@CANCEL", ((int)Status.CANCEL));
                Cmd.Parameters.AddWithValue("@TEHSREJ", ((int)Status.TEHSREJ));
                Cmd.Parameters.AddWithValue("@ISSUCER", ((int)Status.ISSUCER));
                Cmd.Parameters.AddWithValue("@GreenZone", ((int)ValueId.GreenZone));
                Cmd.Parameters.AddWithValue("@YellowZone", ((int)ValueId.YellowZone));
                Cmd.Parameters.AddWithValue("@RedZone", ((int)ValueId.RedZone));
                if (servicecode != 0) { Cmd.Parameters.AddWithValue("@servicecode", servicecode); }
                dt = data.GetDataTable(Cmd);
                if (dt.Rows.Count > 0)
                {
                    foreach (DataColumn dc in dt.Columns)
                    {

                        PieChartReports.Add(new PieChartReports { Name = dc.ColumnName.ToString(), Value = Convert.ToInt32(dt.Rows[0][dc.ColumnName.ToString()]) });
                    }
                }
            }
            if (flag == 2)
            {
                string Qry = @"select AD.DistrictCode,DistrictName,coalesce(count(AD.ApplicationNo),0) TotalReceived,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) then 1 end),0) as TotalPending,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid in (@GreenZone,@YellowZone,@RedZone) then 1 end),0) as Pendingintime,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays <= 10 then 1 else 0 end) as sla10days,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays >10 and AD.sladays <= 20 then 1 else 0 end) as sla20days,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays >20 then 1 else 0 end) as sla30days from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode inner join SubDivMaster SDM on SDM.SubDivCode=AD.SubDivCode where DM.deptcode=@ParamDeptCode";
                if (servicecode != 0) { Qry = Qry + " and AD.servicecode=@servicecode "; }
                if (distcode != 0) { Qry = Qry + " and AD.DistrictCode=@districtcode "; }
                Qry += " group by AD.DistrictCode,DistrictName order by DistrictName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@CANCEL", ((int)Status.CANCEL));
                Cmd.Parameters.AddWithValue("@TEHSREJ", ((int)Status.TEHSREJ));
                Cmd.Parameters.AddWithValue("@ISSUCER", ((int)Status.ISSUCER));
                Cmd.Parameters.AddWithValue("@GreenZone", ((int)ValueId.GreenZone));
                Cmd.Parameters.AddWithValue("@YellowZone", ((int)ValueId.YellowZone));
                Cmd.Parameters.AddWithValue("@RedZone", ((int)ValueId.RedZone));
                if (servicecode != 0) { Cmd.Parameters.AddWithValue("@servicecode", servicecode); }
                if (distcode != 0) { Cmd.Parameters.AddWithValue("@districtcode", distcode); }
                dt = data.GetDataTable(Cmd);
                if (dt.Rows.Count > 0)
                {
                    PieChartReports.Add(new PieChartReports { VarName = dt.Rows[0]["DistrictName"].ToString(), VarCode = Convert.ToInt32(dt.Rows[0]["DistrictCode"]), Name = "Pending In Time", Value = Convert.ToInt32(dt.Rows[0]["PendingInTime"]) });
                    PieChartReports.Add(new PieChartReports { VarName = dt.Rows[0]["DistrictName"].ToString(), VarCode = Convert.ToInt32(dt.Rows[0]["DistrictCode"]), Name = "SLA 10+ Days", Value = Convert.ToInt32(dt.Rows[0]["SLA10Days"]) });
                    PieChartReports.Add(new PieChartReports { VarName = dt.Rows[0]["DistrictName"].ToString(), VarCode = Convert.ToInt32(dt.Rows[0]["DistrictCode"]), Name = "SLA 20+ Days", Value = Convert.ToInt32(dt.Rows[0]["SLA20Days"]) });
                    PieChartReports.Add(new PieChartReports { VarName = dt.Rows[0]["DistrictName"].ToString(), VarCode = Convert.ToInt32(dt.Rows[0]["DistrictCode"]), Name = "SLA 30+ Days", Value = Convert.ToInt32(dt.Rows[0]["SLA30Days"]) });
                }
            }
            if (flag == 3)
            {
                string Qry = @"select AD.SubDivCode,SubDivDescription,coalesce(count(AD.ApplicationNo),0) TotalReceived,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) then 1 end),0) as TotalPending,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid in (@GreenZone,@YellowZone,@RedZone) then 1 end),0) as Pendingintime,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays <= 10 then 1 else 0 end) as sla10days,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays >10 and AD.sladays <= 20 then 1 else 0 end) as sla20days,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays >20 then 1 else 0 end) as sla30days from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode inner join SubDivMaster SDM on SDM.SubDivCode=AD.SubDivCode where DM.deptcode=@ParamDeptCode";
                if (servicecode != 0) { Qry = Qry + " and AD.servicecode=@servicecode "; }
                if (distcode != 0) { Qry = Qry + " and AD.DistrictCode=@districtcode "; }
                Qry += " group by AD.SubDivCode,SubDivDescription order by SubDivDescription";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@CANCEL", ((int)Status.CANCEL));
                Cmd.Parameters.AddWithValue("@TEHSREJ", ((int)Status.TEHSREJ));
                Cmd.Parameters.AddWithValue("@ISSUCER", ((int)Status.ISSUCER));
                Cmd.Parameters.AddWithValue("@GreenZone", ((int)ValueId.GreenZone));
                Cmd.Parameters.AddWithValue("@YellowZone", ((int)ValueId.YellowZone));
                Cmd.Parameters.AddWithValue("@RedZone", ((int)ValueId.RedZone));
                if (servicecode != 0) { Cmd.Parameters.AddWithValue("@servicecode", servicecode); }
                if (distcode != 0) { Cmd.Parameters.AddWithValue("@districtcode", distcode); }
                dt = data.GetDataTable(Cmd);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        PieChartReports.Add(new PieChartReports { VarName = dt.Rows[i]["SubDivDescription"].ToString(), VarCode = Convert.ToInt32(dt.Rows[i]["SubDivCode"]), Name = "Pending In Time", Value = Convert.ToInt32(dt.Rows[i]["PendingInTime"]) });
                        PieChartReports.Add(new PieChartReports { VarName = dt.Rows[i]["SubDivDescription"].ToString(), VarCode = Convert.ToInt32(dt.Rows[i]["SubDivCode"]), Name = "SLA 10+ Days", Value = Convert.ToInt32(dt.Rows[i]["SLA10Days"]) });
                        PieChartReports.Add(new PieChartReports { VarName = dt.Rows[i]["SubDivDescription"].ToString(), VarCode = Convert.ToInt32(dt.Rows[i]["SubDivCode"]), Name = "SLA 20+ Days", Value = Convert.ToInt32(dt.Rows[i]["SLA20Days"]) });
                        PieChartReports.Add(new PieChartReports { VarName = dt.Rows[i]["SubDivDescription"].ToString(), VarCode = Convert.ToInt32(dt.Rows[i]["SubDivCode"]), Name = "SLA 30+ Days", Value = Convert.ToInt32(dt.Rows[i]["SLA30Days"]) });
                    }
                }
            }


            return Json(PieChartReports, JsonRequestBehavior.AllowGet);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult ResendSMS(string Value, string ValueType)
        {
            bool IsSuccess = true;
            GetData data = new GetData();
            string[] arr = Value.Split(',');
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

            try
            {
                if (ValueType == ((int)CountList.Type001).ToString())
                {
                    if (arr[0] == DB.RS.ToString())
                    {
                        string Otp = Utility.GetRandomString(5, 3);
                        string Qry = "select ApplicantMobileNo,ApplicantEmail from web.RegistrationMaster where RegistrationId=@RegistrationId";
                        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@RegistrationId", arr[3].ToString());
                        string[] values = data.SelectColumns(Cmd);
                        string MobileNo = values[0];
                        string ApplicantEmail = values[1];

                        Dictionary<string, string> smsDic = new Dictionary<string, string>();
                        smsDic.Add("ParamOTP", Otp);
                        smsDic.Add("ParamMobileNo", MobileNo);
                        data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS009, smsDic));

                        if (!string.IsNullOrEmpty(ApplicantEmail))
                        {
                            Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                            EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                            EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS009).ToString());
                            EmailDic.Add("ParamOTP", Otp);
                            EmailDic.Add("ParamEmailId", ApplicantEmail);
                            NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                            if (EmailCmd != null) { data.UpdateData(EmailCmd); }
                        }

                        TempData[KeyName._Key03] = Otp + "|" + arr[3].ToString() + "|" + arr[0].ToString();
                    }
                    else if (arr[0] == DB.LS.ToString())
                    {
                        string Qry = "select contactno from dbo.usermaster where UserId=@UserId";
                        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@UserId", arr[1].ToString());
                        string MobileNo = data.SelectColumns(Cmd)[0];
                        string Otp = Utility.GetRandomString(5, 3);

                        Dictionary<string, string> smsDic = new Dictionary<string, string>();
                        smsDic.Add("ParamOTP", Otp);
                        smsDic.Add("ParamMobileNo", MobileNo);
                        data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS009, smsDic));

                        TempData[KeyName._Key03] = Otp + "|" + arr[1].ToString() + "|" + arr[0].ToString();
                    }
                }
                else if (ValueType == ((int)CountList.Type002).ToString())
                {
                    //string Qry = "select RegistrationId from web.RegistrationMaster where ApplicantMobileNo=@ApplicantMobileNo and to_char(ApplicantDOB,'DD/MM/YYYY')=@ApplicantDOB and dbo.udf_general_decrypt(DocumentNo)=@DocumentNo";
                    string Qry = "select RegistrationId from web.RegistrationMaster where DocumentNo=@DocumentNo and ApplicantMobileNo=@ApplicantMobileNo and to_char(ApplicantDOB,'DD/MM/YYYY')=@ApplicantDOB";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicantMobileNo", arr[0].ToString());
                    Cmd.Parameters.AddWithValue("@ApplicantDOB", arr[1].ToString());
                    Cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(arr[2].ToString().ToUpper()));
                    string RegistrationId = data.SelectColumns(Cmd)[0];

                    string Otp = Utility.GetRandomString(5, 3);

                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamOTP", Otp);
                    smsDic.Add("ParamMobileNo", arr[0].ToString());
                    data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS012, smsDic));

                    TempData[KeyName._Key03] = Otp + "|" + RegistrationId + "|" + null;
                }
                else if (ValueType == ((int)CountList.Type003).ToString())
                {
                    string Qry = "select AD.ApplicantMobileNo FROM dbo.ApplicationDetails AD inner join web.RegistrationMaster RM on RM.RegistrationId=AD.RegistrationId  where AD.applicationstatusid=@applicationstatusid and AD.ApplicationNo=@ApplicationNo";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", arr[0].ToString());
                    Cmd.Parameters.AddWithValue("@applicationstatusid", ((int)Status.ISSUCER).ToString());
                    string MobileNo = data.SelectColumns(Cmd)[0];

                    string SimpleOTP = Utility.GetRandomString(6, 1);

                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamOTP", SimpleOTP);
                    smsDic.Add("ParamMobileNo", MobileNo);
                    data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS013, smsDic));

                    PreserveModelState(KeyName._Key08, SimpleOTP, true, false);

                }
                else if (ValueType == ((int)CountList.Type004).ToString())
                {
                    int count = 0;
                    if (TempData[KeyName._Key08] == null) { count = 0; } else { count = Convert.ToInt32(TempData[KeyName._Key08]); }
                    
                    if (count < 3)
                    {
                        string AccessCode = Utility.GetRandomString(5, 1);
                        string SimplePassword = Utility.GetRandomString(8, 3);
                        string HashPassword = Utility.GenerateSHA512(SimplePassword).ToString().ToLower();
                        string str = string.Empty;
                        if (TempData[KeyName._Key09] != null)
                        {
                            str = TempData[KeyName._Key09].ToString();
                            string[] Val = str.Split(',');
                            arr[0] = Val[0];
                            arr[1] = Val[1];
                        }

                        Dictionary<string, string> smsDic = new Dictionary<string, string>();
                        smsDic.Add("ParamAccessCode", AccessCode);
                        smsDic.Add("ParamPassword", SimplePassword);
                        smsDic.Add("ParamMobileNo", arr[0].ToString());
                        data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS008, smsDic));

                        string Qry = "update web.RegistrationMasterTemp set ApplicantAccessCode=@ApplicantAccessCode,ApplicantPassword=@ApplicantPassword where DocumentNo=@DocumentNo";
                        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicantAccessCode", AccessCode);
                        Cmd.Parameters.AddWithValue("@ApplicantPassword", HashPassword);
                        Cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(arr[1].ToString().ToUpper()));
                        data.UpdateData(Cmd);
                        
                        count++;
                        PreserveModelState(KeyName._Key08, count.ToString(), false, true);
                        PreserveModelState(KeyName._Key09, str, false, true);
                    }
                    else
                    {
                        PreserveModelState(KeyName._Key08, null, true, false);
                        IsSuccess = false;
                    }
                }
                else if (ValueType == ((int)CountList.Type005).ToString())
                {
                    string Qry = "select AD.ApplicantMobileNo FROM dbo.ApplicationDetails AD inner join web.RegistrationMaster RM on RM.RegistrationId=AD.RegistrationId  where AD.applicationstatusid=@applicationstatusid and AD.ApplicationNo=@ApplicationNo";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", arr[0].ToString());
                    Cmd.Parameters.AddWithValue("@applicationstatusid", arr[1].ToString());
                    string MobileNo = data.SelectColumns(Cmd)[0];

                    string SimpleOTP = Utility.GetRandomString(5, 2);

                    Qry = "insert into dbo.smsotpdetails(otpdetails,createdate,validupto,referencetype,referenceno) values(@otpdetails,now(),now() + INTERVAL '10 min',@referencetype,@referenceno)";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@otpdetails", SimpleOTP);
                    Cmd.Parameters.AddWithValue("@referencetype", (int)ValueId.OtpApplicationNo);
                    Cmd.Parameters.AddWithValue("@referenceno", arr[0].ToString());
                    cmdList.Add(Cmd);

                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamOTP", SimpleOTP);
                    smsDic.Add("ParamMobileNo", MobileNo);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS038, smsDic));

                    //send email to applicant and insert record in table
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS038).ToString());
                    EmailDic.Add("ParamOTP", SimpleOTP);
                    EmailDic.Add("ParamApplicationNo", arr[0].ToString());
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }

                    data.SaveData(cmdList);

                }
            }
            catch
            {
                IsSuccess = false;
            }
            return Json(IsSuccess);

        }
        public ActionResult FillNatureType(string ServiceCode)
        {
            string Qry = "select SMVD.valueid as DId,SMVD.valuename as DName from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid inner join dgen.lbrservicetocomtypemaster LBR on LBR.natureid= SMVD.valueid where SMV.mastervalueid=@mastervalueid and LBR.ServiceCode=@ServiceCode";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.ComplaintsNatureMaster);
            Cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetQuerystring(string QS)
        {
            ArrayList param = new ArrayList();
            ArrayList value = new ArrayList();
            string QName = string.Empty;
            string QValue = string.Empty;
            if (!string.IsNullOrEmpty(QS))
            {
                string[] QSResult = QS.Split('&');
                if (QSResult.Length > 0)
                {
                    for (int i = 0; i < QSResult.Length; i++)
                    {
                        string[] QS1 = QSResult[i].Split('=');
                        param.Add(QS1[0]);
                        value.Add(QS1[1]);
                    }
                }
            }
            string QueryStr = Utility.CreateEncryptedQueyString(param, value);

            return Json(QueryStr);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult AnonymousEncryptString(string UserId)
        {
            string result = string.Empty;
            if (string.IsNullOrEmpty(UserId)) { result = string.Empty; }
            try {
                result = RijndaelSimple.EncryptString(UserId, null);
            } catch {
                result = string.Empty;
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetSCSTScholorship(string GroupId, string AppNo)
        {
            GetData data = new GetData();
            DataTable dt = new DataTable();
            string result = string.Empty;

            dt = Utility.GetSCSTScholorship(AppNo, null, GroupId);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    result = dt.Rows[0]["FeeAmount"].ToString();
                }
            }
            return Json(result);
        }
        public ActionResult FillDistrictDeptList(string DepartmentId)
        {
            string Qry = "select districtId  as DId,districtName as DName  from dgen.prematdistrictmaster where DepartmentId=@DepartmentId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DepartmentId", DepartmentId);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillZoneDeptList(string DistrictId)
        {
            string Qry = "select ZoneId as DId,ZoneName as DName from dgen.prematzonemaster  where DistrictCode=@DistrictId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DistrictId", DistrictId);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        [AllowAnonymous]
        public JsonResult GetConsent(string DocId, string Server)
        {
            GetData data = new GetData();
            SelectValueMaster model = new SelectValueMaster();
            string Qry = string.Empty;
            string[] Val = new string[2];
            if (DocId == ((int)DocumentId.AadhaarCard).ToString())
            {
                if (Server == DB.LS.ToString()) { Val[0] = Utility.SelectColumnsValue("selectmastervaluedetails", "valuename", "valueid", ((int)Consent.AadhaarCSC).ToString())[0]; Val[1] = ((int)Consent.AadhaarCSC).ToString(); }
                if (Server == DB.RS.ToString()) { Val[0] = Utility.SelectColumnsValue("selectmastervaluedetails", "valuename", "valueid", ((int)Consent.AadhaarCitizen).ToString())[0]; Val[1] = ((int)Consent.AadhaarCitizen).ToString(); }
            }
            else if (DocId == ((int)DocumentId.VoterID).ToString())
            {
                if (Server == DB.LS.ToString()) { Val[0] = Utility.SelectColumnsValue("selectmastervaluedetails", "valuename", "valueid", ((int)Consent.VoterCSC).ToString())[0]; Val[1] = ((int)Consent.VoterCSC).ToString(); }
                if (Server == DB.RS.ToString()) { Val[0] = Utility.SelectColumnsValue("selectmastervaluedetails", "valuename", "valueid", ((int)Consent.VoterCitizen).ToString())[0]; Val[1] = ((int)Consent.VoterCitizen).ToString(); }
            }
            else
            {
                if (Server == DB.LS.ToString()) { Val[0] = Utility.SelectColumnsValue("selectmastervaluedetails", "valuename", "valueid", ((int)Consent.OtherDocumentCSC).ToString())[0]; Val[1] = ((int)Consent.OtherDocumentCSC).ToString(); }
                if (Server == DB.RS.ToString()) { Val[0] = Utility.SelectColumnsValue("selectmastervaluedetails", "valuename", "valueid", ((int)Consent.OtherDocumentCitizen).ToString())[0]; Val[1] = ((int)Consent.OtherDocumentCitizen).ToString(); }
            }
            model.SelectValueName = Val[0]; model.SelectValueId = Val[1];
            return Json(Val, JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillTOList(string UserTimefrom)
        {
            List<SelectListItem> list = new List<SelectListItem>();
            DateTime Starttime = Convert.ToDateTime(UserTimefrom).AddHours(1);
            DateTime Endtime = DateTime.ParseExact("23:55", "HH:mm", null);
            int Inerval = 60;
            for (DateTime i = Starttime; i <= Endtime; i = i.AddMinutes(Inerval))
            {
                list.Add(new SelectListItem() { Text = i.ToString("HH:mm"), Value = i.ToString("HH:mm") });
            }
            return Json(list, JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillSCSTSchoolNameList(string DepartmentId, string DistrictId, string ZoneId)
        {
            string Qry = "select PSM.SchoolId as DId,SchoolName||','||SchoolAddress as DName from dgen.prematschoolmaster PSM where PSM.WhetherActive=@WhetherActive";
            if (!string.IsNullOrEmpty(DepartmentId)) { Qry += " and DepartmentId=@DepartmentId "; }
            if (!string.IsNullOrEmpty(DistrictId)) { Qry += " and District=@DistrictId "; }
            if (!string.IsNullOrEmpty(ZoneId)) { Qry += " and SubDivision=@ZoneId "; }
            Qry += " order by SchoolName ";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DepartmentId", DepartmentId);
            Cmd.Parameters.AddWithValue("@DistrictId", DistrictId);
            Cmd.Parameters.AddWithValue("@ZoneId", ZoneId);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillApparatusTypeList()
        {
            string Qry = "select s1.valueid as DId,s1.valuename as DName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId and s1.valueid not in (@generator) order by s1.valuename";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.ApparatusTypeList);
            Cmd.Parameters.AddWithValue("@generator", (int)ValueId.Generator);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        [AllowAnonymous]
        public ActionResult FillBankBranch(string HeBankCode)
        {
            string Qry = "select hebranchcode as DId,branchname as DName from hebankbranchmaster where hebankcode=@hebankcode and Whetheractive=@Whetheractive order by branchname";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@hebankcode", HeBankCode);
            Cmd.Parameters.AddWithValue("@Whetheractive", CustomText.TRUE.ToString());
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        public ActionResult FillTransformerTypeList()
        {
            string Qry = "select s1.valueid as DId,s1.valuename as DName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.TransformerType);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult CheckRegId(string UserId)
        {
            bool flag = false;
            GetData data = new GetData();
            string Qry = "select RegistrationId from web.Registrationmaster where RegistrationId=@RegistrationId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@RegistrationId", UserId);
            string WhetheruseridExist = data.SelectColumns(Cmd)[0];
            if (!string.IsNullOrEmpty(WhetheruseridExist))
            {
                flag = true;
            }
            return Json(flag);
        }
        public ActionResult FillMarriageAct(string HReligionId, string WReligionId, string ServiceCode)
        {
            string Qry = "select ValueId as DId,Valuename as Dname from dbo.SelectMasterValueDetails where 1=1";
            if (ServiceCode == ((int)ServiceList.Marriage).ToString())
            {
                if (HReligionId == ((int)Religion.Sikh).ToString() && WReligionId == ((int)Religion.Sikh).ToString()) { Qry += " and ValueId in (@Special,@Hindu,@Anand) "; }
                else { Qry += " and ValueId in (@Special,@Hindu) "; }
            }
            else
            {
                Qry += " and ValueId in (@Special13) ";
            }
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@Special", (int)MarriageAct.Special);
            Cmd.Parameters.AddWithValue("@Hindu", (int)MarriageAct.Hindu);
            Cmd.Parameters.AddWithValue("@Anand", (int)MarriageAct.Anand);
            Cmd.Parameters.AddWithValue("@Special13", (int)MarriageAct.Special13);
            return Json(GetDropdown(Cmd), JsonRequestBehavior.AllowGet);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetCasteDetailsValidated(string StateId, string CasteId, string CasteCerNo, string HolderName, string CasteValId)
        {
            CasteDetails model = new CasteDetails();

            if (StateId == ((int)State.Delhi).ToString())
            {
                string Category = String.Empty;
                if (string.IsNullOrEmpty(CasteId) || string.IsNullOrEmpty(CasteCerNo)) { return null; }
                GetData objData = new GetData();
                string WhetherCon = string.Empty, Qry = string.Empty;
                if (CasteCerNo.Length == 14 && (Convert.ToInt32(CasteCerNo.Substring(4, 1)) < 8))
                {
                    if (Convert.ToInt32(CasteId) == (int)ValueId.SC) { WhetherCon = " drev.applicationdetailsscst SC "; }
                    else if (Convert.ToInt32(CasteId) == (int)ValueId.ST) { WhetherCon = " drev.applicationdetailsst SC "; }
                    else if (Convert.ToInt32(CasteId) == (int)ValueId.OBC) { WhetherCon = " drev.applicationdetailsobc SC "; }
                }
                else
                {
                    WhetherCon = " applicationdetailsepp SC ";

                    if (Convert.ToInt32(CasteId) == (int)ValueId.SC) { Category = "SC"; }
                    else if (Convert.ToInt32(CasteId) == (int)ValueId.ST) { Category = "ST"; }
                    else if (Convert.ToInt32(CasteId) == (int)ValueId.OBC) { Category = "OBC"; }
                }

                if (CasteCerNo.Length == 14 && (Convert.ToInt32(CasteCerNo.Substring(4, 1)) < 8))
                {
                    Qry = "select  ServiceCode,AD.ApplicationNo,to_char(AD.lastactiondate,'DD/MM/YYYY') as SignedDate,'True' as WhetherCasteVerified, AD.applicantname, casteid, ApplicationStatusId from applicationdetails AD inner join " + WhetherCon + " on SC.ApplicationNo=AD.applicationNO where AD.ApplicationNo=@ApplicationNo";
                }
                else
                { Qry = "select ServiceCode,IdNo as ApplicationNo,to_char(dop,'DD/MM/YYYY') as SignedDate,'True' as WhetherCasteVerified, applicantname, category, upper(Status) as Status from applicationdetailsepp where IdNo=@ApplicationNo "; }

                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", CasteCerNo);
                DataTable dt = objData.GetDataTable(Cmd);
                if (dt != null && dt.Rows.Count > 0)
                {
                    model.WhetherCasteDetailsAvailable = true;
                    if (CasteCerNo.Length == 14 && (Convert.ToInt32(CasteCerNo.Substring(4, 1)) < 8))
                    {
                        if (dt.Rows[0]["applicantname"].ToString().ToUpper() == HolderName.ToUpper() && dt.Rows[0]["casteid"].ToString() == CasteValId && dt.Rows[0]["ApplicationStatusId"].ToString() == ((int)Status.ISSUCER).ToString())
                        {
                            model.WhetherCasteDetailsValidated = true;
                        }
                        else
                        {
                            model.WhetherCasteDetailsValidated = false;
                        }
                    }
                    else
                    {
                        if (dt.Rows[0]["applicantname"].ToString().ToUpper() == HolderName.ToUpper() && dt.Rows[0]["category"].ToString() == Category && (dt.Rows[0]["Status"].ToString() == CustomText.ISSUED.ToString() || dt.Rows[0]["Status"].ToString().ToUpper() == "ISSUED BY COURIER"))
                        {
                            model.WhetherCasteDetailsValidated = true;
                        }
                        else
                        {
                            model.WhetherCasteDetailsValidated = false;
                        }

                    }

                    string getValue = CasteId + "," + CasteCerNo;
                    TempData[KeyName._Key05] = getValue;
                }
            }

            return Json(model);
        }
        public ActionResult FillConditionalGenderList(string ApplicantGender)
        {
            List<SelectListItem> list = new List<SelectListItem>();
            if (ApplicantGender.ToUpper() == Gender.F.ToString()) { list.Add(new SelectListItem() { Text = "Male", Value = "M" }); }
            else { list.Add(new SelectListItem() { Text = "Female", Value = "F" }); }
            return Json(list, JsonRequestBehavior.AllowGet);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult CheckAllowAttendent(string ApplicantDob, string SpouseDob)
        {
            bool flag = false;
            GetData data = new GetData();
            int ApplicantAge = 0, SpouseAge = 0;
            ApplicantAge = Utility.GetAgeFromDob(ApplicantDob);
            if (!string.IsNullOrEmpty(SpouseDob)) { SpouseAge = Utility.GetAgeFromDob(SpouseDob); }
            if (ApplicantAge > 70 || SpouseAge > 70) { flag = true; }
            return Json(flag);
        }
        public ActionResult Documentvalidate(string docid, string docno, string depart, string docregi)
        {
            Regex regxAadhar = new Regex("^(?<numeric>[0-9]{12})$");//Aadhaar Card-UID (DocID=1 and deprtid=6)
            Regex regxDriver = new Regex("^(?<intro>[DL]{2})(?<numeric>[0-9]{2})(?<year>[0-9]{4})(?<tail>[0-9]{7})$");//Driving License (DocID=13 and deprtid=8)
            //Regex regxVoter = new Regex("^(?<intro>[A-Z]{3})(?<numeric>[0-9]{3})(?<year>[0-9]{4})$");//Voter ID Card (DocID=36 and deprtid=9) 
            Regex regxVoter = new Regex(@"^([a-zA-Z0-9\\\/]{10,17})$");//Voter ID Card (DocID=36 and deprtid=9)
            Regex regxPassport = new Regex("^(?<intro>[A-Z]{1})(?<numeric>[0-9]{2})(?<tail>[0-9]{5})$");//Passport (DocID=28  and deprtid=5)
            Regex regxElectBSES = new Regex("^(?<numeric>[0-9]{1})(?<tail>[0-9]{8})$");//Electricity Bill-BSES (DocID=14 and deprtid=11)
            Regex regxElectNDPL = new Regex("^(?<numeric>[6]{1})(?<tail>[0-9]{10})$");//Electricity Bill-NDPL  (DocID=14 and deprtid=12)
            Regex regxElectNDMC = new Regex("^(?<numeric>[0-9]{1})(?<tail>[0-9]{9,11})$");//Electricity Bill-NDMC (DocID=14 and deprtid=3)
            Regex regxPanCard = new Regex("^(?<intro>[A-Z]{5})(?<numeric>[0-9]{4})([A-Z]{1})$");//PAN Card-Income Tax(DocID=4 and deprtid=10)
            Regex regxDOB_MCD = new Regex("^(?<numeric>[0-9]{1})(?<tail>[0-9]{5,6})$");//Birth Certificate-MCD(DocID=4  and deprtid=7)
            Regex regxDOB_NDMC = new Regex("^([A-Za-z0-9]{15,15})$");//Birth Certificate-NDMC(DocID=4 and deprtid=3)
            Regex regxDOB_Haryana = new Regex("^(?<tail>[0-9]{15,15})$");//Birth Certificate-Edistrict - Haryana(DocID=4 and deprtid=28)
            Regex regxDeathB_MCD = new Regex("^(?<numeric>[0-9]{1})(?<tail>[0-9]{5,6})$");//Death Certificate-MCD (DocID=11 and deprtid=7)
            Regex regxDeathB_NDMC = new Regex("^([A-Za-z0-9]{15,15})$");// Death Certificate-NDMC (DocID=11 and deprtid=3)
            Regex regxDeathB_Haryana = new Regex("^(?<tail>[0-9]{15,15})$");//Death Certificate-Edistrict - Haryana (DocID=11 and deprtid=28)
            Regex regxJalBoard = new Regex("^(?<tail>[0-9]{12,12})$");//Water Bill-Delhi Jal Board (DocID=37 and deprtid=16)
            Regex regxWaterNDMC = new Regex("^(?<numeric>[0-9]{1})(?<tail>[0-9]{9,11})$");//Water Bill-NDMC (DocID=37 and deprtid=3)
            Regex regxCardFoodSuppy = new Regex("^(?<tail>[0-9]{12,12})$");//Ration Card-Food and Suppy Department (DocID=30 and deprtid=17)
            Regex regxBPLRelation = new Regex("^(?<tail>[0-9]{12,12})$");//BPL Ration Card-Food and Suppy Department (DocID=44 and deprtid=17)
            Regex regxCasteCertificate = new Regex("^(?<tail>[0-9]{12,12})$");//Caste Certificate from Parental Side-Edistrict - UP (DocID=43  and deprtid=29)
            Regex regxAircel = new Regex("^(?<tail>[0-9]{9,12})$");//Aircel bill No. (DocID=35  and deprtid=18)
            Regex regxAirtel = new Regex("^(?<tail>[0-9]{9,10})$");//Bharti Airtel bill No. (DocID=35 and deprtid=19)
            Regex regxBSNL = new Regex("^(?<tail>[0-9]{10})$");//BSNL bill No. (DocID=35 and deprtid=20)
            Regex regxIdea = new Regex("^(?<tail>[0-9]{9,10})$");//Idea cellular bill No. (DocID=35 and deprtid=21)
            Regex regxMTNL = new Regex("^(?<tail>[0-9]{10})$");//MTNL bill No. (DocID=35 and deprtid=22)
            Regex regxMTS = new Regex("^(?<tail>[0-9]{9-15})$");//MTS India bill No. (DocID=35 and deprtid=23)
            Regex regxReliance = new Regex("^(?<tail>[0-9]{12})$");//Reliance Communications bill No. (DocID=35 and deprtid=24)
            Regex regxTataDoCoMo = new Regex("^(?<tail>[0-9]{10})$");//Tata DoCoMo bill No. (DocID=35 and deprtid=25)
            Regex regxUninor = new Regex("^(?<tail>[0-9]{9,15})$");//Uninor bill No. (DocID=35 and deprtid=26)
            Regex regxMatriculation = new Regex("^(?<tail>[0-9]{5,10})$");//Matriculation Certificate (DocID=19 and deprtid=27)
            Regex regxNationality = new Regex("^(?<tail>[0-9]{5,10})$");//Nationality Certificate (DocID=23  and deprtid=4)
            //Regex regxOther = new Regex("^([A-Za-z0-9]{5,20})$");// Other (DocID=64 and deprtid=1)(DocID=43,30,84,13,14,85,32,35,3,137,65,82,83,240,27,94,132,133,201,199,200,203,95,23,204)
            Regex regxAllDocuments = new Regex(@"^([A-Za-z0-9\\\/]{5,20})$");// All Documents verified


            string result = string.Empty;

            //Aadhaar Card No
            if (regxAadhar.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.AadhaarCard && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.UID)
            {
                result = "Aadhaar Card No. Invalid " + "\n" + " Aadhaar No. should be of 12-digit and can contain 0-9 only.";
            }

            //Driver Licence
            else if (regxDriver.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.DrivingLicense && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.TransportDepartment)
            {
                result = "Driver Licence No. Invalid" + "\n" + "Driving License No. should be of 15-digit and can contain A-Z,0-9 only.";
            }
            //Voter Id Card
            else if (regxVoter.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.VoterID && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.ElectionCommission)
            {
                //result = "Voter Id Card Invalid" + "\n" + "Voter Id No. should be of 10 digit and can contain A-Z,0-9 only.";
                result = "Voter Id Card Invalid" + "\n" + "Voter Id No. should be of 10-17-digit and can contain a-z,A-Z,0-9,/ and \\ only.";
            }
            //Pasport No
            else if (regxPassport.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.Passport && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.PassportAuthority)
            {
                result = "Pasport No. Invalid" + "\n" + "Passport No. should be of 8-digit and can contain A-Z,0-9 only.";
            }
            //Electricity Bill
            else if (regxElectBSES.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.Electricityid && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.BSES)
            {
                result = "Electricity Bill No. Invalid" + "\n" + "Bill No. should be of 9-digit and can 0-9 only.";
            }
            else if (regxElectNDPL.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.Electricityid && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.TPDDL)
            {
                result = "Electricity Bill No. Invalid" + "\n" + "Bill No. should be of 11-digit and can 0-9 only.";
            }
            else if (regxElectNDMC.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.Electricityid && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.NDMC)
            {
                result = "Electricity Bill No. Invalid" + "\n" + "Bill No. should be atleast of 10-digit and can 0-9 only.";
            }
            //pancard
            else if (regxPanCard.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.PANCard && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.IncomTaxDepartment)
            {
                result = "Pan Card No. Invalid" + "\n" + "PAN Card No. should be of 10-digit and can contain A-Z,0-9 only.";
            }
            //DOB
            else if (regxDOB_MCD.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.BirthCertificate && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.MCD)
            {
                result = "Certificate No. Invalid" + "\n" + "Certificate No. should be of 6 -7 digit and can contain 0-9 only.";
            }
            else if (regxDOB_NDMC.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.BirthCertificate && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.NDMC)
            {
                result = "Certificate No. Invalid" + "\n" + "Certificate No. should be of 15-digit and can contain A-Z,0-9 only.";
            }
            else if (regxDOB_Haryana.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.BirthCertificate && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.EdistrictHaryana)
            {
                result = "Certificate No. Invalid" + "\n" + "Certificate No. should be of 15-digit and can contain 0-9 only.";
            }
            //Matriculation
            else if (regxMatriculation.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.Matriculation && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.CBSE)
            {
                result = "Certificate No. Invalid" + "\n" + "Certificate No. should be of 5-10 digit and can contain 0-9 only.";
            }
            //regxNationality
            else if (regxNationality.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.NationalityCertificate && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.RevenueDepartment)
            {
                result = "Certificate No. Invalid" + "\n" + "Certificate No. should be of 5-10 digit and can contain 0-9 only.";
            }
            //Deathofbirth
            else if (regxDeathB_MCD.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.DeathCertificate && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.MCD)
            {
                result = "Certificate No. Invalid" + "\n" + "Certificate No. should be of 6 -7 digit and can contain 0-9 only.";
            }
            else if (regxDeathB_NDMC.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.DeathCertificate && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.NDMC)
            {
                result = "Certificate No. Invalid" + "\n" + "Certificate No. should be of 15-digit and can contain A-Z,0-9 only.";
            }
            else if (regxDeathB_Haryana.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.DeathCertificate && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.EdistrictHaryana)
            {
                result = "Certificate No. Invalid" + "\n" + "Certificate No. should be of 15-digit and can contain 0-9 only.";
            }
            //Water Bill-Delhi
            else if (regxJalBoard.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.WaterBill && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.DJB)
            {
                result = "Water Bill No. Invalid" + "\n" + "Bill No. should be of 12-digit and can 0-9 only.";
            }
            else if (regxWaterNDMC.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.WaterBill && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.NDMC)
            {
                result = "Water Bill No. Invalid" + "\n" + "Bill No. should be atleast of 10-digit and can 0-9 only.";
            }
            //Card-Food and Suppy
            else if (regxCardFoodSuppy.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.RationCard && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.FoodAndSupplyDepartment)
            {
                result = "Ration Card-Food and Suppy No. Invalid" + "\n" + "Card No. should be of 12-digit and can 0-9 only.";
            }
            //BPL Ration Card-Food and Suppy Department
            else if (regxBPLRelation.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.BPLRelation && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.FoodAndSupplyDepartment)
            {
                result = "BPL Ration Card-Food and Suppy No. Invalid" + "\n" + "Card No. should be of 12-digit and can 0-9 only.";
            }
            //Caste Certificate from Parental Side-Edistrict - UP
            else if (regxCasteCertificate.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.CasteCertificate && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.EdistrictUP)
            {
                result = "Certificate No. Invalid" + "\n" + "Certificate No. should be of 12-digit and can contain 0-9 only.";
            }
            //Phone 
            else if (regxAircel.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.Telephonebill && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.Aircel)
            {
                result = "Bill No. Invalid" + "\n" + "Bill No. should be of 9-12 digit and can 0-9 only.";
            }
            else if (regxAirtel.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.Telephonebill && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.BhartiAirtel)
            {
                result = "Bill No. Invalid" + "\n" + "Bill No. should be of 9-10 digit and can 0-9 only.";
            }
            else if (regxBSNL.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.Telephonebill && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.BSNL)
            {
                result = "Bill No. Invalid" + "\n" + "Bill No. should be of 10 digit and can 0-9 only.";
            }
            else if (regxIdea.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.Telephonebill && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.Ideacellular)
            {
                result = "Bill No. Invalid" + "\n" + "Bill No. should be of 9-10 digit and can 0-9 only.";
            }
            else if (regxMTNL.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.Telephonebill && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.MTNL)
            {
                result = "Bill No. Invalid" + "\n" + "Bill No. should be of 10 digit and can 0-9 only.";
            }
            else if (regxMTS.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.Telephonebill && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.MTSIndi)
            {
                result = "Bill No. Invalid" + "\n" + "Bill No. should be of 9-15 digit and can 0-9 only.";
            }
            else if (regxReliance.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.Telephonebill && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.RelianceCommunications)
            {
                result = "Bill No. Invalid" + "\n" + "Bill No. should be of 12 digit and can 0-9 only.";
            }
            else if (regxTataDoCoMo.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.Telephonebill && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.TataDoCoMo)
            {
                result = "Bill No. Invalid" + "\n" + "Bill No. should be of 10 digit and can 0-9 only.";
            }
            else if (regxUninor.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.Telephonebill && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.Uninor)
            {
                result = "Bill No. Invalid" + "\n" + "Bill No. should be of 9-15 digit and can 0-9 only.";
            }
            //Other
            //else if (regxOther.IsMatch(docno.ToString()) == false && Convert.ToInt32(depart.ToString()) == (int)EnclosureDepartment.Other && (Convert.ToInt32(docid.ToString()) == (int)DocumentId.CasteCertificate || Convert.ToInt32(docid.ToString()) == (int)DocumentId.RationCard || Convert.ToInt32(docid.ToString()) == (int)DocumentId.GovtRecDoc || Convert.ToInt32(docid.ToString()) == (int)DocumentId.DrivingLicense || Convert.ToInt32(docid.ToString()) == (int)DocumentId.Electricityid || Convert.ToInt32(docid.ToString()) == (int)DocumentId.GasBill || Convert.ToInt32(docid.ToString()) == (int)DocumentId.RentAgreement || Convert.ToInt32(docid.ToString()) == (int)DocumentId.Telephonebill || Convert.ToInt32(docid.ToString()) == (int)DocumentId.BankPassbookwithPhotographs || Convert.ToInt32(docid.ToString()) == (int)DocumentId.WaterBill || Convert.ToInt32(docid.ToString()) == (int)DocumentId.Other || Convert.ToInt32(docid.ToString()) == (int)DocumentId.SchoolIDcard || Convert.ToInt32(docid.ToString()) == (int)DocumentId.LetterattestedschoolPrincipal || Convert.ToInt32(docid.ToString()) == (int)DocumentId.DischargeSummaryHospital || Convert.ToInt32(docid.ToString()) == (int)DocumentId.PANCard || Convert.ToInt32(docid.ToString()) == (int)DocumentId.Birthbelowfiveyear || Convert.ToInt32(docid.ToString()) == (int)DocumentId.tenthCertificate || Convert.ToInt32(docid.ToString()) == (int)DocumentId.twelvethCertificate || Convert.ToInt32(docid.ToString()) == (int)DocumentId.AssistantLabourCommissioner || Convert.ToInt32(docid.ToString()) == (int)DocumentId.Employeerincludingcontractor || Convert.ToInt32(docid.ToString()) == (int)DocumentId.RegisteredTradeUnionConstruction || Convert.ToInt32(docid.ToString()) == (int)DocumentId.IssuedRegisteredTradeUnionConstruction || Convert.ToInt32(docid.ToString()) == (int)DocumentId.DomicileCertificate || Convert.ToInt32(docid.ToString()) == (int)DocumentId.NationalityCertificate || Convert.ToInt32(docid.ToString()) == (int)DocumentId.LBRBirthSelfCertification))
            //{
            //    result = "Document No. Invalid" + "\n" + "Document No. should be of 5-20 digit and can can contain A-Z,0-9 only.";
            //}
            else if (regxAllDocuments.IsMatch(docno.ToString()) == false)
            {
                result = "Document No. Invalid" + "\n" + "Certificate No. should be of 5-20 digit and can can contain A-Z,0-9 only.";
            }
            return Json(result);
        }
        [AllowAnonymous]
        public ActionResult DocumentvalidateEntry(string docid, string docno, string docregi)
        {
            Regex regxAadhar = new Regex("^(?<numeric>[0-9]{12})$");//Aadhaar Card-UID(DocID=1
            Regex regxDriver = new Regex("^(?<intro>[DL]{2})(?<numeric>[0-9]{2})(?<year>[0-9]{4})(?<tail>[0-9]{7})$");//Driving License(DocID=13)
            //Regex regxVoter = new Regex("^(?<intro>[A-Z]{3})(?<numeric>[0-9]{3})(?<year>[0-9]{4})$");//Voter ID Card(DocID=36)
            Regex regxVoter = new Regex(@"^([a-zA-Z0-9\\\/]{10,17})$");//Voter ID Card (DocID=36)
            Regex regxPassport = new Regex("^(?<intro>[A-Z]{1})(?<numeric>[0-9]{2})(?<tail>[0-9]{5})$");//Passport(DocID=28)
            Regex regxPanCard = new Regex("^(?<intro>[A-Z]{5})(?<numeric>[0-9]{4})([A-Z]{1})$");//PAN Card-Income Tax(DocID=4)
            Regex regxCardFoodSuppy = new Regex("^(?<tail>[0-9]{12,12})$");//Ration Card-Food and Suppy Department(DocID=30)
            //Regex regxOther = new Regex("^([A-Za-z0-9]{5,20})$");
            Regex regxOther = new Regex(@"^([A-Za-z0-9\\\/]{5,20})$");
            string result = string.Empty;

            //Aadhaar Card No
            if (regxAadhar.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.AadhaarCard)
            {
                result = "Aadhaar Card No. Invalid " + "\n" + " Aadhaar No. should be of 12-digit and can contain 0-9 only.";
            }
            //Driver Licence
            else if (regxDriver.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.DrivingLicense)
            {
                result = "Driver Licence No. Invalid" + "\n" + "Driving License No. should be of 15-digit and can contain A-Z,0-9 only.";
            }
            //Voter Id Card
            else if (regxVoter.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.VoterID)
            {
                //result = "Voter Id Card Invalid" + "\n" + "Voter Id No. should be of 10 digit and can contain A-Z,0-9 only.";
                result = "Voter Id Card Invalid" + "\n" + "Voter Id No. should be of 10-17-digit and can contain a-z,A-Z,0-9,/ and\\ only.";
            }
            //Pasport No
            else if (regxPassport.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.Passport)
            {
                result = "Pasport No. Invalid" + "\n" + "Pasport No. should be of 8-digit and can contain A-Z,0-9 only.";
            }
            //pancard
            else if (regxPanCard.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.PANCard)
            {
                result = "Pan Card No. Invalid" + "\n" + "PAN Card No. should be of 10-digit and can contain A-Z,0-9 only.";
            }
            //Card-Food and Suppy
            else if (regxCardFoodSuppy.IsMatch(docno.ToString()) == false && Convert.ToInt32(docid.ToString()) == (int)DocumentId.RationCard)
            {
                result = "Ration Card-Food and Suppy No. Invalid" + "\n" + "Card No. should be of 12-digit and can 0-9 only.";
            }
            else if (regxOther.IsMatch(docno.ToString()) == false)
            {
                result = "Document No. Invalid" + "\n" + "Card No. should be of 5-20-digit and contain A-Z,0-9 only.";
            }
            return Json(result);
        }
        
        
        #region global method current contoller
        //method for preserve model state
        public void PreserveModelState(string Key, object obj, bool IsKeep, bool IsRemove)
        {
            if (IsRemove == true) { TempData.Remove(Key); }
            if (obj != null) { TempData[Key] = obj; }
            if (IsKeep == true) { TempData.Keep(Key); }
        }
        #endregion global method current contoller
    }
}
