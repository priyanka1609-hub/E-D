﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.DataService;
using Npgsql;
using System.Text;
using Edistrict.Models.ApplicationService;
using Edistrict.Models;
using Edistrict.Models.Entities;
using System.IO;
using System.Globalization;
using System.Collections;
using ReportManagement;
using System.Web.UI;
using Edistrict.Models.CustomClass;
using System.Data;
using Esigndlsc;

namespace Edistrict.Controllers
{
    [Authorize(Roles = "103,104,106,111,114,118,123")]
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class SignController : Controller
    {
        #region Common method for handle the Digital/E-sign request
        // Approval module for approving of application
        [EncryptedActionParameter]
        public ActionResult ProcessApplicationApprovalRequest(Int64 AppNo)
        {
            try
            {
                string Qry = string.Empty;
                GetData data = new GetData();
                NpgsqlCommand Cmd = new NpgsqlCommand();
                string ApplicationNo = AppNo.ToString();
                string UserId = Sessions.getEmployeeUser().UserId;
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                string ServiceCode = Utility.SelectColumnsValue("ApplicationDetails", "ServiceCode", "ApplicationNo", ApplicationNo)[0];
                int StatusId = Utility.GetStatusAfterApproval(ServiceCode, true);

                if (!Utility.CheckCurrentStatusBeforeUpdate(ApplicationNo, StatusId, (int)CountList.Type001))
                {
                    ViewData["message"] = "Application is not pending at this level anymore. Kindly contact to Administrator.";
                    return View("message");
                }

                // Get unsigned pdf buffer for certificate
                byte[] PdfBuffer = null;
                SignModels sModel = DigitalSignatureData.GetModelForCertificateView(Convert.ToInt64(ApplicationNo));
                if (sModel.dataa != null)
                {
                    PdfBufferGenerator objBuffer = new PdfBufferGenerator();
                    PdfBuffer = objBuffer.GetPdfBuffer(this, string.Empty, sModel.ViewName, sModel);
                }

                // Display message if pdf buffer contains null
                if (PdfBuffer == null) { return RedirectToAction("InternalError", "Error"); }

                // Delete existing records of same application from temp table
                Qry = "delete from dsgn.tempdigitaldatadetails where applicationno=@applicationno;";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@applicationno", ApplicationNo);
                cmdList.Add(Cmd);

                if (sModel.dataa != null)
                {
                    // Save the record in temp table
                    Qry = "insert into dsgn.tempdigitaldatadetails (applicationno,unsigneddocument,actionby,ipaddress) values(@applicationno,@unsigneddocument,@actionby,@ipaddress)";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@applicationno", ApplicationNo);
                    Cmd.Parameters.AddWithValue("@unsigneddocument", PdfBuffer);
                    Cmd.Parameters.AddWithValue("@actionby", UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                }

                Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", StatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", ApplicationNo);
                Cmd.Parameters.AddWithValue("@userid", UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,approveddate=now(),userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", StatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", ApplicationNo);
                Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(ApplicationNo, StatusId, (int)CountList.Type001, DB.LS.ToString()));
                Cmd.Parameters.AddWithValue("@userid", UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                // Execute statement after approval of application
                Cmd = Utility.UpdateDataAfterApproval(ApplicationNo);
                if (Cmd != null) { cmdList.Add(Cmd); }

                // Insert transaction in application audit trail
                cmdList.Add(Utility.InsertDepartmentAuditTrail(ApplicationNo, (int)ApplicationHistoryMessage.MSG002, null, (int)ApplicationSource.Window, null));

                data.SaveData(cmdList);
                //Utility.PreserveSessionState(KeyName._Key07, null, true, false);
                PreserveModelState(Constant._ActionMessage, "Application [" + ApplicationNo + "] has been approved successfully.", false, true);

                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.TEHSPEN).ToString() });
                return RedirectToAction(Utility.GetDecisionControllerName(Sessions.getEmployeeUser().DeptCode, null, ((int)CountList.Type002).ToString()), "Decision", new { q = QueryString });
            }
            catch
            {
                //Utility.PreserveSessionState(KeyName._Key07, null, true, false);
                return RedirectToAction("InternalError", "Error");
            }
        }

        // check whether eSign required or Digital Sign required
        [EncryptedActionParameter]
        public ActionResult ProcessSignRequest(Int64 AppNo, int? SanctionNo)
        {
            string QueryString = string.Empty;
            int SignType = Convert.ToInt32(Utility.SelectColumnsValue("UserMaster", "SigningTypeId", "UserId", Sessions.getEmployeeUser().UserId)[0]);

            if (SignType == (int)ValueId.SignEsign)
            {
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { AppNo.ToString() });
                return RedirectToAction("InitializeDocumentESign", "Sign", new { q = QueryString });
            }
            else if (SignType == (int)ValueId.SignDigital)
            {
                if (SanctionNo == null)
                {
                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { AppNo.ToString() });
                }
                else
                {
                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo", "SanctionNo" }, new ArrayList() { AppNo.ToString(), SanctionNo.ToString() });
                }
                return RedirectToAction("InitializeDocumentSign", "Sign", new { q = QueryString });
            }
            else
            {
                ViewData["message"] = "You are not authorized to signing the certificate/document/letter, kindly contact to your Administrator.";
                return View("message");
            }
        }
        #endregion

        #region Digital signature module for electronic document signing
        [EncryptedActionParameter]
        public ActionResult InitializeDocumentSign(Int64? AppNo, int? SanctionNo)
        {
            try
            {
                if (Utility.PreserveSessionState(KeyName._Key08, null, false, true) == true) { 
                    ViewData["message"] = "Another signing request is already in-processing in another window and new request can not be start untill finish the exisitng request."; 
                    return View("message"); 
                }
                Utility.PreserveSessionState(KeyName._Key08, AppNo, false, false);

                GetData data = new GetData();
                SignModels model = new SignModels();
                if (!string.IsNullOrEmpty(SanctionNo.ToString())) { model.ApplicationNo = SanctionNo.ToString(); } else { model.ApplicationNo = AppNo.ToString(); }
                if (string.IsNullOrEmpty(model.ApplicationNo)) { return RedirectToAction("InternalError", "Error"); }

                model.UserId = Sessions.getEmployeeUser().UserId;
                model.DownloadFileUrl = Utility.SaveAndDisplayFileForDocumentSign(Convert.ToInt64(model.ApplicationNo));
                if (string.IsNullOrEmpty(model.DownloadFileUrl)) {
                    Utility.PreserveSessionState(KeyName._Key08, null, true, false);
                    ViewData["message"] = "Oopos...your system not accepting the digital sign request, Please try again later.";
                    return View("message");
                }
                model.FilePath = Utility.SaveAndDisplayFileForMudraLogin(Sessions.getEmployeeUser().UserId, "eDistrictString");

                //delete data from dsgn.tempsignedrecord
                string Qry = "delete from dsgn.tempsignedrecord where applicationno=@applicationno and datatypeid=@datatypeid";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@datatypeid", (int)SigningType.SignedDocument);
                data.UpdateData(Cmd);

                Qry = "select dc.cardpath,dc.exefilepath,dc.cardtypename,dc.jardocumentname,dc.jardocumentlogin,dc.jardocumentbulk from usermaster um inner join userdigitalmaster ud on ud.userid=um.userid inner join digitalcardtypemaster dc on dc.cardtypeid=um.cardtypeid where um.userid=@userid and ud.whetheractive=@whetheractive";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@userid", model.UserId);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                model.DigitalCardTypeMaster = DigitalCardTypeMaster.Get<DigitalCardTypeMaster>(new DigitalCardTypeMaster(), Cmd);
                model.DigitalCardTypeMaster.JarDocumentBulkArray = model.DigitalCardTypeMaster.JarDocumentBulk.Split(',');

                Qry = "select userid ,username ,serialno ,certificatechain ,validfrom ,validto ,whetheractive ,deactivatedate ,actionuserid ,ipaddress ,actiondatetime from userdigitalmaster where userid=@userid and whetheractive=@whetheractive";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@userid", model.UserId);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                model.UserDigitalMaster = UserDigitalMaster.Get<UserDigitalMaster>(new UserDigitalMaster(), Cmd);

                Qry = "select uid,userid,password,username,permission,deptcode,districtcode,designation,dateofbirth,contactno,permanentaddress,presentaddress,dateofjoining,dateofrelieving,createdate,whetheractive,whetherpasswordchange,actionuserid,actionipaddress,actiondatetime from usermaster where userid=@userid";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@userid", model.UserId);
                model.UserMaster = UserMaster.Get<UserMaster>(new UserMaster(), Cmd);

                //model.ReferenceNo = Utility.GenerateEsdReferenceNumber().ToString();
                model.CurrentDateTime = DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss", CultureInfo.InvariantCulture);
                string domainName = new Uri(Request.Url.AbsoluteUri).GetLeftPart(UriPartial.Authority);
                model.ReturnUrl = domainName.Replace("http://", "") + "/in/en/Sign/GetSignedDocument.html?AppNo=" + model.ApplicationNo + "&Uid=" + model.UserId;
                return View(model);
            }
            catch
            {
                Utility.PreserveSessionState(KeyName._Key07, null, true, false);
                return RedirectToAction("DigitalProcessError", "Error");
            }
        }
        [AllowAnonymous]
        public ActionResult GetSignedDocument(Int64 AppNo, string Uid)
        {
            try
            {
                byte[] FileBytes = null;
                string FileName = string.Empty;
                foreach (string RequestKey in Request.Files.AllKeys)
                {
                    HttpPostedFileBase RequestFile = Request.Files[RequestKey];
                    FileName = RequestFile.FileName.ToString();
                    using (var br = new BinaryReader(Request.Files[RequestKey].InputStream))
                    {
                        FileBytes = br.ReadBytes(Request.Files[RequestKey].ContentLength);
                    }
                }

                int DataTypeId = 0;
                GetData data = new GetData();
                if (FileName.ToLower().Equals(AppNo + "_sigpdf_data.txt")) { DataTypeId = (int)SigningType.SignedDocument; } else { return new EmptyResult(); }

                string Qry = "insert into dsgn.tempsignedrecord(applicationno,datatypeid,filedata,userid) values(@applicationno,@datatypeid,@filedata,@userid)";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@applicationno", AppNo);
                Cmd.Parameters.AddWithValue("@datatypeid", DataTypeId);
                Cmd.Parameters.AddWithValue("@filedata", FileBytes);
                Cmd.Parameters.AddWithValue("@userid", Uid);
                data.UpdateData(Cmd);

                return new EmptyResult();
            }
            catch
            {
                return new EmptyResult();
            }
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult FinalizeDigitalSign(SignModels model)
        {
            try
            {
                GetData data = new GetData();
                NpgsqlCommand Cmd = new NpgsqlCommand();
                string Qry = string.Empty, DeptCode = string.Empty;
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                CMDInfoList CmdInfo = new CMDInfoList();
                List<CMDInfoList> cmdInfList = new List<CMDInfoList>();

                model.UserId = Sessions.getEmployeeUser().UserId;
                bool WhetherExist = Utility.CheckSignedData(model.ApplicationNo, model.UserId, (int)SigningType.SignedDocument);
                if (WhetherExist == false) {
                    Utility.PreserveSessionState(KeyName._Key08, null, true, false);
                    return RedirectToAction("DigitalProcessError", "Error");
                }

                Qry = "Select ApplicationNo from ApplicationDetails Where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                string AppNo = data.SelectColumns(Cmd)[0];
                if (string.IsNullOrEmpty(AppNo))
                {
                    // insert records in digital document details major
                    Qry = "insert into dsgn.digitaldocumentdetailsmajor(documenttype,documentdata,whetheractive,UserId,IpAddress,lastactiondate) select @documenttype,filedata,@whetheractive,UserId,@IpAddress,now() from dsgn.tempsignedrecord where applicationno=@sanctionid; SELECT currval(pg_get_serial_sequence('dsgn.digitaldocumentdetailsmajor','documentid'))";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@documenttype", DocumentType.typePdf);
                    Cmd.Parameters.AddWithValue("@sanctionid", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@whetheractive", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    CmdInfo = new CMDInfoList();
                    CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = null; CmdInfo.Returns = true;
                    cmdInfList.Add(CmdInfo);

                    Qry = "insert into sanctionPaymentDetails (signedrefid,sanctiondate,sanctionamount,servicecode,sanctionyear,sanctionmonth,referencecode,UserId,IpAddress,lastactiondate) select @Parameter0,sanctiondate,sanctionamount,servicecode,sanctionyear,sanctionmonth,referencecode,UserId,IpAddress,now() from tempsanctionpaymentdetails where tempsanctionid=@sanctionid; SELECT currval(pg_get_serial_sequence('sanctionpaymentdetails','sanctionid'))";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@sanctionid", model.ApplicationNo);
                    CmdInfo = new CMDInfoList();
                    CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = new int[] { 0 }; CmdInfo.Returns = true;
                    cmdInfList.Add(CmdInfo);

                    //Qry = "insert into dbyt.digitalsanctiondetails(sanctionid,Sanctiondata,sanctiondate,UserId,IpAddress,lastactiondate) select @Parameter0,filedata,now(),UserId,@IpAddress,now() from dsgn.tempsignedrecord where applicationno=@sanctionid ;";
                    //Cmd = new NpgsqlCommand(Qry);
                    //Cmd.Parameters.AddWithValue("@sanctionid", model.ApplicationNo);
                    //Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    //CmdInfo = new CMDInfoList();
                    //CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = new int[] { 0 }; CmdInfo.Returns = false;
                    //cmdInfList.Add(CmdInfo);

                    Qry = "Select ApplicationNo,SanctionRemarks from tempsanctionapplicationdetails Where sanctionid=@sanctionid";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@sanctionid", model.ApplicationNo);
                    DataTable dt = data.GetDataTable(Cmd);

                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        DeptCode = Utility.GetServiceCode(Convert.ToInt64(dt.Rows[i]["ApplicationNo"].ToString()))[1];

                        Qry = "insert into sanctionapplicationdetails(sanctionid,applicationno,sanctionamount,UserId,IpAddress,lastactiondate) select @Parameter1,applicationno,sanctionamount,UserId,IpAddress,now() from tempsanctionapplicationdetails where sanctionid=@sanctionid and ApplicationNo=@ApplicationNo ;";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", dt.Rows[i]["ApplicationNo"].ToString());
                        Cmd.Parameters.AddWithValue("@sanctionid", model.ApplicationNo);
                        CmdInfo = new CMDInfoList();
                        CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = new int[] { 1 }; CmdInfo.Returns = false;
                        cmdInfList.Add(CmdInfo);

                        if (DeptCode == ((int)Department.Dept010).ToString())
                        {
                            Qry = "Update dgen.prematapplicationprocess set sanctionid= @Parameter1, SanctionedDate=now(),SanctionedBy=@SanctionedBy,SanctionedipAddress=@SanctionedipAddress,SanctionRemarks=@SanctionRemarks,processstatusid=@processstatusid where ApplicationNo=@ApplicationNo";
                            Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                            Cmd.Parameters.AddWithValue("@ApplicationNo", dt.Rows[i]["ApplicationNo"].ToString());
                            Cmd.Parameters.AddWithValue("@SanctionedBy", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@SanctionedipAddress", Utility.GetIP4Address());
                            Cmd.Parameters.AddWithValue("@SanctionRemarks", dt.Rows[i]["SanctionRemarks"].ToString());
                            Cmd.Parameters.AddWithValue("@processstatusid", (int)ValueId.SanctionIssued);
                            CmdInfo = new CMDInfoList();
                            CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = new int[] { 1 }; CmdInfo.Returns = false;
                            cmdInfList.Add(CmdInfo);
                        }

                        Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", dt.Rows[i]["ApplicationNo"].ToString());
                        Cmd.Parameters.AddWithValue("@userid", model.UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        CmdInfo = new CMDInfoList();
                        CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = new int[] { 0 }; CmdInfo.Returns = false;
                        cmdInfList.Add(CmdInfo);

                        Qry = "update applicationdetails set applicationstatusid=@applicationstatusid,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where applicationno=@applicationno";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@applicationstatusid", (int)Status.ISSUCER);
                        Cmd.Parameters.AddWithValue("@applicationno", dt.Rows[i]["ApplicationNo"].ToString());
                        Cmd.Parameters.AddWithValue("@userid", model.UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        CmdInfo = new CMDInfoList();
                        CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = new int[] { 0 }; CmdInfo.Returns = false;
                        cmdInfList.Add(CmdInfo);

                        //insert in application audit trail
                        CmdInfo = new CMDInfoList();
                        CmdInfo.Cmd = Utility.InsertDepartmentAuditTrail(dt.Rows[i]["ApplicationNo"].ToString(), (int)ApplicationHistoryMessage.MSG053, dt.Rows[i]["SanctionRemarks"].ToString(), (int)ApplicationSource.Window, null);
                        CmdInfo.ParamenterIndex = new int[] { 0 }; CmdInfo.Returns = false;
                        cmdInfList.Add(CmdInfo);
                    }

                    Qry = "Delete from tempsanctionpaymentdetails where tempsanctionid=@sanctionid; ";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@sanctionid", model.ApplicationNo);
                    CmdInfo = new CMDInfoList();
                    CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = new int[] { 0 }; CmdInfo.Returns = false;
                    cmdInfList.Add(CmdInfo);

                    Qry = "Delete from tempsanctionapplicationdetails where sanctionid=@sanctionid";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@sanctionid", model.ApplicationNo);
                    CmdInfo = new CMDInfoList();
                    CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = new int[] { 0 }; CmdInfo.Returns = false;
                    cmdInfList.Add(CmdInfo);

                    Qry = "delete from  dsgn.tempsignedrecord where applicationno=@applicationno";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationNo);
                    CmdInfo = new CMDInfoList();
                    CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = new int[] { 0 }; CmdInfo.Returns = false;
                    cmdInfList.Add(CmdInfo);

                    Int64 SanctionNo = Convert.ToInt64(data.SaveTransactionalDataCustom(cmdInfList)[1].ToString());
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        //send sms to applicant and insert record in table
                        Dictionary<string, string> smsDic = new Dictionary<string, string>();
                        smsDic.Add("ParamApplicationNo", dt.Rows[i]["ApplicationNo"].ToString());
                        data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS032, smsDic));
                    }
                    Utility.PreserveSessionState(KeyName._Key08, null, true, false);
                    ViewData["message"] = "The Sanction of " + dt.Rows.Count + " application(s) has been signed successfully.";
                    return View("message");
                }
                else
                {
                    Qry = "insert into dsgn.digitaldocumentdetails (applicationno,signeddocument,SigningTypeId,signeddate,signedby,ipaddress) select @applicationno,filedata,@SigningTypeId,now(),@userid,@ipaddress from dsgn.tempsignedrecord where applicationno=@applicationno and userid=@userid and datatypeid=@datatypeid";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@SigningTypeId", (int)ValueId.SignDigital);
                    Cmd.Parameters.AddWithValue("@userid", model.UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    Cmd.Parameters.AddWithValue("@userid", model.UserId);
                    Cmd.Parameters.AddWithValue("@datatypeid", (int)SigningType.SignedDocument);
                    cmdList.Add(Cmd);

                    // delete from tempraory table dsgn.tempdigitaldatadetails
                    Qry = "delete from  dsgn.tempdigitaldatadetails where applicationno=@applicationno";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationNo);
                    cmdList.Add(Cmd);

                    model.ServiceCode = Utility.SelectColumnsValue("ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationNo)[0];
                    int StatusId = Utility.GetStatusAfterApproval(model.ServiceCode, false);

                    if (!Utility.CheckCurrentStatusBeforeUpdate(model.ApplicationNo, StatusId, (int)CountList.Type001))
                    {
                        ViewData["message"] = "Application is not pending at this level anymore. Kindly contact to Administrator.";
                        return View("message");
                    }

                    Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationStatusId", StatusId);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@userid", model.UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    Qry = "update applicationdetails set applicationstatusid=@applicationstatusid,AcceptedBy=@AcceptedBy,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where applicationno=@applicationno";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@applicationstatusid", StatusId);
                    Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationNo, StatusId, (int)CountList.Type001, DB.LS.ToString()));
                    Cmd.Parameters.AddWithValue("@userid", model.UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    Qry = "delete from dsgn.tempsignedrecord where applicationno=@applicationno and datatypeid=@datatypeid";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@datatypeid", (int)SigningType.SignedDocument);
                    cmdList.Add(Cmd);

                    //insert in application audit trail
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG005, null, (int)ApplicationSource.Window, null));

                    //send sms to applicant and insert record in table
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationNo);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS003, smsDic));

                    //send email to applicant and insert record in table
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS003).ToString());
                    EmailDic.Add("ParamApplicationNo", model.ApplicationNo);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }

                    data.SaveData(cmdList);

                    Utility.PreserveSessionState(KeyName._Key08, null, true, false);
                    ViewData["message"] = "Certificate [" + model.ApplicationNo + "] has been signed successfully";
                    return View("message");
                }
            }
            catch
            {
                Utility.PreserveSessionState(KeyName._Key07, null, true, false);
                return RedirectToAction("DigitalProcessError", "Error");
            }
        }
        #endregion

        #region e-Sign module for electronic document signing
        [EncryptedActionParameter]
        public ActionResult InitializeDocumentESign(Int64 AppNo, int Attempt = 0)
        {
            try
            {
                SignModels model = new SignModels();
                Esign esign = new Esign();
                model.ServiceCode = Utility.SelectColumnsValue("ApplicationDetails", "ServiceCode", "ApplicationNo", AppNo.ToString())[0];
                int StatusId = Utility.GetStatusAfterApproval(model.ServiceCode, false);
                if (!Utility.CheckCurrentStatusBeforeUpdate(AppNo.ToString(), StatusId, (int)CountList.Type001))
                {
                    ViewData["message"] = "Application is not pending at this level anymore. Kindly contact to Administrator.";
                    return View("message");
                }
                string OTPResponse = Utility.ProcessEsignRequest((int)ValueId.EsignOTP, (int)ValueId.EsignCerRequest, AppNo, null);
                if (OTPResponse.Split('|')[0] == ((int)CountList.Type000).ToString()) { ViewData["message"] = OTPResponse.Split('|')[1]; return View("message"); }

                model.ApplicationNo = AppNo.ToString();
                string[] Val = Utility.SelectColumnsValue("usermaster", "dbo.udf_general_decrypt(useraadhaarno) as useraadhaarno,username", "userid", Sessions.getEmployeeUser().UserId);
                model.UserAadhaarNo = Utility.ConvertNumbertoFormat(Val[0]);
                model.UserName = Val[1].Trim();
                model.ApplicationNo = AppNo.ToString();

                if (Attempt == 0) { model.EsignAttempt = (int)CountList.Type001; } else { model.EsignAttempt = Attempt; }
                if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
                return View(model);
            }
            catch
            {
                return RedirectToAction("DigitalProcessError", "Error");
            }
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult InitializeDocumentESign(SignModels model)
        {
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                GetData data = new GetData();

                model.ServiceCode = Utility.SelectColumnsValue("ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationNo)[0];
                int StatusId = Utility.GetStatusAfterApproval(model.ServiceCode, false);
                if (!Utility.CheckCurrentStatusBeforeUpdate(model.ApplicationNo, StatusId, (int)CountList.Type001))
                {
                    ViewData["message"] = "Application is not pending at this level anymore. Kindly contact to Administrator.";
                    return View("message");
                }

                // save file on disk in PDF formay from byte array
                Utility.SaveAndDisplayUnsignedFileForDocumentESign(Convert.ToInt64(model.ApplicationNo));

                // insert signed document byte array and transaction log
                string OTPResponse = Utility.ProcessEsignRequest((int)ValueId.EsignPDF, null, Convert.ToInt64(model.ApplicationNo), Convert.ToInt32(model.EsignOTP));
                if (OTPResponse.Split('|')[0] == ((int)CountList.Type000).ToString()) { ViewData["message"] = OTPResponse.Split('|')[1]; return View("message"); }

                string Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", StatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "update applicationdetails set applicationstatusid=@applicationstatusid,AcceptedBy=@AcceptedBy,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where applicationno=@applicationno";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@applicationstatusid", StatusId);
                Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationNo, StatusId, (int)CountList.Type001, DB.LS.ToString()));
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "delete from dsgn.tempdigitaldatadetails where applicationno=@applicationno;";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationNo);
                cmdList.Add(Cmd);

                //insert in application audit trail
                cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG005, null, (int)ApplicationSource.Window, null));

                //send sms to applicant and insert record in table
                Dictionary<string, string> smsDic = new Dictionary<string, string>();
                smsDic.Add("ParamApplicationNo", model.ApplicationNo);
                cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS003, smsDic));

                //send email to applicant and insert record in table
                Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS003).ToString());
                EmailDic.Add("ParamApplicationNo", model.ApplicationNo);
                NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                if (EmailCmd != null) { cmdList.Add(EmailCmd); }

                data.SaveData(cmdList);

                Utility.PreserveSessionState(KeyName._Key08, null, true, false);
                ViewData["message"] = "Certificate [" + model.ApplicationNo + "] has been signed successfully";
                return View("message");
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult DocumentESignRedirection(SignModels model)
        {
            if (model.EsignAttempt == (int)CountList.Type000)
            {
                ViewData["message"] = "Session Timed out! Please retry later!"; return View("message");
            }

            model.EsignAttempt = model.EsignAttempt + 1;
            PreserveModelState(Constant._ActionMessage, "OTP Resend successfully", false, true);

            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo", "Attempt" }, new ArrayList() { model.ApplicationNo, model.EsignAttempt });
            return RedirectToAction("InitializeDocumentESign", "Sign", new { q = QueryString });

        }
        #endregion

        #region global method current contoller
        //method for preserve nodel state
        public void PreserveModelState(string Key, object obj, bool IsKeep, bool IsRemove)
        {
            
            if (IsRemove == true) { TempData.Remove(Key); }
            if (obj != null) { TempData[Key] = obj; }
            if (IsKeep == true) { TempData.Keep(Key); }
        }
        #endregion global method current contoller

        #region Deleted Record signing module
        //[EncryptedActionParameter]
        //public ActionResult InitializeRecordSign(Int64? AppNo)
        //{
        //    try
        //    {
        //        if (Utility.PreserveSessionState(KeyName._Key07, null, false, true) == true) { 
        //            ViewData["message"] = "Another digital sign is already in-processing in another window and new request can not be start untill finish the exisitng request."; 
        //            return View("message"); 
        //        }
        //        Utility.PreserveSessionState(KeyName._Key07, AppNo, false, false);

        //        GetData data = new GetData();
        //        SignModels model = new SignModels();
        //        List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
        //        model.ApplicationNo = AppNo.ToString();
        //        model.UserId = Sessions.getEmployeeUser().UserId;

        //        //process to find out data for record sign
        //        string UnsignedData = DigitalSignatureData.GetUnsignedData(Convert.ToInt64(model.ApplicationNo));
        //        if (string.IsNullOrEmpty(UnsignedData)) {
        //            Utility.PreserveSessionState(KeyName._Key07, null, true, false);
        //            ViewData["message"] = "Oopos...application details are incomplete for digital sign, Please try again later.";
        //            return View("message");
        //        }

        //        //process to create file for record sign
        //        model.DownloadFileUrl = Utility.SaveAndDisplayFileForRecordSign(UnsignedData);
        //        if (string.IsNullOrEmpty(model.DownloadFileUrl)) {
        //            Utility.PreserveSessionState(KeyName._Key07, null, true, false);
        //            ViewData["message"] = "Oopos...your system not accepting the digital sign request, Please try again later.";
        //            return View("message");
        //        }

        //        //get unsigned document pdf buffer
        //        byte[] PdfBuffer = null;
        //        SignModels model1 = DigitalSignatureData.GetModelForCertificateView(Convert.ToInt64(model.ApplicationNo));
        //        if (model1.dataa != null) {
        //            PdfBufferGenerator objBuffer = new PdfBufferGenerator();
        //            PdfBuffer = objBuffer.GetPdfBuffer(this, string.Empty, model1.ViewName, model1);
        //        }

        //        //delete data from dsgn.tempsignedrecord and dsgn.digitaldatadetails
        //        //string Qry = "delete from dsgn.tempsignedrecord where applicationno=@applicationno and datatypeid=@datatypeid;delete from dsgn.tempdigitaldatadetails where applicationno=@applicationno;delete from dsgn.digitaldatadetails where applicationno=@applicationno and whetherdatasigned=@whetherdatasigned;";
        //        string Qry = "delete from dsgn.tempsignedrecord where applicationno=@applicationno and datatypeid=@datatypeid;delete from dsgn.tempdigitaldatadetails where applicationno=@applicationno;";
        //        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationNo);
        //        Cmd.Parameters.AddWithValue("@datatypeid", (int)SigningType.SignedRecord);
        //        Cmd.Parameters.AddWithValue("@whetherdatasigned", CustomText.FALSE.ToString());
        //        cmdList.Add(Cmd);

        //        ////save the data in dsgn.digitaldatadetails
        //        //Qry = "insert into dsgn.digitaldatadetails (applicationno,unsigneddata,whetherdatasigned) values(@applicationno,@unsigneddata,@whetherdatasigned)";
        //        //Cmd = new NpgsqlCommand(Qry);
        //        //Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationNo);
        //        //Cmd.Parameters.AddWithValue("@unsigneddata", UnsignedData);
        //        //Cmd.Parameters.AddWithValue("@whetherdatasigned", CustomText.FALSE.ToString());
        //        //cmdList.Add(Cmd);

        //        if (model1.dataa != null)
        //        {
        //            //save the data in dsgn.tempdigitaldatadetails
        //            Qry = "insert into dsgn.tempdigitaldatadetails (applicationno,unsigneddocument,actionby,ipaddress) values(@applicationno,@unsigneddocument,@actionby,@ipaddress)";
        //            Cmd = new NpgsqlCommand(Qry);
        //            Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationNo);
        //            Cmd.Parameters.AddWithValue("@unsigneddocument", PdfBuffer);
        //            Cmd.Parameters.AddWithValue("@actionby", model.UserId);
        //            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
        //            cmdList.Add(Cmd);
        //        }
        //        data.SaveData(cmdList);

        //        //return view and initialize the data in sign mode
        //        Qry = "select dc.cardpath,dc.exefilepath,dc.cardtypename,dc.jarrecordname,dc.jarrecordlogin,dc.jarrecordbulk from usermaster um inner join userdigitalmaster ud on ud.userid=um.userid inner join digitalcardtypemaster dc on dc.cardtypeid=um.cardtypeid where um.userid=@userid and ud.whetheractive=@whetheractive";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@userid", model.UserId);
        //        Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
        //        model.DigitalCardTypeMaster = DigitalCardTypeMaster.Get<DigitalCardTypeMaster>(new DigitalCardTypeMaster(), Cmd);

        //        Qry = "select userid ,username ,serialno ,certificatechain ,validfrom ,validto ,whetheractive ,deactivatedate ,actionuserid ,ipaddress ,actiondatetime from userdigitalmaster where userid=@userid and whetheractive=@whetheractive";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@userid", model.UserId);
        //        Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
        //        model.UserDigitalMaster = UserDigitalMaster.Get<UserDigitalMaster>(new UserDigitalMaster(), Cmd);

        //        string domainName = new Uri(Request.Url.AbsoluteUri).GetLeftPart(UriPartial.Authority);
        //        model.ReturnUrl = domainName.Replace("http://", "") + "/in/en/Sign/GetSignedFile.html?AppNo=" + model.ApplicationNo + "&Uid=" + model.UserId;
        //        return View(model);
        //    }
        //    catch(Exception ex)
        //    {
        //        Utility.PreserveSessionState(KeyName._Key07, null, true, false);
        //        return RedirectToAction("DigitalProcessError", "Error");
        //    }
        //}
        //[AllowAnonymous]
        //public ActionResult GetSignedFile(Int64 AppNo, string Uid)
        //{
        //    try
        //    {
        //        byte[] FileBytes = null;
        //        string FileName = string.Empty;
        //        foreach (string RequestKey in Request.Files.AllKeys)
        //        {
        //            HttpPostedFileBase RequestFile = Request.Files[RequestKey];
        //            FileName = RequestFile.FileName.ToString();
        //            using (var br = new BinaryReader(Request.Files[RequestKey].InputStream))
        //            {
        //                FileBytes = br.ReadBytes(Request.Files[RequestKey].ContentLength);
        //            }
        //        }

        //        GetData data = new GetData();
        //        string Qry = "insert into dsgn.tempsignedrecord(applicationno,datatypeid,filedata,userid) values(@applicationno,@datatypeid,@filedata,@userid)";
        //        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@applicationno", AppNo);
        //        Cmd.Parameters.AddWithValue("@datatypeid", (int)SigningType.SignedRecord);
        //        Cmd.Parameters.AddWithValue("@filedata", FileBytes);
        //        Cmd.Parameters.AddWithValue("@userid", Uid);
        //        data.UpdateData(Cmd);

        //        return new EmptyResult();
        //    }
        //    catch
        //    {
        //        return new EmptyResult();
        //    }
        //}
        //[AcceptVerbs(HttpVerbs.Post)]
        //[ValidateAntiForgeryToken]
        //[ValidateOnlyIncomingValues]
        //public ActionResult FinalizeRecordSign(SignModels model)
        //{
        //    try
        //    {
        //        GetData data = new GetData();
        //        string Qry = string.Empty;
        //        NpgsqlCommand Cmd = new NpgsqlCommand();
        //        model.UserId = Sessions.getEmployeeUser().UserId;
        //        List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

        //        bool WhetherExist = Utility.CheckSignedData(model.ApplicationNo, model.UserId, (int)SigningType.SignedRecord);
        //        if (WhetherExist == false) {
        //            Utility.PreserveSessionState(KeyName._Key07, null, true, false);
        //            return RedirectToAction("DigitalProcessError", "Error");
        //        }

        //        //Qry = "update dsgn.digitaldatadetails set whetherdatasigned=@uwhetherdatasigned,signeddata=dsgn.tempsignedrecord.filedata,datasigneddate=now(),datasignedby=@userid,ipaddress=@ipaddress from dsgn.tempsignedrecord where dsgn.tempsignedrecord.applicationno=dsgn.digitaldatadetails.applicationno and dsgn.digitaldatadetails.applicationno=@applicationno and dsgn.tempsignedrecord.userid=@userid and dsgn.tempsignedrecord.datatypeid=@datatypeid and dsgn.digitaldatadetails.whetherdatasigned=@swhetherdatasigned";
        //        //Cmd = new NpgsqlCommand(Qry);
        //        //Cmd.Parameters.AddWithValue("@uwhetherdatasigned", CustomText.TRUE.ToString());
        //        //Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationNo);
        //        //Cmd.Parameters.AddWithValue("@userid", model.UserId);
        //        //Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
        //        //Cmd.Parameters.AddWithValue("@swhetherdatasigned", CustomText.FALSE.ToString());
        //        //Cmd.Parameters.AddWithValue("@datatypeid", (int)SigningType.SignedRecord);
        //        //cmdList.Add(Cmd);

        //        model.ServiceCode = Utility.SelectColumnsValue("ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationNo)[0];
        //        int StatusId = Utility.GetStatusAfterApproval(model.ServiceCode, true);

        //        if (!Utility.CheckCurrentStatusBeforeUpdate(model.ApplicationNo, StatusId, (int)CountList.Type001))
        //        {
        //            ViewData["message"] = "Application is not pending at this level anymore!";
        //            return View("message");
        //        }

        //        Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationStatusId", StatusId);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
        //        Cmd.Parameters.AddWithValue("@userid", model.UserId);
        //        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
        //        cmdList.Add(Cmd);

        //        Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,approveddate=now(),userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationStatusId", StatusId);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
        //        Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationNo, StatusId, (int)CountList.Type001, DB.LS.ToString()));
        //        Cmd.Parameters.AddWithValue("@userid", model.UserId);
        //        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
        //        cmdList.Add(Cmd);

        //        Qry = "delete from dsgn.tempsignedrecord where applicationno=@applicationno and datatypeid=@datatypeid";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationNo);
        //        Cmd.Parameters.AddWithValue("@datatypeid", (int)SigningType.SignedRecord);
        //        Cmd.Parameters.AddWithValue("@userid", model.UserId);
        //        cmdList.Add(Cmd);

        //        //Update approval caste details in castemaster table (OBC,SC,ST)
        //        NpgsqlCommand CmdUpdateAddData = Utility.UpdateDataAfterApproval(model.ApplicationNo);
        //        if (CmdUpdateAddData != null) { cmdList.Add(CmdUpdateAddData); }

        //        //insert in application audit trail
        //        cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG002, null, (int)ApplicationSource.Window, null));

        //        data.SaveData(cmdList);
        //        PreserveModelState(Constant._ActionMessage, "Application has been approved successfully.", false, true);

        //        Utility.PreserveSessionState(KeyName._Key07, null, true, false);
        //        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.TEHSPEN).ToString() });
        //        return RedirectToAction(Utility.GetDecisionControllerName(Sessions.getEmployeeUser().DeptCode, null, ((int)CountList.Type002).ToString()), "Decision", new { q = QueryString });
        //    }
        //    catch
        //    {
        //        Utility.PreserveSessionState(KeyName._Key07, null, true, false);
        //        return RedirectToAction("DigitalProcessError", "Error");
        //    }
        //}
        #endregion
    }
}
