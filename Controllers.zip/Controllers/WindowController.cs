﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models;
using System.Data.SqlClient;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using System.Data;
using Edistrict.Models.Entities;
using Npgsql;
using Edistrict.Models.CustomClass;
using System.Collections;

namespace Edistrict.Controllers
{
    [Authorize(Roles = "101,121,136")]
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class WindowController : Controller
    {
        public ActionResult DpRecieveFeeFromCitizen()
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.WIND).ToString() && Sessions.getEmployeeUser().Permission != ((int)Permission.P121).ToString() && Sessions.getEmployeeUser().Permission != ((int)Permission.P136).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

            WindowModels model = new WindowModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult DpRecieveFeeFromCitizen(WindowModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppId" }, new ArrayList() { model.ApplicationId });
                return RedirectToAction("DpRecieveFeeFromCitizenDetails", "Window", new { q = QueryString });
            }
            return View("DpRecieveFeeFromCitizen", model);
        }
        [EncryptedActionParameter]
        public ActionResult DpRecieveFeeFromCitizenDetails(Int32 AppId)
        {
            GetData data = new GetData();
            WindowModels model = new WindowModels();
            model.ApplicationId = AppId;

            string addScript = Utility.GetScriptForAuthorizationProcess();
            //string Qry = "select ApplicationStatusId,ApplicationSubDivCode,OfficeCode,receiveduser,receivedpermission from  web.ApplicationDetails where ApplicationId=@ApplicationId";
            string Qry = "select AD.ApplicationStatusId,AD.ApplicationSubDivCode,AD.OfficeCode,AD.receiveduser,AD.receivedpermission from  web.ApplicationDetails AD inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where AD.ApplicationId=@ApplicationId and SM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode)" + addScript;
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationId);
            DataTable dtsubDiv = data.GetDataTable(Cmd);
            if (dtsubDiv.Rows.Count == (int)CountList.Type000)
            {
                ModelState.AddModelError(string.Empty, "Entered application not found at e-Disrict portal delhi.");
                return View("DpRecieveFeeFromCitizen", model);
            }
            if (Convert.ToInt32(dtsubDiv.Rows[0]["ApplicationStatusId"].ToString()) != (int)Status.SCOM034)
            {
                ModelState.AddModelError(string.Empty, "Entered application not pending for Fee collection.");
                return View("DpRecieveFeeFromCitizen", model);
            }

            if (Convert.ToInt32(dtsubDiv.Rows[0]["receivedpermission"].ToString()) == (int)Permission.P136 && dtsubDiv.Rows[0]["receiveduser"].ToString() != Sessions.getEmployeeUser().UserId)
            {
                ModelState.AddModelError(string.Empty, "Entered application not pending for Fee in your account.");
                return View("DpRecieveFeeFromCitizen", model);
            }

            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000)
            {
                if (Convert.ToInt32(dtsubDiv.Rows[0]["OfficeCode"].ToString()) != Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId))
                {
                    ModelState.AddModelError(string.Empty, "Entered application not pending for Fee Receiving in your account.");
                    return View("DpRecieveFeeFromCitizen", model);
                }
            }
            else
            {
                if (Sessions.getEmployeeUser().Permission != ((int)Permission.P136).ToString())
                {
                    if (Convert.ToInt32(dtsubDiv.Rows[0]["ApplicationSubDivCode"].ToString()) != Convert.ToInt32(Sessions.getEmployeeUser().SubDivCode) || Convert.ToInt32(dtsubDiv.Rows[0]["OfficeCode"].ToString()) != Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId))
                    {
                        ModelState.AddModelError(string.Empty, "Entered application not pending for Fee in this Subdivision.");
                        return View("DpRecieveFeeFromCitizen", model);
                    }
                }
            }

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationId.ToString(), DB.RS.ToString());
            model.ApplicantDetails.ServiceCode = Utility.SelectColumnsValue("web.ApplicationDetails", "ServiceCode", "ApplicationId", model.ApplicationId.ToString())[0];
            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "ApplicationEnclosure", string.Empty, string.Empty, model.ApplicantDetails.ApplicationId.ToString(), DB.RS.ToString(), CustomText.N.ToString());
            ViewData[KeyName._Key01] = Utility.GetFeeDetails(model.ApplicationId.ToString(), DB.RS.ToString(), true, CustomText.FALSE.ToString());

            if (Convert.ToInt16(model.ApplicantDetails.ServiceCode) == (int)ServiceList.Marriage)
            {
                model.ApplicationMarriageDetails = Utility.GetMarriageDetails(model.ApplicantDetails.ApplicationId.ToString(), DB.RS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicantDetails.ServiceCode) == (int)ServiceList.Solemnization)
            {
                model.ApplicationMarriageDetails = Utility.GetMarriageSolemnizationDetails(model.ApplicantDetails.ApplicationId.ToString(), DB.RS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicantDetails.ServiceCode) == (int)ServiceList.ConstructionWorker)
            {
                model.ApplicationDetailsConsWorker = Utility.GetConsWorkerDetails(model.ApplicantDetails.ApplicationId.ToString(), DB.RS.ToString());

                Qry = "select UM.UserId,UserName,designation,case when Gender='M' then 'Male' when Gender='F' then 'Female' end as Gender,to_char(DateofBirth,'DD/MM/YYYY') as DateofBirth,ContactNo,Pname as PermissionType,DistrictName,SubDivdescription,SMVD.ValueName as AuthenticationType,UM.AuthenticationTypeId,SMVDD.ValueName as SigningType,usertimefrom::text,usertimeto::text,to_char(CreateDate,'DD/MM/YYYY') as CreateDate,to_char(LastPassowrdChange,'DD/MM/YYYY') as LastPassowrdChange  from usermaster UM inner join PermissionMaster PM on PM.Pcode=UM.Permission inner join SelectMasterValueDetails SMVD on SMVD.ValueId=UM.AuthenticationTypeId inner join SelectMasterValueDetails SMVDD on SMVDD.ValueId=UM.SigningTypeId left outer join DistrictMaster DM on DM.DistrictCode=UM.DistrictCode left outer join usertosubdivmaster USDM on USDM.Uid=UM.Uid and USDM.WhetherActive=@WhetherActive  left outer join subdivmaster SDM on SDM.SubDivCode=USDM.SubDivCode  where UM.UserId=@UserId  ";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                model.dataa = data.GetDataTable(Cmd);
            }
            else if (Convert.ToInt16(model.ApplicantDetails.ServiceCode) == (int)ServiceList.RenewalConsWorker)
            {
                model.RenewalConsWorker = Utility.GetRenewalConsWorkerDetails(model.ApplicantDetails.ApplicationId.ToString(), DB.RS.ToString());

                Qry = "select UM.UserId,UserName,designation,case when Gender='M' then 'Male' when Gender='F' then 'Female' end as Gender,to_char(DateofBirth,'DD/MM/YYYY') as DateofBirth,ContactNo,Pname as PermissionType,DistrictName,SubDivdescription,SMVD.ValueName as AuthenticationType,UM.AuthenticationTypeId,SMVDD.ValueName as SigningType,usertimefrom::text,usertimeto::text,to_char(CreateDate,'DD/MM/YYYY') as CreateDate,to_char(LastPassowrdChange,'DD/MM/YYYY') as LastPassowrdChange  from usermaster UM inner join PermissionMaster PM on PM.Pcode=UM.Permission inner join SelectMasterValueDetails SMVD on SMVD.ValueId=UM.AuthenticationTypeId inner join SelectMasterValueDetails SMVDD on SMVDD.ValueId=UM.SigningTypeId left outer join DistrictMaster DM on DM.DistrictCode=UM.DistrictCode left outer join usertosubdivmaster USDM on USDM.Uid=UM.Uid and USDM.WhetherActive=@WhetherActive  left outer join subdivmaster SDM on SDM.SubDivCode=USDM.SubDivCode  where UM.UserId=@UserId  ";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                model.dataa = data.GetDataTable(Cmd);
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Entered application not eligible for offline fee.");
                return View("DpRecieveFeeFromCitizen", model);
            }

            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View("DpSaveFeeFromCitizen", model);                

        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DpSaveFeeFromCitizen(WindowModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                List<NpgsqlCommand> cmdListAdd = new List<NpgsqlCommand>();

                string Qry = "select RegistrationId,dbo.udf_general_decrypt(DocumentNo) as DocumentNo,DocumentId,ApplicationId,ServiceCode,ApplicationStatusId,ApplicationRelatedId,ApplicantName,ApplicantGender,ApplicantFatherName,ApplicantMotherName,ApplicantHusbandName,ApplicantMobileNo,ApplicantHousenumber,ApplicantStreetnumber,ApplicantSublocality,stateid,countryid,ApplicantPinCode,to_char(ApplicantDob,'DD/MM/YYYY') as ApplicantDob,ApplicantLocalityId,applicantsubdivcode,ApplicantDistrictCode,ApplicantNationality,applicationsubdivcode,applicationdistrictcode,ApplicantPermanentAddress,WhetherSameAddress,officecode,receiveduser,receivedpermission FROM web.ApplicationDetails where ApplicationId=@ApplicationId";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationId);
                model.ApplicationDetails = ApplicationDetails.Get<ApplicationDetails>(new ApplicationDetails(), Cmd);

                if (model.ApplicationDetails.ApplicationStatusId != ((int)Status.SCOM034).ToString())
                {
                    ViewBag.DisplayMessage = "This Application is not pending to receive fee";
                    return View("DpRecieveFeeFromCitizen", model);
                }
                model.ApplicationDetails.ApplicationStatusId = ((int)Status.DEALOLR).ToString();

                string q = Utility.CheckLocalityActivation(model.ApplicationId.ToString(), DB.RS.ToString());
                if (!string.IsNullOrEmpty(q)) { ViewData["Message"] = q; return View("Message"); }

                //fee calculation details
                Dictionary<string, string> Data = new Dictionary<string, string>();
                Data["ServiceCode"] = model.ApplicationDetails.ServiceCode;
                Data["ApplicationId"] = model.ApplicationId.ToString();
                Data["FeeValue"] = model.FeeAmount;
                Data["ServerType"] = DB.RS.ToString();

                if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.RenewalConsWorker).ToString()) {
                    Data["OldLicenceNo"] = Utility.SelectColumnsValue("wgen.applicationdetailsrenewalconsworker", "RegistrationNo", "ApplicationId", model.ApplicationDetails.ApplicationId.ToString())[0];
                    Data["MatchType"] = CountList.Type005.ToString();
                } else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.ConstructionWorker).ToString()) {
                    Data["MatchType"] = CountList.Type006.ToString();
                } else { Data["MatchType"] = CountList.Type003.ToString(); }

                string[] returnValues = Utility.GetApplicationFeeFlags(Data);
                if (returnValues[2] == CustomText.False.ToString())
                {
                    ViewBag.DisplayMessage = "The entered Fee does not matched with expected fee.\\n Kindly check and try again.";
                    PreserveModelState(Constant._ModelStateParent, null, true, false);
                    return View("DpRecieveFeeFromCitizen", (WindowModels)TempData[Constant._ModelStateParent]);
                }

                // insert photo in foreign server and generate refphotoid for further use
                Utility.InsertPhotoMasterWeb(model.ApplicationDetails.ApplicationId.ToString());

                //select data from citizen ApplicationPhotoMaster
                Qry = "select PhotoId,refphotoid,RelatedId,WhetherActive from web.ApplicationPhotoMaster where ApplicationId=@ApplicationId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationDetails.ApplicationId);
                DataTable dtPhoto = data.GetDataTable(Cmd);

                //select data from citizen ApplicationEnclosureDetails
                Qry = "select ServiceCode,DocumentTypeId,DocumentId,dbo.udf_general_decrypt(DocumentNo) as DocumentNo,DocumentData,ContentType,DepartmentId,OtherDepartment,RelatedId,WhetherVerified,WhetherActive,WhetherMandatory,ReferenceEnclosureId from web.ApplicationEnclosureDetails where ApplicationId=@ApplicationId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationDetails.ApplicationId);
                DataTable dtEnclosure = data.GetDataTable(Cmd);

                //Genearte 14 digit Application No
                Qry = "select (cast(@ServiceCode as varchar) || case when length(MaxAppNo)=1 then ('000000000' || MaxAppNo) when length(MaxAppNo)=2 then ('00000000' || MaxAppNo) when length(MaxAppNo)=3 then ('0000000'|| MaxAppNo) when length(MaxAppNo)=4 then ('000000' || MaxAppNo) when length(MaxAppNo)=5 then ('00000' || MaxAppNo) when length(MaxAppNo)=6 then ('0000' || MaxAppNo) when length(MaxAppNo)=7 then ('000' || MaxAppNo) when length(MaxAppNo)=8 then ('00' || MaxAppNo) when length(MaxAppNo)=9 then ('0' || MaxAppNo) else MaxAppNo end) as ApplicationNo from (select  CAST(CAST(right(coalesce(MAX(ApplicationNo)::varchar,0::varchar),10) as Bigint)+1 as varchar) as MaxAppNo FROM dbo.ApplicationDetails where ServiceCode=@ServiceCode) RS";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ServiceCode", model.ApplicationDetails.ServiceCode);
                cmdList.Add(Cmd);

                //insert data in intra ApplicationDetails
                Qry = "insert into dbo.ApplicationDetails(RegistrationId,DocumentNo,DocumentId,ApplicationNo,ServiceCode,ApplicationSourceId,ApplicationRelatedId,ApplicantName,ApplicantGender,ApplicantFatherName,ApplicantMotherName,ApplicantHusbandName,ApplicantMobileNo,ApplicantHousenumber,ApplicantStreetnumber,ApplicantSublocality,stateid,countryid,ApplicantPinCode,ApplicantDob,ApplicantLocalityId,ApplicantSubDivCode,ApplicantDistrictCode,ApplicantNationality,ApplicationStatusId,applicationsubdivcode,applicationdistrictcode,ApplicationDate,ApplicantPermanentAddress,WhetherSameAddress,OfficeCode,AcceptedBy,receiveduser,receivedpermission,userid,ipaddress,lastactiondate) values(@RegistrationId,dbo.udf_general_encrypt(@DocumentNo),@DocumentId,@LastInsertedId,@ServiceCode,@ApplicationSourceId,@ApplicationRelatedId,@ApplicantName,@ApplicantGender,@ApplicantFatherName,@ApplicantMotherName,@ApplicantHusbandName,@ApplicantMobileNo,@ApplicantHousenumber,@ApplicantStreetnumber,@ApplicantSublocality,@stateid,@countryid,@ApplicantPinCode,@ApplicantDob,@ApplicantLocalityId,@ApplicantSubDivCode,@ApplicantDistrictCode,@ApplicantNationality,@ApplicationStatusId,@applicationsubdivcode,@applicationdistrictcode,now(),@ApplicantPermanentAddress,@WhetherSameAddress,@OfficeCode,@AcceptedBy,@receiveduser,@receivedpermission,@userid,@ipaddress,now())";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RegistrationId", model.ApplicationDetails.RegistrationId);
                Cmd.Parameters.AddWithValue("@ServiceCode", model.ApplicationDetails.ServiceCode);
                Cmd.Parameters.AddWithValue("@DocumentId", model.ApplicationDetails.DocumentId);
                Cmd.Parameters.AddWithValue("@DocumentNo", model.ApplicationDetails.DocumentNo);
                Cmd.Parameters.AddWithValue("@ApplicationSourceId", (int)ApplicationSource.Online);
                Cmd.Parameters.AddWithValue("@ApplicationRelatedId", model.ApplicationDetails.ApplicationRelatedId);
                Cmd.Parameters.AddWithValue("@ApplicantName", model.ApplicationDetails.ApplicantName.ToUpper());
                Cmd.Parameters.AddWithValue("@ApplicantGender", model.ApplicationDetails.ApplicantGender.ToUpper());
                Cmd.Parameters.AddWithValue("@ApplicantFatherName", model.ApplicationDetails.ApplicantFatherName.ToUpper());
                Cmd.Parameters.AddWithValue("@ApplicantMotherName", model.ApplicationDetails.ApplicantMotherName.ToUpper());
                Cmd.Parameters.AddWithValue("@ApplicantHusbandName", model.ApplicationDetails.ApplicantHusbandName);
                Cmd.Parameters.AddWithValue("@ApplicantMobileNo", model.ApplicationDetails.ApplicantMobileNo);
                Cmd.Parameters.AddWithValue("@ApplicantHousenumber", model.ApplicationDetails.ApplicantHouseNumber);
                Cmd.Parameters.AddWithValue("@ApplicantStreetnumber", model.ApplicationDetails.ApplicantStreetNumber);
                Cmd.Parameters.AddWithValue("@ApplicantSublocality", model.ApplicationDetails.ApplicantSubLocality);
                Cmd.Parameters.AddWithValue("@stateid", model.ApplicationDetails.StateId);
                Cmd.Parameters.AddWithValue("@countryid", model.ApplicationDetails.CountryId);
                Cmd.Parameters.AddWithValue("@ApplicantPinCode", model.ApplicationDetails.ApplicantPinCode);
                Cmd.Parameters.AddWithValue("@ApplicantDob", Utility.GetDateYYYYMMDD(model.ApplicationDetails.ApplicantDob, '/', "0/1/2"));
                Cmd.Parameters.AddWithValue("@ApplicantLocalityId", model.ApplicationDetails.ApplicantLocalityId);
                Cmd.Parameters.AddWithValue("@ApplicantSubDivCode", model.ApplicationDetails.ApplicantSubDivCode);
                Cmd.Parameters.AddWithValue("@ApplicantDistrictCode", model.ApplicationDetails.ApplicantDistrictCode);
                Cmd.Parameters.AddWithValue("@ApplicantNationality", model.ApplicationDetails.ApplicantNationality);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@applicationsubdivcode", model.ApplicationDetails.ApplicationSubDivCode);
                Cmd.Parameters.AddWithValue("@applicationdistrictcode", model.ApplicationDetails.ApplicationDistrictCode);
                Cmd.Parameters.AddWithValue("@ApplicantPermanentAddress", model.ApplicationDetails.ApplicantPermanentAddress);
                Cmd.Parameters.AddWithValue("@WhetherSameAddress", model.ApplicationDetails.WhetherSameAddress);
                Cmd.Parameters.AddWithValue("@OfficeCode", model.ApplicationDetails.OfficeCode);
                Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationDetails.ApplicationId.ToString(), Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId), (int)CountList.Type001, DB.RS.ToString()));
                Cmd.Parameters.AddWithValue("@receiveduser", model.ApplicationDetails.ReceivedUser);
                Cmd.Parameters.AddWithValue("@receivedpermission", model.ApplicationDetails.ReceivedPermission);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                // insert data in intra ApplicationPhotoMaster
                for (int i = 0; i < dtPhoto.Rows.Count; i++)
                {
                    Qry = "insert into dbo.ApplicationPhotoMaster(ApplicationNo,refphotoid,RelatedId,WhetherActive,userid,ipaddress,lastactiondate) values(@LastInsertedId,@refphotoid,@RelatedId,@WhetherActive,@userid,@ipaddress,now())";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@refphotoid", dtPhoto.Rows[i]["refphotoid"]);
                    Cmd.Parameters.AddWithValue("@RelatedId", dtPhoto.Rows[i]["RelatedId"]);
                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                }

                //delete optional data from citizen ApplicationEnclosureDetails
                Qry = "delete from web.ApplicationEnclosureDetails where enclosureid in (select enclosureid from web.ApplicationEnclosureDetails aed, servicetodocumentmaster sdm where aed.servicecode=sdm.servicecode and aed.documenttypeid=sdm.documenttypeid and WhetherOptional=@WhetherOptional and ApplicationId=@ApplicationId and DocumentData is null and aed.WhetherActive=@WhetherActive)";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationDetails.ApplicationId);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.FALSE.ToString());
                Cmd.Parameters.AddWithValue("@WhetherOptional", CustomText.TRUE.ToString());
                cmdList.Add(Cmd);

                //insert data in intra ApplicationEnclosureDetails
                for (int i = 0; i < dtEnclosure.Rows.Count; i++)
                {
                    Qry = "insert into dbo.ApplicationEnclosureDetails(ApplicationNo,ServiceCode,DocumentTypeId,DocumentId,DocumentNo,DocumentData,DepartmentId,OtherDepartment,ContentType,RelatedId,WhetherVerified,WhetherActive,WhetherMandatory,ReferenceEnclosureId,userid,ipaddress,lastactiondate) values(@LastInsertedId,@ServiceCode,@DocumentTypeId,@DocumentId,dbo.udf_general_encrypt(@DocumentNo),@DocumentData,@DepartmentId,@OtherDepartment,@ContentType,@RelatedId,@WhetherVerified,@WhetherActive,@WhetherMandatory,@ReferenceEnclosureId,@userid,@ipaddress,now())";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ServiceCode", dtEnclosure.Rows[i]["ServiceCode"].ToString());
                    Cmd.Parameters.AddWithValue("@DocumentTypeId", dtEnclosure.Rows[i]["DocumentTypeId"].ToString());
                    Cmd.Parameters.AddWithValue("@DocumentId", (string.IsNullOrEmpty(dtEnclosure.Rows[i]["DocumentId"].ToString())) ? null : dtEnclosure.Rows[i]["DocumentId"].ToString());
                    Cmd.Parameters.AddWithValue("@DocumentNo", (string.IsNullOrEmpty(dtEnclosure.Rows[i]["DocumentNo"].ToString())) ? null : dtEnclosure.Rows[i]["DocumentNo"].ToString());
                    Cmd.Parameters.AddWithValue("@DocumentData", dtEnclosure.Rows[i]["DocumentData"] == DBNull.Value ? null : (byte[])dtEnclosure.Rows[i]["DocumentData"]);
                    Cmd.Parameters.AddWithValue("@ContentType", (string.IsNullOrEmpty(dtEnclosure.Rows[i]["ContentType"].ToString())) ? null : dtEnclosure.Rows[i]["ContentType"].ToString());
                    Cmd.Parameters.AddWithValue("@DepartmentId", (string.IsNullOrEmpty(dtEnclosure.Rows[i]["DepartmentId"].ToString())) ? null : dtEnclosure.Rows[i]["DepartmentId"].ToString());
                    Cmd.Parameters.AddWithValue("@OtherDepartment", (string.IsNullOrEmpty(dtEnclosure.Rows[i]["OtherDepartment"].ToString())) ? null : dtEnclosure.Rows[i]["OtherDepartment"].ToString());
                    Cmd.Parameters.AddWithValue("@RelatedId", dtEnclosure.Rows[i]["RelatedId"]);
                    Cmd.Parameters.AddWithValue("@WhetherVerified", dtEnclosure.Rows[i]["WhetherVerified"].ToString());
                    Cmd.Parameters.AddWithValue("@WhetherActive", dtEnclosure.Rows[i]["WhetherActive"].ToString());
                    Cmd.Parameters.AddWithValue("@WhetherMandatory", dtEnclosure.Rows[i]["WhetherMandatory"].ToString());
                    Cmd.Parameters.AddWithValue("@ReferenceEnclosureId", dtEnclosure.Rows[i]["ReferenceEnclosureId"]);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                }

                //insert data in intra ApplicationMarriageDetails
                if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Marriage).ToString())
                {
                    Qry = "select HDocumentId,dbo.udf_general_decrypt(HAadhaarNo) as HAadhaarNo,HEnrolmentNo,HName,HFatherName,HMotherName,to_char(HDOB,'DD/MM/YYYY') as HDOB,HMaritalStatusId,HNationalityId,Hpmhousenumber,Hpmstreetnumber,Hpmsublocality,Hpmlocalityid,HpmSubDivCode,Hpmdistrictcode,Hpmstateid,Hpmcountryid,Hpmpincode,Hpshousenumber,Hpsstreetnumber,Hpssublocality,Hpslocalityid,HpsSubDivCode,Hpsdistrictcode,Hpsstateid,Hpscountryid,Hpspincode,HEmail,HMobile,WDocumentId,dbo.udf_general_decrypt(WAadhaarNo) as WAadhaarNo,WEnrolmentNo,WName,WFatherName,WMotherName,to_char(WDOB,'DD/MM/YYYY') as WDOB,WMaritalStatusId,WNationalityId,Wpmhousenumber,Wpmstreetnumber,Wpmsublocality,Wpmlocalityid,WpmSubDivCode,Wpmdistrictcode,Wpmstateid,Wpmcountryid,Wpmpincode,Wpshousenumber,Wpsstreetnumber,Wpssublocality,Wpslocalityid,WpsSubDivCode,Wpsdistrictcode,Wpsstateid,Wpscountryid,Wpspincode,WEmail,WMobile,to_char(MarriageDate,'DD/MM/YYYY') as MarriageDate,MarriagePlace,WhetherReligiousMarriage,MarriageReligion,MarriageReligiousPlace,MarriageSubdivCode,MarriageDistrictCode,MarriageStateId,MarriageCountryId,MarriageLocalityId,HReligionId,WReligionId,AppointmentTypeId,AppointmentId,MarriageActId from wgen.ApplicationMarriageDetails where ApplicationId=@ApplicationId";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationDetails.ApplicationId);
                    model.ApplicationMarriageDetails = ApplicationMarriageDetails.Get<ApplicationMarriageDetails>(new ApplicationMarriageDetails(), Cmd);

                    Qry = "select WitnessName,WitnessFatherName,dbo.udf_general_decrypt(WitnessIdentificationNo) as WitnessIdentificationNo,WitnessIdentificationData,WitnessIdentityTypeId,witnesshousenumber,witnessstreetnumber,witnesssublocality,witnesslocalityid,witnesssubdivcode,witnessdistrictcode,witnessstateid,witnesscountryid,witnesspincode,witnesstypeid from wgen.MarriageWitnessMaster where ApplicationId=@ApplicationId";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationDetails.ApplicationId);
                    DataTable dtMarriageWitnessMaster = data.GetDataTable(Cmd);

                    Qry = "insert into dgen.ApplicationMarriageDetails(ApplicationNo,HDocumentId,HAadhaarNo,HEnrolmentNo,HName,HFatherName,HMotherName,HDOB,Hpmhousenumber,Hpmstreetnumber,Hpmsublocality,Hpmlocalityid,Hpmpincode,Hpmsubdivcode,Hpmdistrictcode,Hpmstateid,Hpmcountryid,Hpshousenumber,Hpsstreetnumber,Hpssublocality,Hpslocalityid,Hpspincode,Hpssubdivcode,Hpsdistrictcode,Hpsstateid,Hpscountryid,HMaritalStatusId,HNationalityId,HEmail,HMobile,WDocumentId,WAadhaarNo,WEnrolmentNo,WName,WFatherName,WMotherName,WDOB,WMaritalStatusId,WNationalityId,Wpmhousenumber,Wpmstreetnumber,Wpmsublocality,Wpmlocalityid,Wpmpincode,Wpmsubdivcode,Wpmdistrictcode,Wpmstateid,Wpmcountryid,Wpshousenumber,Wpsstreetnumber,Wpssublocality,Wpslocalityid,Wpspincode,Wpssubdivcode,Wpsdistrictcode,Wpsstateid,Wpscountryid,WEmail,WMobile,MarriageDate,MarriagePlace,WhetherReligiousMarriage,MarriageReligion,MarriageReligiousPlace,MarriageSubdivCode,MarriageDistrictCode,MarriageStateId,MarriageCountryId,MarriageLocalityId,HReligionId,WReligionId,AppointmentTypeId,AppointmentId,MarriageActId,userid,ipaddress,actiondatetime) VALUES(@LastInsertedId,@HDocumentId,dbo.udf_general_encrypt(@HAadhaarNo),@HEnrolmentNo,@HName,@HFatherName,@HMotherName,@HDOB,@Hpmhousenumber,@Hpmstreetnumber,@Hpmsublocality,@Hpmlocalityid,@Hpmpincode,@Hpmsubdivcode,@Hpmdistrictcode,@Hpmstateid,@Hpmcountryid,@Hpshousenumber,@Hpsstreetnumber,@Hpssublocality,@Hpslocalityid,@Hpspincode,@Hpssubdivcode,@Hpsdistrictcode,@Hpsstateid,@Hpscountryid,@HMaritalStatusId,@HNationalityId,@HEmail,@HMobile,@WDocumentId,dbo.udf_general_encrypt(@WAadhaarNo),@WEnrolmentNo,@WName,@WFatherName,@WMotherName,@WDOB,@WMaritalStatusId,@WNationalityId,@Wpmhousenumber,@Wpmstreetnumber,@Wpmsublocality,@Wpmlocalityid,@Wpmpincode,@Wpmsubdivcode,@Wpmdistrictcode,@Wpmstateid,@Wpmcountryid,@Wpshousenumber,@Wpsstreetnumber,@Wpssublocality,@Wpslocalityid,@Wpspincode,@Wpssubdivcode,@Wpsdistrictcode,@Wpsstateid,@Wpscountryid,@WEmail,@WMobile,@MarriageDate,@MarriagePlace,@WhetherReligiousMarriage,@MarriageReligion,@MarriageReligiousPlace,@MarriageSubdivCode,@MarriageDistrictCode,@MarriageStateId,@MarriageCountryId,@MarriageLocalityId,@HReligionId,@WReligionId,@AppointmentTypeId,@AppointmentId,@MarriageActId,@userid,@ipaddress,now())";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@HDocumentId", model.ApplicationMarriageDetails.HDocumentId);
                    Cmd.Parameters.AddWithValue("@HAadhaarNo", model.ApplicationMarriageDetails.HAadhaarNo);
                    Cmd.Parameters.AddWithValue("@HEnrolmentNo", model.ApplicationMarriageDetails.HEnrolmentNo);
                    Cmd.Parameters.AddWithValue("@HName", model.ApplicationMarriageDetails.HName);
                    Cmd.Parameters.AddWithValue("@HFatherName", model.ApplicationMarriageDetails.HFatherName);
                    Cmd.Parameters.AddWithValue("@HMotherName", model.ApplicationMarriageDetails.HMotherName);
                    Cmd.Parameters.AddWithValue("@HDOB", Utility.GetDateYYYYMMDD(model.ApplicationMarriageDetails.HDOB, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@Hpmhousenumber", model.ApplicationMarriageDetails.HpmHouseNumber);
                    Cmd.Parameters.AddWithValue("@Hpmstreetnumber", model.ApplicationMarriageDetails.HpmStreetNumber);
                    Cmd.Parameters.AddWithValue("@Hpmsublocality", model.ApplicationMarriageDetails.HpmSubLocality);
                    Cmd.Parameters.AddWithValue("@Hpmlocalityid", model.ApplicationMarriageDetails.HpmLocalityId);
                    Cmd.Parameters.AddWithValue("@Hpmpincode", model.ApplicationMarriageDetails.Hpmpincode);
                    Cmd.Parameters.AddWithValue("@Hpmsubdivcode", model.ApplicationMarriageDetails.Hpmsubdivcode);
                    Cmd.Parameters.AddWithValue("@Hpmdistrictcode", model.ApplicationMarriageDetails.Hpmdistrictcode);
                    Cmd.Parameters.AddWithValue("@Hpmstateid", model.ApplicationMarriageDetails.HpmStateId);
                    Cmd.Parameters.AddWithValue("@Hpmcountryid", model.ApplicationMarriageDetails.HpmCountryId);
                    Cmd.Parameters.AddWithValue("@Hpshousenumber", model.ApplicationMarriageDetails.HpsHouseNumber);
                    Cmd.Parameters.AddWithValue("@Hpsstreetnumber", model.ApplicationMarriageDetails.HpsStreetNumber);
                    Cmd.Parameters.AddWithValue("@Hpssublocality", model.ApplicationMarriageDetails.HpsSubLocality);
                    Cmd.Parameters.AddWithValue("@Hpslocalityid", model.ApplicationMarriageDetails.HpsLocalityId);
                    Cmd.Parameters.AddWithValue("@Hpspincode", model.ApplicationMarriageDetails.Hpspincode);
                    Cmd.Parameters.AddWithValue("@Hpssubdivcode", model.ApplicationMarriageDetails.Hpssubdivcode);
                    Cmd.Parameters.AddWithValue("@Hpsdistrictcode", model.ApplicationMarriageDetails.Hpsdistrictcode);
                    Cmd.Parameters.AddWithValue("@Hpsstateid", model.ApplicationMarriageDetails.HpsStateId);
                    Cmd.Parameters.AddWithValue("@Hpscountryid", model.ApplicationMarriageDetails.HpsCountryId);
                    Cmd.Parameters.AddWithValue("@HMaritalStatusId", model.ApplicationMarriageDetails.HMaritalStatusId);
                    Cmd.Parameters.AddWithValue("@HNationalityId", model.ApplicationMarriageDetails.HNationalityId);
                    Cmd.Parameters.AddWithValue("@HEmail", model.ApplicationMarriageDetails.HEmail);
                    Cmd.Parameters.AddWithValue("@HMobile", model.ApplicationMarriageDetails.HMobile);
                    Cmd.Parameters.AddWithValue("@WDocumentId", model.ApplicationMarriageDetails.WDocumentId);
                    Cmd.Parameters.AddWithValue("@WAadhaarNo", model.ApplicationMarriageDetails.WAadhaarNo);
                    Cmd.Parameters.AddWithValue("@WEnrolmentNo", model.ApplicationMarriageDetails.WEnrolmentNo);
                    Cmd.Parameters.AddWithValue("@WName", model.ApplicationMarriageDetails.WName);
                    Cmd.Parameters.AddWithValue("@WFatherName", model.ApplicationMarriageDetails.WFatherName);
                    Cmd.Parameters.AddWithValue("@WMotherName", model.ApplicationMarriageDetails.WMotherName);
                    Cmd.Parameters.AddWithValue("@WDOB", Utility.GetDateYYYYMMDD(model.ApplicationMarriageDetails.WDOB, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@WMaritalStatusId", model.ApplicationMarriageDetails.WMaritalStatusId);
                    Cmd.Parameters.AddWithValue("@WNationalityId", model.ApplicationMarriageDetails.WNationalityId);
                    Cmd.Parameters.AddWithValue("@Wpmhousenumber", model.ApplicationMarriageDetails.WpmHouseNumber);
                    Cmd.Parameters.AddWithValue("@Wpmstreetnumber", model.ApplicationMarriageDetails.WpmStreetNumber);
                    Cmd.Parameters.AddWithValue("@Wpmsublocality", model.ApplicationMarriageDetails.WpmSubLocality);
                    Cmd.Parameters.AddWithValue("@Wpmlocalityid", model.ApplicationMarriageDetails.WpmLocalityId);
                    Cmd.Parameters.AddWithValue("@Wpmpincode", model.ApplicationMarriageDetails.Wpmpincode);
                    Cmd.Parameters.AddWithValue("@Wpmsubdivcode", model.ApplicationMarriageDetails.Wpmsubdivcode);
                    Cmd.Parameters.AddWithValue("@Wpmdistrictcode", model.ApplicationMarriageDetails.Wpmdistrictcode);
                    Cmd.Parameters.AddWithValue("@Wpmstateid", model.ApplicationMarriageDetails.WpmStateId);
                    Cmd.Parameters.AddWithValue("@Wpmcountryid", model.ApplicationMarriageDetails.WpmCountryId);
                    Cmd.Parameters.AddWithValue("@Wpshousenumber", model.ApplicationMarriageDetails.WpsHouseNumber);
                    Cmd.Parameters.AddWithValue("@Wpsstreetnumber", model.ApplicationMarriageDetails.WpsStreetNumber);
                    Cmd.Parameters.AddWithValue("@Wpssublocality", model.ApplicationMarriageDetails.WpsSubLocality);
                    Cmd.Parameters.AddWithValue("@Wpslocalityid", model.ApplicationMarriageDetails.WpsLocalityId);
                    Cmd.Parameters.AddWithValue("@Wpspincode", model.ApplicationMarriageDetails.Wpspincode);
                    Cmd.Parameters.AddWithValue("@Wpssubdivcode", model.ApplicationMarriageDetails.Wpssubdivcode);
                    Cmd.Parameters.AddWithValue("@Wpsdistrictcode", model.ApplicationMarriageDetails.Wpsdistrictcode);
                    Cmd.Parameters.AddWithValue("@Wpsstateid", model.ApplicationMarriageDetails.WpsStateId);
                    Cmd.Parameters.AddWithValue("@Wpscountryid", model.ApplicationMarriageDetails.WpsCountryId);
                    Cmd.Parameters.AddWithValue("@WEmail", model.ApplicationMarriageDetails.WEmail);
                    Cmd.Parameters.AddWithValue("@WMobile", model.ApplicationMarriageDetails.WMobile);
                    Cmd.Parameters.AddWithValue("@MarriageDate", Utility.GetDateYYYYMMDD(model.ApplicationMarriageDetails.MarriageDate, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@MarriagePlace", model.ApplicationMarriageDetails.MarriagePlace);
                    Cmd.Parameters.AddWithValue("@WhetherReligiousMarriage", model.ApplicationMarriageDetails.WhetherReligiousMarriage);
                    Cmd.Parameters.AddWithValue("@MarriageReligion", model.ApplicationMarriageDetails.MarriageReligion);
                    Cmd.Parameters.AddWithValue("@MarriageReligiousPlace", model.ApplicationMarriageDetails.MarriageReligiousPlace);
                    Cmd.Parameters.AddWithValue("@MarriageSubdivCode", model.ApplicationMarriageDetails.MarriageSubdivCode);
                    Cmd.Parameters.AddWithValue("@MarriageDistrictCode", model.ApplicationMarriageDetails.MarriageDistrictCode);
                    Cmd.Parameters.AddWithValue("@MarriageStateId", model.ApplicationMarriageDetails.MarriageStateId);
                    Cmd.Parameters.AddWithValue("@MarriageCountryId", model.ApplicationMarriageDetails.MarriageCountryId);
                    Cmd.Parameters.AddWithValue("@MarriageLocalityId", model.ApplicationMarriageDetails.MarriageLocalityId);
                    Cmd.Parameters.AddWithValue("@HReligionId", model.ApplicationMarriageDetails.HReligionId);
                    Cmd.Parameters.AddWithValue("@WReligionId", model.ApplicationMarriageDetails.WReligionId);
                    Cmd.Parameters.AddWithValue("@AppointmentTypeId", model.ApplicationMarriageDetails.AppointmentTypeId);
                    Cmd.Parameters.AddWithValue("@AppointmentId", model.ApplicationMarriageDetails.AppointmentId);
                    Cmd.Parameters.AddWithValue("@MarriageActId", model.ApplicationMarriageDetails.MarriageActId);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    for (int i = 0; i < dtMarriageWitnessMaster.Rows.Count; i++)
                    {
                        Qry = "insert into dgen.MarriageWitnessMaster(ApplicationNo,WitnessName,WitnessFatherName,WitnessIdentificationNo,WitnessIdentityTypeId,witnesshousenumber,witnessstreetnumber,witnesssublocality,witnesslocalityid,witnesssubdivcode,witnessdistrictcode,witnessstateid,witnesscountryid,witnesspincode,witnesstypeid,userid,ipaddress,actiondatetime) VALUES (@LastInsertedId,@WitnessName,@WitnessFatherName,dbo.udf_general_encrypt(@WitnessIdentificationNo),@WitnessIdentityTypeId,@witnesshousenumber,@witnessstreetnumber,@witnesssublocality,@witnesslocalityid,@witnesssubdivcode,@witnessdistrictcode,@witnessstateid,@witnesscountryid,@witnesspincode,@witnesstypeid,@userid,@ipaddress,now())";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@WitnessName", dtMarriageWitnessMaster.Rows[i]["WitnessName"].ToString());
                        Cmd.Parameters.AddWithValue("@WitnessFatherName", dtMarriageWitnessMaster.Rows[i]["WitnessFatherName"].ToString());
                        Cmd.Parameters.AddWithValue("@WitnessIdentificationNo", dtMarriageWitnessMaster.Rows[i]["WitnessIdentificationNo"].ToString());
                        Cmd.Parameters.AddWithValue("@WitnessIdentityTypeId", dtMarriageWitnessMaster.Rows[i]["WitnessIdentityTypeId"].ToString());
                        Cmd.Parameters.AddWithValue("@witnesshousenumber", dtMarriageWitnessMaster.Rows[i]["witnesshousenumber"].ToString());
                        Cmd.Parameters.AddWithValue("@witnessstreetnumber", dtMarriageWitnessMaster.Rows[i]["witnessstreetnumber"].ToString());
                        Cmd.Parameters.AddWithValue("@witnesssublocality", dtMarriageWitnessMaster.Rows[i]["witnesssublocality"].ToString());
                        Cmd.Parameters.AddWithValue("@witnesslocalityid", dtMarriageWitnessMaster.Rows[i]["witnesslocalityid"].ToString());
                        Cmd.Parameters.AddWithValue("@witnesssubdivcode", dtMarriageWitnessMaster.Rows[i]["witnesssubdivcode"].ToString());
                        Cmd.Parameters.AddWithValue("@witnessdistrictcode", dtMarriageWitnessMaster.Rows[i]["witnessdistrictcode"].ToString());
                        Cmd.Parameters.AddWithValue("@witnessstateid", dtMarriageWitnessMaster.Rows[i]["witnessstateid"].ToString());
                        Cmd.Parameters.AddWithValue("@witnesscountryid", dtMarriageWitnessMaster.Rows[i]["witnesscountryid"].ToString());
                        Cmd.Parameters.AddWithValue("@witnesspincode", dtMarriageWitnessMaster.Rows[i]["witnesspincode"].ToString());
                        Cmd.Parameters.AddWithValue("@witnesstypeid", dtMarriageWitnessMaster.Rows[i]["witnesstypeid"].ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }

                    ////update/insert panelty fee
                    //cmdList.Add(Utility.UpdateApplicationFee(model.ApplicationDetails.ServiceCode, model.ApplicationDetails.ApplicationId.ToString(), model.ApplicationMarriageDetails.MarriageDate));
                }
                else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Solemnization).ToString())
                {
                    Qry = "select HOccupationId,HResidenceYears,WOccupationId,WResidenceYears,HDocumentId,dbo.udf_general_decrypt(HAadhaarNo) as HAadhaarNo,HEnrolmentNo,HName,HFatherName,HMotherName,to_char(HDOB,'DD/MM/YYYY') as HDOB,HMaritalStatusId,HNationalityId,Hpmhousenumber,Hpmstreetnumber,Hpmsublocality,Hpmlocalityid,HpmSubDivCode,Hpmdistrictcode,Hpmstateid,Hpmcountryid,Hpmpincode,Hpshousenumber,Hpsstreetnumber,Hpssublocality,Hpslocalityid,HpsSubDivCode,Hpsdistrictcode,Hpsstateid,Hpscountryid,Hpspincode,HEmail,HMobile,WDocumentId,dbo.udf_general_decrypt(WAadhaarNo) as WAadhaarNo,WEnrolmentNo,WName,WFatherName,WMotherName,to_char(WDOB,'DD/MM/YYYY') as WDOB,WMaritalStatusId,WNationalityId,Wpmhousenumber,Wpmstreetnumber,Wpmsublocality,Wpmlocalityid,WpmSubDivCode,Wpmdistrictcode,Wpmstateid,Wpmcountryid,Wpmpincode,Wpshousenumber,Wpsstreetnumber,Wpssublocality,Wpslocalityid,WpsSubDivCode,Wpsdistrictcode,Wpsstateid,Wpscountryid,Wpspincode,WEmail,WMobile,HReligionId,WReligionId,AppointmentTypeId,AppointmentId,MarriageActId from wgen.ApplicationMarriageSolemnizationDetails where ApplicationId=@ApplicationId";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationDetails.ApplicationId);
                    model.ApplicationMarriageDetails = ApplicationMarriageDetails.Get<ApplicationMarriageDetails>(new ApplicationMarriageDetails(), Cmd);

                    Qry = "select WitnessName,WitnessFatherName,dbo.udf_general_decrypt(WitnessIdentificationNo) as WitnessIdentificationNo,WitnessIdentificationData,WitnessIdentityTypeId,WitnessTypeId,witnesshousenumber,witnessstreetnumber,witnesssublocality,witnesslocalityid,witnesssubdivcode,witnessdistrictcode,witnessstateid,witnesscountryid,witnesspincode from wgen.MarriageWitnessMaster where ApplicationId=@ApplicationId";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationDetails.ApplicationId);
                    DataTable dtMarriageWitnessMaster = data.GetDataTable(Cmd);

                    Qry = "insert into dgen.ApplicationMarriageSolemnizationDetails(ApplicationNo,HOccupationId,HResidenceYears,WOccupationId,WResidenceYears,HDocumentId,HAadhaarNo,HEnrolmentNo,HName,HFatherName,HMotherName,HDOB,Hpmhousenumber,Hpmstreetnumber,Hpmsublocality,Hpmlocalityid,Hpmpincode,Hpmsubdivcode,Hpmdistrictcode,Hpmstateid,Hpmcountryid,Hpshousenumber,Hpsstreetnumber,Hpssublocality,Hpslocalityid,Hpspincode,Hpssubdivcode,Hpsdistrictcode,Hpsstateid,Hpscountryid,HMaritalStatusId,HNationalityId,HEmail,HMobile,WDocumentId,WAadhaarNo,WEnrolmentNo,WName,WFatherName,WMotherName,WDOB,WMaritalStatusId,WNationalityId,Wpmhousenumber,Wpmstreetnumber,Wpmsublocality,Wpmlocalityid,Wpmpincode,Wpmsubdivcode,Wpmdistrictcode,Wpmstateid,Wpmcountryid,Wpshousenumber,Wpsstreetnumber,Wpssublocality,Wpslocalityid,Wpspincode,Wpssubdivcode,Wpsdistrictcode,Wpsstateid,Wpscountryid,WEmail,WMobile,HReligionId,WReligionId,AppointmentTypeId,AppointmentId,MarriageActId,userid,ipaddress,actiondatetime) VALUES(@LastInsertedId,@HOccupationId,@HResidenceYears,@WOccupationId,@WResidenceYears,@HDocumentId,dbo.udf_general_encrypt(@HAadhaarNo),@HEnrolmentNo,@HName,@HFatherName,@HMotherName,@HDOB,@Hpmhousenumber,@Hpmstreetnumber,@Hpmsublocality,@Hpmlocalityid,@Hpmpincode,@Hpmsubdivcode,@Hpmdistrictcode,@Hpmstateid,@Hpmcountryid,@Hpshousenumber,@Hpsstreetnumber,@Hpssublocality,@Hpslocalityid,@Hpspincode,@Hpssubdivcode,@Hpsdistrictcode,@Hpsstateid,@Hpscountryid,@HMaritalStatusId,@HNationalityId,@HEmail,@HMobile,@WDocumentId,dbo.udf_general_encrypt(@WAadhaarNo),@WEnrolmentNo,@WName,@WFatherName,@WMotherName,@WDOB,@WMaritalStatusId,@WNationalityId,@Wpmhousenumber,@Wpmstreetnumber,@Wpmsublocality,@Wpmlocalityid,@Wpmpincode,@Wpmsubdivcode,@Wpmdistrictcode,@Wpmstateid,@Wpmcountryid,@Wpshousenumber,@Wpsstreetnumber,@Wpssublocality,@Wpslocalityid,@Wpspincode,@Wpssubdivcode,@Wpsdistrictcode,@Wpsstateid,@Wpscountryid,@WEmail,@WMobile,@HReligionId,@WReligionId,@AppointmentTypeId,@AppointmentId,@MarriageActId,@userid,@ipaddress,now())";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@HDocumentId", model.ApplicationMarriageDetails.HDocumentId);
                    Cmd.Parameters.AddWithValue("@HAadhaarNo", model.ApplicationMarriageDetails.HAadhaarNo);
                    Cmd.Parameters.AddWithValue("@HEnrolmentNo", model.ApplicationMarriageDetails.HEnrolmentNo);
                    Cmd.Parameters.AddWithValue("@HName", model.ApplicationMarriageDetails.HName);
                    Cmd.Parameters.AddWithValue("@HFatherName", model.ApplicationMarriageDetails.HFatherName);
                    Cmd.Parameters.AddWithValue("@HMotherName", model.ApplicationMarriageDetails.HMotherName);
                    Cmd.Parameters.AddWithValue("@HDOB", Utility.GetDateYYYYMMDD(model.ApplicationMarriageDetails.HDOB, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@Hpmhousenumber", model.ApplicationMarriageDetails.HpmHouseNumber);
                    Cmd.Parameters.AddWithValue("@Hpmstreetnumber", model.ApplicationMarriageDetails.HpmStreetNumber);
                    Cmd.Parameters.AddWithValue("@Hpmsublocality", model.ApplicationMarriageDetails.HpmSubLocality);
                    Cmd.Parameters.AddWithValue("@Hpmlocalityid", model.ApplicationMarriageDetails.HpmLocalityId);
                    Cmd.Parameters.AddWithValue("@Hpmpincode", model.ApplicationMarriageDetails.Hpmpincode);
                    Cmd.Parameters.AddWithValue("@Hpmsubdivcode", model.ApplicationMarriageDetails.Hpmsubdivcode);
                    Cmd.Parameters.AddWithValue("@Hpmdistrictcode", model.ApplicationMarriageDetails.Hpmdistrictcode);
                    Cmd.Parameters.AddWithValue("@Hpmstateid", model.ApplicationMarriageDetails.HpmStateId);
                    Cmd.Parameters.AddWithValue("@Hpmcountryid", model.ApplicationMarriageDetails.HpmCountryId);
                    Cmd.Parameters.AddWithValue("@Hpshousenumber", model.ApplicationMarriageDetails.HpsHouseNumber);
                    Cmd.Parameters.AddWithValue("@Hpsstreetnumber", model.ApplicationMarriageDetails.HpsStreetNumber);
                    Cmd.Parameters.AddWithValue("@Hpssublocality", model.ApplicationMarriageDetails.HpsSubLocality);
                    Cmd.Parameters.AddWithValue("@Hpslocalityid", model.ApplicationMarriageDetails.HpsLocalityId);
                    Cmd.Parameters.AddWithValue("@Hpspincode", model.ApplicationMarriageDetails.Hpspincode);
                    Cmd.Parameters.AddWithValue("@Hpssubdivcode", model.ApplicationMarriageDetails.Hpssubdivcode);
                    Cmd.Parameters.AddWithValue("@Hpsdistrictcode", model.ApplicationMarriageDetails.Hpsdistrictcode);
                    Cmd.Parameters.AddWithValue("@Hpsstateid", model.ApplicationMarriageDetails.HpsStateId);
                    Cmd.Parameters.AddWithValue("@Hpscountryid", model.ApplicationMarriageDetails.HpsCountryId);
                    Cmd.Parameters.AddWithValue("@HMaritalStatusId", model.ApplicationMarriageDetails.HMaritalStatusId);
                    Cmd.Parameters.AddWithValue("@HNationalityId", model.ApplicationMarriageDetails.HNationalityId);
                    Cmd.Parameters.AddWithValue("@HEmail", model.ApplicationMarriageDetails.HEmail);
                    Cmd.Parameters.AddWithValue("@HMobile", model.ApplicationMarriageDetails.HMobile);
                    Cmd.Parameters.AddWithValue("@WDocumentId", model.ApplicationMarriageDetails.WDocumentId);
                    Cmd.Parameters.AddWithValue("@WAadhaarNo", model.ApplicationMarriageDetails.WAadhaarNo);
                    Cmd.Parameters.AddWithValue("@WEnrolmentNo", model.ApplicationMarriageDetails.WEnrolmentNo);
                    Cmd.Parameters.AddWithValue("@WName", model.ApplicationMarriageDetails.WName);
                    Cmd.Parameters.AddWithValue("@WFatherName", model.ApplicationMarriageDetails.WFatherName);
                    Cmd.Parameters.AddWithValue("@WMotherName", model.ApplicationMarriageDetails.WMotherName);
                    Cmd.Parameters.AddWithValue("@WDOB", Utility.GetDateYYYYMMDD(model.ApplicationMarriageDetails.WDOB, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@WMaritalStatusId", model.ApplicationMarriageDetails.WMaritalStatusId);
                    Cmd.Parameters.AddWithValue("@WNationalityId", model.ApplicationMarriageDetails.WNationalityId);
                    Cmd.Parameters.AddWithValue("@Wpmhousenumber", model.ApplicationMarriageDetails.WpmHouseNumber);
                    Cmd.Parameters.AddWithValue("@Wpmstreetnumber", model.ApplicationMarriageDetails.WpmStreetNumber);
                    Cmd.Parameters.AddWithValue("@Wpmsublocality", model.ApplicationMarriageDetails.WpmSubLocality);
                    Cmd.Parameters.AddWithValue("@Wpmlocalityid", model.ApplicationMarriageDetails.WpmLocalityId);
                    Cmd.Parameters.AddWithValue("@Wpmpincode", model.ApplicationMarriageDetails.Wpmpincode);
                    Cmd.Parameters.AddWithValue("@Wpmsubdivcode", model.ApplicationMarriageDetails.Wpmsubdivcode);
                    Cmd.Parameters.AddWithValue("@Wpmdistrictcode", model.ApplicationMarriageDetails.Wpmdistrictcode);
                    Cmd.Parameters.AddWithValue("@Wpmstateid", model.ApplicationMarriageDetails.WpmStateId);
                    Cmd.Parameters.AddWithValue("@Wpmcountryid", model.ApplicationMarriageDetails.WpmCountryId);
                    Cmd.Parameters.AddWithValue("@Wpshousenumber", model.ApplicationMarriageDetails.WpsHouseNumber);
                    Cmd.Parameters.AddWithValue("@Wpsstreetnumber", model.ApplicationMarriageDetails.WpsStreetNumber);
                    Cmd.Parameters.AddWithValue("@Wpssublocality", model.ApplicationMarriageDetails.WpsSubLocality);
                    Cmd.Parameters.AddWithValue("@Wpslocalityid", model.ApplicationMarriageDetails.WpsLocalityId);
                    Cmd.Parameters.AddWithValue("@Wpspincode", model.ApplicationMarriageDetails.Wpspincode);
                    Cmd.Parameters.AddWithValue("@Wpssubdivcode", model.ApplicationMarriageDetails.Wpssubdivcode);
                    Cmd.Parameters.AddWithValue("@Wpsdistrictcode", model.ApplicationMarriageDetails.Wpsdistrictcode);
                    Cmd.Parameters.AddWithValue("@Wpsstateid", model.ApplicationMarriageDetails.WpsStateId);
                    Cmd.Parameters.AddWithValue("@Wpscountryid", model.ApplicationMarriageDetails.WpsCountryId);
                    Cmd.Parameters.AddWithValue("@WEmail", model.ApplicationMarriageDetails.WEmail);
                    Cmd.Parameters.AddWithValue("@WMobile", model.ApplicationMarriageDetails.WMobile);
                    Cmd.Parameters.AddWithValue("@HReligionId", model.ApplicationMarriageDetails.HReligionId);
                    Cmd.Parameters.AddWithValue("@WReligionId", model.ApplicationMarriageDetails.WReligionId);
                    Cmd.Parameters.AddWithValue("@AppointmentTypeId", model.ApplicationMarriageDetails.AppointmentTypeId);
                    Cmd.Parameters.AddWithValue("@AppointmentId", model.ApplicationMarriageDetails.AppointmentId);
                    Cmd.Parameters.AddWithValue("@MarriageActId", model.ApplicationMarriageDetails.MarriageActId);
                    Cmd.Parameters.AddWithValue("@HOccupationId", model.ApplicationMarriageDetails.HOccupationId);
                    Cmd.Parameters.AddWithValue("@WOccupationId", model.ApplicationMarriageDetails.WOccupationId);
                    Cmd.Parameters.AddWithValue("@HResidenceYears", model.ApplicationMarriageDetails.HResidenceYears);
                    Cmd.Parameters.AddWithValue("@WResidenceYears", model.ApplicationMarriageDetails.WResidenceYears);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    for (int i = 0; i < dtMarriageWitnessMaster.Rows.Count; i++)
                    {
                        Qry = "insert into dgen.MarriageWitnessMaster(ApplicationNo,WitnessName,WitnessFatherName,WitnessTypeId,WitnessIdentificationNo,WitnessIdentityTypeId,witnesshousenumber,witnessstreetnumber,witnesssublocality,witnesslocalityid,witnesssubdivcode,witnessdistrictcode,witnessstateid,witnesscountryid,witnesspincode,userid,ipaddress,actiondatetime) VALUES (@LastInsertedId,@WitnessName,@WitnessFatherName,@WitnessTypeId,dbo.udf_general_encrypt(@WitnessIdentificationNo),@WitnessIdentityTypeId,@witnesshousenumber,@witnessstreetnumber,@witnesssublocality,@witnesslocalityid,@witnesssubdivcode,@witnessdistrictcode,@witnessstateid,@witnesscountryid,@witnesspincode,@userid,@ipaddress,now())";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@WitnessName", dtMarriageWitnessMaster.Rows[i]["WitnessName"].ToString());
                        Cmd.Parameters.AddWithValue("@WitnessFatherName", dtMarriageWitnessMaster.Rows[i]["WitnessFatherName"].ToString());
                        Cmd.Parameters.AddWithValue("@WitnessIdentificationNo", dtMarriageWitnessMaster.Rows[i]["WitnessIdentificationNo"].ToString());
                        Cmd.Parameters.AddWithValue("@WitnessIdentityTypeId", dtMarriageWitnessMaster.Rows[i]["WitnessIdentityTypeId"].ToString());
                        Cmd.Parameters.AddWithValue("@witnesshousenumber", dtMarriageWitnessMaster.Rows[i]["witnesshousenumber"].ToString());
                        Cmd.Parameters.AddWithValue("@witnessstreetnumber", dtMarriageWitnessMaster.Rows[i]["witnessstreetnumber"].ToString());
                        Cmd.Parameters.AddWithValue("@witnesssublocality", dtMarriageWitnessMaster.Rows[i]["witnesssublocality"].ToString());
                        Cmd.Parameters.AddWithValue("@witnesslocalityid", dtMarriageWitnessMaster.Rows[i]["witnesslocalityid"].ToString());
                        Cmd.Parameters.AddWithValue("@witnesssubdivcode", dtMarriageWitnessMaster.Rows[i]["witnesssubdivcode"].ToString());
                        Cmd.Parameters.AddWithValue("@witnessdistrictcode", dtMarriageWitnessMaster.Rows[i]["witnessdistrictcode"].ToString());
                        Cmd.Parameters.AddWithValue("@witnessstateid", dtMarriageWitnessMaster.Rows[i]["witnessstateid"].ToString());
                        Cmd.Parameters.AddWithValue("@witnesscountryid", dtMarriageWitnessMaster.Rows[i]["witnesscountryid"].ToString());
                        Cmd.Parameters.AddWithValue("@witnesspincode", dtMarriageWitnessMaster.Rows[i]["witnesspincode"].ToString());
                        Cmd.Parameters.AddWithValue("@WitnessTypeId", dtMarriageWitnessMaster.Rows[i]["WitnessTypeId"].ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                }
                else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.ConstructionWorker).ToString())
                {
                    //Qry = "SELECT applicationid,unionid,Case when unionid=@unionid then 'False' else 'True' end as memberunion,whetherscstobc, maritalstatusid as maritalstatus, to_char(dateofretirement,'DD/MM/YYYY') as dateofretirement , nameofworkplace as workplaceid, addressofworkplace, localityworkplace, esino, pfno, nameofemployeer, addressofemployeer, serviceperioddays,  presentworkpost, detailsofboardmembership, bankcode, branchaddress, accountholdername, accountno, ifsccode, micrcode, userid, ipaddress, lastdatetime,whetherbuildingapplicant,employeremailid,employermobileno,otheremployerdetails,registrationno as oldregistrationno,to_char(registrationDate,'DD/MM/YYYY') as registrationDate,to_char(lastexpregistration,'DD/MM/YYYY') as lastexpregistration,to_char(lastrenewaldate,'DD/MM/YYYY') as lastrenewaldate,whetherregisterworker,whetheruploadvolunteerdata FROM wgen.applicationdetailsregconstructionworker where  ApplicationId = @ApplicationId";
                    Qry = "SELECT applicationid,unionid,Case when unionid=@unionid then 'False' else 'True' end as memberunion,whetherscstobc, maritalstatusid as maritalstatus, to_char(dateofretirement,'DD/MM/YYYY') as dateofretirement , nameofworkplace as workplaceid, addressofworkplace, localityworkplace, esino, pfno, nameofemployeer, addressofemployeer, serviceperioddays,  presentworkpost, detailsofboardmembership, bankcode, branchaddress, accountholdername, accountno, ifsccode, micrcode, userid, ipaddress, lastdatetime,whetherbuildingapplicant,employeremailid,employermobileno,otheremployerdetails,registrationno as oldregistrationno,to_char(registrationDate,'DD/MM/YYYY') as registrationDate,to_char(lastexpregistration,'DD/MM/YYYY') as lastexpregistration,to_char(lastrenewaldate,'DD/MM/YYYY') as lastrenewaldate,whetherregisterworker,whetheruploadvolunteerdata,presentworkpostotherdetails FROM wgen.applicationdetailsregconstructionworker where  ApplicationId = @ApplicationId";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationDetails.ApplicationId);
                    Cmd.Parameters.AddWithValue("@unionid", (int)CountList.Type000);
                    model.ApplicationDetailsConsWorker = ApplicationDetailsConsWorker.Get<ApplicationDetailsConsWorker>(new ApplicationDetailsConsWorker(), Cmd);

                    Qry = "select nid,applicationid,nameofnominee,to_char(dobofnominee,'DD/MM/YYYY') as dobofnominee, addressofnominee,nomineerelationid,ageofnominee,amounttonominee,gendername,udf_general_decrypt(aadhaarno) as  aadhaarno from wgen.regconworkernominationdetails where ApplicationId =@ApplicationId";//changes1502
                    NpgsqlCommand Cmd1 = new NpgsqlCommand(Qry);
                    Cmd1.Parameters.AddWithValue("@ApplicationId", model.ApplicationDetails.ApplicationId);
                    DataTable dtNM = data.GetDataTable(Cmd1);

                    Qry = "select fid,applicationid,nameofmember,to_char(dobofmember,'DD/MM/YYYY') as dobofmember, age,relationid,gender,udf_general_decrypt(AadhaarNo) as aadhaarno,photodata from wgen.regconworkerfamilydetails where ApplicationId =@ApplicationId";
                    NpgsqlCommand Cmd2 = new NpgsqlCommand(Qry);
                    Cmd2.Parameters.AddWithValue("@ApplicationId", model.ApplicationDetails.ApplicationId);
                    DataTable dtFD = data.GetDataTable(Cmd2);

                    Qry = "select cid,applicationid,nameofchildren , to_char(dobofchildren,'DD/MM/YYYY') as dobofchildren,age,gender,classofchildren,nameofschool,addressofschool,schoolcode,udf_general_decrypt(AadhaarNo) as aadhaarno from wgen.regconworkerchildrendetails where ApplicationId =@ApplicationId";//changes1502
                    NpgsqlCommand Cmd3 = new NpgsqlCommand(Qry);
                    Cmd3.Parameters.AddWithValue("@ApplicationId", model.ApplicationDetails.ApplicationId);
                    DataTable dtCH = data.GetDataTable(Cmd3);

                    //Qry = @"INSERT INTO dgen.applicationdetailsregconstructionworker(applicationNo, whetherscstobc, maritalstatusid, dateofretirement, nameofworkplace, addressofworkplace, localityworkplace, esino, pfno, nameofemployeer, addressofemployeer, serviceperioddays, presentworkpost, detailsofboardmembership, bankcode, branchaddress, accountholdername, accountno, ifsccode, micrcode, userid, ipaddress, lastdatetime,WhetherBuildingApplicant,EmployerEmailid,EmployerMobileNo,servicefee,unionid,otheremployerdetails,WhetherRegisterWorker,WhetherUploadVolunteerData,RegistrationNo,RegistrationDate,LastExpRegistration,lastrenewaldate)VALUES  (@LastInsertedId, @whetherscstobc, @maritalstatusid,@dateofretirement, @nameofworkplace, @addressofworkplace, @localityworkplace, @esino, @pfno, @nameofemployeer, @addressofemployeer, @serviceperioddays, @presentworkpost, @detailsofboardmembership, @bankcode, @branchaddress, @accountholdername, @accountno, @ifsccode, @micrcode, @userid, @ipaddress, now(),@WhetherBuildingApplicant,@EmployerEmailid,@EmployerMobileNo,@servicefee,@unionid,@otheremployerdetails,@WhetherRegisterWorker,@WhetherUploadVolunteerData,@OldRegistrationNo,@RegistrationDate,@LastExpRegistration,@lastrenewaldate);";//changes1603
                    Qry = @"INSERT INTO dgen.applicationdetailsregconstructionworker(applicationNo, whetherscstobc, maritalstatusid, dateofretirement, nameofworkplace, addressofworkplace, localityworkplace, esino, pfno, nameofemployeer, addressofemployeer, serviceperioddays, presentworkpost, detailsofboardmembership, bankcode, branchaddress, accountholdername, accountno, ifsccode, micrcode, userid, ipaddress, lastdatetime,WhetherBuildingApplicant,EmployerEmailid,EmployerMobileNo,servicefee,unionid,otheremployerdetails,WhetherRegisterWorker,WhetherUploadVolunteerData,RegistrationNo,RegistrationDate,LastExpRegistration,lastrenewaldate,presentworkpostotherdetails)VALUES  (@LastInsertedId, @whetherscstobc, @maritalstatusid,@dateofretirement, @nameofworkplace, @addressofworkplace, @localityworkplace, @esino, @pfno, @nameofemployeer, @addressofemployeer, @serviceperioddays, @presentworkpost, @detailsofboardmembership, @bankcode, @branchaddress, @accountholdername, @accountno, @ifsccode, @micrcode, @userid, @ipaddress, now(),@WhetherBuildingApplicant,@EmployerEmailid,@EmployerMobileNo,@servicefee,@unionid,@otheremployerdetails,@WhetherRegisterWorker,@WhetherUploadVolunteerData,@OldRegistrationNo,@RegistrationDate,@LastExpRegistration,@lastrenewaldate,@presentworkpostotherdetails);";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationDetails.ApplicationId);
                    Cmd.Parameters.AddWithValue("@whetherbuildingapplicant", model.ApplicationDetailsConsWorker.WhetherBuildingApplicant);
                    Cmd.Parameters.AddWithValue("@employeremailid", model.ApplicationDetailsConsWorker.EmployerEmailid);
                    Cmd.Parameters.AddWithValue("@employermobileno", model.ApplicationDetailsConsWorker.EmployerMobileNo);
                    Cmd.Parameters.AddWithValue("@servicefee", model.ApplicationDetailsConsWorker.servicefee);
                    Cmd.Parameters.AddWithValue("@whetherscstobc", model.ApplicationDetailsConsWorker.whetherscstobc);
                    Cmd.Parameters.AddWithValue("@maritalstatusid", model.ApplicationDetailsConsWorker.MaritalStatus);
                    Cmd.Parameters.AddWithValue("@dateofretirement", Utility.GetDateYYYYMMDD(model.ApplicationDetailsConsWorker.dateofretirement, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@nameofworkplace", model.ApplicationDetailsConsWorker.Workplaceid);
                    Cmd.Parameters.AddWithValue("@addressofworkplace", model.ApplicationDetailsConsWorker.AddressofWorkplace);
                    Cmd.Parameters.AddWithValue("@localityworkplace", model.ApplicationDetailsConsWorker.localityworkplace);
                    Cmd.Parameters.AddWithValue("@esino", model.ApplicationDetailsConsWorker.ESINo);
                    Cmd.Parameters.AddWithValue("@pfno", model.ApplicationDetailsConsWorker.PFNo);
                    Cmd.Parameters.AddWithValue("@nameofemployeer", model.ApplicationDetailsConsWorker.NameofEmployeer);
                    Cmd.Parameters.AddWithValue("@addressofemployeer", model.ApplicationDetailsConsWorker.AddressofEmployeer);
                    Cmd.Parameters.AddWithValue("@serviceperioddays", model.ApplicationDetailsConsWorker.Serviceperioddays);
                    Cmd.Parameters.AddWithValue("@otheremployerdetails", model.ApplicationDetailsConsWorker.OtherEmployerDetails);
                    Cmd.Parameters.AddWithValue("@presentworkpost", model.ApplicationDetailsConsWorker.presentworkpost);
                    Cmd.Parameters.AddWithValue("@detailsofboardmembership", model.ApplicationDetailsConsWorker.detailsofBoardMembership);
                    Cmd.Parameters.AddWithValue("@bankcode", model.ApplicationDetailsConsWorker.BankCode);
                    Cmd.Parameters.AddWithValue("@Branchaddress", model.ApplicationDetailsConsWorker.Branchaddress);
                    Cmd.Parameters.AddWithValue("@AccountholderName", model.ApplicationDetailsConsWorker.AccountHolderName);
                    Cmd.Parameters.AddWithValue("@AccountNo", model.ApplicationDetailsConsWorker.AccountNo);
                    Cmd.Parameters.AddWithValue("@Ifsccode", model.ApplicationDetailsConsWorker.IFSCCode);
                    Cmd.Parameters.AddWithValue("@Micrcode", model.ApplicationDetailsConsWorker.MICRCode);
                    Cmd.Parameters.AddWithValue("@unionid", model.ApplicationDetailsConsWorker.unionid);
                    Cmd.Parameters.AddWithValue("@WhetherRegisterWorker", model.ApplicationDetailsConsWorker.WhetherRegisterWorker);
                    Cmd.Parameters.AddWithValue("@WhetherUploadVolunteerData", model.ApplicationDetailsConsWorker.WhetherUploadVolunteerData);
                    Cmd.Parameters.AddWithValue("@OldRegistrationNo", model.ApplicationDetailsConsWorker.OldRegistrationNo);
                    Cmd.Parameters.AddWithValue("@presentworkpostotherdetails", model.ApplicationDetailsConsWorker.PresentWorkpostOtherDetails);
                    Cmd.Parameters.AddWithValue("@RegistrationDate", Utility.GetDateYYYYMMDD(model.ApplicationDetailsConsWorker.RegistrationDate, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@LastExpRegistration", Utility.GetDateYYYYMMDD(model.ApplicationDetailsConsWorker.LastExpRegistration, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@lastrenewaldate", Utility.GetDateYYYYMMDD(model.ApplicationDetailsConsWorker.LastRenewalDate, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    //For Nominee Details 
                    for (int i = 0; i < dtNM.Rows.Count; i++)
                    {
                        Qry = "insert into dgen.regconworkernominationdetails(ApplicationNo,Nameofnominee,Addressofnominee,NomineerelationId,Dobofnominee,Amounttonominee,UserId,Lastdatetime,Ipaddress,gendername,aadhaarno) values (@LastInsertedId,@Nameofnominee,@Addressofnominee,@NomineerelationId,@Dobofnominee,@Amounttonominee,@UserId,now(),@Ipaddress,@gendername,udf_general_encrypt(@aadhaarno))";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@Nameofnominee", dtNM.Rows[i]["Nameofnominee"].ToString());
                        Cmd.Parameters.AddWithValue("@Addressofnominee", dtNM.Rows[i]["Addressofnominee"].ToString());
                        Cmd.Parameters.AddWithValue("@NomineerelationId", dtNM.Rows[i]["NomineerelationId"].ToString());
                        Cmd.Parameters.AddWithValue("@Dobofnominee", Utility.GetDateYYYYMMDD(dtNM.Rows[i]["Dobofnominee"].ToString(), '/', "0/1/2"));
                        Cmd.Parameters.AddWithValue("@Amounttonominee", dtNM.Rows[i]["Amounttonominee"].ToString());
                        Cmd.Parameters.AddWithValue("@gendername", dtNM.Rows[i]["gendername"].ToString());
                        Cmd.Parameters.AddWithValue("@aadhaarno", dtNM.Rows[i]["aadhaarno"].ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());

                        cmdList.Add(Cmd);
                    }

                    //For Family details
                    for (int i = 0; i < dtFD.Rows.Count; i++)
                    {
                        List<NpgsqlCommand> cmdlistphoto = new List<NpgsqlCommand>();

                        Qry = "INSERT INTO dsgn.enclosuredetailsminor(enclosuretype, enclosuredata,whetheractive, userid, ipaddress, lastactiondate)VALUES (@enclosuretype, @enclosuredata,@whetheractive,@userid , @ipaddress, now());SELECT currval(pg_get_serial_sequence('dsgn.enclosuredetailsminor','enclosureid'))";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@enclosuretype", "image/jpeg");
                        Cmd.Parameters.AddWithValue("@enclosuredata", (byte[])dtFD.Rows[i]["photodata"]);
                        Cmd.Parameters.AddWithValue("@whetheractive", CustomText.True.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdlistphoto.Add(Cmd);

                        Int64[] insertedid = data.SaveTransactionalData(cmdlistphoto);

                        Qry = "insert into dgen.regconworkerfamilydetails(ApplicationNo,Nameofmember,RelationId,Dobofmember,Gender,AadhaarNo,photoid,UserId,Lastdatetime,Ipaddress) values (@LastInsertedId,@Nameofmember,@RelationId,@Dobofmember,@Gender,udf_general_encrypt(@AadhaarNo),@photoid,@UserId,now(),@Ipaddress)";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@Nameofmember", dtFD.Rows[i]["Nameofmember"].ToString());
                        Cmd.Parameters.AddWithValue("@RelationId", dtFD.Rows[i]["RelationId"].ToString());
                        Cmd.Parameters.AddWithValue("@Dobofmember", Utility.GetDateYYYYMMDD(dtFD.Rows[i]["Dobofmember"].ToString(), '/', "0/1/2"));
                        Cmd.Parameters.AddWithValue("@Gender", dtFD.Rows[i]["Gender"].ToString());
                        Cmd.Parameters.AddWithValue("@AadhaarNo", dtFD.Rows[i]["AadhaarNo"].ToString());
                        Cmd.Parameters.AddWithValue("@photoid", insertedid[1]);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        Qry = "update wgen.regconworkerfamilydetails set photoid=@photoid,photodata=null where applicationid=@applicationid and fid=@fid";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@applicationid", model.ApplicationDetails.ApplicationId);
                        Cmd.Parameters.AddWithValue("@fid", dtFD.Rows[i]["fid"].ToString());
                        Cmd.Parameters.AddWithValue("@photoid", insertedid[1]);
                        cmdList.Add(Cmd);
                    }

                    //For Children Details
                    for (int i = 0; i < dtCH.Rows.Count; i++)
                    {
                        Qry = "insert into dgen.regconworkerchildrendetails(ApplicationNo,Nameofchildren,Dobofchildren,Gender,Classofchildren,Nameofschool,Addressofschool,UserId,Lastdatetime,Ipaddress,schoolcode,aadhaarno) values (@LastInsertedId,@Nameofchildren,@Dobofchildren,@Gender,@Classofchildren,@Nameofschool,@Addressofschool,@UserId,now(),@Ipaddress,@schoolcode,udf_general_encrypt(@aadhaarno))";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@Nameofchildren", dtCH.Rows[i]["Nameofchildren"].ToString());
                        Cmd.Parameters.AddWithValue("@Dobofchildren", Utility.GetDateYYYYMMDD(dtCH.Rows[i]["Dobofchildren"].ToString(), '/', "0/1/2"));
                        Cmd.Parameters.AddWithValue("@Gender", dtCH.Rows[i]["Gender"].ToString());
                        Cmd.Parameters.AddWithValue("@Classofchildren", dtCH.Rows[i]["Classofchildren"].ToString());
                        Cmd.Parameters.AddWithValue("@Nameofschool", dtCH.Rows[i]["Nameofschool"].ToString());
                        Cmd.Parameters.AddWithValue("@Addressofschool", dtCH.Rows[i]["Addressofschool"].ToString());
                        Cmd.Parameters.AddWithValue("@schoolcode", dtCH.Rows[i]["schoolcode"].ToString());
                        Cmd.Parameters.AddWithValue("@aadhaarno", dtCH.Rows[i]["aadhaarno"].ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                }
                else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.RenewalConsWorker).ToString())
                {
                    Qry = "  SELECT applicationid, registrationno, to_char(registrationdate,'DD/MM/YYYY') as registrationdate, to_char(lastsubscriptionpaid,'DD/MM/YYYY') as lastsubscriptionpaid, to_char(renewaldate,'DD/MM/YYYY') as renewaldate , delayreasons, membershipperiod, latefees, whethersamebankdetails, accountholdername, accountno, micrcode, ifsccode, bankname, branchnameaddress as BankBranchName,whetherexist, bankcode FROM wgen.applicationdetailsrenewalconsworker where applicationid=@ApplicationId";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationDetails.ApplicationId);
                    model.RenewalConsWorker = RenewalConsWorker.Get<RenewalConsWorker>(new RenewalConsWorker(), Cmd);

                    Qry = @"INSERT INTO dgen.applicationdetailsrenewalconsworker(ApplicationNo,registrationno,registrationdate,lastsubscriptionpaid,renewaldate,delayreasons,membershipperiod,latefees,whethersamebankdetails,accountholdername,accountno,micrcode,ifsccode,branchnameaddress,whetherexist,bankcode,userid,ipaddress,actiondatetime)
                                                                               VALUES (@LastInsertedId,@registrationno,@registrationdate,@lastsubscriptionpaid,@renewaldate,@delayreasons,@membershipperiod,@latefees,@whethersamebankdetails,@accountholdername,@accountno,@micrcode,@ifsccode,@branchnameaddress,@whetherexist,@bankcode,@userid,@ipaddress,now())";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@registrationno", model.RenewalConsWorker.RegistrationNo);
                    Cmd.Parameters.AddWithValue("@registrationdate", Utility.GetDateYYYYMMDD(model.RenewalConsWorker.RegistrationDate, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@lastsubscriptionpaid", Utility.GetDateYYYYMMDD(model.RenewalConsWorker.LastSubscriptionPaid, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@renewaldate", Utility.GetDateYYYYMMDD(model.RenewalConsWorker.Renewaldate, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@delayreasons", model.RenewalConsWorker.DelayReasons);
                    Cmd.Parameters.AddWithValue("@latefees", model.RenewalConsWorker.LateFees);
                    Cmd.Parameters.AddWithValue("@membershipperiod", model.RenewalConsWorker.MembershipPeriod);
                    Cmd.Parameters.AddWithValue("@whethersamebankdetails", model.RenewalConsWorker.whetherSameBankDetails);
                    Cmd.Parameters.AddWithValue("@accountholdername", model.RenewalConsWorker.AccountHolderName);
                    Cmd.Parameters.AddWithValue("@accountno", model.RenewalConsWorker.AccountNo);
                    Cmd.Parameters.AddWithValue("@ifsccode", model.RenewalConsWorker.IFSCCode);
                    Cmd.Parameters.AddWithValue("@micrcode", model.RenewalConsWorker.MICRCode);
                    Cmd.Parameters.AddWithValue("@branchnameaddress", model.RenewalConsWorker.BankBranchName);
                    Cmd.Parameters.AddWithValue("@whetherexist", model.RenewalConsWorker.whetherexist);
                    Cmd.Parameters.AddWithValue("@bankcode", model.RenewalConsWorker.BankCode);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                }
                else
                {
                    ViewBag.DisplayMessage = "The Entered application not eligible for submission of fee.";
                    return View("DpRecieveFeeFromCitizen", model);
                }

                //update accept status in citizen ApplicationDetails
                Qry = "update web.ApplicationDetails set ApplicationNo=@LastInsertedId,ApplicationStatusId=@ApplicationStatusId,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationId=@ApplicationId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationDetails.ApplicationId);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                //update payment acceptation in  status in applicationpaymentrequest table
                Qry = "update dbo.applicationpaymentrequest set ApplicationNo=@LastInsertedId,PaymentStatusId=@PaymentStatusId,PaymentDate=now(),Actionuserid=@userid,Actionipaddress=@ipaddress where ApplicationId=@ApplicationId and PaymentStatusId=@SbiEpayNewPayment";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@SbiEpayNewPayment", (int)ValueId.SbiEpayNewPayment);
                Cmd.Parameters.AddWithValue("@PaymentStatusId", (int)ValueId.SbiEpaySuccess);
                Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationDetails.ApplicationId);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                // save addtional fee amount
                Dictionary<string, string> FeeDic = new Dictionary<string, string>();
                FeeDic.Add("ApplicationId", model.ApplicationDetails.ApplicationId.ToString());
                if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Marriage).ToString())
                {
                    FeeDic.Add("MarriageDate", model.ApplicationMarriageDetails.MarriageDate);
                    FeeDic.Add("MarriageActId", model.ApplicationMarriageDetails.MarriageActId);
                }
                NpgsqlCommand CmdExist = Utility.UpdateApplicationFee(model.ApplicationDetails.ServiceCode, FeeDic);
                if (CmdExist != null) { cmdList.Add(CmdExist); }

                //insert in audit trail
                cmdList.Add(Utility.InsertDepartmentAuditTrail(null, (int)ApplicationHistoryMessage.MSG008, null, (int)ApplicationSource.Window, "LastInsertedId"));

                //insert in audit trail
                cmdList.Add(Utility.InsertDepartmentAuditTrail(null, (int)ApplicationHistoryMessage.MSG007, null, (int)ApplicationSource.Window, "LastInsertedId"));

                string AppNo = data.SaveTransactionalData(cmdList)[1].ToString();

                //send sms to applicant and insert record in table
                Dictionary<string, string> smsDic = new Dictionary<string, string>();
                smsDic.Add("ParamApplicationNo", AppNo);
                data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS002, smsDic));

                PreserveModelState(Constant._ModelStateParent, null, false, true);
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo", "IsPrint" }, new ArrayList() { AppNo, "0" });

                if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Marriage).ToString() || model.ApplicationDetails.ServiceCode == ((int)ServiceList.Solemnization).ToString())
                {
                    return RedirectToAction("MarriageApplicationReciept", "Print", new { q = QueryString });
                }
                else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.ConstructionWorker).ToString() || model.ApplicationDetails.ServiceCode == ((int)ServiceList.RenewalConsWorker).ToString())
                {
                    return RedirectToAction("ConstrcutionWorkerApplicationReciept", "Print", new { q = QueryString });
                }
                else
                {
                    return RedirectToAction("RevenueApplicationReciept", "Print", new { q = QueryString });
                }                

            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("DpRecieveFeeFromCitizen", (WindowModels)TempData[Constant._ModelStateParent]);
        }


        #region verify document from citizen
        public ActionResult DpVerifyDocumentFromCitizen()
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.WIND).ToString() && Sessions.getEmployeeUser().Permission != ((int)Permission.P121).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

            WindowModels model = new WindowModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DpVerifyDocumentFromCitizen(WindowModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string addScript = Utility.GetScriptForAuthorizationProcess();

                string Qry = "select AD.ApplicationStatusId,AD.whetherdocumentseen,AD.applicationsubdivcode,AD.OfficeCode from dbo.ApplicationDetails AD inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationSourceId=@ApplicationSourceId and AD.receivedpermission=@ReceivedPermission and SM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode)" + addScript;
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationSourceId", (int)ApplicationSource.Online);
                Cmd.Parameters.AddWithValue("@ReceivedPermission", (int)Permission.CITZ);
                string[] GetValues = data.SelectColumns(Cmd);
                string StatusId = GetValues[0];
                string WhetherDocSeen = GetValues[1];
                string SubdivCode = GetValues[2];
                string OfficeCode = GetValues[3];

                if (WhetherDocSeen == null)
                {
                    ModelState.AddModelError(string.Empty, "The entered application either does not applied through citizen account or does not belong to e-District Delhi.");
                    return View(model);
                }
                else
                {
                    Dictionary<string, string> ValidateData = new Dictionary<string, string>();
                    ValidateData.Add("ApplicationNo", model.ApplicationNo.ToString());

                    string DisplayMessage = Utility.WhetherAccessAllowed(ValidateData, new int[] { (int)ValueId.AuthOtp, (int)ValueId.AuthCrendential }, null, null, false, false, false);
                    if (!string.IsNullOrEmpty(DisplayMessage))
                    {
                        ViewData["message"] = DisplayMessage;
                        return View("message");
                    }

                    if (WhetherDocSeen.ToUpper() == CustomText.TRUE.ToString())
                    {
                        ModelState.AddModelError(string.Empty, "The document of entered application has been already seen.");
                        return View(model);
                    }
                    else
                    {
                        if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000)
                        {
                            if (Convert.ToInt32(OfficeCode) != Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId))
                            {
                                ModelState.AddModelError(string.Empty, "Entered application does not pending in your SR Office.");
                                return View(model);
                            }
                        }
                        else
                        {
                            if (Convert.ToInt32(SubdivCode) != Convert.ToInt32(Sessions.getEmployeeUser().SubDivCode) || Convert.ToInt32(OfficeCode) != Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId))
                            {
                                ModelState.AddModelError(string.Empty, "Entered application does not pending in your Subdivision.");
                                return View(model);
                            }
                        }

                        if (StatusId == ((int)Status.ISSUCER).ToString() || StatusId == ((int)Status.TEHSREC).ToString() || StatusId == ((int)Status.TEHSREJ).ToString())
                        {
                            ModelState.AddModelError(string.Empty, "Entered application not pending for Document Verification.");
                            return View(model);
                        }
                    }
                }

                //Fetch Applicant Basic Details
                model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationNo.ToString(), DB.LS.ToString());
                model.data = Utility.GetEnclosureDetails(string.Empty, string.Empty, string.Empty, string.Empty, model.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());

                PreserveModelState(Constant._ModelStateParent, model, false, true);
                return View("DpVerifyDocumentFromCitizenPost", model);
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DpVerifyDocumentFromCitizenPost(WindowModels model)
        {
            if (!model.DocumentCheck)
            {
                ViewBag.Message = "Please verify thay you have checked all documents and found correct.";
                PreserveModelState(Constant._ModelStateParent, null, true, false);
                return View("DpVerifyDocumentFromCitizenPost", (WindowModels)TempData[Constant._ModelStateParent]);
            }

            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

            string Qry = "update dbo.ApplicationDetails set WhetherDocumentSeen=@WhetherDocumentSeen,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ObservationRemarks);
            Cmd.Parameters.AddWithValue("@WhetherDocumentSeen", CustomText.TRUE.ToString());
            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
            cmdList.Add(Cmd);

            //insert in audit trail
            cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo.ToString(), (int)ApplicationHistoryMessage.MSG032, model.ObservationRemarks.ToString(), (int)ApplicationSource.Window, null));

            data.SaveData(cmdList);

            ViewBag.Message = "Documents has been successfully check and verified.";
            return View("DpVerifyDocumentFromCitizen");
        }
        #endregion


        #region recieve affidavit from citizen
        //public ActionResult DpRecieveAffidavitFromCitizen()
        //{
        //    if (Sessions.getEmployeeUser().Permission != ((int)Permission.WIND).ToString() && Sessions.getEmployeeUser().Permission != ((int)Permission.P121).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

        //    WindowModels model = new WindowModels();
        //    return View(model);
        //}
        //[AcceptVerbs(HttpVerbs.Post)]
        //[ValidateOnlyIncomingValues]
        //public ActionResult DpRecieveAffidavitFromCitizen(WindowModels model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        System.Nullable<int> StatusId = Convert.ToInt32(Utility.SelectColumnsValue("dbo.ApplicationDetails", "ApplicationStatusId", "ApplicationNo", model.ApplicationNo.ToString())[0]);
        //        if (StatusId == null)
        //        {
        //            ModelState.AddModelError(string.Empty, "Entered application not found at e-Disrict portal delhi.");
        //            return View(model);
        //        }
        //        if (StatusId != (int)Status.SCOM035)
        //        {
        //            ModelState.AddModelError(string.Empty, "Entered application not pending for affidavit collection.");
        //            return View(model);
        //        }

        //        //Fetch Applicant Basic Details
        //        model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationNo.ToString(), DB.LS.ToString());

        //        //Fetch Fee Detail of application
        //        ViewData[KeyName._Key01] = Utility.GetFeeDetails(model.ApplicationNo.ToString(), DB.LS.ToString(), true, CustomText.FALSE.ToString());

        //        PreserveModelState(Constant._ModelStateParent, model, false, true);
        //        return View("DpSaveAffidavitFromCitizen", model);
        //    }
        //    return View(model);
        //}
        //[AcceptVerbs(HttpVerbs.Post)]
        //[ValidateOnlyIncomingValues]
        //public ActionResult DpSaveAffidavitFromCitizen(WindowModels model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        GetData data = new GetData();
        //        List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

        //        string Qry = "update dbo.ApplicationEnclosureDetails set WhetherPhysicallyRecieved=@WhetherPhysicallyRecieved,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo and DocumentTypeId=@DocumentTypeId";
        //        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@WhetherPhysicallyRecieved", CustomText.TRUE.ToString());
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
        //        Cmd.Parameters.AddWithValue("@DocumentTypeId", (int)DocumentTypeId.NotarizedAffidavit);
        //        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
        //        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
        //        cmdList.Add(Cmd);

        //        //insert in audit trail
        //        cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo.ToString(), (int)ApplicationHistoryMessage.MSG030, null, (int)ApplicationSource.Window, null));

        //        data.SaveData(cmdList);

        //        ViewData["message"] = "Affidavit has been recieved successfully.";
        //        return View("message");
        //    }
        //    PreserveModelState(Constant._ModelStateParent, null, true, false);
        //    return View((WindowModels) TempData[Constant._ModelStateParent]);
        //}
        #endregion


        public ActionResult EditApplicationList()
        {
            GetData data = new GetData();
            WindowModels model = new WindowModels();

            string addScript = Utility.GetScriptForAuthorizationProcess();
            //string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where AD.ServiceCode in (@ParamServiceCode) and AD.ApplicationSubDivCode in (@ParamSubDivCode) and AD.ApplicationStatusId=@ApplicationStatusId";
            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where AD.ServiceCode in (@ParamServiceCode) and AD.ApplicationStatusId=@ApplicationStatusId and SM.deptcode=@ParamDeptCode" + addScript;
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.CSCEDT);
            model.data = data.GetDataTable(cmd);
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult SaveEditedApplication(Int64 AppNo)
        {
            SdmModels model = new SdmModels();
            GetData data = new GetData();

            if (!Utility.CheckCurrentStatusBeforeUpdate(AppNo.ToString(), (int)Status.DEALOLR, (int)CountList.Type001))
            {
                ViewData["message"] = "Application is not pending at this level anymore!";
                return View("message");
            }

            string Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
            Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.DEALOLR);
            Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(AppNo.ToString(), (int)Status.DEALOLR, (int)CountList.Type001, DB.LS.ToString()));
            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
            data.UpdateData(Cmd);

            PreserveModelState(Constant._ActionMessage, "Selected application has been processed successfully.", false, true);
            return RedirectToAction("EditApplicationList");
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult EditUserRegistrationDetails()
        {
            WindowModels model = new WindowModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult EditUserRegistrationDetails(WindowModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = "select RegistrationId from web.RegistrationMaster  where ApplicantUserId=@ApplicantUserId";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@ApplicantUserId", model.RegisterModel.RegistrationMaster.ApplicantUserID);
                string WhetheruseridExist = data.SelectColumns(cmd)[0];

                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "UserId" }, new ArrayList() { Convert.ToInt32(WhetheruseridExist) });
                return RedirectToAction("UpdateUserRegistrationDetails", "Window", new { q = QueryString });
            }
            return View("EditUserRegistrationDetails", model);
        }
        [EncryptedActionParameter]
        public ActionResult UpdateUserRegistrationDetails(int UserId)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                WindowModels model = new WindowModels();
                string Qry = "select ApplicantUserId from web.RegistrationMaster  where RegistrationId=@RegistrationId";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@RegistrationId", UserId);
                string WhetheruseridExist = data.SelectColumns(cmd)[0];
                if (string.IsNullOrEmpty(WhetheruseridExist))
                {
                    ViewBag.DisplayMessage = "UserID Provided is not Exist";
                    return View("EditUserRegistrationDetails");
                }
                model.ApplicantUserId = UserId.ToString();
                Qry = "select RegistrationId,ApplicantName,ApplicantGender,ApplicantLocalityId,LocalityName,ApplicantDistrictCode,DistrictName,ApplicantSubDivCode,SubDivDescription from web.registrationmaster RM inner join localityMaster LM on LM.localityId=RM.ApplicantLocalityId inner join DistrictMaster DM on DM.DistrictCode=RM.ApplicantDistrictCode inner join SubDivMaster SDM on SDM.SubDivCode=RM.ApplicantSubDivCode   where RegistrationId=@RegistrationId";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@RegistrationId", UserId);
                string WhetherUserIdExist = data.SelectColumns(cmd)[0];
                if (string.IsNullOrEmpty(WhetherUserIdExist))
                {
                    ViewData["message"] = " The UserID Provided is not Exist";
                    return View("message");
                }
                model.data = data.GetDataTable(cmd);
                PreserveModelState(Constant._ModelStateParent, model, false, true);
                return View(model);

            }

            return View("EditUserRegistrationDetails");
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateUserDetails(WindowModels model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList1 = new List<NpgsqlCommand>();
                ArrayList Values = new ArrayList();

                string Qry = "update web.registrationmaster set ApplicantLocalityId=@ApplicantLocalityId,ApplicantDistrictCode=@ApplicantDistrictCode,ApplicantSubDivCode=@ApplicantSubDivCode,Applicantipaddress=@Applicantipaddress,LastactionPerformed=now(),ActionPerformedBy=@ActionPerformedBy where RegistrationId=@RegistrationId";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                cmd.Parameters.AddWithValue("@RegistrationId", model.ApplicantUserId);
                cmd.Parameters.AddWithValue("@ApplicantLocalityId", model.LocalityId);
                cmd.Parameters.AddWithValue("@ApplicantDistrictCode", model.ApplicantDistrictCode);
                cmd.Parameters.AddWithValue("@ApplicantSubDivCode", model.ApplicantSubDivCode);
                cmd.Parameters.AddWithValue("@Applicantipaddress", Utility.GetIP4Address());
                cmd.Parameters.AddWithValue("@ActionPerformedBy", Sessions.getEmployeeUser().UserId);
                cmdList.Add(cmd);

                data.SaveData(cmdList);

                PreserveModelState(Constant._ModelStateParent, model, false, true);
                ViewData["message"] = "Locality has been updated successfully";
                return View("message");
            }


            return View("EditUserRegistrationDetails", model);
        }

        #region Physical verficication of applicant
        public ActionResult DpPhysicalVerificationCitizen()
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.WIND).ToString() && Sessions.getEmployeeUser().Permission != ((int)Permission.P121).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

            WindowModels model = new WindowModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DpPhysicalVerificationCitizenPost(WindowModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationNo.ToString(), DB.LS.ToString());

                //select data from citizen ApplicationDetails
                string Qry = "select RegistrationId,dbo.udf_general_decrypt(DocumentNo) as DocumentNo,DocumentId,ApplicationId,ServiceCode,ApplicationStatusId,ApplicationRelatedId,ApplicantName,ApplicantGender,ApplicantFatherName,ApplicantMotherName,ApplicantHusbandName,ApplicantMobileNo,ApplicantHousenumber,ApplicantStreetnumber,ApplicantSublocality,stateid,countryid,ApplicantPinCode,to_char(ApplicantDob,'DD/MM/YYYY') as ApplicantDob,ApplicantLocalityId,applicantsubdivcode,ApplicantDistrictCode,ApplicantNationality,applicationsubdivcode,applicationdistrictcode,ApplicantPermanentAddress,WhetherSameAddress,officecode FROM dbo.ApplicationDetails where ApplicationNo=@ApplicationNo";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.ApplicationDetails = ApplicationDetails.Get<ApplicationDetails>(new ApplicationDetails(), Cmd);

                if (model.ApplicationDetails.ApplicationStatusId != ((int)Status.SCOM034).ToString())
                {
                    ViewBag.DisplayMessage = "This Application is not pending at this level.";
                    return View("DpPhysicalVerificationCitizenPost", model);
                }
            }
            return View("DpPhysicalVerificationCitizenPost", model);
        }

        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DpPhysicalVerifiedPost(WindowModels model)
        {
            if (model.check == true)
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                string Qry = string.Empty;

                model.ApplicationStatusId = ((int)Status.DEALOLR).ToString();

                Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo;";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationNo.ToString(), Convert.ToInt32(model.ApplicationStatusId), (int)CountList.Type001, DB.LS.ToString()));
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                data.SaveData(cmdList);

                ViewBag.DisplayMessage = "Selected Application has been Processed Successfully.";
                return View("DpPhysicalVerificationCitizen", model);
            }
            return RedirectToAction("DpPhysicalVerificationCitizen", model);
        }
        #endregion

        #region global method current contoller
        //method for preserve model state
        public void PreserveModelState(string Key, object obj, bool IsKeep, bool IsRemove)
        {
            if (IsRemove == true) { TempData.Remove(Key); }
            if (obj != null) { TempData[Key] = obj; }
            if (IsKeep == true) { TempData.Keep(Key); }
        }
        #endregion global method current contoller




        #region temp Process for recieve the fee of application which is enetered withput payment
        public ActionResult RecieveOfflineFeeTemp()
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.WIND).ToString() && Sessions.getEmployeeUser().Permission != ((int)Permission.P121).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

            WindowModels model = new WindowModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult RecieveOfflineFeeTemp(WindowModels model)
        {
            if (ModelState.IsValid)
            {
                string Qry = string.Empty;
                GetData data = new GetData();
                model.ApplicationId = Convert.ToInt32(Utility.SelectColumnsValue("web.ApplicationDetails", "ApplicationId", "ApplicationNo", model.ApplicationNo.ToString())[0]);

                Qry = "select ApplicationStatusId,ApplicationSubDivCode,OfficeCode from  ApplicationDetails where ApplicationNo=@ApplicationNo and ApplicationNo=@ApplicationNoStatic";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNoStatic", "90730000062911");// last was 90730000056975 and 90730000057444
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo.ToString());
                model.data = data.GetDataTable(Cmd);
                if (model.data.Rows.Count == (int)CountList.Type000)
                {
                    ModelState.AddModelError(string.Empty, "Entered application either not found or does not allowed for this process.");
                    return View("RecieveOfflineFeeTemp", model);
                }
                if (Convert.ToInt32(model.data.Rows[0]["ApplicationStatusId"].ToString()) != (int)Status.DEALOLR)
                {
                    ViewData["message"] = "Entered application does not allowed for this process";
                    return View("message");
                }
                if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000)
                {
                    if (Convert.ToInt32(model.data.Rows[0]["OfficeCode"].ToString()) != Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId))
                    {
                        ViewData["message"] = "Entered application not pending for Fee in this SR Office.";
                        return View("message");
                    }
                }
                else
                {
                    if (Convert.ToInt32(model.data.Rows[0]["ApplicationSubDivCode"].ToString()) != Convert.ToInt32(Sessions.getEmployeeUser().SubDivCode) || Convert.ToInt32(model.data.Rows[0]["OfficeCode"].ToString()) != Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId))
                    {
                        ViewData["message"] = "Entered application not pending for Fee in this Subdivision.";
                        return View("message");
                    }
                }

                model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationId.ToString(), DB.RS.ToString());
                model.ServiceCode = Utility.GetServiceCode(model.ApplicationNo)[0];

                Qry = "select PMM.PaymentMode,SFT.ServiceFeeType,APD.PaymentAmount as ServiceFeeAmount,to_char(APR.PaymentGenerateDate,'DD/MM/YYYY') as PaymentInsertDate,case when APR.PaymentDate is null then false else true end as  WhetherPaymentRecived ,APR.PaymentDate as PaymentRecievedDate from dbo.applicationpaymentrequest APR inner join applicationpaymentdescription APD on APD.PaymentId=APR.PaymentId inner join dbo.PaymentModeMaster PMM on PMM.PaymentModeId=APR.PaymentModeId inner join dbo.ServiceFeeTypeMaster SFT on SFT.ServiceFeeTypeId=APD.PaymentTypeId where APR.ApplicationId=@ApplicationId and APR.paymentstatusid=@SbiEpayNew";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("SbiEpayNew", (int)ValueId.SbiEpayNewPayment);
                Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationId.ToString());
                model.dataa = data.GetDataTable(Cmd);
                if (model.dataa.Rows.Count == (int)CountList.Type000)
                {
                    ViewData["message"] = "Entered application not pending for Fee collection.";
                    return View("message");
                }

                if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.Marriage)
                {
                    model.ApplicationMarriageDetails = Utility.GetMarriageDetails(model.ApplicationId.ToString(), DB.RS.ToString());
                }
                else
                {
                    ViewData["message"] = "Entered application not eligible for offline fee.";
                    return View("message");
                }

                PreserveModelState(Constant._ModelStateParent, model, false, true);
                return View("RecieveOfflineFeeTemp", model);
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("RecieveOfflineFeeTemp", (WindowModels)TempData[Constant._ModelStateParent]);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult SaveOfflineFeeTemp(WindowModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                //update in citizen ApplicationDetails
                string Qry = "update web.ApplicationDetails set userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationId=@ApplicationId";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationId);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                //update in ApplicationDetails
                Qry = "update ApplicationDetails set acceptedby=@acceptedby, userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@acceptedby", (int)Permission.DEAL);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                //update payment acceptation in  status in applicationpaymentrequest table
                Qry = "update dbo.applicationpaymentrequest set ApplicationNo=@ApplicationNo,PaymentStatusId=@PaymentStatusId,PaymentDate=now(),Actionuserid=@userid,Actionipaddress=@ipaddress where ApplicationId=@ApplicationId and PaymentStatusId=@SbiEpayNewPayment";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@SbiEpayNewPayment", (int)ValueId.SbiEpayNewPayment);
                Cmd.Parameters.AddWithValue("@PaymentStatusId", (int)ValueId.SbiEpaySuccess);
                Cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicationId);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                //insert in audit trail
                cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo.ToString(), (int)ApplicationHistoryMessage.MSG008, null, (int)ApplicationSource.Window, null));

                data.SaveData(cmdList);

                ViewData["message"] = "Payment Received Successfully!!!";
                return View("message");

            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("RecieveOfflineFeeTemp", (WindowModels)TempData[Constant._ModelStateParent]);
        }
        #endregion

    }
}
