﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using System.IO;
using Edistrict.Models.DataService;
using System.Xml;
using System.Xml.Linq;
using Npgsql;
using System.Data;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.CustomClass;

namespace Edistrict.Controllers
{
    [Authorize]
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class IntegrationController : Controller
    {
        #region action methods for integration of e-District Certificate with DIGI LOCKER
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult ProcessDigiRequest()
        {
            if (!System.Web.HttpContext.Current.Request.Url.Host.ToLower().Equals(Digilocker.DigiDocRequestUrl))
                return null;

            if (Request.InputStream == null)
                return null;

            GetData data = new GetData();
            string Response = string.Empty, Base64StringDocContent = string.Empty;
            DigiLockerRequestData objRequest = new DigiLockerRequestData();
            objRequest.AppKey = Digilocker.AppKey;

            try
            {
                StreamReader RequestStream = new StreamReader(Request.InputStream);
                string RequestString = RequestStream.ReadToEnd();
                string XmlString = HttpUtility.UrlDecode(RequestString);
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(XmlString);
                XmlElement root = xmlDoc.DocumentElement;

                //check whether orgid is missing or not??
                if (root.HasAttribute("orgId")) { objRequest.OrgId = root.GetAttribute("orgId"); } else { objRequest.StatusName = "Parameter orgId missing"; goto FinalProcess; }

                if (root.HasAttribute("ts")) { objRequest.TsValue = root.GetAttribute("ts").Replace(" ","+"); } else { objRequest.StatusName = "Parameter ts missing"; goto FinalProcess; }
                if (string.IsNullOrEmpty(objRequest.TsValue)) { objRequest.StatusName = "Parameter ts contains NULL value"; goto FinalProcess; }

                if (root.HasAttribute("txn")) { objRequest.TxnValue = root.GetAttribute("txn"); } else { objRequest.StatusName = "Parameter txn missing"; goto FinalProcess; }
                if (string.IsNullOrEmpty(objRequest.TxnValue)) { objRequest.StatusName = "Parameter txn contains NULL value"; goto FinalProcess; }

                if (root.HasAttribute("keyhash")) { objRequest.KeyHash = root.GetAttribute("keyhash"); } else { objRequest.StatusName = "Parameter keyhash missing"; goto FinalProcess; }
                if (string.IsNullOrEmpty(objRequest.KeyHash)) { objRequest.StatusName = "Parameter keyhash contains NULL value"; goto FinalProcess; }
                if (!Utility.GetSHA256(objRequest.AppKey + objRequest.TsValue).Equals(objRequest.KeyHash)) { objRequest.StatusName = "Parameter keyhash contains wrong value"; goto FinalProcess; }


                XDocument xmlDoc1 = XDocument.Parse(xmlDoc.OuterXml);

                XmlNodeList xnodes = xmlDoc.GetElementsByTagName("DocDetails");
                //for (int i = 0; i < xnodes.Count; i++) { objRequest.DtxnValue = xnodes[i].Attributes["txn"].Value; }

                XmlNodeList urinodes = xmlDoc.GetElementsByTagName("URI");
                for (int i = 0; i < urinodes.Count; i++) { objRequest.Uri = urinodes[i].InnerText; }
                if (string.IsNullOrEmpty(objRequest.Uri)) { objRequest.StatusName = "Parameter URL contains NULL value"; }

                XmlNodeList UDF1nodes = xmlDoc.GetElementsByTagName("UDF1");
                for (int i = 0; i < UDF1nodes.Count; i++) { objRequest.UDF1 = UDF1nodes[i].InnerText; }

                XmlNodeList UDF2nodes = xmlDoc.GetElementsByTagName("UDF2");
                for (int i = 0; i < UDF2nodes.Count; i++) { objRequest.UDF2 = UDF2nodes[i].InnerText; }

                XmlNodeList UDF3nodes = xmlDoc.GetElementsByTagName("UDF3");
                for (int i = 0; i < UDF3nodes.Count; i++) { objRequest.UDF3 = UDF3nodes[i].InnerText; }

                //check whether URL contain correct application value
                objRequest.ApplicationNo = objRequest.Uri.Substring(objRequest.Uri.Length - 14, 14);
                if (Utility.IsValidApplicationNo(objRequest.ApplicationNo) == false) { objRequest.StatusName = "Parameter URL contains wrong value"; goto FinalProcess; }

                FinalProcess:
                if (string.IsNullOrEmpty(objRequest.StatusName))
                {
                    byte[] CertificateData = null;

                    string Qry = "select signeddocument from dsgn.digitaldocumentdetails where applicationno=@applicationno and applicationno in (select applicationno from ApplicationAdditionalDetails where applicationno=@applicationno and whetherdigipost=@whetherdigipost);";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@applicationno", objRequest.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@whetherdigipost", CustomText.TRUE.ToString());
                    DataTable dtData = data.GetDataTable(Cmd);
                    if (dtData.Rows.Count > 0)
                    {
                        CertificateData = (byte[])dtData.Rows[0][0];
                        Base64StringDocContent = Convert.ToBase64String(CertificateData);
                    }

                    objRequest.StatusName = "Document request process successfully";
                    Response = Utility.CreateDigiResponse((int)CountList.Type001, objRequest.StatusName, objRequest.TxnValue, objRequest.TsValue, Base64StringDocContent, string.Empty, string.Empty, string.Empty);
                }
                else
                {
                    Response = Utility.CreateDigiResponse((int)CountList.Type000, objRequest.StatusName, objRequest.TxnValue, objRequest.TsValue, Base64StringDocContent, string.Empty, string.Empty, string.Empty);
                }
            }
            catch
            {
                objRequest.StatusName = "Internal Server Error.";
                Response = Utility.CreateDigiResponse((int)CountList.Type000, objRequest.StatusName, objRequest.TxnValue, objRequest.TsValue, Base64StringDocContent, string.Empty, string.Empty, string.Empty);
            }
            return this.Content(Response, "application/xml");
        }
        #endregion



    }
}
