﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using Edistrict.Models.CustomAttribute;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Drawing.Imaging;
using Edistrict.Models;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using Npgsql;
using System.Text;
using System.Collections.Generic;
using System.Net.Mail;
using System.Net;
using System.Net.Mime;
using System.Configuration;
using System.Web.Security;
using System.Transactions;
using System.Data;
using System.ServiceModel;
using System.Globalization;
using com.toml.dp.util;
using System.Collections;
using System.ComponentModel;
using System.Text.RegularExpressions;
using Edistrict.Models.CustomClass;
using System.Diagnostics;

namespace Edistrict.Controllers
{
    
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class HomeController : Controller
    {
        [OperationBehavior(TransactionScopeRequired = true)]
        [TransactionFlow(TransactionFlowOption.Mandatory)]
        public ActionResult Index()
        {
            //Utility.PostRasData(90500000110306);
            //Utility.PostDigiLockerData(90500000110306);

            //int vot = Utility.VerifyRegistrationDocument("RANJEET VERMA", "M", "11/12/1988", "775927804180", (int)DocumentId.AadhaarCard);
            //int vot = Utility.VerifyRegistrationDocument("RANJEET VERMA", "M", "11/12/1988", "AKC1912574", (int)DocumentId.VoterID);

            if (Session != null)
            {
                if (Sessions.getCurrentUser() != null) { return RedirectToAction("CitizenIndex"); }
                if (Sessions.getEmployeeUser() != null) { return RedirectToAction("DepartmentIndex"); }
            }

            PublicModels model = new PublicModels();
            model.data = Utility.GetServiceDetails(false, false, true, false, false, false, false, false, null);
            return View(model);
        }
        [Authorize]
        public ActionResult CitizenIndex()
        {
            if (Sessions.getCurrentUser() != null)
            {
                PublicModels model = new PublicModels();

                ////temppraroy disable for connection problem
                //model.data = Utility.GetServiceDetails(true, false, false, false, false, false, false, false, null);
                if (Sessions.getCurrentUser().RegistrationId != null)
                {
                    model.dataset = Utility.GetReportDetailsForCitizen(false);
                }

                return View(model);
            }
            return RedirectToAction("BadRequest", "Error");
        }
        [Authorize]
        public ActionResult DepartmentIndex()
        {
            if (Sessions.getEmployeeUser() != null)
            {
                PublicModels model = new PublicModels();
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().Permission))
                {
                    model.dataset = Utility.GetReportDetailsForDepartment(false);
                }

                // temp process for Update SC/ST Department School Details
                if (Sessions.getEmployeeUser().Permission == ((int)Permission.P120).ToString())
                {
                    if (Convert.ToInt32(Sessions.getEmployeeUser().DeptCode) == (int)Department.Dept010)
                    {
                        string routereidrect = Utility.SelectColumnsValue("dgen.prematschoolmaster", "whetherdataupdate", "SchoolId", Sessions.getEmployeeUser().AuthorizationId)[0];
                        if (routereidrect.ToUpper() == CustomText.FALSE.ToString())
                        {
                            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "TypeId" }, new ArrayList() { (int)CountList.Type001 });
                            return RedirectToAction("UpdatePrematSchoolDetails", "Process", new { q = QueryString });
                        }
                    }
                }

                // temp process for locality approval
                if (Sessions.getEmployeeUser().Permission == ((int)Permission.TEHS).ToString())
                {
                    if (Convert.ToInt32(Sessions.getEmployeeUser().DeptCode) == (int)Department.Dept001)
                    {
                        string routereidrect = Utility.SelectColumnsValue("dbo.temp_localitycheck", "whethercomplete", "subdivcode", Sessions.getEmployeeUser().SubDivCode)[0];
                        if (routereidrect.ToUpper() == CustomText.FALSE.ToString())
                        {
                            return RedirectToAction("MapPendingLocality", "Common");
                        }
                    }
                }

                return View(model);
            }
            return RedirectToAction("BadRequest", "Error");
        }
        public ActionResult Contact()
        {
            return View();
        }
        public ActionResult Downloads()
        {
            return View();
        }
        public ActionResult EligibilityCriteria()
        {
            return View();
        }
        [EncryptedActionParameter]
        public ActionResult BasicApplicationDetails(int? service, int? status)
        {
            if (service == null && status == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }

            string statusId = string.Empty, WEBorDBO = "dbo.";
            if (status == 202) { statusId = " and AD.ApplicationStatusId in(25,29,30,31,32,33) "; WEBorDBO = "web."; }
            else if (status == 303) { statusId = " and AD.ApplicationStatusId in(21,5,6,7,3,28,27)"; }
            else if (status == 404) { statusId = " and AD.ApplicationStatusId in(12,13)"; }
            else if (status == 505) { statusId = " and AD.ApplicationStatusId in(14,18)"; }
            else if (status == 606) { statusId = " and AD.ApplicationStatusId in(16)"; }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select AD.ServiceCode,AD.ApplicationNo, AD.ApplicationId,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName from " + WEBorDBO + "ApplicationDetails AD left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode left outer join web.registrationmaster RM on RM.RegistrationId=AD.RegistrationId where AD.ServiceCode=@ServiceCode and (AD.RegistrationId=@RegistrationId or RM.ParentRegistrationid=@RegistrationId) " + statusId + " order by AD.ApplicationDate";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@RegistrationId", Sessions.getCurrentUser().RegistrationId);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }

        //[EncryptedActionParameter]
        //public ActionResult MyTest(int id, int gh, string name)
        //{
        //    return View();
        //}
    }
}
