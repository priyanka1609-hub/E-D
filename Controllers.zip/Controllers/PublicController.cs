﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using Edistrict.Models.DataService;
using Edistrict.Models;
using Edistrict.Models.CustomAttribute;
using System.Web.UI;
using Npgsql;
using Edistrict.Models.ApplicationService;
using System.Collections;
using Edistrict.Models.Entities;
using System.Data;
using System.Text;
using System.Net;
using System.IO;
using Edistrict.Models.CustomClass;

namespace Edistrict.Controllers
{
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class PublicController : Controller
    {
        public ActionResult ApplicationForm()
        {
            PublicModels model = new PublicModels();
            model.data = Utility.GetServiceDetails(false, false, true, false, false, false, false, false, null);
            return View(model);
        }
        public ActionResult OutputCertificate()
        {
            PublicModels model = new PublicModels();
            model.data = Utility.GetServiceDetails(false, false, false, true, false, false, false, false, null);
            return View(model);
        }
        public ActionResult ServiceGuideline()
        {
            PublicModels model = new PublicModels();
            model.data = Utility.GetServiceDetails(false, true, false, false, false, false, false, false, null);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult Services(int? DeptCode)
        {
            PublicModels model = new PublicModels();
            model.data = Utility.GetServiceDetails(false, false, false, false, false, true, false, true, DeptCode);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult TrackApplication(int? sid, Int64? app)
        {
            PublicModels model = new PublicModels();
            if (sid != null) { model.ServiceCode = sid.ToString(); }
            if (app != null) { model.ApplicationNo = app.ToString(); }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult TrackApplication(PublicModels model)
        {
            if (ModelState.IsValid)
            {
                if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.Captcha) == false)
                {
                    ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                    return View(model);
                }

                GetData data = new GetData();
                string Qry = string.Empty;
                if (model.ServiceCode == ((int)ServiceList.Marriage).ToString())
                {
                    if (model.ApplicationNo.Length < 14) { Qry = "select 'False' as WhetherEdistrictData,RectNo as ApplicationNo, distname  as DistrictName, subdivision as SubDivDescription, HusbandName, DobHusband, PresentAddressHusband,  WifeName, DobWife ,PresentAddressWife, FatherNameHusband,FatherNameWife,to_char(dateofapplication,'DD/MM/YYYY')as ApplicationDate , case when dateofprint is null then 'Pending' else 'Issued' end as trackingstatus, DateOfMarriage , 'Registration Of Marriage' as ServiceName , deptname from applicationdetailsmarriageepp  where RectNo=@ApplicationNo and DistCode=@DistrictCode and upper(HusbandName) = (@ApplicantName) and upper(WifeName) = (@WName)"; }
                    else
                    {
                        if (Convert.ToInt32(model.ApplicationNo.ToString().Substring(4, 1)) > 7) { Qry = "select 'False' as WhetherEdistrictData,RectNo as ApplicationNo, distname  as DistrictName, subdivision as SubDivDescription, HusbandName, DobHusband, PresentAddressHusband,  WifeName, DobWife ,PresentAddressWife,FatherNameHusband,FatherNameWife, to_char(dateofapplication,'DD/MM/YYYY')as ApplicationDate , case when dateofprint is null then 'Pending' else 'Issued' end as trackingstatus, DateOfMarriage , 'Registration Of Marriage' as ServiceName , deptname from applicationdetailsmarriageepp  where RectNo=@ApplicationNo and DistCode=@DistrictCode and upper(HusbandName) = (@ApplicantName) and upper(WifeName) = (@WName)"; }
                        else { Qry = "select 'True' as WhetherEdistrictData,ApplicationStatusId,RejectionReasonCode,reasondetail,ApplicationRemarks,ApplicationId,ApplicationNo,ApplicantName,ApplicantGender,ApplicantFatherName,to_char(ApplicationDate,'DD/MM/YYYY') as ApplicationDate,SM.ServiceName,ST.trackingstatus,DM.DistrictName,SD.subdivdescription,DP.deptname,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress FROM dbo.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.districtmaster DM on DM.districtcode=AD.applicationdistrictcode inner join dbo.subdivmaster  SD on SD.subdivcode=AD.applicationsubdivcode inner join dbo.deptmaster DP on DP.deptcode=SM.deptcode Left Outer join dbo.ReasonMaster RM on RM.ReasonCode=AD.RejectionReasonCode where AD.ApplicationNo=@ApplicationNo and upper(ApplicantName) = (@ApplicantName) and AD.ServiceCode=@ServiceCode "; }
                    }
                }
                else
                {
                    if (model.ApplicationNo.Length == 10) { Qry = "Select 'False' as WhetherEdistrictData,idno as ApplicationNo,ApplicantName,FName as ApplicantFatherName,'' as ApplicantGender ,to_char(DateOfApplication,'DD/MM/YYYY') as ApplicationDate,ServiceName,Status as trackingstatus,DistName as DistrictName,SubDivName as subdivdescription,deptname,Address as ApplicantAddress,rejectionreason from Dbo.ApplicationDetailsEpp AD  where AD.Idno=@ApplicationNo and upper(ApplicantName)=@ApplicantName and ServiceCode=@ServiceCode"; }
                    else if (model.ApplicationNo.Length < 10) { Qry = "Select 'False' as WhetherEdistrictData,idno as ApplicationNo,ApplicantName,FName as ApplicantFatherName,'' as ApplicantGender ,to_char(DateOfApplication,'DD/MM/YYYY') as ApplicationDate,ServiceName,Status as trackingstatus,DistName as DistrictName,SubDivName as subdivdescription,deptname,Address as ApplicantAddress,rejectionreason from Dbo.ApplicationDetailsEpp AD  where AD.Idno::text like (@ApplicationNo) and upper(ApplicantName)=@ApplicantName and ServiceCode=@ServiceCode and upper(ApplicantName)=@ApplicantName "; }
                    else if (model.ApplicationNo.Length == 14)
                    {
                        if (Convert.ToInt32(model.ApplicationNo.ToString().Substring(4, 1)) > 7) { Qry = "Select 'False' as WhetherEdistrictData,idno as ApplicationNo,ApplicantName,FName as ApplicantFatherName,'' as ApplicantGender ,to_char(DateOfApplication,'DD/MM/YYYY') as ApplicationDate,ServiceName,Status as trackingstatus,DistName as DistrictName,SubDivName as subdivdescription,deptname,Address as ApplicantAddress,rejectionreason from Dbo.ApplicationDetailsEpp AD  where AD.Idno=@ApplicationNo and upper(ApplicantName)=@ApplicantName and ServiceCode=@ServiceCode"; }
                        else { Qry = "select 'True' as WhetherEdistrictData,ApplicationStatusId,RejectionReasonCode,reasondetail,ApplicationRemarks,ApplicationId,ApplicationNo,ApplicantName,ApplicantGender,ApplicantFatherName,to_char(ApplicationDate,'DD/MM/YYYY') as ApplicationDate,SM.ServiceName,ST.trackingstatus,DM.DistrictName,SD.subdivdescription,DP.deptname,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress FROM dbo.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.districtmaster DM on DM.districtcode=AD.applicationdistrictcode inner join dbo.subdivmaster  SD on SD.subdivcode=AD.applicationsubdivcode inner join dbo.deptmaster DP on DP.deptcode=SM.deptcode Left Outer join dbo.ReasonMaster RM on RM.ReasonCode=AD.RejectionReasonCode where AD.ApplicationNo=@ApplicationNo and upper(ApplicantName)=@ApplicantName and AD.ServiceCode=@ServiceCode"; }
                    }
                    else
                    {
                        ViewBag.DisplayMessage = "Please Check Certificate No. Again";
                        return View("TrackApplication", model);
                    }
                }
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                if (model.ServiceCode == ((int)ServiceList.Marriage).ToString())
                {
                    if (model.ApplicationNo.Length < 14)
                    {
                        Cmd.Parameters.AddWithValue("@DistrictCode", model.DistCode);
                        Cmd.Parameters.AddWithValue("@WName", model.WName.ToUpper());
                    }
                    else
                    {
                        if (Convert.ToInt32(model.ApplicationNo.ToString().Substring(4, 1)) > 7)
                        {
                            Cmd.Parameters.AddWithValue("@DistrictCode", model.DistCode);
                            Cmd.Parameters.AddWithValue("@WName", model.WName.ToUpper());
                        }
                    }
                }

                if (model.ApplicationNo.Length < 10)
                {
                    if (model.ServiceCode != ((int)ServiceList.Marriage).ToString())
                    { Cmd.Parameters.AddWithValue("@ApplicationNo", string.Format("%{0}", model.ApplicationNo)); }
                    else
                    {
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@WName", model.WName.ToUpper());
                    }
                }
                else { Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo); }
                Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                Cmd.Parameters.AddWithValue("@ApplicantName", model.ApplicantName.ToUpper());
                model.data = data.GetDataTable(Cmd);

                try
                {
                    // call the eTaal service tracker web service
                    eTaalServiceTracker.IetaalDelhiClient serv = new eTaalServiceTracker.IetaalDelhiClient();
                    serv.count(Constant._eTaalTrackCode, Constant._eTaalTokenCode);
                }
                catch { }

                if (model.data.Rows.Count > 0) { Utility.InsertApplicationTrackingDetails(model.ApplicationNo, (int)ValueId.TrackApplication); }
                return View(model);
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult VerifyCertificate()
        {
            PublicModels model = new PublicModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult VerifyCertificate(PublicModels model)
        {
            if (ModelState.IsValid)
            {
                if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.Captcha) == false)
                {
                    ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                    return View(model);
                }

                string Qry = null;
                GetData data = new GetData();
                if (model.ServiceCode == ((int)ServiceList.Marriage).ToString())
                {
                    if (model.ApplicationNo.Length < 14) { Qry = "select 'False' as WhetherEdistrictData,RectNo as ApplicationNo, distname  as DistrictName, subdivision as SubDivDescription, HusbandName, DobHusband, PresentAddressHusband,  WifeName, DobWife ,PresentAddressWife,FatherNameHusband,FatherNameWife, to_char(dateofapplication,'DD/MM/YYYY')as ApplicationDate , case when dateofprint is null then 'Pending' else 'Issued' end as trackingstatus, DateOfMarriage , 'Registration Of Marriage' as ServiceName , deptname, to_char(dateofprint,'DD/MM/YYYY') as IssuedDate,'' as Designation from applicationdetailsmarriageepp  where RectNo=@ApplicationNo and dateofprint is not null and DistCode=@DistrictCode and upper(HusbandName) = (@ApplicantName) and upper(WifeName) = (@WName)"; }
                    else
                    {
                        if (Convert.ToInt32(model.ApplicationNo.ToString().Substring(4, 1)) > 7) { Qry = "select 'False' as WhetherEdistrictData,RectNo as ApplicationNo, distname  as DistrictName, subdivision as SubDivDescription, HusbandName, DobHusband, PresentAddressHusband,  WifeName, DobWife ,PresentAddressWife,FatherNameHusband,FatherNameWife, to_char(dateofapplication,'DD/MM/YYYY')as ApplicationDate , case when dateofprint is null then 'Pending' else 'Issued' end as trackingstatus, DateOfMarriage , 'Registration Of Marriage' as ServiceName , deptname,to_char(dateofprint,'DD/MM/YYYY') as IssuedDate,'' as Designation from applicationdetailsmarriageepp  where RectNo=@ApplicationNo and dateofprint is not null and DistCode=@DistrictCode and upper(HusbandName) = (@ApplicantName) and upper(WifeName) = (@WName)"; }
                        else { Qry = "select 'True' as WhetherEdistrictData,ApplicationId,AD.ApplicationNo,ApplicantName,ApplicantGender,ApplicantFatherName,to_char(ApplicationDate,'DD/MM/YYYY') as ApplicationDate,SM.ServiceName,ST.trackingstatus,DM.DistrictName,SD.subdivdescription,DP.deptname,to_char(DG.signeddate,'DD/MM/YYYY') as Issueddate,UM.designation,SD1.subdivdescription as Usersubdiv,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress FROM dbo.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.districtmaster DM on DM.districtcode=AD.applicationdistrictcode inner join dbo.subdivmaster  SD on SD.subdivcode=AD.applicationsubdivcode inner join dbo.deptmaster DP on DP.deptcode=SM.deptcode inner join dsgn.digitaldocumentdetails DG on DG.ApplicationNo=AD.ApplicationNo inner join dbo.usermaster UM on DG.signedby=UM.userid inner join dbo.usertosubdivmaster US on US.uid= UM.uid inner join dbo.subdivmaster  SD1 on SD1.subdivcode=US.subdivcode  where AD.applicationstatusid=@applicationstatusid and AD.applicationno=@ApplicationNo and ApplicationDistrictCode=@DistrictCode and upper(ApplicantName) = (@ApplicantName) and AD.ServiceCode=@ServiceCode "; }
                    }
                }
                else
                {
                    if (model.ApplicationNo.Length == 10) { Qry = "Select 'False' as WhetherEdistrictData,idno as ApplicationNo,ApplicantName,'' as ApplicantGender,FName as ApplicantFatherName,to_char(DateOfApplication,'DD/MM/YYYY') as ApplicationDate,ServiceName,Status as trackingstatus, DistName as DistrictName,SubDivName as subdivdescription,to_char(dop,'DD/MM/YYYY') as Issueddate,deptname,'' as  designation,SubDivName as Usersubdiv, Address as ApplicantAddress,ChildName,Caste  from Dbo.ApplicationDetailsEpp AD  where upper(Status)=@Status and AD.Idno=@ApplicationNo and ServiceCode=@ServiceCode"; }
                    else if (model.ApplicationNo.Length < 10) { Qry = "Select 'False' as WhetherEdistrictData,idno as ApplicationNo,ApplicantName,'' as ApplicantGender,FName as ApplicantFatherName,to_char(DateOfApplication,'DD/MM/YYYY') as ApplicationDate,ServiceName,Status as trackingstatus, DistName as DistrictName,SubDivName as subdivdescription,to_char(dop,'DD/MM/YYYY') as Issueddate,deptname,'' as  designation,SubDivName as Usersubdiv, Address as ApplicantAddress,ChildName,Caste  from Dbo.ApplicationDetailsEpp AD  where upper(Status)=@Status and AD.Idno::text like (@ApplicationNo) and upper(ApplicantName)=@ApplicantName and ServiceCode=@ServiceCode"; }
                    else if (model.ApplicationNo.Length == 14)
                    {
                        if (Convert.ToInt32(model.ApplicationNo.ToString().Substring(4, 1)) > 7) { Qry = "Select 'False' as WhetherEdistrictData,idno as ApplicationNo,ApplicantName,'' as ApplicantGender,FName as ApplicantFatherName,to_char(DateOfApplication,'DD/MM/YYYY') as ApplicationDate,ServiceName,Status as trackingstatus, DistName as DistrictName,SubDivName as subdivdescription,to_char(dop,'DD/MM/YYYY') as Issueddate,deptname,'' as  designation,SubDivName as Usersubdiv, Address as ApplicantAddress,ChildName,Caste  from Dbo.ApplicationDetailsEpp AD  where upper(Status)=@Status and AD.Idno=@ApplicationNo and upper(ApplicantName)=@ApplicantName and ServiceCode=@ServiceCode"; }
                        else { Qry = "select 'True' as WhetherEdistrictData,ApplicationId,AD.ApplicationNo,ApplicantName,ApplicantGender,ApplicantFatherName,to_char(ApplicationDate,'DD/MM/YYYY') as ApplicationDate,SM.ServiceName,ST.trackingstatus,DM.DistrictName,SD.subdivdescription,DP.deptname,to_char(DG.signeddate,'DD/MM/YYYY') as Issueddate,UM.designation,SD1.subdivdescription as Usersubdiv,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress FROM dbo.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.districtmaster DM on DM.districtcode=AD.applicationdistrictcode inner join dbo.subdivmaster  SD on SD.subdivcode=AD.applicationsubdivcode inner join dbo.deptmaster DP on DP.deptcode=SM.deptcode inner join dsgn.digitaldocumentdetails DG on DG.ApplicationNo=AD.ApplicationNo inner join dbo.usermaster UM on DG.signedby=UM.userid inner join dbo.usertosubdivmaster US on US.uid= UM.uid inner join dbo.subdivmaster  SD1 on SD1.subdivcode=US.subdivcode  where AD.applicationstatusid=@applicationstatusid and AD.applicationno=@ApplicationNo and upper(ApplicantName)=@ApplicantName and AD.ServiceCode=@ServiceCode"; }
                    }
                    else
                    {
                        ViewBag.DisplayMessage = "Please Check Certificate No Again";
                        return View("VerifyCertificate", model);
                    }
                }
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                if (model.ServiceCode == ((int)ServiceList.Marriage).ToString())
                {
                    if (model.ApplicationNo.Length < 14)
                    {
                        Cmd.Parameters.AddWithValue("@DistrictCode", model.DistCode);
                        Cmd.Parameters.AddWithValue("@WName", model.WName.ToUpper());
                    }
                    else
                    {
                        if (Convert.ToInt32(model.ApplicationNo.ToString().Substring(4, 1)) > 7)
                        {
                            Cmd.Parameters.AddWithValue("@DistrictCode", model.DistCode);
                            Cmd.Parameters.AddWithValue("@WName", model.WName.ToUpper());
                        }
                        else
                        {
                            Cmd.Parameters.AddWithValue("@DistrictCode", model.DistCode);
                            Cmd.Parameters.AddWithValue("@applicationstatusid", (int)Status.ISSUCER);
                        }
                    }
                }
                else
                {
                    if (model.ApplicationNo.Length < 14) { Cmd.Parameters.AddWithValue("@Status", CustomText.ISSUED.ToString()); }
                    else
                    {
                        if (Convert.ToInt32(model.ApplicationNo.ToString().Substring(4, 1)) > 7) { Cmd.Parameters.AddWithValue("@Status", CustomText.ISSUED.ToString()); }
                        else { Cmd.Parameters.AddWithValue("@applicationstatusid", (int)Status.ISSUCER); }
                    }
                }
                if (model.ApplicationNo.Length < 10)
                {
                    if (model.ServiceCode != ((int)ServiceList.Marriage).ToString()) { Cmd.Parameters.AddWithValue("@ApplicationNo", string.Format("%{0}", model.ApplicationNo)); }
                    else { Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo); }
                }
                else
                {
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                }
                Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                Cmd.Parameters.AddWithValue("@ApplicantName", model.ApplicantName.ToUpper());
                model.data = data.GetDataTable(Cmd);
                model.dataset = Utility.GetServiceSpecificCertificateVerificationData(model.ApplicationNo);
                if (model.data.Rows.Count > 0) { Utility.InsertApplicationTrackingDetails(model.ApplicationNo, (int)ValueId.VerifyCertificate); }
                return View(model);
            }
            return View(model);
        }
        [HttpGet]
        public ActionResult GeneralCertificateSearch()
        {
            GetData data = new GetData();
            PublicModels model = new PublicModels();
            string Qry = "select ServiceCode,ServiceName from ServiceMaster order by ServiceName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            model.ServiceList = new SelectList(ServiceMaster.List<ServiceMaster>(Cmd), "ServiceCode", "ServiceName");
            return View(model);
        }
        [HttpPost]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult GeneralCertificateSearch(PublicModels model)
        {
            if (ModelState.IsValid)
            {
                if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.Captcha) == false)
                {
                    ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                    return View(model);
                }

                GetData data = new GetData();
                string Str = string.Empty, StrEpp = string.Empty, StrMEpp = string.Empty;
                string Qry = string.Empty, Join = string.Empty;
                NpgsqlCommand cmd = new NpgsqlCommand();
                if ((string.IsNullOrEmpty(model.ServiceCode)) && (string.IsNullOrEmpty(model.Year)) && (string.IsNullOrEmpty(model.Month)))
                {
                    ViewBag.DisplayMessage = "Please fill Service and period of issuance";
                    return View(model);
                }

                if (!string.IsNullOrEmpty(model.ServiceCode))
                {
                    if (model.ServiceCode == ((int)ServiceList.Income).ToString())
                    {
                        if (!string.IsNullOrEmpty(model.IncomeAmount))
                        {
                            Join = " inner join drev.ApplicationDetailsIncome ADI on ADI.ApplicationNo=AD.ApplicationNo ";
                            if (!string.IsNullOrEmpty(model.IncomeCondition))
                            {
                                Str = " and ADI.AnnualIncome" + model.IncomeCondition + "@AnnualIncome ";
                            }
                            else { Str = " and ADI.AnnualIncome=@AnnualIncome "; }
                        }
                    }
                    else if (model.ServiceCode == ((int)ServiceList.OBC).ToString())
                    {
                        if (!string.IsNullOrEmpty(model.CasteId))
                        {
                            Join = " inner join drev.ApplicationDetailsOBC OBC on OBC.ApplicationNo=AD.ApplicationNo ";
                            Str = " and OBC.CasteId=@CasteId ";
                            if (!string.IsNullOrEmpty(model.WhetherCentreCaste))
                            {
                                Str = " and OBC.WhetherCentreCaste=@WhetherCentreCaste ";
                            }
                        }
                    }
                    else if (model.ServiceCode == ((int)ServiceList.SCST).ToString())
                    {
                        if (!string.IsNullOrEmpty(model.CasteId))
                        {
                            Join = " inner join drev.ApplicationDetailsSCST SCST on SCST.ApplicationNo=AD.ApplicationNo ";
                            Str = " and SCST.CasteId=@CasteId ";
                            if (!string.IsNullOrEmpty(model.WhetherCentreCaste))
                            {
                                Str = " and SCST.WhetherCentreCaste=@WhetherCentreCaste ";
                            }
                        }
                    }
                    else if (model.ServiceCode == ((int)ServiceList.ST).ToString())
                    {
                        if (!string.IsNullOrEmpty(model.CasteId))
                        {
                            Join = " inner join drev.ApplicationDetailsST ST on ST.ApplicationNo=AD.ApplicationNo ";
                            Str = " and ST.CasteId=@CasteId ";
                            if (!string.IsNullOrEmpty(model.WhetherCentreCaste))
                            {
                                Str = " and ST.WhetherCentreCaste=@WhetherCentreCaste ";
                            }
                        }
                    }

                    Str = Str + " and AD.ServiceCode=" + model.ServiceCode;
                    StrEpp = StrEpp + " and AD.ServiceCode=" + model.ServiceCode;
                    StrMEpp = StrMEpp + " and AD.ServiceCode=" + model.ServiceCode;
                }
                if (!string.IsNullOrEmpty(model.ApplicantName))
                {
                    Str = Str + " and lower(ApplicantName) like '%" + model.ApplicantName.ToLower() + "%'";
                    StrEpp = StrEpp + " and lower(ApplicantName) like '%" + model.ApplicantName.ToLower() + "%'";
                    StrMEpp = StrMEpp + " and lower(HusbandName) like '%" + model.ApplicantName.ToLower() + "%'";
                }
                if (!string.IsNullOrEmpty(model.FatherName))
                {
                    Str = Str + " and lower(ApplicantFatherName) like '%" + model.FatherName.ToLower() + "%'";
                    StrEpp = StrEpp + " and lower(FName) like '%" + model.FatherName.ToLower() + "%'";
                }
                if (!string.IsNullOrEmpty(model.LocalityId))
                {
                    Str = Str + " and ApplicantLocalityId = " + model.LocalityId;
                }
                if (!string.IsNullOrEmpty(model.Year))
                {
                    Str = Str + " and (extract(year from DD.SignedDate))='" + model.Year + "'";
                    StrEpp = StrEpp + " and (extract(year from AD.dop))='" + model.Year + "'";
                    StrMEpp = StrMEpp + " and (extract(year from AD.DateOfPrint))='" + model.Year + "'";
                }
                if (!string.IsNullOrEmpty(model.Month))
                {
                    Str = Str + " and (extract(month from DD.SignedDate))='" + model.Month + "'";
                    StrEpp = StrEpp + " and (extract(month from AD.dop))='" + model.Month + "' and upper(Status) like '%" + CustomText.ISSUED.ToString() + "%'";
                    StrMEpp = StrMEpp + " and (extract(month from AD.DateOfPrint))='" + model.Month + "' and AD.DateOfPrint is Not Null";
                }

                // from edistrict dataBase
                Qry = "select AD.ApplicationNO,ApplicationDistrictCode,DistrictName,AD.ApplicantName,SM.ServiceName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantlocalityid,applicantsubdivcode,applicantdistrictcode,AD.stateid,countryid,applicantpincode) as ApplicantAddress,to_char(DD.SignedDate,'DD/MM/YYYY') as ApprovedDate from ApplicationDetails AD inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode left outer join dsgn.digitaldocumentdetails DD on AD.ApplicationNo=DD.ApplicationNo inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode " + Join + " where 1=1 " + Str;
                cmd = new NpgsqlCommand(Qry);
                if (!string.IsNullOrEmpty(model.ServiceCode))
                {
                    if (model.ServiceCode == ((int)ServiceList.Income).ToString())
                    {
                        if (!string.IsNullOrEmpty(model.IncomeAmount))
                        {
                            cmd.Parameters.AddWithValue("@AnnualIncome", model.IncomeAmount);
                        }
                    }
                }
                if (model.ServiceCode == ((int)ServiceList.OBC).ToString())
                {
                    if (!string.IsNullOrEmpty(model.CasteId))
                    {
                        cmd.Parameters.AddWithValue("@CasteId", model.CasteId);
                        if (!string.IsNullOrEmpty(model.WhetherCentreCaste))
                        {
                            if (model.WhetherCentreCaste.ToUpper() == CustomText.TRUE.ToString()) { cmd.Parameters.AddWithValue("@WhetherCentreCaste", CustomText.TRUE.ToString()); }
                            else if (model.WhetherCentreCaste.ToUpper() == CustomText.FALSE.ToString()) { cmd.Parameters.AddWithValue("@WhetherCentreCaste", CustomText.FALSE.ToString()); }
                        }
                    }
                }
                if (model.ServiceCode == ((int)ServiceList.SCST).ToString())
                {
                    if (!string.IsNullOrEmpty(model.CasteId))
                    {
                        cmd.Parameters.AddWithValue("@CasteId", model.CasteId);
                        if (!string.IsNullOrEmpty(model.WhetherCentreCaste))
                        {
                            if (model.WhetherCentreCaste.ToUpper() == CustomText.TRUE.ToString()) { cmd.Parameters.AddWithValue("@WhetherCentreCaste", CustomText.TRUE.ToString()); }
                            else if (model.WhetherCentreCaste.ToUpper() == CustomText.FALSE.ToString()) { cmd.Parameters.AddWithValue("@WhetherCentreCaste", CustomText.FALSE.ToString()); }
                        }
                    }
                }
                if (model.ServiceCode == ((int)ServiceList.ST).ToString())
                {
                    if (!string.IsNullOrEmpty(model.CasteId))
                    {
                        cmd.Parameters.AddWithValue("@CasteId", model.CasteId);
                        if (!string.IsNullOrEmpty(model.WhetherCentreCaste))
                        {
                            if (model.WhetherCentreCaste.ToUpper() == CustomText.TRUE.ToString()) { cmd.Parameters.AddWithValue("@WhetherCentreCaste", CustomText.TRUE.ToString()); }
                            else if (model.WhetherCentreCaste.ToUpper() == CustomText.FALSE.ToString()) { cmd.Parameters.AddWithValue("@WhetherCentreCaste", CustomText.FALSE.ToString()); }
                        }
                    }
                }
                model.data = data.GetDataTable(cmd);

                //From SLA DataBase ApplicationDetailsEpp Table
                Qry = "select idno as ApplicationNO, DistName as DistrictName,AD.ApplicantName,SM.ServiceName,Address as ApplicantAddress,to_char(dop,'DD/MM/YYYY') as ApprovedDate from ApplicationDetailsEpp AD inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where 1=1 " + StrEpp;
                cmd = new NpgsqlCommand(Qry);
                model.dataEpp = data.GetDataTable(cmd);

                //From SLA DataBase ApplicationDetailsMarriageEpp Table
                Qry = "select rectNo as ApplicationNO,DistName as DistrictName,AD.HusbandName As ApplicantName,SM.ServiceName,PresentAddressHusband as ApplicantAddress,to_char(DateOfPrint,'DD/MM/YYYY') as ApprovedDate from ApplicationDetailsMarriageEpp AD inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where 1=1  " + StrMEpp;
                cmd = new NpgsqlCommand(Qry);
                model.dataMEpp = data.GetDataTable(cmd);

                foreach (DataRow drtableOld in model.dataEpp.Rows)
                {
                    model.data.ImportRow(drtableOld);
                }

                foreach (DataRow drtableOldMEpp in model.dataMEpp.Rows)
                {
                    model.data.ImportRow(drtableOldMEpp);
                }

                model.data.DefaultView.Sort = "ApplicantName" + " " + "Asc";
                model.data = model.data.DefaultView.ToTable();
                if (model.data.Rows.Count > 0)
                {
                    return View(model);
                }
                else
                {
                    ViewBag.DisplayMessage = "No Certificate Found";
                    return View(model);
                }
            }
            return View(model);
        }
        [HttpGet]
        public ActionResult SearchLocality()
        {
            PublicModels model = new PublicModels();
            return View(model);
        }
        [HttpPost]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult SearchLocality(PublicModels model)
        {
            if (ModelState.IsValid)
            {
                if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.Captcha) == false)
                {
                    ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                    return View(model);
                }

                GetData data = new GetData();
                string Str = string.Empty;
                string Qry = string.Empty;
                NpgsqlCommand cmd = new NpgsqlCommand();
                if ((string.IsNullOrEmpty(model.LocalityName)) && (string.IsNullOrEmpty(model.PinCode)))
                {
                    ViewBag.DisplayMessage = "Please fill at least one text box";
                    return View(model);
                }
                if (!string.IsNullOrEmpty(model.LocalityName))
                {
                    Str = Str + " and lower(LocalityName) like '%" + model.LocalityName.ToLower() + "%'";
                }
                if (!string.IsNullOrEmpty(model.PinCode))
                {
                    Str = Str + " and Pincode='" + model.PinCode + "'";
                }
                Qry = "select LM.LocalityId,LM.LocalityName,LM.Pincode,DM.DistrictName,SM.SubDivDescription,SM.SubdivAddress,SM.ContactNumber,SM.ContactEmail from dbo.LocalityMaster LM inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join dbo.SubDivMaster SM on SM.SubDivCode=LS.SubDivCode inner join dbo.DistrictMaster DM on SM.DistrictCode=DM.DistrictCode where DM.deptcode=@deptcode and LS.WhetherActive=@WhetherActive and LM.WhetherActive=@WhetherActive" + Str;
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@deptcode", model.DeptCode);
                cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                model.data = data.GetDataTable(cmd);
            }
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult DownloadVerifyCertificate()
        {
            PublicModels model = new PublicModels();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult DownloadVerifyCertificate(PublicModels model)
        {
            if (ModelState.IsValid)
            {
                if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.Captcha) == false)
                {
                    ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                    return View(model);
                }

                GetData data = new GetData();
                NpgsqlCommand Cmd = new NpgsqlCommand();

                string Qry = "select AD.ApplicationNo,AD.ApplicantDOB,AD.RegistrationId,RM.DocumentId,AD.ApplicantMobileNo FROM dbo.ApplicationDetails AD inner join web.RegistrationMaster RM on RM.RegistrationId=AD.RegistrationId inner join dbo.DocumentMaster DM on DM.DocumentId=RM.DocumentId inner join servicemaster SM on SM.servicecode=AD.servicecode where AD.applicationstatusid=@applicationstatusid and AD.ApplicationNo=@ApplicationNo and to_char(AD.ApplicantDOB,'YYYYMMDD')::date = @ApplicantDOB and RM.DocumentNo=@DocumentNo  and SM.deptcode=@DeptCode and AD.ServiceCode=@ServiceCode ";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicantDOB", Utility.ConvertDateSequenceForDatabase(model.DOB, '/', true));
                Cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(model.DocumentNo.ToUpper()));
                Cmd.Parameters.AddWithValue("@applicationstatusid", (int)Status.ISSUCER);
                Cmd.Parameters.AddWithValue("@DeptCode", model.DeptCode);
                Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                model.data = data.GetDataTable(Cmd);
                if (model.data.Rows.Count > 0)
                {
                    string SimpleOTP = Utility.GetRandomString(6, 1);

                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamOTP", SimpleOTP);
                    smsDic.Add("ParamMobileNo", model.data.Rows[0]["ApplicantMobileNo"].ToString());
                    data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS013, smsDic));

                    PreserveModelState(KeyName._Key08, SimpleOTP, true, false);
                }
                else
                {
                    Qry = "select AD.ApplicationNo,AD.ApplicantDOB,AD.RegistrationId,RM.DocumentId,AD.ApplicantMobileNo,AD.applicationstatusid,StatusName FROM dbo.ApplicationDetails AD inner join web.RegistrationMaster RM on RM.RegistrationId=AD.RegistrationId inner join dbo.DocumentMaster DM on DM.DocumentId=RM.DocumentId inner join dbo.StatusMaster SM on SM.StatusId=AD.applicationstatusid inner join servicemaster SR on SR.servicecode=AD.servicecode where AD.ApplicationNo=@ApplicationNo and to_char(AD.ApplicantDOB,'YYYYMMDD')::date = @ApplicantDOB and RM.DocumentNo=@DocumentNo and SR.deptcode=@DeptCode and AD.ServiceCode=@ServiceCode ";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@ApplicantDOB", Utility.ConvertDateSequenceForDatabase(model.DOB, '/', true));
                    Cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(model.DocumentNo.ToUpper()));
                    Cmd.Parameters.AddWithValue("@DeptCode", model.DeptCode);
                    Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                    model.dataEpp = data.GetDataTable(Cmd);
                    if (model.dataEpp.Rows.Count > 0)
                    {
                        PreserveModelState(Constant._ActionMessage, "Your Certificate is Not Generated, Your Current Application Status is: " + model.dataEpp.Rows[0]["StatusName"].ToString(), false, true);
                    }
                    else
                    {
                        PreserveModelState(Constant._ActionMessage, "The Input Value are Invalid Please Check Again", false, true);
                    }
                    return RedirectToAction("DownloadVerifyCertificate", "Public");
                }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationNo });
                return RedirectToAction("DownloadCertificateOTP", "Public", new { q = QueryString });
            }
            return View(model);
        }
        
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult DownloadCertificateOTP(Int64 AppNo)
        {
            PublicModels model = new PublicModels();
            if (string.IsNullOrEmpty(TempData[KeyName._Key08].ToString()))
            { return RedirectToAction("UnauthorizedRequest", "Error"); }
            model.ApplicationNo = AppNo.ToString();
            PreserveModelState(KeyName._Key08, model.OTP, true, false);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult DownloadCertificateOTP(PublicModels model)
        {
            if (ModelState.IsValid)
            {
                if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.Captcha) == false)
                {
                    ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                    return View(model);
                }
                if (!string.IsNullOrEmpty(TempData[KeyName._Key08].ToString()))
                {
                    if (TempData[KeyName._Key08].ToString() == model.OTP)
                    {
                        Utility.InsertApplicationTrackingDetails(model.ApplicationNo, (int)ValueId.DownloadCertificate);

                        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationNo });
                        return RedirectToAction("GetSignedCertificate", "Common", new { q = QueryString });
                    }
                }
                return View(model);
            }
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult ServiceApplyDetails(int id)
        {
            GetData data = new GetData();
            PublicModels model = new PublicModels();

            string Qry = "select htmlstarttag,contentdetails,htmlendtag,displayorder from contentdetails where whetheractive=true and contenttypeid in (1,2,3) and servicecode=@ServiceCode order by contenttypeid,contentorder";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ServiceCode", id);
            ViewData[KeyName._Key01] = data.GetDataTable(Cmd);

            Qry = "select htmlstarttag,contentdetails,htmlendtag,displayorder from contentdetails where whetheractive=true and contenttypeid=3 and servicecode=@ServiceCode order by contentorder";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ServiceCode", id);
            ViewData[KeyName._Key02] = data.GetDataTable(Cmd);

            Qry = "select htmlstarttag,contentdetails,htmlendtag,displayorder from contentdetails where whetheractive=true and contenttypeid=1 and servicecode=@ServiceCode order by contentorder";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ServiceCode", id);
            ViewData[KeyName._Key03] = data.GetDataTable(Cmd);

            return View(model);
        }
        public ActionResult DisposalProcedure()
        {
            return View();
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult ContactDetails()
        {
            GetData data = new GetData();
            PublicModels model = new PublicModels();

            string Qry = "select distinct DPT.DeptCode,DPT.deptname from districtmaster dm inner join deptmaster DPT on DPT.deptcode=DM.deptcode order by DPT.DeptCode";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            model.data1 = data.GetDataTable(Cmd);

            Qry = "select DM.DeptCode,DPT.DeptName,SM.SubDivDescription,SM.SubDivAddress,SM.ContactNumber,replace(replace(SM.ContactEmail, '.', '[dot]'),'@','[at]') as ContactEmail,DM.DistrictName,DM.DistrictCode,DAddress,Dcontact,replace(replace(DM.demail, '.', '[dot]'),'@','[at]') as Demail,AAddress,Acontact,replace(replace(DM.aemail, '.', '[dot]'),'@','[at]') as Aemail from dbo.SubDivMaster SM inner join dbo.DistrictMaster DM on SM.DistrictCode=DM.DistrictCode inner join DeptMaster DPT on DPT.deptcode=DM.deptcode where DM.deptcode=@deptcode and DM.StateId=@StateId order by DM.Deptcode,DM.DistrictName,SM.SubDivDescription";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@StateId", (int)State.Delhi);
            Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
            model.data = data.GetDataTable(Cmd);

            Qry = "select Deptcode,districtcode,DistrictName,daddress,dcontact,replace(replace(demail, '.', '[dot]'),'@','[at]') as ContactEmail  from districtmaster where deptcode =@deptcode and stateid=@stateid order by 1";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
            Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept002);
            model.data2 = data.GetDataTable(Cmd);

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult DesignatedOfficials()
        {
            PublicModels model = new PublicModels();
            GetData data = new GetData();
            string Qry = "select SM.SubDivDescription,SM.SubDivAddress,SM.ContactNumber,SM.ContactEmail,DM.DistrictName from dbo.SubDivMaster SM inner join dbo.DistrictMaster DM on SM.DistrictCode=DM.DistrictCode where DM.deptcode=@deptcode order by DM.DistrictCode";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
            model.data = data.GetDataTable(Cmd);
            return View(model);
        }
        public ActionResult GrievanceDetails()
        {
            return View();
        }
        public ActionResult Faq()
        {
            return View();
        }
        public ActionResult ComingSoon()
        {
            return View();
        }
        public ActionResult AboutUs()
        {
            return View();
        }
        public ActionResult Downloads()
        {
            return View();
        }
        public ActionResult DigitalSignature()
        {
            return View();
        }
        public ActionResult TermsAndConditions()
        {
            return View();
        }
        public ActionResult ApplyOnlineProcess()
        {
            return View();
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult RegisterGrievances()
        {
            PublicModels model = new PublicModels();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult RegisterGrievances(PublicModels model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.Captcha) == false)
                {
                    ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                    return View(model);
                }

                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                string Qry = "insert into ApplicationGrievances(ApplicantName,ApplicantMobileNo,ApplicantEmail,ApplicationNo,QueryDescription,IpAddress,QueryDate,WhetherTechnical,RegistrationId,OldGrievanceId,DepartmentId) values(@ApplicantName,@ApplicantMobileNo,@ApplicantEmail,@ApplicationNo,@QueryDescription,@IpAddress,now(),@WhetherTechnical,@RegistrationId,@OldGrievanceId,@DepartmentId); SELECT currval(pg_get_serial_sequence('applicationgrievances','grievanceid'))";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicantName", model.ApplicationGrievances.ApplicantName);
                Cmd.Parameters.AddWithValue("@ApplicantMobileNo", model.ApplicationGrievances.ApplicantMobileNo);
                Cmd.Parameters.AddWithValue("@ApplicantEmail", model.ApplicationGrievances.ApplicantEmail);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationGrievances.ApplicationNo);
                Cmd.Parameters.AddWithValue("@QueryDescription", model.ApplicationGrievances.QueryDescription);
                Cmd.Parameters.AddWithValue("@WhetherTechnical", model.ApplicationGrievances.WhetherTechnical);
                Cmd.Parameters.AddWithValue("@RegistrationId", model.ApplicationGrievances.RegistrationId);
                Cmd.Parameters.AddWithValue("@OldGrievanceId", model.ApplicationGrievances.OldGrievanceId);
                Cmd.Parameters.AddWithValue("@DepartmentId", model.ApplicationGrievances.DepartmentId);
                Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                string GrievanceId = data.SaveTransactionalData(cmdList)[1].ToString();

                Dictionary<string, string> smsDic = new Dictionary<string, string>();
                smsDic.Add("ParamRemarks", GrievanceId);
                smsDic.Add("ParamMobileNo", model.ApplicationGrievances.ApplicantMobileNo);
                data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS040, smsDic));

                PreserveModelState(Constant._ActionMessage, "Your Grievances Query has been submitted successfully, You will receive a reply from concerned department soon!!! ", false, true);
                return RedirectToAction("RegisterGrievances");
            }
            PreserveModelState(Constant._ModelStateParent, null, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult SearchRegisterGrievances()
        {
            PublicModels model = new PublicModels();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SearchRegisterGrievances(PublicModels model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.Captcha) == false)
                {
                    ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                    return View(model);
                }

                GetData data = new GetData();
                string Qry = string.Empty;
                NpgsqlCommand Cmd = new NpgsqlCommand();
                Qry = "select GrievanceId from ApplicationGrievances AG  where GrievanceId=@GrievanceId and ApplicantMobileNo=@ApplicantMobileNo";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@GrievanceId", model.ApplicationGrievances.GrievanceId);
                cmd.Parameters.AddWithValue("@ApplicantMobileNo", model.ApplicationGrievances.ApplicantMobileNo);
                string GrievanceId = data.SelectColumns(cmd)[0];
                if (!string.IsNullOrEmpty(GrievanceId))
                {
                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "GrievanceId", "WQR", "MobileNo" }, new ArrayList() { Convert.ToInt32(model.ApplicationGrievances.GrievanceId), CustomText.TRUE.ToString(), Convert.ToInt64(model.ApplicationGrievances.ApplicantMobileNo) });
                    return RedirectToAction("ViewGrievancesDetails", "Common", new { q = QueryString });
                }

                PreserveModelState(Constant._ActionMessage, "No Grievances Found on this detail has been submitted successfully, You will receive a reply from concerned department soon!!! ", false, true);
                return RedirectToAction("SearchRegisterGrievances");
            }
            PreserveModelState(Constant._ModelStateParent, null, false, true);
            return View(model);
        }


        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult UserFeedBack()
        {
            PublicModels model = new PublicModels();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult UserFeedBack(PublicModels model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.Captcha) == false)
                {
                    ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                    return View(model);
                }

                GetData data = new GetData();
                string Qry = string.Empty;
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                Qry = "insert into UserFeedBackMaster(UserName,UserMobileNo,UserEmail,UserFeedback,IpAddress) values(@UserName,@UserMobileNo,@UserEmail,@UserFeedback,@IpAddress)";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@UserName", model.UserFeedBackMaster.UserName);
                Cmd.Parameters.AddWithValue("@UserMobileNo", model.UserFeedBackMaster.UserMobileNo);
                Cmd.Parameters.AddWithValue("@UserEmail", model.UserFeedBackMaster.UserEmail);
                Cmd.Parameters.AddWithValue("@UserFeedback", model.UserFeedBackMaster.UserFeedBack);
                Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                data.UpdateData(Cmd);

                PreserveModelState(Constant._ActionMessage, "Your Feedback is Saved. Thanks For Your FeedBack!!! ", false, true);
                return RedirectToAction("UserFeedBack");
            }
            PreserveModelState(Constant._ModelStateParent, null, false, true);
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult RORDetails()
        {
            GetData data = new GetData();
            PublicModels model = new PublicModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult RORDetails(PublicModels model)
        {
            if (ModelState.IsValid)
            {
                if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.Captcha) == false)
                {
                    ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                    return View(model);
                }

                GetData data = new GetData();
                string str = string.Empty;

                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "Dist", "SubDiv", "Vilge", "KhaTyp", "OptTyp", "KhaNo", "RectNo", "KhasNo", "MinNo", "Name" }, new ArrayList() { model.DistrictCode, model.SubDivCode, model.VillageId, model.KhataTypeId, model.OptionType, model.KhataNo, model.RectNo, model.KhasraNo, model.MinNo, model.Name }, true);

                if (model.SubDivCode != "962" && model.SubDivCode != "968")
                    Response.Redirect("http://dlrc.delhigovt.nic.in/ViewKhataDetails.aspx?str=" + QueryString);
                Response.Redirect("http://dlrc.delhigovt.nic.in/ror/ViewKhataDetails.aspx?str=" + QueryString);
            }
            return View(model);
        }


        #region Status Tracking of Recovery
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult TrackGovermentDue()
        {
            PublicModels model = new PublicModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult TrackGovermentDue(PublicModels model)
        {
            if (ModelState.IsValid)
            {
                if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.Captcha) == false)
                {
                    ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                    return View(model);
                }

                GetData data = new GetData();
                string qry = string.Empty;
                if ((string.IsNullOrEmpty(model.CaseNo)) && (string.IsNullOrEmpty(model.RecoveryNo)) && (string.IsNullOrEmpty(model.DiaryNo)) && (string.IsNullOrEmpty(model.AppNo)) && (string.IsNullOrEmpty(model.RecoverytypeId)) && (string.IsNullOrEmpty(model.Amount)))
                {
                    ViewBag.DisplayMessage = "Please fill at least one Text box";
                    return View(model);
                }
                StringBuilder Qry = new StringBuilder("select  AR.CaseNo,AR.RecoveryNo,AR.DiaryNo,AR.ApplicationNo,SMVD.ValueId as RecoveryTypeId,SMVD.ValueName as RecoveryType,AR.Amount,SMV.ValueName as CurrentStatus,DM.deptname from dgen.applicationdetailsrecovery AR left outer join selectmastervaluedetails SMVD on SMVD.valueid=AR.RecoveryTypeId left outer join selectmastervaluedetails SMV on SMV.valueid=AR.PresentStatus left outer join dbo.deptmaster DM on DM.deptcode=AR.DeptId where 1=1");
                if (!string.IsNullOrEmpty(model.CaseNo))
                {
                    Qry.Append(" and AR.CaseNo=@CaseNo");
                }
                if (!string.IsNullOrEmpty(model.RecoveryNo))
                {
                    Qry.Append(" and AR.RecoveryNo=@RecoveryNo");
                }
                if (!string.IsNullOrEmpty(model.DiaryNo))
                {
                    Qry.Append(" and AR.DiaryNo=@DiaryNo");
                }
                if (!string.IsNullOrEmpty(model.AppNo))
                {
                    Qry.Append(" and AR.ApplicationNo=@ApplicationNo");
                }
                if (!string.IsNullOrEmpty(model.RecoverytypeId))
                {
                    Qry.Append(" and RecoveryTypeId=@RecoveryTypeId");
                }

                if (!string.IsNullOrEmpty(model.Amount))
                {
                    Qry.Append(" and AR.Amount>=@Amount");
                }

                Qry.Append(" order by RecoveryType");
                NpgsqlCommand cmd = new NpgsqlCommand(Qry.ToString());
                if (!string.IsNullOrEmpty(model.CaseNo)) cmd.Parameters.AddWithValue("@CaseNo", model.CaseNo);
                if (!string.IsNullOrEmpty(model.RecoveryNo)) { cmd.Parameters.AddWithValue("@RecoveryNo", model.RecoveryNo); }
                if (!string.IsNullOrEmpty(model.DiaryNo)) { cmd.Parameters.AddWithValue("@DiaryNo", model.DiaryNo); }
                if (!string.IsNullOrEmpty(model.AppNo)) cmd.Parameters.AddWithValue("@ApplicationNo", model.AppNo);
                if (!string.IsNullOrEmpty(model.RecoverytypeId)) { cmd.Parameters.AddWithValue("@RecoveryTypeId", model.RecoverytypeId); }
                if (!string.IsNullOrEmpty(model.Amount)) { cmd.Parameters.AddWithValue("@Amount", model.Amount); }
                model.data = data.GetDataTable(cmd);
            }
            return View(model);

        }
        #endregion


        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult LabourGrievanceStatus()
        {
            PublicModels model = new PublicModels();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult LabourGrievanceStatus(PublicModels model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.Captcha) == false)
                {
                    ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                    return View(model);
                }
                GetData data = new GetData();
                string Qry = string.Empty;
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                model.LBRGrievanceDetails = new LBRGrievanceDetails();
                model.LBRGrievanceDetails = Utility.GetGrievanceDetails(Convert.ToInt32(model.LabourGrievanceId));
                model.LBRGrievanceDetails.WhetherNotice = Utility.SelectColumnsValue("dgen.LBRInspectionMaster", "WhetherNoticeGenerated", "GrievanceId", model.LabourGrievanceId)[0];

                return View(model);
            }
            PreserveModelState(Constant._ModelStateParent, null, false, true);
            return View(model);
        }

        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult MessagePage(Int32 Type, Int32 Source, string Message)
        {
            //if (TempData[KeyName._Key01] != null) { return RedirectToAction("Refresh", "Error"); }

            ViewBag.Type = Type;
            ViewBag.Source = Source;
            ViewBag.Message = Message;
            PreserveModelState(KeyName._Key01, Type, false, true);
            return View();
        }

        [HttpPost]
        public ActionResult PublicAppPreview(string AppData)
        {
            PublicModels model = new PublicModels();
            GetData data = new GetData();
            if (string.IsNullOrEmpty(AppData)) { return RedirectToAction("BadRequest", "Error"); }
            try
            {
                if (Sessions.getEmployeeUser() != null)
                {
                    return RedirectToAction("PublicAppPreviewDetails", "Public", new { AppData = AppData });
                }
                else
                {
                    return RedirectToAction("EmployeeLogin", "Account", new { AppData = AppData });
                }
            }
            catch
            {
                return RedirectToAction("BadRequest", "Error");
            }

        }

        [HttpGet]
        [Authorize]
        public ActionResult PublicAppPreviewDetails(string AppData)
        {
            GetData data = new GetData();
            PublicModels model = new PublicModels();
            string DecryptVal = Utility.DecryptPublicRequest(AppData);
            string[] ArrayValue = Utility.ConvertStingToArray(DecryptVal, '|');
            if (ArrayValue[0] == ((int)CountList.Type000).ToString())
            {
                ViewData["message"] = "Not Authorize";
                return View("message");
            }


            model.ApplicationNo = ArrayValue[1];
            string Qry = "select ServiceCode FROM dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ServiceCode in (@Mutation)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            Cmd.Parameters.AddWithValue("@Mutation", (int)ServiceList.Mutation);
            model.ServiceCode = data.SelectColumns(Cmd)[0];

            if (string.IsNullOrEmpty(model.ServiceCode))
            {
                return RedirectToAction("BadRequest", "Error");
            }

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationNo, DB.LS.ToString());
            if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.Mutation)
            {
                model.ApplicationDetailsMutation = Utility.GetApplicationDetailsMutation(model.ApplicationNo, DB.LS.ToString());
            }

            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", string.Empty, string.Empty, model.ApplicationNo, DB.LS.ToString(), CustomText.N.ToString());
            model.data1 = Utility.GetPhotoDetails(string.Empty, string.Empty, string.Empty, string.Empty, model.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }

        public ActionResult ComingSoon2()
        {
            return View();
        }

        [AcceptVerbs(HttpVerbs.Get)]
        [Authorize]
        public ActionResult MismatchServiceDetails()
        {
            PublicModels model = new PublicModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        [Authorize]
        public ActionResult MismatchServiceDetails(PublicModels model, FormCollection frm)
        {
            GetData data = new GetData();
            string Qry = "select applicationno,applicantname,sm.servicename,to_char(applicantdob,'DD/MM/YYYY') as   applicantdob ,to_char(applicationdate,'DD/MM/YYYY') as  applicationdate, case when applicantgender='M' then 'Male' else 'Female' end as applicantgender from dstc.scheduledapplicationdetails  sad inner join servicemaster sm on sad.servicecode=sm.servicecode where invalidtype=@invalidtype order by sm.servicename,applicantname";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@invalidtype", model.MismatchType);
            model.data = data.GetDataTable(Cmd);
            return View(model);
        }

        public ActionResult DeptUtilityResponse(DeptUtilityResponse model)
        {

            if (ModelState.IsValid)
            {

                Utility.UpdateCitizenSessionAuditTrail(model.applicationRefNo, model.applicationUniqueNumber, model.USER_INFO, model.applicationStatus);

                //return View(model);
            }
            PreserveModelState(Constant._ModelStateParent, null, false, true);
            //return View(model);
            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "logid" }, new ArrayList() { model.applicationUniqueNumber });
            return RedirectToAction("ShowOtherDeptResponse", "Public", new { q = QueryString });
        }

        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult ShowOtherDeptResponse(int logid)
        {
            GetData data = new GetData();

            DeptUtilityResponse model = new DeptUtilityResponse();
            string Qry = @"select deptrefno as applicationrefno, dept.deptname, sm.servicename, smvd.valuename from citizensessionaudittrail cat
                        inner join servicemaster sm on sm.servicecode = cat.servicecode
                        inner join deptmaster dept on dept.deptcode = cat.deptcode
                        left outer join selectmastervaluedetails smvd on smvd.valueid::text = cat.deptstatus
                        where logid = @logid";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@logid", logid);
            DataTable dt = data.GetDataTable(Cmd);

            if (dt.Rows.Count > 0)
            {
                model.applicationRefNo = dt.Rows[0][0].ToString();
                model.deptName = dt.Rows[0][1].ToString();
                model.serviceName = dt.Rows[0][2].ToString();
                model.deptStatus = dt.Rows[0][3].ToString();
            }
            return View(model);
        }

        #region Odd Even Vehicle Process

        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult OddEvenApplication(Int32? RType)
        {
            PublicModels model = new PublicModels();
            model.OddEvenApplicationDetails = new OddEvenApplicationDetails();
            if (RType == null) { return View(model); }
            model.OddEvenApplicationDetails.RType = RType.ToString();
            model.OddEvenApplicationDetails.RTypeName = Utility.SelectColumnsValue("dbo.selectmastervaluedetails", "valuename", "valueid", model.OddEvenApplicationDetails.RType)[0];
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult OddEvenApplication(PublicModels model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                if (model.OddEvenApplicationDetails.Name == null)
                {
                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "RType" }, new ArrayList() { model.OddEvenApplicationDetails.RType });
                    return RedirectToAction("OddEvenApplication", "Public", new { q = QueryString });
                }
                else
                {
                    GetData data = new GetData();
                    string Qry = @"insert into dgen.oddevenapplicationdetails (Rtype,Name,RegistrationNo,Dateofcommencement,Typeofinstitution,Natureofwork,Noofemployees,Employeeonpvt4wheeler,Membersinterested,Phoneno1,Phoneno2,FhName,Address,Occupation,Officeaddress,Nameofemployer,Addressofemployer,Eduqualification,Whetheranyvehicle,Vehicletype,VehicleregistrationNo,Noofpersonconvinced,Noofhourstospare,Nameofrcomplex,Nameofpresorsec,Noofmembers,McdwardNo,Noofvehiclesownedbyra,Nameofmaintrafficpoints,IpAddress,Actiondatetime,LocalityId)values(@Rtype,@Name,@RegistrationNo,@Dateofcommencement,@Typeofinstitution,@Natureofwork,@Noofemployees,@Employeeonpvt4wheeler,@Membersinterested,@Phoneno1,@Phoneno2,@FhName,@Address,@Occupation,@Officeaddress,@Nameofemployer,@Addressofemployer,@Eduqualification,@Whetheranyvehicle,@Vehicletype,@VehicleregistrationNo,@Noofpersonconvinced,@Noofhourstospare,@Nameofrcomplex,@Nameofpresorsec,@Noofmembers,@McdwardNo,@Noofvehiclesownedbyra,@Nameofmaintrafficpoints,@IpAddress,now(),@LocalityId)";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@Rtype", model.OddEvenApplicationDetails.RType);
                    Cmd.Parameters.AddWithValue("@Name", model.OddEvenApplicationDetails.Name);
                    Cmd.Parameters.AddWithValue("@RegistrationNo", model.OddEvenApplicationDetails.RegistrationNo);
                    Cmd.Parameters.AddWithValue("@Dateofcommencement", Utility.GetDateYYYYMMDD(model.OddEvenApplicationDetails.Dateofcommencement, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@Typeofinstitution", model.OddEvenApplicationDetails.Typeofinstitution);
                    Cmd.Parameters.AddWithValue("@Natureofwork", model.OddEvenApplicationDetails.Natureofwork);
                    Cmd.Parameters.AddWithValue("@Noofemployees", model.OddEvenApplicationDetails.Noofemployees);
                    Cmd.Parameters.AddWithValue("@Employeeonpvt4wheeler", model.OddEvenApplicationDetails.Employeeonpvt4wheeler);
                    Cmd.Parameters.AddWithValue("@Membersinterested", model.OddEvenApplicationDetails.Membersinterested);
                    Cmd.Parameters.AddWithValue("@Phoneno1", model.OddEvenApplicationDetails.Phoneno1);
                    Cmd.Parameters.AddWithValue("@Phoneno2", model.OddEvenApplicationDetails.Phoneno2);
                    Cmd.Parameters.AddWithValue("@FhName", model.OddEvenApplicationDetails.FhName);
                    Cmd.Parameters.AddWithValue("@Address", model.OddEvenApplicationDetails.Address);
                    Cmd.Parameters.AddWithValue("@LocalityId", model.OddEvenApplicationDetails.LocalityId);
                    Cmd.Parameters.AddWithValue("@Occupation", model.OddEvenApplicationDetails.Occupation);
                    Cmd.Parameters.AddWithValue("@Officeaddress", model.OddEvenApplicationDetails.Officeaddress);
                    Cmd.Parameters.AddWithValue("@Nameofemployer", model.OddEvenApplicationDetails.Nameofemployer);
                    Cmd.Parameters.AddWithValue("@Addressofemployer", model.OddEvenApplicationDetails.Addressofemployer);
                    Cmd.Parameters.AddWithValue("@Eduqualification", model.OddEvenApplicationDetails.Eduqualification);
                    Cmd.Parameters.AddWithValue("@Whetheranyvehicle", model.OddEvenApplicationDetails.Whetheranyvehicle);
                    Cmd.Parameters.AddWithValue("@Vehicletype", model.OddEvenApplicationDetails.Vehicletype);
                    Cmd.Parameters.AddWithValue("@VehicleregistrationNo", model.OddEvenApplicationDetails.VehicleregistrationNo);
                    Cmd.Parameters.AddWithValue("@Noofpersonconvinced", model.OddEvenApplicationDetails.Noofpersonconvinced);
                    Cmd.Parameters.AddWithValue("@Noofhourstospare", model.OddEvenApplicationDetails.Noofhourstospare);
                    Cmd.Parameters.AddWithValue("@Nameofrcomplex", model.OddEvenApplicationDetails.Nameofrcomplex);
                    Cmd.Parameters.AddWithValue("@Nameofpresorsec", model.OddEvenApplicationDetails.Nameofpresorsec);
                    Cmd.Parameters.AddWithValue("@Noofmembers", model.OddEvenApplicationDetails.Noofmembers);
                    Cmd.Parameters.AddWithValue("@McdwardNo", model.OddEvenApplicationDetails.McdwardNo);
                    Cmd.Parameters.AddWithValue("@Noofvehiclesownedbyra", model.OddEvenApplicationDetails.Noofvehiclesownedbyra);
                    Cmd.Parameters.AddWithValue("@Nameofmaintrafficpoints", model.OddEvenApplicationDetails.Nameofmaintrafficpoints);
                    Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    data.UpdateData(Cmd);
                    return View("ThankYou");
                }
            }
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult ThankYou()
        {
            return View();
        }
        #endregion

        #region User Manual Download
        [Authorize]
        public ActionResult UserGuide()
        {
            GetData data = new GetData();
            PublicModels model = new PublicModels();

            string Qry = "select id,module_name from dbo.modules ";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd = new NpgsqlCommand(Qry);
            model.data = data.GetDataTable(cmd);

            Qry = "select 'UserManual_'||cast(ServiceCode as varchar)||'.pdf' as InputDoc,ServiceCode,ServiceName from dbo.ServiceMaster where servicecode in (9074,9078,9090,9079,9077,9076,9075,9058,9082) order by ServiceName ";
            cmd = new NpgsqlCommand(Qry);
            model.dataEpp = data.GetDataTable(cmd);

            return View(model);
        }
        [Authorize]
        [EncryptedActionParameter]
        public ActionResult UserGuideCitizen(int typ)
        {
            GetData data = new GetData();
            PublicModels model = new PublicModels();

            string Qry = "Select SD.id,SD.sub_module_name,SD.module_id,SD.is_process,MO.module_name FROM dbo.submodules SD inner join dbo.modules MO on MO.id=SD.module_id where SD.module_id=@module_id";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@module_id", Convert.ToInt32(typ));
            model.data = data.GetDataTable(cmd);
            return View(model);

        }
        [Authorize]
        [EncryptedActionParameter]
        public ActionResult UserGuideSubModule(int typ)
        {
            GetData data = new GetData();
            PublicModels model = new PublicModels();

            string Qry = "Select Mo.module_name,UM.id,UM.doc_name,UM.sub_module_id,SD.sub_module_name FROM dbo.usermanuals UM inner join dbo.submodules SD on SD.id=UM.sub_module_id inner join dbo.modules MO on MO.id=UM.module_id where UM.sub_module_id=@sub_module_id";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@sub_module_id", Convert.ToInt32(typ));
            model.data = data.GetDataTable(cmd);
            return View(model);

        }

        #endregion





        public ActionResult SessionOut(string q)
        {
            if (string.IsNullOrEmpty(q)) { return RedirectToAction("UnauthorizedRequest", "Error"); }
            if (!q.ToUpper().Equals(CustomText.SUCCESS.ToString())) { return RedirectToAction("UnauthorizedRequest", "Error"); }

            NpgsqlCommand Cmd = new NpgsqlCommand("update useronlinedetails set whetherlogout=TRUE where whetherlogout=FALSE");
            new GetData().UpdateData(Cmd);
            return View();
        }

        #region global method current contoller
        //method for preserve nodel state
        public void PreserveModelState(string Key, object obj, bool IsKeep, bool IsRemove)
        {
            if (IsRemove == true) { TempData.Remove(Key); }
            if (obj != null) { TempData[Key] = obj; }
            if (IsKeep == true) { TempData.Keep(Key); }
        }
        #endregion global method current contoller

    }
}
