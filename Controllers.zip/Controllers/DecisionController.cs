﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using Edistrict.Models;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.DataService;
using Edistrict.Models.Entities;
using Npgsql;
using System.Collections;
using System.Web.UI;
using System.Web;
using System.Data;
using Edistrict.Models.CustomClass;
using ReportManagement;

namespace Edistrict.Controllers
{
    [Authorize]
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class DecisionController : Controller
    {
        #region Decision methods for Revenue Department
        [Authorize(Roles = "103,104,106,114,123,124")]
        [EncryptedActionParameter]
        public ActionResult PendingDecsionSummary(int sid)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();

            //string WhetherCondition = string.Empty;
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition = " and AD.OfficeCode in (@ParamAuthorizationId)  and AD.AcceptedBy in (@AcceptedBy)"; }
            //else { WhetherCondition = " and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.OfficeCode=@OfficeCode  and AD.AcceptedBy in (@AcceptedBy)"; }

            string addScript = Utility.GetScriptForAuthorizationProcess();

            //string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@SourceWindow then 1 end),0) as atCSC,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@SourceOnline then 1 end),0) as atOnline from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode  and AD.AcceptedBy in (@AcceptedBy) and AD.ServiceCode in (@ParamServiceCode) " + WhetherCondition + " group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@SourceWindow then 1 end),0) as atCSC,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@SourceOnline then 1 end),0) as atOnline from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode  and AD.AcceptedBy in (@AcceptedBy) and AD.ServiceCode in (@ParamServiceCode) " + addScript + " group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@SourceWindow", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@SourceOnline", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            model.data = data.GetDataTable(cmd);
            model.StatusId = sid.ToString();

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "103,104,114,123,124")]
        [EncryptedActionParameter]
        public ActionResult PendingDecsionList(int subDiv, int service, int status, int? SourceId)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();

            //string value = string.Empty;
            //if (SourceId != null) { value += " and ApplicationSourceId=@ApplicationSourceId"; }
            //string WhetherCondition = string.Empty;
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition = " and AD.OfficeCode in (@ParamAuthorizationId)  and AD.AcceptedBy in (@AcceptedBy)"; }
            //else { WhetherCondition = " and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.OfficeCode=@OfficeCode  and AD.AcceptedBy in (@AcceptedBy)"; }

            string addScript = Utility.GetScriptForAuthorizationProcess();
            if (SourceId != null) { addScript += " and AD.ApplicationSourceId=@ApplicationSourceId"; }

            //string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where DM.deptcode=@ParamDeptCode and AD.ServiceCode=@ServiceCode " + WhetherCondition + " and AD.ApplicationStatusId=@ApplicationStatusId " + value + " order by AD.applicationdate";
            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where DM.deptcode=@ParamDeptCode and AD.ServiceCode=@ServiceCode and AD.AcceptedBy in (@AcceptedBy) and AD.ApplicationStatusId=@ApplicationStatusId " + addScript + " order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", status);
            if (SourceId != null) { cmd.Parameters.AddWithValue("@ApplicationSourceId", SourceId); }
            cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [Authorize(Roles = "103,104,114,123,124")]
        [EncryptedActionParameter]
        public ActionResult SearchAppForDecision(int sid)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            model.StatusId = sid.ToString();

            string Qry = "select StatusName from dbo.StatusMaster where StatusId=@StatusId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@StatusId", model.StatusId);
            ViewBag.ListTitle = data.SelectColumns(Cmd)[0];

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "103,104,114,123,124")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult SearchAppForDecision(DecisionModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationNo });
                return RedirectToAction(Utility.GetDecisionControllerName(Sessions.getEmployeeUser().DeptCode, null, ((int)CountList.Type001).ToString()), "Decision", new { q = QueryString });
            }
            return View(model);
        }
        [Authorize(Roles = "103,104,114,123,124")]
        [EncryptedActionParameter]
        public ActionResult PendingApplicationDecisionDetails(Int64 AppNo, int? Source = 0)
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }

            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();
            if (Source != 0) { model.Source = Source.ToString(); }

            //string WhetherCondition = string.Empty, DisplayMessage = string.Empty;
            //string[] Values = Utility.GetServiceCode(Convert.ToInt64(model.ApplicationDetails.ApplicationNo));
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) 
            //{ 
            //    WhetherCondition = " and OfficeCode in (@ParamAuthorizationId)  and AcceptedBy in (@AcceptedBy)"; 
            //}
            //else 
            //{
            //    if (Convert.ToInt32(Values[0]) == (int)ServiceList.NOC)
            //    {
            //        WhetherCondition += " and ApplicationDistrictCode in (@ParamDistrictCode) and OfficeCode=@OfficeCode and AcceptedBy in (@AcceptedBy)";
            //    }
            //    else
            //    {
            //        WhetherCondition += " and ApplicationSubdivCode in (@ParamSubDivCode) and OfficeCode=@OfficeCode and AcceptedBy in (@AcceptedBy)";
            //    }
            //}

            string addScript = Utility.GetScriptForAuthorizationProcess();
            string serviceCode = Utility.GetServiceCode(Convert.ToInt64(model.ApplicationDetails.ApplicationNo))[0];
            if (Convert.ToInt32(serviceCode) == (int)ServiceList.NOC)
            {
                addScript = " and AD.ApplicationDistrictCode in (@ParamDistrictCode)";
                if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { addScript += " and AD.OfficeCode in (@ParamAuthorizationId)"; }
            }

            //string Qry = "select ServiceCode,ApplicationStatusId from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo " + WhetherCondition + " and ServiceCode in (@ParamServiceCode)";
            string Qry = "select AD.ServiceCode,AD.ApplicationStatusId from dbo.ApplicationDetails AD inner join servicemaster SM on SM.ServiceCode=AD.ServiceCode where AD.ApplicationNo=@ApplicationNo and SM.deptcode=@ParamDeptCode and AD.AcceptedBy in (@AcceptedBy) and AD.ServiceCode in (@ParamServiceCode) " + addScript;
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //Cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            string[] GetValues = data.SelectColumns(Cmd);
            model.ApplicationDetails.ServiceCode = GetValues[0];
            model.ApplicationDetails.ApplicationStatusId = GetValues[1];

            //Dictionary<string, string> ValidateData = new Dictionary<string, string>();
            //ValidateData.Add("ApplicationNo", model.ApplicationDetails.ApplicationNo);

            //string[] ValidationCheck = Utility.ApplicationValidation(ValidateData, (int)ValidationCheckLevels.DecisionProcessGeneralGet, false);
            //if (ValidationCheck[0] == ((int)CountList.Type001).ToString())
            //{
            //    PreserveModelState(Constant._ActionMessage, ValidationCheck[1], false, true);
            //    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId) });
            //    return RedirectToAction("SearchAppForDecision", new { q = QueryString });
            //}
            //else if (ValidationCheck[0] == ((int)CountList.Type002).ToString())
            //{
            //    ViewData["message"] = ValidationCheck[1];
            //    return View("message");
            //}

            //if (model.ApplicationDetails.ApplicationStatusId != ((int)Status.TEHSPEN).ToString() && model.ApplicationDetails.ApplicationStatusId != ((int)Status.VERLGAZ).ToString() && model.ApplicationDetails.ApplicationStatusId != ((int)Status.VERLOTHS).ToString() && model.ApplicationDetails.ApplicationStatusId != ((int)Status.VERSENT).ToString() && model.ApplicationDetails.ApplicationStatusId != ((int)Status.OBSPEND).ToString() && model.ApplicationDetails.ApplicationStatusId != ((int)Status.OBSPEN2).ToString())
            //{
            //    PreserveModelState(Constant._ActionMessage, "Application Not Found, Kindly Check Your Application No.", false, true);
            //    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.ApplicationDetails.ApplicationStatusId });
            //    return RedirectToAction("SearchAppForAction", new { q = QueryString });
            //}

            //check whether document verified or not??
            Qry = "select documentstatusid from web.registrationmaster RM left outer join dbo.applicationdetails AD on RM.RegistrationId=AD.RegistrationId where AD.ApplicationNo=@ApplicationNo and RM.DocumentId in (@AadhaarCard,@VoterID)";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@AadhaarCard", ((int)DocumentId.AadhaarCard).ToString());
            Cmd.Parameters.AddWithValue("@VoterID", ((int)DocumentId.VoterID).ToString());
            model.DocumentStatusId = data.SelectColumns(Cmd)[0];

            string flag = Utility.SelectColumnsValue("dbo.VerifierVerificationReport", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
            if (string.IsNullOrEmpty(flag)) { model.WhetherVerification = false; } else { model.WhetherVerification = true; }

            if (Convert.ToInt32(model.ApplicationDetails.ServiceCode) != (int)ServiceList.NOC)
            {
                Qry = "select UM.UID,UM.UserName from UserMaster UM inner join UserToSubDivMaster SDM on SDM.Uid=UM.Uid where UM.DistrictCode=@DistrictCode and SDM.SubDivCode in (@ParamSubDivCode) and UM.Permission=@Permission";
                Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@DistrictCode", Sessions.getEmployeeUser().DistrictCode);
                Cmd.Parameters.AddWithValue("@Permission", Convert.ToString((int)Permission.VERF));
                model.VerifierMaster = new SelectList(UserMaster.List<UserMaster>(Cmd), "UID", "UserName");
            }

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.VerifierVerificationDetails = Utility.GetVerifierVerificationDetails(model.ApplicantDetails.ApplicationNo);
            model.VerifierWitnessMaster = Utility.GetVerifierWitnessMasterDetails(model.ApplicantDetails.ApplicationNo);
            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data1 = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data2 = Utility.GetServiceSpecificVerificationDetails(model.ApplicationDetails.ApplicationNo);
            model.data3 = Utility.GetObjectionDetails(model.ApplicantDetails.ApplicationNo.ToString());
            model.data4 = Utility.GetApplicationAuditTrail(model.ApplicantDetails.ApplicationNo);
            model.data6 = Utility.GetSingleDocVerificationStatus(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.data9 = Utility.GetPaymentDetails(model.ApplicationDetails.ApplicationNo);
            model.data10 = Utility.GetRectifyDocumentDetails(model.ApplicationDetails.ApplicationNo);
            model.data11 = Utility.GetMobileSahayakDetailsData(model.ApplicationDetails.ApplicationNo);
            model.IsPhysicalDocVerificationDone = Utility.IsPhysicalVerificationDone(model.ApplicationDetails.ApplicationNo);

            model.IsAlreadyVerified = Utility.SelectColumnsValue("dbo.VerifierApplicationDetails", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
            model.WhetherVerificationLetterRequired = false;
            //if (Values[1] == ((int)Department.Dept007).ToString()) { model.data10 = Utility.GetLBRChallanStatus(model.ApplicationDetails.ApplicationNo, model.ApplicationDetails.ServiceCode); }

            //Qry = "select AD.ApplicationNo from applicationdetails AD where applicationstatusid=@applicationstatusid and registrationid=@registrationid";
            //Cmd = new NpgsqlCommand(Qry);
            //Cmd.Parameters.AddWithValue("@applicationstatusid", (int)Status.ISSUCER);
            //Cmd.Parameters.AddWithValue("@registrationid", model.ApplicantDetails.RegistrationId);
            //model.data5 = data.GetDataTable(Cmd);
            model.data5 = Utility.GetApplicantAvailedService(model.ApplicantDetails.RegistrationId.ToString());


            model.WhetherDocVerified = true;
            //if (Values[1] == ((int)Department.Dept003).ToString() || Values[1] == ((int)Department.Dept007).ToString())
            //{
            //    model.WhetherDocVerified = Utility.CheckWhetherDocVerify(model.ApplicationDetails.ApplicationNo);
            //}
            //else
            //{
            //    model.WhetherDocVerified = true;
            //}

            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Marriage)
            {
                model.ApplicationMarriageDetails = Utility.GetMarriageDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.MarriageWitnessDetails = Utility.GetMarriageWitnessDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());

                // Check Husband and Wife Age Criteria [skipped for 90730000017124]
                string rtnAppNo = Utility.CheckApplicationExemptAllow(model.ApplicantDetails.ApplicationNo);
                if (string.IsNullOrEmpty(rtnAppNo))
                {
                    // Check Husband and Wife Age Criteria [skipped for 90730000017124]
                    bool HAge = Utility.CheckMarriageAgeCriteria(RegistrationType.H.ToString(), model.ApplicationMarriageDetails.HDOB, model.ApplicationMarriageDetails.MarriageDate);
                    bool WAge = Utility.CheckMarriageAgeCriteria(RegistrationType.W.ToString(), model.ApplicationMarriageDetails.WDOB, model.ApplicationMarriageDetails.MarriageDate);
                    if (HAge == false || WAge == false)
                    {
                        ViewData["message"] = "Age criteria of Husband/Wife does not full fill, kindly enter valid details to further process.";
                        return View("message");
                    }
                }

                string Currdate = System.DateTime.Now.ToString("yyyyMMdd");
                if (Currdate != model.ApplicationMarriageDetails.ActualAppointmentDate)
                {
                    model.ApplicationMarriageDetails.WhetherPriorAfterDecisionRemark = CustomText.TRUE.ToString();
                }
                else
                {
                    model.ApplicationMarriageDetails.WhetherPriorAfterDecisionRemark = CustomText.FALSE.ToString();
                }

                PreserveModelState(Constant._ModelStateParent, model, false, true);
                return View("PendingMarriageDecisionDetails", model);
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Solemnization)
            {
                model.ApplicationMarriageDetails = Utility.GetMarriageSolemnizationDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.MarriageWitnessDetails = Utility.GetMarriageWitnessDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());

                Qry = "select distinct to_char(AppointmentDate,'DD/MM/YYYY') as AppointmentDateText,to_char(AppointmentDate,'DD/MM/YYYY') as AppointmentDateValue,AppointmentDate from dbo.AppointmentMaster where AppointmentDate::date>(now()::date + interval '29' day) and SubDivCode=@SubDivCode and ServiceCode=@ServiceCode order by AppointmentDate LIMIT 12";
                NpgsqlCommand Cmd1 = new NpgsqlCommand(Qry);
                Cmd1.Parameters.AddWithValue("@ServiceCode", model.ApplicationDetails.ServiceCode);
                Cmd1.Parameters.AddWithValue("@SubDivCode", Sessions.getEmployeeUser().SubDivCode);
                model.SolemnizationDateList = new SelectList(AppointmentDate.List<AppointmentDate>(Cmd1), "AppointmentDateValue", "AppointmentDateText");

                model.SolemnizationDate = model.ApplicationMarriageDetails.SolemnizationDate;
                if (!string.IsNullOrEmpty(model.SolemnizationDate))
                {
                    if ((Convert.ToDateTime(model.SolemnizationDate) - Convert.ToDateTime(DateTime.Now.ToShortDateString())).Days <= 0)
                    {
                        model.WhetherSolemnizationDatePassed = true;
                    }
                    else
                    {
                        model.WhetherSolemnizationDatePassed = false;
                    }
                }

                Cmd = new NpgsqlCommand("select AV.LetterDetailsId,AV.ApplicationNo,AV.TypeValueId, SV.ValueName,to_char(AV.GenerateDate,'DD/MM/YYYY') as GenerateDate,AV.Generateby,AV.WhetherVerificationUpload,to_char(AV.UploadDate,'DD/MM/YYYY') as UploadDate,AV.Uploadby from dgen.SolemnizationLetterDetails AV inner join dbo.SelectMasterValueDetails SV on SV.ValueId=AV.TypeValueId where AV.ApplicationNo=@ApplicationNo and AV.TypeValueId=@TypeValueId");
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@TypeValueId", (int)LetterTypeValueId.SolemnizationVerificationLetter);
                Cmd.Parameters.AddWithValue("@WhetherVerificationUpload", CustomText.True.ToString());
                model.dtVerificationLetter = data.GetDataTable(Cmd);

                PreserveModelState(Constant._ModelStateParent, model, false, true);
                return View("PendingMarriageDecisionDetails", model);
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Domicile)
            {
                model.ApplicationDetailsDomicile = Utility.GetDomicileDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                if (model.ApplicationDetailsDomicile.WhetherGazettedProof.ToLower() == "true") { model.WhetherVerificationLetterRequired = true; }
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Solvency)
            {
                model.ApplicationDetailsSolvency = Utility.GetSolvencyDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Disability)
            {
                model.ApplicationDetailsDisability = Utility.GetDisabilityDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Nationality)
            {
                model.ApplicationDetailsNationality = Utility.GetNationalityDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.WhetherVerificationLetterRequired = true;
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Birth)
            {
                model.ApplicationDetailsBirth = Utility.GetBirthDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Death)
            {
                model.ApplicationDetailsDeath = Utility.GetDeathDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Income)
            {
                model.ApplicationDetailsIncome = Utility.GetIncomeDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.SCST)
            {
                model.ApplicationDetailsSCST = Utility.GetSCSTDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.ApplicationLetterDetailsModel = Utility.GetApplicationLetterDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                if ((model.ApplicationDetailsSCST.StateId != ((int)State.Delhi).ToString()) && (model.ApplicationDetailsSCST.WhetherRelationSCST.ToLower() == "true")) { model.WhetherVerificationLetterRequired = true; }

                model.Flag = Utility.GetCasteApprovalDetails(model.ApplicationDetailsSCST.CasteId.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.ST)
            {
                model.ApplicationDetailsST = Utility.GetSTDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.ApplicationLetterDetailsModel = Utility.GetApplicationLetterDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                if ((model.ApplicationDetailsST.StateId != ((int)State.Delhi).ToString()) && (model.ApplicationDetailsST.WhetherRelationST.ToLower() == "true")) { model.WhetherVerificationLetterRequired = true; }

                model.Flag = Utility.GetCasteApprovalDetails(model.ApplicationDetailsST.CasteId.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.NT)
            {
                model.ApplicationDetailsNT = Utility.GetNTDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.ApplicationLetterDetailsModel = Utility.GetApplicationLetterDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                if ((model.ApplicationDetailsNT.StateId != ((int)State.Delhi).ToString()) && (model.ApplicationDetailsNT.WhetherRelationNT.ToLower() == "true")) { model.WhetherVerificationLetterRequired = true; }

                model.Flag = Utility.GetCasteApprovalDetails(model.ApplicationDetailsNT.CasteId.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.OBC)
            {
                bool WhetherOld = false;
                string ApplicationDate = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ApplicationDate", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0];
                if (Convert.ToDateTime(ApplicationDate) < Convert.ToDateTime(Constant._OBCDate)) { WhetherOld = true; }
                model.ApplicationDetailsOBC = Utility.GetOBCDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.ApplicationDetailsOBC.WhetherOld = WhetherOld;
                model.ApplicationDetailsOBC.OBCIncomeDetails = Utility.GetOBCIncomeDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.ApplicationLetterDetailsModel = Utility.GetApplicationLetterDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                if ((model.ApplicationDetailsOBC.StateId != ((int)State.Delhi).ToString()) && (model.ApplicationDetailsOBC.WhetherRelationObc.ToLower() == "true")) { model.WhetherVerificationLetterRequired = true; }

                model.Flag = Utility.GetCasteApprovalDetails(model.ApplicationDetailsOBC.CasteId.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.LalDora)
            {
                model.ApplicationDetailsLalDora = Utility.GetLalDoraDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.LalDoraWitnessDetails = Utility.GetWitnessDetailsLalDora(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Surviving)
            {
                model.ApplicationDetailsSurviving = Utility.GetSurvivingDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.CDVolunteer)
            {
                model.ApplicationDetailsCDV = Utility.GetCDVDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                string Qr = "select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid";
                NpgsqlCommand cmd = new NpgsqlCommand(Qr);
                cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CDVServices);
                model.datacdv = data.GetDataTable(cmd);

                model.WhetherVerificationLetterRequired = true;
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.NOC)
            {
                model.ApplicationDetailsNOC = Utility.GetNOCDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.datanoc = Utility.GetNOCApplicationRemarks(model.ApplicantDetails.ApplicationNo.ToString());
                model.NOCApplicationRemarks = new NOCApplicationRemarks();
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Migration)
            {
                model.ApplicationDetailsMigration = Utility.GetMigrationDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Recovery)
            {
                model.ApplicationDetailsRecovery = Utility.GetRecoveryDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.RecoveryNoticeDetails = new RecoveryNoticeDetails();
                model.RecoveryNoticeDetails.dtDef = model.ApplicationDetailsRecovery.dt2;
                model.RecoveryNoticeDetails.IssueDate = DateTime.Now.ToShortDateString();
                model.RecoveryNoticeDetails.Remarks = "If the due Date is Gazetted Holiday for any other reason, the next working date will be treated as the due date.";
                string Q = "select typeid,to_char(generatedate,'DD/MM/YYYY') as generatedate from dgen.recoverynoticedetails where ApplicationNo=@ApplicationNo order by lastactiondate desc";
                NpgsqlCommand Cm = new NpgsqlCommand(Q);
                Cm.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
                DataTable dta = data.GetDataTable(Cm);
                if (dta.Rows.Count > 0)
                {
                    if (dta.Rows[0]["typeid"].ToString() == ((int)CountList.Type000).ToString())
                    {
                        model.RecoveryNoticeDetails.WhetherProceedingDetails = CustomText.False.ToString();
                    }
                    else
                    {
                        model.RecoveryNoticeDetails.WhetherProceedingDetails = CustomText.True.ToString();
                        string temp = Utility.SelectColumnsValue("dbo.selectmastervaluedetails", "valuename", "valueid", dta.Rows[0]["typeid"].ToString())[0];
                        model.RecoveryNoticeDetails.ProceedingHeading = temp + " generated on " + dta.Rows[0]["generatedate"].ToString();
                    }
                }
                else { model.RecoveryNoticeDetails.WhetherProceedingDetails = CustomText.False.ToString(); }
                model.RecoveryNoticeDetails.RName = Utility.SelectColumnsValue("dbo.usermaster", "username", "userid", Sessions.getEmployeeUser().UserId)[0];
                PreserveModelState(Constant._ModelStateParent, model, false, true);
                return View("PendingRecoveryDecisionDetails", model);
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.SocietyRegistration)
            {
                model.ApplicationDetailsSociety = Utility.GetApplicationDetailsSociety(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.FirmRegistration)
            {
                model.ApplicationDetailsFirm = Utility.GetApplicationDetailsFirm(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PrematricScholarshipSC)
            //{
            //    model.ApplicationDetailsPrematsSC = Utility.GetPrematsSCDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.FinancialAssistanceStationery)
            //{
            //    model.ApplicationDetailsFinancialAssistance = Utility.GetFinancialAssistanceDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MeritscholarshipSchool)
            //{
            //    model.ApplicationDetailsMeritscholarshipSchool = Utility.GetMeritscholarshipSchoolDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.DrbrAmbedkarToppers)
            //{
            //    model.ApplicationDetailsDrbrAmbedkarToppers = Utility.GetDrbrAmbedkarToppersDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MeritscholarshipProfessional)
            //{
            //    model.ApplicationDetailsMeritProfessional = Utility.GetMeritscholarshipProfessionalDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PrematricScholarshipOBC)
            //{
            //    model.ApplicationDetailsPrematOBC = Utility.GetPrematsOBCDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PostmatricScholarshipOBC)
            //{
            //    model.ApplicationDetailsPostmatOBC = Utility.GetPostmatOBCDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //}
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.CertifiedCopyFromSR)
            {
                model.ApplicationDetailsSRCopy = Utility.GetCertifiedCopyFromSR(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Demarcation)
            {
                model.ApplicationDetailsDemarcation = Utility.GetDemarcationDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else
            {
                return RedirectToAction("UnauthorizedRequest", "Error");
            }

            if (model.WhetherVerificationLetterRequired == true)
            {
                model.WhetherVerificationLetterRequired = Utility.CheckVerificationLetter(model.ApplicantDetails.ApplicationNo);

                Qry = "select 0 as LetterDetailsId,AV.ApplicationNo,AV.TypeValueId, SV.ValueName,to_char(AV.GenerateDate,'DD/MM/YYYY') as GenerateDate,AV.Generateby,AV.WhetherVerificationUpload,AV.UploaddocumentData,to_char(AV.UploadDate,'DD/MM/YYYY') as UploadDate,AV.Uploadby from dbo.ApplicationVerificationLetterDetails AV inner join dbo.SelectMasterValueDetails SV on SV.ValueId=AV.TypeValueId where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
                model.dtVerificationLetter = data.GetDataTable(Cmd);
            }

            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.InstallationOfLift)
            //{
            //    model.ApplicationDetailsInstallationOfLift = Utility.GetInstallationOfLiftDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            //    model.IsAlreadyInspected = Utility.SelectColumnsValue("dgen.lbrliftinspectionmaster", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
            //    if (!string.IsNullOrEmpty(model.IsAlreadyInspected))
            //    {
            //        model.data7 = Utility.GetLBRLiftInspectionDetails(model.ApplicationDetails.ApplicationNo);
            //    }
            //    PreserveModelState(Constant._ModelStateParent, model, false, true);
            //    return View("PendingLabourDecisionDetails", model);
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.GrantOfPassengerLift)
            //{
            //    model.ApplicationDetailsGrantOfPassengerLift = Utility.GetGrantOfPassengerLiftDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            //    model.LBRPaymentStatus = Utility.GetLBRPaymentStatus(model.ApplicantDetails.ApplicationNo.ToString());
            //    model.PAmount = Utility.GetConditionalFee(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString()).ToString();
            //    model.IsAlreadyInspected = Utility.SelectColumnsValue("dgen.lbrliftinspectionmaster", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
            //    if (!string.IsNullOrEmpty(model.IsAlreadyInspected))
            //    {
            //        model.data7 = Utility.GetLBRLiftInspectionDetails(model.ApplicationDetails.ApplicationNo);
            //    }
            //    PreserveModelState(Constant._ModelStateParent, model, false, true);
            //    return View("PendingLabourDecisionDetails", model);
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.RenewalOfPassengerLift)
            //{
            //    model.ApplicationDetailsRenewalOfPassengerLift = Utility.GetRenewalOfPassengerLiftDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            //    model.LBRPaymentStatus = Utility.GetLBRPaymentStatus(model.ApplicantDetails.ApplicationNo.ToString());
            //    model.PAmount = Utility.GetConditionalFee(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString()).ToString();
            //    model.IsAlreadyInspected = Utility.SelectColumnsValue("dgen.lbrliftinspectionmaster", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
            //    if (!string.IsNullOrEmpty(model.IsAlreadyInspected))
            //    {
            //        model.data7 = Utility.GetLBRLiftInspectionDetails(model.ApplicationDetails.ApplicationNo);
            //    }
            //    PreserveModelState(Constant._ModelStateParent, model, false, true);
            //    return View("PendingLabourDecisionDetails", model);
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.LbrRecovery)
            //{
            //    model.ApplicationDetailsLBRRecovery = Utility.GetLBRRecoveryDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //    Qry = "select NID from dgen.recoverynoticedetails where ApplicationNo=@ApplicationNo and TypeId=@TypeId and WhetherGenerated=@WhetherGenerated and ProceedingDetails is null";
            //    Cmd = new NpgsqlCommand(Qry);
            //    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            //    Cmd.Parameters.AddWithValue("@TypeId", (int)ValueId.Notice);
            //    Cmd.Parameters.AddWithValue("@WhetherGenerated", CustomText.TRUE.ToString());
            //    string[] GVal = data.SelectColumns(Cmd);
            //    if (GVal.Length > 0) { model.ApplicationDetailsLBRRecovery.NoticeId = GVal[0]; }
            //    if (!string.IsNullOrEmpty(model.ApplicationDetailsLBRRecovery.NoticeId))
            //    { model.ApplicationDetailsLBRRecovery.WhetherProceedingDetails = CustomText.TRUE.ToString(); }
            //    else { model.ApplicationDetailsLBRRecovery.WhetherProceedingDetails = CustomText.FALSE.ToString(); }
            //    PreserveModelState(Constant._ModelStateParent, model, false, true);
            //    return View("PendingLabourDecisionDetails", model);
            //}

            ////Temp Code
            //if (Sessions.getEmployeeUser().Permission.Equals(((int)Permission.SDMG).ToString()))
            //    model.ApplicationDetails.ApplicationStatusId = ((int)Status.TEHSREC).ToString();

            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [Authorize(Roles = "103,104,114,123,124")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingApplicationDecisionDetails(DecisionModels model, FormCollection frm)
        {
            model.ServiceCode = Utility.SelectColumnsValue("ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0];
            model.DeptCode = Utility.GetDeptCode(model.ServiceCode);

            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                //bool BypassPermission = false;
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string QueryString = string.Empty, Qry = string.Empty, DisplayMessage = string.Empty;

                bool StopDataCheckRequired = false;
                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.VERSENT).ToString()) { StopDataCheckRequired = true; }

                Dictionary<string, string> ValidateData = new Dictionary<string, string>();
                ValidateData.Add("ApplicationNo", model.ApplicationDetails.ApplicationNo);
                string[] ValidationCheck = Utility.ApplicationValidation(ValidateData, (int)ValidationCheckLevels.DecisionProcessGeneralPost, StopDataCheckRequired);
                if (ValidationCheck[0] == ((int)CountList.Type001).ToString())
                {
                    PreserveModelState(Constant._ActionMessage, ValidationCheck[1], false, true);
                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                    return RedirectToAction("PendingApplicationDecisionDetails", "Decision", new { q = QueryString });
                }
                else if (ValidationCheck[0] == ((int)CountList.Type002).ToString())
                {
                    ViewData["message"] = ValidationCheck[1];
                    return View("message");
                }


                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREC).ToString())
                {
                    if (model.ServiceCode.Equals(((int)ServiceList.Marriage).ToString()))
                    {
                        string[] value = Utility.SelectColumnsValue("dgen.ApplicationMarriageDetails", "to_char(HDOB,'DD/MM/YYYY') as HDOB,to_char(WDOB,'DD/MM/YYYY') as WDOB,to_char(MarriageDate,'DD/MM/YYYY') as MarriageDate", "ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        string HDOB = value[0];
                        string WDOB = value[1];
                        string MarriageDate = value[2];
                        
                        // Check Husband and Wife Age Criteria [skipped for 90730000017124]
                        string rtnAppNo = Utility.CheckApplicationExemptAllow(model.ApplicationDetails.ApplicationNo);
                        if (string.IsNullOrEmpty(rtnAppNo))
                        {
                            bool HAge = Utility.CheckMarriageAgeCriteria(RegistrationType.H.ToString(), HDOB, MarriageDate);
                            bool WAge = Utility.CheckMarriageAgeCriteria(RegistrationType.W.ToString(), WDOB, MarriageDate);
                            if (HAge == false || WAge == false)
                            {
                                ViewData["message"] = "Age criteria of Husband/Wife does not full fill, kindly enter valid details to further process.";
                                return View("message");
                            }
                        }

                        string RSystemDate = Utility.SelectColumnsValue("dgen.applicationmarriagedetails", "RegistrationSystemDate", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0];
                        if (string.IsNullOrEmpty(RSystemDate))
                        {
                            bool result = Utility.CheckCorrectDecisionDate(model.ServiceCode, model.ApplicationDetails.ApplicationNo, model.ApplicationMarriageDetails.RegistrationPerformDate);
                            if (result == false)
                            {
                                string Message = "Please enter the Corret Registration Date of Marriage!!!";
                                PreserveModelState(Constant._ActionMessage, Message, false, true);
                                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                                return RedirectToAction("PendingApplicationDecisionDetails", "Decision", new { q = QueryString });
                            }
                        }

                        string whethercondition = string.Empty;
                        if (string.IsNullOrEmpty(RSystemDate)) { whethercondition = " RegistrationPerformDate=@RegistrationPerformDate, "; }

                        NpgsqlCommand updCmd = new NpgsqlCommand("update dgen.applicationmarriagedetails set MarriageActId=@MarriageActId,WhetherFooterRequired=@WhetherFooterRequired,PriorAfterDecisionRemarks=@PriorAfterDecisionRemarks," + whethercondition + "userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo");
                        updCmd.Parameters.AddWithValue("@WhetherFooterRequired", model.ApplicationMarriageDetails.WhetherFooterRequired);
                        if (string.IsNullOrEmpty(RSystemDate)) { updCmd.Parameters.AddWithValue("@RegistrationPerformDate", Utility.GetDateYYYYMMDD(model.ApplicationMarriageDetails.RegistrationPerformDate, '/', "0/1/2")); }
                        updCmd.Parameters.AddWithValue("@MarriageActId", model.MarriageActId);
                        updCmd.Parameters.AddWithValue("@PriorAfterDecisionRemarks", model.ApplicationMarriageDetails.PriorAfterDecisionRemarks);
                        updCmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        updCmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        updCmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        data.UpdateData(updCmd);
                    }
                    else if (model.ServiceCode.Equals(((int)ServiceList.Solemnization).ToString()))
                    {
                        string[] value = Utility.SelectColumnsValue("dgen.ApplicationMarriageSolemnizationDetails", "to_char(HDOB,'DD/MM/YYYY') as HDOB,to_char(WDOB,'DD/MM/YYYY') as WDOB", "ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        string HDOB = value[0];
                        string WDOB = value[1];
                        bool HAge = Utility.CheckMarriageAgeCriteria(RegistrationType.H.ToString(), HDOB, null);
                        bool WAge = Utility.CheckMarriageAgeCriteria(RegistrationType.W.ToString(), WDOB, null);
                        if (HAge == false || WAge == false)
                        {
                            ViewData["message"] = "Age criteria of Husband/Wife does not full fill, kindly enter valid details to further process.";
                            return View("message");
                        }

                        string SSystemDate = Utility.SelectColumnsValue("dgen.applicationmarriagesolemnizationdetails", "SolemnizationSystemDate", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0];
                        if (string.IsNullOrEmpty(SSystemDate))
                        {
                            bool result = Utility.CheckCorrectDecisionDate(model.ServiceCode, model.ApplicationDetails.ApplicationNo, model.ApplicationMarriageDetails.SolemnizationPerformDate);
                            if (result == false)
                            {
                                string Message = "Please enter the Corret Solemnization Date!!!";
                                PreserveModelState(Constant._ActionMessage, Message, false, true);
                                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                                return RedirectToAction("PendingApplicationDecisionDetails", "Decision", new { q = QueryString });
                            }
                        }
                        string whethercondition = string.Empty;
                        if (string.IsNullOrEmpty(SSystemDate)) { whethercondition = " SolemnizationPerformDate=@SolemnizationPerformDate, "; }

                        NpgsqlCommand updCmd = new NpgsqlCommand("update dgen.applicationmarriagesolemnizationdetails set MarriageActId=@MarriageActId," + whethercondition + "userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo");
                        updCmd.Parameters.AddWithValue("@MarriageActId", model.MarriageActId);
                        if (string.IsNullOrEmpty(SSystemDate)) { updCmd.Parameters.AddWithValue("@SolemnizationPerformDate", Utility.GetDateYYYYMMDD(model.ApplicationMarriageDetails.SolemnizationPerformDate, '/', "0/1/2")); }
                        updCmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        updCmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        updCmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(updCmd);

                        cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG002, null, (int)ApplicationSource.Window, null));

                        data.SaveData(cmdList);
                    }
                    else if (model.ServiceCode.Equals(((int)ServiceList.NOC).ToString()))
                    {
                        if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.P114).ToString())
                        {
                            Qry = "select N.VillageId,A.ApplicationNo,A.AId,A.KhasraNo,A.RectangleNo from dgen.NOCApplicationAreaDetails A inner join dgen.ApplicationDetailsNOC N on N.ApplicationNo=A.ApplicationNo where A.ApplicationNo=@ApplicationNo";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                            DataTable dt = data.GetDataTable(Cmd);
                            if (dt.Rows.Count > 0)
                            {
                                for (int i = 0; i < dt.Rows.Count; i++)
                                {
                                    Cmd = new NpgsqlCommand("insert into dgen.NOCAcquisitionDetails (ApplicationNo,AcquisitionId,VillageId,rectangleno,KhasraNo,Bigha,Biswa,Biswansi,Min,acquisitiontypeid,acquisitionno,acquisitiondate,acquisitionapprovaldate,acquisitionremarks,WhetherActive,userid,ipaddress,lastactiondate) select @ApplicationNo as ApplicationNo,AQ.AcquisitionId,AQ.VillageId,AQ.rectangleno,AQ.KhasraNo,AQ.Bigha,AQ.Biswa,AQ.Biswansi,AQ.Min,AQ.acquisitiontypeid,AQ.acquisitionno,AQ.acquisitiondate,AQ.acquisitionapprovaldate,AQ.acquisitionremarks,AQ.WhetherActive,@userid,@ipaddress,now() from dgen.nocacquisitionmaster  AQ left outer join dgen.NOCAcquisitionDetails ND on ND.rectangleno=AQ.rectangleno and ND.khasrano=AQ.khasrano and ND.villageid=AQ.villageid where AQ.WhetherActive=@WhetherActive and AQ.RectangleNo=@RectangleNo and AQ.KhasraNo=@KhasraNo and AQ.VillageId=@VillageId and ND.id is null");
                                    Cmd.Parameters.AddWithValue("@RectangleNo", dt.Rows[i]["RectangleNo"]);
                                    Cmd.Parameters.AddWithValue("@KhasraNo", dt.Rows[i]["KhasraNo"]);
                                    Cmd.Parameters.AddWithValue("@VillageId", dt.Rows[i]["VillageId"]);
                                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                    cmdList.Add(Cmd);

                                    Cmd = new NpgsqlCommand("insert into dgen.NOCViolationDetails (ApplicationNo,ViolationId,VillageId,KhasraNo,rectangleno,ViolationActId,LandId,SectionId,vdate,remarks,whetheractive,userid,ipaddress,lastactiondate) select @ApplicationNo as ApplicationNo,V.ViolationId,V.VillageId,V.KhasraNo,V.rectangleno,V.ViolationActId,V.LandId,V.SectionId,V.vdate,v.remarks,v.whetheractive,@userid,@ipaddress,now() from dgen.nocviolationmaster V left outer join dgen.NOCViolationDetails D on D.rectangleno=V.rectangleno and D.khasrano=V.khasrano and D.villageid=V.villageid where V.VillageId=@VillageId and V.RectangleNo=@RectangleNo and V.KhasraNo=@KhasraNo and WhetherDeViolate=@WhetherDeViolate and V.WhetherActive=@WhetherActive and D.id is null");
                                    Cmd.Parameters.AddWithValue("@RectangleNo", dt.Rows[i]["RectangleNo"]);
                                    Cmd.Parameters.AddWithValue("@KhasraNo", dt.Rows[i]["KhasraNo"]);
                                    Cmd.Parameters.AddWithValue("@VillageId", dt.Rows[i]["VillageId"]);
                                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                                    Cmd.Parameters.AddWithValue("@WhetherDeViolate", CustomText.False.ToString());
                                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                    cmdList.Add(Cmd);
                                }
                                if (cmdList.Count > 0) { data.SaveData(cmdList); }
                            }
                        }
                        else { return RedirectToAction("UnauthorizedRequest", "Error"); }
                    }
                    else if (model.ServiceCode.Equals(((int)ServiceList.CDVolunteer).ToString()))
                    {
                        string Values = string.Empty;
                        List<NpgsqlCommand> cmdList2 = new List<NpgsqlCommand>();

                        Cmd = new NpgsqlCommand("update dgen.ApplicationDetailsCDV set EnrollmentNo=@ApplicationNo,Enrollmentdate=now() where ApplicationNo=@ApplicationNo and EnrollmentNo is null");
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        cmdList2.Add(Cmd);

                        Qry = "select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CDVServices);
                        model.datacdv = data.GetDataTable(Cmd);
                        for (int i = 0; i < model.datacdv.Rows.Count; i++)
                        {
                            if (frm[model.datacdv.Rows[i]["valueid"].ToString()] != null)
                            {
                                if (string.IsNullOrEmpty(Values)) { Values += frm[model.datacdv.Rows[i]["valueid"].ToString()]; }
                                else { Values += "," + frm[model.datacdv.Rows[i]["valueid"].ToString()]; }
                            }
                        }
                        if (string.IsNullOrEmpty(Values))
                        {
                            ViewBag.DisplayMessage = "Select atleast 1 service for the CDV aspirant.";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("PendingApplicationDecisionDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
                        }

                        Cmd = new NpgsqlCommand("update dgen.ApplicationDetailsCDV set SelectedServices=@SelectedServices where ApplicationNo=@ApplicationNo ");
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@SelectedServices", Values);
                        cmdList2.Add(Cmd);

                        data.SaveData(cmdList2);
                    }
                    else if (model.ServiceCode.Equals(((int)ServiceList.CertifiedCopyFromSR).ToString()) || model.ServiceCode.Equals(((int)ServiceList.Demarcation).ToString()))
                    {
                        Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                        Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                        Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationDetails.ApplicationNo, Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId), (int)CountList.Type001, DB.LS.ToString()));
                        Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG002, null, (int)ApplicationSource.Window, null));

                        data.SaveData(cmdList);
                        return View("message", ViewData["message"] = "Application has been processed Successfully.");
                    }

                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                    return RedirectToAction("ProcessApplicationApprovalRequest", "Sign", new { q = QueryString });
                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.NOTIACT).ToString())
                {
                    if (model.ServiceCode.Equals(((int)ServiceList.Solemnization).ToString()))
                    {
                        model.MarriageActId = ((int)MarriageAct.Special13).ToString();

                        Cmd = new NpgsqlCommand("update dgen.ApplicationMarriageSolemnizationDetails set SolemnizationDate=@SolemnizationDate,NoticeGenerateDate=now(),marriageactid=@marriageactid,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo");
                        Cmd.Parameters.AddWithValue("@SolemnizationDate", Utility.GetDateYYYYMMDD(model.SolemnizationDate, '/', "0/1/2"));
                        Cmd.Parameters.AddWithValue("@marriageactid", model.MarriageActId);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        Cmd = new NpgsqlCommand("update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,UserId=@UserId,IpAddress=@IpAddress,LastActionDate=now() where ApplicationNo=@ApplicationNo");
                        Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        Cmd = new NpgsqlCommand("update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,UserId=@UserId,IpAddress=@IpAddress,actiondatetime=now() where ApplicationNo=@ApplicationNo");
                        Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG049, null, (int)ApplicationSource.Window, null));

                        data.SaveData(cmdList);

                        ViewBag.DisplayMessage = "Application[" + model.ApplicationDetails.ApplicationNo + "] has been successfully processed, and Solemnization Date is: [" + model.SolemnizationDate + "].\\nNow you can Generate Verification Letter and Notices for this application. ";

                        QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                        return RedirectToAction("GenerateVerificationLetter", "SDM", new { q = QueryString });
                    }
                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.OBSPEND).ToString())
                {
                    HttpPostedFile UploadData = System.Web.HttpContext.Current.Request.Files["PatwariReport"];
                    byte[] fileData = Utility.CompareFileCapturePhotoData(null, UploadData);
                    string contentType = UploadData.ContentType;
                    if (fileData == null)
                    {
                        ViewBag.DisplayMessage = "Please upload Patwari Report to proceed.";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View("PendingApplicationDecisionDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
                    }

                    Qry = "insert into dgen.nocapplicationremarks (ApplicationNo,PermReqFor,ApplicableAct,ClassificationOfLand,Whethervsec81t,Whethervsec81remarkst,Whethervsec33t,Whethervsec33remarkst,Whetherlfsec74t,Whetherlfsec74remarkst,Whetheranystayt,Whetheranystayremarkst,Whetheranyobjt,Whetheranyobjremarkst,tehobs,userid,ipaddress) values (@ApplicationNo,@PermReqFor,@ApplicableAct,@ClassificationOfLand,@Whethervsec81t,@Whethervsec81remarkst,@Whethervsec33t,@Whethervsec33remarkst,@Whetherlfsec74t,@Whetherlfsec74remarkst,@Whetheranystayt,@Whetheranystayremarkst,@Whetheranyobjt,@Whetheranyobjremarkst,@TEHObs,@userid,@ipaddress)";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@Whethervsec81t", model.NOCApplicationRemarks.Whethervsec81t);
                    Cmd.Parameters.AddWithValue("@Whethervsec81remarkst", model.NOCApplicationRemarks.Whethervsec81remarkst);
                    Cmd.Parameters.AddWithValue("@Whethervsec33t", model.NOCApplicationRemarks.Whethervsec33t);
                    Cmd.Parameters.AddWithValue("@Whethervsec33remarkst", model.NOCApplicationRemarks.Whethervsec33remarkst);
                    Cmd.Parameters.AddWithValue("@Whetherlfsec74t", model.NOCApplicationRemarks.Whetherlfsec74t);
                    Cmd.Parameters.AddWithValue("@Whetherlfsec74remarkst", model.NOCApplicationRemarks.Whetherlfsec74remarkst);
                    Cmd.Parameters.AddWithValue("@Whetheranystayt", model.NOCApplicationRemarks.Whetheranystayt);
                    Cmd.Parameters.AddWithValue("@Whetheranystayremarkst", model.NOCApplicationRemarks.Whetheranystayremarkst);
                    Cmd.Parameters.AddWithValue("@Whetheranyobjt", model.NOCApplicationRemarks.Whetheranyobjt);
                    Cmd.Parameters.AddWithValue("@Whetheranyobjremarkst", model.NOCApplicationRemarks.Whetheranyobjremarkst);
                    Cmd.Parameters.AddWithValue("@PermReqFor", model.NOCApplicationRemarks.PermReqFor);
                    Cmd.Parameters.AddWithValue("@ApplicableAct", model.NOCApplicationRemarks.ApplicableAct);
                    Cmd.Parameters.AddWithValue("@ClassificationOfLand", model.NOCApplicationRemarks.ClassificationOfLand);
                    Cmd.Parameters.AddWithValue("@TEHObs", model.ApplicationDetails.ApplicationRemarks);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);


                    Qry = "insert into dbo.applicationdocumentdetails (ApplicationNo,DocumentValueId,DocumentData,DocumentContentType,userid,ipaddress) values (@ApplicationNo,@DocumentValueId,@DocumentData,@DocumentContentType,@userid,@ipaddress)";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@DocumentValueId", (int)ValueId.PatwariReport);
                    Cmd.Parameters.AddWithValue("@DocumentData", fileData);
                    Cmd.Parameters.AddWithValue("@DocumentContentType", contentType);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, model.WhetherRecommend + " by Tehsildar : " + model.ApplicationDetails.ApplicationRemarks, (int)ApplicationSource.Window, null));
                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.OBSPEN2).ToString())
                {
                    Qry = "update dgen.nocapplicationremarks set Whethernsec4nt=@Whethernsec4nt,Whethernsec4remarksnt=@Whethernsec4remarksnt,Whethernsec6nt=@Whethernsec6nt,Whethernsec6remarksnt=@Whethernsec6remarksnt,Whetherldenotifynt=@Whetherldenotifynt,Whetherldenotifyremarksnt=@Whetherldenotifyremarksnt,Whetherapquestnt=@Whetherapquestnt,Whetherapquestremarksnt=@Whetherapquestremarksnt,Whetherlitigationnt=@Whetherlitigationnt,Whetherlitigationremarksnt=@Whetherlitigationremarksnt,NTEHObs=@NTEHObs,UserId=@UserId,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@Whethernsec4nt", model.NOCApplicationRemarks.Whethernsec4nt);
                    Cmd.Parameters.AddWithValue("@Whethernsec4remarksnt", model.NOCApplicationRemarks.Whethernsec4remarksnt);
                    Cmd.Parameters.AddWithValue("@Whethernsec6nt", model.NOCApplicationRemarks.Whethernsec6nt);
                    Cmd.Parameters.AddWithValue("@Whethernsec6remarksnt", model.NOCApplicationRemarks.Whethernsec6remarksnt);
                    Cmd.Parameters.AddWithValue("@Whetherldenotifynt", model.NOCApplicationRemarks.Whetherldenotifynt);
                    Cmd.Parameters.AddWithValue("@Whetherldenotifyremarksnt", model.NOCApplicationRemarks.Whetherldenotifyremarksnt);
                    Cmd.Parameters.AddWithValue("@Whetherapquestnt", model.NOCApplicationRemarks.Whetherapquestnt);
                    Cmd.Parameters.AddWithValue("@Whetherapquestremarksnt", model.NOCApplicationRemarks.Whetherapquestremarksnt);
                    Cmd.Parameters.AddWithValue("@Whetherlitigationnt", model.NOCApplicationRemarks.Whetherlitigationnt);
                    Cmd.Parameters.AddWithValue("@Whetherlitigationremarksnt", model.NOCApplicationRemarks.Whetherlitigationremarksnt);
                    Cmd.Parameters.AddWithValue("@NTEHObs", model.ApplicationDetails.ApplicationRemarks);
                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, model.WhetherRecommend + " by Naib Tehsildar : " + model.ApplicationDetails.ApplicationRemarks, (int)ApplicationSource.Window, null));
                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.VERSENT).ToString())
                {
                    model.IsAlreadyVerified = Utility.SelectColumnsValue("dbo.VerifierApplicationDetails", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                    if (string.IsNullOrEmpty(model.IsAlreadyVerified))
                    {
                        Utility.SaveOldStatusBeforeVerification(model.ApplicationDetails.ApplicationNo, CustomText.TRUE.ToString());
                        string Uid = Utility.SelectColumnsValue("dbo.UserMaster", "Uid", "UserId", Sessions.getEmployeeUser().UserId.ToString())[0];

                        Qry = "update dbo.VerifierApplicationDetails set WhetherLastVerification=@WhetherLastVerification where ApplicationNo=@ApplicationNo and exists (select ApplicationNo from dbo.VerifierApplicationDetails where ApplicationNo=@ApplicationNo)";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@WhetherLastVerification", CustomText.FALSE.ToString());
                        cmdList.Add(Cmd);

                        Qry = "insert into dbo.VerifierApplicationDetails (ApplicationNo,SentBy,SentTo,SentDate,WhetherVerified,WhetherLastVerification) values(@ApplicationNo,@SentBy,@SentTo,now(),@WhetherVerified,@WhetherLastVerification)";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@SentBy", Uid);
                        Cmd.Parameters.AddWithValue("@SentTo", model.VerifierCode);
                        Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.FALSE.ToString());
                        Cmd.Parameters.AddWithValue("@WhetherLastVerification", CustomText.TRUE.ToString());
                        cmdList.Add(Cmd);
                    }
                    else
                    {
                        return RedirectToAction("UnauthorizedRequest", "Error");
                    }

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG013, null, (int)ApplicationSource.Window, null));

                    //send sms to applicant and insert record in table
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS004, smsDic));

                    //send email to applicant and insert record in table
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS004).ToString());
                    EmailDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREJ).ToString())
                {
                    //BypassPermission = true;
                    string ReasonOfRejection = model.ApplicationDetails.ApplicationRemarks;
                    if (model.ApplicationDetails.RejectionReasonCode != ((int)RejectionReason.Other).ToString()) { ReasonOfRejection = Utility.SelectColumnsValue("dbo.reasonmaster", "reasondetail", "reasoncode", model.ApplicationDetails.RejectionReasonCode)[0]; }

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG003, ReasonOfRejection, (int)ApplicationSource.Window, null));

                    //send sms to applicant and insert record in table
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    smsDic.Add("ParamRemarks", ReasonOfRejection);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS005, smsDic));

                    //send email to applicant and insert record in table
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS005).ToString());
                    EmailDic.Add("ParamRemarks", ReasonOfRejection);
                    EmailDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                }
                else
                {
                    return RedirectToAction("BadRequest", "Error");
                }


                //if (!BypassPermission)
                //{
                //    if (!Utility.CheckCurrentStatusBeforeUpdate(model.ApplicationDetails.ApplicationNo, Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId), (int)CountList.Type001))
                //    {
                //        ViewData["message"] = "Application is not pending at this level anymore!";
                //        return View("message");
                //    }
                //}

                Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);                
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationDetails.ApplicationNo, Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId), (int)CountList.Type001, DB.LS.ToString()));
                Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                data.SaveData(cmdList);

                if (model.ServiceCode.Equals(((int)ServiceList.NOC).ToString()))
                {
                    string newStatus = string.Empty;
                    if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.OBSPEND).ToString())
                    {
                        newStatus = ((int)Status.TEHSPEN).ToString();
                    }
                    else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.OBSPEN2).ToString())
                    {
                        newStatus = ((int)Status.OBSPEND).ToString();
                    }
                    else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREC).ToString())
                    {
                        newStatus = ((int)Status.OBSPEN2).ToString();
                    }
                    PreserveModelState(Constant._ActionMessage, "Selected application has been processed successfully.", false, true);
                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { newStatus });
                    return RedirectToAction("PendingDecsionSummary", new { q = QueryString });
                }
                else
                {
                    PreserveModelState(Constant._ActionMessage, "Selected application has been processed successfully.", false, true);

                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.TEHSPEN).ToString() });
                    return RedirectToAction("PendingDecsionSummary", new { q = QueryString });

                    //if (model.ServiceCode.Equals(((int)ServiceList.GrantOfPassengerLift).ToString()) || model.ServiceCode.Equals(((int)ServiceList.RenewalOfPassengerLift).ToString()))
                    //{
                    //    if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.INSPEND).ToString())
                    //    {
                    //        PreserveModelState(Constant._ActionMessage, "Application has been processed successfully! Go To Service Specific - Grant of Lift License - Pending For Inspection to complete inspection.", false, true);
                    //    }
                    //    return RedirectToAction("PendingDecsionSummary", new { q = QueryString });
                    //}
                    //else
                    //{
                    //    return RedirectToAction("PendingDecsionSummary", new { q = QueryString });
                    //}
                }
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            if (model.ServiceCode == ((int)ServiceList.Marriage).ToString() || model.ServiceCode == ((int)ServiceList.Solemnization).ToString())
            {
                return View("PendingMarriageDecisionDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
            }
            else
            {
                return View("PendingApplicationDecisionDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
            } 
        }

        [Authorize(Roles = "103,104,114,123,124")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingRecoveryDecisionDetails(DecisionModels model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string QueryString = string.Empty, Qry = string.Empty;
                NpgsqlCommand updCmd = null;
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                ArrayList Values = new ArrayList();

                int SigningTypeId = Convert.ToInt32(Utility.SelectColumnsValue("dbo.usermaster", "signingtypeid", "UserId", Sessions.getEmployeeUser().UserId)[0]);
                if (SigningTypeId != (int)ValueId.SignDigital)
                {
                    PreserveModelState(Constant._ActionMessage, "You need to be digitally signed in to take action on this application.", false, true);
                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                    return RedirectToAction("PendingApplicationDecisionDetails", new { q = QueryString });
                }                
                if (model.RecoveryNoticeDetails.WhetherDisposedOff == CustomText.N.ToString())
                {
                    Qry = "select DId from dgen.recoverydefaulterdetails where ApplicationNo=@ApplicationNo";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    DataTable dta = data.GetDataTable(Cmd);
                    for (int i = 0; i < dta.Rows.Count; i++)
                    {
                        if (frm["D" + dta.Rows[i]["DId"].ToString()] != null)
                        {
                            Values.Add(frm["D" + dta.Rows[i]["DId"].ToString()]);
                        }
                        if (Values == null)
                        {
                            ViewBag.DisplayMessage = "Select atleast one defaulter!";
                            return View(model);
                        }
                    }
                }
                if (model.RecoveryNoticeDetails.WhetherDisposedOff == CustomText.Y.ToString() || model.RecoveryNoticeDetails.WhetherProceedingDetails.ToUpper() == CustomText.TRUE.ToString())
                {
                    model.RecoveryNoticeDetails.WhetherGenerated = CustomText.False.ToString();
                    updCmd = new NpgsqlCommand("insert into dgen.recoverynoticedetails(ApplicationNo,ServiceCode,DisposalRemarks,Proceedingdetails,ProceedingDate,Whethergenerated,userid,ipaddress,lastactiondate) values (@ApplicationNo,@ServiceCode,@DisposalRemarks,@Proceedingdetails,@ProceedingDate,@Whethergenerated,@userid,@ipaddress,now()) ");
                    updCmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    updCmd.Parameters.AddWithValue("@DisposalRemarks", model.RecoveryNoticeDetails.DisposalRemarks);
                    updCmd.Parameters.AddWithValue("@Proceedingdetails", model.RecoveryNoticeDetails.ProceedingDetails);
                    updCmd.Parameters.AddWithValue("@ProceedingDate", Utility.GetDateYYYYMMDD(model.RecoveryNoticeDetails.ProceedingDate, '/', "0/1/2"));
                    updCmd.Parameters.AddWithValue("@Whethergenerated", CustomText.False.ToString());
                    updCmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.Recovery);
                    updCmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    updCmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(updCmd);
                }
                else
                {
                    if (model.RecoveryNoticeDetails.WhetherWarrantRequired == CustomText.Y.ToString())
                    {
                        model.RecoveryNoticeDetails.TypeId = model.RecoveryNoticeDetails.WTypeId;
                        model.RecoveryNoticeDetails.RName = model.RecoveryNoticeDetails.WRName;
                        model.RecoveryNoticeDetails.ExpiryDate = model.RecoveryNoticeDetails.WExpiryDate;
                        model.RecoveryNoticeDetails.Remarks = model.RecoveryNoticeDetails.WRemarks;
                    }
                    model.RecoveryNoticeDetails.WhetherGenerated = CustomText.True.ToString();
                    for (int i = 0; i < Values.Count; i++)
                    {
                        updCmd = new NpgsqlCommand("insert into dgen.recoverynoticedetails(ApplicationNo,ServiceCode,DId,TypeId,Proceedingdetails,ProceedingDate,Whethergenerated,Generatedby,GenerateDate,RName,Servicecharge,IssueDate,ExpiryDate,PoliceStationId,Note,Remarks,Servedby,Propertydetails,userid,ipaddress,lastactiondate) values (@ApplicationNo,@ServiceCode,@DId,@TypeId,@Proceedingdetails,@ProceedingDate,@Whethergenerated,@Generatedby,now(),@RName,@Servicecharge,now(),@ExpiryDate,@PoliceStationId,@Note,@Remarks,@Servedby,@Propertydetails,@userid,@ipaddress,now()) ");
                        updCmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        updCmd.Parameters.AddWithValue("@Proceedingdetails", model.RecoveryNoticeDetails.ProceedingDetails);
                        updCmd.Parameters.AddWithValue("@ProceedingDate", Utility.GetDateYYYYMMDD(model.RecoveryNoticeDetails.ProceedingDate, '/', "0/1/2"));
                        updCmd.Parameters.AddWithValue("@Whethergenerated", model.RecoveryNoticeDetails.WhetherGenerated);
                        updCmd.Parameters.AddWithValue("@TypeId", model.RecoveryNoticeDetails.TypeId);
                        updCmd.Parameters.AddWithValue("@DId", Values[i]);
                        updCmd.Parameters.AddWithValue("@Generatedby", Sessions.getEmployeeUser().UserId);
                        updCmd.Parameters.AddWithValue("@RName", model.RecoveryNoticeDetails.RName);
                        updCmd.Parameters.AddWithValue("@Servicecharge", model.RecoveryNoticeDetails.Servicecharge);
                        updCmd.Parameters.AddWithValue("@ExpiryDate", Utility.GetDateYYYYMMDD(model.RecoveryNoticeDetails.ExpiryDate, '/', "0/1/2"));
                        updCmd.Parameters.AddWithValue("@PoliceStationId", model.RecoveryNoticeDetails.PoliceStationId);
                        updCmd.Parameters.AddWithValue("@Note", model.RecoveryNoticeDetails.Note);
                        updCmd.Parameters.AddWithValue("@Remarks", model.RecoveryNoticeDetails.Remarks);
                        updCmd.Parameters.AddWithValue("@Servedby", model.RecoveryNoticeDetails.Servedby);
                        updCmd.Parameters.AddWithValue("@Propertydetails", model.RecoveryNoticeDetails.Propertydetails);
                        updCmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.Recovery);
                        updCmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        updCmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(updCmd);
                    }
                }
                //QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                //return RedirectToAction("InitializeRecordSign", "Sign", new { q = QueryString });                             

                if (model.RecoveryNoticeDetails.WhetherDisposedOff == CustomText.Y.ToString())
                {
                    Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    data.SaveData(cmdList);
                    PreserveModelState(Constant._ActionMessage, "Selected application has been processed successfully.", false, true);
                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.TEHSPEN).ToString() });
                    return RedirectToAction("PendingDecsionSummary", new { q = QueryString });
                }
                if (model.RecoveryNoticeDetails.WhetherProceedingDetails.ToUpper() == CustomText.TRUE.ToString())
                {
                    data.SaveData(cmdList);
                    PreserveModelState(Constant._ActionMessage, "Selected application has been processed successfully.", false, true);
                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                    return RedirectToAction("PendingApplicationDecisionDetails", new { q = QueryString });
                }
                data.SaveData(cmdList);

                PreserveModelState(Constant._ActionMessage, "Notice/Warrants has been generated successfully.", false, true);
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                return RedirectToAction("PrintRecoveryNotice", "Common", new { q = QueryString });
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PendingRecoveryDecisionDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        [Authorize(Roles = "103,104")]
        public ActionResult PendingDecsionListNULM()
        {
            GetData data = new GetData();
            //string WhetherCondition = string.Empty;
            DecisionModels model = new DecisionModels();

            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition = " and AD.OfficeCode in (@ParamAuthorizationId)  and AD.AcceptedBy in (@AcceptedBy)"; }
            //else { WhetherCondition = "  and AD.OfficeCode=@OfficeCode and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.AcceptedBy in (@AcceptedBy)"; }

            string addScript = Utility.GetScriptForAuthorizationProcess();

            //string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD inner join drev.applicationdetailsincome ADI on ADI.applicationno=AD.applicationno left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where DM.deptcode=@ParamDeptCode and AD.ServiceCode=@ServiceCode " + WhetherCondition + " and AD.ApplicationStatusId=@ApplicationStatusId and pforcertificateid =@pforcertificateid order by AD.applicationdate";
            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD inner join drev.applicationdetailsincome ADI on ADI.applicationno=AD.applicationno left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where DM.deptcode=@ParamDeptCode and AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId and pforcertificateid =@pforcertificateid and AD.AcceptedBy in (@AcceptedBy) " + addScript + " order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.Income);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            cmd.Parameters.AddWithValue("@pforcertificateid", (int)ValueId.pForCertificateId);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [Authorize(Roles = "114")]
        [EncryptedActionParameter]
        public ActionResult PendingNOCDecsionSummary(int sid)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();

            //string WhetherCondition = string.Empty;
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition = " and AD.OfficeCode in (@ParamAuthorizationId)  and AD.AcceptedBy in (@AcceptedBy)"; }
            //else { WhetherCondition = " and AD.applicationdistrictCode in (@ParamDistrictCode) and AD.OfficeCode=@OfficeCode  and AD.AcceptedBy in (@AcceptedBy)"; }

            string addScript = " and AD.applicationdistrictCode in (@ParamDistrictCode)";
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { addScript += " and AD.OfficeCode in (@ParamAuthorizationId)"; }

            //string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationdistrictCode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@ApplicationSourceId then 1 end),0) as atCSC,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as atOnline from dbo.ApplicationDetails AD inner join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode " + WhetherCondition + " and AD.ServiceCode in (@ParamServiceCode) group by AD.applicationdistrictCode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationdistrictCode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@ApplicationSourceId then 1 end),0) as atCSC,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as atOnline from dbo.ApplicationDetails AD inner join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) and AD.AcceptedBy in (@AcceptedBy) " + addScript + " group by AD.applicationdistrictCode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@ApplicationSourceId", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            model.data = data.GetDataTable(cmd);
            model.StatusId = sid.ToString();

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "114")]
        [EncryptedActionParameter]
        public ActionResult PendingNOCDecsionList(int DistCode, int service, int status, int? SourceId)
        {
            //string value = string.Empty;
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();

            //if (SourceId != null) { value += " and ApplicationSourceId=@ApplicationSourceId"; }
            //string WhetherCondition = string.Empty;
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition = " and AD.OfficeCode in (@ParamAuthorizationId)  and AD.AcceptedBy in (@AcceptedBy)"; }
            //else { WhetherCondition = " and AD.applicationdistrictCode in (@ParamDistrictCode) and AD.OfficeCode=@OfficeCode  and AD.AcceptedBy in (@AcceptedBy)"; }

            string addScript = " and AD.applicationdistrictCode in (@ParamDistrictCode)";
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { addScript += " and AD.OfficeCode in (@ParamAuthorizationId)"; }
            if (SourceId != null) { addScript += " and AD.ApplicationSourceId=@ApplicationSourceId"; }

            //string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where DM.deptcode=@ParamDeptCode and AD.applicationdistrictCode=@applicationdistrictCode and AD.ServiceCode=@ServiceCode " + WhetherCondition + " and AD.ApplicationStatusId=@ApplicationStatusId " + value + " order by AD.applicationdate";
            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where DM.deptcode=@ParamDeptCode and AD.applicationdistrictCode=@applicationdistrictCode and AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId and AD.AcceptedBy in (@AcceptedBy) " + addScript + " order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@applicationdistrictCode", DistCode);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", status);
            if (SourceId != null) { cmd.Parameters.AddWithValue("@ApplicationSourceId", SourceId); }
            cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }

        [Authorize(Roles = "103,104")]
        [EncryptedActionParameter]
        public ActionResult PendingForOtherStateVerification(int sid)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and VD.ApplicationNo is null then 1 end),0) as Before from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode left outer join (select distinct applicationno from (select applicationno from verifierapplicationdetails union select applicationno from applicationverificationletterdetails)a) VD on VD.ApplicationNo=AD.ApplicationNo where DM.deptcode=@ParamDeptCode and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.ServiceCode in (@OBC,@SCST,@ST) group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@OBC", (int)ServiceList.OBC);
            cmd.Parameters.AddWithValue("@SCST", (int)ServiceList.SCST);
            cmd.Parameters.AddWithValue("@ST", (int)ServiceList.ST);
            model.data = data.GetDataTable(cmd);

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }

        [EncryptedActionParameter]
        public ActionResult CertificateListForAction(int sid, int? service)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();

            //string addScript = string.Empty;
            //if (!string.IsNullOrEmpty(service.ToString()))  { addScript = " and AD.ServiceCode=@ServiceCode";  }
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000)
            //{
            //    addScript = addScript + " and AD.OfficeCode in (@ParamAuthorizationId)";
            //}
            //else
            //{
            //    if (Sessions.getEmployeeUser().Permission == ((int)Permission.DC).ToString())
            //    {
            //        addScript = addScript + " and AD.applicationdistrictcode in (@ParamDistrictCode)";
            //    }
            //    else if (Sessions.getEmployeeUser().Permission == ((int)Permission.P114).ToString())
            //    {
            //        addScript = addScript + " and AD.applicationdistrictcode in (@ParamDistrictCode) and AD.ServiceCode=@NOC";
            //    }
            //    else
            //    {
            //        addScript = addScript + " and AD.applicationsubdivcode in (@ParamSubDivCode)";
            //    }
            //}

            string addScript = Utility.GetScriptForAuthorizationProcess();
            if (Sessions.getEmployeeUser().Permission == ((int)Permission.DC).ToString() || Sessions.getEmployeeUser().Permission == ((int)Permission.P114).ToString())
            {
                addScript = " and AD.applicationdistrictcode in (@ParamDistrictCode)";
                if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { addScript += " and AD.OfficeCode in (@ParamAuthorizationId)"; }
            }
            if (!string.IsNullOrEmpty(service.ToString())) { addScript += " and AD.ServiceCode=@ServiceCode"; }

            string Qry = "SELECT AD.ApplicationNo,SM.ServiceName,AD.ApplicantName,case when AD.ApplicantGender='M' then 'Male' when AD.ApplicantGender='F' then 'Female' else AD.ApplicantGender end as ApplicantGender,AD.RegistrationId,AD.ApplicantFatherName,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,AD.ApplicationStatusId FROM dbo.ApplicationDetails AD inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join StatusMaster ST on ST.StatusId=AD.ApplicationStatusId where SM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) and AD.AcceptedBy in (@AcceptedBy) and AD.ApplicationStatusId=@StatusId " + addScript;
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@StatusId", sid);
            //Cmd.Parameters.AddWithValue("@NOC", (int)ServiceList.NOC);
            Cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            if (!string.IsNullOrEmpty(service.ToString())) { Cmd.Parameters.AddWithValue("@ServiceCode", service); }
            //Cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            model.data = data.GetDataTable(Cmd);

            ViewData[KeyName._Key01] = sid;
            return View(model);
        }

        [Authorize(Roles = "103,104")]
        [EncryptedActionParameter]
        public ActionResult PendingExistingDecsionSummary()
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            string Qry = " select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  then 1 end),0) as PendingCSC from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=1 and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.ServiceCode in (@ServiceCode) group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.SCOM002);
            cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.CDVolunteer);
            model.data = data.GetDataTable(cmd);

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "103,104")]
        [EncryptedActionParameter]
        public ActionResult PendingExistingDecsionList(int subDiv, int service, int status)
        {
            string value = string.Empty;
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            string Qry = " select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where DM.deptcode=@ParamDeptCode and AD.ServiceCode=@ServiceCode and AD.applicationsubdivcode=@SubDivCode and AD.ApplicationStatusId=@ApplicationStatusId  order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", status);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [Authorize(Roles = "103,104")]
        [EncryptedActionParameter]
        public ActionResult PendingExistingApplicationDecisionDetails(Int64 AppNo)
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }

            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();

            string Qry = "select ServiceCode,ApplicationStatusId from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ApplicationSubdivCode in (@ParamSubDivCode) and ServiceCode in (@ParamServiceCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            string[] GetValues = data.SelectColumns(Cmd);

            model.ApplicationDetails.ServiceCode = GetValues[0];
            model.ApplicationDetails.ApplicationStatusId = GetValues[1];

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.data1 = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data4 = Utility.GetApplicationAuditTrail(model.ApplicantDetails.ApplicationNo);

            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.CDVolunteer)
            {
                model.ApplicationDetailsCDV = Utility.GetCDVDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.WhetherVerificationLetterRequired = true;
            }

            model.ApplicationDetails.ApplicationStatusId = ((int)Status.ISSUCER).ToString();
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [Authorize(Roles = "103,104")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingExistingApplicationDecisionDetails(DecisionModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                NpgsqlCommand Cmd = null;
                string QueryString = string.Empty, Qry = string.Empty;
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                int SigningTypeId = Convert.ToInt32(Utility.SelectColumnsValue("dbo.usermaster", "signingtypeid", "UserId", Sessions.getEmployeeUser().UserId)[0]);
                if (SigningTypeId != (int)ValueId.SignDigital)
                {
                    ViewBag.DisplayMessage = "You need to be digitally signed in to take action on this application.";
                    PreserveModelState(Constant._ModelStateParent, null, true, false);
                    return View("PendingExistingApplicationDecisionDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
                }

                model.ServiceCode = Utility.SelectColumnsValue("ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0];

                if (Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId) == (int)Status.ISSUCER)
                {
                    Cmd = new NpgsqlCommand("update dgen.ApplicationDetailsCDV set EnrollmentNo=@ApplicationNo where ApplicationNo=@ApplicationNo and EnrollmentNo is null");
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    cmdList.Add(Cmd);
                }
                Qry = "update dbo.applicationdetails set applicationstatusid=@applicationstatusid,";
                if (Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId) == (int)Status.CSCEDT) { Qry += "ApplicationRemarks=@ApplicationRemarks,"; }
                Qry += "userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where applicationno=@applicationno";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@applicationstatusid", model.ApplicationDetails.ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "update web.applicationdetails set applicationstatusid=@applicationstatusid,";
                if (Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId) == (int)Status.CSCEDT) { Qry += "ApplicationRemarks=@ApplicationRemarks,"; }
                Qry += "userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where applicationno=@applicationno";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@applicationstatusid", model.ApplicationDetails.ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);


                cmdList.Add(Utility.InsertDepartmentAuditTrail(null, (int)ApplicationHistoryMessage.MSG019, model.ApplicationDetails.ApplicationRemarks, (int)ApplicationSource.Window, model.ApplicationDetails.ApplicationNo));

                data.SaveData(cmdList);

                PreserveModelState(Constant._ActionMessage, "Selected application has been process successfully.", false, true);
                return RedirectToAction("PendingExistingDecsionSummary", "Decision");
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PendingExistingApplicationDecisionDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
        }


        #region decision methods for Tirth Yatra Service
        [Authorize(Roles = "132")]
        [EncryptedActionParameter]
        public ActionResult PendingYatraAppDecsionSummary(int sid)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            string Qry = "select SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName,sum(case when ApplicationStatusId in (@TEHSPEN,@TEHSOBJ,@ISSUCER) then 1 else 0 end) as total,coalesce(sum(case when ApplicationStatusId=@TEHSPEN then 1 end),0) as PendingApproval,coalesce(sum(case when ApplicationStatusId not in (@TEHSPEN,@TEHSOBJ) then 1 end),0) as Approved,sum((case when ApplicationStatusId=@ISSUCER then 1 else 0 end) + (case when ApplicationStatusId=@ISSUCER and whetherappyingwithspouse=true then 1 else 0 end) + (case when ApplicationStatusId=@ISSUCER and optingforattendant=true then 1 else 0 end)) as totalrecMember from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid inner join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) and  ADTY.constituencyid in (select constituencyid from districttoconstituencymaster where districtcode=@ParamDistrictCode and whetheractive=true) group by SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName order by SMVD.ValueName,constituencyName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@TEHSPEN", sid);
            cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            model.data = data.GetDataTable(cmd);
            model.StatusId = sid.ToString();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "132")]
        [EncryptedActionParameter]
        public ActionResult PendingYatraAppDecsionList(int RouteId, int ConstituencyId, int StatusId)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();

            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName,to_Char(AD.applicationdate,'DD/MM/YYY')as DateofApplication,sum(1 + (case when whetherappyingwithspouse=true then 1 else 0 end) + (case when optingforattendant=true then 1 else 0 end)) as totalrecMember from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo  inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid inner join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId and ADTY.constituencyid=@ConstituencyId and ADTY.RouteId=@RouteId group by AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,SL.StatusName,AD.ApplicationStatusId,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.TirthYatraYojna);
            cmd.Parameters.AddWithValue("@RouteId", RouteId);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", StatusId);
            cmd.Parameters.AddWithValue("@ConstituencyId", ConstituencyId);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [Authorize(Roles = "132")]
        [EncryptedActionParameter]
        public ActionResult PendingYatraAppDecisionDetails(Int64 AppNo)
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }

            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();
            string[] Values = Utility.GetServiceCode(Convert.ToInt64(model.ApplicationDetails.ApplicationNo));

            string Qry = "select ServiceCode,ApplicationStatusId from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ServiceCode in (@ParamServiceCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //Cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            string[] GetValues = data.SelectColumns(Cmd);
            model.ApplicationDetails.ServiceCode = GetValues[0];
            model.ApplicationDetails.ApplicationStatusId = GetValues[1];


            //check whether document verified or not??
            Qry = "select documentstatusid from web.registrationmaster RM left outer join dbo.applicationdetails AD on RM.RegistrationId=AD.RegistrationId where AD.ApplicationNo=@ApplicationNo and RM.DocumentId in (@AadhaarCard,@VoterID)";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@AadhaarCard", ((int)DocumentId.AadhaarCard).ToString());
            Cmd.Parameters.AddWithValue("@VoterID", ((int)DocumentId.VoterID).ToString());
            model.DocumentStatusId = data.SelectColumns(Cmd)[0];

            string flag = Utility.SelectColumnsValue("dbo.VerifierVerificationReport", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
            if (string.IsNullOrEmpty(flag)) { model.WhetherVerification = false; } else { model.WhetherVerification = true; }

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data1 = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data3 = Utility.GetObjectionDetails(model.ApplicantDetails.ApplicationNo.ToString());
            model.data4 = Utility.GetApplicationAuditTrail(model.ApplicantDetails.ApplicationNo);
            model.data6 = Utility.GetSingleDocVerificationStatus(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());

            model.IsAlreadyVerified = Utility.SelectColumnsValue("dbo.VerifierApplicationDetails", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
            model.WhetherVerificationLetterRequired = false;

            Qry = "select AD.ApplicationNo from applicationdetails AD where applicationstatusid=@applicationstatusid and registrationid=@registrationid";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@applicationstatusid", (int)Status.ISSUCER);
            Cmd.Parameters.AddWithValue("@registrationid", model.ApplicantDetails.RegistrationId);
            model.data5 = data.GetDataTable(Cmd);


            model.WhetherDocVerified = true;
            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.TirthYatraYojna)
            {
                model.ApplicationDetailsTirthYatraYojana = Utility.GetTirthYatraYojnaDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            }
            else
            {
                return RedirectToAction("UnauthorizedRequest", "Error");
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [Authorize(Roles = "132")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingYatraAppDecisionDetails(DecisionModels model, FormCollection frm)
        {
            model.ServiceCode = Utility.SelectColumnsValue("ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0];
            model.DeptCode = Utility.GetDeptCode(model.ServiceCode);

            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                bool StopDataCheckRequired = false;
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string QueryString = string.Empty, Qry = string.Empty, DisplayMessage = string.Empty;

                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.ISSUCER).ToString())
                {
                    Dictionary<string, string> ValidateData = new Dictionary<string, string>();
                    ValidateData.Add("ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    string[] ValidationCheck = Utility.ApplicationValidation(ValidateData, (int)ValidationCheckLevels.DecisionProcessGeneralPost, StopDataCheckRequired);
                    if (ValidationCheck[0] == ((int)CountList.Type001).ToString())
                    {
                        PreserveModelState(Constant._ActionMessage, ValidationCheck[1], false, true);
                        QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                        return RedirectToAction("PendingYatraAppDecisionDetails", "Decision", new { q = QueryString });
                    }
                    else if (ValidationCheck[0] == ((int)CountList.Type002).ToString())
                    {
                        ViewData["message"] = ValidationCheck[1];
                        return View("message");
                    }

                    Qry = "Update dgen.applicationdetailstirthyatrayojana set RecommendBy=@RecommendBy,RecommendIpAddress=@RecommendIpAddress,RecommendDate=now() where ApplicationNo=@ApplicationNo ";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@RecommendBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@RecommendIpAddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG002, null, (int)ApplicationSource.Window, null));
                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREJ).ToString())
                {
                    string ReasonOfRejection = model.ApplicationDetails.ApplicationRemarks;
                    if (model.ApplicationDetails.RejectionReasonCode != ((int)RejectionReason.Other).ToString()) { ReasonOfRejection = Utility.SelectColumnsValue("dbo.reasonmaster", "reasondetail", "reasoncode", model.ApplicationDetails.RejectionReasonCode)[0]; }

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG003, ReasonOfRejection, (int)ApplicationSource.Window, null));

                    //send sms to applicant and insert record in table
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    smsDic.Add("ParamRemarks", ReasonOfRejection);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS005, smsDic));
                }
                else
                {
                    return RedirectToAction("BadRequest", "Error");
                }

                Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() ";
                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.ISSUCER).ToString()) { Qry += ",Approveddate=now() "; }
                Qry += " where ApplicationNo=@ApplicationNo ";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                data.SaveData(cmdList);

                PreserveModelState(Constant._ActionMessage, "The application [" + model.ApplicationDetails.ApplicationNo + "] has been processed successfully.", false, true);
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.TEHSPEN).ToString() });
                return RedirectToAction("PendingYatraAppDecsionSummary", new { q = QueryString });
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PendingYatraAppDecisionDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
        }
        #endregion

        #endregion

        #region decision methods for Higher Education
        [Authorize(Roles = "116")]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult HGPendingDecsionSummary(int sid)
        {
            GetData data = new GetData();
            string Qry = string.Empty;
            DecisionModels model = new DecisionModels();
            Qry = @"select SC.ServiceName,SC.ServiceCode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId then 1 end),0) as PendingApp from dbo.ApplicationDetails AD inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNO=AD.ApplicationNo left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode  where AD.ServiceCode in (@ParamServiceCode)  and LoanBankId=@LoanBankId and whetherdocumentshown=@whetherdocumentshown group by SC.ServiceName,SC.ServiceCode order by SC.ServiceName ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@whetherdocumentshown", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@LoanBankId", Sessions.getEmployeeUser().AuthorizationId);
            model.data = data.GetDataTable(cmd);

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "116")]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult HGPendingDecsionList(int service, int status)
        {
            string value = string.Empty;
            GetData data = new GetData();
            string Qry = string.Empty;
            DecisionModels model = new DecisionModels();
            Qry = @"select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNO=AD.ApplicationNo left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode  left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where AD.ServiceCode=@ServiceCode  and AD.ApplicationStatusId=@ApplicationStatusId and LoanBankId=@LoanBankId and whetherdocumentshown=@whetherdocumentshown order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", status);
            cmd.Parameters.AddWithValue("@whetherdocumentshown", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@LoanBankId", Sessions.getEmployeeUser().AuthorizationId);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [Authorize(Roles = "116")]
        [EncryptedActionParameter]
        public ActionResult HGPendingApplicationDecisionDetails(Int64 AppNo)
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }

            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();

            string Qry = "select ServiceCode,ApplicationStatusId from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ServiceCode in (@ParamServiceCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            string[] GetValues = data.SelectColumns(Cmd);

            model.ApplicationDetails.ServiceCode = GetValues[0];
            model.ApplicationDetails.ApplicationStatusId = GetValues[1];
            if (model.ApplicationDetails.ApplicationStatusId != ((int)Status.DEALOLR).ToString())
            {
                PreserveModelState(Constant._ActionMessage, "Application Not Found, Kindly Check Your Application No.", false, true);
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.ApplicationDetails.ApplicationStatusId });
                return RedirectToAction("SearchAppForAction", new { q = QueryString });
            }

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data1 = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data4 = Utility.GetApplicationAuditTrail(model.ApplicantDetails.ApplicationNo);
            model.data5 = Utility.GetMobileSahayakDetailsData(model.ApplicationDetails.ApplicationNo);
            model.WhetherVerificationLetterRequired = false;

            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.HigherEducationSKGS)
            {
                model.HeSkillDevelopmentScheme = Utility.GetHeSkillDevelopmentSchemeDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [Authorize(Roles = "116")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult HGPendingApplicationDecisionDetails(DecisionModels model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                NpgsqlCommand Cmd = null;
                string QueryString = string.Empty, Qry = string.Empty;
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                if (model.ApplicationDetails.ApplicationStatusId != ((int)Status.TEHSREC).ToString() && model.ApplicationDetails.ApplicationStatusId != ((int)Status.TEHSREJ).ToString())
                {
                    return RedirectToAction("BadRequest", "Error");
                }
                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREC).ToString())
                {
                    string Message = Utility.CheckBeforeFinalSubmit(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    if (!string.IsNullOrEmpty(Message))
                    {
                        PreserveModelState(Constant._ActionMessage, Message, false, true);
                        QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                        return RedirectToAction("HGPendingApplicationDecisionDetails", "Decision", new { q = QueryString });
                    }
                }

                model.ServiceCode = Utility.SelectColumnsValue("ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0];
                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREC).ToString())
                {
                    if (model.ServiceCode.Equals(((int)ServiceList.HigherEducationSKGS).ToString()))
                    {

                        Qry = "select coalesce(sum(LoanAmount),0) as RequiredLoan from dgen.hefinancedetails where applicationno=@applicationno Group by applicationno";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationDetails.ApplicationNo);
                        string RequiredLoan = data.SelectColumns(Cmd)[0];
                        if (Convert.ToInt64(model.ApplicationDetails.ApproveLoanAmount) > Convert.ToInt64(RequiredLoan))
                        {
                            PreserveModelState(Constant._ActionMessage, "Sanctioned Amount is Not Allowed More Than Required Loan Amount", false, true);
                            QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                            return RedirectToAction("HGPendingApplicationDecisionDetails", "Decision", new { q = QueryString });
                        }

                        Qry = "update dgen.heskilldevelopmentscheme set ApproveLoanAmount=@ApproveLoanAmount where applicationno=@applicationno";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@ApproveLoanAmount", model.ApplicationDetails.ApproveLoanAmount);
                        cmdList.Add(Cmd);

                        Qry = "update applicationdetails set applicationstatusid=@applicationstatusid,ApprovedDate=@ApprovedDate,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where applicationno=@applicationno";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@applicationstatusid", ((int)Status.TEHSREC).ToString());
                        Cmd.Parameters.AddWithValue("@ApprovedDate", Utility.GetDateYYYYMMDD(model.ApplicationDetails.ApproveDate, '/', "0/1/2"));
                        Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                        Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        Qry = "update applicationdetails set applicationstatusid=@applicationstatusid,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where applicationno=@applicationno";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@applicationstatusid", ((int)Status.TEHSREC).ToString());
                        Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                        Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        data.SaveData(cmdList);

                        ViewBag.DisplayMessage = "Selected application has been process successfully.";
                        QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { (int)Status.DEALOLR });
                        return RedirectToAction("HGPendingDecsionSummary", "Decision", new { q = QueryString });
                    }

                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                    return RedirectToAction("HGPendingApplicationDecisionDetails", "Decision", new { q = QueryString });
                }

                Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREJ).ToString())
                {
                    string ReasonOfRejection = model.ApplicationDetails.ApplicationRemarks;
                    if (model.ApplicationDetails.RejectionReasonCode != ((int)RejectionReason.Other).ToString()) { ReasonOfRejection = Utility.SelectColumnsValue("dbo.reasonmaster", "reasondetail", "reasoncode", model.ApplicationDetails.RejectionReasonCode)[0]; }
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG003, ReasonOfRejection, (int)ApplicationSource.Window, null));

                    //send sms to applicant and insert record in table
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    smsDic.Add("ParamRemarks", ReasonOfRejection);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS005, smsDic));

                    //send email to applicant and insert record in table
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS005).ToString());
                    EmailDic.Add("ParamRemarks", ReasonOfRejection);
                    EmailDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                }
                data.SaveData(cmdList);

                PreserveModelState(Constant._ActionMessage, "Selected application has been process successfully.", false, true);
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.TEHSPEN).ToString() });
                return RedirectToAction("HGPendingDecsionSummary", new { q = QueryString });
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("HGPendingApplicationDecisionDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
        }

        [Authorize(Roles = "116")]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult HGSanctionDecsionSummary(int sid)
        {
            GetData data = new GetData();
            string Qry = string.Empty;
            DecisionModels model = new DecisionModels();

            Qry = @"select SC.ServiceName,SC.ServiceCode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId then 1 end),0) as PendingApp from dbo.ApplicationDetails AD inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNO=AD.ApplicationNo LEFT outer join dgen.hedisbursaldetails HDB on HDB.ApplicationNO=AD.ApplicationNo left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode  where AD.ServiceCode in (@ParamServiceCode)  and LoanBankId=@LoanBankId and whetherdocumentshown=@whetherdocumentshown and  HSDS.installmentcount<HSDS.CoursePeriod and  case when lastdisbursaldate is null then date('2015-10-05 00:00:00') + interval '1 year' else date(lastdisbursaldate) + interval '1 year' end  < now() group by SC.ServiceName,SC.ServiceCode order by SC.ServiceName ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@whetherdocumentshown", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@LoanBankId", Sessions.getEmployeeUser().AuthorizationId);
            model.data = data.GetDataTable(cmd);

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "116")]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult HGSanctionDecsionList(int service, int status)
        {
            string value = string.Empty;
            GetData data = new GetData();
            string Qry = string.Empty;
            DecisionModels model = new DecisionModels();

            Qry = @"select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,to_char(ApplicationDate,'DD/MM/YYYY') as ApplicationDate,coalesce(sum(HFD.loanAmount),0) as LoanRequired,ApplicationStatusId,StatusName,to_char(ApprovedDate,'DD/MM/YYYY') as ApprovedDate,ApproveLoanAmount from dbo.ApplicationDetails AD inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNO=AD.ApplicationNo inner join dgen.hefinancedetails HFD on HFD.ApplicationNo=HSDS.ApplicationNo  LEFT outer join dgen.hedisbursaldetails HDB on HDB.ApplicationNO=AD.ApplicationNo left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode  left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where AD.ServiceCode=@ServiceCode  and AD.ApplicationStatusId=@ApplicationStatusId and LoanBankId=@LoanBankId and whetherdocumentshown=@whetherdocumentshown and  HSDS.installmentcount<HSDS.CoursePeriod and  case when lastdisbursaldate is null then date('2015-10-05 00:00:00') + interval '1 year' else date(lastdisbursaldate) + interval '1 year' end  < now() group by AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,ApplicationDate,ApplicationStatusId,StatusName,ApprovedDate,ApproveLoanAmount order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", status);
            cmd.Parameters.AddWithValue("@whetherdocumentshown", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@LoanBankId", Sessions.getEmployeeUser().AuthorizationId);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [Authorize(Roles = "116")]
        [EncryptedActionParameter]
        public ActionResult HGSanctionApplicationDecisionDetails(Int64 AppNo)
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }

            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();

            string Qry = "select ServiceCode,ApplicationStatusId from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ServiceCode in (@ParamServiceCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            string[] GetValues = data.SelectColumns(Cmd);

            model.ApplicationDetails.ServiceCode = GetValues[0];
            model.ApplicationDetails.ApplicationStatusId = GetValues[1];
            if (model.ApplicationDetails.ApplicationStatusId != ((int)Status.TEHSREC).ToString())
            {
                PreserveModelState(Constant._ActionMessage, "Application Not Found, Kindly Check Your Application No.", false, true);
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.ApplicationDetails.ApplicationStatusId });
                return RedirectToAction("SearchAppForAction", new { q = QueryString });
            }

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data1 = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data4 = Utility.GetApplicationAuditTrail(model.ApplicantDetails.ApplicationNo);
            model.WhetherVerificationLetterRequired = false;

            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.HigherEducationSKGS)
            {
                model.HeSkillDevelopmentScheme = Utility.GetHeSkillDevelopmentSchemeDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }

            Qry = "select count(HDD.ApplicationNo) as CouseCount,Case when HDD.academicsession is null then (date_part('Year',ApprovedDate) ||'-'|| date_part('Year',ApprovedDate) + 1) else (HDD.AcademicSession + 1 ||'-'||HDD.AcademicSession + 2) end as  AcademicSessionType,Case when HDD.academicsession is null then date_part('Year',ApprovedDate) else HDD.academicsession + 1 end as academicsession from ApplicationDetails AD Left Outer Join dgen.hedisbursaldetails HDD on HDD.ApplicationNo=AD.Applicationno where AD.applicationno=@ApplicationNo group by academicsession,ApprovedDate,disbursalid order by disbursalid desc";
            Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            DataTable dt = data.GetDataTable(Cmd);
            if (dt != null && dt.Rows.Count > 0)
            {
                if (dt.Rows.Count == (int)CountList.Type001)
                {
                    if (dt.Rows[0]["CouseCount"].ToString() == ((int)CountList.Type000).ToString()) { model.HeSkillDevelopmentScheme.CourseYear = "1st Year"; }
                    else { model.HeSkillDevelopmentScheme.CourseYear = "2nd Year"; }
                }
                else if (dt.Rows.Count == (int)CountList.Type002)
                {
                    model.HeSkillDevelopmentScheme.CourseYear = "3rd Year";
                }
                else
                {
                    model.HeSkillDevelopmentScheme.CourseYear = (dt.Rows.Count + 1).ToString() + "th Year";
                }
                model.HeSkillDevelopmentScheme.AcademicSessionType = dt.Rows[0]["AcademicSessionType"].ToString();
                model.HeSkillDevelopmentScheme.AcademicSession = dt.Rows[0]["academicsession"].ToString();
            }

            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [Authorize(Roles = "116")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult HGSanctionApplicationDecisionDetails(DecisionModels model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                NpgsqlCommand Cmd = null;
                string QueryString = string.Empty, Qry = string.Empty;
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                if (model.ApplicationDetails.ApplicationStatusId != ((int)Status.TEHSREC).ToString())
                {
                    return RedirectToAction("BadRequest", "Error");
                }

                bool result = Utility.CheckAFGDetails(Convert.ToInt64(model.ApplicationDetails.ApplicationNo), ((int)CountList.Type001).ToString(), model.HeSkillDevelopmentScheme.DisbursalAmount);
                if (result == false)
                {
                    ViewData["message"] = "Disbursed Amount Not Greater that Loan Sanction Amount!!";
                    return View("message");
                }
                model.ServiceCode = Utility.SelectColumnsValue("ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0];
                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREC).ToString())
                {
                    if (model.ServiceCode.Equals(((int)ServiceList.HigherEducationSKGS).ToString()))
                    {
                        Qry = "insert into dgen.hedisbursaldetails (applicationno,disbursaldate,disbursalamount,paymentafgdate,afgamount,TrustAccNo,MICRCode,BankCode,AcademicSession,userid,ipaddress,lastactiondate) values  (@applicationno,@disbursaldate,@disbursalamount,@paymentafgdate,@afgamount,@TrustAccNo,@MICRCode,@BankCode,@AcademicSession,@userid,@ipaddress,now());";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@disbursaldate", Utility.GetDateYYYYMMDD(model.HeSkillDevelopmentScheme.DisbursalDate, '/', "0/1/2"));
                        Cmd.Parameters.AddWithValue("@disbursalamount", model.HeSkillDevelopmentScheme.DisbursalAmount);
                        Cmd.Parameters.AddWithValue("@paymentafgdate", Utility.GetDateYYYYMMDD(model.HeSkillDevelopmentScheme.AFGDate, '/', "0/1/2"));
                        Cmd.Parameters.AddWithValue("@afgamount", model.HeSkillDevelopmentScheme.AFGAmount);
                        Cmd.Parameters.AddWithValue("@TrustAccNo", model.HeSkillDevelopmentScheme.TrustAccNo);
                        Cmd.Parameters.AddWithValue("@MICRCode", model.HeSkillDevelopmentScheme.MICRCode);
                        Cmd.Parameters.AddWithValue("@BankCode", model.HeSkillDevelopmentScheme.BankCode);
                        Cmd.Parameters.AddWithValue("@AcademicSession", model.HeSkillDevelopmentScheme.AcademicSession);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        string installmentcount = Utility.SelectColumnsValue("dgen.heskilldevelopmentscheme", "installmentcount", "applicationno", model.ApplicationDetails.ApplicationNo)[0];
                        Qry = "update dgen.heskilldevelopmentscheme set installmentcount=@installmentcount,lastdisbursaldate=@lastdisbursaldate, userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where applicationno=@applicationno";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@installmentcount", Convert.ToInt32(installmentcount) + 1);
                        Cmd.Parameters.AddWithValue("@lastdisbursaldate", Utility.GetDateYYYYMMDD(model.HeSkillDevelopmentScheme.DisbursalDate, '/', "0/1/2"));
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        data.SaveData(cmdList);

                        PreserveModelState(Constant._ActionMessage, "Selected application has been process successfully", false, true);
                        QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { (int)Status.TEHSREC });
                        return RedirectToAction("HGSanctionDecsionSummary", "Decision", new { q = QueryString });
                    }
                }
            }
            return View(model);
        }

        [Authorize(Roles = "116")]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult HGPendingDocumentSeenList()
        {
            string value = string.Empty;
            GetData data = new GetData();
            string Qry = string.Empty;
            DecisionModels model = new DecisionModels();
            Qry = @"select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNO=AD.ApplicationNo left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode  left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where AD.ServiceCode=@ServiceCode  and AD.ApplicationStatusId=@ApplicationStatusId and LoanBankId=@LoanBankId and whetherdocumentshown=@whetherdocumentshown order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.HigherEducationSKGS);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@whetherdocumentshown", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@LoanBankId", Sessions.getEmployeeUser().AuthorizationId);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [Authorize(Roles = "116")]
        [EncryptedActionParameter]
        public ActionResult HGPendingAppDocumentSeenDetails(Int64 AppNo)
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }

            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();

            string Qry = "select ServiceCode,ApplicationStatusId from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ServiceCode in (@ParamServiceCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            string[] GetValues = data.SelectColumns(Cmd);

            model.ApplicationDetails.ServiceCode = GetValues[0];
            model.ApplicationDetails.ApplicationStatusId = GetValues[1];
            if (model.ApplicationDetails.ApplicationStatusId != ((int)Status.DEALOLR).ToString())
            {
                PreserveModelState(Constant._ActionMessage, "Application Not Found, Kindly Check Your Application No.", false, true);
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.ApplicationDetails.ApplicationStatusId });
                return RedirectToAction("SearchAppForAction", new { q = QueryString });
            }

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data1 = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data4 = Utility.GetApplicationAuditTrail(model.ApplicantDetails.ApplicationNo);
            model.WhetherVerificationLetterRequired = false;

            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.HigherEducationSKGS)
            {
                model.HeSkillDevelopmentScheme = Utility.GetHeSkillDevelopmentSchemeDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [Authorize(Roles = "116")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult HGPendingAppDocumentSeenDetails(DecisionModels model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                NpgsqlCommand Cmd = null;
                string QueryString = string.Empty, Qry = string.Empty;
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                model.ServiceCode = Utility.SelectColumnsValue("ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0];

                Qry = "update dgen.HeSkillDevelopmentScheme set whetherdocumentshown=@whetherdocumentshown,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@whetherdocumentshown", CustomText.True.ToString());
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                // entry in trail
                cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo.ToString(), (int)ApplicationHistoryMessage.MSG032, null, (int)ApplicationSource.Window, null));

                data.SaveData(cmdList);
                PreserveModelState(Constant._ActionMessage, "Selected application has been process successfully.", false, true);
                return RedirectToAction("HGPendingDocumentSeenList", "Decision");
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("HGPendingAppDocumentSeenDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
        }

        [Authorize(Roles = "116,118")]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult HGCancelApplication()
        {
            DecisionModels model = new DecisionModels();
            return View(model);
        }
        [Authorize(Roles = "116,118")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult HGCancelApplication(DecisionModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = "select HSDS.ApplicationNo,ApplicantName,ApplicantFatherName,ApplicationStatusId from dgen.heskilldevelopmentscheme HSDS inner join ApplicationDetails AD on AD.ApplicationNo=HSDS.ApplicationNo where HSDS.ApplicationNo=@ApplicationNo and ApplicationStatusId !=@ApplicationStatusId ";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.CANCEL);
                model.data = data.GetDataTable(Cmd);
                if (model.data != null)
                {
                    if (model.data.Rows.Count > 0)
                    {
                        model.StatusId = model.data.Rows[0]["ApplicationStatusId"].ToString();
                        PreserveModelState(Constant._ModelStateParent, model, false, true);
                        return View("HGCancelApplicationPost", model);
                    }

                }
            }
            return View(model);
        }
        [Authorize(Roles = "116,118")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult HGCancelApplicationPost(DecisionModels model)
        {
            if (model.StatusId == ((int)Status.TEHSREC).ToString())
            {
                if (!model.WhetherVerification)
                {
                    ViewBag.Message = "Please verify thay you have received payment and found correct.";
                    PreserveModelState(Constant._ModelStateParent, null, true, false);
                    return View("HGCancelApplicationPost", (DecisionModels)TempData[Constant._ModelStateParent]);
                }
            }

            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

            string Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,applicationremarks=@applicationremarks,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            Cmd.Parameters.AddWithValue("@applicationremarks", model.SchollRemarks);
            Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.CANCEL);
            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
            cmdList.Add(Cmd);

            Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,applicationremarks=@applicationremarks,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            Cmd.Parameters.AddWithValue("@applicationremarks", model.SchollRemarks);
            Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.CANCEL);
            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
            cmdList.Add(Cmd);

            //insert in audit trail
            cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo.ToString(), (int)ApplicationHistoryMessage.MSG032, model.SchollRemarks, (int)ApplicationSource.Window, null));

            data.SaveData(cmdList);

            ViewBag.Message = "Application has been successfully Canceled.";
            return View("HGCancelApplication");
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult HGRejectApplication()
        {
            DecisionModels model = new DecisionModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult HGRejectApplication(DecisionModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = "select HSDS.ApplicationNo,ApplicantName,ApplicantFatherName,ApplicationStatusId from dgen.heskilldevelopmentscheme HSDS inner join ApplicationDetails AD on AD.ApplicationNo=HSDS.ApplicationNo where HSDS.ApplicationNo=@ApplicationNo and ApplicationStatusId=@ApplicationStatusId";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", ((int)Status.TEHSREJ).ToString());
                model.data = data.GetDataTable(Cmd);
                PreserveModelState(Constant._ModelStateParent, model, false, true);
                return View("HGRejectApplicationPost", model);
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult HGRejectApplicationPost(DecisionModels model)
        {
            if (model.StatusId == ((int)Status.TEHSREC).ToString())
            {
                if (!model.WhetherVerification)
                {
                    ViewBag.Message = "Please verify thay you wnat to Re-Allow of Application.";
                    PreserveModelState(Constant._ModelStateParent, null, true, false);
                    return View("HGRejectApplicationPost", (DecisionModels)TempData[Constant._ModelStateParent]);
                }
            }

            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

            string Qry = "update dgen.heskilldevelopmentscheme set WhetherReAllow=@WhetherReAllow,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            Cmd.Parameters.AddWithValue("@WhetherReAllow", CustomText.True.ToString());
            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
            cmdList.Add(Cmd);

            //Qry = "update wgen.heskilldevelopmentscheme set WhetherReAllow=@WhetherReAllow, set ApplicationStatusId=@ApplicationStatusId,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
            //Cmd = new NpgsqlCommand(Qry);
            //Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            //Cmd.Parameters.AddWithValue("@WhetherReAllow", CustomText.True.ToString());
            //Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
            //Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
            //cmdList.Add(Cmd);

            //insert in audit trail
            cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo.ToString(), (int)ApplicationHistoryMessage.MSG032, null, (int)ApplicationSource.Window, null));

            data.SaveData(cmdList);

            ViewBag.Message = "Application has been successfully processed.";
            return View("HGRejectApplication");
        }

        [Authorize(Roles = "104")]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult HeMCMServiceWisePendingSummary(int sid)
        {
            GetData data = new GetData();
            string WhetherCondition = string.Empty;
            DecisionModels model = new DecisionModels();
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { WhetherCondition += " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { WhetherCondition += " and AD.applicationDistrictCode in (@ParamDistrictCode) "; }
            string Qry = "select SC.ServiceName,SC.ServiceCode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and whetherrecommended=@WhetherSchoolRecomended then 1 end),0) as Recomended,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and whetherrecommended=@WhetherSchoolRecomended1 then 1 end),0) as NotRecomended  from dbo.ApplicationDetails AD  inner join dgen.heapplicationprocess HAP on HAP.ApplicationNo=AD.ApplicationNo right outer join ServiceMaster SC on SC.ServiceCode=AD.ServiceCode where SC.deptcode=@ParamDeptCode and UniversityId=@UniversityId and AD.ServiceCode in (@ParamServiceCode) and AD.ServiceCode<>@ServiceCode and HAP.AcademicSession=(select valueName::integer from SelectMasterValueDetails where ValueId=@AcademicSession) " + WhetherCondition + " group by SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.HigherEducationSKGS);
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended1", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@UniversityId", Sessions.getEmployeeUser().AuthorizationId);
            cmd.Parameters.AddWithValue("@AcademicSession", (int)ValueId.HigherEduCurAcadmicSession);
            model.data = data.GetDataTable(cmd);
            model.StatusId = sid.ToString();

            Qry = "select SMVD.valuename as AcademicSession,(SMVD.valuename ||'-'||SMVD.valuename::integer + 1) as AcademicSessionType from  selectmastervaluedetails SMVD inner join selectmastervaluetodetails SMVTD  on SMVTD.valueid=SMVD.valueid where mastervalueid=@mastervalueid";
            cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HigherEduAcadmicSession);
            model.data1 = data.GetDataTable(cmd);
            if (model.data1 != null && model.data1.Rows.Count > 0)
            {
                model.AcademicSession = model.data1.Rows[0]["AcademicSession"].ToString();
                model.AcademicSessionType = model.data1.Rows[0]["AcademicSessionType"].ToString();
            }

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "104")]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult HeMCMInstituteWisePendingSummary(int ServiceCode, int AcademicSession, string AcademicSessionType)
        {
            GetData data = new GetData();
            string WhetherCondition = string.Empty;
            DecisionModels model = new DecisionModels();

            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { WhetherCondition += " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { WhetherCondition += " and AD.applicationDistrictCode in (@ParamDistrictCode) "; }
            string Qry = "select HAP.InstitutionId,InstituitonName,SC.ServiceName,SC.ServiceCode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and whetherrecommended=@WhetherSchoolRecomended then 1 end),0) as Recomended,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and whetherrecommended=@WhetherSchoolRecomended1 then 1 end),0) as NotRecomended  from dbo.ApplicationDetails AD  inner join dgen.heapplicationprocess HAP on HAP.ApplicationNo=AD.ApplicationNo right outer join HeInstitutionMaster HIM on HIM.InstituitonId=HAP.InstitutionId right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where SC.deptcode=@ParamDeptCode and AD.ServiceCode<>@HigherEducationSKGS  and HAP.UniversityId=@UniversityId and AD.ServiceCode in (@ServiceCode) and HAP.AcademicSession=@AcademicSession " + WhetherCondition + " group by HAP.InstitutionId,InstituitonName,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@HigherEducationSKGS", (int)ServiceList.HigherEducationSKGS);
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended1", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@UniversityId", Sessions.getEmployeeUser().AuthorizationId);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.data = data.GetDataTable(cmd);

            model.AcademicSessionType = AcademicSessionType;
            model.AcademicSession = AcademicSession.ToString();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "104")]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult HeMCMPendingDecsionList(int ServiceCode, int InstituteId, int Type, int AcademicSession, string AcademicSessionType)
        {
            string value = string.Empty;
            GetData data = new GetData();
            string Qry = string.Empty, WhetherCondition = string.Empty;
            DecisionModels model = new DecisionModels();
            model.Flag = Type.ToString();

            if (Type == (int)CountList.Type000) { WhetherCondition = " and whetherrecommended=true "; } else if (Type == (int)CountList.Type001) { WhetherCondition = " and whetherrecommended=false "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { WhetherCondition += " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { WhetherCondition += " and AD.applicationDistrictCode in (@ParamDistrictCode) "; }
            Qry = @"select InstituitonName,AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,AD.ApplicantDob,AD.ApplicationStatusId from dbo.ApplicationDetails AD inner join dgen.heapplicationprocess HAP on HAP.ApplicationNo=AD.ApplicationNo inner join HeInstitutionMaster HIM on HIM.InstituitonId=HAP.InstitutionId inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode where AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId and HAP.AcademicSession=@AcademicSession " + WhetherCondition + "  and InstitutionId=@InstitutionId  and HAP.UniversityId =@UniversityId order by AD.applicationdate ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@InstitutionId", InstituteId);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@UniversityId", Sessions.getEmployeeUser().AuthorizationId);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.data = data.GetDataTable(cmd);
            model.AcademicSessionType = AcademicSessionType;
            return View(model);
        }
        [Authorize(Roles = "104")]
        [EncryptedActionParameter]
        public ActionResult PendingAppDecisionDetailsHEMCM(Int64 AppNo, int? Source = 0)
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }

            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();
            if (Source != 0) { model.Source = Source.ToString(); }

            string WhetherCondition = string.Empty, DisplayMessage = string.Empty;
            string[] Values = Utility.GetServiceCode(Convert.ToInt64(model.ApplicationDetails.ApplicationNo));

            string Qry = "select ServiceCode,ApplicationStatusId from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo " + WhetherCondition + " and ServiceCode in (@ParamServiceCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //Cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            string[] GetValues = data.SelectColumns(Cmd);
            model.ApplicationDetails.ServiceCode = GetValues[0];
            model.ApplicationDetails.ApplicationStatusId = GetValues[1];

            //check whether document verified or not??
            Qry = "select documentstatusid from web.registrationmaster RM left outer join dbo.applicationdetails AD on RM.RegistrationId=AD.RegistrationId where AD.ApplicationNo=@ApplicationNo and RM.DocumentId in (@AadhaarCard,@VoterID)";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@AadhaarCard", ((int)DocumentId.AadhaarCard).ToString());
            Cmd.Parameters.AddWithValue("@VoterID", ((int)DocumentId.VoterID).ToString());
            model.DocumentStatusId = data.SelectColumns(Cmd)[0];

            string flag = Utility.SelectColumnsValue("dbo.VerifierVerificationReport", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
            if (string.IsNullOrEmpty(flag)) { model.WhetherVerification = false; } else { model.WhetherVerification = true; }


            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data1 = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data2 = Utility.GetServiceSpecificVerificationDetails(model.ApplicationDetails.ApplicationNo);

            Qry = "select Feeamount from dgen.hefeedetails where ApplicationNo=@ApplicationNo and FeeInitiateBy=@FeeInitiateBy";
            Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@FeeInitiateBy", (int)ValueId.Department);
            model.data3 = data.GetDataTable(Cmd);

            model.data4 = Utility.GetApplicationAuditTrail(model.ApplicantDetails.ApplicationNo);

            //Qry = "select AD.ApplicationNo from applicationdetails AD where applicationstatusid=@applicationstatusid and registrationid=@registrationid";
            //Cmd = new NpgsqlCommand(Qry);
            //Cmd.Parameters.AddWithValue("@applicationstatusid", (int)Status.ISSUCER);
            //Cmd.Parameters.AddWithValue("@registrationid", model.ApplicantDetails.RegistrationId);
            //model.data5 = data.GetDataTable(Cmd);
            model.data5 = Utility.GetApplicantAvailedService(model.ApplicantDetails.RegistrationId.ToString());


            Qry = "select Processstatusid,WhetherRecommended,WhetherRevertBack,RevertBackRemarks,Instituteremarks,VerificationBy,Verificationipaddress from dgen.heapplicationprocess where ApplicationNo=@ApplicationNo";
            Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            model.data7 = data.GetDataTable(Cmd);

            model.WhetherDocVerified = Utility.CheckWhetherDocVerify(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.HeFinancialAssistance)
            {
                model.HeMCMFinancialAssistance = Utility.GetHeMCMFinancialAssistanceDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }

            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [Authorize(Roles = "104")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingAppDecisionDetailsHEMCM(DecisionModels model, FormCollection frm)
        {
            model.ServiceCode = Utility.SelectColumnsValue("ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0];
            model.DeptCode = Utility.GetDeptCode(model.ServiceCode);

            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string QueryString = string.Empty, Qry = string.Empty, DisplayMessage = string.Empty;

                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.ISSUCER).ToString())
                {
                    //bool WhetherExist = Utility.HoldDuplicateApplication(Convert.ToInt64(model.ApplicationDetails.ApplicationNo));
                    //if (WhetherExist == false)
                    //{
                    //    DisplayMessage = "Approval can not be possible becuase the applicant already applied another application for this service. ";
                    //    PreserveModelState(Constant._ActionMessage, DisplayMessage, false, true);

                    //    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                    //    return RedirectToAction("PendingApplicationDecisionDetailsSCST", "Decision", new { q = QueryString });

                    //}

                    Dictionary<string, string> ValidateData = new Dictionary<string, string>();
                    ValidateData.Add("ApplicationNo", model.ApplicationDetails.ApplicationNo);

                    string[] ValidationCheck = Utility.ApplicationValidation(ValidateData, (int)ValidationCheckLevels.DecisionProcessGeneralPost, false);
                    if (ValidationCheck[0] == ((int)CountList.Type001).ToString())
                    {
                        DisplayMessage = ValidationCheck[1];
                        PreserveModelState(Constant._ActionMessage, DisplayMessage, false, true);

                        QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                        return RedirectToAction("PendingAppDecisionDetailsHEMCM", "Decision", new { q = QueryString });
                    }
                    else if (ValidationCheck[0] == ((int)CountList.Type002).ToString())
                    {
                        ViewData["message"] = ValidationCheck[1];
                        return View("message");
                    }

                    string resultrtn = Utility.CheckMCMCourseFee(model.ApplicationDetails.ApplicationNo.ToString(), ((int)CountList.Type003).ToString());
                    if (!string.IsNullOrEmpty(resultrtn))
                    {
                        ViewData["message"] = resultrtn;
                        return View("message");
                    }

                    Qry = "update dgen.heapplicationprocess set ProcessStatusId=@ProcessStatusId,ApprovedDate=now(),ApprovedBy=@ApprovedBy,ApprovedIpAddress=@ApprovedIpAddress where ApplicationNo=@ApplicationNo;";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.Approved);
                    Cmd.Parameters.AddWithValue("@ApprovedBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ApprovedIpAddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG002, null, (int)ApplicationSource.Window, null));

                    //send sms to applicant and insert record in table
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS003, smsDic));

                    //send email to applicant and insert record in table
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS003).ToString());
                    EmailDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREJ).ToString())
                {
                    //BypassPermission = true;
                    string ReasonOfRejection = model.ApplicationDetails.ApplicationRemarks;
                    if (model.ApplicationDetails.RejectionReasonCode != ((int)RejectionReason.Other).ToString()) { ReasonOfRejection = Utility.SelectColumnsValue("dbo.reasonmaster", "reasondetail", "reasoncode", model.ApplicationDetails.RejectionReasonCode)[0]; }

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG003, ReasonOfRejection, (int)ApplicationSource.Window, null));

                    //send sms to applicant and insert record in table
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    smsDic.Add("ParamRemarks", ReasonOfRejection);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS005, smsDic));

                    //send email to applicant and insert record in table
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS005).ToString());
                    EmailDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    EmailDic.Add("ParamRemarks", ReasonOfRejection);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.OBSPEND).ToString())
                {
                    Qry = "update dgen.heapplicationprocess set WhetherRevertBack=@WhetherRevertBack,processstatusid=@processstatusid,revertbackremarks=@revertbackremarks where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@processstatusid", (int)ValueId.PendingVerification);
                    Cmd.Parameters.AddWithValue("@revertbackremarks", model.ApplicationDetails.ApplicationRemarks);
                    cmdList.Add(Cmd);

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG051, model.ApplicationDetails.ApplicationRemarks, (int)ApplicationSource.Window, null));
                    //send sms to applicant and insert record in table
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS030, smsDic));

                    //send email to applicant and insert record in table
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS030).ToString());
                    EmailDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                }

                Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationDetails.ApplicationNo, Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId), (int)CountList.Type001, DB.LS.ToString()));
                Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                data.SaveData(cmdList);

                PreserveModelState(Constant._ActionMessage, "Selected application has been processed successfully.", false, true);
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.TEHSPEN).ToString() });
                return RedirectToAction("HeMCMServiceWisePendingSummary", new { q = QueryString });
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PendingAppDecisionDetailsHEMCM", (DecisionModels)TempData[Constant._ModelStateParent]);

        }
        #endregion

        #region decision methods for SC/ST
        [Authorize(Roles = "103,104")]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult SCSTServiceWisePendingSummary(int sid, int? AcademicSession = 0)
        {
            GetData data = new GetData();
            string WhetherCondition = string.Empty;
            DecisionModels model = new DecisionModels();

            if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
            string Qry = string.Empty;
            NpgsqlCommand cmd = new NpgsqlCommand();
            if (AcademicSession == (int)CountList.Type000)
            {
                //----------------------Temp comment for 2017-18 session, un-comment when you wants to process for 2017-18
                Qry = "select s1.valuename from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SCSTWelfareAcadmicSession);
                AcademicSession = Convert.ToInt32(data.SelectColumns(cmd)[0]);
                //AcademicSession = 2016;
            }

            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { WhetherCondition += " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { WhetherCondition += " and AD.applicationDistrictCode in (@ParamDistrictCode) "; }
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition += " and ( PAP.DepartmentId in (@Code) or PSM.District in (@Code) or PSM.SubDivision in (@Code))"; }
            if (AcademicSession != (int)CountList.Type000) { WhetherCondition += " and PAP.AcademicSession=@Academicsession "; }
            Qry = "select SC.ServiceName,SC.ServiceCode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and PAP.whetherrecommended=@WhetherSchoolRecomended then 1 end),0) as Recomended,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and PAP.whetherrecommended=@WhetherSchoolRecomended1 then 1 end),0) as NotRecomended  from dbo.ApplicationDetails AD  inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo inner join dgen.prematschoolmaster PSM on PSM.SchoolId=PAP.SchoolId left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode " + WhetherCondition + " and AD.ServiceCode in (@ParamServiceCode) and PAP.SchoolId is not Null  group by SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended1", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@Code", Sessions.getEmployeeUser().AuthorizationId);
            if (AcademicSession != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@Academicsession", AcademicSession); }
            model.data = data.GetDataTable(cmd);
            model.StatusId = sid.ToString();
            model.AcademicSession = AcademicSession.ToString();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult SCSTServiceWisePendingSummary(DecisionModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid", "AcademicSession" }, new ArrayList() { Convert.ToInt32(model.StatusId), AcademicSession });
                return RedirectToAction("SCSTServiceWisePendingSummary", "Decision", new { q = QueryString });
            }
            return View("SCSTServiceWisePendingSummary", model);
        }
        [Authorize(Roles = "103,104")]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult SCSTSchoolWisePendingSummary(int ServiceCode, int AcademicSession)
        {
            GetData data = new GetData();
            string WhetherCondition = string.Empty;
            DecisionModels model = new DecisionModels();

            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { WhetherCondition += " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { WhetherCondition += " and AD.applicationDistrictCode in (@ParamDistrictCode) "; }
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000)
            { WhetherCondition += " and ( PAP.DepartmentId in (@Code) or PSM.District in (@Code) or PSM.SubDivision in (@Code))"; }

            string Qry = "select PAP.SchoolID,SchoolName,SC.ServiceName,SC.ServiceCode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and whetherrecommended=@WhetherSchoolRecomended then 1 end),0) as Recomended,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and whetherrecommended=@WhetherSchoolRecomended1 then 1 end),0) as NotRecomended  from dbo.ApplicationDetails AD  inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo inner join dgen.prematschoolmaster PSM on PSM.SchoolId=PAP.SchoolId left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode  and AD.ServiceCode in (@ServiceCode) and PAP.AcademicSession=@AcademicSession " + WhetherCondition + " group by PAP.SchoolID,SchoolName,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended1", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            cmd.Parameters.AddWithValue("@Code", Sessions.getEmployeeUser().AuthorizationId);
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "103,104")]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult SCSTPendingSummary(int sid, int? AcademicSession = 0)
        {
            GetData data = new GetData();
            string WhetherCondition = string.Empty;
            DecisionModels model = new DecisionModels();

            if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
            string Qry = string.Empty;
            NpgsqlCommand cmd = new NpgsqlCommand();
            if (AcademicSession == (int)CountList.Type000)
            {
                //----------------------Temp comment for 2017-18 session, un-comment when you wants to process for 2017-18
                Qry = "select s1.valuename from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SCSTWelfareAcadmicSession);
                AcademicSession = Convert.ToInt32(data.SelectColumns(cmd)[0]);
                //AcademicSession = 2016;
            }

            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { WhetherCondition += " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { WhetherCondition += " and AD.applicationDistrictCode in (@ParamDistrictCode) "; }
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition += " and PAP.DepartmentId in (@Code)"; }
            if (AcademicSession != (int)CountList.Type000) { WhetherCondition += " and PAP.AcademicSession=@Academicsession "; }
            Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId then 1 end),0) as Pending from dbo.ApplicationDetails AD  inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode " + WhetherCondition + " and AD.ServiceCode in (@ParamServiceCode) and PAP.SchoolId is Null  group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended1", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@Code", Sessions.getEmployeeUser().AuthorizationId);
            if (AcademicSession != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@Academicsession", AcademicSession); }
            model.data = data.GetDataTable(cmd);
            model.StatusId = sid.ToString();
            model.AcademicSession = AcademicSession.ToString();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult SCSTPendingSummary(DecisionModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid", "AcademicSession" }, new ArrayList() { Convert.ToInt32(model.StatusId), AcademicSession });
                return RedirectToAction("SCSTPendingSummary", "Decision", new { q = QueryString });
            }
            return View("SCSTPendingSummary", model);
        }
        [Authorize(Roles = "103,104")]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult SCSTPendingDecsionList(int ServiceCode, int SchoolId, int Type, int AcademicSession)
        {
            string value = string.Empty;
            GetData data = new GetData();
            string Qry = string.Empty, WhetherCondition = string.Empty;
            DecisionModels model = new DecisionModels();
            model.Flag = Type.ToString();

            if (Type == (int)CountList.Type000) { WhetherCondition = " and whetherrecommended=true "; } else if (Type == (int)CountList.Type001) { WhetherCondition = " and whetherrecommended=false "; }
            if (SchoolId == (int)CountList.Type000) { WhetherCondition += " and PAP.schoolid is null "; } else { WhetherCondition += " and PAP.schoolid=@SchoolId "; }

            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { WhetherCondition += " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { WhetherCondition += " and AD.applicationDistrictCode in (@ParamDistrictCode) "; }

            if (SchoolId == (int)CountList.Type000)
            {
                if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition += " and PAP.DepartmentId in (@Code)"; }
            }
            else
            {
                if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition += " and ( PAP.DepartmentId in (@Code) or PSM.District in (@Code) or PSM.SubDivision in (@Code))"; }
            }

            if (SchoolId == (int)CountList.Type000) { Qry = @"select 'Out of Delhi' as SchoolName,"; } else { Qry = @"select SchoolName,"; }
            Qry += @"AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,AD.ApplicantDob,AD.ApplicationStatusId from dbo.ApplicationDetails AD inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo ";
            if (SchoolId != (int)CountList.Type000) { Qry += @" inner join dgen.prematschoolmaster PSM on PSM.SchoolId=PAP.SchoolId "; }
            Qry += @"inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode where AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId and PAP.AcademicSession=@AcademicSession " + WhetherCondition + " order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@SchoolId", SchoolId);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@Code", Sessions.getEmployeeUser().AuthorizationId);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.data = data.GetDataTable(cmd);

            model.AcademicSession = AcademicSession.ToString();
            return View(model);
        }
        [Authorize(Roles = "103,104")]
        [EncryptedActionParameter]
        public ActionResult PendingApplicationDecisionDetailsSCST(Int64 AppNo)
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }

            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();
            //if (Source != 0) { model.Source = Source.ToString(); }

            string Qry = "select AD.ServiceCode,AD.ApplicationStatusId from dbo.ApplicationDetails AD inner join dbo.ServiceMaster SM on AD.ServiceCode=SM.ServiceCode where AD.ApplicationNo=@ApplicationNo and SM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode)"; //  and AD.AcceptedBy in (@AcceptedBy)
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            //Cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            string[] GetValues = data.SelectColumns(Cmd);
            model.ApplicationDetails.ServiceCode = GetValues[0];
            model.ApplicationDetails.ApplicationStatusId = GetValues[1];

            //check whether document verified or not??
            Qry = "select documentstatusid from web.registrationmaster RM left outer join dbo.applicationdetails AD on RM.RegistrationId=AD.RegistrationId where AD.ApplicationNo=@ApplicationNo and RM.DocumentId in (@AadhaarCard,@VoterID)";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@AadhaarCard", ((int)DocumentId.AadhaarCard).ToString());
            Cmd.Parameters.AddWithValue("@VoterID", ((int)DocumentId.VoterID).ToString());
            model.DocumentStatusId = data.SelectColumns(Cmd)[0];

            string flag = Utility.SelectColumnsValue("dbo.VerifierVerificationReport", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
            if (string.IsNullOrEmpty(flag)) { model.WhetherVerification = false; } else { model.WhetherVerification = true; }

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data1 = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data2 = Utility.GetServiceSpecificVerificationDetails(model.ApplicationDetails.ApplicationNo);
            model.data3 = Utility.GetObjectionDetails(model.ApplicantDetails.ApplicationNo.ToString());
            model.data4 = Utility.GetApplicationAuditTrail(model.ApplicantDetails.ApplicationNo);
            model.data6 = Utility.GetSingleDocVerificationStatus(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.data7 = Utility.GetMobileSahayakDetailsData(model.ApplicationDetails.ApplicationNo);
            model.data5 = Utility.GetApplicantAvailedService(model.ApplicantDetails.RegistrationId.ToString());

            model.WhetherDocVerified = Utility.CheckWhetherDocVerify(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());

            Qry = "select ApplicantName,to_char(ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB, Case When ApplicantGender='M' Then 'Male' When ApplicantGender='F' Then 'Female' When ApplicantGender='T' Then 'Transgender' end as ApplicantGender from dgen.scstupdatedapplicationdetail where ApplicationNo=@ApplicationNo";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
            model.data8 = data.GetDataTable(Cmd);

            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PrematricScholarshipSC)
            {
                model.ApplicationDetailsPrematsSC = Utility.GetPrematsSCDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.WhetherRecommend = model.ApplicationDetailsPrematsSC.WhetherSchoolRecomended;
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.FinancialAssistanceStationery)
            {
                model.ApplicationDetailsFinancialAssistance = Utility.GetFinancialAssistanceDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.WhetherRecommend = model.ApplicationDetailsFinancialAssistance.WhetherSchoolRecomended;
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MeritscholarshipSchool)
            {
                model.ApplicationDetailsMeritscholarshipSchool = Utility.GetMeritscholarshipSchoolDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.WhetherRecommend = model.ApplicationDetailsMeritscholarshipSchool.WhetherSchoolRecomended;
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.DrbrAmbedkarToppers)
            {
                model.ApplicationDetailsDrbrAmbedkarToppers = Utility.GetDrbrAmbedkarToppersDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.WhetherRecommend = model.ApplicationDetailsDrbrAmbedkarToppers.WhetherSchoolRecomended;
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MeritscholarshipProfessional)
            {
                model.ApplicationDetailsMeritProfessional = Utility.GetMeritscholarshipProfessionalDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.WhetherRecommend = model.ApplicationDetailsMeritProfessional.WhetherSchoolRecomended;
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PrematricScholarshipOBC)
            {
                model.ApplicationDetailsPrematOBC = Utility.GetPrematsOBCDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.WhetherRecommend = model.ApplicationDetailsPrematOBC.WhetherSchoolRecomended;
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PostmatricScholarshipOBC)
            {
                model.ApplicationDetailsPostmatOBC = Utility.GetPostmatOBCDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.WhetherRecommend = model.ApplicationDetailsPostmatOBC.WhetherSchoolRecomended;
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PrematricSC)
            {
                model.ApplicationDetailsPrematSCssd = Utility.GetPrematSCSSDDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.WhetherRecommend = model.ApplicationDetailsPrematSCssd.WhetherSchoolRecomended;
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PostmatricSC)
            {
                model.ApplicationDetailsPostmatSCssd = Utility.GetPostmatSCSSDDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.WhetherRecommend = model.ApplicationDetailsPostmatSCssd.WhetherSchoolRecomended;
            }

            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [Authorize(Roles = "103,104")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingApplicationDecisionDetailsSCST(DecisionModels model, FormCollection frm)
        {
            model.ServiceCode = Utility.SelectColumnsValue("ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0];
            model.DeptCode = Utility.GetDeptCode(model.ServiceCode);

            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                //bool BypassPermission = false;
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string QueryString = string.Empty, Qry = string.Empty, DisplayMessage = string.Empty;

                Dictionary<string, string> ValidateData = new Dictionary<string, string>();
                ValidateData.Add("ApplicationNo", model.ApplicationDetails.ApplicationNo);

                string[] ValidationCheck = Utility.ApplicationValidation(ValidateData, (int)ValidationCheckLevels.DecisionProcessGeneralPost, false);
                if (ValidationCheck[0] == ((int)CountList.Type001).ToString())
                {
                    DisplayMessage = ValidationCheck[1];
                    PreserveModelState(Constant._ActionMessage, DisplayMessage, false, true);

                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                    return RedirectToAction("PendingApplicationDecisionDetailsSCST", "Decision", new { q = QueryString });
                }
                else if (ValidationCheck[0] == ((int)CountList.Type002).ToString())
                {
                    ViewData["message"] = ValidationCheck[1];
                    return View("message");
                }

                // check verification and approval letter uploaded or not?
                Qry = "select Academicsession,SchoolId from dgen.prematapplicationprocess where ApplicationNo=@ApplicationNo and whetherrevertback=@whetherrevertback;";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@whetherrevertback", CustomText.False.ToString());
                string[] Values = data.SelectColumns(Cmd);
                if (Values != null)
                {
                    if (!string.IsNullOrEmpty(Values[0]))
                    {
                        Qry = "select DepartmentId from dbyt.prematverifiedapplication where SchoolId=@SchoolId and ServiceCode=@ServiceCode and WhetherFileUploaded=@WhetherFileUploaded and Academicsession=@Academicsession and Academicsession<>@AcademicsessionNotIn and DepartmentId=@DepartmentId";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@SchoolId", Values[1]);
                        Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                        Cmd.Parameters.AddWithValue("@WhetherFileUploaded", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@Academicsession", Values[0]);
                        Cmd.Parameters.AddWithValue("@AcademicsessionNotIn", "2016");
                        Cmd.Parameters.AddWithValue("@DepartmentId", Sessions.getEmployeeUser().AuthorizationId);
                        string DepartmentId = data.SelectColumns(Cmd)[0];
                        if (!string.IsNullOrEmpty(DepartmentId))
                        {
                            ViewData["message"] = "You are Not Allowed To Take Decision on the Application. Your Have Alerady Uploaded The Approval Letter!!!";
                            return View("message");
                        }

                        //Qry = "select SchoolId from dbyt.prematverifiedapplication where SchoolId=@SchoolId and ServiceCode=@ServiceCode and WhetherFileUploaded=@WhetherFileUploaded and WhetherRevertBack=@WhetherRevertBack and AcademicSession=@AcademicSession and AcademicSession=@AcademicsessionNotIn and DepartmentId=@DepartmentId";
                        //Cmd = new NpgsqlCommand(Qry);
                        //Cmd.Parameters.AddWithValue("@SchoolId", Values[1]);
                        //Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                        //Cmd.Parameters.AddWithValue("@WhetherFileUploaded", CustomText.TRUE.ToString());
                        //Cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.FALSE.ToString());
                        //Cmd.Parameters.AddWithValue("@DepartmentId", (int)CountList.Type000);
                        //Cmd.Parameters.AddWithValue("@AcademicSession", Values[0]);
                        //Cmd.Parameters.AddWithValue("@AcademicsessionNotIn", "2016");
                        //string SchlId = data.SelectColumns(Cmd)[0];
                        //if (string.IsNullOrEmpty(SchlId))
                        //{
                        //    ViewData["message"] = "Your Are Not Allowed To Take Decision on the Application,First Upload The Verification Letter!!!";
                        //    return View("message");
                        //}
                    }
                }
                else
                {
                    return RedirectToAction("BadRequest", "Error");
                }


                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREC).ToString())
                {
                    bool WhetherExist = Utility.HoldDuplicateApplication(Convert.ToInt64(model.ApplicationDetails.ApplicationNo));
                    if (WhetherExist == false)
                    {
                        DisplayMessage = "Approval can not be possible becuase the applicant already applied another application for this service. ";
                        PreserveModelState(Constant._ActionMessage, DisplayMessage, false, true);
                        QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                        return RedirectToAction("PendingApplicationDecisionDetailsSCST", "Decision", new { q = QueryString });
                    }

                    Qry = "update dgen.prematapplicationprocess set ProcessStatusId=@ProcessStatusId,ApprovedDate=now(),ApprovedBy=@ApprovedBy,ApprovedIpAddress=@ApprovedIpAddress where ApplicationNo=@ApplicationNo;";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.Approved);
                    Cmd.Parameters.AddWithValue("@ApprovedBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ApprovedIpAddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG002, null, (int)ApplicationSource.Window, null));
                    
                    //send sms to applicant and insert record in table
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS003, smsDic));

                    //send email to applicant and insert record in table
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS003).ToString());
                    EmailDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREJ).ToString())
                {
                    // get reason of rejection
                    string ReasonOfRejection = model.ApplicationDetails.ApplicationRemarks;
                    if (model.ApplicationDetails.RejectionReasonCode != ((int)RejectionReason.Other).ToString()) { ReasonOfRejection = Utility.SelectColumnsValue("dbo.reasonmaster", "reasondetail", "reasoncode", model.ApplicationDetails.RejectionReasonCode)[0]; }

                    //// tempraroy code for check duplicate application
                    //Qry = "update temp_duplicateapplication set WhetherActive=False where ApplicationNo=@ApplicationNo;";
                    //Cmd = new NpgsqlCommand(Qry);
                    //Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    //cmdList.Add(Cmd);

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG003, ReasonOfRejection, (int)ApplicationSource.Window, null));

                    //send sms to applicant and insert record in table
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    smsDic.Add("ParamRemarks", ReasonOfRejection);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS005, smsDic));

                    //send email to applicant and insert record in table
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS005).ToString());
                    EmailDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    EmailDic.Add("ParamRemarks", ReasonOfRejection);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.DEALOLR).ToString())
                {
                    string SchoolId = string.Empty;
                    if (model.ServiceCode.Equals(((int)ServiceList.PrematricScholarshipSC).ToString()))
                    {
                        model.ApplicationDetails.ApplicationStatusId = ((int)Status.OBSPEND).ToString();
                        SchoolId = Utility.SelectColumnsValue("dgen.applicationdetailsprematssc", "SchoolId", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                        Qry = "update dgen.applicationdetailsprematssc set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@Observation", model.ApplicationDetails.ApplicationRemarks);
                        Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                    else if (model.ServiceCode.Equals(((int)ServiceList.FinancialAssistanceStationery).ToString()))
                    {
                        model.ApplicationDetails.ApplicationStatusId = ((int)Status.OBSPEND).ToString();
                        SchoolId = Utility.SelectColumnsValue("dgen.applicationdetailsfinancialassistance", "SchoolId", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                        Qry = "update dgen.applicationdetailsfinancialassistance set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@Observation", model.ApplicationDetails.ApplicationRemarks);
                        Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                    else if (model.ServiceCode.Equals(((int)ServiceList.MeritscholarshipSchool).ToString()))
                    {
                        model.ApplicationDetails.ApplicationStatusId = ((int)Status.OBSPEND).ToString();
                        SchoolId = Utility.SelectColumnsValue("dgen.applicationdetailsmeritscholarshipschool", "SchoolId", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                        Qry = "update dgen.applicationdetailsmeritscholarshipschool set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@Observation", model.ApplicationDetails.ApplicationRemarks);
                        Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                    else if (model.ServiceCode.Equals(((int)ServiceList.DrbrAmbedkarToppers).ToString()))
                    {
                        model.ApplicationDetails.ApplicationStatusId = ((int)Status.OBSPEND).ToString();
                        SchoolId = Utility.SelectColumnsValue("dgen.applicationdetailsbrambedkar", "SchoolId", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                        Qry = "update dgen.applicationdetailsbrambedkar set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@Observation", model.ApplicationDetails.ApplicationRemarks);
                        Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                    else if (model.ServiceCode.Equals(((int)ServiceList.MeritscholarshipProfessional).ToString()))
                    {
                        SchoolId = Utility.SelectColumnsValue("dgen.applicationdetailsmeritprofessional", "SchoolId", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                        if (string.IsNullOrEmpty(SchoolId))
                        {
                            model.ApplicationDetails.ApplicationStatusId = ((int)Status.DEALOLR).ToString();
                        }
                        else
                        {
                            model.ApplicationDetails.ApplicationStatusId = ((int)Status.OBSPEND).ToString();
                        }

                        Qry = "update dgen.applicationdetailsmeritprofessional set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@Observation", model.ApplicationDetails.ApplicationRemarks);
                        Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                    else if (model.ServiceCode.Equals(((int)ServiceList.PrematricScholarshipOBC).ToString()))
                    {
                        model.ApplicationDetails.ApplicationStatusId = ((int)Status.OBSPEND).ToString();
                        SchoolId = Utility.SelectColumnsValue("dgen.applicationdetailsprematobc", "SchoolId", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                        Qry = "update dgen.applicationdetailsprematobc set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@Observation", model.ApplicationDetails.ApplicationRemarks);
                        Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                    else if (model.ServiceCode.Equals(((int)ServiceList.PostmatricScholarshipOBC).ToString()))
                    {
                        SchoolId = Utility.SelectColumnsValue("dgen.applicationdetailspostmatobc", "SchoolId", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                        if (string.IsNullOrEmpty(SchoolId))
                        {
                            model.ApplicationDetails.ApplicationStatusId = ((int)Status.DEALOLR).ToString();
                        }
                        else
                        {
                            model.ApplicationDetails.ApplicationStatusId = ((int)Status.OBSPEND).ToString();
                        }

                        Qry = "update dgen.applicationdetailspostmatobc set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@Observation", model.ApplicationDetails.ApplicationRemarks);
                        Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                    else if (model.ServiceCode.Equals(((int)ServiceList.PrematricSC).ToString()))
                    {
                        model.ApplicationDetails.ApplicationStatusId = ((int)Status.OBSPEND).ToString();
                        SchoolId = Utility.SelectColumnsValue("dgen.applicationdetailsprematscssd", "SchoolId", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                        Qry = "update dgen.applicationdetailsprematscssd set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@Observation", model.ApplicationDetails.ApplicationRemarks);
                        Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                    else if (model.ServiceCode.Equals(((int)ServiceList.PostmatricSC).ToString()))
                    {
                        SchoolId = Utility.SelectColumnsValue("dgen.applicationdetailspostmatscssd", "SchoolId", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                        if (string.IsNullOrEmpty(SchoolId))
                        {
                            model.ApplicationDetails.ApplicationStatusId = ((int)Status.DEALOLR).ToString();
                        }
                        else
                        {
                            model.ApplicationDetails.ApplicationStatusId = ((int)Status.OBSPEND).ToString();
                        }

                        Qry = "update dgen.applicationdetailspostmatscssd set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@Observation", model.ApplicationDetails.ApplicationRemarks);
                        Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }

                    if (!string.IsNullOrEmpty(SchoolId))
                    {
                        Qry = "select letterId from dbyt.prematverifiedapplication where SchoolId=@SchoolId and ServiceCode=@ServiceCode and WhetherFileUploaded=@WhetherFileUploaded and AcademicSession=@AcademicSession and DepartmentId=@DepartmentId";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@SchoolId", SchoolId);
                        Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                        Cmd.Parameters.AddWithValue("@WhetherFileUploaded", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@AcademicSession", Values[0]);
                        Cmd.Parameters.AddWithValue("@DepartmentId", (int)CountList.Type000);
                        string letterId = data.SelectColumns(Cmd)[0];
                        if (!string.IsNullOrEmpty(letterId))
                        {
                            Qry = "update dbyt.prematverifiedapplication set WhetherRevertBack=@WhetherRevertBack where letterId=@letterId";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@letterId", letterId);
                            Cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.True.ToString());
                            cmdList.Add(Cmd);
                        }

                    }

                    Qry = "update dgen.prematapplicationprocess set WhetherRevertBack=@WhetherRevertBack,processstatusid=@processstatusid,whethervletteruploaded=@whethervletteruploaded where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@processstatusid", (int)ValueId.PendingVerification);
                    Cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@whethervletteruploaded", CustomText.False.ToString());
                    cmdList.Add(Cmd);

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG051, model.ApplicationDetails.ApplicationRemarks, (int)ApplicationSource.Window, null));
                    
                    //send sms to applicant and insert record in table
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS030, smsDic));

                    //send email to applicant and insert record in table
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS030).ToString());
                    EmailDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                }

                Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationDetails.ApplicationNo, Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId), (int)CountList.Type001, DB.LS.ToString()));
                Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                data.SaveData(cmdList);

                PreserveModelState(Constant._ActionMessage, "Selected application has been processed successfully.", false, true);
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.TEHSPEN).ToString() });
                return RedirectToAction("SCSTServiceWisePendingSummary", new { q = QueryString });
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PendingApplicationDecisionDetailsSCST", (DecisionModels)TempData[Constant._ModelStateParent]);

        }
        [Authorize(Roles = "103,104")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SCSTApproveMultipleApplication(DecisionModels model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string QueryString = string.Empty, Qry = string.Empty, DisplayMessage = string.Empty;
                string checkboxvalue = frm["chkboxData"];
                string[] Values = checkboxvalue.Split(',');

                for (int i = 0; i < Values.Length; i++)
                {
                    //bool WhetherExist = Utility.HoldDuplicateApplication(Convert.ToInt64(Values[i].ToString()));
                    //if (WhetherExist == false)
                    //{
                    //    DisplayMessage = "Approval can not be possible on Application No " + Values[i].ToString() + " becuase the applicant already applied another application for this service.";
                    //    PreserveModelState(Constant._ActionMessage, DisplayMessage, false, true);
                    //    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.TEHSPEN).ToString() });
                    //    return RedirectToAction("SCSTServiceWisePendingSummary", new { q = QueryString });
                    //}

                    Dictionary<string, string> ValidateData = new Dictionary<string, string>();
                    ValidateData.Add("ApplicationNo", Values[i].ToString());

                    string[] ValidationCheck = Utility.ApplicationValidation(ValidateData, (int)ValidationCheckLevels.DecisionProcessGeneralPost, false);
                    if (ValidationCheck[0] == ((int)CountList.Type001).ToString())
                    {
                        DisplayMessage = ValidationCheck[1];
                        PreserveModelState(Constant._ActionMessage, DisplayMessage, false, true);

                        QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.TEHSPEN).ToString() });
                        return RedirectToAction("SCSTServiceWisePendingSummary", "Decision", new { q = QueryString });
                    }
                    else if (ValidationCheck[0] == ((int)CountList.Type002).ToString())
                    {
                        ViewData["message"] = ValidationCheck[1];
                        return View("message");
                    }

                    // check whether verification and approval letter uploaded or not?
                    Qry = "select Academicsession,SchoolId from dgen.prematapplicationprocess where ApplicationNo=@ApplicationNo and whetherrevertback=@whetherrevertback;";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", Values[i].ToString());
                    Cmd.Parameters.AddWithValue("@whetherrevertback", CustomText.False.ToString());
                    string[] Value = data.SelectColumns(Cmd);
                    if (Value != null)
                    {
                        if (!string.IsNullOrEmpty(Value[0]))
                        {
                            Qry = "select DepartmentId from dbyt.prematverifiedapplication where SchoolId=@SchoolId and ServiceCode=@ServiceCode and WhetherFileUploaded=@WhetherFileUploaded and Academicsession=@Academicsession and Academicsession<>@AcademicsessionNotIn and DepartmentId=@DepartmentId";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@SchoolId", Value[1]);
                            Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                            Cmd.Parameters.AddWithValue("@WhetherFileUploaded", CustomText.TRUE.ToString());
                            Cmd.Parameters.AddWithValue("@Academicsession", Value[0]);
                            Cmd.Parameters.AddWithValue("@AcademicsessionNotIn", "2016");
                            Cmd.Parameters.AddWithValue("@DepartmentId", Sessions.getEmployeeUser().AuthorizationId);
                            string DepartmentId = data.SelectColumns(Cmd)[0];
                            if (!string.IsNullOrEmpty(DepartmentId))
                            {
                                ViewData["message"] = "You are Not Allowed To Take Decision on the Application. Your Have Alerady Uploaded The Approval Letter!!!";
                                return View("message");
                            }

                            Qry = "select SchoolId from dbyt.prematverifiedapplication where SchoolId=@SchoolId and ServiceCode=@ServiceCode and WhetherFileUploaded=@WhetherFileUploaded and WhetherRevertBack=@WhetherRevertBack and AcademicSession=@AcademicSession and AcademicSession=@AcademicsessionNotIn and DepartmentId=@DepartmentId";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@SchoolId", Value[1]);
                            Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                            Cmd.Parameters.AddWithValue("@WhetherFileUploaded", CustomText.TRUE.ToString());
                            Cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.FALSE.ToString());
                            Cmd.Parameters.AddWithValue("@DepartmentId", (int)CountList.Type000);
                            Cmd.Parameters.AddWithValue("@AcademicSession", Value[0]);
                            Cmd.Parameters.AddWithValue("@AcademicsessionNotIn", "2016");
                            string SchoolId = data.SelectColumns(Cmd)[0];
                            if (string.IsNullOrEmpty(SchoolId))
                            {
                                ViewData["message"] = "Your Are Not Allowed To Take Decision on the Application,First Upload The Verification Letter!!!";
                                return View("message");
                            }
                        }
                    }


                    Qry = "update dgen.prematapplicationprocess set ApprovedDate=now(),ApprovedBy=@ApprovedBy,ApprovedIpAddress=@ApprovedIpAddress,ProcessStatusId=@ProcessStatusId where ApplicationNo=@ApplicationNo;";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", Values[i].ToString());
                    Cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.Approved);
                    Cmd.Parameters.AddWithValue("@ApprovedBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ApprovedIpAddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", Values[i].ToString());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", Values[i].ToString());
                    Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(Values[i].ToString(), (int)Status.TEHSREC, (int)CountList.Type001, DB.LS.ToString()));
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(Values[i].ToString(), (int)ApplicationHistoryMessage.MSG002, null, (int)ApplicationSource.Window, null));
                }
                data.SaveData(cmdList);

                // process for send message after successfully saving operation
                cmdList.Clear();
                for (int i = 0; i < Values.Length; i++)
                {
                    //send sms to applicant and insert record in table
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", Values[i].ToString());
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS003, smsDic));

                    //send email to applicant and insert record in table
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS003).ToString());
                    EmailDic.Add("ParamApplicationNo", Values[i].ToString());
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                }
                data.SaveData(cmdList);

                PreserveModelState(Constant._ActionMessage, "Selected application has been processed successfully.", false, true);
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.TEHSPEN).ToString() });
                return RedirectToAction("SCSTServiceWisePendingSummary", new { q = QueryString });
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PendingApplicationDecisionDetailsSCST", (DecisionModels)TempData[Constant._ModelStateParent]);

        }
        [Authorize(Roles = "103,104")]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult SCSTServiceWiseApproval(int sid)
        {
            GetData data = new GetData();
            string WhetherCondition = string.Empty;
            DecisionModels model = new DecisionModels();
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { WhetherCondition += " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { WhetherCondition += " and AD.applicationDistrictCode in (@ParamDistrictCode) "; }
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition += " and ( ADSC.DepartmentId in (@Code) or PSM.District in (@Code) or PSM.SubDivision in (@Code))"; }

            string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and whetherschoolrecomended=@WhetherSchoolRecomended then 1 end),0) as Recomended,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId1  and whetherschoolrecomended=@WhetherSchoolRecomended1 then 1 end),0) as NotRecomended  from dbo.ApplicationDetails AD  inner join (select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsfinancialassistance union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsprematssc union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsmeritscholarshipschool union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsbrambedkar union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsmeritprofessional union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsprematobc union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId from dgen.applicationdetailspostmatobc ) ADSC on AD.ApplicationNo=ADSC.ApplicationNo inner join dgen.prematschoolmaster PSM on PSM.SchoolId=ADSC.SchoolId left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode " + WhetherCondition + " and AD.ServiceCode in (@ParamServiceCode) and ADSC.SchoolId is not Null group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@ApplicationStatusId1", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended1", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@Code", Sessions.getEmployeeUser().AuthorizationId);
            model.data = data.GetDataTable(cmd);
            model.StatusId = sid.ToString();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "103,104")]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult SCSTSchoolWiseApproval(int ServiceCode)
        {
            GetData data = new GetData();
            string WhetherCondition = string.Empty;
            DecisionModels model = new DecisionModels();

            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { WhetherCondition += " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { WhetherCondition += " and AD.applicationDistrictCode in (@ParamDistrictCode) "; }
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition += " and ( ADSC.DepartmentId in (@Code) or PSM.District in (@Code) or PSM.SubDivision in (@Code))"; }

            string Qry = "select ADSC.SchoolID,SchoolName,SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and whetherschoolrecomended=@WhetherSchoolRecomended then 1 end),0) as Recomended,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId1  and whetherschoolrecomended=@WhetherSchoolRecomended1 then 1 end),0) as NotRecomended  from dbo.ApplicationDetails AD  inner join (select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsfinancialassistance union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsprematssc union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsmeritscholarshipschool union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsbrambedkar union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsmeritprofessional union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsprematobc union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId from dgen.applicationdetailspostmatobc ) ADSC on AD.ApplicationNo=ADSC.ApplicationNo inner join dgen.prematschoolmaster PSM on PSM.SchoolId=ADSC.SchoolId left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode  and AD.ServiceCode in (@ServiceCode) " + WhetherCondition + " group by ADSC.SchoolID,SchoolName,AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId1", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended1", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@Code", Sessions.getEmployeeUser().AuthorizationId);
            model.data = data.GetDataTable(cmd);

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "103,104")]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult SCSTApprovedAppList(int ServiceCode, int SchoolId)
        {
            string value = string.Empty;
            GetData data = new GetData();
            string Qry = string.Empty, WhetherCondition = string.Empty;
            DecisionModels model = new DecisionModels();
            model.ApplicationDetailsPrematsSC = new ApplicationDetailsPrematsSC();
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { WhetherCondition += " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { WhetherCondition += " and AD.applicationDistrictCode in (@ParamDistrictCode) "; }
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition += " and ( ADSC.DepartmentId in (@Code) or PSM.District in (@Code) or PSM.SubDivision in (@Code))"; }

            Qry += @"select ADSC.SchoolId,SchoolName, ADSC.DepartmentId,SMVD1.ValueName as Department, AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantMobileNo,ServiceName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as DOB,AD.ApplicationStatusId,coalesce(sum(Feeamount),0) as Recomended,to_char(AD.ApprovedDate,'DD/MM/YYYY') as ApprovedDate,SMVD.ValueName as Category  from dbo.ApplicationDetails AD inner join (select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId,CategoryId,null as CollegeName from dgen.applicationdetailsfinancialassistance union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId,CategoryId,null as CollegeName from dgen.applicationdetailsprematssc union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId,CategoryId,null as CollegeName from dgen.applicationdetailsmeritscholarshipschool union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId,CategoryId,null as CollegeName from dgen.applicationdetailsbrambedkar union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId,CategoryId,CollegeName from dgen.applicationdetailsmeritprofessional union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId,CategoryId,null as CollegeName from dgen.applicationdetailsprematobc union all select SchoolId,ApplicationNo,whetherschoolrecomended,DepartmentId,CategoryId,CollegeName from dgen.applicationdetailspostmatobc) ADSC on AD.ApplicationNo=ADSC.ApplicationNo inner join dgen.scstfeedetails  SCSTFD on SCSTFD.applicationNo=AD.ApplicationNo inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADSC.CategoryId left outer join dgen.prematschoolmaster PSM on PSM.SchoolId=ADSC.SchoolId left outer join SelectMasterValueDetails SMVD1 on SMVD1.ValueId=ADSC.DepartmentId  where AD.ServiceCode in (@ServiceCode) and AD.ApplicationStatusId=@ApplicationStatusId  and FeeinitiateBy=@FeeinitiateBy " + WhetherCondition + " group by AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,ApplicantAddress,AD.ApplicantDob,AD.ApplicationStatusId,Category,ApprovedDate,ADSC.SchoolId,CollegeName,SchoolName,ADSC.DepartmentId,SMVD1.ValueName  order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@SchoolId", SchoolId);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
            cmd.Parameters.AddWithValue("@Code", Sessions.getEmployeeUser().AuthorizationId);
            model.data = data.GetDataTable(cmd);

            model.ServiceCode = ServiceCode.ToString();
            if (model.data.Rows.Count > 0)
            {
                model.ApplicationDetailsPrematsSC.SchoolId = model.data.Rows[0]["SchoolId"].ToString();
                //model.ApplicationDetailsPrematsSC.DepartmentId = model.data.Rows[0]["DepartmentId"].ToString();
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SCSTPendingForSendSanction(DecisionModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string Message = string.Empty;
                string checkboxvalue = frm["chkboxData"];
                TempData[KeyName._Key05] = checkboxvalue;
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "ServiceCode", "SchoolId" }, new ArrayList() { Convert.ToInt32(model.ServiceCode), Convert.ToInt32(model.ApplicationDetailsPrematsSC.SchoolId) });
                return RedirectToAction("PrintSCSTApprovedApplication", "Print", new { q = QueryString });

                //if (TempData[KeyName._Key05] != null)
                //{
                //    checkboxvalue = TempData[KeyName._Key05].ToString();
                //}
                //TempData[KeyName._Key05] = checkboxvalue;
                //string[] Values = checkboxvalue.Split(',');
                //Int64 CalculateAmt = 0;
                //string Qry = "Select UserName,Designation from UserMaster where Userid=@Userid";
                //NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                //cmd.Parameters.AddWithValue("@Userid", Sessions.getEmployeeUser().UserId);
                //model.data = data.GetDataTable(cmd);

                //Qry = "Select ServiceName from ServiceMaster where ServiceCode=@ServiceCode";
                //cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                //cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                //model.data2 = data.GetDataTable(cmd);

                //for (int i = 0; i < Values.Length; i++)
                //{
                //    Qry = "select coalesce(sum(Feeamount),0) as Recomended from dgen.scstfeedetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                //    cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                //    cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                //    cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                //    model.data1 = data.GetDataTable(cmd);
                //    CalculateAmt += Convert.ToInt64(model.data1.Rows[0]["Recomended"].ToString());
                //}
                //model.ApplicationDetailsPrematsSC.CalculatedSanction = CalculateAmt.ToString();
                //model.ServiceCode = model.ServiceCode;
                //model.PNo = Convert.ToString(Values.Length);
                //return View(model);
            }
            string QueryString1 = Utility.CreateEncryptedQueyString(new ArrayList() { "ServiceCode", "SchoolId" }, new ArrayList() { Convert.ToInt32(model.ServiceCode), Convert.ToInt32(model.ApplicationDetailsPrematsSC.SchoolId) });
            return RedirectToAction("SCSTApprovedAppList", "Decision", new { q = QueryString1 });
        }
        [Authorize(Roles = "111")]
        [EncryptedActionParameter]
        public ActionResult SCSTPendingForSanction()
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.P111).ToString()) { return RedirectToAction("UnauthorizedRequest"); }
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }

            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            model.ApplicationDetailsPrematsSC = new ApplicationDetailsPrematsSC();
            string join = string.Empty, cond = string.Empty;
            string Qry = "select AD.ServiceCode,ServiceName,sum(case when ApplicationStatusId=@ApplicationStatusId and ProcessstatusId in (@SanctionProcessed,@SanctionIssued) then 1 else 0 end) as TotalApp,sum(case when ApplicationStatusId=@ApplicationStatusId  and ProcessstatusId=@SanctionProcessed then 1 else 0 end) as PendingApp,sum(case when ApplicationStatusId=@ApplicationStatusId and ProcessstatusId=@SanctionIssued then 1 else 0 end) as SantionedProcessedApp from applicationdetails AD inner join dgen.PrematApplicationProcess  PAP on PAP.ApplicationNo=AD.ApplicationNo inner join (select SchoolId,ApplicationNo,DepartmentId from dgen.applicationdetailsfinancialassistance union all select SchoolId,ApplicationNo,DepartmentId from dgen.applicationdetailsprematssc union all select SchoolId,ApplicationNo,DepartmentId from dgen.applicationdetailsmeritscholarshipschool union all select SchoolId,ApplicationNo,DepartmentId from  dgen.applicationdetailsbrambedkar union all select SchoolId,ApplicationNo,DepartmentId from  dgen.applicationdetailsmeritprofessional union all select SchoolId,ApplicationNo,DepartmentId from dgen.applicationdetailsprematobc union all select SchoolId,ApplicationNo,DepartmentId from dgen.applicationdetailspostmatobc ) SCD on AD.ApplicationNo=SCD.ApplicationNo inner join ServiceMaster Sm on SM.ServiceCode=AD.ServiceCode inner join SelectMasterValueDetails SMVD on SMVD.ValueId=PAP.ProcessstatusId left outer join dgen.prematschoolmaster PSM on PSM.SchoolId = SCD.SchoolId  left outer join dgen.prematdistrictmaster PDM on PDM.DistrictId = PSM.District left outer join dgen.prematzonemaster PZM on PZM.ZoneId = PSM.SubDivision where AD.ServiceCode in (@ParamServiceCode) group by ServiceName,AD.ServiceCode order by ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@SanctionProcessed", (int)ValueId.SanctionProcessed);
            cmd.Parameters.AddWithValue("@SanctionIssued", (int)ValueId.SanctionIssued);
            model.data = data.GetDataTable(cmd);
            model.SCSTDepartmentId = ((int)CountList.Type000).ToString();
            model.SCSTDistrictId = ((int)CountList.Type000).ToString();
            model.SCSTZoneId = ((int)CountList.Type000).ToString();
            model.SchoolId = ((int)CountList.Type000).ToString();
            model.CategoryId = ((int)CountList.Type000).ToString();
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult SCSTPendingForSanction(DecisionModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string WhetherCondition = string.Empty;

                string Qry = "select AD.ServiceCode,ServiceName,sum(case when ApplicationStatusId=@ApplicationStatusId and ProcessstatusId in (@SanctionProcessed,@SanctionIssued) then 1 else 0 end) as TotalApp,sum(case when ApplicationStatusId=@ApplicationStatusId  and ProcessstatusId=@SanctionProcessed then 1 else 0 end) as PendingApp,sum(case when ApplicationStatusId=@ApplicationStatusId and ProcessstatusId=@SanctionIssued then 1 else 0 end) as SantionedProcessedApp from applicationdetails AD inner join dgen.PrematApplicationProcess  PAP on PAP.ApplicationNo=AD.ApplicationNo inner join (select SchoolId,ApplicationNo,DepartmentId,CategoryId from dgen.applicationdetailsfinancialassistance union all select SchoolId,ApplicationNo,DepartmentId,CategoryId from dgen.applicationdetailsprematssc union all select SchoolId,ApplicationNo,DepartmentId,CategoryId from dgen.applicationdetailsmeritscholarshipschool union all select SchoolId,ApplicationNo,DepartmentId,CategoryId from  dgen.applicationdetailsbrambedkar union all select SchoolId,ApplicationNo,DepartmentId,CategoryId from  dgen.applicationdetailsmeritprofessional union all select SchoolId,ApplicationNo,DepartmentId,CategoryId from dgen.applicationdetailsprematobc union all select SchoolId,ApplicationNo,DepartmentId,CategoryId from dgen.applicationdetailspostmatobc ) SCD on AD.ApplicationNo=SCD.ApplicationNo inner join ServiceMaster Sm on SM.ServiceCode=AD.ServiceCode inner join SelectMasterValueDetails SMVD on SMVD.ValueId=PAP.ProcessstatusId left outer join dgen.prematschoolmaster PSM on PSM.SchoolId = SCD.SchoolId  left outer join dgen.prematdistrictmaster PDM on PDM.DistrictId = PSM.District left outer join dgen.prematzonemaster PZM on PZM.ZoneId = PSM.SubDivision where AD.ServiceCode in (@ParamServiceCode) ";
                if (!string.IsNullOrEmpty(model.SCSTDepartmentId)) { Qry += " and SCD.DepartmentId = @SCSTDepartmentId "; }
                if (!string.IsNullOrEmpty(model.SCSTDistrictId)) { Qry += " and PSM.District = @SCSTDistrictId "; }
                if (!string.IsNullOrEmpty(model.SCSTZoneId)) { Qry += " and PSM.SubDivision = @SCSTZoneId "; }
                if (!string.IsNullOrEmpty(model.SchoolId)) { Qry += " and SCD.SchoolId = @SchoolId "; }
                if (!string.IsNullOrEmpty(model.CategoryId)) { Qry += " and SCD.CategoryId = @CategoryId "; }
                Qry += " group by ServiceName,AD.ServiceCode order by ServiceName ";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
                cmd.Parameters.AddWithValue("@SanctionProcessed", (int)ValueId.SanctionProcessed);
                cmd.Parameters.AddWithValue("@SanctionIssued", (int)ValueId.SanctionIssued);
                cmd.Parameters.AddWithValue("@SCSTDepartmentId", model.SCSTDepartmentId);
                cmd.Parameters.AddWithValue("@SCSTDistrictId", model.SCSTDistrictId);
                cmd.Parameters.AddWithValue("@SCSTZoneId", model.SCSTZoneId);
                cmd.Parameters.AddWithValue("@SchoolId", model.SchoolId);
                cmd.Parameters.AddWithValue("@CategoryId", model.CategoryId);
                model.data = data.GetDataTable(cmd);

                if (string.IsNullOrEmpty(model.SCSTDepartmentId)) { model.SCSTDepartmentId = ((int)CountList.Type000).ToString(); }
                if (string.IsNullOrEmpty(model.SCSTDistrictId)) { model.SCSTDistrictId = ((int)CountList.Type000).ToString(); }
                if (string.IsNullOrEmpty(model.SCSTZoneId)) { model.SCSTZoneId = ((int)CountList.Type000).ToString(); }
                if (string.IsNullOrEmpty(model.SchoolId)) { model.SchoolId = ((int)CountList.Type000).ToString(); }
                if (string.IsNullOrEmpty(model.CategoryId)) { model.CategoryId = ((int)CountList.Type000).ToString(); }
                model.data = data.GetDataTable(cmd);
            }
            return View("SCSTPendingForSanction", model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult SCSTPendingForSanctionList(int ServiceCode, int Type, int? DepartmentId = 0, int? DistrictId = 0, int? ZoneId = 0, int? SchoolId = 0, int? CategoryId = 0)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            string Whethercondition = string.Empty;

            string Qry = @"select  AD.ApplicationNo,ApplicantName,to_char(ApplicantDob,'DD/MM/YYYY') as ApplicantDob,ApplicantGender,AD.ServiceCode,ServiceName,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,SchoolName, SCD .DepartmentId,SMVD1.ValueName as Department,to_char(AD.ApplicantDob,'DD/MM/YYYY') as DOB,AD.ApplicationStatusId,coalesce(sum(Feeamount),0) as Recomended,to_char(AD.ApprovedDate,'DD/MM/YYYY') as ApprovedDate,SMVD.ValueName as Category  from applicationdetails AD inner join dgen.PrematApplicationProcess  PAP on PAP.ApplicationNo=AD.ApplicationNo inner join (select SchoolId,ApplicationNo,DepartmentId,CategoryId from dgen.applicationdetailsfinancialassistance union all select SchoolId,ApplicationNo,DepartmentId,CategoryId from dgen.applicationdetailsprematssc union all select SchoolId,ApplicationNo,DepartmentId,CategoryId from dgen.applicationdetailsmeritscholarshipschool union all select SchoolId,ApplicationNo,DepartmentId,CategoryId from  dgen.applicationdetailsbrambedkar union all select SchoolId,ApplicationNo,DepartmentId,CategoryId from  dgen.applicationdetailsmeritprofessional union all select SchoolId,ApplicationNo,DepartmentId,CategoryId from dgen.applicationdetailsprematobc union all select SchoolId,ApplicationNo,DepartmentId,CategoryId from dgen.applicationdetailspostmatobc ) SCD on AD.ApplicationNo=SCD.ApplicationNo inner join dgen.scstfeedetails  SCSTFD on SCSTFD.applicationNo=AD.ApplicationNo inner join ServiceMaster Sm on SM.ServiceCode=AD.ServiceCode  inner join SelectMasterValueDetails SMVVD on SMVVD.ValueId=PAP.ProcessstatusId inner join SelectMasterValueDetails SMVD on SMVD.ValueId = SCD.CategoryId left outer join SelectMasterValueDetails SMVD1 on SMVD1.ValueId = SCD.DepartmentId left outer join dgen.prematschoolmaster PSM on PSM.SchoolId = SCD.SchoolId left outer join dgen.prematdistrictmaster PDM on PDM.DistrictId = PSM.District   left outer join dgen.prematzonemaster PZM on PZM.ZoneId = PSM.SubDivision where AD.ServiceCode in (@ServiceCode) and ApplicATionStatusId=@ApplicationStatusId and FeeinitiateBy=@FeeinitiateBy ";
            if (DepartmentId != (int)CountList.Type000) { Qry += "and SCD.DepartmentId = @DepartmentId "; }
            if (DistrictId != (int)CountList.Type000) { Qry += " and PSM.District = @DistrictId "; }
            if (ZoneId != (int)CountList.Type000) { Qry += " and PSM.SubDivision = @ZoneId "; }
            if (SchoolId != (int)CountList.Type000) { Qry += " and SCD.SchoolId = @SchoolId"; }
            if (CategoryId != (int)CountList.Type000) { Qry += " and SCD.CategoryId = @CategoryId"; }

            if (Type == (int)CountList.Type000) { Qry += " and ProcessstatusId=@SanctionProcessed "; }
            if (Type == (int)CountList.Type001) { Qry += " and ProcessstatusId=@SanctionIssued "; }

            Qry += " group by  AD.ApplicationNo,ApplicantName, ApplicantDob,ApplicantGender,AD.ServiceCode,ServiceName,ApplicationDate,SchoolName, SCD.DepartmentId,SMVD1.ValueName,AD.ApplicantDob,AD.ApplicationStatusId,SMVD.ValueName";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@DepartmentId", DepartmentId);
            cmd.Parameters.AddWithValue("@DistrictId", DistrictId);
            cmd.Parameters.AddWithValue("@ZoneId", ZoneId);
            cmd.Parameters.AddWithValue("@SchoolId", SchoolId);
            cmd.Parameters.AddWithValue("@CategoryId", CategoryId);
            cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@SanctionProcessed", (int)ValueId.SanctionProcessed);
            cmd.Parameters.AddWithValue("@SanctionIssued", (int)ValueId.SanctionIssued);
            model.data = data.GetDataTable(cmd);

            model.ServiceCode = ServiceCode.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SavePendingSanction(DecisionModels model, FormCollection frm)
        {

            GetData data = new GetData();

            if (ModelState.IsValid)
            {
                ArrayList ValuesDate = new ArrayList();
                List<CMDInfoList> cmdList = new List<CMDInfoList>();
                List<NpgsqlCommand> cmdList2 = new List<NpgsqlCommand>();
                CMDInfoList CmdInfo = new CMDInfoList();
                string Message = string.Empty;
                Int64 CalculateAmt = 0;
                string checkboxvalue = frm["chkboxData"];
                if (TempData[KeyName._Key05] != null)
                {
                    checkboxvalue = TempData[KeyName._Key05].ToString();
                }
                TempData[KeyName._Key05] = checkboxvalue;
                string[] Values = checkboxvalue.Split(',');

                string Qry = "select date_part('year', now()) as CYear, date_part('month', now()) as Cmonth ";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                model.data = data.GetDataTable(cmd);

                Qry = "Delete from tempsanctionpaymentdetails where UserId=@UserId; ";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                cmdList2.Add(cmd);


                Qry = "Delete from tempsanctionapplicationdetails where UserId=@UserId";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                cmdList2.Add(cmd);
                data.SaveData(cmdList2);

                for (int i = 0; i < Values.Length; i++)
                {
                    Qry = "select coalesce(sum(Feeamount),0) as Recomended from dgen.scstfeedetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                    cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                    cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                    model.data1 = data.GetDataTable(cmd);
                    CalculateAmt += Convert.ToInt64(model.data1.Rows[0]["Recomended"].ToString());
                }

                Qry = "insert into tempsanctionpaymentdetails(sanctiondate,sanctionamount,servicecode,sanctionyear,sanctionmonth,UserId,IpAddress,lastactiondate) values(now(),@sanctionamount,@servicecode,@sanctionyear,@sanctionmonth,@UserId,@IpAddress,now()); SELECT currval(pg_get_serial_sequence('tempsanctionpaymentdetails','tempsanctionid'))";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@sanctionamount", CalculateAmt);
                cmd.Parameters.AddWithValue("@servicecode", model.ServiceCode);
                cmd.Parameters.AddWithValue("@sanctionyear", model.data.Rows[0]["CYear"].ToString());
                cmd.Parameters.AddWithValue("@sanctionmonth", model.data.Rows[0]["Cmonth"].ToString());
                cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                CmdInfo = new CMDInfoList();
                CmdInfo.Cmd = cmd; CmdInfo.ParamenterIndex = null; CmdInfo.Returns = true;
                cmdList.Add(CmdInfo);

                for (int i = 0; i < Values.Length; i++)
                {
                    Dictionary<string, string> ValidateData = new Dictionary<string, string>();
                    ValidateData.Add("ApplicationNo", (Values[i]).ToString());

                    string DisplayMessage = Utility.WhetherAccessAllowed(ValidateData, new int[] { (int)ValueId.AuthDigital, (int)ValueId.AutheKYC }, new int[] { (int)ValueId.SignEsign, (int)ValueId.SignDigital }, new int[] { (int)Status.TEHSREC }, false, false, false);
                    if (!string.IsNullOrEmpty(DisplayMessage))
                    {
                        PreserveModelState(Constant._ActionMessage, DisplayMessage, false, true);
                        return RedirectToAction("SCSTPendingForSanction", "Decision");
                    }

                    Qry = "select ApplicationNo,coalesce(sum(Feeamount),0) as Recomended from dgen.scstfeedetails  where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy group by ApplicationNo";
                    cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                    cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                    model.data1 = data.GetDataTable(cmd);

                    Qry = "insert into tempsanctionapplicationdetails(sanctionid,applicationno,sanctionamount,SanctionRemarks,UserId,IpAddress,lastactiondate) values(@Parameter0,@applicationno,@sanctionamount,@SanctionRemarks,@UserId,@IpAddress,now())";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@applicationno", (Values[i]).ToString());
                    cmd.Parameters.AddWithValue("@sanctionamount", model.data1.Rows[0]["Recomended"].ToString());
                    cmd.Parameters.AddWithValue("@SanctionRemarks", model.SchollRemarks);
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    CmdInfo = new CMDInfoList();
                    CmdInfo.Cmd = cmd; CmdInfo.ParamenterIndex = new int[] { 0 }; CmdInfo.Returns = false;
                    cmdList.Add(CmdInfo);

                    //string Qry = "Update dgen.prematapplicationprocess set SanctionedDate=now(),SanctionedBy=@SanctionedBy,SanctionedipAddress=@SanctionedipAddress,SanctionRemarks=@SanctionRemarks,processstatusid=@processstatusid where ApplicationNo=@ApplicationNo";
                    //NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    //cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                    //cmd.Parameters.AddWithValue("@SanctionedBy", Sessions.getEmployeeUser().UserId);
                    //cmd.Parameters.AddWithValue("@SanctionedipAddress", Utility.GetIP4Address());
                    //cmd.Parameters.AddWithValue("@SanctionRemarks", model.SchollRemarks);
                    //cmd.Parameters.AddWithValue("@processstatusid", (int)ValueId.SanctionIssued);
                    //cmdList.Add(cmd);

                    //Qry = "Update applicationdetails set ApplicationStatusId=@ApplicationStatusId,userid=@userid,ipaddress=@ipaddress,lastactiondate=now()   where ApplicationNo=@ApplicationNo";
                    //cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    //cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                    //cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                    //cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    //cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    //cmdList.Add(cmd);

                    //Qry = "Update web.applicationdetails set ApplicationStatusId=@ApplicationStatusId,userid=@userid,ipaddress=@ipaddress,actiondatetime=now()  where ApplicationNo=@ApplicationNo";
                    //cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    //cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                    //cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                    //cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    //cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    //cmdList.Add(cmd);

                }
                if (cmdList.Count > 0)
                {
                    Int64 AppNo = Convert.ToInt64(data.SaveTransactionalDataCustom(cmdList)[1].ToString());

                    DecisionModels model1 = new DecisionModels();
                    byte[] PdfBuffer = null;

                    Qry = @"select case when SCD.SchoolId is null then '0' else SCD.SchoolId end as SchoolId,case when SCD.SchoolId is null then 'Out Side Delhi' else PSM.SchoolName end as SchoolName  ,case when SCD.SchoolId is null then 'Out Side Delhi' else PSM.SchoolAddress end as SchoolAddress ,beneficiarycode as BeneficiaryCode,AD.applicationNo, case when SUD.ApplicantName is null then  AD.ApplicantName else SUD.ApplicantName end as BeneficiaryName,ServiceName,SMVVDD.ValueName as Category ,SMVDD.ValueName as PClass,coalesce(sum(Feeamount),0) as SanctionPaymentAmount,'01/04/2016' as PaymentFromDate,'31/03/2017' as PaymentToDate from applicationdetails AD inner join dgen.PrematApplicationProcess  PAP on PAP.ApplicationNo=AD.ApplicationNo inner join (select SchoolId,ApplicationNo,DepartmentId,AccountNo,Ifsccode,bankcode,CategoryId,PresentClass from dgen.applicationdetailsfinancialassistance union all select SchoolId,ApplicationNo,DepartmentId,AccountNo,Ifsccode,bankcode,CategoryId,PresentClass from dgen.applicationdetailsprematssc union all select SchoolId,ApplicationNo,DepartmentId,AccountNo,Ifsccode,bankcode,CategoryId,PresentClass from dgen.applicationdetailsmeritscholarshipschool union all select SchoolId,ApplicationNo,DepartmentId,AccountNo,Ifsccode,bankcode,CategoryId,PresentClass from  dgen.applicationdetailsbrambedkar union all select SchoolId,ApplicationNo,DepartmentId,AccountNo,Ifsccode,bankcode,CategoryId,PresentClass from  dgen.applicationdetailsmeritprofessional union all select SchoolId,ApplicationNo,DepartmentId,AccountNo,Ifsccode,bankcode,CategoryId,PresentClass from dgen.applicationdetailsprematobc union all select SchoolId,ApplicationNo,DepartmentId,AccountNo,Ifsccode,bankcode,CategoryId,PresentClass from dgen.applicationdetailspostmatobc ) SCD on AD.ApplicationNo=SCD.ApplicationNo inner join tempsanctionapplicationdetails TSPD on TSPD.ApplicationNo = AD.ApplicationNo inner join dgen.scstfeedetails SCSTFD on SCSTFD.applicationNo = AD.ApplicationNo inner join ServiceMaster Sm on SM.ServiceCode = AD.ServiceCode inner join DistrictMaster DM on DM.DistrictCode = AD.ApplicationDistrictCode inner join StateMaster STM on STM.StateId = AD.StateId inner join BankMaster BM on BM.BankCode = SCD.BankCode  inner join SelectMasterValueDetails SMVVD on SMVVD.ValueId = PAP.ProcessstatusId inner join SelectMasterValueDetails SMVVDD on SMVVDD.ValueId = SCD.CategoryId inner join SelectMasterValueDetails SMVDD on SMVDD.ValueId = SCD.PresentClass left outer join dgen.prematschoolmaster PSM on PSM.SchoolId = SCD.SchoolId left outer join dgen.prematdistrictmaster PDM on PDM.DistrictId = PSM.District left outer join SelectMasterValueDetails SMVD1 on SMVD1.ValueId = SCD.DepartmentId left outer join dgen.scstupdatedapplicationdetail SUD on SUD.ApplicationNo = AD.ApplicationNo left outer join dgen.prematzonemaster PZM on PZM.ZoneId = PSM.SubDivision where ApplicationStatusId = @ApplicationStatusId and FeeinitiateBy = @FeeinitiateBy and ProcessstatusId = @ProcessstatusId and TSPD.SanctionId = @SanctionId group by  beneficiarycode, SUD.ApplicantName,AD.ApplicantName,AD.ApplicationNo,ServiceName,PSM.SchoolName,PSM.SchoolAddress,SCD.SchoolId,SMVVDD.ValueName,SMVDD.ValueName order by PSM.SchoolName,AD.ApplicationNo,SMVDD.ValueName ";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@SanctionId", AppNo);
                    Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
                    Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                    Cmd.Parameters.AddWithValue("@ProcessstatusId", (int)ValueId.SanctionProcessed);
                    model1.data2 = data.GetDataTable(Cmd);
                    if (model1.data2 != null)
                    {
                        PdfBufferGenerator objBuffer = new PdfBufferGenerator();
                        PdfBuffer = objBuffer.GetPdfBuffer(this, string.Empty, "PrintPrematSanctionCertificate", model1);
                    }

                    if (model1.data2 != null)
                    {
                        List<NpgsqlCommand> cmdList1 = new List<NpgsqlCommand>();
                        Qry = "update tempsanctionpaymentdetails set documentdata=@documentdata,ContentType=@ContentType where tempSanctionId=@SanctionId; ";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@SanctionId", AppNo);
                        Cmd.Parameters.AddWithValue("@documentdata", PdfBuffer);
                        Cmd.Parameters.AddWithValue("@ContentType", "application/pdf");
                        cmdList1.Add(Cmd);
                        data.SaveData(cmdList1);
                    }

                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "SanctionNo" }, new ArrayList() { Convert.ToInt32(AppNo) });
                    return RedirectToAction("InitializeDocumentSign", "Sign", new { q = QueryString });
                }
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("SCSTPendingForSanctionList", (DecisionModels)TempData[Constant._ModelStateParent]);

        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult PrematUpdateScholarshipDetails(Int64 AppNo, int ServiceCode)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            model.ApplicationNo = AppNo.ToString();
            model.ServiceCode = ServiceCode.ToString();
            string Qry = string.Empty, cond = string.Empty;
            NpgsqlCommand Cmd = new NpgsqlCommand();

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationNo, DB.LS.ToString());

            Qry = "select ApplicantName,to_char(ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB, Case When ApplicantGender='M' Then 'Male' When ApplicantGender='F' Then 'Female' When ApplicantGender='T' Then 'Transgender' end as ApplicantGender from dgen.scstupdatedapplicationdetail where ApplicationNo=@ApplicationNo";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            model.data1 = data.GetDataTable(Cmd);

            if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.MeritscholarshipProfessional)
            {
                model.ApplicationDetailsMeritProfessional = Utility.GetMeritscholarshipProfessionalDetails(model.ApplicationNo, DB.LS.ToString());
                model.ApplicationDetailsMeritProfessional.ScStFeeDetails = new List<ScStFeeDetails>();
                DataTable Dt1 = Utility.GetSCSTScholorship(model.ApplicationNo, null, null);
                for (int i = 0; i < Dt1.Rows.Count; i++)
                {
                    model.ApplicationDetailsMeritProfessional.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
                }
            }
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.PostmatricScholarshipOBC)
            {
                model.ApplicationDetailsPostmatOBC = Utility.GetPostmatOBCDetails(model.ApplicationNo, DB.LS.ToString());
                model.ApplicationDetailsPostmatOBC.ScStFeeDetails = new List<ScStFeeDetails>();
                DataTable Dt1 = Utility.GetSCSTScholorship(model.ApplicationNo, null, null);
                for (int i = 0; i < Dt1.Rows.Count; i++)
                {
                    model.ApplicationDetailsPostmatOBC.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
                }
            }
            //Changes20180613
            else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.PostmatricSC)
            {
                model.ApplicationDetailsPostmatSCssd = Utility.GetPostmatSCSSDDetails(model.ApplicationNo, DB.LS.ToString());
                model.ApplicationDetailsPostmatSCssd.ScStFeeDetails = new List<ScStFeeDetails>();
                DataTable Dt1 = Utility.GetSCSTScholorship(model.ApplicationNo, null, null);
                for (int i = 0; i < Dt1.Rows.Count; i++)
                {
                    model.ApplicationDetailsPostmatSCssd.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
                }
            }

            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PrematUpdateScholarshipDetails(DecisionModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Qry = string.Empty, ApplicationStatusId = string.Empty, DisAmount = string.Empty;


                if (model.ServiceCode == ((int)ServiceList.MeritscholarshipProfessional).ToString())
                {
                    string whetherCon = string.Empty;
                    // coide for check fee from database ----commented on 11/07/2017 requested from department
                    foreach (ScStFeeDetails Head in model.ApplicationDetailsMeritProfessional.ScStFeeDetails)
                    {
                        DisAmount = Head.FeeAmount;
                    }
                    model.data1 = Utility.GetSCSTScholorship(model.ApplicationNo, null, model.ApplicationDetailsMeritProfessional.GroupId);
                    if (Convert.ToInt32(model.data1.Rows[0]["FeeAmount"].ToString()) < Convert.ToInt32(DisAmount))
                    {
                        ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View("PrematUpdateScholarshipDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
                    }

                    Qry = "Delete from dgen.ScStFeeDetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                    cmdList.Add(Cmd);

                    foreach (ScStFeeDetails Head in model.ApplicationDetailsMeritProfessional.ScStFeeDetails)
                    {
                        Qry = "insert into dgen.ScStFeeDetails(ApplicationNo,FeeinitiateBy,FeeTypeBy,FeeAmount,UserId,IpAddress,LastActionDate) values (@ApplicationNo,@FeeinitiateBy,@FeeTypeBy,@FeeAmount,@UserId,@IpAddress,now())";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                        Cmd.Parameters.AddWithValue("@FeeTypeBy", Head.FeeTypeId);
                        Cmd.Parameters.AddWithValue("@FeeAmount", Head.FeeAmount);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }

                    Qry = "update dgen.applicationdetailsmeritprofessional set WhetherVerified=@WhetherVerified,GroupId=@GroupId,VerifiedDate=now(),SchollRemarks=@SchollRemarks,SchollRemarksBy=@SchollRemarksBy,SchollRemarksIpAddress=@SchollRemarksIpAddress,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@GroupId", model.ApplicationDetailsMeritProfessional.GroupId);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@SchollRemarks", model.ApplicationDetailsMeritProfessional.SchollRemarks);
                    Cmd.Parameters.AddWithValue("@SchollRemarksBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@SchollRemarksIpAddress", Utility.GetIP4Address());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG058, model.ApplicationDetailsMeritProfessional.SchollRemarks, (int)ApplicationSource.Window, null));
                }
                else if (model.ServiceCode == ((int)ServiceList.PostmatricScholarshipOBC).ToString())
                {
                    string whetherCon = string.Empty;
                    Int64 DisburseAmount = 0, FillAmount = 0;
                    //// coide for check fee from database ----commented on 13/04/2017 from department
                    //foreach (ScStFeeDetails Head in model.ApplicationDetailsPostmatOBC.ScStFeeDetails)
                    //{
                    //    DisAmount = Head.FeeAmount;
                    //}
                    //model.data1 = Utility.GetSCSTScholorship(model.ApplicationNo, null, model.ApplicationDetailsPostmatOBC.GroupId);
                    //if (Convert.ToInt32(model.data1.Rows[0]["FeeAmount"].ToString()) < Convert.ToInt32(DisAmount))
                    //{
                    //    ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                    //    PreserveModelState(Constant._ModelStateParent, null, true, false);
                    //    return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                    //}


                    string WhetherHostler = Utility.SelectColumnsValue("dgen.applicationdetailspostmatobc", "WhetherHostler", "ApplicationNo", model.ApplicationNo)[0];
                    foreach (ScStFeeDetails Head in model.ApplicationDetailsPostmatOBC.ScStFeeDetails)
                    {
                        DisburseAmount = DisburseAmount + Convert.ToInt64(Head.FeeAmount);
                    }

                    if (WhetherHostler.ToUpper() == CustomText.TRUE.ToString() && DisburseAmount > 30000)
                    {
                        ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View("PrematUpdateScholarshipDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
                    }
                    if (WhetherHostler.ToUpper() == CustomText.FALSE.ToString() && DisburseAmount > 25000)
                    {
                        ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View("PrematUpdateScholarshipDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
                    }


                    Qry = "Select FeeAmount from dgen.ScStFeeDetails Where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Applicant);
                    DataTable dt = data.GetDataTable(Cmd);
                    if (dt != null)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            FillAmount = FillAmount + Convert.ToInt64(dt.Rows[i]["FeeAmount"].ToString());
                        }
                    }

                    model.data1 = Utility.GetSCSTScholorship(model.ApplicationNo, null, model.ApplicationDetailsPostmatOBC.GroupId);
                    if (model.data1 != null)
                    {
                        for (int i = 0; i < model.data1.Rows.Count; i++)
                        {
                            FillAmount = FillAmount + Convert.ToInt64(model.data1.Rows[i]["FeeAmount"].ToString());
                        }
                    }
                    Dictionary<string, string> Data = new Dictionary<string, string>();
                    Data.Add("DisAmount", DisburseAmount.ToString());
                    Data.Add("FillAmount", FillAmount.ToString());
                    bool chececkresult = Utility.CheckEligibilitySCSTService(Data, model.ServiceCode, (int)CountList.Type001);
                    if (chececkresult == false)
                    {
                        ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View("PrematUpdateScholarshipDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
                    }


                    Qry = "Delete from dgen.ScStFeeDetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                    cmdList.Add(Cmd);

                    foreach (ScStFeeDetails Head in model.ApplicationDetailsPostmatOBC.ScStFeeDetails)
                    {
                        Qry = "insert into dgen.ScStFeeDetails(ApplicationNo,FeeinitiateBy,FeeTypeBy,FeeAmount,UserId,IpAddress,LastActionDate) values (@ApplicationNo,@FeeinitiateBy,@FeeTypeBy,@FeeAmount,@UserId,@IpAddress,now())";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                        Cmd.Parameters.AddWithValue("@FeeTypeBy", Head.FeeTypeId);
                        Cmd.Parameters.AddWithValue("@FeeAmount", Head.FeeAmount);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                    Qry = "update dgen.applicationdetailspostmatobc set WhetherVerified=@WhetherVerified,GroupId=@GroupId,VerifiedDate=now(),SchollRemarks=@SchollRemarks,SchollRemarksBy=@SchollRemarksBy,SchollRemarksIpAddress=@SchollRemarksIpAddress,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@GroupId", model.ApplicationDetailsPostmatOBC.GroupId);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@SchollRemarks", model.ApplicationDetailsPostmatOBC.SchollRemarks);
                    Cmd.Parameters.AddWithValue("@SchollRemarksBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@SchollRemarksIpAddress", Utility.GetIP4Address());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG058, model.ApplicationDetailsPostmatOBC.SchollRemarks, (int)ApplicationSource.Window, null));
                }

                else if (model.ServiceCode == ((int)ServiceList.PostmatricSC).ToString())
                {
                    string whetherCon = string.Empty;
                    Int64 FillAmount = 0, DisburseAmount = 0;

                    Qry = "Select FeeAmount from dgen.ScStFeeDetails Where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Applicant);
                    DataTable dt = data.GetDataTable(Cmd);
                    if (dt != null)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            FillAmount = FillAmount + Convert.ToInt64(dt.Rows[i]["FeeAmount"].ToString());
                        }
                    }
                    foreach (ScStFeeDetails Head in model.ApplicationDetailsPostmatSCssd.ScStFeeDetails)
                    {
                        DisburseAmount = DisburseAmount + Convert.ToInt64(Head.FeeAmount);
                    }
                    model.data1 = Utility.GetSCSTScholorship(model.ApplicationNo, null, model.ApplicationDetailsPostmatSCssd.GroupId);
                    if (model.data1 != null)
                    {
                        for (int i = 0; i < model.data1.Rows.Count; i++)
                        {
                            FillAmount = FillAmount + Convert.ToInt64(model.data1.Rows[i]["FeeAmount"].ToString());
                        }
                    }
                    Dictionary<string, string> Data = new Dictionary<string, string>();
                    Data.Add("DisAmount", DisburseAmount.ToString());
                    Data.Add("FillAmount", FillAmount.ToString());
                    bool chececkresult = Utility.CheckEligibilitySCSTService(Data, model.ServiceCode, (int)CountList.Type001);
                    if (chececkresult == false)
                    {
                        ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View("PrematUpdateScholarshipDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
                    }


                    Qry = "Delete from dgen.ScStFeeDetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                    cmdList.Add(Cmd);

                    foreach (ScStFeeDetails Head in model.ApplicationDetailsPostmatSCssd.ScStFeeDetails)
                    {
                        Qry = "insert into dgen.ScStFeeDetails(ApplicationNo,FeeinitiateBy,FeeTypeBy,FeeAmount,UserId,IpAddress,LastActionDate) values (@ApplicationNo,@FeeinitiateBy,@FeeTypeBy,@FeeAmount,@UserId,@IpAddress,now())";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                        Cmd.Parameters.AddWithValue("@FeeTypeBy", Head.FeeTypeId);
                        Cmd.Parameters.AddWithValue("@FeeAmount", Head.FeeAmount);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                    Qry = "update dgen.ApplicationDetailsPostmatSCssd set WhetherVerified=@WhetherVerified,GroupId=@GroupId,VerifiedDate=now(),SchollRemarks=@SchollRemarks,SchollRemarksBy=@SchollRemarksBy,SchollRemarksIpAddress=@SchollRemarksIpAddress,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@GroupId", model.ApplicationDetailsPostmatSCssd.GroupId);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@SchollRemarks", model.ApplicationDetailsPostmatSCssd.SchollRemarks);
                    Cmd.Parameters.AddWithValue("@SchollRemarksBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@SchollRemarksIpAddress", Utility.GetIP4Address());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG058, model.ApplicationDetailsPostmatSCssd.SchollRemarks, (int)ApplicationSource.Window, null));
                }

                data.SaveData(cmdList);

                ViewData["message"] = "Application [" + model.ApplicationNo + "] has been processed successfully.";
                return View("message");
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PrematUpdateScholarshipDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
        }
        #endregion

        #region decision methods for SocialWelfare and WCD Department
        [Authorize(Roles = "103")]
        [EncryptedActionParameter]
        public ActionResult PendingDecsionSummarySW(int sid)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();

            //string WhetherCondition = string.Empty;
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition = " and AD.OfficeCode in (@ParamAuthorizationId)  and AD.AcceptedBy in (@AcceptedBy)"; }
            //else { WhetherCondition = " and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.OfficeCode=@OfficeCode  and AD.AcceptedBy in (@AcceptedBy)"; }

            string addScript = Utility.GetScriptForAuthorizationProcess();

            //string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@ApplicationSourceId then 1 end),0) as atCSC,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as atOnline from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode " + WhetherCondition + " and AD.ServiceCode in (@ParamServiceCode) group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@ApplicationSourceId then 1 end),0) as atCSC,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as atOnline from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) and AD.AcceptedBy in (@AcceptedBy) " + addScript + " group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@ApplicationSourceId", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            model.data = data.GetDataTable(cmd);
            model.StatusId = sid.ToString();

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "103")]
        [EncryptedActionParameter]
        //public ActionResult PendingDecsionListSW(int subDiv, int service, int status, string Value, int? SourceId)
        public ActionResult PendingDecsionListSW(int service, int status, int? SourceId)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();

            //string value = string.Empty;
            //if (SourceId != null) { value += " and ApplicationSourceId=@ApplicationSourceId"; }
            //string WhetherCondition = string.Empty;
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition = " and AD.OfficeCode in (@ParamAuthorizationId)  and AD.AcceptedBy in (@AcceptedBy)"; }
            //else { WhetherCondition = " and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.OfficeCode=@OfficeCode  and AD.AcceptedBy in (@AcceptedBy)"; }

            string addScript = Utility.GetScriptForAuthorizationProcess();
            if (SourceId != null) { addScript += " and AD.ApplicationSourceId=@ApplicationSourceId"; }

            //string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where DM.deptcode=@ParamDeptCode and AD.ServiceCode=@ServiceCode " + WhetherCondition + " and AD.ApplicationStatusId=@ApplicationStatusId " + value + " order by AD.applicationdate";
            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where DM.deptcode=@ParamDeptCode and AD.AcceptedBy in (@AcceptedBy) and AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId " + addScript + " order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            //cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", status);
            if (SourceId != null) { cmd.Parameters.AddWithValue("@ApplicationSourceId", SourceId); }
            cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [Authorize(Roles = "103")]
        [EncryptedActionParameter]
        public ActionResult PendingApplicationDecisionDetailsSW(Int64 AppNo, int? Source = 0)
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }

            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();
            if (Source != 0) { model.Source = Source.ToString(); }

            //string WhetherCondition = string.Empty, DisplayMessage = string.Empty;
            //string[] Values = Utility.GetServiceCode(Convert.ToInt64(model.ApplicationDetails.ApplicationNo));
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition = " and OfficeCode in (@ParamAuthorizationId)  and AcceptedBy in (@AcceptedBy)"; }
            //else { WhetherCondition = " and ApplicationSubdivCode in (@ParamSubDivCode) and OfficeCode=@OfficeCode and AcceptedBy in (@AcceptedBy)"; }

            string addScript = Utility.GetScriptForAuthorizationProcess();

            //string Qry = "select ServiceCode,ApplicationStatusId from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo " + WhetherCondition + " and ServiceCode in (@ParamServiceCode)";
            string Qry = "select AD.ServiceCode,AD.ApplicationStatusId from dbo.ApplicationDetails AD inner join servicemaster SM on SM.ServiceCode=AD.ServiceCode where AD.ApplicationNo=@ApplicationNo and SM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) and AD.AcceptedBy in (@AcceptedBy) " + addScript;
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //Cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            string[] GetValues = data.SelectColumns(Cmd);
            model.ApplicationDetails.ServiceCode = GetValues[0];
            model.ApplicationDetails.ApplicationStatusId = GetValues[1];

            Dictionary<string, string> ValidateData = new Dictionary<string, string>();
            ValidateData.Add("ApplicationNo", model.ApplicationDetails.ApplicationNo);
            string[] ValidationCheck = Utility.ApplicationValidation(ValidateData, (int)ValidationCheckLevels.DecisionProcessGeneralGet, false);
            if (ValidationCheck[0] == ((int)CountList.Type001).ToString())
            {
                PreserveModelState(Constant._ActionMessage, ValidationCheck[1], false, true);
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId) });
                return RedirectToAction("SearchAppForDecision", new { q = QueryString });
            }
            else if (ValidationCheck[0] == ((int)CountList.Type002).ToString())
            {
                ViewData["message"] = ValidationCheck[1];
                return View("message");
            }

            //check whether document verified or not??
            Qry = "select documentstatusid from web.registrationmaster RM left outer join dbo.applicationdetails AD on RM.RegistrationId=AD.RegistrationId where AD.ApplicationNo=@ApplicationNo and RM.DocumentId in (@AadhaarCard,@VoterID)";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@AadhaarCard", ((int)DocumentId.AadhaarCard).ToString());
            Cmd.Parameters.AddWithValue("@VoterID", ((int)DocumentId.VoterID).ToString());
            model.DocumentStatusId = data.SelectColumns(Cmd)[0];

            string flag = Utility.SelectColumnsValue("dbo.VerifierVerificationReport", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
            if (string.IsNullOrEmpty(flag)) { model.WhetherVerification = false; } else { model.WhetherVerification = true; }

            Qry = "select UM.UID,UM.UserName from UserMaster UM inner join UserToSubDivMaster SDM on SDM.Uid=UM.Uid where UM.DistrictCode=@DistrictCode and SDM.SubDivCode in (@ParamSubDivCode) and UM.Permission=@Permission";
            Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@DistrictCode", Sessions.getEmployeeUser().DistrictCode);
            Cmd.Parameters.AddWithValue("@Permission", Convert.ToString((int)Permission.VERF));
            model.VerifierMaster = new SelectList(UserMaster.List<UserMaster>(Cmd), "UID", "UserName");

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data1 = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.VerifierVerificationDetails = Utility.GetVerifierVerificationDetails(model.ApplicantDetails.ApplicationNo);
            model.VerifierWitnessMaster = Utility.GetVerifierWitnessMasterDetails(model.ApplicantDetails.ApplicationNo);
            model.data2 = Utility.GetServiceSpecificVerificationDetails(model.ApplicationDetails.ApplicationNo);
            model.data3 = Utility.GetObjectionDetails(model.ApplicantDetails.ApplicationNo.ToString());
            model.data4 = Utility.GetApplicationAuditTrail(model.ApplicantDetails.ApplicationNo);
            model.IsAlreadyVerified = Utility.SelectColumnsValue("dbo.VerifierApplicationDetails", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
            model.WhetherVerificationLetterRequired = false;
            model.data6 = Utility.GetSingleDocVerificationStatus(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.data7 = Utility.GetMobileSahayakDetailsData(model.ApplicationDetails.ApplicationNo);
            model.data5 = Utility.GetApplicantAvailedService(model.ApplicantDetails.RegistrationId.ToString());
            model.IsPhysicalDocVerificationDone = Utility.IsPhysicalVerificationDone(model.ApplicationDetails.ApplicationNo);

            model.WhetherDocVerified = Utility.CheckWhetherDocVerify(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());

            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Handicapped)
            {
                model.ApplicationHandicappedDetails = Utility.GetHandicappedDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.OldAge)
            {
                model.ApplicationOldAgeDetails = Utility.GetOldAgeDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Widow)
            {
                model.ApplicationWidowDetails = Utility.GetWidowDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Ladli)
            {
                model.ApplicationDetailsLadli = Utility.GetLadliDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.DFBScheme)
            {
                model.ApplicationDetailsDFBScheme = Utility.GetDFBSchemeDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [Authorize(Roles = "103")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingApplicationDecisionDetailsSW(DecisionModels model, FormCollection frm)
        {
            model.ServiceCode = Utility.SelectColumnsValue("ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0];
            model.DeptCode = Utility.GetDeptCode(model.ServiceCode);

            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string QueryString = string.Empty, Qry = string.Empty, DisplayMessage = string.Empty;

                Dictionary<string, string> ValidateData = new Dictionary<string, string>();
                ValidateData.Add("ApplicationNo", model.ApplicationDetails.ApplicationNo);
                string[] ValidationCheck = Utility.ApplicationValidation(ValidateData, (int)ValidationCheckLevels.DecisionProcessGeneralPost, false);
                if (ValidationCheck[0] == ((int)CountList.Type001).ToString())
                {
                    ViewBag.DisplayMessage = ValidationCheck[1];
                    PreserveModelState(Constant._ActionMessage, DisplayMessage, false, true);
                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                    return RedirectToAction("PendingApplicationDecisionDetailsSW", "Decision", new { q = QueryString });
                }
                else if (ValidationCheck[0] == ((int)CountList.Type002).ToString())
                {
                    ViewData["message"] = ValidationCheck[1];
                    return View("message");
                }


                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREC).ToString())
                {
                    bool WhetherExist = Utility.HoldDuplicateApplication(Convert.ToInt64(model.ApplicationDetails.ApplicationNo));
                    if (WhetherExist == false)
                    {
                        DisplayMessage = "Approval can not be possible becuase the applicant already applied another application for this service. ";
                        PreserveModelState(Constant._ActionMessage, DisplayMessage, false, true);
                        QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                        return RedirectToAction("PendingApplicationDecisionDetailsSW", "Decision", new { q = QueryString });
                    }
                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                    return RedirectToAction("ProcessApplicationApprovalRequest", "Sign", new { q = QueryString });
                }
                
                
                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.VERSENT).ToString())
                {
                    model.IsAlreadyVerified = Utility.SelectColumnsValue("dbo.VerifierApplicationDetails", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                    if (string.IsNullOrEmpty(model.IsAlreadyVerified))
                    {
                        Utility.SaveOldStatusBeforeVerification(model.ApplicationDetails.ApplicationNo, CustomText.TRUE.ToString());
                        string Uid = Utility.SelectColumnsValue("dbo.UserMaster", "Uid", "UserId", Sessions.getEmployeeUser().UserId.ToString())[0];

                        Qry = "update dbo.VerifierApplicationDetails set WhetherLastVerification=@WhetherLastVerification where ApplicationNo=@ApplicationNo and exists (select ApplicationNo from dbo.VerifierApplicationDetails where ApplicationNo=@ApplicationNo)";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@WhetherLastVerification", CustomText.FALSE.ToString());
                        cmdList.Add(Cmd);

                        Qry = "insert into dbo.VerifierApplicationDetails (ApplicationNo,SentBy,SentTo,SentDate,WhetherVerified,WhetherLastVerification) values(@ApplicationNo,@SentBy,@SentTo,now(),@WhetherVerified,@WhetherLastVerification)";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@SentBy", Uid);
                        Cmd.Parameters.AddWithValue("@SentTo", model.VerifierCode);
                        Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.FALSE.ToString());
                        Cmd.Parameters.AddWithValue("@WhetherLastVerification", CustomText.TRUE.ToString());
                        cmdList.Add(Cmd);
                    }

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG013, null, (int)ApplicationSource.Window, null));
                    
                    //send sms to applicant and insert record in table
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS004, smsDic));

                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREJ).ToString())
                {
                    // get the reason of rejection
                    string ReasonOfRejection = model.ApplicationDetails.ApplicationRemarks;
                    if (model.ApplicationDetails.RejectionReasonCode != ((int)RejectionReason.Other).ToString()) { ReasonOfRejection = Utility.SelectColumnsValue("dbo.reasonmaster", "reasondetail", "reasoncode", model.ApplicationDetails.RejectionReasonCode)[0]; }

                    //// temprary code for check duplicate application
                    //Qry = "update temp_duplicateapplication set WhetherActive=False where ApplicationNo=@ApplicationNo;";
                    //Cmd = new NpgsqlCommand(Qry);
                    //Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    //cmdList.Add(Cmd);

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG003, ReasonOfRejection, (int)ApplicationSource.Window, null));

                    //send sms to applicant and insert record in table
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    smsDic.Add("ParamRemarks", ReasonOfRejection);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS005, smsDic));

                    //send email to applicant and insert record in table
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS005).ToString());
                    EmailDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    EmailDic.Add("ParamRemarks", ReasonOfRejection);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                }

                Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationDetails.ApplicationNo, Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId), (int)CountList.Type001, DB.LS.ToString()));
                Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                data.SaveData(cmdList);

                PreserveModelState(Constant._ActionMessage, "Selected application has been processed successfully.", false, true);
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.TEHSPEN).ToString() });
                return RedirectToAction("PendingDecsionSummarySW", new { q = QueryString });
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PendingApplicationDecisionDetailsSW", (DecisionModels)TempData[Constant._ModelStateParent]);
        }
        [Authorize(Roles = "103")]
        [EncryptedActionParameter]
        public ActionResult SWPendingForSanction()
        {
            //if (Sessions.getEmployeeUser().Permission != ((int)Permission.TEHS).ToString()) { return RedirectToAction("UnauthorizedRequest"); }
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();

            //string WhetherCondition = string.Empty;
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition = " and AD.OfficeCode in (@ParamAuthorizationId)  and AD.AcceptedBy in (@AcceptedBy)"; }
            //else { WhetherCondition = " and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.OfficeCode=@OfficeCode  and AD.AcceptedBy in (@AcceptedBy)"; }

            string addScript = Utility.GetScriptForAuthorizationProcess();

            //string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,count(AD.ApplicationNo) as AppPending from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.ApplicationStatusId=@ApplicationStatusId " + WhetherCondition + " and AD.ServiceCode in (@ParamServiceCode) group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,count(AD.ApplicationNo) as AppPending from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) and AD.AcceptedBy in (@AcceptedBy) and AD.ApplicationStatusId=@ApplicationStatusId " + addScript + " group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            model.data = data.GetDataTable(cmd);
            model.StatusId = ((int)Status.TEHSREC).ToString();

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "103")]
        [EncryptedActionParameter]
        //public ActionResult SwPendingForSanctionList(int subDiv, int service, int status)
        public ActionResult SwPendingForSanctionList(int service, int status)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();

            //string value = string.Empty;
            //string WhetherCondition = string.Empty;
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition = " and AD.OfficeCode in (@ParamAuthorizationId)  and AD.AcceptedBy in (@AcceptedBy)"; }
            //else { WhetherCondition = " and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.OfficeCode=@OfficeCode  and AD.AcceptedBy in (@AcceptedBy)"; }

            string addScript = Utility.GetScriptForAuthorizationProcess();

            //string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where DM.deptcode=@ParamDeptCode and AD.ServiceCode=@ServiceCode " + WhetherCondition + " and AD.ApplicationStatusId=@ApplicationStatusId " + value + " order by AD.applicationdate";
            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where DM.deptcode=@ParamDeptCode and AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId and AD.AcceptedBy in (@AcceptedBy) " + addScript + " order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            //cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", status);
            cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            model.data = data.GetDataTable(cmd);

            model.ServiceCode = service.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SWSavePendingSanction(DecisionModels model, FormCollection frm)
        {

            GetData data = new GetData();

            if (ModelState.IsValid)
            {
                ArrayList ValuesDate = new ArrayList();
                List<CMDInfoList> cmdList = new List<CMDInfoList>();
                List<NpgsqlCommand> cmdList2 = new List<NpgsqlCommand>();
                CMDInfoList CmdInfo = new CMDInfoList();
                string Message = string.Empty, WhetherCondition = string.Empty;
                string checkboxvalue = frm["chkboxData"];
                //if (TempData[KeyName._Key05] != null)
                //{
                //    checkboxvalue = TempData[KeyName._Key05].ToString();
                //}
                //TempData[KeyName._Key05] = checkboxvalue;
                string[] Values = checkboxvalue.Split(',');

                string Qry = "select date_part('year', now()) as CYear, date_part('month', now()) as Cmonth ";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                model.data = data.GetDataTable(cmd);

                Qry = "Delete from tempsanctionpaymentdetails where UserId=@UserId; ";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                cmdList2.Add(cmd);


                Qry = "Delete from tempsanctionapplicationdetails where UserId=@UserId";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                cmdList2.Add(cmd);
                data.SaveData(cmdList2);

                //for (int i = 0; i < Values.Length; i++)
                //{
                //    Qry = "select coalesce(sum(Feeamount),0) as Recomended from dgen.scstfeedetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                //    cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                //    cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                //    cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                //    model.data1 = data.GetDataTable(cmd);
                //    CalculateAmt += Convert.ToInt64(model.data1.Rows[0]["Recomended"].ToString());
                //}

                Qry = "insert into tempsanctionpaymentdetails(sanctiondate,servicecode,sanctionyear,sanctionmonth,UserId,IpAddress,lastactiondate) values(now(),@servicecode,@sanctionyear,@sanctionmonth,@UserId,@IpAddress,now()); SELECT currval(pg_get_serial_sequence('tempsanctionpaymentdetails','tempsanctionid'))";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@servicecode", model.ServiceCode);
                cmd.Parameters.AddWithValue("@sanctionyear", model.data.Rows[0]["CYear"].ToString());
                cmd.Parameters.AddWithValue("@sanctionmonth", model.data.Rows[0]["Cmonth"].ToString());
                cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                CmdInfo = new CMDInfoList();
                CmdInfo.Cmd = cmd; CmdInfo.ParamenterIndex = null; CmdInfo.Returns = true;
                cmdList.Add(CmdInfo);

                for (int i = 0; i < Values.Length; i++)
                {
                    Dictionary<string, string> ValidateData = new Dictionary<string, string>();
                    ValidateData.Add("ApplicationNo", (Values[i]).ToString());

                    string DisplayMessage = Utility.WhetherAccessAllowed(ValidateData, new int[] { (int)ValueId.AuthDigital, (int)ValueId.AutheKYC }, new int[] { (int)ValueId.SignEsign, (int)ValueId.SignDigital }, new int[] { (int)Status.TEHSREC }, false, false, false);
                    if (!string.IsNullOrEmpty(DisplayMessage))
                    {
                        PreserveModelState(Constant._ActionMessage, DisplayMessage, false, true);
                        return RedirectToAction("SWPendingForSanction", "Decision");
                    }

                    //Qry = "select ApplicationNo,coalesce(sum(Feeamount),0) as Recomended from dgen.scstfeedetails  where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy group by ApplicationNo";
                    //cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    //cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                    //cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                    //model.data1 = data.GetDataTable(cmd);

                    Qry = "insert into tempsanctionapplicationdetails(sanctionid,applicationno,SanctionRemarks,UserId,IpAddress,lastactiondate) values(@Parameter0,@applicationno,@SanctionRemarks,@UserId,@IpAddress,now())";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@applicationno", (Values[i]).ToString());
                    cmd.Parameters.AddWithValue("@SanctionRemarks", model.SchollRemarks);
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    CmdInfo = new CMDInfoList();
                    CmdInfo.Cmd = cmd; CmdInfo.ParamenterIndex = new int[] { 0 }; CmdInfo.Returns = false;
                    cmdList.Add(CmdInfo);

                }
                if (cmdList.Count > 0)
                {
                    Int64 AppNo = Convert.ToInt64(data.SaveTransactionalDataCustom(cmdList)[1].ToString());

                    DecisionModels model1 = new DecisionModels();
                    byte[] PdfBuffer = null;
                    if (model.ServiceCode == ((int)ServiceList.OldAge).ToString())
                    {
                        WhetherCondition = " inner join dgen.applicationdetailsoldage ADOD on ADOD.ApplicationNo=AD.ApplicationNo ";
                    }
                    else if (model.ServiceCode == ((int)ServiceList.Handicapped).ToString())
                    {
                        WhetherCondition = " inner join dgen.applicationdetailshandicapped ADOD on ADOD.ApplicationNo=AD.ApplicationNo ";
                    }
                    else if (model.ServiceCode == ((int)ServiceList.DFBScheme).ToString())
                    {
                        WhetherCondition = " inner join dgen.applicationdetailsdfbscheme ADOD on ADOD.ApplicationNo=AD.ApplicationNo ";
                    }
                    else if (model.ServiceCode == ((int)ServiceList.Widow).ToString())
                    {
                        WhetherCondition = " inner join dgen.applicationdetailswidow ADOD on ADOD.ApplicationNo=AD.ApplicationNo ";
                    }
                    Qry = @"select referencecode,AD.applicationNo,AD.ApplicantName,AD.ServiceCode,ServiceName,ApplicantGender,ApplicantFatherName,ApplicantHusbandName,to_char(ApplicantDob ,'DD/MM/YYYY') as ApplicantDob,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress ";
                    if (model.ServiceCode == ((int)ServiceList.DFBScheme).ToString())
                    {
                        Qry += " ,null as CategoryName ";
                    }
                    else { Qry += ",CategoryName "; }
                    Qry += " from applicationdetails AD " + WhetherCondition + " inner join tempsanctionapplicationdetails TSPD on TSPD.ApplicationNo = AD.ApplicationNo inner join tempsanctionpaymentdetails TSD on TSD.tempSanctionId = TSPD.SanctionId inner join ServiceMaster Sm on SM.ServiceCode = AD.ServiceCode inner join DistrictMaster DM on DM.DistrictCode = AD.ApplicationDistrictCode inner join StateMaster STM on STM.StateId = AD.StateId   ";
                    if (model.ServiceCode != ((int)ServiceList.DFBScheme).ToString())
                    {
                        Qry += " inner join categorymaster CM on CM.CategoryId=ADOD.CategoryId ";
                    }
                    Qry += "  where ApplicationStatusId=@ApplicationStatusId and TSPD.SanctionId=@SanctionId  order by AD.ApplicationNo";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@SanctionId", AppNo);
                    Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
                    model1.data2 = data.GetDataTable(Cmd);
                    if (model1.data2 != null)
                    {
                        PdfBufferGenerator objBuffer = new PdfBufferGenerator();
                        PdfBuffer = objBuffer.GetPdfBuffer(this, string.Empty, "PrintSWSanctionCertificate", model1);
                    }

                    if (model1.data2 != null)
                    {
                        List<NpgsqlCommand> cmdList1 = new List<NpgsqlCommand>();
                        Qry = "update tempsanctionpaymentdetails set documentdata=@documentdata,ContentType=@ContentType where tempSanctionId=@SanctionId; ";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@SanctionId", AppNo);
                        Cmd.Parameters.AddWithValue("@documentdata", PdfBuffer);
                        Cmd.Parameters.AddWithValue("@ContentType", "application/pdf");
                        cmdList1.Add(Cmd);
                        data.SaveData(cmdList1);
                    }

                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "SanctionNo" }, new ArrayList() { Convert.ToInt32(AppNo) });
                    return RedirectToAction("InitializeDocumentSign", "Sign", new { q = QueryString });
                }
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("SwPendingForSanctionList", (DecisionModels)TempData[Constant._ModelStateParent]);

        }
        #endregion

        #region decision method for labour department
        [Authorize(Roles = "103")]
        [EncryptedActionParameter]
        public ActionResult PendingDecsionSummaryLD(int sid)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();

            //string WhetherCondition = string.Empty;
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition = " and AD.OfficeCode in (@ParamAuthorizationId)  and AD.AcceptedBy in (@AcceptedBy)"; }
            //else { WhetherCondition = " and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.OfficeCode=@OfficeCode  and AD.AcceptedBy in (@AcceptedBy)"; }

            string addScript = Utility.GetScriptForAuthorizationProcess();

            //string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@ApplicationSourceId then 1 end),0) as atCSC,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as atOnline from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode " + WhetherCondition + " and AD.ServiceCode in (@ParamServiceCode) group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@ApplicationSourceId then 1 end),0) as atCSC,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as atOnline from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) and AD.AcceptedBy in (@AcceptedBy) " + addScript + " group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@ApplicationSourceId", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            model.data = data.GetDataTable(cmd);
            model.StatusId = sid.ToString();

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "103")]
        [EncryptedActionParameter]
        //public ActionResult PendingDecsionListLD(int subDiv, int service, int status, string Value, int? SourceId)
        public ActionResult PendingDecsionListLD(int service, int status, int? SourceId)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();

            //string value = string.Empty;
            //if (SourceId != null) { value += " and ApplicationSourceId=@ApplicationSourceId"; }
            //string WhetherCondition = string.Empty;
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition = " and AD.OfficeCode in (@ParamAuthorizationId)  and AD.AcceptedBy in (@AcceptedBy)"; }
            //else { WhetherCondition = " and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.OfficeCode=@OfficeCode  and AD.AcceptedBy in (@AcceptedBy)"; }

            string addScript = Utility.GetScriptForAuthorizationProcess();
            if (SourceId != null) { addScript += " and AD.ApplicationSourceId=@ApplicationSourceId"; }

            //string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where DM.deptcode=@ParamDeptCode and AD.ServiceCode=@ServiceCode " + WhetherCondition + " and AD.ApplicationStatusId=@ApplicationStatusId " + value + " order by AD.applicationdate";
            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where DM.deptcode=@ParamDeptCode and AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId and AD.AcceptedBy in (@AcceptedBy) " + addScript + " order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            //cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", status);
            if (SourceId != null) { cmd.Parameters.AddWithValue("@ApplicationSourceId", SourceId); }
            cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [Authorize(Roles = "103")]
        [EncryptedActionParameter]
        public ActionResult PendingApplicationDecisionDetailsLD(Int64 AppNo, int? Source = 0)
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }

            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();
            if (Source != 0) { model.Source = Source.ToString(); }

            //string WhetherCondition = string.Empty, DisplayMessage = string.Empty;
            //string[] Values = Utility.GetServiceCode(Convert.ToInt64(model.ApplicationDetails.ApplicationNo));
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition = " and OfficeCode in (@ParamAuthorizationId)  and AcceptedBy in (@AcceptedBy)"; }
            //else { WhetherCondition = " and ApplicationSubdivCode in (@ParamSubDivCode) and OfficeCode=@OfficeCode and AcceptedBy in (@AcceptedBy)"; }

            string addScript = Utility.GetScriptForAuthorizationProcess();

            //string Qry = "select ServiceCode,ApplicationStatusId from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo " + WhetherCondition + " and ServiceCode in (@ParamServiceCode)";
            string Qry = "select AD.ServiceCode,AD.ApplicationStatusId from dbo.ApplicationDetails AD inner join servicemaster SM on SM.ServiceCode=AD.ServiceCode where AD.ApplicationNo=@ApplicationNo and SM.deptcode=@ParamDeptCode  and AD.ServiceCode in (@ParamServiceCode) and AD.AcceptedBy in (@AcceptedBy) " + addScript;
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //Cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            string[] GetValues = data.SelectColumns(Cmd);
            model.ApplicationDetails.ServiceCode = GetValues[0];
            model.ApplicationDetails.ApplicationStatusId = GetValues[1];

            Dictionary<string, string> ValidateData = new Dictionary<string, string>();
            ValidateData.Add("ApplicationNo", model.ApplicationDetails.ApplicationNo);

            string[] ValidationCheck = Utility.ApplicationValidation(ValidateData, (int)ValidationCheckLevels.DecisionProcessGeneralGet, false);
            if (ValidationCheck[0] == ((int)CountList.Type001).ToString())
            {
                PreserveModelState(Constant._ActionMessage, ValidationCheck[1], false, true);
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId) });
                return RedirectToAction("SearchAppForDecision", new { q = QueryString });
            }
            else if (ValidationCheck[0] == ((int)CountList.Type002).ToString())
            {
                ViewData["message"] = ValidationCheck[1];
                return View("message");
            }

            Qry = "select documentstatusid from web.registrationmaster RM left outer join dbo.applicationdetails AD on RM.RegistrationId=AD.RegistrationId where AD.ApplicationNo=@ApplicationNo and RM.DocumentId in (@AadhaarCard,@VoterID)";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@AadhaarCard", ((int)DocumentId.AadhaarCard).ToString());
            Cmd.Parameters.AddWithValue("@VoterID", ((int)DocumentId.VoterID).ToString());
            model.DocumentStatusId = data.SelectColumns(Cmd)[0];

            string flag = Utility.SelectColumnsValue("dbo.VerifierVerificationReport", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
            if (string.IsNullOrEmpty(flag)) { model.WhetherVerification = false; } else { model.WhetherVerification = true; }

            Qry = "select UM.UID,UM.UserName from UserMaster UM inner join UserToSubDivMaster SDM on SDM.Uid=UM.Uid where UM.DistrictCode=@DistrictCode and SDM.SubDivCode in (@ParamSubDivCode) and UM.Permission=@Permission";
            Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@DistrictCode", Sessions.getEmployeeUser().DistrictCode);
            Cmd.Parameters.AddWithValue("@Permission", Convert.ToString((int)Permission.VERF));
            model.VerifierMaster = new SelectList(UserMaster.List<UserMaster>(Cmd), "UID", "UserName");

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.VerifierVerificationDetails = Utility.GetVerifierVerificationDetails(model.ApplicantDetails.ApplicationNo);
            model.VerifierWitnessMaster = Utility.GetVerifierWitnessMasterDetails(model.ApplicantDetails.ApplicationNo);

            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data1 = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data2 = Utility.GetServiceSpecificVerificationDetails(model.ApplicationDetails.ApplicationNo);
            model.data3 = Utility.GetObjectionDetails(model.ApplicantDetails.ApplicationNo.ToString());
            model.data4 = Utility.GetApplicationAuditTrail(model.ApplicantDetails.ApplicationNo);
            model.data5 = Utility.GetApplicantAvailedService(model.ApplicantDetails.RegistrationId.ToString());
            model.data6 = Utility.GetSingleDocVerificationStatus(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.data9 = Utility.GetPaymentDetails(model.ApplicationDetails.ApplicationNo);
            model.data10 = Utility.GetLBRChallanStatus(model.ApplicationDetails.ApplicationNo, model.ApplicationDetails.ServiceCode);
            model.data8 = Utility.GetMobileSahayakDetailsData(model.ApplicationDetails.ApplicationNo);

            model.IsAlreadyVerified = Utility.SelectColumnsValue("dbo.VerifierApplicationDetails", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
            model.WhetherDocVerified = Utility.CheckWhetherDocVerify(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.WhetherVerificationLetterRequired = false;
            

            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.BOCW)
            {
                model.ApplicationDetailsBOCWAct = Utility.GetBOCWActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.LBRPaymentStatus = Utility.GetLBRPaymentStatus(model.ApplicantDetails.ApplicationNo.ToString());
                model.PAmount = Utility.GetConditionalFee(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString()).ToString();
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.ContractLabour)
            {
                model.ApplicationDetailsCLAct = Utility.GetCLActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.LBRPaymentStatus = Utility.GetLBRPaymentStatus(model.ApplicantDetails.ApplicationNo.ToString());
                model.PAmount = Utility.GetConditionalFee(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString()).ToString();
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Contractors)
            {
                model.ApplicationDetailsContractor = Utility.GetContractorDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.LBRPaymentStatus = Utility.GetLBRPaymentStatus(model.ApplicantDetails.ApplicationNo.ToString());
                model.PAmount = Utility.GetConditionalFee(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString()).ToString();
                model.PAmount2 = Utility.GetContractorSecurityDepositFee(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString()).ToString();
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.RenewalOfContractor)
            {
                model.ApplicationDetailsRenewalContractor = Utility.GetRenewalContractorDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());

                Qry = "select WhetherWorkerIncreased,Whetherapplrenewal,Whetherapplamend from dgen.applicationdetailsrenewalcontractor where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
                string[] GetFeeType = data.SelectColumns(Cmd);
                model.WhetherWorkerIncreased = GetFeeType[0];
                model.WhetherApplRenewal = GetFeeType[1];
                model.WhetherApplAmend = GetFeeType[2];

                model.LBRPaymentStatus = Utility.GetLBRPaymentStatus(model.ApplicantDetails.ApplicationNo.ToString());

                //if (model.WhetherWorkerIncreased == CustomText.True.ToString())
                //{
                //    model.PAmount2 = (Utility.GetContractorSecurityDepositFee(model.ApplicationDetails.ApplicationNo, DB.LS.ToString())).ToString();
                //}
                if (model.WhetherApplRenewal == CustomText.True.ToString())
                {
                    model.PAmount4 = (Utility.GetContractorRenewalDepositFee(model.ApplicantDetails.ApplicationNo, DB.LS.ToString())).ToString();
                    string ApprovedDate = string.Empty;
                    string Today = DateTime.Now.ToString("dd/MM/yyyy");
                    ApprovedDate = Utility.SelectColumnsValue("dgen.applicationdetailsrenewalcontractor", "OldCertificateDate", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                    string OldCertificateDate = (Convert.ToDateTime(ApprovedDate)).ToString("dd/MM/yyyy");

                    if (Convert.ToDateTime(Today) > Convert.ToDateTime(OldCertificateDate))
                    {
                        model.PAmount3 = (Utility.GetContractorRenewalPenaltyFee(model.ApplicationDetails.ApplicationNo, DB.LS.ToString())).ToString();
                        model.PTotalAmount = Convert.ToInt32(model.PAmount4) + Convert.ToInt32(model.PAmount3);
                    }
                }

                if (model.WhetherApplAmend == CustomText.True.ToString())
                {
                    if (model.WhetherWorkerIncreased == CustomText.True.ToString())
                    {
                        model.PAmount2 = (Utility.GetContractorSecurityDepositFee(model.ApplicationDetails.ApplicationNo, DB.LS.ToString())).ToString();
                        model.PAmount5 = (Utility.GetContractorAmendmentDepositFee(model.ApplicationDetails.ApplicationNo, DB.LS.ToString())).ToString();//Changes170119
                    }
                }
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.InstallationOfLift)
            {
                model.ApplicationDetailsInstallationOfLift = Utility.GetInstallationOfLiftDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                model.IsAlreadyInspected = Utility.SelectColumnsValue("dgen.lbrliftinspectionmaster", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                if (!string.IsNullOrEmpty(model.IsAlreadyInspected))
                {
                    model.data7 = Utility.GetLBRLiftInspectionDetails(model.ApplicationDetails.ApplicationNo);
                }
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.GrantOfPassengerLift)
            {
                model.ApplicationDetailsGrantOfPassengerLift = Utility.GetGrantOfPassengerLiftDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                model.LBRPaymentStatus = Utility.GetLBRPaymentStatus(model.ApplicantDetails.ApplicationNo.ToString());
                model.PAmount = Utility.GetConditionalFee(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString()).ToString();
                model.IsAlreadyInspected = Utility.SelectColumnsValue("dgen.lbrliftinspectionmaster", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                if (!string.IsNullOrEmpty(model.IsAlreadyInspected))
                {
                    model.data7 = Utility.GetLBRLiftInspectionDetails(model.ApplicationDetails.ApplicationNo);
                }
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.RenewalOfPassengerLift)
            {
                model.ApplicationDetailsRenewalOfPassengerLift = Utility.GetRenewalOfPassengerLiftDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                model.LBRPaymentStatus = Utility.GetLBRPaymentStatus(model.ApplicantDetails.ApplicationNo.ToString());
                model.PAmount = Utility.GetConditionalFee(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString()).ToString();
                model.IsAlreadyInspected = Utility.SelectColumnsValue("dgen.lbrliftinspectionmaster", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                if (!string.IsNullOrEmpty(model.IsAlreadyInspected))
                {
                    model.data7 = Utility.GetLBRLiftInspectionDetails(model.ApplicationDetails.ApplicationNo);
                }
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.LbrRecovery)
            {
                model.ApplicationDetailsLBRRecovery = Utility.GetLBRRecoveryDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                Qry = "select NID from dgen.recoverynoticedetails where ApplicationNo=@ApplicationNo and TypeId=@TypeId and WhetherGenerated=@WhetherGenerated and ProceedingDetails is null";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@TypeId", (int)ValueId.Notice);
                Cmd.Parameters.AddWithValue("@WhetherGenerated", CustomText.TRUE.ToString());
                string[] GVal = data.SelectColumns(Cmd);
                if (GVal.Length > 0) { model.ApplicationDetailsLBRRecovery.NoticeId = GVal[0]; }
                if (!string.IsNullOrEmpty(model.ApplicationDetailsLBRRecovery.NoticeId))
                { model.ApplicationDetailsLBRRecovery.WhetherProceedingDetails = CustomText.TRUE.ToString(); }
                else { model.ApplicationDetailsLBRRecovery.WhetherProceedingDetails = CustomText.FALSE.ToString(); }
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.CEA1)
            {
                List<SelectListItem> items = new List<SelectListItem>();
                string qry = "select UM.UID,UM.UserName from UserMaster UM inner join UserToSubDivMaster SDM on SDM.Uid=UM.Uid where UM.DistrictCode=@DistrictCode and SDM.SubDivCode in (@ParamSubDivCode) and UM.Permission=@Permission";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@DistrictCode", Sessions.getEmployeeUser().DistrictCode);
                Cmd.Parameters.AddWithValue("@Permission", Convert.ToString((int)Permission.VERF));
                DataTable dt = data.GetDataTable(Cmd);
                if (dt != null && dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++) { items.Add(new SelectListItem { Text = dt.Rows[i]["UserName"].ToString(), Value = dt.Rows[i]["UID"].ToString() }); }
                }
                model.AdditionalVerifier = items;

                qry = "select llim.inspectionid from dgen.lbrliftinspectionmaster llim inner join dgen.lbradditionalverifierdetails lavd on llim.inspectionid=lavd.inspectionid where llim.applicationno=@applicationno and lavd.whetherinspected=@whetherinspected";
                cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(qry));
                cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                cmd.Parameters.AddWithValue("@whetherinspected", CustomText.False.ToString());
                DataTable dtver = data.GetDataTable(cmd);
                if (dtver.Rows.Count > 0 && dtver != null)
                {
                    model.WhetherAllVerComp = CustomText.False.ToString();
                }
                
                qry = "select llim.inspectionid,um.username as inspectedby,llim.markedby,markedon,case when whethersatisfactory=false then 'No' else 'Yes' end as whethersatisfactory,inspectionremarks,to_char(lavd.inspectedon,'DD/MM/YYYY') as  inspectedon from dgen.lbrliftinspectionmaster llim inner join dgen.lbradditionalverifierdetails lavd on llim.inspectionid=lavd.inspectionid inner join dbo.usermaster um on lavd.inspectedby=um.uid where llim.applicationno=@applicationno";
                cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(qry));
                cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                model.data11 = data.GetDataTable(cmd);

                model.ApplicationDetailsCEA1 = Utility.GetApplicationDetailsCEA1(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.IsAlreadyInspected = Utility.SelectColumnsValue("dgen.lbrliftinspectionmaster", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                if (!string.IsNullOrEmpty(model.IsAlreadyInspected))
                {
                    model.data7 = Utility.GetLBRLiftInspectionDetails(model.ApplicationDetails.ApplicationNo);
                }
                model.PAmount = Utility.GetConditionalFee(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString()).ToString();
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.CEA2)
            {
                model.ApplicationDetailsCEA2 = Utility.GetApplicationDetailsCEA2(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.IsAlreadyInspected = Utility.SelectColumnsValue("dgen.lbrliftinspectionmaster", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                if (!string.IsNullOrEmpty(model.IsAlreadyInspected))
                {
                    model.data7 = Utility.GetLBRLiftInspectionDetails(model.ApplicationDetails.ApplicationNo);
                }
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.CEA3)
            {
                model.ApplicationDetailsCEA3 = Utility.GetApplicationDetailsCEA3(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.IsAlreadyInspected = Utility.SelectColumnsValue("dgen.lbrliftinspectionmaster", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                if (!string.IsNullOrEmpty(model.IsAlreadyInspected))
                {
                    model.data7 = Utility.GetLBRLiftInspectionDetails(model.ApplicationDetails.ApplicationNo);
                }
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.ECLicence)
            {
                model.ApplicationDetailsEC = Utility.GetApplicationDetailsEC(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.LBRPaymentStatus = Utility.GetLBRPaymentStatus(model.ApplicantDetails.ApplicationNo.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.CompCertificate)
            {
                model.ApplicationDetailsCompCertificate = Utility.GetApplicationDetailsCompCertificate(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.LBRPaymentStatus = Utility.GetLBRPaymentStatus(model.ApplicantDetails.ApplicationNo.ToString());
            }
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.ConstructionWorker)
            //{
            //    model.ApplicationDetailsConsWorker = Utility.GetConsWorkerDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());

            //    Qry = "select username,to_char(actiondate,'DD/MM/YYYY HH:MM:SS') as actiondate,ipaddress from departmentaudittrail dat inner join usermaster um on dat.actionby=um.userid where applicationno=@applicationno and actionmessageid=@actionmessageid";
            //    Cmd = new NpgsqlCommand(Qry);
            //    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
            //    Cmd.Parameters.AddWithValue("@actionmessageid", (int)CountList.Type008);
            //    model.data11 = data.GetDataTable(Cmd);
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.RenewalConsWorker)
            //{
            //    model.RenewalConsWorker = Utility.GetRenewalConsWorkerDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.DeathBenefits)
            //{
            //    model.ApplicationDetailsDeathBenefits = Utility.GetDeathBenefitsActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsDeathBenefits.WorkerRegNo);
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.FuneralBenefit)
            //{
            //    model.ApplicationDetailsFuneralBenefit = Utility.GetFuneralBenefitActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsFuneralBenefit.WorkerRegNo);
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.FamilyPension)
            //{
            //    model.ApplicationDetailsFamilyPension = Utility.GetFamilyPensionActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsFamilyPension.WorkerRegNo);
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MarriageAssistance)
            //{
            //    model.ApplicationDetailsMarriageAssistance = Utility.GetMarriageAssistanceActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsMarriageAssistance.WorkerRegNo);
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.EduScholarship)
            //{
            //    model.ApplicationDetailsEduScholarship = Utility.GetEduScholarshipActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsEduScholarship.WorkerRegNo);
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MedicalAssistance)
            //{
            //    model.ApplicationDetailsMedicalAssistance = Utility.GetMedicalAssistanceActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsMedicalAssistance.WorkerRegNo);
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.HBA)
            //{
            //    model.ApplicationDetailsHBA = Utility.GetHBAActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsHBA.WorkerRegNo);
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.DisabilityPension)
            //{
            //    model.ApplicationDetailsDisabilityPension = Utility.GetDisabilityPensionActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsDisabilityPension.WorkerRegNo);
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Pension)
            //{
            //    model.ApplicationDetailsPension = Utility.GetPensionActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsPension.WorkerRegNo);
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MaternityBenefit)
            //{
            //    model.ApplicationDetailsMaternityBenefit = Utility.GetMaternityBenefitActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsMaternityBenefit.WorkerRegNo);
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.GrantofWork)
            //{
            //    model.ApplicationDetailsGrantofWork = Utility.GetGrantofWorkActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsGrantofWork.WorkerRegNo);
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.InstrumentLoan)
            //{
            //    model.ApplicationDetailsInstrumentLoan = Utility.GetInstrumentLoanActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            //    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsInstrumentLoan.WorkerRegNo);
            //}
            //else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.ExGratia)
            //{
            //    model.ApplicationDetailsExgratia = Utility.GetApplicationDetailsExGratia(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());

            //}
            else
            {
                return RedirectToAction("BadRequest", "Error");
            }

            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [Authorize(Roles = "103")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingApplicationDecisionDetailsLD(DecisionModels model, FormCollection frm)
        {
            model.ServiceCode = Utility.SelectColumnsValue("ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0];
            model.DeptCode = Utility.GetDeptCode(model.ServiceCode);

            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                //bool BypassPermission = false;
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string QueryString = string.Empty, Qry = string.Empty;


                Dictionary<string, string> ValidateData = new Dictionary<string, string>();
                ValidateData.Add("ApplicationNo", model.ApplicationDetails.ApplicationNo);
                string[] ValidationCheck = Utility.ApplicationValidation(ValidateData, (int)ValidationCheckLevels.DecisionProcessGeneralPost, false);
                if (ValidationCheck[0] == ((int)CountList.Type001).ToString())
                {
                    PreserveModelState(Constant._ActionMessage, ValidationCheck[1], false, true);
                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                    return RedirectToAction("PendingApplicationDecisionDetailsLD", "Decision", new { q = QueryString });
                }
                else if (ValidationCheck[0] == ((int)CountList.Type002).ToString())
                {
                    ViewData["message"] = ValidationCheck[1];
                    return View("message");
                }


                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREC).ToString())
                {
                    if (model.ServiceCode.Equals(((int)ServiceList.ContractLabour).ToString()) || model.ServiceCode.Equals(((int)ServiceList.BOCW).ToString()) || model.ServiceCode.Equals(((int)ServiceList.Contractors).ToString()) || model.ServiceCode.Equals(((int)ServiceList.GrantOfPassengerLift).ToString()) || model.ServiceCode.Equals(((int)ServiceList.RenewalOfPassengerLift).ToString()) || model.ServiceCode.Equals(((int)ServiceList.RenewalOfContractor).ToString()) || model.ServiceCode.Equals(((int)ServiceList.CEA1).ToString()))
                    {
                        if (model.LBRPaymentStatus == (int)CountList.Type001)
                        {
                            if (Convert.ToInt32(model.PAmount) > 0)
                            {
                                HttpPostedFile file = System.Web.HttpContext.Current.Request.Files["PFile"];
                                byte[] fileData = Utility.CompareFileCapturePhotoData(null, file);
                                string contentType = file.ContentType;
                                if (fileData != null)
                                {
                                    Qry = "update dgen.lbrapplicationpaymentdetails set pfilecontenttype=@pfilecontenttype,PFile=@PFile,TransactionType=@TransactionType,PNo=@PNo, PDate=@PDate, PAmount=@PAmount,userid=@userid, ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo and challantype=@challantype";
                                    Cmd = new NpgsqlCommand(Qry);
                                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                                    Cmd.Parameters.AddWithValue("@challantype", (int)ChallanType.LicenseFee);
                                    Cmd.Parameters.AddWithValue("@TransactionType", (int)ValueId.Treasury);
                                    Cmd.Parameters.AddWithValue("@PNo", model.PNo);
                                    Cmd.Parameters.AddWithValue("@PAmount", model.PAmount);
                                    Cmd.Parameters.AddWithValue("@PFile", fileData);
                                    Cmd.Parameters.AddWithValue("@pfilecontenttype", contentType);
                                    Cmd.Parameters.AddWithValue("@PDate", Utility.GetDateYYYYMMDD(model.PDate, '/', "0/1/2"));
                                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                    cmdList.Add(Cmd);
                                }
                                else { return View("message", ViewData["message"] = "Upload Unsuccessful!"); }
                            }

                            if (model.ServiceCode == ((int)ServiceList.Contractors).ToString() || model.ServiceCode == ((int)ServiceList.RenewalOfContractor).ToString())
                            {
                                if (model.ServiceCode == ((int)ServiceList.Contractors).ToString())
                                {
                                    HttpPostedFile file2 = System.Web.HttpContext.Current.Request.Files["PFile2"];
                                    byte[] fileData2 = Utility.CompareFileCapturePhotoData(null, file2);
                                    string contentType2 = file2.ContentType;

                                    if (fileData2 != null)
                                    {
                                        Qry = "update dgen.lbrapplicationpaymentdetails set pfilecontenttype=@pfilecontenttype,PFile=@PFile,TransactionType=@TransactionType,PNo=@PNo, PDate=@PDate, PAmount=@PAmount,userid=@userid, ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo and challantype=@challantype";
                                        Cmd = new NpgsqlCommand(Qry);
                                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                                        Cmd.Parameters.AddWithValue("@challantype", (int)ChallanType.SecurityDeposit);
                                        Cmd.Parameters.AddWithValue("@TransactionType", (int)ValueId.Treasury);
                                        Cmd.Parameters.AddWithValue("@PNo", model.PNo2);
                                        Cmd.Parameters.AddWithValue("@PAmount", model.PAmount2);
                                        Cmd.Parameters.AddWithValue("@PDate", Utility.GetDateYYYYMMDD(model.PDate2, '/', "0/1/2"));
                                        Cmd.Parameters.AddWithValue("@PFile", fileData2);
                                        Cmd.Parameters.AddWithValue("@pfilecontenttype", contentType2);
                                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                        cmdList.Add(Cmd);
                                    }
                                }
                                else if (model.ServiceCode == ((int)ServiceList.RenewalOfContractor).ToString())
                                {
                                    // generate renewal challan 
                                    if (model.WhetherApplRenewal.ToUpper() == CustomText.TRUE.ToString())
                                    {
                                        HttpPostedFile file4 = System.Web.HttpContext.Current.Request.Files["PFile4"];
                                        byte[] fileData4 = Utility.CompareFileCapturePhotoData(null, file4);
                                        string contentType4 = file4.ContentType;

                                        string ApprovedDate = string.Empty;
                                        string Today = DateTime.Now.ToString("dd/MM/yyyy");
                                        ApprovedDate = Utility.SelectColumnsValue("dgen.applicationdetailsrenewalcontractor", "OldCertificateDate", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                                        string OldCertificateDate = (Convert.ToDateTime(ApprovedDate)).ToString("dd/MM/yyyy");

                                        if (fileData4 != null)
                                        {
                                            Qry = "update dgen.lbrapplicationpaymentdetails set pfilecontenttype=@pfilecontenttype,PFile=@PFile,TransactionType=@TransactionType,PNo=@PNo, PDate=@PDate, PAmount=@PAmount,userid=@userid, ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo and challantype=@challantype";
                                            Cmd = new NpgsqlCommand(Qry);
                                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                                            Cmd.Parameters.AddWithValue("@challantype", (int)ChallanType.RenewalDeposit);
                                            Cmd.Parameters.AddWithValue("@TransactionType", (int)ValueId.Treasury);
                                            Cmd.Parameters.AddWithValue("@PNo", model.PNo4);
                                            if (Convert.ToDateTime(Today) > Convert.ToDateTime(OldCertificateDate))
                                            { Cmd.Parameters.AddWithValue("@PAmount", model.PTotalAmount); }
                                            else { Cmd.Parameters.AddWithValue("@PAmount", model.PAmount4); }
                                            Cmd.Parameters.AddWithValue("@PDate", Utility.GetDateYYYYMMDD(model.PDate4, '/', "0/1/2"));
                                            Cmd.Parameters.AddWithValue("@PFile", fileData4);
                                            Cmd.Parameters.AddWithValue("@pfilecontenttype", contentType4);
                                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                            cmdList.Add(Cmd);
                                        }
                                        else { return View("message", ViewData["message"] = "Upload Unsuccessful!"); }
                                    }

                                    // generate amendment challan
                                    if (model.WhetherApplAmend.ToUpper() == CustomText.TRUE.ToString() && model.WhetherWorkerIncreased.ToUpper() == CustomText.TRUE.ToString())
                                    {
                                        // genrate security deposit challan
                                        HttpPostedFile file3 = System.Web.HttpContext.Current.Request.Files["PFile3"];
                                        byte[] fileData3 = Utility.CompareFileCapturePhotoData(null, file3);
                                        string contentType3 = file3.ContentType;
                                        if (fileData3 != null)
                                        {
                                            Qry = "update dgen.lbrapplicationpaymentdetails set pfilecontenttype=@pfilecontenttype,PFile=@PFile,TransactionType=@TransactionType,PNo=@PNo, PDate=@PDate, PAmount=@PAmount,userid=@userid, ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo and challantype=@challantype";
                                            Cmd = new NpgsqlCommand(Qry);
                                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                                            Cmd.Parameters.AddWithValue("@challantype", (int)ChallanType.SecurityDeposit);
                                            Cmd.Parameters.AddWithValue("@TransactionType", (int)ValueId.Treasury);
                                            Cmd.Parameters.AddWithValue("@PNo", model.PNo3);
                                            Cmd.Parameters.AddWithValue("@PAmount", model.PAmount2);
                                            Cmd.Parameters.AddWithValue("@PDate", Utility.GetDateYYYYMMDD(model.PDate3, '/', "0/1/2"));
                                            Cmd.Parameters.AddWithValue("@PFile", fileData3);
                                            Cmd.Parameters.AddWithValue("@pfilecontenttype", contentType3);
                                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                            cmdList.Add(Cmd);
                                        }
                                        else { return View("message", ViewData["message"] = "Upload Unsuccessful!"); }

                                        // generate amendment deposit challan 
                                        HttpPostedFile file2 = System.Web.HttpContext.Current.Request.Files["PFile2"];
                                        byte[] fileData2 = Utility.CompareFileCapturePhotoData(null, file2);
                                        string contentType2 = file2.ContentType;
                                        if (fileData2 != null)
                                        {
                                            Qry = "update dgen.lbrapplicationpaymentdetails set pfilecontenttype=@pfilecontenttype,PFile=@PFile,TransactionType=@TransactionType,PNo=@PNo, PDate=@PDate, PAmount=@PAmount,userid=@userid, ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo and challantype=@challantype";
                                            Cmd = new NpgsqlCommand(Qry);
                                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                                            Cmd.Parameters.AddWithValue("@challantype", (int)ChallanType.AmendmentDeposit);
                                            Cmd.Parameters.AddWithValue("@TransactionType", (int)ValueId.Treasury);
                                            Cmd.Parameters.AddWithValue("@PNo", model.PNo2);
                                            Cmd.Parameters.AddWithValue("@PAmount", model.PAmount5);
                                            Cmd.Parameters.AddWithValue("@PDate", Utility.GetDateYYYYMMDD(model.PDate3, '/', "0/1/2"));
                                            Cmd.Parameters.AddWithValue("@PFile", fileData2);
                                            Cmd.Parameters.AddWithValue("@pfilecontenttype", contentType2);
                                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                            cmdList.Add(Cmd);
                                        }
                                        else { return View("message", ViewData["message"] = "Upload Unsuccessful!"); }

                                    }
                                }
                            }

                            Qry = "update applicationpaymentrequest set paymentstatusid=@paymentstatusidNEW where ApplicationNo=@ApplicationNo and paymentmodeid=@paymentmodeid and paymentstatusid=@paymentstatusidOLD";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@paymentmodeid", (int)PaymentMode.Offline);
                            Cmd.Parameters.AddWithValue("@paymentstatusidNEW", (int)ValueId.SbiEpaySuccess);
                            Cmd.Parameters.AddWithValue("@paymentstatusidOLD", (int)ValueId.SbiEpayNewPayment);
                            cmdList.Add(Cmd);

                            cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG039, null, (int)ApplicationSource.Window, null));
                            data.SaveData(cmdList);

                            return View("message", ViewData["message"] = "Payment Details have been Saved Successfully.");

                        }
                    }
                    else if (model.ServiceCode.Equals(((int)ServiceList.LbrRecovery).ToString()))
                    {
                        if (model.ApplicationDetailsLBRRecovery.IsSettled == CustomText.Y.ToString())
                        {
                            Cmd = new NpgsqlCommand("insert into dgen.recoverynoticedetails(ApplicationNo,ServiceCode,DisposalRemarks,Whethergenerated,userid,ipaddress,lastactiondate) values (@ApplicationNo,@ServiceCode,@DisposalRemarks,@Whethergenerated,@userid,@ipaddress,now()) ");
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@DisposalRemarks", model.ApplicationDetailsLBRRecovery.Remarks);
                            Cmd.Parameters.AddWithValue("@Whethergenerated", CustomText.False.ToString());
                            Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.LbrRecovery);
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);

                            Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,ApplicationRemarks=@ApplicationRemarks,ApprovedDate=now(),userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetailsLBRRecovery.Remarks);
                            Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationDetails.ApplicationNo, (int)Status.ISSUCER, (int)CountList.Type001, DB.LS.ToString()));
                            Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);

                            Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetailsLBRRecovery.Remarks);
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);

                            cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG048, model.ApplicationDetailsLBRRecovery.Remarks, (int)ApplicationSource.Window, null));
                            data.SaveData(cmdList);

                            return View("message", ViewData["message"] = "Application has been disposed off successfully.");
                        }
                        else if (model.ApplicationDetailsLBRRecovery.WhetherProceedingDetails.ToUpper() == CustomText.TRUE.ToString())
                        {
                            Cmd = new NpgsqlCommand("update dgen.recoverynoticedetails set Proceedingdetails=@Proceedingdetails,ProceedingDate=@ProceedingDate,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where nid=@NoticeId ");
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@Proceedingdetails", model.ApplicationDetailsLBRRecovery.ProceedingDetails);
                            Cmd.Parameters.AddWithValue("@ProceedingDate", Utility.GetDateYYYYMMDD(model.ApplicationDetailsLBRRecovery.ProceedingDate, '/', "0/1/2"));
                            Cmd.Parameters.AddWithValue("@Whethergenerated", CustomText.True.ToString());
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                            Cmd.Parameters.AddWithValue("@NoticeId", model.ApplicationDetailsLBRRecovery.NoticeId);
                            cmdList.Add(Cmd);

                            cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, null, (int)ApplicationSource.Window, null));
                            data.SaveData(cmdList);

                            PreserveModelState(Constant._ActionMessage, "Proceeding Details Saved!", false, true);
                            QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                            return RedirectToAction("PendingApplicationDecisionDetailsLD", "Decision", new { q = QueryString });
                        }
                        else if (model.ApplicationDetailsLBRRecovery.IsNoticeRequired.ToUpper() == CustomText.Y.ToString())
                        {
                            QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                            return RedirectToAction("GenerateLBRRecoveryNotice", "Print", new { q = QueryString });
                        }
                        else if (model.ApplicationDetailsLBRRecovery.IsRecoveryCertRequired == CustomText.Y.ToString())
                        {
                            Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.OBSPEND);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);

                            Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,ApprovedDate=now(),userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.OBSPEND);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationDetails.ApplicationNo, (int)Status.OBSPEND, (int)CountList.Type001, DB.LS.ToString()));
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);

                            cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG045, null, (int)ApplicationSource.Window, null));
                            data.SaveData(cmdList);

                            QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                            return RedirectToAction("GenerateLBRRecoveryCertificate", "Print", new { q = QueryString });
                        }
                    }
//                    else if (model.ServiceCode == ((int)ServiceList.ConstructionWorker).ToString())
//                    {

//                        Qry = @"INSERT INTO applicationdetailsregvalidity(applicationno, regdate, renewaldate, expirydate, userid,ipaddress, actiondatetime)
//                                         (select applicationno,case when whetherregisterworker=false and whetheruploadvolunteerdata=false then now()  -- fresh
//                                        when whetherregisterworker=true and whetheruploadvolunteerdata=false then registrationdate  --renewal
//                                        when whetherregisterworker=true and whetheruploadvolunteerdata=true then registrationdate end as regdate, --volunteer
//                                        case when whetherregisterworker=false and whetheruploadvolunteerdata=false then now()  -- fresh
//                                        when whetherregisterworker=true and whetheruploadvolunteerdata=false then now()  --renewal
//                                        when whetherregisterworker=true and whetheruploadvolunteerdata=true then lastrenewaldate end as renewaldate, --volunteer
//                                        case when whetherregisterworker=false and whetheruploadvolunteerdata=false then now() + interval ' 1 year'  -- fresh
//                                        when whetherregisterworker=true and whetheruploadvolunteerdata=false then lastexpregistration + interval  '1 year'  --renewal
//                                        when whetherregisterworker=true and whetheruploadvolunteerdata=true then lastexpregistration end as expirydate, --volunteer
//                                        @userid as userid,@ipaddress as ipaddress, now() as actiondatetime
//                                        from dgen.applicationdetailsregconstructionworker where applicationno=@applicationno);";
//                        Cmd = new NpgsqlCommand(Qry);
//                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
//                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
//                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
//                        cmdList.Add(Cmd);

//                        data.SaveData(cmdList);

//                    }
//                    else if (model.ServiceCode == ((int)ServiceList.RenewalConsWorker).ToString())
//                    {
//                        string registrationno = Utility.SelectColumnsValue("dgen.applicationdetailsrenewalconsworker", "registrationno", "applicationno", model.ApplicationDetails.ApplicationNo)[0];
//                        Qry = @"update applicationdetailsregvalidity set renewaldate=now(),expirydate=(expirydate + interval '1 year'),userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where applicationno=@registrationno;";
//                        Cmd = new NpgsqlCommand(Qry);
//                        Cmd.Parameters.AddWithValue("@registrationno", registrationno);
//                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
//                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
//                        cmdList.Add(Cmd);

//                        data.SaveData(cmdList);
//                    }

                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                    return RedirectToAction("ProcessApplicationApprovalRequest", "Sign", new { q = QueryString });
                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.VERSENT).ToString())
                {
                    CMDInfoList CmdInfo = new CMDInfoList();
                    List<CMDInfoList> cmdInfoList = new List<CMDInfoList>();
                    if (model.ServiceCode.Equals(((int)ServiceList.GrantOfPassengerLift).ToString()) || model.ServiceCode.Equals(((int)ServiceList.InstallationOfLift).ToString()) || model.ServiceCode.Equals(((int)ServiceList.RenewalOfPassengerLift).ToString()) || model.ServiceCode.Equals(((int)ServiceList.CEA1).ToString()) || model.ServiceCode.Equals(((int)ServiceList.CEA2).ToString()) || model.ServiceCode.Equals(((int)ServiceList.CEA3).ToString()))
                    {
                        model.IsAlreadyInspected = Utility.SelectColumnsValue("dgen.lbrliftinspectionmaster", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                        Utility.SaveOldStatusBeforeVerification(model.ApplicationDetails.ApplicationNo, CustomText.TRUE.ToString());
                        string Uid = string.Empty;
                        if (string.IsNullOrEmpty(model.IsMarkedToSelf)) { Uid = model.VerifierCode; }
                        else { Uid = Utility.SelectColumnsValue("dbo.UserMaster", "Uid", "UserId", Sessions.getEmployeeUser().UserId.ToString())[0]; }

                        Qry = "update dgen.lbrliftinspectionmaster set WhetherActive=@WhetherActive where ApplicationNo=@ApplicationNo and exists (select ApplicationNo from dgen.lbrliftinspectionmaster where ApplicationNo=@ApplicationNo)";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.FALSE.ToString());

                        CmdInfo = new CMDInfoList();
                        CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
                        cmdInfoList.Add(CmdInfo);

                        Qry = "insert into dgen.lbrliftinspectionmaster (ApplicationNo,InspectedBy,MarkedBy,MarkedOn,WhetherInspected,WhetherActive,UserId,ipaddress) values(@ApplicationNo,@InspectedBy,@userid,now(),@WhetherInspected,@WhetherActive,@userid,@ipaddress);SELECT currval(pg_get_serial_sequence('dgen.lbrliftinspectionmaster','inspectionid'))";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@InspectedBy", Uid);
                        Cmd.Parameters.AddWithValue("@WhetherInspected", CustomText.FALSE.ToString());
                        Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());

                        CmdInfo = new CMDInfoList();
                        CmdInfo.Cmd = Cmd; CmdInfo.Returns = true; CmdInfo.ParamenterIndex = null;
                        cmdInfoList.Add(CmdInfo);

                        if (!string.IsNullOrEmpty(model.IsMarkedToSelf))
                        {
                            model.ApplicationDetails.ApplicationStatusId = ((int)Status.INSPEND).ToString();
                        }
                        if (model.ServiceCode.Equals(((int)ServiceList.CEA1).ToString()) && string.IsNullOrEmpty(model.IsMarkedToSelf))//changes1005
                        {
                            foreach (var item in model.verifierId)
                            {
                                if (item.ToString() != Uid)
                                {
                                    Qry = "INSERT INTO dgen.lbradditionalverifierdetails(inspectionid, inspectedby, userid,ipaddress, lastactiondatetime)VALUES (@Parameter1, @inspectedby, @userid, @ipaddress, now());";
                                    Cmd = new NpgsqlCommand(Qry);
                                    Cmd.Parameters.AddWithValue("@inspectedby", item);
                                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());

                                    CmdInfo = new CMDInfoList();
                                    CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = new int[] { 1 };
                                    cmdInfoList.Add(CmdInfo);
                                }
                            }

                        }

                        CmdInfo = new CMDInfoList();
                        CmdInfo.Cmd = Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG045, null, (int)ApplicationSource.Window, null);
                        CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
                        cmdInfoList.Add(CmdInfo);
                        // cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG045, null, (int)ApplicationSource.Window, null));

                        if (model.ServiceCode.Equals(((int)ServiceList.GrantOfPassengerLift).ToString()) || model.ServiceCode.Equals(((int)ServiceList.RenewalOfPassengerLift).ToString()))
                        {
                            //send sms to applicant and insert record in table
                            Dictionary<string, string> smsDic = new Dictionary<string, string>();
                            smsDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);

                            CmdInfo = new CMDInfoList();
                            CmdInfo.Cmd = Utility.ApplicationProcessSms((int)SmsSendType.SMS027, smsDic); CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
                            cmdInfoList.Add(CmdInfo);
                        }
                        Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                        Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        CmdInfo = new CMDInfoList();
                        CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
                        cmdInfoList.Add(CmdInfo);

                        Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                        Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationDetails.ApplicationNo, Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId), (int)CountList.Type001, DB.LS.ToString()));
                        Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        CmdInfo = new CMDInfoList();
                        CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
                        cmdInfoList.Add(CmdInfo);

                        data.SaveTransactionalDataCustom(cmdInfoList);
                    }
                    else
                    {
                        return RedirectToAction("UnauthorizedRequest", "Error");
                    }                    
                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREJ).ToString())
                {
                    //BypassPermission = true;
                    string ReasonOfRejection = model.ApplicationDetails.ApplicationRemarks;
                    if (model.ApplicationDetails.RejectionReasonCode != ((int)RejectionReason.Other).ToString()) { ReasonOfRejection = Utility.SelectColumnsValue("dbo.reasonmaster", "reasondetail", "reasoncode", model.ApplicationDetails.RejectionReasonCode)[0]; }

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG003, ReasonOfRejection, (int)ApplicationSource.Window, null));

                    //send sms to applicant and insert record in table
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    smsDic.Add("ParamRemarks", ReasonOfRejection);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS005, smsDic));

                    //send email to applicant and insert record in table
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS005).ToString());
                    EmailDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    EmailDic.Add("ParamRemarks", ReasonOfRejection);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }

                    Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                    Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                    Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationDetails.ApplicationNo, Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId), (int)CountList.Type001, DB.LS.ToString()));
                    Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    data.SaveData(cmdList);
                }
                //if (!BypassPermission)
                //{
                //    if (!Utility.CheckCurrentStatusBeforeUpdate(model.ApplicationDetails.ApplicationNo, Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId), (int)CountList.Type001))
                //    {
                //        ViewData["message"] = "Application is not pending at this level anymore!";
                //        return View("message");
                //    }
                //}



                string actionMessage = "Selected application has been processed successfully.";
                if (model.ServiceCode.Equals(((int)ServiceList.GrantOfPassengerLift).ToString()) || model.ServiceCode.Equals(((int)ServiceList.RenewalOfPassengerLift).ToString()) || model.ServiceCode.Equals(((int)ServiceList.CEA1).ToString())  || model.ServiceCode.Equals(((int)ServiceList.CEA2).ToString()) || model.ServiceCode.Equals(((int)ServiceList.CEA3).ToString()))
                {
                    if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.INSPEND).ToString()) { actionMessage = "Application has been sent for inspection.!!! Go To Service Specific to complete inspection."; }
                }
                PreserveModelState(Constant._ActionMessage, actionMessage, false, true);

                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.TEHSPEN).ToString() });
                return RedirectToAction("PendingDecsionSummaryLD", new { q = QueryString });
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PendingApplicationDecisionDetailsLD", (DecisionModels)TempData[Constant._ModelStateParent]);
        }
        [Authorize(Roles = "103,104,114,123,124")]
        [EncryptedActionParameter]
        public ActionResult PendingInspectionList(int sid)
        {
            string value = string.Empty;

            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            string WhetherCondition = string.Empty;
            string Qry = "select to_char(VD.markedon,'DD/MM/YYYY') as MarkedOn,AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId left outer join (select applicationno,markedon from dgen.lbrliftinspectionmaster where whetheractive=true) VD on VD.ApplicationNo=AD.ApplicationNo where DM.deptcode=@ParamDeptCode and AD.ServiceCode=@ServiceCode  and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.AcceptedBy in (@AcceptedBy) and AD.ApplicationStatusId=@ApplicationStatusId  order by VD.MarkedOn";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", sid);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.INSPEND);
            cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            model.data = data.GetDataTable(cmd);
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        #endregion

        #region decision method for construction workers and Welfare board
        [Authorize(Roles = "103")]
        [EncryptedActionParameter]
        public ActionResult PendingDecsionSummaryBoard(int sid)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();

            //string WhetherCondition = string.Empty;
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition = " and AD.OfficeCode in (@ParamAuthorizationId)  and AD.AcceptedBy in (@AcceptedBy)"; }
            //else { WhetherCondition = " and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.OfficeCode=@OfficeCode  and AD.AcceptedBy in (@AcceptedBy)"; }

            string addScript = Utility.GetScriptForAuthorizationProcess();

            //string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@ApplicationSourceId then 1 end),0) as atCSC,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as atOnline from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode " + WhetherCondition + " and AD.ServiceCode in (@ParamServiceCode) group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@ApplicationSourceId then 1 end),0) as atCSC,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as atOnline from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode)  and AD.AcceptedBy in (@AcceptedBy) " + addScript + " group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@ApplicationSourceId", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            model.data = data.GetDataTable(cmd);
            model.StatusId = sid.ToString();

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "103")]
        [EncryptedActionParameter]
        //public ActionResult PendingDecsionListBoard(int subDiv, int service, int status, string Value, int? SourceId)
        public ActionResult PendingDecsionListBoard(int service, int status, int? SourceId)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();

            //string value = string.Empty;
            //if (SourceId != null) { value += " and ApplicationSourceId=@ApplicationSourceId"; }
            //string WhetherCondition = string.Empty;
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition = " and AD.OfficeCode in (@ParamAuthorizationId)  and AD.AcceptedBy in (@AcceptedBy)"; }
            //else { WhetherCondition = " and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.OfficeCode=@OfficeCode  and AD.AcceptedBy in (@AcceptedBy)"; }

            string addScript = Utility.GetScriptForAuthorizationProcess();
            if (SourceId != null) { addScript += " and AD.ApplicationSourceId=@ApplicationSourceId"; }

            //string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where DM.deptcode=@ParamDeptCode and AD.ServiceCode=@ServiceCode " + WhetherCondition + " and AD.ApplicationStatusId=@ApplicationStatusId " + value + " order by AD.applicationdate";
            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where DM.deptcode=@ParamDeptCode and AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId and AD.AcceptedBy in (@AcceptedBy) " + addScript + " order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            //cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", status);
            if (SourceId != null) { cmd.Parameters.AddWithValue("@ApplicationSourceId", SourceId); }
            cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [Authorize(Roles = "103")]
        [EncryptedActionParameter]
        public ActionResult PendingApplicationDecisionDetailsBoard(Int64 AppNo, int? Source = 0)
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }

            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();
            if (Source != 0) { model.Source = Source.ToString(); }

            //string WhetherCondition = string.Empty, DisplayMessage = string.Empty;
            //string[] Values = Utility.GetServiceCode(Convert.ToInt64(model.ApplicationDetails.ApplicationNo));
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition = " and OfficeCode in (@ParamAuthorizationId)  and AcceptedBy in (@AcceptedBy)"; }
            //else { WhetherCondition = " and ApplicationSubdivCode in (@ParamSubDivCode) and OfficeCode=@OfficeCode and AcceptedBy in (@AcceptedBy)"; }

            string addScript = Utility.GetScriptForAuthorizationProcess();

            string Qry = "select AD.ServiceCode,AD.ApplicationStatusId from dbo.ApplicationDetails AD inner join servicemaster SM on SM.ServiceCode=AD.ServiceCode where AD.ApplicationNo=@ApplicationNo and SM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) and AD.AcceptedBy in (@AcceptedBy) " + addScript;
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //Cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            string[] GetValues = data.SelectColumns(Cmd);
            model.ApplicationDetails.ServiceCode = GetValues[0];
            model.ApplicationDetails.ApplicationStatusId = GetValues[1];

            Dictionary<string, string> ValidateData = new Dictionary<string, string>();
            ValidateData.Add("ApplicationNo", model.ApplicationDetails.ApplicationNo);
            string[] ValidationCheck = Utility.ApplicationValidation(ValidateData, (int)ValidationCheckLevels.DecisionProcessGeneralGet, false);
            if (ValidationCheck[0] == ((int)CountList.Type001).ToString())
            {
                PreserveModelState(Constant._ActionMessage, ValidationCheck[1], false, true);
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId) });
                return RedirectToAction("SearchAppForDecision", new { q = QueryString });
            }
            else if (ValidationCheck[0] == ((int)CountList.Type002).ToString())
            {
                ViewData["message"] = ValidationCheck[1];
                return View("message");
            }

            Qry = "select documentstatusid from web.registrationmaster RM left outer join dbo.applicationdetails AD on RM.RegistrationId=AD.RegistrationId where AD.ApplicationNo=@ApplicationNo and RM.DocumentId in (@AadhaarCard,@VoterID)";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@AadhaarCard", ((int)DocumentId.AadhaarCard).ToString());
            Cmd.Parameters.AddWithValue("@VoterID", ((int)DocumentId.VoterID).ToString());
            model.DocumentStatusId = data.SelectColumns(Cmd)[0];

            string flag = Utility.SelectColumnsValue("dbo.VerifierVerificationReport", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
            if (string.IsNullOrEmpty(flag)) { model.WhetherVerification = false; } else { model.WhetherVerification = true; }

            Qry = "select UM.UID,UM.UserName from UserMaster UM inner join UserToSubDivMaster SDM on SDM.Uid=UM.Uid where UM.DistrictCode=@DistrictCode and SDM.SubDivCode in (@ParamSubDivCode) and UM.Permission=@Permission";
            Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@DistrictCode", Sessions.getEmployeeUser().DistrictCode);
            Cmd.Parameters.AddWithValue("@Permission", Convert.ToString((int)Permission.VERF));
            model.VerifierMaster = new SelectList(UserMaster.List<UserMaster>(Cmd), "UID", "UserName");

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.VerifierVerificationDetails = Utility.GetVerifierVerificationDetails(model.ApplicantDetails.ApplicationNo);
            model.VerifierWitnessMaster = Utility.GetVerifierWitnessMasterDetails(model.ApplicantDetails.ApplicationNo);

            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data1 = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data2 = Utility.GetServiceSpecificVerificationDetails(model.ApplicationDetails.ApplicationNo);
            model.data3 = Utility.GetObjectionDetails(model.ApplicantDetails.ApplicationNo.ToString());
            model.data4 = Utility.GetApplicationAuditTrail(model.ApplicantDetails.ApplicationNo);
            model.data5 = Utility.GetApplicantAvailedService(model.ApplicantDetails.RegistrationId.ToString());
            model.data6 = Utility.GetSingleDocVerificationStatus(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.data9 = Utility.GetPaymentDetails(model.ApplicationDetails.ApplicationNo);
            model.data10 = Utility.GetLBRChallanStatus(model.ApplicationDetails.ApplicationNo, model.ApplicationDetails.ServiceCode);
            model.data8 = Utility.GetMobileSahayakDetailsData(model.ApplicationDetails.ApplicationNo);

            model.IsAlreadyVerified = Utility.SelectColumnsValue("dbo.VerifierApplicationDetails", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
            model.WhetherDocVerified = Utility.CheckWhetherDocVerify(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.WhetherVerificationLetterRequired = false;


            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.ConstructionWorker)
            {
                model.ApplicationDetailsConsWorker = Utility.GetConsWorkerDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());

                Qry = "select username,to_char(actiondate,'DD/MM/YYYY HH:MM:SS') as actiondate,ipaddress from departmentaudittrail dat inner join usermaster um on dat.actionby=um.userid where applicationno=@applicationno and actionmessageid=@actionmessageid";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@actionmessageid", (int)CountList.Type008);
                model.data11 = data.GetDataTable(Cmd);
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.RenewalConsWorker)
            {
                model.RenewalConsWorker = Utility.GetRenewalConsWorkerDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.DeathBenefits)
            {
                model.ApplicationDetailsDeathBenefits = Utility.GetDeathBenefitsActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsDeathBenefits.WorkerRegNo);
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.FuneralBenefit)
            {
                model.ApplicationDetailsFuneralBenefit = Utility.GetFuneralBenefitActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsFuneralBenefit.WorkerRegNo);
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.FamilyPension)
            {
                model.ApplicationDetailsFamilyPension = Utility.GetFamilyPensionActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsFamilyPension.WorkerRegNo);
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MarriageAssistance)
            {
                model.ApplicationDetailsMarriageAssistance = Utility.GetMarriageAssistanceActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsMarriageAssistance.WorkerRegNo);
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.EduScholarship)
            {
                model.ApplicationDetailsEduScholarship = Utility.GetEduScholarshipActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsEduScholarship.WorkerRegNo);
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MedicalAssistance)
            {
                model.ApplicationDetailsMedicalAssistance = Utility.GetMedicalAssistanceActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsMedicalAssistance.WorkerRegNo);
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.HBA)
            {
                model.ApplicationDetailsHBA = Utility.GetHBAActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsHBA.WorkerRegNo);
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.DisabilityPension)
            {
                model.ApplicationDetailsDisabilityPension = Utility.GetDisabilityPensionActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsDisabilityPension.WorkerRegNo);
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Pension)
            {
                model.ApplicationDetailsPension = Utility.GetPensionActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsPension.WorkerRegNo);
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MaternityBenefit)
            {
                model.ApplicationDetailsMaternityBenefit = Utility.GetMaternityBenefitActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsMaternityBenefit.WorkerRegNo);
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.GrantofWork)
            {
                model.ApplicationDetailsGrantofWork = Utility.GetGrantofWorkActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsGrantofWork.WorkerRegNo);
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.InstrumentLoan)
            {
                model.ApplicationDetailsInstrumentLoan = Utility.GetInstrumentLoanActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsInstrumentLoan.WorkerRegNo);
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.ExGratia)
            {
                model.ApplicationDetailsExgratia = Utility.GetApplicationDetailsExGratia(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());

            }
            else
            {
                return RedirectToAction("BadRequest", "Error");
            }

            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [Authorize(Roles = "103")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingApplicationDecisionDetailsBoard(DecisionModels model, FormCollection frm)
        {
            model.ServiceCode = Utility.SelectColumnsValue("ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0];
            model.DeptCode = Utility.GetDeptCode(model.ServiceCode);

            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string QueryString = string.Empty, Qry = string.Empty;


                Dictionary<string, string> ValidateData = new Dictionary<string, string>();
                ValidateData.Add("ApplicationNo", model.ApplicationDetails.ApplicationNo);
                string[] ValidationCheck = Utility.ApplicationValidation(ValidateData, (int)ValidationCheckLevels.DecisionProcessGeneralPost, false);
                if (ValidationCheck[0] == ((int)CountList.Type001).ToString())
                {
                    PreserveModelState(Constant._ActionMessage, ValidationCheck[1], false, true);
                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                    return RedirectToAction("PendingApplicationDecisionDetailsBoard", "Decision", new { q = QueryString });
                }
                else if (ValidationCheck[0] == ((int)CountList.Type002).ToString())
                {
                    ViewData["message"] = ValidationCheck[1];
                    return View("message");
                }


                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREC).ToString())
                {
//                    if (model.ServiceCode == ((int)ServiceList.ConstructionWorker).ToString())
//                    {

//                        Qry = @"INSERT INTO applicationdetailsregvalidity(applicationno, regdate, renewaldate, expirydate, userid,ipaddress, actiondatetime)
//                                         (select applicationno,case when whetherregisterworker=false and whetheruploadvolunteerdata=false then now()  -- fresh
//                                        when whetherregisterworker=true and whetheruploadvolunteerdata=false then registrationdate  --renewal
//                                        when whetherregisterworker=true and whetheruploadvolunteerdata=true then registrationdate end as regdate, --volunteer
//                                        case when whetherregisterworker=false and whetheruploadvolunteerdata=false then now()  -- fresh
//                                        when whetherregisterworker=true and whetheruploadvolunteerdata=false then now()  --renewal
//                                        when whetherregisterworker=true and whetheruploadvolunteerdata=true then lastrenewaldate end as renewaldate, --volunteer
//                                        case when whetherregisterworker=false and whetheruploadvolunteerdata=false then now() + interval ' 1 year'  -- fresh
//                                        when whetherregisterworker=true and whetheruploadvolunteerdata=false then lastexpregistration + interval  '1 year'  --renewal
//                                        when whetherregisterworker=true and whetheruploadvolunteerdata=true then lastexpregistration end as expirydate, --volunteer
//                                        @userid as userid,@ipaddress as ipaddress, now() as actiondatetime
//                                        from dgen.applicationdetailsregconstructionworker where applicationno=@applicationno);";
//                        Cmd = new NpgsqlCommand(Qry);
//                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
//                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
//                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
//                        cmdList.Add(Cmd);

//                        data.SaveData(cmdList);

//                    }
//                    else if (model.ServiceCode == ((int)ServiceList.RenewalConsWorker).ToString())
//                    {
//                        string registrationno = Utility.SelectColumnsValue("dgen.applicationdetailsrenewalconsworker", "registrationno", "applicationno", model.ApplicationDetails.ApplicationNo)[0];
//                        Qry = @"update applicationdetailsregvalidity set renewaldate=now(),expirydate=(expirydate + interval '1 year'),userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where applicationno=@registrationno;";
//                        Cmd = new NpgsqlCommand(Qry);
//                        Cmd.Parameters.AddWithValue("@registrationno", registrationno);
//                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
//                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
//                        cmdList.Add(Cmd);

//                        data.SaveData(cmdList);
//                    }



                    // Delete existing records of same application from temp table
                    if (model.ServiceCode == ((int)ServiceList.ConstructionWorker).ToString())
                    {
                        Cmd = Utility.InsertAndUpdateConstructionWorker(Convert.ToInt64(model.ApplicationDetails.ApplicationNo), Convert.ToInt32(model.ServiceCode), true);
                        if (Cmd != null) { cmdList.Add(Cmd); }
                    }

                    // set flag to false for further processing
                    cmdList.Add(Utility.InsertAndUpdateConstructionWorker(Convert.ToInt64(model.ApplicationDetails.ApplicationNo), Convert.ToInt32(model.ServiceCode)));

                    data.SaveData(cmdList);

                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                    return RedirectToAction("ProcessApplicationApprovalRequest", "Sign", new { q = QueryString });
                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREJ).ToString())
                {
                    //BypassPermission = true;
                    string ReasonOfRejection = model.ApplicationDetails.ApplicationRemarks;
                    if (model.ApplicationDetails.RejectionReasonCode != ((int)RejectionReason.Other).ToString()) { ReasonOfRejection = Utility.SelectColumnsValue("dbo.reasonmaster", "reasondetail", "reasoncode", model.ApplicationDetails.RejectionReasonCode)[0]; }

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG003, ReasonOfRejection, (int)ApplicationSource.Window, null));

                    //send sms to applicant and insert record in table
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    smsDic.Add("ParamRemarks", ReasonOfRejection);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS005, smsDic));

                    //send email to applicant and insert record in table
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS005).ToString());
                    EmailDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    EmailDic.Add("ParamRemarks", ReasonOfRejection);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }

                    Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                    Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                    Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationDetails.ApplicationNo, Convert.ToInt32(model.ApplicationDetails.ApplicationStatusId), (int)CountList.Type001, DB.LS.ToString()));
                    Cmd.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    data.SaveData(cmdList);
                }
                else
                {
                    return RedirectToAction("UnauthorizedRequest", "Error");
                }

                string actionMessage = "Selected application has been processed successfully.";
                PreserveModelState(Constant._ActionMessage, actionMessage, false, true);
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.TEHSPEN).ToString() });
                return RedirectToAction("PendingApplicationDecisionDetailsBoard", new { q = QueryString });
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PendingApplicationDecisionDetailsBoard", (DecisionModels)TempData[Constant._ModelStateParent]);
        }
        #endregion

        #region decision methods for DM
        [Authorize(Roles = "106,104,114,115")]
        [EncryptedActionParameter]
        public ActionResult PendingDMDecsionSummary(int sid)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            string cond = string.Empty;
            if (string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { cond = "  and AD.applicationdistrictcode = @ParamDistrictCode "; } else { cond = "  and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            string Qry = "select SC.ServiceName,SC.ServiceCode,coalesce(sum(case when ApplicationStatusId in (@ApplicationStatusId) then 1 end),0) as Before  from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode left outer join dgen.applicationinspectiondetails  AI on AI.ApplicationNo=AD.ApplicationNo  where DM.deptcode=@ParamDeptCode " + cond + " and AI.cid is null ";
            if (sid == (int)Status.OBSPEND || sid == (int)Status.OBSPEN2) { Qry += "  and  AD.ServiceCode in(@Provisional) "; }
            else if (sid == (int)Status.STRTINS) { Qry += " and  AD.ServiceCode in (@Renewal,@Fresh) "; }
            else { Qry += "  and  AD.ServiceCode  in (@Renewal,@Fresh,@Provisional) "; }
            Qry += "  group by SC.ServiceName,SC.ServiceCode order by SC.ServiceName ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@Provisional", (int)ServiceList.ProvisionalCinema);
            cmd.Parameters.AddWithValue("@Renewal", (int)ServiceList.RenewalCinemaLicense);
            cmd.Parameters.AddWithValue("@Fresh", (int)ServiceList.FreshCinemaLicense);
            model.data = data.GetDataTable(cmd);
            model.StatusId = sid.ToString();

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "106,104,114,115")]
        [EncryptedActionParameter]
        public ActionResult PendingDMDecsionList(int service, int status)
        {
            string value = string.Empty;
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            string cond = string.Empty;
            if (string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { cond = "  and AD.applicationdistrictcode = @ParamDistrictCode "; } else { cond = "  and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId left outer join dgen.applicationinspectiondetails  AI on AI.ApplicationNo=AD.ApplicationNo  where DM.deptcode=@ParamDeptCode and AD.applicationdistrictcode = @ParamDistrictCode and AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId " + cond + " and AI.cid is null  order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", status);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [Authorize(Roles = "106,104,115")]
        [EncryptedActionParameter]
        public ActionResult PendingDMApplicationDecisionDetails(Int64 AppNo, int? Source = 0)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();
            if (Source != 0) { model.Source = Source.ToString(); }

            string Qry = "select ServiceCode,ApplicationStatusId from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ServiceCode in (@ParamServiceCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            string[] GetValues = data.SelectColumns(Cmd);

            model.ApplicationDetails.ServiceCode = GetValues[0];
            model.ApplicationDetails.ApplicationStatusId = GetValues[1];
            if (model.ApplicationDetails.ApplicationStatusId != ((int)Status.TEHSPEN).ToString() && model.ApplicationDetails.ApplicationStatusId != ((int)Status.STRTINS).ToString() && model.ApplicationDetails.ApplicationStatusId != ((int)Status.OBSPEND).ToString() && model.ApplicationDetails.ApplicationStatusId != ((int)Status.TEHSOBJ).ToString())
            {
                PreserveModelState(Constant._ActionMessage, "Application Not Found, Kindly Check Your Application No.", false, true);
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.ApplicationDetails.ApplicationStatusId });
                return RedirectToAction("SearchAppForAction", new { q = QueryString });
            }

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.data = Utility.GetEnclosureDetails(string.Empty, string.Empty, string.Empty, string.Empty, model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            ViewData[KeyName._Key01] = Utility.GetPhotoDetails(string.Empty, string.Empty, string.Empty, string.Empty, model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data2 = Utility.GetServiceSpecificVerificationDetails(model.ApplicationDetails.ApplicationNo);
            model.data3 = Utility.GetObjectionDetails(model.ApplicantDetails.ApplicationNo.ToString());
            model.data4 = Utility.GetApplicationAuditTrail(model.ApplicantDetails.ApplicationNo);
            model.IsAlreadyVerified = Utility.SelectColumnsValue("dbo.VerifierApplicationDetails", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
            model.WhetherVerificationLetterRequired = false;

            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.ProvisionalCinema || Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.FreshCinemaLicense || Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.RenewalCinemaLicense)
            {
                model.ApplicationDetailsCinematograph = Utility.GetProvisionalCinemaDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.ApplicationInspectionDetails = Utility.GetCinemaInspectionDetails(model.ApplicantDetails.ApplicationNo.ToString(), ((int)CountList.Type001).ToString());
                model.ApplicationInspectionDetails.TMCounter = "4";
            }

            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [Authorize(Roles = "106,104,115")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingDMApplicationDecisionDetails(DecisionModels model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string QueryString = string.Empty;
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                if (model.ApplicationDetails.ApplicationStatusId != ((int)Status.NOTIACT).ToString() && model.ApplicationDetails.ApplicationStatusId != ((int)Status.TEHSREC).ToString() && model.ApplicationDetails.ApplicationStatusId != ((int)Status.TEHSPEN).ToString() && model.ApplicationDetails.ApplicationStatusId != ((int)Status.TEHSOBJ).ToString() && model.ApplicationDetails.ApplicationStatusId != ((int)Status.STRTINS).ToString())
                {
                    return RedirectToAction("BadRequest", "Error");
                }

                int SigningTypeId = Convert.ToInt32(Utility.SelectColumnsValue("dbo.usermaster", "signingtypeid", "UserId", Sessions.getEmployeeUser().UserId)[0]);
                if (SigningTypeId != (int)ValueId.SignDigital)
                {
                    ViewBag.DisplayMessage = "You need to be digitally signed in to take action on this application.";
                    PreserveModelState(Constant._ModelStateParent, null, true, false);
                    return View("PendingDMApplicationDecisionDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
                }

                model.ServiceCode = Utility.SelectColumnsValue("ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0];
                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREC).ToString())
                {
                    if (model.ServiceCode.Equals(((int)ServiceList.ProvisionalCinema).ToString()) || model.ServiceCode.Equals(((int)ServiceList.FreshCinemaLicense).ToString()) || model.ServiceCode.Equals(((int)ServiceList.RenewalCinemaLicense).ToString()))//change20151013
                    {
                        if (model.ServiceCode == ((int)ServiceList.FreshCinemaLicense).ToString())
                        {
                            NpgsqlCommand updCmd = new NpgsqlCommand("insert into dgen.ApplicationDetailsExistingCinema (LicenceNo,CinemaName,CinemaOwnerName,CinemaAddress,LocalityId,DistrictCode,NoOfScreens,LicenceGrantDate,LastInspectionDate,StatusId,UserId,IpAddress,ActionDateTime) select @LicenceNo,CinemaName,CinemaOwner,CinemaAddress,CinemaLocalityId,SD.DistrictCode,NoOfScreens,now(),now(),@StatusId,@UserId,@IpAddress,now() from dgen.applicationdetailscinematograph AC inner join localitytosubdivmaster LTS on LTS.localityid=AC.cinemalocalityid inner join subdivmaster SD on SD.subdivcode=LTS.subdivcode inner join districtmaster DM on DM.districtcode=SD.districtcode and DM.deptcode=@deptcode where ApplicationNo=@LicenceNo");
                            updCmd.Parameters.AddWithValue("@LicenceNo", model.ApplicationDetails.ApplicationNo);
                            updCmd.Parameters.AddWithValue("@UserId", Utility.SelectColumnsValue("dbo.ApplicationDetails", "RegistrationId", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0]);
                            updCmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                            updCmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                            updCmd.Parameters.AddWithValue("@StatusId", (int)ValueId.CinemaInspectionComplete);
                            cmdList.Add(updCmd);
                        }
                        data.SaveData(cmdList);
                        QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                        //return RedirectToAction("InitializeRecordSign", "Sign", new { q = QueryString });
                        return RedirectToAction("ProcessApplicationApprovalRequest", "Sign", new { q = QueryString });
                    }
                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.STRTINS).ToString())
                {
                    if (model.ServiceCode.Equals(((int)ServiceList.FreshCinemaLicense).ToString()) || model.ServiceCode.Equals(((int)ServiceList.RenewalCinemaLicense).ToString()))//change169
                    {
                        string Qry = string.Empty;
                        NpgsqlCommand Cmd = new NpgsqlCommand();
                        NpgsqlCommand updCmd = new NpgsqlCommand(@"insert into dgen.ApplicationInspectionDetails (ApplicationNo,InspectionDate,InspectionTypeId,WhetherActive,WhetherInspected,PreInspectionRemarks,UserId,IpAddress,Actiondatetime) values (@ApplicationNo,@InspectionDate,@InspectionTypeId,@WhetherActive,@WhetherInspected,@PreInspectionRemarks,@UserId,@IpAddress,now()); SELECT currval(pg_get_serial_sequence('dgen.applicationinspectiondetails','inspectionid'))");
                        updCmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        updCmd.Parameters.AddWithValue("@InspectionDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDate, '/', "0/1/2"));
                        updCmd.Parameters.AddWithValue("@InspectionTypeId", (int)InspectionTypeId.Fresh);
                        updCmd.Parameters.AddWithValue("@PreInspectionRemarks", model.ApplicationInspectionDetails.PreInspectionRemarks);
                        updCmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                        updCmd.Parameters.AddWithValue("@WhetherInspected", CustomText.False.ToString());
                        updCmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                        updCmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                        cmdList.Add(updCmd);

                        int varTMCount = Convert.ToInt16(model.ApplicationInspectionDetails.TMCounter);
                        for (int i = 1; i <= varTMCount; i++)
                        {
                            if ((frm["ApplicationInspectionDetails.TValueId" + i] == null) && (frm["TName" + i] == null) && (frm["TDesignation" + i] == null) && (frm["TOAddress" + i] == null) && (frm["TContact" + i] == null) && (frm["TAName" + i] == null) && (frm["TAAddress" + i] == null))
                            {
                                //code here
                            }
                            else
                            {
                                ViewData["TValueId" + i] = frm["ApplicationInspectionDetails.TValueId" + i].ToString();
                                ViewData["TName" + i] = frm["TName" + i].ToString();
                                ViewData["TDesignation" + i] = frm["TDesignation" + i].ToString();
                                ViewData["TOAddress" + i] = frm["TOAddress" + i].ToString();
                                ViewData["TContact" + i] = frm["TContact" + i].ToString();
                                ViewData["TAName" + i] = frm["TAName" + i].ToString();
                                ViewData["TAAddress" + i] = frm["TAAddress" + i].ToString();

                                if ((string.IsNullOrEmpty(frm["ApplicationInspectionDetails.TValueId" + i].ToString())) || (string.IsNullOrEmpty(frm["TName" + i].ToString())) || (string.IsNullOrEmpty(frm["TDesignation" + i].ToString())) || (string.IsNullOrEmpty(frm["TOAddress" + i].ToString())) || (string.IsNullOrEmpty(frm["TContact" + i].ToString())) || (string.IsNullOrEmpty(frm["TAName" + i].ToString())) || (string.IsNullOrEmpty(frm["TAAddress" + i].ToString())))
                                {
                                    model.ApplicationInspectionDetails.TMCounter = i.ToString();
                                    PreserveModelState(Constant._ModelStateParent, null, true, false);
                                    return View((DecisionModels)TempData[Constant._ModelStateParent]);
                                }

                                Qry = "INSERT INTO dgen.inspectionteammemberdetails(InspectionId,AuthorityTypeId,OfficerName,OfficerDesignation,OfficerContactNo,OfficerAddress,AuthorityName,AuthorityAddress,UserId,Ipaddress,lastactiondate)values(@LastInsertedId,@AuthorityTypeId,@OfficerName,@OfficerDesignation,@OfficerContactNo,@OfficerAddress,@AuthorityName,@AuthorityAddress,@UserId,@Ipaddress,now())";
                                Cmd = new NpgsqlCommand(Qry);
                                Cmd.Parameters.AddWithValue("@AuthorityTypeId", frm["ApplicationInspectionDetails.TValueId" + i].ToString());
                                Cmd.Parameters.AddWithValue("@OfficerName", frm["TName" + i].ToString());
                                Cmd.Parameters.AddWithValue("@OfficerDesignation", frm["TDesignation" + i].ToString());
                                Cmd.Parameters.AddWithValue("@OfficerContactNo", frm["TContact" + i].ToString());
                                Cmd.Parameters.AddWithValue("@OfficerAddress", frm["TOAddress" + i].ToString());
                                Cmd.Parameters.AddWithValue("@AuthorityName", frm["TAName" + i].ToString());
                                Cmd.Parameters.AddWithValue("@AuthorityAddress", frm["TAAddress" + i].ToString());
                                Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                cmdList.Add(Cmd);
                            }

                        }

                        updCmd = new NpgsqlCommand(@"update dgen.ApplicationInspectionDetails set WhetherActive=@WhetherActive,UserId=@UserId,IpAddress=@IpAddress,Actiondatetime=now() where ApplicationNo=@ApplicationNo and InspectionId<>@LastInsertedId");
                        updCmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        updCmd.Parameters.AddWithValue("@WhetherActive", CustomText.False.ToString());
                        updCmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                        updCmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                        cmdList.Add(updCmd);

                        string[] GV = Utility.SelectColumnsValue("dgen.applicationdetailscinematograph", "noofscreens,CinemaAddress", "ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        Int32 NoOfScreens = Convert.ToInt32(GV[0]);
                        string CinemaAddr = GV[1].Trim();

                        for (int i = 1; i <= NoOfScreens; i++)
                        {
                            updCmd = new NpgsqlCommand(@"insert into dgen.InspectionDetails (InspectionId,ScreenNo,UserId,IpAddress,Actiondatetime) values (@LastInsertedId,@ScreenNo,@UserId,@IpAddress,now())");
                            updCmd.Parameters.AddWithValue("@ScreenNo", i);
                            updCmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                            updCmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                            cmdList.Add(updCmd);
                        }

                        cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG035, "Inspection Date Selected: " + model.ApplicationInspectionDetails.InspectionDate, (int)ApplicationSource.Window, null));

                        //send sms to applicant and insert record in table
                        Dictionary<string, string> smsDic = new Dictionary<string, string>();
                        smsDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                        smsDic.Add("ParamDate", model.ApplicationInspectionDetails.InspectionDate);
                        smsDic.Add("ParamAddress", CinemaAddr);
                        cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS023, smsDic));
                        model.ApplicationDetails.ApplicationStatusId = ((int)Status.INSPEND).ToString();

                        //send email to applicant and insert record in table
                        Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                        EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                        EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS023).ToString());
                        EmailDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                        EmailDic.Add("ParamDate", model.ApplicationInspectionDetails.InspectionDate);
                        EmailDic.Add("ParamAddress", CinemaAddr);
                        NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                        if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                    }
                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSPEN).ToString())
                {
                    string Qry = "update dgen.ApplicationInspectionDetails set RectificationRemarks=@ApplicationRemarks where ApplicationNo=@ApplicationNo and WhetherActive=@WhetherActive";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                    cmdList.Add(Cmd);

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, model.ApplicationDetails.ApplicationRemarks, (int)ApplicationSource.Window, null));
                    model.ApplicationDetails.ApplicationRemarks = string.Empty;
                }
                string Qry1 = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                NpgsqlCommand Cmd1 = new NpgsqlCommand(Qry1);
                Cmd1.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                Cmd1.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd1.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                Cmd1.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                Cmd1.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd1.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd1);

                Qry1 = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,RejectionReasonCode=@RejectionReasonCode,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                Cmd1 = new NpgsqlCommand(Qry1);
                Cmd1.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationDetails.ApplicationStatusId);
                Cmd1.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd1.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                Cmd1.Parameters.AddWithValue("@RejectionReasonCode", model.ApplicationDetails.RejectionReasonCode);
                Cmd1.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd1.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd1);


                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREJ).ToString())
                {
                    string ReasonOfRejection = model.ApplicationDetails.ApplicationRemarks;
                    if (model.ApplicationDetails.RejectionReasonCode != ((int)RejectionReason.Other).ToString()) { ReasonOfRejection = Utility.SelectColumnsValue("dbo.reasonmaster", "reasondetail", "reasoncode", model.ApplicationDetails.RejectionReasonCode)[0]; }
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG003, ReasonOfRejection, (int)ApplicationSource.Window, null));

                    //send sms to applicant and insert record in table
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    smsDic.Add("ParamRemarks", ReasonOfRejection);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS005, smsDic));

                    //send email to applicant and insert record in table
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS005).ToString());
                    EmailDic.Add("ParamApplicationNo", model.ApplicationDetails.ApplicationNo);
                    EmailDic.Add("ParamRemarks", ReasonOfRejection);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.INSPEND).ToString())
                {
                    data.SaveTransactionalData(cmdList);
                    PreserveModelState(Constant._ActionMessage, "Selected application has been processed successfully.", false, true);
                    if (model.ServiceCode.Equals(((int)ServiceList.ProvisionalCinema).ToString()))
                    {
                        QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.OBSPEND).ToString() });
                        return RedirectToAction("PendingDMDecsionSummary", new { q = QueryString });
                    }
                    else
                    {
                        QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo.ToString() });
                        return RedirectToAction("PrintCinemaInitiateInspectionLetter", "Print", new { q = QueryString });
                    }
                }
                else if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSPEN).ToString())
                {
                    data.SaveData(cmdList);
                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.TEHSOBJ).ToString() });
                    return RedirectToAction("PendingDMDecsionSummary", new { q = QueryString });
                }
                else
                {
                    return RedirectToAction("BadRequest", "Error");
                }
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PendingDMApplicationDecisionDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
        }
        [Authorize(Roles = "104,114,106,115")]
        [EncryptedActionParameter]
        public ActionResult PendingForInspectionSearch(Int64? AppNo, int? cid)
        {
            GetData data = new GetData();
            string Qry = string.Empty;
            NpgsqlCommand Cmd = new NpgsqlCommand();
            DecisionModels model = new DecisionModels();
            model.ApplicationInspectionDetails = new ApplicationInspectionDetails();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationStatusId = ((int)Status.TEHSREC).ToString();
            if (cid != null)
            {
                Qry = "select * from dgen.applicationdetailsexistingcinema where cid=@cid";
                Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@cid", cid);
                DataTable dt = data.GetDataTable(Cmd);
                if (dt.Rows.Count > 0)
                {
                    Qry = "select InspectionId from dgen.ApplicationInspectionDetails where cid=@cid and whetheractive=@whetheractive ";
                    if (Sessions.getEmployeeUser().Permission == ((int)Permission.DC).ToString()) { Qry += " and whetherdcinspected=@whetherinspected"; }
                    if (Sessions.getEmployeeUser().Permission == ((int)Permission.P114).ToString()) { Qry += " and whetherinspected=@whetherinspected"; }
                    if (Sessions.getEmployeeUser().Permission == ((int)Permission.P115).ToString()) { Qry += " and whethersdminspected=@whetherinspected"; }
                    Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    Cmd.Parameters.AddWithValue("@cid", cid);
                    Cmd.Parameters.AddWithValue("@whetheractive", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@whetherinspected", CustomText.False.ToString());
                    dt = data.GetDataTable(Cmd);
                    if (dt.Rows.Count > 0)
                    {
                        model.ApplicationInspectionDetails = Utility.GetCinemaInspectionDetails(cid.ToString(), ((int)CountList.Type004).ToString());
                        model.ApplicationInspectionDetails.InspectionId = model.ApplicationInspectionDetails.InspectionDetails[0].InspectionId;
                        model.ApplicationInspectionDetails.cid = cid.ToString();
                        model.ApplicationDetailsCinematograph = Utility.GetExistingCinemaDetails(cid.ToString());
                        PreserveModelState(Constant._ModelStateParent, model, true, false);
                        return View((DecisionModels)TempData[Constant._ModelStateParent]);
                    }
                    else
                    {
                        ViewData["message"] = "Inspection CANNOT be filled for this Cinema as the inspection is already COMPLETED or is no longer ACTIVE";
                        return View("Message");
                    }
                }
                else
                {
                    ViewData["message"] = "Cinema doesnot exist in our system.";
                    return View("Message");
                }
            }
            if (AppNo == null) { return View(model); }
            model.ApplicationNo = AppNo.ToString();

            Qry = "select ApplicationStatusId,ServiceCode from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ApplicationDistrictCode in (@ParamDistrictCode)";
            Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            string[] GetValues = data.SelectColumns(Cmd);
            string StatusCheck = GetValues[0];
            model.ServiceCode = GetValues[1];

            Qry = "select WhetherDCInspected from dgen.applicationinspectiondetails where ApplicationNo=@ApplicationNo and WhetherActive=@WhetherActive and WhetherInspected=@WhetherInspected and WhetherSDMInspected=@WhetherSDMInspected and WhetherDCInspected=@WhetherDCInspected";
            Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
            Cmd.Parameters.AddWithValue("@WhetherInspected", CustomText.True.ToString());
            Cmd.Parameters.AddWithValue("@WhetherSDMInspected", CustomText.True.ToString());
            Cmd.Parameters.AddWithValue("@WhetherDCInspected", CustomText.False.ToString());
            string dcCheck = data.SelectColumns(Cmd)[0];

            if (string.IsNullOrEmpty(dcCheck)) { dcCheck = CustomText.FALSE.ToString(); } else { dcCheck = CustomText.TRUE.ToString(); }

            if (model.ServiceCode == ((int)ServiceList.FreshCinemaLicense).ToString() || model.ServiceCode == ((int)ServiceList.RenewalCinemaLicense).ToString())
            {
                if (StatusCheck == ((int)Status.INSPEND).ToString() || (dcCheck == CustomText.TRUE.ToString()))
                {
                    Qry = "select InspectionId from dgen.ApplicationInspectionDetails where ApplicationNo=@ApplicationNo and WhetherInspected=@WhetherInspected and WhetherActive=@WhetherActive";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@WhetherInspected", CustomText.False.ToString());
                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                    GetValues = data.SelectColumns(Cmd);
                    if (!string.IsNullOrEmpty(GetValues[0]) || (dcCheck == CustomText.TRUE.ToString()))
                    {
                        model.ApplicationInspectionDetails = Utility.GetCinemaInspectionDetails(model.ApplicationNo, ((int)CountList.Type002).ToString());
                        model.ApplicationInspectionDetails.InspectionId = model.ApplicationInspectionDetails.InspectionDetails[0].InspectionId;
                        //model.ApplicationInspectionDetails.datatm = model.ApplicationInspectionDetails.InspectionDetails[0].datatm;
                        model.ApplicantDetails = model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationNo, DB.LS.ToString());
                        model.ApplicationDetailsCinematograph = Utility.GetProvisionalCinemaDetails(model.ApplicationNo, DB.LS.ToString());
                        PreserveModelState(Constant._ModelStateParent, model, true, false);
                        return View((DecisionModels)TempData[Constant._ModelStateParent]);
                    }
                    else
                    {
                        ViewBag.DisplayMessage = "This application does not have any active/pending inspections.";
                    }
                }
            }
            else if (model.ServiceCode == ((int)ServiceList.ProvisionalCinema).ToString())
            {
                if (StatusCheck == ((int)Status.OBSPEND).ToString() || StatusCheck == ((int)Status.OBSPEN2).ToString() || (dcCheck == CustomText.TRUE.ToString()))
                {
                    Qry = "select InspectionId from dgen.ApplicationInspectionDetails where ApplicationNo=@ApplicationNo and WhetherInspected=@WhetherInspected and WhetherActive=@WhetherActive";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@WhetherInspected", CustomText.False.ToString());
                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                    GetValues = data.SelectColumns(Cmd);
                    if (!string.IsNullOrEmpty(GetValues[0]) || (dcCheck == CustomText.TRUE.ToString()))
                    {
                        model.ApplicationInspectionDetails = Utility.GetCinemaInspectionDetails(model.ApplicationNo, ((int)CountList.Type002).ToString());
                        model.ApplicationInspectionDetails.InspectionId = model.ApplicationInspectionDetails.InspectionDetails[0].InspectionId;
                        model.ApplicantDetails = model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationNo, DB.LS.ToString());
                        model.ApplicationDetailsCinematograph = Utility.GetProvisionalCinemaDetails(model.ApplicationNo, DB.LS.ToString());
                        PreserveModelState(Constant._ModelStateParent, model, true, false);
                        return View((DecisionModels)TempData[Constant._ModelStateParent]);
                    }
                    else
                    {
                        ViewBag.DisplayMessage = "This application does not have any active/pending observations.";
                    }
                }
            }
            else
            {
                ViewBag.DisplayMessage = "This application is not pending for inspection.";
            }
            return View();
        }
        [Authorize(Roles = "104,114,106,115")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingForInspectionSearch(DecisionModels model)
        {
            if (ModelState.IsValid)
            {
                if (!string.IsNullOrEmpty(model.ApplicationNo) && string.IsNullOrEmpty(model.ApplicationInspectionDetails.InspectionId))
                {
                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo,ServiceCode" }, new ArrayList() { model.ApplicationNo, model.ServiceCode });
                    return RedirectToAction("PendingForInspectionSearch", "Decision", new { q = QueryString });
                }
                else
                {
                    string Qry = string.Empty;
                    NpgsqlCommand Cmd = new NpgsqlCommand();
                    GetData data = new GetData();
                    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                    if (!string.IsNullOrEmpty(model.ApplicationDetails.ApplicationStatusId))
                    {
                        bool WhetherObjected = false;
                        if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSOBJ).ToString())
                        { model.ApplicationDetails.ApplicationStatusId = ((int)Status.TEHSREC).ToString(); WhetherObjected = true; }

                        if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.TEHSREC).ToString())
                        {
                            if (!string.IsNullOrEmpty(model.ApplicationNo))
                            {
                                string SCode = Utility.SelectColumnsValue("applicationdetails", "servicecode", "applicationno", model.ApplicationNo.ToString())[0];
                                if (SCode == ((int)ServiceList.ProvisionalCinema).ToString())
                                {
                                    if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.P115).ToString())//change809
                                    {
                                        for (int i = 0; i < model.ApplicationInspectionDetails.InspectionDetails.Count; i++)
                                        {
                                            HttpPostedFile BPlandata = System.Web.HttpContext.Current.Request.Files["BPlandata" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                            HttpPostedFile SitePlandata = System.Web.HttpContext.Current.Request.Files["SitePlandata" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                            HttpPostedFile TClearancedata = System.Web.HttpContext.Current.Request.Files["TClearancedata" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                            HttpPostedFile CharCertdata = System.Web.HttpContext.Current.Request.Files["CharCertdata" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                            //HttpPostedFile ODoc1data = System.Web.HttpContext.Current.Request.Files["ODoc1data" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                            //HttpPostedFile ODoc2data = System.Web.HttpContext.Current.Request.Files["ODoc2data" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                            byte[] BPlanFile = Utility.CompareFileCapturePhotoData(null, BPlandata); byte[] SitePlanFile = Utility.CompareFileCapturePhotoData(null, SitePlandata); byte[] TClearanceFile = Utility.CompareFileCapturePhotoData(null, TClearancedata); byte[] CharCertFile = Utility.CompareFileCapturePhotoData(null, CharCertdata);
                                            string BPlancontentType = BPlandata.ContentType; string SitePlancontentType = SitePlandata.ContentType; string TClearancecontentType = TClearancedata.ContentType; string CharCertcontentType = CharCertdata.ContentType;

                                            Qry = "update dgen.InspectionDetails set Observation=@Observation,WhetherActive=@WhetherActive,BPlandata=@BPlandata,BPlancontentType=@BPlancontentType,BPlanDocumentNo=@BPlanDocumentNo,BPlanIssueDate=@BPlanIssueDate,SitePlandata=@SitePlandata,SitePlancontentType=@SitePlancontentType,SitePlanDocumentNo=@SitePlanDocumentNo,SitePlanIssueDate=@SitePlanIssueDate,TClearancedata=@TClearancedata,TClearancecontentType=@TClearancecontentType,TClearanceDocumentNo=@TClearanceDocumentNo,TClearanceIssueDate=@TClearanceIssueDate,CharCertdata=@CharCertdata,CharCertcontentType=@CharCertcontentType,CharCertDocumentNo=@CharCertDocumentNo,CharCertIssueDate=@CharCertIssueDate,BPlanRemarksSDM=@BPlanRemarksSDM,SitePlanRemarksSDM=@SitePlanRemarksSDM,TClearanceRemarksSDM=@TClearanceRemarksSDM,CharCertRemarksSDM=@CharCertRemarksSDM,UserId=@UserId,Ipaddress=@Ipaddress,Actiondatetime=now() where Id=@Id and InspectionId=@InspectionId";
                                            Cmd = new NpgsqlCommand(Qry);
                                            Cmd.Parameters.AddWithValue("@Id", model.ApplicationInspectionDetails.InspectionDetails[i].id);
                                            Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[i].InspectionId);
                                            Cmd.Parameters.AddWithValue("@Observation", model.ApplicationInspectionDetails.InspectionDetails[i].Observation);
                                            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                                            Cmd.Parameters.AddWithValue("@BPlandata", BPlanFile);
                                            Cmd.Parameters.AddWithValue("@BPlancontentType", BPlancontentType);
                                            Cmd.Parameters.AddWithValue("@BPlanDocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].BPlanDocumentNo);
                                            Cmd.Parameters.AddWithValue("@BPlanIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].BPlanIssueDate, '/', "0/1/2"));
                                            Cmd.Parameters.AddWithValue("@BPlanRemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].BPlanRemarksSDM);
                                            Cmd.Parameters.AddWithValue("@SitePlandata", SitePlanFile);
                                            Cmd.Parameters.AddWithValue("@SitePlancontentType", SitePlancontentType);
                                            Cmd.Parameters.AddWithValue("@SitePlanDocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].SitePlanDocumentNo);
                                            Cmd.Parameters.AddWithValue("@SitePlanIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].SitePlanIssueDate, '/', "0/1/2"));
                                            Cmd.Parameters.AddWithValue("@SitePlanRemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].SitePlanRemarksSDM);
                                            Cmd.Parameters.AddWithValue("@TClearancedata", TClearanceFile);
                                            Cmd.Parameters.AddWithValue("@TClearancecontentType", TClearancecontentType);
                                            Cmd.Parameters.AddWithValue("@TClearanceDocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].TClearanceDocumentNo);
                                            Cmd.Parameters.AddWithValue("@TClearanceIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].TClearanceIssueDate, '/', "0/1/2"));
                                            Cmd.Parameters.AddWithValue("@TClearanceRemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].TClearanceRemarksSDM);
                                            Cmd.Parameters.AddWithValue("@CharCertdata", CharCertFile);
                                            Cmd.Parameters.AddWithValue("@CharCertcontentType", CharCertcontentType);
                                            Cmd.Parameters.AddWithValue("@CharCertDocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].CharCertDocumentNo);
                                            Cmd.Parameters.AddWithValue("@CharCertIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].CharCertIssueDate, '/', "0/1/2"));
                                            Cmd.Parameters.AddWithValue("@CharCertRemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].CharCertRemarksSDM);

                                            Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                            Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                            cmdList.Add(Cmd);
                                        }
                                        Cmd = new NpgsqlCommand("update dgen.ApplicationInspectionDetails set WhetherSDMInspected=@WhetherSDMInspected,UserId=@UserId,Ipaddress=@Ipaddress where InspectionId=@InspectionId");
                                        Cmd.Parameters.AddWithValue("@WhetherSDMInspected", CustomText.True.ToString());
                                        Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[0].InspectionId);
                                        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                        Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                        cmdList.Add(Cmd);

                                        Cmd = new NpgsqlCommand("update ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,UserId=@UserId,Ipaddress=@Ipaddress where ApplicationNo=@ApplicationNo");
                                        Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.OBSPEN2);
                                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                                        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                        Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                        cmdList.Add(Cmd);

                                        cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, "Observation done by SDM", (int)ApplicationSource.Window, null));
                                    }
                                    else if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.P114).ToString())
                                    {
                                        for (int i = 0; i < model.ApplicationInspectionDetails.InspectionDetails.Count; i++)
                                        {
                                            Qry = "update dgen.InspectionDetails set ObservationADM=@ObservationADM,BPlanRemarksADM=@BPlanRemarksADM,SitePlanRemarksADM=@SitePlanRemarksADM,TClearanceRemarksADM=@TClearanceRemarksADM,CharCertRemarksADM=@CharCertRemarksADM,UserId=@UserId,Ipaddress=@Ipaddress,Actiondatetime=now() where Id=@Id and InspectionId=@InspectionId";
                                            Cmd = new NpgsqlCommand(Qry);
                                            Cmd.Parameters.AddWithValue("@Id", model.ApplicationInspectionDetails.InspectionDetails[i].id);
                                            Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[i].InspectionId);
                                            Cmd.Parameters.AddWithValue("@ObservationADM", model.ApplicationInspectionDetails.InspectionDetails[i].ObservationADM);
                                            Cmd.Parameters.AddWithValue("@BPlanRemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].BPlanRemarksADM);
                                            Cmd.Parameters.AddWithValue("@SitePlanRemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].SitePlanRemarksADM);
                                            Cmd.Parameters.AddWithValue("@TClearanceRemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].TClearanceRemarksADM);
                                            Cmd.Parameters.AddWithValue("@CharCertRemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].CharCertRemarksADM);
                                            Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                            Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                            cmdList.Add(Cmd);
                                        }
                                        Cmd = new NpgsqlCommand("update dgen.ApplicationInspectionDetails set WhetherInspected=@WhetherInspected,UserId=@UserId,Ipaddress=@Ipaddress where InspectionId=@InspectionId");
                                        Cmd.Parameters.AddWithValue("@WhetherInspected", CustomText.True.ToString());
                                        Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[0].InspectionId);
                                        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                        Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                        cmdList.Add(Cmd);

                                        cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, "Observation done by ADM", (int)ApplicationSource.Window, null));
                                    }
                                    else if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.DC).ToString())
                                    {
                                        for (int i = 0; i < model.ApplicationInspectionDetails.InspectionDetails.Count; i++)
                                        {
                                            Qry = "update dgen.InspectionDetails set ObservationDC=@ObservationDC,BPlanRemarksDC=@BPlanRemarksDC,SitePlanRemarksDC=@SitePlanRemarksDC,TClearanceRemarksDC=@TClearanceRemarksDC,CharCertRemarksDC=@CharCertRemarksDC,whetherbplanobjectiondc=@whetherbplanobjectiondc,whethersiteplanobjectiondc=@whethersiteplanobjectiondc,whethertclearanceobjectiondc=@whethertclearanceobjectiondc,whethercharcertobjectiondc=@whethercharcertobjectiondc,UserId=@UserId,Ipaddress=@Ipaddress,Actiondatetime=now() where Id=@Id and InspectionId=@InspectionId";
                                            Cmd = new NpgsqlCommand(Qry);
                                            Cmd.Parameters.AddWithValue("@Id", model.ApplicationInspectionDetails.InspectionDetails[i].id);
                                            Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[i].InspectionId);
                                            Cmd.Parameters.AddWithValue("@ObservationDC", model.ApplicationInspectionDetails.InspectionDetails[i].ObservationDC);
                                            Cmd.Parameters.AddWithValue("@BPlanRemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].BPlanRemarksDC);
                                            Cmd.Parameters.AddWithValue("@whetherbplanobjectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whetherbplanobjectiondc);
                                            Cmd.Parameters.AddWithValue("@SitePlanRemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].SitePlanRemarksDC);
                                            Cmd.Parameters.AddWithValue("@whethersiteplanobjectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whethersiteplanobjectiondc);
                                            Cmd.Parameters.AddWithValue("@TClearanceRemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].TClearanceRemarksDC);
                                            Cmd.Parameters.AddWithValue("@whethertclearanceobjectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whethertclearanceobjectiondc);
                                            Cmd.Parameters.AddWithValue("@CharCertRemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].CharCertRemarksDC);
                                            Cmd.Parameters.AddWithValue("@whethercharcertobjectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whethercharcertobjectiondc);
                                            Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                            Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                            cmdList.Add(Cmd);
                                        }
                                        Cmd = new NpgsqlCommand("update dgen.ApplicationInspectionDetails set WhetherDCInspected=@WhetherDCInspected,UserId=@UserId,Ipaddress=@Ipaddress where InspectionId=@InspectionId");
                                        Cmd.Parameters.AddWithValue("@WhetherDCInspected", CustomText.True.ToString());
                                        Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[0].InspectionId);
                                        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                        Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                        cmdList.Add(Cmd);

                                        cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, "Observation done by DC", (int)ApplicationSource.Window, null));
                                    }
                                }
                                else
                                {
                                    if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.P115).ToString())//change208i
                                    {
                                        for (int i = 0; i < model.ApplicationInspectionDetails.InspectionDetails.Count; i++)
                                        {
                                            HttpPostedFile BPlandata = System.Web.HttpContext.Current.Request.Files["BPlandata" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                            HttpPostedFile DDMAdata = System.Web.HttpContext.Current.Request.Files["DDMAdata" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                            HttpPostedFile MCDdata = System.Web.HttpContext.Current.Request.Files["MCDdata" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                            HttpPostedFile FireDeptdata = System.Web.HttpContext.Current.Request.Files["FireDeptdata" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                            HttpPostedFile ElectricalDeptdata = System.Web.HttpContext.Current.Request.Files["ElectricalDeptdata" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                            HttpPostedFile SitePlandata = System.Web.HttpContext.Current.Request.Files["SitePlandata" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                            HttpPostedFile ODoc1data = System.Web.HttpContext.Current.Request.Files["ODoc1data" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                            HttpPostedFile ODoc2data = System.Web.HttpContext.Current.Request.Files["ODoc2data" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                            byte[] BPlanFile = Utility.CompareFileCapturePhotoData(null, BPlandata); byte[] SitePlanFile = Utility.CompareFileCapturePhotoData(null, SitePlandata); byte[] DDMAFile = Utility.CompareFileCapturePhotoData(null, DDMAdata); byte[] MCDFile = Utility.CompareFileCapturePhotoData(null, MCDdata); byte[] FireDeptFile = Utility.CompareFileCapturePhotoData(null, FireDeptdata); byte[] ElectricalDeptFile = Utility.CompareFileCapturePhotoData(null, ElectricalDeptdata); byte[] ODoc1File = Utility.CompareFileCapturePhotoData(null, ODoc1data); byte[] ODoc2File = Utility.CompareFileCapturePhotoData(null, ODoc2data);
                                            string BPlancontentType = BPlandata.ContentType; string SitePlancontentType = SitePlandata.ContentType; string DDMAcontentType = DDMAdata.ContentType; string MCDcontentType = MCDdata.ContentType; string FDcontentType = FireDeptdata.ContentType; string EDcontentType = ElectricalDeptdata.ContentType; string ODoc1contentType = ODoc1data.ContentType; string ODoc2contentType = ODoc2data.ContentType;

                                            Qry = "update dgen.InspectionDetails set WhetherActive=@WhetherActive,Observation=@Observation,InspectedOn=@InspectedOn,TeamMembers=@TeamMembers,BPlandata=@BPlandata,BPlancontentType=@BPlancontentType,BPlanDocumentNo=@BPlanDocumentNo,BPlanIssueDate=@BPlanIssueDate,SitePlandata=@SitePlandata,SitePlancontentType=@SitePlancontentType,SitePlanDocumentNo=@SitePlanDocumentNo,SitePlanIssueDate=@SitePlanIssueDate,DDMAdata=@DDMAdata,DDMAcontentType=@DDMAcontentType,DDMADocumentNo=@DDMADocumentNo,DDMAIssueDate=@DDMAIssueDate,MCDdata=@MCDdata,MCDcontentType=@MCDcontentType,MCDDocumentNo=@MCDDocumentNo,MCDIssueDate=@MCDIssueDate,FireDeptdata=@FireDeptdata,FDcontentType=@FDcontentType,FDDocumentNo=@FDDocumentNo,FDIssueDate=@FDIssueDate,ElectricalDeptdata=@ElectricalDeptdata,EDcontentType=@EDcontentType,EDDocumentNo=@EDDocumentNo,EDIssueDate=@EDIssueDate,ODoc1data=@ODoc1data,ODoc1contentType=@ODoc1contentType,ODoc1DocumentNo=@ODoc1DocumentNo,ODoc1IssueDate=@ODoc1IssueDate,ODoc2data=@ODoc2data,ODoc2contentType=@ODoc2contentType,ODoc2DocumentNo=@ODoc2DocumentNo,ODoc2IssueDate=@ODoc2IssueDate,BPlanRemarksSDM=@BPlanRemarksSDM,SitePlanRemarksSDM=@SitePlanRemarksSDM,DDMARemarksSDM=@DDMARemarksSDM,MCDRemarksSDM=@MCDRemarksSDM,FDRemarksSDM=@FDRemarksSDM,EDRemarksSDM=@EDRemarksSDM,ODoc1RemarksSDM=@ODoc1RemarksSDM,ODoc2RemarksSDM=@ODoc2RemarksSDM,UserId=@UserId,Ipaddress=@Ipaddress,Actiondatetime=now() where Id=@Id and InspectionId=@InspectionId";
                                            Cmd = new NpgsqlCommand(Qry);
                                            Cmd.Parameters.AddWithValue("@Id", model.ApplicationInspectionDetails.InspectionDetails[i].id);
                                            Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[i].InspectionId);
                                            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                                            Cmd.Parameters.AddWithValue("@Observation", model.ApplicationInspectionDetails.InspectionDetails[i].Observation);
                                            Cmd.Parameters.AddWithValue("@TeamMembers", model.ApplicationInspectionDetails.InspectionDetails[i].TeamMembers);
                                            Cmd.Parameters.AddWithValue("@InspectedOn", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].InspectedOn, '/', "0/1/2"));
                                            Cmd.Parameters.AddWithValue("@BPlandata", BPlanFile);
                                            Cmd.Parameters.AddWithValue("@BPlancontentType", BPlancontentType);
                                            Cmd.Parameters.AddWithValue("@BPlanDocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].BPlanDocumentNo);
                                            Cmd.Parameters.AddWithValue("@BPlanIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].BPlanIssueDate, '/', "0/1/2"));
                                            Cmd.Parameters.AddWithValue("@BPlanRemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].BPlanRemarksSDM);
                                            Cmd.Parameters.AddWithValue("@SitePlandata", SitePlanFile);
                                            Cmd.Parameters.AddWithValue("@SitePlancontentType", SitePlancontentType);
                                            Cmd.Parameters.AddWithValue("@SitePlanDocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].SitePlanDocumentNo);
                                            Cmd.Parameters.AddWithValue("@SitePlanIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].SitePlanIssueDate, '/', "0/1/2"));
                                            Cmd.Parameters.AddWithValue("@SitePlanRemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].SitePlanRemarksSDM);
                                            Cmd.Parameters.AddWithValue("@DDMAdata", DDMAFile);
                                            Cmd.Parameters.AddWithValue("@DDMAcontentType", DDMAcontentType);
                                            Cmd.Parameters.AddWithValue("@DDMADocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].DDMADocumentNo);
                                            Cmd.Parameters.AddWithValue("@DDMAIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].DDMAIssueDate, '/', "0/1/2"));
                                            Cmd.Parameters.AddWithValue("@DDMARemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].DDMARemarksSDM);
                                            Cmd.Parameters.AddWithValue("@MCDdata", MCDFile);
                                            Cmd.Parameters.AddWithValue("@MCDcontentType", MCDcontentType);
                                            Cmd.Parameters.AddWithValue("@MCDDocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].MCDDocumentNo);
                                            Cmd.Parameters.AddWithValue("@MCDIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].MCDIssueDate, '/', "0/1/2"));
                                            Cmd.Parameters.AddWithValue("@MCDRemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].MCDRemarksSDM);
                                            Cmd.Parameters.AddWithValue("@FireDeptdata", FireDeptFile);
                                            Cmd.Parameters.AddWithValue("@FDcontentType", FDcontentType);
                                            Cmd.Parameters.AddWithValue("@FDDocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].FDDocumentNo);
                                            Cmd.Parameters.AddWithValue("@FDIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].FDIssueDate, '/', "0/1/2"));
                                            Cmd.Parameters.AddWithValue("@FDRemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].FDRemarksSDM);
                                            Cmd.Parameters.AddWithValue("@ElectricalDeptdata", ElectricalDeptFile);
                                            Cmd.Parameters.AddWithValue("@EDcontentType", EDcontentType);
                                            Cmd.Parameters.AddWithValue("@EDDocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].EDDocumentNo);
                                            Cmd.Parameters.AddWithValue("@EDIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].EDIssueDate, '/', "0/1/2"));
                                            Cmd.Parameters.AddWithValue("@EDRemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].EDRemarksSDM);
                                            Cmd.Parameters.AddWithValue("@ODoc1data", ODoc1File);
                                            Cmd.Parameters.AddWithValue("@ODoc1contentType", ODoc1contentType);
                                            Cmd.Parameters.AddWithValue("@ODoc1DocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].ODoc1DocumentNo);
                                            Cmd.Parameters.AddWithValue("@ODoc1IssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].ODoc1IssueDate, '/', "0/1/2"));
                                            Cmd.Parameters.AddWithValue("@ODoc1RemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].ODoc1RemarksSDM);
                                            Cmd.Parameters.AddWithValue("@ODoc2data", ODoc2File);
                                            Cmd.Parameters.AddWithValue("@ODoc2contentType", ODoc2contentType);
                                            Cmd.Parameters.AddWithValue("@ODoc2DocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].ODoc2DocumentNo);
                                            Cmd.Parameters.AddWithValue("@ODoc2IssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].ODoc2IssueDate, '/', "0/1/2"));
                                            Cmd.Parameters.AddWithValue("@ODoc2RemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].ODoc2RemarksSDM);
                                            Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                            Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                            cmdList.Add(Cmd);
                                        }
                                        Cmd = new NpgsqlCommand("update dgen.ApplicationInspectionDetails set WhetherSDMInspected=@WhetherSDMInspected,UserId=@UserId,Ipaddress=@Ipaddress where InspectionId=@InspectionId");
                                        Cmd.Parameters.AddWithValue("@WhetherSDMInspected", CustomText.True.ToString());
                                        Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[0].InspectionId);
                                        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                        Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                        cmdList.Add(Cmd);

                                        cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, "Inspection done by SDM", (int)ApplicationSource.Window, null));
                                    }
                                    else if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.P114).ToString())
                                    {
                                        for (int i = 0; i < model.ApplicationInspectionDetails.InspectionDetails.Count; i++)
                                        {
                                            Qry = "update dgen.InspectionDetails set ObservationADM=@ObservationADM,BPlanRemarksADM=@BPlanRemarksADM,SitePlanRemarksADM=@SitePlanRemarksADM,DDMARemarksADM=@DDMARemarksADM,MCDRemarksADM=@MCDRemarksADM,FDRemarksADM=@FDRemarksADM,EDRemarksADM=@EDRemarksADM,ODoc1RemarksADM=@ODoc1RemarksADM,ODoc2RemarksADM=@ODoc2RemarksADM,UserId=@UserId,Ipaddress=@Ipaddress,Actiondatetime=now() where Id=@Id and InspectionId=@InspectionId";
                                            Cmd = new NpgsqlCommand(Qry);
                                            Cmd.Parameters.AddWithValue("@Id", model.ApplicationInspectionDetails.InspectionDetails[i].id);
                                            Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[i].InspectionId);
                                            Cmd.Parameters.AddWithValue("@BPlanRemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].BPlanRemarksADM);
                                            Cmd.Parameters.AddWithValue("@SitePlanRemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].SitePlanRemarksADM);
                                            Cmd.Parameters.AddWithValue("@DDMARemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].DDMARemarksADM);
                                            Cmd.Parameters.AddWithValue("@MCDRemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].MCDRemarksADM);
                                            Cmd.Parameters.AddWithValue("@FDRemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].FDRemarksADM);
                                            Cmd.Parameters.AddWithValue("@EDRemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].EDRemarksADM);
                                            Cmd.Parameters.AddWithValue("@ODoc1RemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].ODoc1RemarksADM);
                                            Cmd.Parameters.AddWithValue("@ODoc2RemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].ODoc2RemarksADM);
                                            Cmd.Parameters.AddWithValue("@ObservationADM", model.ApplicationInspectionDetails.InspectionDetails[i].ObservationADM);
                                            Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                            Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                            cmdList.Add(Cmd);
                                        }
                                        Cmd = new NpgsqlCommand("update dgen.ApplicationInspectionDetails set WhetherInspected=@WhetherInspected,UserId=@UserId,Ipaddress=@Ipaddress where InspectionId=@InspectionId");
                                        Cmd.Parameters.AddWithValue("@WhetherInspected", CustomText.True.ToString());
                                        Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[0].InspectionId);
                                        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                        Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                        cmdList.Add(Cmd);

                                        cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, "Inspection done by ADM", (int)ApplicationSource.Window, null));
                                    }
                                    else if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.DC).ToString())
                                    {
                                        for (int i = 0; i < model.ApplicationInspectionDetails.InspectionDetails.Count; i++)
                                        {
                                            Qry = "update dgen.InspectionDetails set ObservationDC=@ObservationDC,BPlanRemarksDC=@BPlanRemarksDC,SitePlanRemarksDC=@SitePlanRemarksDC,DDMARemarksDC=@DDMARemarksDC,MCDRemarksDC=@MCDRemarksDC,FDRemarksDC=@FDRemarksDC,EDRemarksDC=@EDRemarksDC,ODoc1RemarksDC=@ODoc1RemarksDC,ODoc2RemarksDC=@ODoc2RemarksDC,whetherbplanobjectiondc=@whetherbplanobjectiondc,whetherddmaobjectiondc=@whetherddmaobjectiondc,whethermcdobjectiondc=@whethermcdobjectiondc,whetherfdobjectiondc=@whetherfdobjectiondc,whetheredobjectiondc=@whetheredobjectiondc,whethersiteplanobjectiondc=@whethersiteplanobjectiondc,whetherodoc1objectiondc=@whetherodoc1objectiondc,whetherodoc2objectiondc=@whetherodoc2objectiondc,UserId=@UserId,Ipaddress=@Ipaddress,Actiondatetime=now() where Id=@Id and InspectionId=@InspectionId";
                                            Cmd = new NpgsqlCommand(Qry);
                                            Cmd.Parameters.AddWithValue("@Id", model.ApplicationInspectionDetails.InspectionDetails[i].id);
                                            Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[i].InspectionId);
                                            Cmd.Parameters.AddWithValue("@BPlanRemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].BPlanRemarksDC);
                                            Cmd.Parameters.AddWithValue("@whetherbplanobjectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whetherbplanobjectiondc);
                                            Cmd.Parameters.AddWithValue("@SitePlanRemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].SitePlanRemarksDC);
                                            Cmd.Parameters.AddWithValue("@whethersiteplanobjectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whethersiteplanobjectiondc);
                                            Cmd.Parameters.AddWithValue("@DDMARemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].DDMARemarksDC);
                                            Cmd.Parameters.AddWithValue("@whetherddmaobjectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whetherddmaobjectiondc);
                                            Cmd.Parameters.AddWithValue("@MCDRemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].MCDRemarksDC);
                                            Cmd.Parameters.AddWithValue("@whethermcdobjectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whethermcdobjectiondc);
                                            Cmd.Parameters.AddWithValue("@FDRemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].FDRemarksDC);
                                            Cmd.Parameters.AddWithValue("@whetherfdobjectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whetherfdobjectiondc);
                                            Cmd.Parameters.AddWithValue("@EDRemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].EDRemarksDC);
                                            Cmd.Parameters.AddWithValue("@whetheredobjectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whetheredobjectiondc);
                                            Cmd.Parameters.AddWithValue("@ODoc1RemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].ODoc1RemarksDC);
                                            Cmd.Parameters.AddWithValue("@whetherodoc1objectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whetherodoc1objectiondc);
                                            Cmd.Parameters.AddWithValue("@ODoc2RemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].ODoc2RemarksDC);
                                            Cmd.Parameters.AddWithValue("@whetherodoc2objectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whetherodoc2objectiondc);
                                            Cmd.Parameters.AddWithValue("@ObservationDC", model.ApplicationInspectionDetails.InspectionDetails[i].ObservationDC);
                                            Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                            Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                            cmdList.Add(Cmd);
                                        }
                                        Cmd = new NpgsqlCommand("update dgen.ApplicationInspectionDetails set WhetherDCInspected=@WhetherDCInspected,UserId=@UserId,Ipaddress=@Ipaddress where InspectionId=@InspectionId");
                                        Cmd.Parameters.AddWithValue("@WhetherDCInspected", CustomText.True.ToString());
                                        Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[0].InspectionId);
                                        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                        Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                        cmdList.Add(Cmd);

                                        cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, "Inspection done by DC", (int)ApplicationSource.Window, null));
                                    }
                                }

                                string cid = Utility.SelectColumnsValue("dgen.ApplicationInspectionDetails", "cid", "InspectionId", model.ApplicationInspectionDetails.InspectionDetails[0].InspectionId)[0];
                                if (!string.IsNullOrEmpty(cid))
                                {
                                    Cmd = new NpgsqlCommand("update dgen.ApplicationDetailsExistingCinema set LastInspectionDate=now() where cid=@cid");
                                    Cmd.Parameters.AddWithValue("@cid", cid);
                                    cmdList.Add(Cmd);
                                }

                                if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.P114).ToString())
                                {
                                    Cmd = new NpgsqlCommand("update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,UserId=@UserId,Ipaddress=@Ipaddress where ApplicationNo=@ApplicationNo");
                                    Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSPEN);
                                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                    Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                    cmdList.Add(Cmd);
                                }



                                if (!string.IsNullOrEmpty(model.ApplicationNo))
                                {
                                    //if (model.ServiceCode == ((int)ServiceList.FreshCinemaLicense).ToString())
                                    //{
                                    //    Qry = "insert into dgen.ApplicationDetailsExistingCinema (LicenceNo,CinemaName,CinemaOwnerName,CinemaAddress,LocalityId,DistrictCode,NoOfScreens,LicenceGrantDate,LastInspectionDate,UserId,IpAddress,ActionDateTime) select @LicenceNo,CinemaName,CinemaOwner,CinemaAddress,CinemaLocalityId,SD.DistrictCode,NoOfScreens,now(),now(),@UserId,@IpAddress,now() from dgen.applicationdetailscinematograph AC inner join localitytosubdivmaster LTS on LTS.localityid=AC.cinemalocalityid inner join subdivmaster SD on SD.subdivcode=LTS.subdivcode inner join districtmaster DM on DM.districtcode=SD.districtcode and DM.deptcode=@deptcode where ApplicationNo=@LicenceNo";
                                    //    Cmd = new NpgsqlCommand(Qry);
                                    //    Cmd.Parameters.AddWithValue("@LicenceNo", model.ApplicationNo);
                                    //    Cmd.Parameters.AddWithValue("@UserId", Utility.SelectColumnsValue("dbo.ApplicationDetails", "RegistrationId", "ApplicationNo", model.ApplicationNo)[0]);
                                    //    Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                    //    Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                                    //    //cmdList.Add(Cmd);  taken to DM
                                    //}
                                    //data.SaveData(cmdList);
                                    //return RedirectToAction("PrintCinemaProvisional", "Print");
                                }
                                if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.P114).ToString() || Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.P115).ToString())
                                {
                                    data.SaveData(cmdList);
                                    if (SCode == ((int)ServiceList.ProvisionalCinema).ToString())
                                    {
                                        if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.P114).ToString())
                                        {
                                            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.OBSPEN2).ToString() });
                                            return RedirectToAction("PendingDMDecsionSummary", "Decision", new { q = QueryString });
                                        }
                                        else
                                        {
                                            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.OBSPEND).ToString() });
                                            return RedirectToAction("PendingDMDecsionSummary", "Decision", new { q = QueryString });
                                        }
                                    }
                                    else
                                    {
                                        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "ServiceCode" }, new ArrayList() { model.ServiceCode });
                                        return RedirectToAction("PendingCountForInspection", "Decision", new { q = QueryString });
                                    }
                                }
                                else if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.DC).ToString())
                                {
                                    data.SaveData(cmdList);
                                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationNo.ToString() });
                                    return RedirectToAction("PendingDMApplicationDecisionDetails", new { q = QueryString });
                                }
                                else
                                {
                                    data.SaveData(cmdList);
                                    return RedirectToAction("CinemaListForInspection", "Decision");
                                }
                            }
                            else
                            {
                                //string CId = Utility.SelectColumnsValue("dgen.ApplicationInspectionDetails", "CId", "InspectionId",model.ApplicationInspectionDetails.InspectionDetails[0].InspectionId)[0];
                                if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.P115).ToString())//change169
                                {
                                    for (int i = 0; i < model.ApplicationInspectionDetails.InspectionDetails.Count; i++)
                                    {
                                        HttpPostedFile BPlandata = System.Web.HttpContext.Current.Request.Files["BPlandata" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                        HttpPostedFile DDMAdata = System.Web.HttpContext.Current.Request.Files["DDMAdata" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                        HttpPostedFile MCDdata = System.Web.HttpContext.Current.Request.Files["MCDdata" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                        HttpPostedFile FireDeptdata = System.Web.HttpContext.Current.Request.Files["FireDeptdata" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                        HttpPostedFile ElectricalDeptdata = System.Web.HttpContext.Current.Request.Files["ElectricalDeptdata" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                        HttpPostedFile SitePlandata = System.Web.HttpContext.Current.Request.Files["SitePlandata" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                        HttpPostedFile ODoc1data = System.Web.HttpContext.Current.Request.Files["ODoc1data" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                        HttpPostedFile ODoc2data = System.Web.HttpContext.Current.Request.Files["ODoc2data" + model.ApplicationInspectionDetails.InspectionDetails[i].id];
                                        byte[] BPlanFile = Utility.CompareFileCapturePhotoData(null, BPlandata); byte[] SitePlanFile = Utility.CompareFileCapturePhotoData(null, SitePlandata); byte[] DDMAFile = Utility.CompareFileCapturePhotoData(null, DDMAdata); byte[] MCDFile = Utility.CompareFileCapturePhotoData(null, MCDdata); byte[] FireDeptFile = Utility.CompareFileCapturePhotoData(null, FireDeptdata); byte[] ElectricalDeptFile = Utility.CompareFileCapturePhotoData(null, ElectricalDeptdata); byte[] ODoc1File = Utility.CompareFileCapturePhotoData(null, ODoc1data); byte[] ODoc2File = Utility.CompareFileCapturePhotoData(null, ODoc2data);
                                        string BPlancontentType = BPlandata.ContentType; string SitePlancontentType = SitePlandata.ContentType; string DDMAcontentType = DDMAdata.ContentType; string MCDcontentType = MCDdata.ContentType; string FDcontentType = FireDeptdata.ContentType; string EDcontentType = ElectricalDeptdata.ContentType; string ODoc1contentType = ODoc1data.ContentType; string ODoc2contentType = ODoc2data.ContentType;

                                        Qry = "update dgen.InspectionDetails set WhetherActive=@WhetherActive,Observation=@Observation,InspectedOn=@InspectedOn,TeamMembers=@TeamMembers,BPlandata=@BPlandata,BPlancontentType=@BPlancontentType,BPlanDocumentNo=@BPlanDocumentNo,BPlanIssueDate=@BPlanIssueDate,SitePlandata=@SitePlandata,SitePlancontentType=@SitePlancontentType,SitePlanDocumentNo=@SitePlanDocumentNo,SitePlanIssueDate=@SitePlanIssueDate,DDMAdata=@DDMAdata,DDMAcontentType=@DDMAcontentType,DDMADocumentNo=@DDMADocumentNo,DDMAIssueDate=@DDMAIssueDate,MCDdata=@MCDdata,MCDcontentType=@MCDcontentType,MCDDocumentNo=@MCDDocumentNo,MCDIssueDate=@MCDIssueDate,FireDeptdata=@FireDeptdata,FDcontentType=@FDcontentType,FDDocumentNo=@FDDocumentNo,FDIssueDate=@FDIssueDate,ElectricalDeptdata=@ElectricalDeptdata,EDcontentType=@EDcontentType,EDDocumentNo=@EDDocumentNo,EDIssueDate=@EDIssueDate,ODoc1data=@ODoc1data,ODoc1contentType=@ODoc1contentType,ODoc1DocumentNo=@ODoc1DocumentNo,ODoc1IssueDate=@ODoc1IssueDate,ODoc2data=@ODoc2data,ODoc2contentType=@ODoc2contentType,ODoc2DocumentNo=@ODoc2DocumentNo,ODoc2IssueDate=@ODoc2IssueDate,BPlanRemarksSDM=@BPlanRemarksSDM,SitePlanRemarksSDM=@SitePlanRemarksSDM,DDMARemarksSDM=@DDMARemarksSDM,MCDRemarksSDM=@MCDRemarksSDM,FDRemarksSDM=@FDRemarksSDM,EDRemarksSDM=@EDRemarksSDM,ODoc1RemarksSDM=@ODoc1RemarksSDM,ODoc2RemarksSDM=@ODoc2RemarksSDM,UserId=@UserId,Ipaddress=@Ipaddress,Actiondatetime=now() where Id=@Id and InspectionId=@InspectionId";
                                        Cmd = new NpgsqlCommand(Qry);
                                        Cmd.Parameters.AddWithValue("@Id", model.ApplicationInspectionDetails.InspectionDetails[i].id);
                                        Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[i].InspectionId);
                                        Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                                        Cmd.Parameters.AddWithValue("@Observation", model.ApplicationInspectionDetails.InspectionDetails[i].Observation);
                                        Cmd.Parameters.AddWithValue("@TeamMembers", model.ApplicationInspectionDetails.InspectionDetails[i].TeamMembers);
                                        Cmd.Parameters.AddWithValue("@InspectedOn", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].InspectedOn, '/', "0/1/2"));
                                        Cmd.Parameters.AddWithValue("@BPlandata", BPlanFile);
                                        Cmd.Parameters.AddWithValue("@BPlancontentType", BPlancontentType);
                                        Cmd.Parameters.AddWithValue("@BPlanDocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].BPlanDocumentNo);
                                        Cmd.Parameters.AddWithValue("@BPlanIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].BPlanIssueDate, '/', "0/1/2"));
                                        Cmd.Parameters.AddWithValue("@BPlanRemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].BPlanRemarksSDM);
                                        Cmd.Parameters.AddWithValue("@SitePlandata", SitePlanFile);
                                        Cmd.Parameters.AddWithValue("@SitePlancontentType", SitePlancontentType);
                                        Cmd.Parameters.AddWithValue("@SitePlanDocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].SitePlanDocumentNo);
                                        Cmd.Parameters.AddWithValue("@SitePlanIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].SitePlanIssueDate, '/', "0/1/2"));
                                        Cmd.Parameters.AddWithValue("@SitePlanRemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].SitePlanRemarksSDM);
                                        Cmd.Parameters.AddWithValue("@DDMAdata", DDMAFile);
                                        Cmd.Parameters.AddWithValue("@DDMAcontentType", DDMAcontentType);
                                        Cmd.Parameters.AddWithValue("@DDMADocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].DDMADocumentNo);
                                        Cmd.Parameters.AddWithValue("@DDMAIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].DDMAIssueDate, '/', "0/1/2"));
                                        Cmd.Parameters.AddWithValue("@DDMARemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].DDMARemarksSDM);
                                        Cmd.Parameters.AddWithValue("@MCDdata", MCDFile);
                                        Cmd.Parameters.AddWithValue("@MCDcontentType", MCDcontentType);
                                        Cmd.Parameters.AddWithValue("@MCDDocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].MCDDocumentNo);
                                        Cmd.Parameters.AddWithValue("@MCDIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].MCDIssueDate, '/', "0/1/2"));
                                        Cmd.Parameters.AddWithValue("@MCDRemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].MCDRemarksSDM);
                                        Cmd.Parameters.AddWithValue("@FireDeptdata", FireDeptFile);
                                        Cmd.Parameters.AddWithValue("@FDcontentType", FDcontentType);
                                        Cmd.Parameters.AddWithValue("@FDDocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].FDDocumentNo);
                                        Cmd.Parameters.AddWithValue("@FDIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].FDIssueDate, '/', "0/1/2"));
                                        Cmd.Parameters.AddWithValue("@FDRemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].FDRemarksSDM);
                                        Cmd.Parameters.AddWithValue("@ElectricalDeptdata", ElectricalDeptFile);
                                        Cmd.Parameters.AddWithValue("@EDcontentType", EDcontentType);
                                        Cmd.Parameters.AddWithValue("@EDDocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].EDDocumentNo);
                                        Cmd.Parameters.AddWithValue("@EDIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].EDIssueDate, '/', "0/1/2"));
                                        Cmd.Parameters.AddWithValue("@EDRemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].EDRemarksSDM);
                                        Cmd.Parameters.AddWithValue("@ODoc1data", ODoc1File);
                                        Cmd.Parameters.AddWithValue("@ODoc1contentType", ODoc1contentType);
                                        Cmd.Parameters.AddWithValue("@ODoc1DocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].ODoc1DocumentNo);
                                        Cmd.Parameters.AddWithValue("@ODoc1IssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].ODoc1IssueDate, '/', "0/1/2"));
                                        Cmd.Parameters.AddWithValue("@ODoc1RemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].ODoc1RemarksSDM);
                                        Cmd.Parameters.AddWithValue("@ODoc2data", ODoc2File);
                                        Cmd.Parameters.AddWithValue("@ODoc2contentType", ODoc2contentType);
                                        Cmd.Parameters.AddWithValue("@ODoc2DocumentNo", model.ApplicationInspectionDetails.InspectionDetails[i].ODoc2DocumentNo);
                                        Cmd.Parameters.AddWithValue("@ODoc2IssueDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDetails[i].ODoc2IssueDate, '/', "0/1/2"));
                                        Cmd.Parameters.AddWithValue("@ODoc2RemarksSDM", model.ApplicationInspectionDetails.InspectionDetails[i].ODoc2RemarksSDM);
                                        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                        Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                        cmdList.Add(Cmd);
                                    }
                                    Cmd = new NpgsqlCommand("update dgen.ApplicationInspectionDetails set WhetherSDMInspected=@WhetherSDMInspected,UserId=@UserId,Ipaddress=@Ipaddress where InspectionId=@InspectionId");
                                    Cmd.Parameters.AddWithValue("@WhetherSDMInspected", CustomText.True.ToString());
                                    Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[0].InspectionId);
                                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                    Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                    cmdList.Add(Cmd);

                                    Qry = "update dgen.ApplicationDetailsExistingCinema set StatusId=@StatusId,Actiondatetime=now() where CId=@CId";
                                    Cmd = new NpgsqlCommand(Qry);
                                    Cmd.Parameters.AddWithValue("@CId", model.ApplicationInspectionDetails.cid);
                                    Cmd.Parameters.AddWithValue("@StatusId", (int)ValueId.CinemaInspectionEntered);
                                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                    Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                    cmdList.Add(Cmd);
                                }
                                else if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.P114).ToString())
                                {
                                    for (int i = 0; i < model.ApplicationInspectionDetails.InspectionDetails.Count; i++)
                                    {
                                        Qry = "update dgen.InspectionDetails set ObservationADM=@ObservationADM,BPlanRemarksADM=@BPlanRemarksADM,SitePlanRemarksADM=@SitePlanRemarksADM,DDMARemarksADM=@DDMARemarksADM,MCDRemarksADM=@MCDRemarksADM,FDRemarksADM=@FDRemarksADM,EDRemarksADM=@EDRemarksADM,ODoc1RemarksADM=@ODoc1RemarksADM,ODoc2RemarksADM=@ODoc2RemarksADM,UserId=@UserId,Ipaddress=@Ipaddress,Actiondatetime=now() where Id=@Id and InspectionId=@InspectionId";
                                        Cmd = new NpgsqlCommand(Qry);
                                        Cmd.Parameters.AddWithValue("@Id", model.ApplicationInspectionDetails.InspectionDetails[i].id);
                                        Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[i].InspectionId);
                                        Cmd.Parameters.AddWithValue("@BPlanRemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].BPlanRemarksADM);
                                        Cmd.Parameters.AddWithValue("@SitePlanRemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].SitePlanRemarksADM);
                                        Cmd.Parameters.AddWithValue("@DDMARemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].DDMARemarksADM);
                                        Cmd.Parameters.AddWithValue("@MCDRemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].MCDRemarksADM);
                                        Cmd.Parameters.AddWithValue("@FDRemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].FDRemarksADM);
                                        Cmd.Parameters.AddWithValue("@EDRemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].EDRemarksADM);
                                        Cmd.Parameters.AddWithValue("@ODoc1RemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].ODoc1RemarksADM);
                                        Cmd.Parameters.AddWithValue("@ODoc2RemarksADM", model.ApplicationInspectionDetails.InspectionDetails[i].ODoc2RemarksADM);
                                        Cmd.Parameters.AddWithValue("@ObservationADM", model.ApplicationInspectionDetails.InspectionDetails[i].ObservationADM);
                                        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                        Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                        cmdList.Add(Cmd);
                                    }
                                    Cmd = new NpgsqlCommand("update dgen.ApplicationInspectionDetails set WhetherInspected=@WhetherInspected,UserId=@UserId,Ipaddress=@Ipaddress where InspectionId=@InspectionId");
                                    Cmd.Parameters.AddWithValue("@WhetherInspected", CustomText.True.ToString());
                                    Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[0].InspectionId);
                                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                    Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                    cmdList.Add(Cmd);

                                }
                                else if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.DC).ToString())
                                {
                                    for (int i = 0; i < model.ApplicationInspectionDetails.InspectionDetails.Count; i++)
                                    {
                                        Qry = "update dgen.InspectionDetails set ObservationDC=@ObservationDC,BPlanRemarksDC=@BPlanRemarksDC,SitePlanRemarksDC=@SitePlanRemarksDC,DDMARemarksDC=@DDMARemarksDC,MCDRemarksDC=@MCDRemarksDC,FDRemarksDC=@FDRemarksDC,EDRemarksDC=@EDRemarksDC,ODoc1RemarksDC=@ODoc1RemarksDC,ODoc2RemarksDC=@ODoc2RemarksDC,whetherbplanobjectiondc=@whetherbplanobjectiondc,whetherddmaobjectiondc=@whetherddmaobjectiondc,whethermcdobjectiondc=@whethermcdobjectiondc,whetherfdobjectiondc=@whetherfdobjectiondc,whetheredobjectiondc=@whetheredobjectiondc,whethersiteplanobjectiondc=@whethersiteplanobjectiondc,whetherodoc1objectiondc=@whetherodoc1objectiondc,whetherodoc2objectiondc=@whetherodoc2objectiondc,UserId=@UserId,Ipaddress=@Ipaddress,Actiondatetime=now() where Id=@Id and InspectionId=@InspectionId";
                                        Cmd = new NpgsqlCommand(Qry);
                                        Cmd.Parameters.AddWithValue("@Id", model.ApplicationInspectionDetails.InspectionDetails[i].id);
                                        Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[i].InspectionId);
                                        Cmd.Parameters.AddWithValue("@BPlanRemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].BPlanRemarksDC);
                                        Cmd.Parameters.AddWithValue("@whetherbplanobjectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whetherbplanobjectiondc);
                                        Cmd.Parameters.AddWithValue("@SitePlanRemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].SitePlanRemarksDC);
                                        Cmd.Parameters.AddWithValue("@whethersiteplanobjectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whethersiteplanobjectiondc);
                                        Cmd.Parameters.AddWithValue("@DDMARemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].DDMARemarksDC);
                                        Cmd.Parameters.AddWithValue("@whetherddmaobjectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whetherddmaobjectiondc);
                                        Cmd.Parameters.AddWithValue("@MCDRemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].MCDRemarksDC);
                                        Cmd.Parameters.AddWithValue("@whethermcdobjectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whethermcdobjectiondc);
                                        Cmd.Parameters.AddWithValue("@FDRemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].FDRemarksDC);
                                        Cmd.Parameters.AddWithValue("@whetherfdobjectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whetherfdobjectiondc);
                                        Cmd.Parameters.AddWithValue("@EDRemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].EDRemarksDC);
                                        Cmd.Parameters.AddWithValue("@whetheredobjectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whetheredobjectiondc);
                                        Cmd.Parameters.AddWithValue("@ODoc1RemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].ODoc1RemarksDC);
                                        Cmd.Parameters.AddWithValue("@whetherodoc1objectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whetherodoc1objectiondc);
                                        Cmd.Parameters.AddWithValue("@ODoc2RemarksDC", model.ApplicationInspectionDetails.InspectionDetails[i].ODoc2RemarksDC);
                                        Cmd.Parameters.AddWithValue("@whetherodoc2objectiondc", model.ApplicationInspectionDetails.InspectionDetails[i].whetherodoc2objectiondc);
                                        Cmd.Parameters.AddWithValue("@ObservationDC", model.ApplicationInspectionDetails.InspectionDetails[i].ObservationDC);
                                        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                        Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                        cmdList.Add(Cmd);
                                    }
                                    if (!WhetherObjected)
                                    {
                                        Cmd = new NpgsqlCommand("update dgen.ApplicationInspectionDetails set WhetherDCInspected=@WhetherDCInspected,UserId=@UserId,Ipaddress=@Ipaddress where InspectionId=@InspectionId");
                                        Cmd.Parameters.AddWithValue("@WhetherDCInspected", CustomText.True.ToString());
                                        Cmd.Parameters.AddWithValue("@InspectionId", model.ApplicationInspectionDetails.InspectionDetails[0].InspectionId);
                                        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                                        Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                        cmdList.Add(Cmd);
                                    }
                                    Qry = "update dgen.ApplicationDetailsExistingCinema set StatusId=@StatusId,Actiondatetime=now() where CId=@CId";
                                    Cmd = new NpgsqlCommand(Qry);
                                    Cmd.Parameters.AddWithValue("@CId", model.ApplicationInspectionDetails.cid);
                                    if (WhetherObjected)
                                    {
                                        Cmd.Parameters.AddWithValue("@StatusId", (int)ValueId.CinemaObjectionRaised);
                                    }
                                    else
                                    {
                                        Cmd.Parameters.AddWithValue("@StatusId", (int)ValueId.CinemaInspectionComplete);
                                    }
                                    Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                                    cmdList.Add(Cmd);
                                }
                            }
                            data.SaveData(cmdList);
                            if (WhetherObjected)
                            {
                                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "CId" }, new ArrayList() { model.ApplicationInspectionDetails.cid });
                                return RedirectToAction("PrintCinemaObjectionLetter", "Print", new { q = QueryString });
                            }
                            return RedirectToAction("CinemaListForInspection", "Decision");
                        }
                        else//badr 
                        {
                            return RedirectToAction("BadRequest", "Error");
                        }
                        //string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationNo });
                        //return RedirectToAction("InitializeRecordSign", "Sign", new { q = QueryString });
                    }
                    else //rejection 
                    {
                        Cmd = new NpgsqlCommand("update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,UserId=@UserId,Ipaddress=@Ipaddress where ApplicationNo=@ApplicationNo");
                        Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREJ);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "ServiceCode" }, new ArrayList() { model.ServiceCode });
                        return RedirectToAction("PendingCountForInspection", "Decision", new { q = QueryString });
                    }
                }
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View((DecisionModels)TempData[Constant._ModelStateParent]);
        }
        [Authorize(Roles = "104,114,115")]
        [EncryptedActionParameter]
        public ActionResult PendingCountForInspection(int ServiceCode)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            model.ServiceCode = ServiceCode.ToString();
            string Qry = "select @ServiceCode as ServiceCode,coalesce(count(AI.applicationno),0) as Count,to_char(AI.InspectionDate,'DD/MM/YYYY') as InspectionDate from dgen.applicationinspectiondetails AI inner join applicationdetails AD on AD.applicationno=AI.applicationno where ApplicationStatusId=@ApplicationStatusId and AD.ServiceCode=@ServiceCode and AI.WhetherInspected=@WhetherInspected and AI.WhetherActive=@WhetherActive";
            if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.P115).ToString())
            { Qry += " and WhetherSDMInspected=@WhetherInspected"; }
            if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.P114).ToString())
            { Qry += " and WhetherSDMInspected=@WhetherActive"; }
            Qry += "  group by AI.inspectiondate order by AI.inspectiondate desc";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
            Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.INSPEND);
            Cmd.Parameters.AddWithValue("@WhetherInspected", CustomText.False.ToString());
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
            model.data = data.GetDataTable(Cmd);
            return View(model);
        }
        [Authorize(Roles = "104,114,106,115")]
        [EncryptedActionParameter]
        public ActionResult PendingListForInspection(int ServiceCode, string InspectionDate)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            model.ServiceCode = ServiceCode.ToString();
            string Qry = "select SM.ServiceName,AD.applicantName,AD.applicationno,AD.applicantmobileno,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantlocalityid,applicantsubdivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,to_char(AI.InspectionDate,'DD/MM/YYYY') as InspectionDate from dbo.applicationdetails AD inner join dgen.ApplicationInspectionDetails AI on AI.ApplicationNo=AD.ApplicationNo inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where AI.WhetherInspected=@WhetherInspected and AI.WhetherActive=@WhetherActive and AI.InspectionDate=@InspectionDate and AD.ServiceCode=@ServiceCode";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
            Cmd.Parameters.AddWithValue("@InspectionDate", Utility.GetDateYYYYMMDD(InspectionDate, '/', "0/1/2"));
            Cmd.Parameters.AddWithValue("@WhetherInspected", CustomText.False.ToString());
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
            model.data = data.GetDataTable(Cmd);
            return View(model);
        }
        [Authorize(Roles = "104,114,106,115")]
        [EncryptedActionParameter]
        public ActionResult CinemaListForInspection()
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            string Qry = "select EC.Statusid,EC.cid,EC.cinemaname,EC.cinemaaddress,LM.localityname as locality,DM.districtname as district,EC.contactno,to_char(licencegrantdate,'DD/MM/YYYY') as licencegrantdate,to_char(lastinspectiondate,'DD/MM/YYYY') as lastinspectiondate,to_char(AI.inspectiondate,'DD/MM/YYYY') as nextinspectiondate,AI.WhetherActive,AI.WhetherInspected,AI.whethersdminspected from dgen.applicationdetailsexistingcinema EC left outer join dgen.applicationinspectiondetails AI on AI.cid=EC.cid and AI.WhetherActive=@WhetherActive inner join localitymaster LM on LM.localityid=EC.localityid inner join districtmaster DM on Dm.districtcode=EC.districtcode ";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@WhetherInspected", CustomText.False.ToString());
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
            model.data = data.GetDataTable(Cmd);
            PreserveModelState(Constant._ModelStateParent, model, true, false);
            return View(model);
        }
        [Authorize(Roles = "104,114,106,115")]
        [EncryptedActionParameter]
        public ActionResult ApplyInspectionOnCinema(int cid)
        {
            GetData data = new GetData();
            DecisionModels model = new DecisionModels();
            string Qry = "select to_char(InspectionDate,'DD/MM/YYYY') as InspectionDate from dgen.ApplicationInspectionDetails where cid=@cid and whetheractive=@whetheractive and whetherinspected=@whetherinspected";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@cid", cid);
            Cmd.Parameters.AddWithValue("@whetheractive", CustomText.True.ToString());
            Cmd.Parameters.AddWithValue("@whetherinspected", CustomText.False.ToString());
            DataTable dt = data.GetDataTable(Cmd);
            if (dt.Rows.Count > 0)
            {
                ViewData["message"] = "Inspection CANNOT be applied on this Cinema as an inspection is already PENDING on it with Inspection Date: " + dt.Rows[0]["InspectionDate"];
                return View("Message");
            }
            else
            {
                model.ApplicationDetailsCinematograph = new ApplicationDetailsCinematograph();
                model.ApplicationInspectionDetails = new ApplicationInspectionDetails();
                model.ApplicationDetailsCinematograph = Utility.GetExistingCinemaDetails(cid.ToString());
                model.ApplicationInspectionDetails.cid = cid.ToString();
                model.ApplicationInspectionDetails.TMCounter = "4";
                PreserveModelState(Constant._ModelStateParent, model, true, false);
                return View(model);
            }
        }
        [Authorize(Roles = "104,114,106,115")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ApplyInspectionOnCinema(DecisionModels model, FormCollection frm)
        {
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

            NpgsqlCommand updCmd = new NpgsqlCommand(@"insert into dgen.ApplicationInspectionDetails (cid,InspectionDate,InspectionTypeId,WhetherActive,WhetherInspected,PreInspectionRemarks,UserId,IpAddress,Actiondatetime) values (@cid,@InspectionDate,@InspectionTypeId,@WhetherActive,@WhetherInspected,@PreInspectionRemarks,@UserId,@IpAddress,now()); SELECT currval(pg_get_serial_sequence('dgen.applicationinspectiondetails','inspectionid'))");
            updCmd.Parameters.AddWithValue("@cid", model.ApplicationInspectionDetails.cid);
            updCmd.Parameters.AddWithValue("@InspectionDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDate, '/', "0/1/2"));
            updCmd.Parameters.AddWithValue("@InspectionTypeId", (int)InspectionTypeId.BiAnnual);
            updCmd.Parameters.AddWithValue("@PreInspectionRemarks", model.ApplicationInspectionDetails.PreInspectionRemarks);
            updCmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
            updCmd.Parameters.AddWithValue("@WhetherInspected", CustomText.False.ToString());
            updCmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
            updCmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
            cmdList.Add(updCmd);

            int varTMCount = Convert.ToInt16(model.ApplicationInspectionDetails.TMCounter);
            for (int i = 1; i <= varTMCount; i++)
            {
                if ((frm["ApplicationInspectionDetails.TValueId" + i] == null) && (frm["TName" + i] == null) && (frm["TDesignation" + i] == null) && (frm["TOAddress" + i] == null) && (frm["TContact" + i] == null) && (frm["TAName" + i] == null) && (frm["TAAddress" + i] == null))
                {
                    return RedirectToAction("BadRequest", "Error");
                }
                else
                {
                    ViewData["TValueId" + i] = frm["ApplicationInspectionDetails.TValueId" + i].ToString();
                    ViewData["TName" + i] = frm["TName" + i].ToString();
                    ViewData["TDesignation" + i] = frm["TDesignation" + i].ToString();
                    ViewData["TOAddress" + i] = frm["TOAddress" + i].ToString();
                    ViewData["TContact" + i] = frm["TContact" + i].ToString();
                    ViewData["TAName" + i] = frm["TAName" + i].ToString();
                    ViewData["TAAddress" + i] = frm["TAAddress" + i].ToString();

                    if ((string.IsNullOrEmpty(frm["ApplicationInspectionDetails.TValueId" + i].ToString())) || (string.IsNullOrEmpty(frm["TName" + i].ToString())) || (string.IsNullOrEmpty(frm["TDesignation" + i].ToString())) || (string.IsNullOrEmpty(frm["TOAddress" + i].ToString())) || (string.IsNullOrEmpty(frm["TContact" + i].ToString())) || (string.IsNullOrEmpty(frm["TAName" + i].ToString())) || (string.IsNullOrEmpty(frm["TAAddress" + i].ToString())))
                    {
                        model.ApplicationInspectionDetails.TMCounter = i.ToString();
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View((DecisionModels)TempData[Constant._ModelStateParent]);
                    }

                    string Qry = "INSERT INTO dgen.inspectionteammemberdetails(InspectionId,AuthorityTypeId,OfficerName,OfficerDesignation,OfficerContactNo,OfficerAddress,AuthorityName,AuthorityAddress,UserId,Ipaddress,lastactiondate)values(@LastInsertedId,@AuthorityTypeId,@OfficerName,@OfficerDesignation,@OfficerContactNo,@OfficerAddress,@AuthorityName,@AuthorityAddress,@UserId,@Ipaddress,now())";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@AuthorityTypeId", frm["ApplicationInspectionDetails.TValueId" + i].ToString());
                    Cmd.Parameters.AddWithValue("@OfficerName", frm["TName" + i].ToString());
                    Cmd.Parameters.AddWithValue("@OfficerDesignation", frm["TDesignation" + i].ToString());
                    Cmd.Parameters.AddWithValue("@OfficerContactNo", frm["TContact" + i].ToString());
                    Cmd.Parameters.AddWithValue("@OfficerAddress", frm["TOAddress" + i].ToString());
                    Cmd.Parameters.AddWithValue("@AuthorityName", frm["TAName" + i].ToString());
                    Cmd.Parameters.AddWithValue("@AuthorityAddress", frm["TAAddress" + i].ToString());
                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                }

            }

            updCmd = new NpgsqlCommand(@"update dgen.ApplicationInspectionDetails set WhetherActive=@WhetherActive,UserId=@UserId,IpAddress=@IpAddress,Actiondatetime=now() where cid=@cid and InspectionId<>@LastInsertedId");
            updCmd.Parameters.AddWithValue("@cid", model.ApplicationInspectionDetails.cid);
            updCmd.Parameters.AddWithValue("@WhetherActive", CustomText.False.ToString());
            updCmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
            updCmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
            cmdList.Add(updCmd);

            string[] GV = Utility.SelectColumnsValue("dgen.applicationdetailsexistingcinema", "noofscreens,CinemaAddress,ContactNo", "cid", model.ApplicationInspectionDetails.cid);//change169
            Int32 NoOfScreens = Convert.ToInt32(GV[0]);
            string CinemaAddr = GV[1].Trim();
            string MobNo = GV[2].Trim();

            for (int i = 1; i <= NoOfScreens; i++)
            {
                updCmd = new NpgsqlCommand(@"insert into dgen.InspectionDetails (InspectionId,ScreenNo,UserId,IpAddress,Actiondatetime) values (@LastInsertedId,@ScreenNo,@UserId,@IpAddress,now())");
                updCmd.Parameters.AddWithValue("@ScreenNo", i);
                updCmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                updCmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                cmdList.Add(updCmd);
            }

            updCmd = new NpgsqlCommand(@"update dgen.ApplicationDetailsExistingCinema set StatusId=@StatusId,Actiondatetime=now() where cid=@cid");
            updCmd.Parameters.AddWithValue("@cid", model.ApplicationInspectionDetails.cid);
            updCmd.Parameters.AddWithValue("@StatusId", (int)ValueId.CinemaInspectionInitiated);
            updCmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
            cmdList.Add(updCmd);

            //send sms to applicant and insert record in table
            Dictionary<string, string> smsDic = new Dictionary<string, string>();
            smsDic.Add("ParamMobileNo", MobNo);
            smsDic.Add("ParamDate", model.ApplicationInspectionDetails.InspectionDate);
            smsDic.Add("ParamAddress", CinemaAddr);
            cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS023, smsDic));

            //send email to applicant and insert record in table
            Dictionary<string, string> EmailDic = new Dictionary<string, string>();
            EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
            EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS023).ToString());
            EmailDic.Add("ParamMobileNo", MobNo);
            EmailDic.Add("ParamDate", model.ApplicationInspectionDetails.InspectionDate);
            EmailDic.Add("ParamAddress", CinemaAddr);
            NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
            if (EmailCmd != null) { cmdList.Add(EmailCmd); }

            data.SaveTransactionalData(cmdList);

            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "CId" }, new ArrayList() { model.ApplicationInspectionDetails.cid.ToString() });
            return RedirectToAction("PrintCinemaInitiateInspectionLetter", "Print", new { q = QueryString });
        }
        [Authorize(Roles = "106")]
        [EncryptedActionParameter]
        public ActionResult CinemaRectification(int CId)
        {
            DecisionModels model = new DecisionModels();
            model.ApplicationDetailsCinematograph = new ApplicationDetailsCinematograph();
            model.ApplicationInspectionDetails = new ApplicationInspectionDetails();
            model.ApplicationDetailsCinematograph = Utility.GetExistingCinemaDetails(CId.ToString());
            model.ApplicationInspectionDetails.cid = CId.ToString();
            PreserveModelState(Constant._ModelStateParent, model, true, false);
            return View(model);
        }
        [Authorize(Roles = "106")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult CinemaRectification(DecisionModels model)
        {
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            string Qry = "update dgen.ApplicationInspectionDetails set RectificationRemarks=@ApplicationRemarks where cid=@cid and WhetherActive=@WhetherActive";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@cid", model.ApplicationInspectionDetails.cid);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
            Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationInspectionDetails.Observation);
            cmdList.Add(Cmd);

            Cmd = new NpgsqlCommand(@"update dgen.ApplicationDetailsExistingCinema set StatusId=@StatusId,Actiondatetime=now() where cid=@cid");
            Cmd.Parameters.AddWithValue("@cid", model.ApplicationInspectionDetails.cid);
            Cmd.Parameters.AddWithValue("@StatusId", (int)ValueId.CinemaInspectionEntered);
            Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
            cmdList.Add(Cmd);

            data.SaveData(cmdList);
            return RedirectToAction("CinemaListForInspection");
        }
        [Authorize(Roles = "104,114,106,115")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult CinemaReInspection(DecisionModels model)
        {
            GetData data = new GetData();
            DataTable dt = new DataTable(); string Qry = string.Empty;
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            if (!string.IsNullOrEmpty(model.ApplicationInspectionDetails.cid))
            {
                Qry = "select to_char(InspectionDate,'DD/MM/YYYY') as InspectionDate from dgen.ApplicationInspectionDetails where cid=@cid and whetheractive=@whetheractive and whetherinspected=@whetherinspected";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@cid", model.ApplicationInspectionDetails.cid);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.True.ToString());
                Cmd.Parameters.AddWithValue("@whetherinspected", CustomText.False.ToString());
                dt = data.GetDataTable(Cmd);
                if (dt.Rows.Count > 0)
                {
                    NpgsqlCommand updCmd = new NpgsqlCommand(@"insert into dgen.ApplicationInspectionDetails (cid,InspectionDate,InspectionTypeId,OfficerName,OfficerDesignation,OfficerContactNo,WhetherActive,WhetherInspected,PreInspectionRemarks,UserId,IpAddress,Actiondatetime) values (@cid,@InspectionDate,@InspectionTypeId,@OfficerName,@OfficerDesignation,@OfficerContactNo,@WhetherActive,@WhetherInspected,@PreInspectionRemarks,@UserId,@IpAddress,now()); SELECT currval(pg_get_serial_sequence('dgen.applicationinspectiondetails','inspectionid'))");
                    updCmd.Parameters.AddWithValue("@cid", model.ApplicationInspectionDetails.cid);
                    updCmd.Parameters.AddWithValue("@InspectionDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDate, '/', "0/1/2"));
                    updCmd.Parameters.AddWithValue("@OfficerName", model.ApplicationInspectionDetails.OfficerName);
                    updCmd.Parameters.AddWithValue("@OfficerDesignation", model.ApplicationInspectionDetails.OfficerDesignation);
                    updCmd.Parameters.AddWithValue("@InspectionTypeId", (int)InspectionTypeId.BiAnnual);
                    updCmd.Parameters.AddWithValue("@OfficerContactNo", model.ApplicationInspectionDetails.OfficerContactNo);
                    updCmd.Parameters.AddWithValue("@PreInspectionRemarks", model.ApplicationInspectionDetails.PreInspectionRemarks);
                    updCmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                    updCmd.Parameters.AddWithValue("@WhetherInspected", CustomText.False.ToString());
                    updCmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    updCmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(updCmd);

                    updCmd = new NpgsqlCommand(@"update dgen.ApplicationInspectionDetails set WhetherActive=@WhetherActive,UserId=@UserId,IpAddress=@IpAddress,Actiondatetime=now() where cid=@cid and InspectionId<>@LastInsertedId");
                    updCmd.Parameters.AddWithValue("@cid", model.ApplicationInspectionDetails.cid);
                    updCmd.Parameters.AddWithValue("@WhetherActive", CustomText.False.ToString());
                    updCmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    updCmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(updCmd);

                    Int32 NoOfScreens = Convert.ToInt32(Utility.SelectColumnsValue("dgen.applicationdetailsexistingcinema", "noofscreens", "cid", model.ApplicationInspectionDetails.cid)[0]);

                    for (int i = 1; i <= NoOfScreens; i++)
                    {
                        updCmd = new NpgsqlCommand(@"insert into dgen.InspectionDetails (InspectionId,ScreenNo,UserId,IpAddress,Actiondatetime) values (@LastInsertedId,@ScreenNo,@UserId,@IpAddress,now())");
                        updCmd.Parameters.AddWithValue("@ScreenNo", i);
                        updCmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                        updCmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                        cmdList.Add(updCmd);
                    }
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationInspectionDetails.cid, (int)ApplicationHistoryMessage.MSG035, "Re-Inspection Date Selected: " + model.ApplicationInspectionDetails.InspectionDate, (int)ApplicationSource.Window, null));
                    data.SaveTransactionalData(cmdList);
                    return RedirectToAction("CinemaListForInspection", "Decision");
                }
            }
            else if (!string.IsNullOrEmpty(model.ApplicationNo))
            {
                Qry = "select to_char(InspectionDate,'DD/MM/YYYY') as InspectionDate from dgen.ApplicationInspectionDetails where ApplicationNo=@ApplicationNo and whetheractive=@whetheractive and whetherinspected=@whetherinspected";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.True.ToString());
                Cmd.Parameters.AddWithValue("@whetherinspected", CustomText.False.ToString());
                dt = data.GetDataTable(Cmd);

                if (dt.Rows.Count > 0)
                {
                    NpgsqlCommand updCmd = new NpgsqlCommand(@"insert into dgen.ApplicationInspectionDetails (ApplicationNo,InspectionDate,InspectionTypeId,OfficerName,OfficerDesignation,OfficerContactNo,WhetherActive,WhetherInspected,PreInspectionRemarks,UserId,IpAddress,Actiondatetime) values (@ApplicationNo,@InspectionDate,@InspectionTypeId,@OfficerName,@OfficerDesignation,@OfficerContactNo,@WhetherActive,@WhetherInspected,@PreInspectionRemarks,@UserId,@IpAddress,now()); SELECT currval(pg_get_serial_sequence('dgen.applicationinspectiondetails','inspectionid'))");
                    updCmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    updCmd.Parameters.AddWithValue("@InspectionDate", Utility.GetDateYYYYMMDD(model.ApplicationInspectionDetails.InspectionDate, '/', "0/1/2"));
                    updCmd.Parameters.AddWithValue("@OfficerName", model.ApplicationInspectionDetails.OfficerName);
                    updCmd.Parameters.AddWithValue("@OfficerDesignation", model.ApplicationInspectionDetails.OfficerDesignation);
                    updCmd.Parameters.AddWithValue("@InspectionTypeId", (int)InspectionTypeId.Fresh);
                    updCmd.Parameters.AddWithValue("@OfficerContactNo", model.ApplicationInspectionDetails.OfficerContactNo);
                    updCmd.Parameters.AddWithValue("@PreInspectionRemarks", model.ApplicationInspectionDetails.PreInspectionRemarks);
                    updCmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                    updCmd.Parameters.AddWithValue("@WhetherInspected", CustomText.False.ToString());
                    updCmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    updCmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(updCmd);

                    updCmd = new NpgsqlCommand(@"update dgen.ApplicationInspectionDetails set WhetherActive=@WhetherActive,UserId=@UserId,IpAddress=@IpAddress,Actiondatetime=now() where ApplicationNo=@ApplicationNo and InspectionId<>@LastInsertedId");
                    updCmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    updCmd.Parameters.AddWithValue("@WhetherActive", CustomText.False.ToString());
                    updCmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    updCmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(updCmd);

                    Int32 NoOfScreens = Convert.ToInt32(Utility.SelectColumnsValue("dgen.applicationdetailscinematograph", "noofscreens", "ApplicationNo", model.ApplicationNo)[0]);

                    for (int i = 1; i <= NoOfScreens; i++)
                    {
                        updCmd = new NpgsqlCommand(@"insert into dgen.InspectionDetails (InspectionId,ScreenNo,UserId,IpAddress,Actiondatetime) values (@LastInsertedId,@ScreenNo,@UserId,@IpAddress,now())");
                        updCmd.Parameters.AddWithValue("@ScreenNo", i);
                        updCmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                        updCmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                        cmdList.Add(updCmd);
                    }
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG035, "Re-Inspection Date Selected: " + model.ApplicationInspectionDetails.InspectionDate, (int)ApplicationSource.Window, null));
                    data.SaveTransactionalData(cmdList);
                }
            }
            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "ServiceCode" }, new ArrayList() { model.ServiceCode });
            return RedirectToAction("PendingCountForInspection", "Decision", new { q = QueryString });
        }
        #endregion

        #region global method current contoller
        //method for preserve model state
        public void PreserveModelState(string Key, object obj, bool IsKeep, bool IsRemove)
        {
            if (IsRemove == true) { TempData.Remove(Key); }
            if (obj != null) { TempData[Key] = obj; }
            if (IsKeep == true) { TempData.Keep(Key); }
        }
        #endregion global method current contoller
    }
}
