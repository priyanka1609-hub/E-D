﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using System.Security.Cryptography;
using System.Text;
using Edistrict.Models.CustomAttribute;

namespace Edistrict.Controllers
{
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class ErrorController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult NotFound()
        {
            return View();
        }
        public ActionResult InternalError()
        {
            return RedirectToAction("OperationalAlert", "Error");
        }
        public ActionResult Refresh()
        {
            return View();
        }
        public ActionResult UnauthorizedRequest()
        {
            return View();
        }
        public ActionResult BadRequest()
        {
            return View();
        }
        public ActionResult Forbidden()
        {
            return View();
        }
        public ActionResult OperationalError()
        {
            return View();
        }
        public ActionResult DigitalProcessError()
        {
            return View();
        }
        public ActionResult JavascriptError()
        {
            return View();
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult MultipleLogin(string Uid)
        {
            if (string.IsNullOrEmpty(Uid)) { return RedirectToAction("UnauthorizedRequest"); }
            ViewBag.UserId = Uid;
            return View();
        }
        public ActionResult CustomError()
        {
            ViewBag.ErrorString = Session["globalEx"].ToString();
            return View();
        }
        public ActionResult HeavyTraffic()
        {
            return View();
        }

        public ActionResult OperationalAlert()
        {
            return View();
        }
    }
}
