﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Edistrict.Models.DataService;
using Edistrict.Models;
using System.Data.SqlClient;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.Entities;
using Edistrict.Models.CustomAttribute;
using System.Web.UI;
using Npgsql;
using System.Data;
using System.Collections;
using System.Text;
using System.IO;

namespace Edistrict.Controllers
{
    [Authorize]
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class ReportController : Controller
    {
        #region General & Common Report
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DistrictWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("DistrictWiseReport", "Report", new { q = QueryString });
            }
            return View("DistrictWiseReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DistrictWiseReport(int? servicode, string DTF, string DTT)
        {
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { return RedirectToAction("DistrictWiseReport"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,DM.DistrictCode,DM.DistrictName,
                            coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) CSCReceived,
                            coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) CitizenReceived,
                            coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId2 and ApplicationStatusId in (@ApplicationStatus16) then 1 end),0) as CSCApproved,
                            coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId1 and ApplicationStatusId in (@ApplicationStatus16) then 1 end),0) as CitizenApproved
                            from dbo.ApplicationDetails AD right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode 
                            where DM.deptcode = @ParamDeptCode and AD.Servicecode in (Select ServiceCode from ServiceMaster Where DeptCode=@ParamDeptCode)";
            if (!string.IsNullOrEmpty(servicode.ToString())) { Qry += " and AD.ServiceCode in (@ServiceCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by DM.DistrictCode,DM.DistrictName order by DM.DistrictName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", servicode);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@ApplicationSourceId2", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            if (servicode != null)
            {
                Qry = "select SC.ServiceName,SC.ServiceCode from dbo.ApplicationDetails AD right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where ";
                if (servicode != null) { Qry += " SC.Deptcode = @Deptcode and SC.ServiceCode=@ServiceCode group by SC.ServiceName,SC.ServiceCode order by SC.ServiceName"; }
                NpgsqlCommand cmd1 = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd1.Parameters.AddWithValue("@ServiceCode", servicode);
                model.dataa = data.GetDataTable(cmd1);
                model.ServiceCode = servicode.ToString();
            }

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ServiceDistWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("ServiceDistWiseReport", "Report", new { q = QueryString });
            }
            return View("ServiceDistWiseReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ServiceDistWiseReport(int? distId, string DTF, string DTT)
        {
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { return RedirectToAction("DistrictWiseReport"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SC.ServiceName,SC.ServiceCode,
                            coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) CSCReceived,
                            coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) CitizenReceived,
                            coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId2 and ApplicationStatusId in (@ApplicationStatus16) then 1 end),0) as CSCApproved,
                            coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId1 and ApplicationStatusId in (@ApplicationStatus16) then 1 end),0) as CitizenApproved
                            from dbo.ApplicationDetails AD right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode 
                            right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode = @ParamDeptCode";
            if (distId != null) { Qry += " and DM.DistrictCode=@DistrictCode"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DistrictCode", distId);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@ApplicationSourceId2", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            if (distId != null)
            {
                Qry = " Select DistrictCode,DistrictName from dbo.DistrictMaster where deptcode=@ParamDeptCode ";
                if (distId != null) { Qry += " and DistrictCode=@DistrictCode"; }
                NpgsqlCommand cmd1 = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd1.Parameters.AddWithValue("@DistrictCode", distId);
                model.dataa = data.GetDataTable(cmd1);
                model.DistrictCode = distId.ToString();
            }
            return View(model);
        }
        [HttpGet]
        public ActionResult DocumentSeenPending()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { whereCondition += " and AD.ApplicationDistrictCode=@ParamDistrictCode "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { whereCondition += " and AD.ApplicationSubDivCode=@ParamSubDivCode "; }
            string Qry = "select ApplicationNo,ApplicantName,case when ApplicantGender='M' then 'Male' when ApplicantGender='F' then 'Female' when ApplicantGender='T' then 'Transgender' end as ApplicantGender,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate  from applicationdetails AD inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where WhetherDocumentSeen=@WhetherDocumentSeen and Deptcode=@ParamDeptCode " + whereCondition + " order by ApplicationDate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@WhetherDocumentSeen", CustomText.FALSE.ToString());
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AllowAnonymous]
        public ActionResult DownloadExcelReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            return View(model);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public void DownloadExcelReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = "select AD.ApplicationNo as \"Application No\",applicantname as \"Applicant Name\",dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as \"Applicant Address\",to_char(ApplicationDate,'DD/MM/YYYY') as \"Date of Application\",to_char(ApprovedDate,'DD/MM/YYYY') as \"Date of Disposal\",	SM.statusName as \"Status\"	from applicationdetails AD inner join statusmaster SM on SM.statusid=AD.applicationstatusid inner join servicemaster ST on ST.servicecode=AD.servicecode where applicationsubdivcode in (892) and date_part('month',AD.applicationdate)=@Month and date_part('year',AD.applicationdate)=@Year order by ST.servicename,AD.ApplicationNo";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@Month", model.Month);
                Cmd.Parameters.AddWithValue("@Year", model.Year);
                DataTable dt = new DataTable();
                dt = data.GetDataTable(Cmd);

                var grid = new System.Web.UI.WebControls.GridView();
                grid.DataSource = dt;
                grid.DataBind();

                Response.ClearContent();
                Response.AddHeader("content-disposition", "attachment; filename=Edistrict_Report_[" + model.Month + "-" + model.Year + "].xls");
                Response.ContentType = "application/excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                grid.RenderControl(htw);
                Response.Write(sw.ToString());
                Response.Headers.Clear();
                Response.End();
            }
        }
        [EncryptedActionParameter]
        public ActionResult CitizenAppointmentReport(string AppDate)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            if (string.IsNullOrEmpty(AppDate)) { model.DateFrom = DateTime.Now.ToString("dd/MM/yyyy"); }
            model.DistrictCode = Sessions.getEmployeeUser().DistrictCode;
            string Qry1 = "select RM.RegistrationId,ApplicantName,ApplicantFatherName,dbo.displaycompleteaddressfromid(ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,RM.ApplicantLocalityId,RM.ApplicantSubDivCode,RM.ApplicantDistrictCode,RM.ApplicantStateId,RM.ApplicantCountryId,ApplicantPinCode) as ApplicantAddress ,ApplicantMobileNo,SMVD.valueid,SMVD.valuename as AppointmentTime,to_char(CA.AppointmentDate,'DD-MM-YYYY') as DisplayAppointmentDate,to_char(CA.AppointmentDate,'YYYY-MM-DD') as ValueAppointmentDate,CA.reasonofappointment from web.RegistrationMaster RM inner join citizenappointmentdetails CA on CA.RegistrationId=RM.RegistrationId inner join dbo.selectmastervaluedetails SMVD on CA.AppointmentTime=SMVD.ValueId  where CA.AppointmentDate=@AppointmentDate";
            if (!string.IsNullOrEmpty(model.DistrictCode)) { Qry1 += " and CA.DistrictCode=@DistrictCode"; }
            Qry1 += " order by SMVD.valueid";
            NpgsqlCommand Cmd1 = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry1));
            if (!string.IsNullOrEmpty(model.DistrictCode)) { Cmd1.Parameters.AddWithValue("@DistrictCode", model.DistrictCode); }
            if (!string.IsNullOrEmpty(model.DateFrom)) { Cmd1.Parameters.AddWithValue("@AppointmentDate", Utility.ConvertDateSequenceForDatabase(model.DateFrom, '/', true)); }
            if (!string.IsNullOrEmpty(AppDate)) { Cmd1.Parameters.AddWithValue("@AppointmentDate", Utility.ConvertDateSequenceForDatabase(AppDate, '/', true)); }
            model.data = data.GetDataTable(Cmd1);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult CitizenAppointmentReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppDate" }, new ArrayList() { model.DateFrom });
                return RedirectToAction("CitizenAppointmentReport", "Report", new { q = QueryString });
            }
            return View("CitizenAppointmentReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult CitizenAppointmentDetailsReport(int RId, string AppDate)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select dbo.udf_general_decrypt(DocumentNo) as DocumentNo,DocM.DocumentName,ApplicantName,ApplicantGender,to_char(ApplicantDob,'DD/MM/YYYY') as ApplicantDob,ApplicantFatherName,ApplicantMotherName,ApplicantSpouseName as ApplicantHusbandName,dbo.displaycompleteaddressfromid(ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,RM.ApplicantLocalityId,RM.ApplicantSubDivCode,RM.ApplicantDistrictCode,RM.ApplicantStateId,RM.ApplicantCountryId,ApplicantPinCode) as ApplicantAddress ,ApplicantMobileNo,SD.Subdivdescription as applicantsubdivcode,DM.DistrictName as ApplicantDistrictCode,ApplicantPermanentAddress,DM.daddress,DM.dcontact,DM.demail,to_char(CA.AppointmentDate,'DD/MM/YYYY') as AppointmentDate,SMVD.valuename as AppointmentTime,CA.ReasonofAppointment from web.RegistrationMaster RM   inner join dbo.SubDivMaster SD on SD.SubDivCode=RM.ApplicantSubDivCode inner join dbo.DistrictMaster DM on DM.DistrictCode=RM.ApplicantDistrictCode inner join dbo.DocumentMaster DocM on DocM.DocumentId=RM.DocumentId  left outer join citizenappointmentdetails CA on CA.RegistrationId=RM.RegistrationId inner join dbo.selectmastervaluedetails SMVD on CA.AppointmentTime=SMVD.ValueId where RM.RegistrationId=@RegistrationId and CA.AppointmentDate=@AppointmentDate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@RegistrationId", RId);
            cmd.Parameters.AddWithValue("@AppointmentDate", AppDate);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult CitizenAppointmentReportwithDC(int RId)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select RM.RegistrationId,ApplicantName,ReasonofAppointment,dbo.displaycompleteaddressfromid(ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,RM.ApplicantLocalityId,RM.ApplicantSubDivCode,RM.ApplicantDistrictCode,RM.ApplicantStateId,RM.ApplicantCountryId,ApplicantPinCode) as ApplicantAddress ,ApplicantMobileNo,SMVD.valueid,SMVD.valuename as AppointmentTime,to_char(CA.AppointmentDate,'DD-MM-YYYY') as AppointmentDate from web.RegistrationMaster RM inner join citizenappointmentdetails CA on CA.RegistrationId=RM.RegistrationId inner join dbo.selectmastervaluedetails SMVD on CA.AppointmentTime=SMVD.ValueId  where CA.RegistrationId=@RegistrationId order by SMVD.valueid";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@RegistrationId", RId);
            model.data = data.GetDataTable(Cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult DistWiseCitizenAppointmentReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.DistrictCode = Sessions.getEmployeeUser().DistrictCode;
            string Qry1 = "select AD.districtcode,DM.districtname,coalesce(count(registrationid),0) Received from citizenappointmentdetails  AD inner join districtmaster DM on DM.districtcode=AD.districtcode group by AD.districtcode,DM.districtname,AD.districtcode order by DM.districtname";
            NpgsqlCommand Cmd1 = new NpgsqlCommand(Qry1);
            model.data = data.GetDataTable(Cmd1);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult DateWiseCitizenAppointmentReport(Int32 Dist)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.DistrictCode = Dist.ToString();
            string Qry = "select to_char(AD.appointmentdate,'DD/MM/YYYY') as appointmentdate,to_char(AD.appointmentdate,'YYYY-MM-DD') as valueappointmentdate,AD.districtcode,DM.districtname,coalesce(count(registrationid),0) Received from citizenappointmentdetails  AD inner join districtmaster DM on DM.districtcode=AD.districtcode  where AD.districtcode=@DistrictCode group by AD.appointmentdate,AD.districtcode,DM.districtname order by AD.appointmentdate desc";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DistrictCode", model.DistrictCode);
            model.data = data.GetDataTable(Cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult TimeWiseCitizenAppointment(Int32 Dist, string Date)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.DistrictCode = Dist.ToString();
            string Qry1 = "select RM.RegistrationId,ApplicantName,ApplicantFatherName,dbo.displaycompleteaddressfromid(ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,RM.ApplicantLocalityId,RM.ApplicantSubDivCode,RM.ApplicantDistrictCode,RM.ApplicantStateId,RM.ApplicantCountryId,ApplicantPinCode) as ApplicantAddress ,ApplicantMobileNo,SMVD.valueid,SMVD.valuename as AppointmentTime,to_char(CA.AppointmentDate,'DD-MM-YYYY') as DisplayAppointmentDate,to_char(CA.AppointmentDate,'YYYY-MM-DD') as ValueAppointmentDate,CA.reasonofappointment from web.RegistrationMaster RM inner join citizenappointmentdetails CA on CA.RegistrationId=RM.RegistrationId inner join dbo.selectmastervaluedetails SMVD on CA.AppointmentTime=SMVD.ValueId  where CA.AppointmentDate=@AppointmentDate and CA.DistrictCode=@DistrictCode";
            Qry1 += " order by SMVD.valueid";
            NpgsqlCommand Cmd1 = new NpgsqlCommand(Qry1);
            Cmd1.Parameters.AddWithValue("@DistrictCode", model.DistrictCode);
            Cmd1.Parameters.AddWithValue("@AppointmentDate", Date);
            model.data = data.GetDataTable(Cmd1);
            return View(model);
        }





        #endregion

        #region Revenue Department Reports

        #region Tirth Yatra Service MIS 
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult TirthYatraACWisereport(int? acid)
        {
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { return RedirectToAction("TirthYatraACWisereport"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = @"select count(applicationno) as applicationcount, SMVD.valuename as routename,SMVD.valueid as routeid from dgen.applicationdetailstirthyatrayojana ADTY left outer join selectmastervaluedetails SMVD on SMVD.valueid=ADTY.routeid ";
            if (acid != null) { Qry += " where constituencyid=@constituencyid"; }
            Qry += " group by SMVD.valueid,SMVD.valuename order by SMVD.valuename";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@constituencyid", acid);
            model.data = data.GetDataTable(cmd);

            if (acid != null)
            {
                Qry = " Select constituencyid,constituencyname from dbo.assemblyconstituencymaster where constituencyid=@constituencyid ";
                NpgsqlCommand cmd1 = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd1.Parameters.AddWithValue("@constituencyid", acid);
                model.dataa = data.GetDataTable(cmd1);
                model.ConstituencyId = acid.ToString();
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult TirthYatraACWisereport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "acid" }, new ArrayList() { model.ConstituencyId });
                return RedirectToAction("TirthYatraACWisereport", "Report", new { q = QueryString });
            }
            return View("TirthYatraACWisereport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult TirthYatraRouteWisereport(int? routeid)
        {
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { return RedirectToAction("TirthYatraACWisereport"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = @"select count(applicationno) as applicationcount, constituencyname,ADTY.constituencyid from dgen.applicationdetailstirthyatrayojana ADTY inner join assemblyconstituencymaster ACM on ACM.constituencyid = ADTY.constituencyid ";
            if (routeid != null) { Qry += "where routeid=@routeid "; }
            Qry += " group by constituencyname,ADTY.constituencyid order by constituencyname ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@routeid", routeid);
            model.data = data.GetDataTable(cmd);

            if (routeid != null)
            {
                Qry = " Select valueid as routeid,valuename as routename from dbo.selectmastervaluedetails where valueid=@routeid ";
                NpgsqlCommand cmd1 = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd1.Parameters.AddWithValue("@routeid", routeid);
                model.dataa = data.GetDataTable(cmd1);
                model.RouteId = routeid.ToString();
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult TirthYatraRouteWisereport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "routeid" }, new ArrayList() { model.RouteId });
                return RedirectToAction("TirthYatraRouteWisereport", "Report", new { q = QueryString });
            }
            return View("TirthYatraRouteWisereport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult TirthYatraApplicationDetails(int? acid, int? routeid)
        {
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { return RedirectToAction("DistrictWiseReport"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = @"select AD.applicationno,applicantname,applicantgender,to_char(applicantdob,'DD/MM/YYYY') as applicantdob,applicantmobileno, dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress, valuename as routename, constituencyname from applicationdetails AD 
                            inner join dgen.applicationdetailstirthyatrayojana ADTY on ADTY.applicationno = AD.applicationno inner join assemblyconstituencymaster ACM on ACM.constituencyid = ADTY.constituencyid 
                            inner join selectmastervaluedetails SMVD on SMVD.valueid = ADTY.routeid where 1=1";
            if (acid != null) { Qry += " and ADTY.constituencyid=@constituencyid"; }
            if (routeid != null) { Qry += " and ADTY.routeid=@routeid"; }
            Qry += " order by AD.applicantname";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@constituencyid", acid);
            cmd.Parameters.AddWithValue("@routeid", routeid);
            model.data = data.GetDataTable(cmd);

            //if (distId != null)
            //{
            //    Qry = " Select DistrictCode,DistrictName from dbo.DistrictMaster where deptcode=@ParamDeptCode ";
            //    if (distId != null) { Qry += " and DistrictCode=@DistrictCode"; }
            //    NpgsqlCommand cmd1 = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            //    cmd1.Parameters.AddWithValue("@DistrictCode", distId);
            //    model.dataa = data.GetDataTable(cmd1);
            //    model.DistrictCode = distId.ToString();
            //}
            return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult YatraSummaryReport(int? RouteId = 0, int? ConstituencyId = 0, int? DistrictCode = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            if (Sessions.getEmployeeUser().DistrictCode != null) { DistrictCode = Convert.ToInt16(Sessions.getEmployeeUser().DistrictCode); }

            string Qry = "select SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName,count(AD.ApplicationNo) as total,sum(1 + (case when whetherappyingwithspouse=true then 1 else 0 end) + (case when optingforattendant=true then 1 else 0 end)) as totalMember,coalesce(sum(case when ApplicationStatusId in (5) then 1 end),0) as Pending,coalesce(sum(case when ApplicationStatusId in (16) then 1 end),0) as Recommended, coalesce(sum(case when ApplicationStatusId in (14) then 1 end),0) as NotRecommended,SMVD.ValueId,ACM.constituencyid from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid inner join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.ServiceCode in (@TirthServiceCode)";
            if (RouteId != (int)CountList.Type000) { Qry += " and ADTY.RouteId=@RouteId "; }
            if (DistrictCode != (int)CountList.Type000) { Qry += " and ADTY.constituencyid in (select constituencyid from districttoconstituencymaster where districtcode = @DistrictCode) "; }
            if (ConstituencyId != (int)CountList.Type000) { Qry += " and ADTY.constituencyid=@ConstituencyId "; }
            Qry += " group by SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName order by SMVD.ValueName,constituencyName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@RouteId", RouteId);
            cmd.Parameters.AddWithValue("@ConstituencyId", ConstituencyId);
            cmd.Parameters.AddWithValue("@DistrictCode", DistrictCode);
            cmd.Parameters.AddWithValue("@TirthServiceCode", (int)ServiceList.TirthYatraYojna);
            model.data = data.GetDataTable(cmd);
            if (RouteId != (int)CountList.Type000) { model.RouteId = RouteId.ToString(); }
            if (ConstituencyId != (int)CountList.Type000) { model.ConstituencyId = ConstituencyId.ToString(); }
            if (DistrictCode != (int)CountList.Type000) { model.DistrictCode = DistrictCode.ToString(); }
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult YatraSummaryReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int RouteId = 0, ConstituencyId = 0, DistrictCode = 0;
                if (!string.IsNullOrEmpty(model.RouteId)) { RouteId = Convert.ToInt32(model.RouteId); }
                if (!string.IsNullOrEmpty(model.ConstituencyId)) { ConstituencyId = Convert.ToInt32(model.ConstituencyId); }
                if (!string.IsNullOrEmpty(model.DistrictCode)) { DistrictCode = Convert.ToInt32(model.DistrictCode); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "RouteId", "ConstituencyId", "DistrictCode" }, new ArrayList() { RouteId, ConstituencyId, DistrictCode });
                return RedirectToAction("YatraSummaryReport", "Report", new { q = QueryString });
            }
            return View("YatraSummaryReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult YatraSummaryAppViewList(int RouteId, int ConstituencyId, int StatusId = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName,to_Char(AD.applicationdate,'DD/MM/YYY')as DateofApplication,sum(1 + (case when whetherappyingwithspouse=true then 1 else 0 end) + (case when optingforattendant=true then 1 else 0 end)) as totalrecMember from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo  inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid inner join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where AD.ServiceCode=@ServiceCode and ADTY.constituencyid=@ConstituencyId and ADTY.RouteId=@RouteId ";
            if (StatusId != 0) { Qry += "and AD.ApplicationStatusId=@ApplicationStatusId"; }
            Qry += " group by AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,SL.StatusName,AD.ApplicationStatusId,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.TirthYatraYojna);
            cmd.Parameters.AddWithValue("@RouteId", RouteId);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", StatusId);
            cmd.Parameters.AddWithValue("@ConstituencyId", ConstituencyId);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        


        [EncryptedActionParameter]
        public ActionResult YatraVisitedSummaryReport(int? RouteId = 0, int? ConstituencyId = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            //string Qry = "select SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName,coalesce(sum(case when ApplicationStatusId in (@ISSUCER) then 1 end),0) as total,sum((case when ApplicationStatusId=@ISSUCER then 1 else 0 end) + (case when ApplicationStatusId=@ISSUCER and whetherappyingwithspouse=@WhetherTrue then 1 else 0 end) + (case when ApplicationStatusId=@ISSUCER  and optingforattendant=@WhetherTrue then 1 else 0 end)) as totalMember,coalesce(sum(case when ApplicationStatusId in (@ISSUCER) and WhetherPresentInTrip=@WhetherTrue then 1 end),0) as ApprovedByChairman,sum((case when ApplicationStatusId=@ISSUCER and WhetherPresentInTrip=@WhetherTrue then 1 else 0 end) + (case when ApplicationStatusId=@ISSUCER and whetherappyingwithspouse=@WhetherTrue and WhetherPresentInTrip=@WhetherTrue then 1 else 0 end) + (case when ApplicationStatusId=@ISSUCER  and optingforattendant=@WhetherTrue and WhetherPresentInTrip=@WhetherTrue then 1 else 0 end)) as totalrecMember from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid inner join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) ";

            string Qry = "select SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName,count(AD.applicationno) as total,sum((case when ApplicationStatusId not in (@ISSUCER) then 1 else 0 end) + (case when ApplicationStatusId not in (@ISSUCER) and whetherappyingwithspouse=@WhetherTrue then 1 else 0 end) + (case when ApplicationStatusId not in (@ISSUCER)  and optingforattendant=@WhetherTrue then 1 else 0 end)) as totalMember,coalesce(sum(case when ApplicationStatusId not in (@ISSUCER) and WhetherPresentInTrip=@WhetherTrue then 1 end),0) as ApprovedByChairman,sum((case when ApplicationStatusId not in (@ISSUCER) and WhetherPresentInTrip=@WhetherTrue then 1 else 0 end) + (case when ApplicationStatusId not in (@ISSUCER) and whetherappyingwithspouse=@WhetherTrue and WhetherPresentInTrip=@WhetherTrue then 1 else 0 end) + (case when ApplicationStatusId not in (@ISSUCER)  and optingforattendant=@WhetherTrue and WhetherPresentInTrip=@WhetherTrue then 1 else 0 end)) as totalrecMember from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid inner join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) ";
            if (RouteId != (int)CountList.Type000) { Qry += " and ADTY.RouteId=@RouteId "; }
            if (ConstituencyId != (int)CountList.Type000) { Qry += " and ADTY.constituencyid=@ConstituencyId "; }
            Qry += " group by SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName order by SMVD.ValueName,constituencyName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@RouteId", RouteId);
            cmd.Parameters.AddWithValue("@ConstituencyId", ConstituencyId);
            cmd.Parameters.AddWithValue("@ConstituencyId", ConstituencyId);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@WhetherTrue", CustomText.True.ToString());
            model.data = data.GetDataTable(cmd);
            if (RouteId != (int)CountList.Type000) { model.RouteId = RouteId.ToString(); }
            if (ConstituencyId != (int)CountList.Type000) { model.ConstituencyId = ConstituencyId.ToString(); }
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult YatraVisitedSummaryReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int RouteId = 0, ConstituencyId = 0;
                if (!string.IsNullOrEmpty(model.RouteId)) { RouteId = Convert.ToInt32(model.RouteId); }
                if (!string.IsNullOrEmpty(model.ConstituencyId)) { ConstituencyId = Convert.ToInt32(model.ConstituencyId); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "RouteId", "ConstituencyId" }, new ArrayList() { RouteId, ConstituencyId });
                return RedirectToAction("YatraVisitedSummaryReport", "Process", new { q = QueryString });
            }
            return View("YatraVisitedSummaryReport", model);
        }
        #endregion

        [EncryptedActionParameter]
        public ActionResult BasicApplicationDetails(int? subDiv, int? service, int? status, string DTF, string DTT, int? PageIndex = 1)
        {
            if (subDiv == null && service == null && status == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }
            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "subDiv=" + subDiv.ToString());
            Parameters.Add(1, "service=" + service.ToString());
            Parameters.Add(2, "status=" + status.ToString());
            if (!string.IsNullOrEmpty(DTF)) { Parameters.Add(3, "DTF=" + DTF.ToString()); }
            if (!string.IsNullOrEmpty(DTT)) { Parameters.Add(4, "DTT=" + DTT.ToString()); }
            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                GetData data = new GetData();
                string statusId = string.Empty, Qry = string.Empty;
                if (status == 231 || status == 232 || status == 233 || status == 234 || status == 235 || status == 236)
                {
                    if (status == 231) { statusId = " "; }
                    else if (status == 232) { statusId = " and b.documentid=@AadhaarCard"; }
                    else if (status == 233) { statusId = " and b.documentid=@AadhaarCard and b.documentstatusid=58"; }
                    else if (status == 234) { statusId = " and b.documentid=@AadhaarCard and b.documentstatusid=59"; }
                    else if (status == 235) { statusId = " and b.documentid=@AadhaarCard and (b.documentstatusid=61 or b.documentstatusid=87)"; }
                    else if (status == 236) { statusId = " and b.documentid<>@AadhaarCard"; }
                    Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,AD.applicationsubdivcode,SM.SubDivDescription,DM.DistrictCode,DM.DistrictName,c.servicecode,c.servicename,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,SL.StatusName from applicationdetails AD inner join web.registrationmaster b on b.registrationid=AD.registrationid inner join servicemaster c on c.servicecode=AD.servicecode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode where AD.ServiceCode=@ServiceCode and c.deptcode=@ParamDeptCode " + statusId + " order by 2";
                }
                else
                {
                    if (status == 12) { statusId = " and AD.ApplicationStatusId in(12,13,24)"; }
                    else if (status == 14) { statusId = " and AD.ApplicationStatusId in(14,15,18,23)"; }
                    else if (status == 24) { statusId = " and AD.ApplicationStatusId in(12,13)"; }
                    else if (status == 21) { statusId = " and AD.ApplicationStatusId =21"; }
                    else if (status == (int)Status.ISSUCER) { statusId = " and AD.ApplicationStatusId in (16)"; }
                    else if (status == 5555) { statusId = " and AD.ApplicationStatusId in (5)"; }
                    else if (status == 2712) { statusId = " and AD.ApplicationStatusId in (27,12)"; }
                    else if (status == 6666) { statusId = " and AD.ApplicationStatusId in (6)"; }
                    else if (status == 2828) { statusId = " and AD.ApplicationStatusId in (28)"; }
                    else if (status == 2713) { statusId = " and AD.ApplicationStatusId in (27,13)"; }
                    else if (status == 7777) { statusId = " and AD.ApplicationStatusId in (7)"; }
                    else if (status == 2121) { statusId = " and AD.ApplicationStatusId in (21)"; }
                    else if (status == 3333) { statusId = " and AD.ApplicationStatusId in (3,39,40)"; }
                    else if (status == 3434) { statusId = " and AD.ApplicationStatusId in (34)"; }

                    else if (status == 1) { statusId = " and AD.ApplicationStatusId in(25,29,30,31,32,33,34,35)"; }
                    else if (status == 2) { statusId = " and AD.ApplicationStatusId in(21)"; }
                    else if (status == 3) { statusId = " and AD.ApplicationStatusId in(3,39,40)"; }
                    else if (status == 4) { statusId = " and AD.ApplicationStatusId in(5) and VD.ApplicationNo is null"; }
                    else if (status == 10) { statusId = " and AD.ApplicationStatusId in(5) and VD.ApplicationNo is not null"; }
                    else if (status == 5) { statusId = " and AD.ApplicationStatusId in(6,7,36)"; }
                    else if (status == 6) { statusId = " and AD.ApplicationStatusId in(12,13,27)"; }
                    else if (status == 7) { statusId = " and AD.ApplicationStatusId in(16)"; }
                    else if (status == 8) { statusId = " and AD.ApplicationStatusId in(14,18)"; }
                    else if (status == 9) { statusId = " and AD.ApplicationStatusId in(41)"; }
                    else if (status == 11) { statusId = " and AD.ApplicationSourceId =1"; }
                    else if (status == 13) { statusId = " and AD.ApplicationSourceId =2"; }

                    else if (status == 100) { statusId = " "; }
                    else if (status == 101) { statusId = " and AD.ApplicationStatusId =1"; }
                    else if (status == 200) { statusId = " and AD.ApplicationStatusId not in (1,14,16) and (select (to_char(now(),'YYYYMMDD')::date- to_char(AD.applicationdate,'YYYYMMDD')::date)<=(case when AD.applicationdate<'2015-12-01' then SR.oldprocessingdays else SR.processingdays end))"; }
                    else if (status == 300) { statusId = " and AD.ApplicationStatusId not in (1,14,16) and ((select (to_char(now(),'YYYYMMDD')::date- to_char(AD.applicationdate,'YYYYMMDD')::date)) - COALESCE((case when AD.applicationdate>'2015-11-30 23:59:59' then LD.totalverificationdays else 0 end),0)>(case when AD.applicationdate<'2015-12-01' then SR.oldprocessingdays else SR.processingdays end))"; }
                    else if (status == 400) { statusId = " and AD.ApplicationStatusId in (16)"; }
                    else if (status == 500) { statusId = " and AD.ApplicationStatusId in(14)"; }
                    else if (status == 600) { statusId = " and AD.ApplicationStatusId in(12,13)"; }

                    else if (status == 603) { statusId = " and AD.ApplicationStatusId not in(1,6,14,16,35) and ApplicationSourceId=1 and whetherdocumentSeen=false"; }
                    else if (status == 604) { statusId = " and AD.ApplicationStatusId in(21) and AD.ApplicationSourceId =1"; }
                    else if (status == 605) { statusId = " and AD.ApplicationStatusId in(3,39,40) and AD.ApplicationSourceId =1"; }
                    else if (status == 606) { statusId = " and AD.ApplicationStatusId in(5) and VD.ApplicationNo is null and AD.ApplicationSourceId =1"; }
                    else if (status == 607) { statusId = " and AD.ApplicationStatusId in(5) and VD.ApplicationNo is not null and AD.ApplicationSourceId =1"; }
                    else if (status == 608) { statusId = " and AD.ApplicationStatusId in(6,7,36) and AD.ApplicationSourceId =1"; }
                    else if (status == 609) { statusId = " and AD.ApplicationStatusId in(12,13,27) and AD.ApplicationSourceId =1"; }
                    else if (status == 610) { statusId = " and AD.ApplicationStatusId in(16) and AD.ApplicationSourceId =1"; }
                    else if (status == 611) { statusId = " and AD.ApplicationStatusId in(14,18) and AD.ApplicationSourceId =1"; }
                    else if (status == 612) { statusId = " and AD.ApplicationStatusId =1 and AD.ApplicationSourceId =1"; }

                    Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,@RejectionFlag as RejectionFlag,to_char(AD.LastActionDate,'DD/MM/YYYY') as LastActionDate,AD.ServiceCode,AD.applicationsubdivcode,SM.SubDivDescription,DM.DistrictCode,DM.DistrictName,AD.ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,case when AD.rejectionreasoncode=@OtherReason then AD.applicationremarks else RE.reasondetail end as rejectionreason from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode left outer join (select distinct applicationno from (select applicationno from verifierapplicationdetails union select applicationno from applicationverificationletterdetails)a) VD on VD.ApplicationNo=AD.ApplicationNo left outer join applicationverificationletterdetails LD on LD.ApplicationNo=AD.ApplicationNo left outer join reasonmaster RE on RE.reasoncode=AD.rejectionreasoncode where AD.ServiceCode=@ServiceCode and AD.applicationsubdivcode=@SubDivCode " + statusId;
                    if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
                    if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
                    if (status == 8 || status == 14 || status == 500 || status == 611)
                    {
                        Qry += " order by AD.LastActionDate Desc";
                    }
                    else
                    {
                        Qry += " order by AD.ApplicationNo";
                    }
                }

                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ServiceCode", service);
                cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
                cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
                cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
                cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
                cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
                cmd.Parameters.AddWithValue("@OtherReason", (int)RejectionReason.Other);
                cmd.Parameters.AddWithValue("@RejectionFlag", status == 14 || status == 8 || status == 500 || status == 611 ? 1 : 0);
                if (status == 231 || status == 232 || status == 233 || status == 234 || status == 235 || status == 236) { cmd.Parameters.AddWithValue("@AadhaarCard", (int)DocumentId.AadhaarCard); }
                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "BasicApplicationDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "BasicApplicationDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult BasicApplicationPreview(Int64? app, int? Const,int? flag)
        {
            if (app == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.readOnly = Const.ToString();
            model.Flag = flag.ToString();

            model.ApplicantDetails = Utility.GetApplicantDetails(app.ToString(), DB.LS.ToString());
            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", string.Empty, string.Empty, model.ApplicantDetails.ApplicationNo, DB.LS.ToString(), CustomText.N.ToString());
            ViewData["dtPhotoData"] = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", string.Empty, string.Empty, model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            ViewData["dtObjectionData"] = Utility.GetObjectionDetails(model.ApplicantDetails.ApplicationNo.ToString());
            model.VerifierVerificationDetails = Utility.GetVerifierVerificationDetails(model.ApplicantDetails.ApplicationNo);
            model.VerifierWitnessMaster = Utility.GetVerifierWitnessMasterDetails(model.ApplicantDetails.ApplicationNo);
            ViewData["dtVerServiceSpecific"] = Utility.GetServiceSpecificVerificationDetails(model.ApplicantDetails.ApplicationNo);
            ViewData["dtApplicationTrail"] = Utility.GetApplicationAuditTrail(model.ApplicantDetails.ApplicationNo);
            model.dataS = Utility.GetPaymentDetails(model.ApplicantDetails.ApplicationNo);
            model.dataa = Utility.GetRectifyDocumentDetails(model.ApplicantDetails.ApplicationNo);

            model.ApplicationDetails = new ApplicationDetails();
            string Qry = "select ServiceCode,ApplicationStatusId from ApplicationDetails where ApplicationNo=@ApplicationNo";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
            string[] GetValues = data.SelectColumns(Cmd);
            model.ApplicationDetails.ServiceCode = GetValues[0];
            model.ApplicationDetails.StatusId = GetValues[1];

            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Domicile)
            {
                model.ApplicationDetailsDomicile = Utility.GetDomicileDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Birth)
            {
                model.ApplicationDetailsBirth = Utility.GetBirthDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Death)
            {
                model.ApplicationDetailsDeath = Utility.GetDeathDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Disability)
            {
                model.ApplicationDetailsDisability = Utility.GetDisabilityDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Handicapped)
            {
                model.ApplicationHandicappedDetails = Utility.GetHandicappedDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.OldAge)
            {
                model.ApplicationOldAgeDetails = Utility.GetOldAgeDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Widow)
            {
                model.ApplicationWidowDetails = Utility.GetWidowDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Marriage)
            {
                model.ApplicationMarriageDetails = Utility.GetMarriageDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
                model.MarriageWitnessDetails = Utility.GetMarriageWitnessDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Solemnization)
            {
                model.ApplicationMarriageDetails = Utility.GetMarriageSolemnizationDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Nationality)
            {
                model.ApplicationDetailsNationality = Utility.GetNationalityDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
            }

            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Solvency)
            {
                model.ApplicationDetailsSolvency = Utility.GetSolvencyDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.SCST)
            {
                model.ApplicationDetailsSCST = Utility.GetSCSTDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
                model.ApplicationLetterDetailsModel = Utility.GetApplicationLetterDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.ST)
            {
                model.ApplicationDetailsST = Utility.GetSTDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
                model.ApplicationLetterDetailsModel = Utility.GetApplicationLetterDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.OBC)
            {
                bool WhetherOld = false;
                string ApplicationDate = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ApplicationDate", "ApplicationNo", model.ApplicantDetails.ApplicationNo)[0];
                if (Convert.ToDateTime(ApplicationDate) < Convert.ToDateTime(Constant._OBCDate)) { WhetherOld = true; }
                model.ApplicationDetailsOBC = Utility.GetOBCDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
                model.ApplicationDetailsOBC.WhetherOld = WhetherOld;
                model.ApplicationDetailsOBC.OBCIncomeDetails = Utility.GetOBCIncomeDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.ApplicationLetterDetailsModel = Utility.GetApplicationLetterDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Income)
            {
                model.ApplicationDetailsIncome = Utility.GetIncomeDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Surviving)
            {
                model.ApplicationDetailsSurviving = Utility.GetSurvivingDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.LalDora)
            {
                model.ApplicationDetailsLalDora = Utility.GetLalDoraDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                model.LalDoraWitnessDetails = Utility.GetWitnessDetailsLalDora(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.CDVolunteer)
            {
                model.ApplicationDetailsCDV = Utility.GetCDVDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
                model.ApplicationDetailsCDV.dataseta = Utility.GetAwardData(model.ApplicantDetails.ApplicationNo.ToString());
                model.ApplicationDetailsCDV.datasetb = Utility.GetTrainingData(model.ApplicantDetails.ApplicationNo.ToString());
                model.ApplicationDetailsCDV.datasetc = Utility.GetDutyData(model.ApplicantDetails.ApplicationNo.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.ProvisionalCinema)
            {
                model.ApplicationDetailsCinematograph = Utility.GetProvisionalCinemaDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.FreshCinemaLicense)
            {
                model.ApplicationDetailsCinematograph = Utility.GetProvisionalCinemaDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.RenewalCinemaLicense)
            {
                model.ApplicationDetailsCinematograph = Utility.GetProvisionalCinemaDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Ladli)
            {
                model.ApplicationDetailsLadli = Utility.GetLadliDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.DFBScheme)
            {
                model.ApplicationDetailsDFBScheme = Utility.GetDFBSchemeDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.HigherEducationSKGS)
            {
                model.HeSkillDevelopmentScheme = Utility.GetHeSkillDevelopmentSchemeDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Migration)
            {
                model.ApplicationDetailsMigration = Utility.GetMigrationDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.FirmRegistration)
            {
                model.ApplicationDetailsFirm = Utility.GetApplicationDetailsFirm(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.NOC)
            {
                model.ApplicationDetailsNOC = Utility.GetNOCDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Recovery)
            {
                model.ApplicationDetailsRecovery = Utility.GetRecoveryDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PrematricScholarshipSC)
            {
                model.ApplicationDetailsPrematsSC = Utility.GetPrematsSCDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.DrbrAmbedkarToppers)
            {
                model.ApplicationDetailsDrbrAmbedkarToppers = Utility.GetDrbrAmbedkarToppersDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MeritscholarshipSchool)
            {
                model.ApplicationDetailsMeritscholarshipSchool = Utility.GetMeritscholarshipSchoolDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MeritscholarshipProfessional)
            {
                model.ApplicationDetailsMeritProfessional = Utility.GetMeritscholarshipProfessionalDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PostmatricScholarshipOBC)
            {
                model.ApplicationDetailsPostmatOBC = Utility.GetPostmatOBCDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PrematricScholarshipOBC)
            {
                model.ApplicationDetailsPrematOBC = Utility.GetPrematsOBCDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PrematricSC)
            {
                model.ApplicationDetailsPrematSCssd = Utility.GetPrematSCSSDDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PostmatricSC)
            {
                model.ApplicationDetailsPostmatSCssd = Utility.GetPostmatSCSSDDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.FinancialAssistanceStationery)
            {
                model.ApplicationDetailsFinancialAssistance = Utility.GetFinancialAssistanceDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.BOCW)
            {
                model.ApplicationDetailsBOCWAct = Utility.GetBOCWActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.ContractLabour)
            {
                model.ApplicationDetailsCLAct = Utility.GetCLActDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Contractors)
            {
                model.ApplicationDetailsContractor = Utility.GetContractorDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.InstallationOfLift)
            {
                model.ApplicationDetailsInstallationOfLift = Utility.GetInstallationOfLiftDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.GrantOfPassengerLift)
            {
                model.ApplicationDetailsGrantOfPassengerLift = Utility.GetGrantOfPassengerLiftDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.LbrRecovery)
            {
                model.ApplicationDetailsLBRRecovery = Utility.GetLBRRecoveryDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.HeFinancialAssistance)
            {
                model.HeMCMFinancialAssistance = Utility.GetHeMCMFinancialAssistanceDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.RenewalOfPassengerLift)
            {
                model.ApplicationDetailsRenewalOfPassengerLift = Utility.GetRenewalOfPassengerLiftDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.ECLicence)
            {
                model.ApplicationDetailsEC = Utility.GetApplicationDetailsEC(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.CompCertificate)
            {
                model.ApplicationDetailsCompCertificate = Utility.GetApplicationDetailsCompCertificate(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.NFSNewRc)
            {
                model.NfsApplicationDetails = Utility.GetNfsNewRc(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.NFSSurrenderRc)
            {
                model.NfsApplicationDetails = Utility.GetNfsSurrenderRc(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.NFSDetailsUpdate)
            {
                model.NfsApplicationDetails = Utility.GetNfsUpdateBsicDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.NFSFpsChange)
            {
                model.NfsApplicationDetails = Utility.GetNfsFpsChangeDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.NFSHofChange)
            {
                model.NfsApplicationDetails = Utility.GetNfsHOFChangeDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.NFSMemberChange || Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.NFSMemberAddition || Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.NFSMemberDeletion)
            {
                model.NfsApplicationDetails = Utility.GetNfsMemberChangeDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.TirthYatraYojna)
            {
                model.ApplicationDetailsTirthYatraYojana = Utility.GetTirthYatraYojnaDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
            }
            else {
                ViewData["message"] = "You are not authorized to view this application details. Kindly contact to Administrator.";
                return View("message");
            }

            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult BasicDistWiseReport(string DTF, string DTT)
        {
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { return RedirectToAction("BasicSubDivWiseReport"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.DistrictCode, rs.DistrictName,rs.Received,rs.Disposed,rs.PenDisposed,rs.underobjection,rs.rejected,rs.canceled,rs.Pendingintime,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end,2) as perPending,round(case when rs.PenDisposed=0 then 0 else (rs.PenDisposed::decimal*100/rs.Disposed::decimal) end,2) as PerDIsposed,rs.OtherStateVer from (select DM.DistrictCode, DM.DistrictName,coalesce(count(AD.ApplicationNo),0) Received,coalesce(sum(case when AD.ApplicationStatusId=@ISSUCER then 1 end),0) as Disposed,coalesce(sum(case when AD.ApplicationStatusId=@ISSUCER  and (select DATE_PART('day',AD.signeddate-AD.applicationdate)<=(case when AD.applicationdate<'2015-12-01' then SM.oldprocessingdays else SM.processingdays end))then 1 end),0) as PenDisposed,coalesce(sum(case when AD.ApplicationStatusId in(@TEHSOBJ) then 1 end),0) as underobjection,coalesce(sum(case when AD.ApplicationStatusId in(@TEHSREJ) then 1 end),0) as rejected,coalesce(sum(case when AD.ApplicationStatusId=@CANCEL then 1 end),0) as canceled,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid in (@GreenZone,@YellowZone,@RedZone) then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=@SlaZone then 1 end),0) as Pendingbeyondtime,coalesce(sum(case when AD.ApplicationStatusId in(@VERLOTHS)  and AD.valueid=@SlaZone then 1 end),0) as OtherStateVer from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode where DM.deptcode=@ParamDeptCode ";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by AD.districtcode,DM.DistrictCode,DM.DistrictName order by DM.DistrictName) rs";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@WEBJST", (int)Status.WEBJST);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@GreenZone", (int)ValueId.GreenZone);
            cmd.Parameters.AddWithValue("@YellowZone", (int)ValueId.YellowZone);
            cmd.Parameters.AddWithValue("@RedZone", (int)ValueId.RedZone);
            cmd.Parameters.AddWithValue("@SlaZone", (int)ValueId.SlaZone);
            cmd.Parameters.AddWithValue("@VERLOTHS", (int)Status.VERLOTHS);

            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult BasicDistWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("BasicDistWiseReport", "Report", new { q = QueryString });
            }
            return View("BasicDistWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult BasicSubDivWiseReport(int? dist, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            if (dist.Equals(null)) { dist = Convert.ToInt32(Sessions.getEmployeeUser().DistrictCode); }
            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
            model.ApplicationSubDivCode = Sessions.getEmployeeUser().SubDivCode;

            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.SubdivCode,rs.SubDivDescription,rs.DistrictCode, rs.DistrictName,rs.Received,rs.Disposed,rs.PenDisposed,rs.underobjection,rs.rejected,rs.canceled,rs.Pendingintime,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end,2) as perPending,round(case when rs.PenDisposed=0 then 0 else (rs.PenDisposed::decimal*100/rs.Disposed::decimal) end,2) as PerDIsposed,rs.OtherStateVer from (select SM.SubdivCode,SM.SubDivDescription, DM.DistrictCode, DM.DistrictName,coalesce(count(ApplicationNo),0) Received,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Disposed,coalesce(sum(case when AD.ApplicationStatusId=@ISSUCER  and (select DATE_PART('day',AD.signeddate-AD.applicationdate)<=(case when AD.applicationdate<'2015-12-01' then SR.oldprocessingdays else SR.processingdays end))then 1 end),0) as PenDisposed,coalesce(sum(case when ApplicationStatusId in(@TEHSOBJ) then 1 end),0) as underobjection,coalesce(sum(case when ApplicationStatusId in(@TEHSREJ) then 1 end),0) as rejected,coalesce(sum(case when ApplicationStatusId=@CANCEL then 1 end),0) as canceled,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid in (@GreenZone,@YellowZone,@RedZone) then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=@SlaZone then 1 end),0) as Pendingbeyondtime,coalesce(sum(case when AD.ApplicationStatusId in(@VERLOTHS)  and AD.valueid=@SlaZone then 1 end),0) as OtherStateVer from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SR on AD.servicecode=SR.servicecode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode  where SM.DistrictCode=@DistrictCode";
            //string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.SubdivCode,rs.SubDivDescription,rs.DistrictCode, rs.DistrictName,rs.Received,rs.Disposed,rs.PenDisposed,rs.underobjection,rs.rejected,rs.canceled,rs.Pendingintime,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end,2) as perPending,round(case when rs.PenDisposed=0 then 0 else (rs.PenDisposed::decimal*100/rs.Disposed::decimal) end,2) as PerDIsposed from (select SM.SubdivCode,SM.SubDivDescription, DM.DistrictCode, DM.DistrictName,coalesce(count(ApplicationNo),0) Received,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Disposed,coalesce(sum(case when ApplicationStatusId=@ISSUCER  and (select (to_char(now(),'YYYYMMDD')::date- to_char(AD.applicationdate,'YYYYMMDD')::date)<=(case when AD.applicationdate<'2015-12-01' then SR.oldprocessingdays else SR.processingdays end))then 1 end),0) as PenDisposed,coalesce(sum(case when ApplicationStatusId in(@TEHSOBJ) then 1 end),0) as underobjection,coalesce(sum(case when ApplicationStatusId in(@TEHSREJ) then 1 end),0) as rejected,coalesce(sum(case when ApplicationStatusId=@CANCEL then 1 end),0) as canceled,coalesce(sum(case when AD.ApplicationStatusId not in (@ISSUCER,@TEHSOBJ,@TEHSREJ,@WEBJST) and (select (to_char(now(),'YYYYMMDD')::date- to_char(AD.applicationdate,'YYYYMMDD')::date)<=(case when AD.applicationdate<'2015-12-01' then SR.oldprocessingdays else SR.processingdays end))then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in (@ISSUCER,@TEHSOBJ,@TEHSREJ,@WEBJST) and (select (to_char(now(),'YYYYMMDD')::date- to_char(AD.applicationdate,'YYYYMMDD')::date)>(case when AD.applicationdate<'2015-12-01' then SR.oldprocessingdays else SR.processingdays end))then 1 end),0) as Pendingbeyondtime from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SR on AD.servicecode=SR.servicecode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode  where SM.DistrictCode=@DistrictCode";
            if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry += " and SM.SubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by SM.subdivcode,DM.DistrictCode,DM.DistrictName,SM.SubDivDescription,SM.DistrictCode order by SM.SubDivDescription) rs";
            //Qry += " group by SM.subdivcode,DM.DistrictCode,DM.DistrictName,SM.SubDivDescription,SM.DistrictCode order by SM.SubDivDescription) rs";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@WEBJST", (int)Status.WEBJST);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@GreenZone", (int)ValueId.GreenZone);
            cmd.Parameters.AddWithValue("@YellowZone", (int)ValueId.YellowZone);
            cmd.Parameters.AddWithValue("@RedZone", (int)ValueId.RedZone);
            cmd.Parameters.AddWithValue("@SlaZone", (int)ValueId.SlaZone);
            cmd.Parameters.AddWithValue("@VERLOTHS", (int)Status.VERLOTHS);
            cmd.Parameters.AddWithValue("@DistrictCode", dist);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult BasicSubDivWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("BasicSubDivWiseReport", "Report", new { q = QueryString });
            }
            return View("BasicDistWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult BasicServiceWiseReport(int subDiv, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.ServiceName,rs.ServiceCode,rs.subdivcode,rs.SubDivDescription,rs.DistrictCode, rs.DistrictName,rs.Received,rs.Disposed,rs.PenDisposed,rs.underobjection,rs.rejected,rs.canceled,rs.Pendingintime,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end,2) as perPending,round(case when rs.PenDisposed=0 then 0 else (rs.PenDisposed::decimal*100/rs.Disposed::decimal) end,2) as PerDIsposed,rs.OtherStateVer from (select SR.ServiceName,SR.ServiceCode,SM.SubdivCode,SM.SubDivDescription,DM.DistrictCode, DM.DistrictName,coalesce(count(ApplicationNo),0) Received,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Disposed,coalesce(sum(case when ApplicationStatusId=@ISSUCER  and (select DATE_PART('day',AD.signeddate-AD.applicationdate)<=(case when AD.applicationdate<'2015-12-01' then SR.oldprocessingdays else SR.processingdays end))then 1 end),0) as PenDisposed,coalesce(sum(case when ApplicationStatusId in(@TEHSOBJ) then 1 end),0) as underobjection,coalesce(sum(case when ApplicationStatusId in(@TEHSREJ) then 1 end),0) as rejected,coalesce(sum(case when ApplicationStatusId=@CANCEL then 1 end),0) as canceled,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid in (@GreenZone,@YellowZone,@RedZone) then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=@SlaZone then 1 end),0) as Pendingbeyondtime, coalesce(sum(case when AD.ApplicationStatusId in(@VERLOTHS)  and AD.valueid=@SlaZone then 1 end),0) as OtherStateVer from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SR on AD.servicecode=SR.servicecode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode where AD.subdivcode=@SubDivCode  ";
            //string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.ServiceName,rs.ServiceCode,rs.subdivcode,rs.SubDivDescription,rs.DistrictCode, rs.DistrictName,rs.Received,rs.Disposed,rs.PenDisposed,rs.underobjection,rs.rejected,rs.canceled,rs.Pendingintime,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end,2) as perPending,round(case when rs.PenDisposed=0 then 0 else (rs.PenDisposed::decimal*100/rs.Disposed::decimal) end,2) as PerDIsposed from (select SR.ServiceName,SR.ServiceCode,SM.SubdivCode,SM.SubDivDescription,DM.DistrictCode, DM.DistrictName,coalesce(count(ApplicationNo),0) Received,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Disposed,coalesce(sum(case when ApplicationStatusId=@ISSUCER  and (select DATE_PART('day',AD.signeddate-AD.applicationdate)<=(case when AD.applicationdate<'2015-12-01' then SR.oldprocessingdays else SR.processingdays end))then 1 end),0) as PenDisposed,coalesce(sum(case when ApplicationStatusId in(@TEHSOBJ) then 1 end),0) as underobjection,coalesce(sum(case when ApplicationStatusId in(@TEHSREJ) then 1 end),0) as rejected,coalesce(sum(case when ApplicationStatusId=@CANCEL then 1 end),0) as canceled,coalesce(sum(case when AD.ApplicationStatusId not in (@ISSUCER,@TEHSOBJ,@TEHSREJ,@WEBJST) and (select (to_char(now(),'YYYYMMDD')::date- to_char(AD.applicationdate,'YYYYMMDD')::date)<=(case when AD.applicationdate<'2015-12-01' then SR.oldprocessingdays else SR.processingdays end))then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in (@ISSUCER,@TEHSOBJ,@TEHSREJ,@WEBJST) and (select (to_char(now(),'YYYYMMDD')::date- to_char(AD.applicationdate,'YYYYMMDD')::date)>(case when AD.applicationdate<'2015-12-01' then SR.oldprocessingdays else SR.processingdays end))then 1 end),0) as Pendingbeyondtime from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SR on AD.servicecode=SR.servicecode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode where AD.subdivcode=@SubDivCode";
            if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by DM.DistrictName,DM.DistrictCode,SM.subdivcode,SM.SubDivDescription,SR.ServiceName,SR.ServiceCode order by SR.ServiceName) rs";
            //Qry += " group by DM.DistrictName,DM.DistrictCode,SM.subdivcode,SM.SubDivDescription,SR.ServiceName,SR.ServiceCode order by SR.ServiceName) rs";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@WEBJST", (int)Status.WEBJST);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@GreenZone", (int)ValueId.GreenZone);
            cmd.Parameters.AddWithValue("@YellowZone", (int)ValueId.YellowZone);
            cmd.Parameters.AddWithValue("@RedZone", (int)ValueId.RedZone);
            cmd.Parameters.AddWithValue("@SlaZone", (int)ValueId.SlaZone);
            cmd.Parameters.AddWithValue("@VERLOTHS", (int)Status.VERLOTHS);
            cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }

        [EncryptedActionParameter]
        public ActionResult BasicAllSubDivWiseReport(string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.SubdivCode,rs.SubDivDescription,rs.DistrictCode, rs.DistrictName,rs.stateid,rs.Received,rs.Disposed,rs.PenDisposed,rs.underobjection,rs.rejected,rs.canceled,rs.Pendingintime,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end,2) as perPending,round(case when rs.PenDisposed=0 then 0 else (rs.PenDisposed::decimal*100/rs.Disposed::decimal) end,2) as PerDIsposed,rs.OtherStateVer from (select SM.SubDivDescription,SM.DistrictCode,DM.DistrictName,DM.stateid,AD.subdivcode,coalesce(count(ApplicationNo),0) Received,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Disposed,coalesce(sum(case when ApplicationStatusId=@ISSUCER  and (select DATE_PART('day',AD.signeddate- AD.applicationdate)<=(case when AD.applicationdate<'2015-12-01' then SR.oldprocessingdays else SR.processingdays end))then 1 end),0) as PenDisposed,coalesce(sum(case when ApplicationStatusId in(@TEHSOBJ) then 1 end),0) as underobjection,coalesce(sum(case when ApplicationStatusId in(@TEHSREJ) then 1 end),0) as rejected,coalesce(sum(case when ApplicationStatusId=@CANCEL then 1 end),0) as canceled,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid in (@GreenZone,@YellowZone,@RedZone) then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=@SlaZone then 1 end),0) as Pendingbeyondtime,coalesce(sum(case when AD.ApplicationStatusId in(@VERLOTHS)  and AD.valueid=@SlaZone then 1 end),0) as OtherStateVer from dstc.scheduledstaticdata  AD inner join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SR on AD.servicecode=SR.servicecode inner join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode where DM.deptcode=@ParamDeptCode ";
            //string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.SubdivCode,rs.SubDivDescription,rs.DistrictCode, rs.DistrictName,rs.stateid,rs.Received,rs.Disposed,rs.PenDisposed,rs.underobjection,rs.rejected,rs.canceled,rs.Pendingintime,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end,2) as perPending,round(case when rs.PenDisposed=0 then 0 else (rs.PenDisposed::decimal*100/rs.Disposed::decimal) end,2) as PerDIsposed from (select SM.SubDivDescription,SM.DistrictCode,DM.DistrictName,DM.stateid,AD.subdivcode,coalesce(count(ApplicationNo),0) Received,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Disposed,coalesce(sum(case when ApplicationStatusId=@ISSUCER  and (select DATE_PART('day',AD.signeddate- AD.applicationdate)<=(case when AD.applicationdate<'2015-12-01' then SR.oldprocessingdays else SR.processingdays end))then 1 end),0) as PenDisposed,coalesce(sum(case when ApplicationStatusId in(@TEHSOBJ) then 1 end),0) as underobjection,coalesce(sum(case when ApplicationStatusId in(@TEHSREJ) then 1 end),0) as rejected,coalesce(sum(case when ApplicationStatusId=@CANCEL then 1 end),0) as canceled,coalesce(sum(case when AD.ApplicationStatusId not in (@ISSUCER,@TEHSOBJ,@TEHSREJ,@WEBJST) and (select (to_char(now(),'YYYYMMDD')::date- to_char(AD.applicationdate,'YYYYMMDD')::date)<=(case when AD.applicationdate<'2015-12-01' then SR.oldprocessingdays else SR.processingdays end))then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in (@ISSUCER,@TEHSOBJ,@TEHSREJ,@WEBJST) and (select (to_char(now(),'YYYYMMDD')::date- to_char(AD.applicationdate,'YYYYMMDD')::date)>(case when AD.applicationdate<'2015-12-01' then SR.oldprocessingdays else SR.processingdays end))then 1 end),0) as Pendingbeyondtime from dstc.scheduledstaticdata  AD inner join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SR on AD.servicecode=SR.servicecode inner join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode where DM.deptcode=@ParamDeptCode";
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += "  group by AD.subdivcode,DM.DistrictName,DM.stateid,SM.SubDivDescription,SM.DistrictCode order by SM.SubDivDescription) rs where rs.stateid=@stateid order by perPending ";
            //Qry += " group by AD.subdivcode,DM.DistrictName,DM.stateid,SM.SubDivDescription,SM.DistrictCode order by SM.SubDivDescription) rs where rs.stateid=@stateid order by perPending";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@WEBJST", (int)Status.WEBJST);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@GreenZone", (int)ValueId.GreenZone);
            cmd.Parameters.AddWithValue("@YellowZone", (int)ValueId.YellowZone);
            cmd.Parameters.AddWithValue("@RedZone", (int)ValueId.RedZone);
            cmd.Parameters.AddWithValue("@SlaZone", (int)ValueId.SlaZone);
            cmd.Parameters.AddWithValue("@VERLOTHS", (int)Status.VERLOTHS);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult BasicAllSubDivWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("BasicAllSubDivWiseReport", "Report", new { q = QueryString });
            }
            return View("BasicAllSubDivWiseReport", model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DivcomServiceWiseReport(string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = " select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.ServiceName,rs.ServiceCode,rs.Received,rs.ReceivedOnline,rs.ReceivedOffline,rs.Disposed,rs.PenDisposed,rs.underobjection,rs.rejected,rs.canceled,rs.Pendingintime,rs.Pendingbeyondtime,round(case when Pendingbeyondtime=0 then 0 else (rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal)) end,2) as perPending,round(case when rs.PenDisposed=0 then 0 else (rs.PenDisposed::decimal*100/rs.Disposed::decimal) end,2) as PerDIsposed,rs.OtherStateVer from (select  SC.ServiceName,SC.ServiceCode,coalesce(count(ApplicationNo),0) Received,coalesce(sum(case when ApplicationSourceId in(@Online) then 1 end),0) ReceivedOnline,coalesce(sum(case when ApplicationSourceId in(@Window) then 1 end),0) ReceivedOffline,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Disposed,coalesce(sum(case when ApplicationStatusId=@ISSUCER  and (select DATE_PART('day',AD.signeddate- AD.applicationdate)<=(case when AD.applicationdate<'2015-12-01' then SC.oldprocessingdays else SC.processingdays end))then 1 end),0) as PenDisposed,coalesce(sum(case when ApplicationStatusId in(@TEHSOBJ) then 1 end),0) as underobjection,coalesce(sum(case when ApplicationStatusId in(@TEHSREJ) then 1 end),0) as rejected,coalesce(sum(case when ApplicationStatusId=@CANCEL then 1 end),0) as canceled,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid in (@GreenZone,@YellowZone,@RedZone) then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=@SlaZone then 1 end),0) as Pendingbeyondtime,coalesce(sum(case when AD.ApplicationStatusId in(@VERLOTHS) and AD.valueid=@SlaZone then 1 end),0) as OtherStateVer from dstc.scheduledstaticdata AD inner join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode ";
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by SC.ServiceName,SC.ServiceCode order by SC.ServiceName) rs";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@WEBJST", (int)Status.WEBJST);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@GreenZone", (int)ValueId.GreenZone);
            cmd.Parameters.AddWithValue("@YellowZone", (int)ValueId.YellowZone);
            cmd.Parameters.AddWithValue("@RedZone", (int)ValueId.RedZone);
            cmd.Parameters.AddWithValue("@SlaZone", (int)ValueId.SlaZone);
            cmd.Parameters.AddWithValue("@VERLOTHS", (int)Status.VERLOTHS);
            cmd.Parameters.AddWithValue("@Online", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@Window", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [ValidateOnlyIncomingValues]
        public ActionResult DivcomServiceWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("DivcomServiceWiseReport", "Report", new { q = QueryString });
            }
            return View("DivcomServiceWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult DivcomDistWiseReport(int? service, string DTF, string DTT)
        {
            if (service == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.DistrictName,rs.DistrictCode,rs.ServiceCode,rs.ServiceName,rs.Received,rs.ReceivedOnline,rs.ReceivedOffline,rs.Disposed,rs.PenDisposed,rs.underobjection,rs.rejected,rs.canceled,rs.Pendingintime,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end ,2) as perPending,round(case when rs.PenDisposed=0 then 0 else (rs.PenDisposed::decimal*100/rs.Disposed::decimal) end,2) as PerDIsposed,rs.OtherStateVer from (select DM.DistrictCode,DM.DistrictName, SC.ServiceName,SC.ServiceCode,coalesce(count(ApplicationNo),0) Received,coalesce(sum(case when ApplicationSourceId in(@Online) then 1 end),0) ReceivedOnline,coalesce(sum(case when ApplicationSourceId in(@Window) then 1 end),0) ReceivedOffline,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Disposed,coalesce(sum(case when ApplicationStatusId=@ISSUCER  and (select DATE_PART('day',AD.signeddate- AD.applicationdate)<=(case when AD.applicationdate<'2015-12-01' then SC.oldprocessingdays else SC.processingdays end))then 1 end),0) as PenDisposed,coalesce(sum(case when ApplicationStatusId in(@TEHSOBJ) then 1 end),0) as underobjection,coalesce(sum(case when ApplicationStatusId in(@TEHSREJ) then 1 end),0) as rejected,coalesce(sum(case when ApplicationStatusId=@CANCEL then 1 end),0) as canceled,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid in (@GreenZone,@YellowZone,@RedZone) then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=@SlaZone then 1 end),0) as Pendingbeyondtime,coalesce(sum(case when AD.ApplicationStatusId in(@VERLOTHS)  and AD.valueid=@SlaZone then 1 end),0) as OtherStateVer from dstc.scheduledstaticdata AD left outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where AD.ServiceCode=@ServiceCode";
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += "  group by DM.DistrictName,SC.ServiceCode,SC.ServiceName,DM.DistrictCode order by DM.DistrictName) rs";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@WEBJST", (int)Status.WEBJST);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@GreenZone", (int)ValueId.GreenZone);
            cmd.Parameters.AddWithValue("@YellowZone", (int)ValueId.YellowZone);
            cmd.Parameters.AddWithValue("@RedZone", (int)ValueId.RedZone);
            cmd.Parameters.AddWithValue("@SlaZone", (int)ValueId.SlaZone);
            cmd.Parameters.AddWithValue("@VERLOTHS", (int)Status.VERLOTHS);
            cmd.Parameters.AddWithValue("@Online", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@Window", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult DivcomSubDivWiseReport(int? service, int? dist, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.SubDivDescription,rs.subdivcode,rs.ServiceCode,rs.ServiceName,rs.DistrictCode,rs.DistrictName,rs.Received,rs.ReceivedOnline,rs.ReceivedOffline,rs.Disposed,rs.PenDisposed,rs.underobjection,rs.rejected,rs.canceled,rs.Pendingintime,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end,2) as perPending,round(case when rs.PenDisposed=0 then 0 else (rs.PenDisposed::decimal*100/rs.Disposed::decimal) end,2) as PerDIsposed,rs.OtherStateVer from (select SM.SubDivDescription,AD.subdivcode,SC.ServiceCode,SC.ServiceName,DM.DistrictCode,DM.DistrictName,coalesce(count(ApplicationNo),0) Received,coalesce(sum(case when ApplicationSourceId in(@Online) then 1 end),0) ReceivedOnline,coalesce(sum(case when ApplicationSourceId in(@Window) then 1 end),0) ReceivedOffline,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Disposed,coalesce(sum(case when AD.ApplicationStatusId=@ISSUCER  and (select DATE_PART('day',AD.signeddate-AD.applicationdate)<=(case when AD.applicationdate<'2015-12-01' then SC.oldprocessingdays else SC.processingdays end))then 1 end),0) as PenDisposed,coalesce(sum(case when ApplicationStatusId in(@TEHSOBJ) then 1 end),0) as underobjection,coalesce(sum(case when ApplicationStatusId in(@TEHSREJ) then 1 end),0) as rejected,coalesce(sum(case when ApplicationStatusId=@CANCEL then 1 end),0) as canceled,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid in (@GreenZone,@YellowZone,@RedZone) then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=@SlaZone then 1 end),0) as Pendingbeyondtime,coalesce(sum(case when AD.ApplicationStatusId in(@VERLOTHS)  and AD.valueid=@SlaZone then 1 end),0) as OtherStateVer from dstc.scheduledstaticdata AD left outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode  right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where AD.districtcode=@applicationdistrictcode and AD.ServiceCode=@ServiceCode";
            //string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.SubDivDescription,rs.subdivcode,rs.ServiceCode,rs.ServiceName,rs.DistrictCode,rs.DistrictName,rs.Received,rs.Disposed,rs.PenDisposed,rs.underobjection,rs.rejected,rs.canceled,rs.Pendingintime,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end,2) as perPending,round(case when rs.PenDisposed=0 then 0 else (rs.PenDisposed::decimal*100/rs.Disposed::decimal) end,2) as PerDIsposed from (select SM.SubDivDescription,AD.subdivcode,SC.ServiceCode,SC.ServiceName,DM.DistrictCode,DM.DistrictName,coalesce(count(ApplicationNo),0) Received,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Disposed,coalesce(sum(case when ApplicationStatusId=@ISSUCER  and (select DATE_PART('day',now()- AD.applicationdate)<=(case when AD.applicationdate<'2015-12-01' then SC.oldprocessingdays else SC.processingdays end))then 1 end),0) as PenDisposed,coalesce(sum(case when ApplicationStatusId in(@TEHSOBJ) then 1 end),0) as underobjection,coalesce(sum(case when ApplicationStatusId in(@TEHSREJ) then 1 end),0) as rejected,coalesce(sum(case when ApplicationStatusId=@CANCEL then 1 end),0) as canceled,coalesce(sum(case when AD.ApplicationStatusId not in (@ISSUCER,@TEHSOBJ,@TEHSREJ,@WEBJST) and (select (to_char(now(),'YYYYMMDD')::date- to_char(AD.applicationdate,'YYYYMMDD')::date)<=(case when AD.applicationdate<'2015-12-01' then SC.oldprocessingdays else SC.processingdays end))then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in (@ISSUCER,@TEHSOBJ,@TEHSREJ,@WEBJST) and (select (to_char(now(),'YYYYMMDD')::date- to_char(AD.applicationdate,'YYYYMMDD')::date)>(case when AD.applicationdate<'2015-12-01' then SC.oldprocessingdays else SC.processingdays end))then 1 end),0) as Pendingbeyondtime from dstc.scheduledstaticdata AD left outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode  right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where AD.districtcode=@applicationdistrictcode and AD.ServiceCode=@ServiceCode";
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by SM.SubDivDescription,AD.subdivcode,DM.DistrictCode,DM.DistrictName,SC.ServiceCode,SC.ServiceName order by SM.SubDivDescription) rs";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@WEBJST", (int)Status.WEBJST);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@GreenZone", (int)ValueId.GreenZone);
            cmd.Parameters.AddWithValue("@YellowZone", (int)ValueId.YellowZone);
            cmd.Parameters.AddWithValue("@RedZone", (int)ValueId.RedZone);
            cmd.Parameters.AddWithValue("@SlaZone", (int)ValueId.SlaZone);
            cmd.Parameters.AddWithValue("@VERLOTHS", (int)Status.VERLOTHS);
            cmd.Parameters.AddWithValue("@Online", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@Window", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@applicationdistrictcode", dist);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }

        [EncryptedActionParameter]
        public ActionResult ServiceWiseEscalationReport(string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string SubDivQry = string.Empty, ServiceQry = string.Empty, DistrictQry = string.Empty, DateQry = string.Empty;
            if (Convert.ToInt32(Sessions.getEmployeeUser().Permission).Equals((int)Permission.DC) || Convert.ToInt32(Sessions.getEmployeeUser().Permission).Equals((int)Permission.DCOM) || Convert.ToInt32(Sessions.getEmployeeUser().Permission).Equals((int)Permission.ADMN) || Convert.ToInt32(Sessions.getEmployeeUser().Permission).Equals((int)Permission.MONT)) { SubDivQry = " "; ServiceQry = " and AD.ServiceCode=SM.ServiceCode "; }
            else { SubDivQry = " and AD.SubDivCode in (@ParamSubDivCode) "; ServiceQry = " and AD.ServiceCode in (@ParamServiceCode) "; }
            if (Convert.ToInt32(Sessions.getEmployeeUser().Permission) != (int)Permission.DCOM && Convert.ToInt32(Sessions.getEmployeeUser().Permission) != (int)Permission.ADMN && Convert.ToInt32(Sessions.getEmployeeUser().Permission) != (int)Permission.MONT) { DistrictQry = " and AD.DistrictCode=@DistrictCode "; } else { DistrictQry = " "; }
            if (!string.IsNullOrEmpty(DTF)) { DateQry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate "; }
            if (!string.IsNullOrEmpty(DTT)) { DateQry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate "; }
            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,sm.servicecode,sm.servicename,
            coalesce(sum(case when displayid=11 then 1 end),0) as cscatteh,
            coalesce(sum(case when displayid=12 then 1 end),0) as daatteh,
            coalesce(sum(case when displayid=13 then 1 end),0) as veratteh,
            coalesce(sum(case when displayid=21 then 1 end),0) as cscatsdm,
            coalesce(sum(case when displayid=22 then 1 end),0) as daatsdm,
            coalesce(sum(case when displayid=23 then 1 end),0) as veratsdm,
            coalesce(sum(case when displayid=24 then 1 end),0) as tehatsdm,
            coalesce(sum(case when displayid=31 then 1 end),0) as cscatdm,
            coalesce(sum(case when displayid=32 then 1 end),0) as daatdm,
            coalesce(sum(case when displayid=33 then 1 end),0) as veratdm,
            coalesce(sum(case when displayid=34 then 1 end),0) as tehatdm
            from dstc.scheduledescalationdata AD inner join servicemaster sm on sm.servicecode=ad.servicecode
            where 1=1 " + SubDivQry + ServiceQry + DistrictQry + DateQry + " group by sm.servicecode";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            cmd.Parameters.AddWithValue("@DistrictCode", Sessions.getEmployeeUser().DistrictCode);
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledEscalationData);
            return View(model);

        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ServiceWiseEscalationReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("ServiceWiseEscalationReport", "Report", new { q = QueryString });
            }
            return View("ServiceWiseEscalationReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult ApplicationEscalationDetails(int? service, int? status, string DTF, string DTT)
        {
            string SubDivQry = string.Empty, DateQry = string.Empty;
            if (Convert.ToInt32(Sessions.getEmployeeUser().Permission).Equals((int)Permission.DC) || Convert.ToInt32(Sessions.getEmployeeUser().Permission).Equals((int)Permission.DCOM) || Convert.ToInt32(Sessions.getEmployeeUser().Permission).Equals((int)Permission.ADMN) || Convert.ToInt32(Sessions.getEmployeeUser().Permission).Equals((int)Permission.MONT)) { SubDivQry = " "; }
            else { SubDivQry = " and AD.subdivcode in (@ParamSubDivCode) "; }

            if (!string.IsNullOrEmpty(DTF)) { DateQry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { DateQry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }

            if (service == null && status == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }
            string statusId = string.Empty;
            if (status == 11) { statusId = " and SCH.DisplayId = 11"; }
            else if (status == 12) { statusId = " and SCH.DisplayId = 12"; }
            else if (status == 13) { statusId = " and SCH.DisplayId = 13"; }
            else if (status == 21) { statusId = " and SCH.DisplayId = 21"; }
            else if (status == 22) { statusId = " and SCH.DisplayId = 22"; }
            else if (status == 23) { statusId = " and SCH.DisplayId = 23"; }
            else if (status == 24) { statusId = " and SCH.DisplayId = 24"; }
            else if (status == 31) { statusId = " and SCH.DisplayId = 31"; }
            else if (status == 32) { statusId = " and SCH.DisplayId = 32"; }
            else if (status == 33) { statusId = " and SCH.DisplayId = 33"; }
            else if (status == 34) { statusId = " and SCH.DisplayId = 34"; }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,AD.ServiceCode,SR.ServiceName,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,date_part('day',(now()-AD.ApplicationDate)) as PendingDays,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantlocalityid,applicationsubdivcode,applicationdistrictcode,AD.stateid,countryid,applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,SL.StatusName from dstc.scheduledescalationdata SSD inner join dbo.ApplicationDetails AD on AD.ApplicationNo=SSD.ApplicationNo inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join dbo.scheduledescalationdata SCH on SCH.ApplicationNo=AD.ApplicationNo and SCH.ServiceCode=AD.ServiceCode
            where AD.ServiceCode=@ServiceCode " + SubDivQry + " " + statusId + " " + DateQry + "  group by SR.ServiceName,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ApplicantAddress,AD.ApplicantDob,SL.StatusName,AD.ServiceCode order by SL.StatusName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@PendingAtDA", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@PendingAtTEH", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@PendingAtVerifier", (int)Status.VERSENT);
            cmd.Parameters.AddWithValue("@ObjectionByTEH", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@PermissionVER", (int)Permission.VERF);
            cmd.Parameters.AddWithValue("@PermissionDA", (int)Permission.DEAL);
            cmd.Parameters.AddWithValue("@PermissionTEH", (int)Permission.TEHS);
            cmd.Parameters.AddWithValue("@PermissionSDM", (int)Permission.SDMG);
            cmd.Parameters.AddWithValue("@PermissionDC", (int)Permission.DC);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DistWiseReport(string DTF, string DTT)
        {
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { return RedirectToAction("SubDivWiseReport"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = @"select  @DisplayFromDate as FromDate,@DisplayToDate as ToDate,DM.DistrictCode,DM.DistrictName,coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) CSCReceived,coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) CitizenReceived,
            coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus25,@ApplicationStatus29,@ApplicationStatus30,@ApplicationStatus31,@ApplicationStatus32,@ApplicationStatus33,@ApplicationStatus34,@ApplicationStatus35) then 1 end),0) as Pendingatwindow,
            coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus41) then 1 end),0) as PendingUnderEditing,coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus21) then 1 end),0) as PendingatDA,
            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus3,@ApplicationStatus39,@ApplicationStatus40) then 1 end),0) as PendingatVerifier,
            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus5) and WhetherVerified=false  then 1 end),0) as Pendingbeforeverification,
            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus5) and WhetherVerified=true  then 1 end),0) as Pendingafterverification,
            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus6,@ApplicationStatus7,@ApplicationStatus36) then 1 end),0) as PendingforSigning,
            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus12,@ApplicationStatus27) then 1 end),0) as underobjection,
            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus16) then 1 end),0) as Disposed,coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus14) then 1 end),0) as rejected,
            coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus1) then 1 end),0) as Canceled from dstc.ScheduledStaticData  AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode where DM.deptcode=@ParamDeptCode and DM.stateid=@stateid";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by AD.districtcode,DM.DistrictCode,DM.DistrictName order by DM.DistrictName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@ApplicationSourceId2", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ApplicationStatus25", (int)Status.WEBPENC);
            cmd.Parameters.AddWithValue("@ApplicationStatus29", (int)Status.SCOM029);
            cmd.Parameters.AddWithValue("@ApplicationStatus30", (int)Status.SCOM030);
            cmd.Parameters.AddWithValue("@ApplicationStatus31", (int)Status.SCOM031);
            cmd.Parameters.AddWithValue("@ApplicationStatus32", (int)Status.SCOM032);
            cmd.Parameters.AddWithValue("@ApplicationStatus33", (int)Status.SCOM033);
            cmd.Parameters.AddWithValue("@ApplicationStatus34", (int)Status.SCOM034);
            cmd.Parameters.AddWithValue("@ApplicationStatus35", (int)Status.SCOM035);
            cmd.Parameters.AddWithValue("@ApplicationStatus41", (int)Status.CSCEDT);
            cmd.Parameters.AddWithValue("@ApplicationStatus21", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ApplicationStatus3", (int)Status.VERSENT);
            cmd.Parameters.AddWithValue("@ApplicationStatus39", (int)Status.VERLGAZ);
            cmd.Parameters.AddWithValue("@ApplicationStatus40", (int)Status.VERLOTHS);
            cmd.Parameters.AddWithValue("@ApplicationStatus5", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@ApplicationStatus6", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ApplicationStatus7", (int)Status.NOTIACT);
            cmd.Parameters.AddWithValue("@ApplicationStatus36", (int)Status.SCOM036);
            cmd.Parameters.AddWithValue("@ApplicationStatus12", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus27", (int)Status.WEBJST);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DistWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("DistWiseReport", "Report", new { q = QueryString });
            }
            return View("DistWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult SubDivWiseReport(int? dist, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            if (dist.Equals(null)) { dist = Convert.ToInt32(Sessions.getEmployeeUser().DistrictCode); }

            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
            model.ApplicationSubDivCode = Sessions.getEmployeeUser().SubDivCode;
            string Qry = @"select  @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SM.SubDivDescription,SM.DistrictCode,DM.DistrictName,AD.subdivcode, coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) CSCReceived,coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) CitizenReceived,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus25,@ApplicationStatus29,@ApplicationStatus30,@ApplicationStatus31,@ApplicationStatus32,@ApplicationStatus33,@ApplicationStatus34,@ApplicationStatus35) then 1 end),0) as Pendingatwindow,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus41) then 1 end),0) as PendingUnderEditing,coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus21) then 1 end),0) as PendingatDA,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus3,@ApplicationStatus39,@ApplicationStatus40) then 1 end),0) as PendingatVerifier, 
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus5) and WhetherVerified=false then 1 end),0) as Pendingbeforeverification,coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus5) and WhetherVerified=true then 1 end),0) as Pendingafterverification,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus6,@ApplicationStatus7,@ApplicationStatus36) then 1 end),0) as PendingforSigning,coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus12,@ApplicationStatus27) then 1 end),0) as underobjection,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus16) then 1 end),0) as Disposed,coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus14) then 1 end),0) as rejected,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus1) then 1 end),0) as Canceled 
                        from dstc.ScheduledStaticData AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode where SM.DistrictCode=@DistrictCode";
            if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry += " and SM.SubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by AD.subdivcode,DM.DistrictName,SM.SubDivDescription,SM.DistrictCode order by SM.SubDivDescription";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DistrictCode", dist);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@ApplicationSourceId2", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ApplicationStatus25", (int)Status.WEBPENC);
            cmd.Parameters.AddWithValue("@ApplicationStatus29", (int)Status.SCOM029);
            cmd.Parameters.AddWithValue("@ApplicationStatus30", (int)Status.SCOM030);
            cmd.Parameters.AddWithValue("@ApplicationStatus31", (int)Status.SCOM031);
            cmd.Parameters.AddWithValue("@ApplicationStatus32", (int)Status.SCOM032);
            cmd.Parameters.AddWithValue("@ApplicationStatus33", (int)Status.SCOM033);
            cmd.Parameters.AddWithValue("@ApplicationStatus34", (int)Status.SCOM034);
            cmd.Parameters.AddWithValue("@ApplicationStatus35", (int)Status.SCOM035);
            cmd.Parameters.AddWithValue("@ApplicationStatus41", (int)Status.CSCEDT);
            cmd.Parameters.AddWithValue("@ApplicationStatus21", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ApplicationStatus3", (int)Status.VERSENT);
            cmd.Parameters.AddWithValue("@ApplicationStatus39", (int)Status.VERLGAZ);
            cmd.Parameters.AddWithValue("@ApplicationStatus40", (int)Status.VERLOTHS);
            cmd.Parameters.AddWithValue("@ApplicationStatus5", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@ApplicationStatus6", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ApplicationStatus7", (int)Status.NOTIACT);
            cmd.Parameters.AddWithValue("@ApplicationStatus36", (int)Status.SCOM036);
            cmd.Parameters.AddWithValue("@ApplicationStatus12", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus27", (int)Status.WEBJST);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult SubDivWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("SubDivWiseReport", "Report", new { q = QueryString });
            }
            return View("SubDivWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult ServiceWiseReport(int subDiv, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
            string Qry = @"select  @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SC.ServiceName,SC.ServiceCode,DM.DistrictName,DM.DistrictCode,AD.subdivcode,SM.SubDivDescription,coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) CSCReceived,coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) CitizenReceived,
                            coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus25,@ApplicationStatus29,@ApplicationStatus30,@ApplicationStatus31,@ApplicationStatus32,@ApplicationStatus33,@ApplicationStatus34,@ApplicationStatus35) then 1 end),0) as Pendingatwindow,
                            coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus41) then 1 end),0) as PendingUnderEditing,coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus21) then 1 end),0) as PendingatDA,
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus3,@ApplicationStatus39,@ApplicationStatus40) then 1 end),0) as PendingatVerifier, coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus5) and WhetherVerified=False then 1 end),0) as Pendingbeforeverification,coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus5) and WhetherVerified=True then 1 end),0) as Pendingafterverification,
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus6,@ApplicationStatus7,@ApplicationStatus36) then 1 end),0) as PendingforSigning,
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus12,@ApplicationStatus27) then 1 end),0) as underobjection,
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus16) then 1 end),0) as Disposed,coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus14) then 1 end),0) as rejected,coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus1) then 1 end),0) as Canceled 
                            from dstc.ScheduledStaticData  AD left outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where AD.subdivcode=@SubDivCode";
            if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by AD.subdivcode,SM.SubDivDescription,DM.DistrictName,DM.DistrictCode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@ApplicationSourceId2", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ApplicationStatus25", (int)Status.WEBPENC);
            cmd.Parameters.AddWithValue("@ApplicationStatus29", (int)Status.SCOM029);
            cmd.Parameters.AddWithValue("@ApplicationStatus30", (int)Status.SCOM030);
            cmd.Parameters.AddWithValue("@ApplicationStatus31", (int)Status.SCOM031);
            cmd.Parameters.AddWithValue("@ApplicationStatus32", (int)Status.SCOM032);
            cmd.Parameters.AddWithValue("@ApplicationStatus33", (int)Status.SCOM033);
            cmd.Parameters.AddWithValue("@ApplicationStatus34", (int)Status.SCOM034);
            cmd.Parameters.AddWithValue("@ApplicationStatus35", (int)Status.SCOM035);
            cmd.Parameters.AddWithValue("@ApplicationStatus41", (int)Status.CSCEDT);
            cmd.Parameters.AddWithValue("@ApplicationStatus21", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ApplicationStatus3", (int)Status.VERSENT);
            cmd.Parameters.AddWithValue("@ApplicationStatus39", (int)Status.VERLGAZ);
            cmd.Parameters.AddWithValue("@ApplicationStatus40", (int)Status.VERLOTHS);
            cmd.Parameters.AddWithValue("@ApplicationStatus5", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@ApplicationStatus6", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ApplicationStatus7", (int)Status.NOTIACT);
            cmd.Parameters.AddWithValue("@ApplicationStatus36", (int)Status.SCOM036);
            cmd.Parameters.AddWithValue("@ApplicationStatus12", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus27", (int)Status.WEBJST);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult LiveDistWiseReport(string DTF, string DTT)
        {
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { return RedirectToAction("LiveSubDivWiseReport"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            //string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.DistrictCode,rs.DistrictName,rs.CSCReceived,rs.CitizenReceived,rs.Pendingatwindow,rs.PendingUnderEditing,rs.PendingatDA,rs.PendingatVerifier,rs.Pendingbeforeverification,rs.Pendingafterverification,rs.PendingforSigning,rs.underobjection,rs.Disposed,rs.rejected,rs.Canceled,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end,2) as perPending,rs.Pendingintime from (select  DM.DistrictCode,DM.DistrictName,coalesce(sum(case when ApplicationSourceId=2 then 1 end),0) CSCReceived,coalesce(sum(case when ApplicationSourceId=1 then 1 end),0) CitizenReceived,coalesce(sum(case when ApplicationStatusId in(25,29,30,31,32,33,34,35) then 1 end),0) as Pendingatwindow,coalesce(sum(case when ApplicationStatusId in(41) then 1 end),0) as PendingUnderEditing,coalesce(sum(case when ApplicationStatusId in (21) then 1 end),0) as PendingatDA,coalesce(sum(case when ApplicationStatusId in (3,39,40) then 1 end),0) as PendingatVerifier,coalesce(sum(case when ApplicationStatusId in (5) and VD.ApplicationNo is null then 1 end),0) as Pendingbeforeverification,coalesce(sum(case when ApplicationStatusId in (5) and VD.ApplicationNo is not null then 1 end),0) as Pendingafterverification,coalesce(sum(case when ApplicationStatusId in (6,7,36) then 1 end),0) as PendingforSigning,coalesce(sum(case when ApplicationStatusId in (12,13,27) then 1 end),0) as underobjection,coalesce(sum(case when ApplicationStatusId in (16) then 1 end),0) as Disposed,coalesce(sum(case when ApplicationStatusId in(14) then 1 end),0) as rejected,coalesce(sum(case when ApplicationStatusId in(1) then 1 end),0) as Canceled,coalesce(sum(case when AD.ApplicationStatusId not in (1,14,16) and (select (to_char(now(),'YYYYMMDD')::date- to_char(AD.applicationdate,'YYYYMMDD')::date)<=(case when AD.applicationdate<'2015-12-01' then SM.oldprocessingdays else SM.processingdays end))then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in (1,14,16) and (select (to_char(now(),'YYYYMMDD')::date- to_char(AD.applicationdate,'YYYYMMDD')::date)>(case when AD.applicationdate<'2015-12-01' then SM.oldprocessingdays else SM.processingdays end))then 1 end),0) as Pendingbeyondtime from dbo.ApplicationDetails AD right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode left outer join (select distinct applicationno from (select applicationno from verifierapplicationdetails union select applicationno from applicationverificationletterdetails)a) VD on VD.ApplicationNo=AD.ApplicationNo where DM.deptcode=@ParamDeptCode and DM.stateid=@stateid ";
            //string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.DistrictCode,rs.DistrictName,rs.CSCReceived,rs.CitizenReceived,rs.Pendingatwindow,rs.PendingUnderEditing,rs.PendingatDA,rs.PendingatVerifier,rs.Pendingbeforeverification,rs.Pendingafterverification,rs.PendingforSigning,rs.underobjection,rs.Disposed,rs.rejected,rs.Canceled,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end,2) as perPending,rs.Pendingintime,rs.OtherStateVer from (select  DM.DistrictCode,DM.DistrictName,coalesce(sum(case when AD.ApplicationSourceId=2 then 1 end),0) CSCReceived,coalesce(sum(case when AD.ApplicationSourceId=1 then 1 end),0) CitizenReceived,coalesce(sum(case when AD.ApplicationStatusId in(25,29,30,31,32,33,34,35) then 1 end),0) as Pendingatwindow,coalesce(sum(case when AD.ApplicationStatusId in(41) then 1 end),0) as PendingUnderEditing,coalesce(sum(case when AD.ApplicationStatusId in (21) then 1 end),0) as PendingatDA,coalesce(sum(case when AD.ApplicationStatusId in (3,39,40) then 1 end),0) as PendingatVerifier,coalesce(sum(case when AD.ApplicationStatusId in (5) and VD.ApplicationNo is null then 1 end),0) as Pendingbeforeverification,coalesce(sum(case when AD.ApplicationStatusId in (5) and VD.ApplicationNo is not null then 1 end),0) as Pendingafterverification,coalesce(sum(case when AD.ApplicationStatusId in (6,7,36) then 1 end),0) as PendingforSigning,coalesce(sum(case when AD.ApplicationStatusId in (12,13,27) then 1 end),0) as underobjection,coalesce(sum(case when AD.ApplicationStatusId in (16) then 1 end),0) as Disposed,coalesce(sum(case when AD.ApplicationStatusId in(14) then 1 end),0) as rejected,coalesce(sum(case when AD.ApplicationStatusId in(1) then 1 end),0) as Canceled,coalesce(sum(case when AD.ApplicationStatusId not in(1,14,16) and SSD.valueid in (78,79,80) then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in(1,14,16) and SSD.valueid=81 then 1 end),0) as Pendingbeyondtime,coalesce(sum(case when AD.ApplicationStatusId in(@VERLOTHS)  and SSD.valueid=81 then 1 end),0) as OtherStateVer from dbo.ApplicationDetails AD right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode left outer join (select distinct applicationno from (select applicationno from verifierapplicationdetails union select applicationno from applicationverificationletterdetails)a) VD on VD.ApplicationNo=AD.ApplicationNo left outer join dstc.scheduledstaticdata SSD on SSD.Applicationno=AD.Applicationno  where DM.deptcode=@ParamDeptCode and DM.stateid=@stateid";
            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.DistrictCode,rs.DistrictName,rs.CSCReceived,rs.CitizenReceived,rs.Pendingatwindow,rs.PendingUnderEditing,rs.PendingatDA,rs.PendingatVerifier,rs.Pendingbeforeverification,rs.Pendingafterverification,rs.PendingforSigning,rs.underobjection,rs.Disposed,rs.rejected,rs.Canceled,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end,2) as perPending,rs.Pendingintime,rs.OtherStateVer from (select  DM.DistrictCode,DM.DistrictName,coalesce(sum(case when AD.ApplicationSourceId=2 then 1 end),0) CSCReceived,coalesce(sum(case when AD.ApplicationSourceId=1 then 1 end),0) CitizenReceived,coalesce(sum(case when AD.ApplicationStatusId in(25,29,30,31,32,33,34,35) then 1 end),0) as Pendingatwindow,coalesce(sum(case when AD.ApplicationStatusId in(41) then 1 end),0) as PendingUnderEditing,coalesce(sum(case when AD.ApplicationStatusId in (21) then 1 end),0) as PendingatDA,coalesce(sum(case when AD.ApplicationStatusId in (3,39,40) then 1 end),0) as PendingatVerifier,coalesce(sum(case when AD.ApplicationStatusId in (5) and VD.ApplicationNo is null then 1 end),0) as Pendingbeforeverification,coalesce(sum(case when AD.ApplicationStatusId in (5) and VD.ApplicationNo is not null then 1 end),0) as Pendingafterverification,coalesce(sum(case when AD.ApplicationStatusId in (6,7,36) then 1 end),0) as PendingforSigning,coalesce(sum(case when AD.ApplicationStatusId in (12,13,27) then 1 end),0) as underobjection,coalesce(sum(case when AD.ApplicationStatusId in (16) then 1 end),0) as Disposed,coalesce(sum(case when AD.ApplicationStatusId in(14) then 1 end),0) as rejected,coalesce(sum(case when AD.ApplicationStatusId in(1) then 1 end),0) as Canceled,coalesce(sum(case when AD.ApplicationStatusId not in(1,14,16) and SSD.valueid in (78,79,80) then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in(1,14,16) and SSD.valueid=81 then 1 end),0) as Pendingbeyondtime,coalesce(sum(case when AD.ApplicationStatusId in(@VERLOTHS)  and SSD.valueid=81 then 1 end),0) as OtherStateVer from dbo.ApplicationDetails AD right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode left outer join (select distinct applicationno from (select applicationno from verifierapplicationdetails union select applicationno from applicationverificationletterdetails)a) VD on VD.ApplicationNo=AD.ApplicationNo left outer join (select applicationno,case when daystype = 0 or Sm.servicecode=@Marriage then 	case when pendays<=OldProcessingDays-10 then 78 when pendays>OldProcessingDays-10 and pendays<=OldProcessingDays-5 then 79 when pendays>OldProcessingDays-5 and pendays<=OldProcessingDays then 80 when pendays>OldProcessingDays then 81 end when daystype = 1 then case when pendays<=ProcessingDays-8 then 78 when pendays>ProcessingDays-8 and pendays<=ProcessingDays-3 then 79 when pendays>ProcessingDays-3 and pendays<=ProcessingDays then 80 	when pendays>ProcessingDays then 81 end end as valueid from (select AD.ApplicationNo,AD.servicecode,AD.applicationdate,case when AD.applicationdate < '2015-12-01 00:00:01' then (to_char(now(),'YYYYMMDD')::date-to_char(AD.ApplicationDate,'YYYYMMDD')::date) when AD.applicationdate > '2015-11-30 23:59:59' then (to_char(now(),'YYYYMMDD')::date-to_char(AD.ApplicationDate,'YYYYMMDD')::date) - COALESCE(VD.totalverificationdays,0) end as pendays ,case when AD.applicationdate < '2015-12-01 00:00:01' then 0 when AD.applicationdate > '2015-11-30 23:59:59' then 1 end as daystype from ApplicationDetails AD left outer join applicationverificationletterdetails VD on VD.applicationno=AD.applicationno where AD.ApplicationStatusId not in(1,14,16)) ab inner join servicemaster sm on sm.servicecode=ab.servicecode ) SSD on SSD.Applicationno=AD.Applicationno where DM.deptcode=@ParamDeptCode and DM.stateid=@stateid ";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by AD.applicationdistrictcode,DM.DistrictCode,DM.DistrictName order by DM.DistrictName) rs";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@VERLOTHS", (int)Status.VERLOTHS);
            cmd.Parameters.AddWithValue("@Marriage", (int)ServiceList.Marriage);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult LiveDistWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("LiveDistWiseReport", "Report", new { q = QueryString });
            }
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult LiveSubDivWiseReport(int? dist, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            if (dist.Equals(null)) { dist = Convert.ToInt32(Sessions.getEmployeeUser().DistrictCode); }

            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
            model.ApplicationSubDivCode = Sessions.getEmployeeUser().SubDivCode;
            //string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.SubDivDescription,rs.DistrictCode,rs.DistrictName,rs.applicationsubdivcode,rs.CSCReceived,rs.CitizenReceived,rs.Pendingatwindow,rs.PendingUnderEditing,rs.PendingatDA,rs.PendingatVerifier,rs.Pendingbeforeverification,rs.Pendingafterverification,rs.PendingforSigning,rs.underobjection,rs.Disposed,rs.rejected,rs.Canceled,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end,2) as perPending,rs.Pendingintime from (select SM.SubDivDescription,SM.DistrictCode,DM.DistrictName,AD.applicationsubdivcode,coalesce(sum(case when ApplicationSourceId=2 then 1 end),0) CSCReceived,coalesce(sum(case when ApplicationSourceId=1 then 1 end),0) CitizenReceived,coalesce(sum(case when ApplicationStatusId in(25,29,30,31,32,33,34,35) then 1 end),0) as Pendingatwindow,coalesce(sum(case when ApplicationStatusId in(41) then 1 end),0) as PendingUnderEditing,coalesce(sum(case when ApplicationStatusId in (21) then 1 end),0) as PendingatDA,coalesce(sum(case when ApplicationStatusId in (3,39,40) then 1 end),0) as PendingatVerifier, coalesce(sum(case when ApplicationStatusId in (5) and VD.ApplicationNo is null then 1 end),0) as Pendingbeforeverification,coalesce(sum(case when ApplicationStatusId in (5) and VD.ApplicationNo is not null then 1 end),0) as Pendingafterverification,coalesce(sum(case when ApplicationStatusId in (6,7,36) then 1 end),0) as PendingforSigning,coalesce(sum(case when ApplicationStatusId in (12,13,27) then 1 end),0) as underobjection,coalesce(sum(case when ApplicationStatusId in (16) then 1 end),0) as Disposed,coalesce(sum(case when ApplicationStatusId in(14,18) then 1 end),0) as rejected,coalesce(sum(case when ApplicationStatusId in(1) then 1 end),0) as Canceled,coalesce(sum(case when AD.ApplicationStatusId not in (1,14,16) and (select (to_char(now(),'YYYYMMDD')::date- to_char(AD.applicationdate,'YYYYMMDD')::date)<=(case when AD.applicationdate<'2015-12-01' then SR.oldprocessingdays else SR.processingdays end))then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in (1,14,16) and (select (to_char(now(),'YYYYMMDD')::date- to_char(AD.applicationdate,'YYYYMMDD')::date)>(case when AD.applicationdate<'2015-12-01' then SR.oldprocessingdays else SR.processingdays end))then 1 end),0) as Pendingbeyondtime from dbo.ApplicationDetails AD inner join dbo.ServiceMaster SR on AD.servicecode=SR.servicecode right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join (select distinct applicationno from (select applicationno from verifierapplicationdetails union select applicationno from applicationverificationletterdetails)a) VD on VD.ApplicationNo=AD.ApplicationNo where SM.DistrictCode=@DistrictCode ";
            //string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.SubDivDescription,rs.DistrictCode,rs.DistrictName,rs.applicationsubdivcode,rs.CSCReceived,rs.CitizenReceived,rs.Pendingatwindow,rs.PendingUnderEditing,rs.PendingatDA,rs.PendingatVerifier,rs.Pendingbeforeverification,rs.Pendingafterverification,rs.PendingforSigning,rs.underobjection,rs.Disposed,rs.rejected,rs.Canceled,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end,2) as perPending,rs.Pendingintime,rs.OtherStateVer from (select SM.SubDivDescription,SM.DistrictCode,DM.DistrictName,AD.applicationsubdivcode,coalesce(sum(case when AD.ApplicationSourceId=2 then 1 end),0) CSCReceived,coalesce(sum(case when AD.ApplicationSourceId=1 then 1 end),0) CitizenReceived,coalesce(sum(case when AD.ApplicationStatusId in(25,29,30,31,32,33,34,35) then 1 end),0) as Pendingatwindow,coalesce(sum(case when AD.ApplicationStatusId in(41) then 1 end),0) as PendingUnderEditing,coalesce(sum(case when AD.ApplicationStatusId in (21) then 1 end),0) as PendingatDA,coalesce(sum(case when AD.ApplicationStatusId in (3,39,40) then 1 end),0) as PendingatVerifier, coalesce(sum(case when AD.ApplicationStatusId in (5) and VD.ApplicationNo is null then 1 end),0) as Pendingbeforeverification,coalesce(sum(case when AD.ApplicationStatusId in (5) and VD.ApplicationNo is not null then 1 end),0) as Pendingafterverification,coalesce(sum(case when AD.ApplicationStatusId in (6,7,36) then 1 end),0) as PendingforSigning,coalesce(sum(case when AD.ApplicationStatusId in (12,13,27) then 1 end),0) as underobjection,coalesce(sum(case when AD.ApplicationStatusId in (16) then 1 end),0) as Disposed,coalesce(sum(case when AD.ApplicationStatusId in(14,18) then 1 end),0) as rejected,coalesce(sum(case when AD.ApplicationStatusId in(1) then 1 end),0) as Canceled,coalesce(sum(case when AD.ApplicationStatusId not in(1,14,16) and SSD.valueid in (78,79,80) then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in(1,14,16) and SSD.valueid=81 then 1 end),0) as Pendingbeyondtime,coalesce(sum(case when AD.ApplicationStatusId in(@VERLOTHS) and SSD.valueid=81 then 1 end),0) as OtherStateVer from dbo.ApplicationDetails AD inner join dbo.ServiceMaster SR on AD.servicecode=SR.servicecode right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join (select distinct applicationno from (select applicationno from verifierapplicationdetails union select applicationno from applicationverificationletterdetails)a) VD on VD.ApplicationNo=AD.ApplicationNo left outer join dstc.scheduledstaticdata SSD on SSD.Applicationno=AD.Applicationno where SM.DistrictCode=@DistrictCode ";
            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.SubDivDescription,rs.DistrictCode,rs.DistrictName,rs.applicationsubdivcode,rs.CSCReceived,rs.CitizenReceived,rs.Pendingatwindow,rs.PendingUnderEditing,rs.PendingatDA,rs.PendingatVerifier,rs.Pendingbeforeverification,rs.Pendingafterverification,rs.PendingforSigning,rs.underobjection,rs.Disposed,rs.rejected,rs.Canceled,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end,2) as perPending,rs.Pendingintime,rs.OtherStateVer from (select SM.SubDivDescription,SM.DistrictCode,DM.DistrictName,AD.applicationsubdivcode,coalesce(sum(case when AD.ApplicationSourceId=2 then 1 end),0) CSCReceived,coalesce(sum(case when AD.ApplicationSourceId=1 then 1 end),0) CitizenReceived,coalesce(sum(case when AD.ApplicationStatusId in(25,29,30,31,32,33,34,35) then 1 end),0) as Pendingatwindow,coalesce(sum(case when AD.ApplicationStatusId in(41) then 1 end),0) as PendingUnderEditing,coalesce(sum(case when AD.ApplicationStatusId in (21) then 1 end),0) as PendingatDA,coalesce(sum(case when AD.ApplicationStatusId in (3,39,40) then 1 end),0) as PendingatVerifier, coalesce(sum(case when AD.ApplicationStatusId in (5) and VD.ApplicationNo is null then 1 end),0) as Pendingbeforeverification,coalesce(sum(case when AD.ApplicationStatusId in (5) and VD.ApplicationNo is not null then 1 end),0) as Pendingafterverification,coalesce(sum(case when AD.ApplicationStatusId in (6,7,36) then 1 end),0) as PendingforSigning,coalesce(sum(case when AD.ApplicationStatusId in (12,13,27) then 1 end),0) as underobjection,coalesce(sum(case when AD.ApplicationStatusId in (16) then 1 end),0) as Disposed,coalesce(sum(case when AD.ApplicationStatusId in(14,18) then 1 end),0) as rejected,coalesce(sum(case when AD.ApplicationStatusId in(1) then 1 end),0) as Canceled,coalesce(sum(case when AD.ApplicationStatusId not in(1,14,16) and SSD.valueid in (78,79,80) then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in(1,14,16) and SSD.valueid=81 then 1 end),0) as Pendingbeyondtime,coalesce(sum(case when AD.ApplicationStatusId in(@VERLOTHS) and SSD.valueid=81 then 1 end),0) as OtherStateVer from dbo.ApplicationDetails AD inner join dbo.ServiceMaster SR on AD.servicecode=SR.servicecode right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join (select distinct applicationno from (select applicationno from verifierapplicationdetails union select applicationno from applicationverificationletterdetails)a) VD on VD.ApplicationNo=AD.ApplicationNo left outer join (select applicationno,case when daystype = 0 or Sm.servicecode=@Marriage then case when pendays<=OldProcessingDays-10 then 78 when pendays>OldProcessingDays-10 and pendays<=OldProcessingDays-5 then 79	when pendays>OldProcessingDays-5 and pendays<=OldProcessingDays then 80 when pendays>OldProcessingDays then 81 end when daystype = 1 then case when pendays<=ProcessingDays-8 then 78 when pendays>ProcessingDays-8 and pendays<=ProcessingDays-3 then 79 when pendays>ProcessingDays-3 and pendays<=ProcessingDays then 80 when pendays>ProcessingDays then 81 end end as valueid from (select AD.ApplicationNo,AD.servicecode,AD.applicationdate,case when AD.applicationdate < '2015-12-01 00:00:01' then (to_char(now(),'YYYYMMDD')::date-to_char(AD.ApplicationDate,'YYYYMMDD')::date) when AD.applicationdate > '2015-11-30 23:59:59' then (to_char(now(),'YYYYMMDD')::date-to_char(AD.ApplicationDate,'YYYYMMDD')::date) - COALESCE(VD.totalverificationdays,0) end as pendays,case when AD.applicationdate < '2015-12-01 00:00:01' then 0 when AD.applicationdate > '2015-11-30 23:59:59' then 1 end as daystype from ApplicationDetails AD left outer join applicationverificationletterdetails VD on VD.applicationno=AD.applicationno where AD.ApplicationStatusId not in(1,14,16)) ab inner join servicemaster sm on sm.servicecode=ab.servicecode ) SSD on SSD.Applicationno=AD.Applicationno where SM.DistrictCode=@DistrictCode";
            if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry += " and SM.SubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by AD.applicationsubdivcode,DM.DistrictName,SM.SubDivDescription,SM.DistrictCode order by SM.SubDivDescription)rs";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DistrictCode", dist);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@Marriage", (int)ServiceList.Marriage);
            cmd.Parameters.AddWithValue("@VERLOTHS", (int)Status.VERLOTHS);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult LiveSubDivWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("LiveSubDivWiseReport", "Report", new { q = QueryString });
            }
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult LiveServiceWiseReport(int subDiv, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
            //string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.ServiceName,rs.ServiceCode,rs.DistrictName,rs.DistrictCode,rs.applicationsubdivcode,rs.SubDivDescription,rs.CSCReceived,rs.CitizenReceived,rs.Pendingatwindow,rs.PendingUnderEditing,rs.PendingatDA,rs.PendingatVerifier,rs.Pendingbeforeverification,rs.Pendingafterverification,rs.PendingforSigning,rs.underobjection,rs.Disposed,rs.rejected,rs.Canceled,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end,2) as perPending,rs.Pendingintime from (select  SC.ServiceName,SC.ServiceCode,DM.DistrictName,DM.DistrictCode,AD.applicationsubdivcode,SM.SubDivDescription,coalesce(sum(case when ApplicationSourceId=2 then 1 end),0) CSCReceived,coalesce(sum(case when ApplicationSourceId=1 then 1 end),0) CitizenReceived,coalesce(sum(case when ApplicationStatusId in(25,29,30,31,32,33,34,35) then 1 end),0) as Pendingatwindow,coalesce(sum(case when ApplicationStatusId in(41) then 1 end),0) as PendingUnderEditing,coalesce(sum(case when ApplicationStatusId in (21) then 1 end),0) as PendingatDA,coalesce(sum(case when ApplicationStatusId in (3,39,40) then 1 end),0) as PendingatVerifier, coalesce(sum(case when ApplicationStatusId in (5) and VD.ApplicationNo is null then 1 end),0) as Pendingbeforeverification,coalesce(sum(case when ApplicationStatusId in (5) and VD.ApplicationNo is not null then 1 end),0) as Pendingafterverification,coalesce(sum(case when ApplicationStatusId in (6,7,36) then 1 end),0) as PendingforSigning,coalesce(sum(case when ApplicationStatusId in (12,13,27) then 1 end),0) as underobjection,coalesce(sum(case when ApplicationStatusId in (16) then 1 end),0) as Disposed,coalesce(sum(case when ApplicationStatusId in(14,18) then 1 end),0) as rejected,coalesce(sum(case when ApplicationStatusId in(1) then 1 end),0) as Canceled,coalesce(sum(case when AD.ApplicationStatusId not in (1,14,16) and (select (to_char(now(),'YYYYMMDD')::date- to_char(AD.applicationdate,'YYYYMMDD')::date)<=(case when AD.applicationdate<'2015-12-01' then SC.oldprocessingdays else SC.processingdays end))then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in (1,14,16) and (select (to_char(now(),'YYYYMMDD')::date- to_char(AD.applicationdate,'YYYYMMDD')::date)>(case when AD.applicationdate<'2015-12-01' then SC.oldprocessingdays else SC.processingdays end))then 1 end),0) as Pendingbeyondtime from dbo.ApplicationDetails AD  left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode left outer join (select distinct applicationno from (select applicationno from verifierapplicationdetails union select applicationno from applicationverificationletterdetails)a) VD on VD.ApplicationNo=AD.ApplicationNo where AD.applicationsubdivcode=@SubDivCode ";
            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,rs.ServiceName,rs.ServiceCode,rs.DistrictName,rs.DistrictCode,rs.applicationsubdivcode,rs.SubDivDescription,rs.CSCReceived,rs.CitizenReceived,rs.Pendingatwindow,rs.PendingUnderEditing,rs.PendingatDA,rs.PendingatVerifier,rs.Pendingbeforeverification,rs.Pendingafterverification,rs.PendingforSigning,rs.underobjection,rs.Disposed,rs.rejected,rs.Canceled,rs.Pendingbeyondtime,round(case when rs.Pendingbeyondtime=0 then 0 else rs.Pendingbeyondtime::decimal*100/(rs.Pendingintime::decimal+rs.Pendingbeyondtime::decimal) end,2) as perPending,rs.Pendingintime,rs.OtherStateVer from (select  SC.ServiceName,SC.ServiceCode,DM.DistrictName,DM.DistrictCode,AD.applicationsubdivcode,SM.SubDivDescription,coalesce(sum(case when AD.ApplicationSourceId=2 then 1 end),0) CSCReceived,coalesce(sum(case when AD.ApplicationSourceId=1 then 1 end),0) CitizenReceived,coalesce(sum(case when AD.ApplicationStatusId in(25,29,30,31,32,33,34,35) then 1 end),0) as Pendingatwindow,coalesce(sum(case when AD.ApplicationStatusId in(41) then 1 end),0) as PendingUnderEditing,coalesce(sum(case when AD.ApplicationStatusId in (21) then 1 end),0) as PendingatDA,coalesce(sum(case when AD.ApplicationStatusId in (3,39,40) then 1 end),0) as PendingatVerifier, coalesce(sum(case when AD.ApplicationStatusId in (5) and VD.ApplicationNo is null then 1 end),0) as Pendingbeforeverification,coalesce(sum(case when AD.ApplicationStatusId in (5) and VD.ApplicationNo is not null then 1 end),0) as Pendingafterverification,coalesce(sum(case when AD.ApplicationStatusId in (6,7,36) then 1 end),0) as PendingforSigning,coalesce(sum(case when AD.ApplicationStatusId in (12,13,27) then 1 end),0) as underobjection,coalesce(sum(case when AD.ApplicationStatusId in (16) then 1 end),0) as Disposed,coalesce(sum(case when AD.ApplicationStatusId in(14,18) then 1 end),0) as rejected,coalesce(sum(case when AD.ApplicationStatusId in(1) then 1 end),0) as Canceled,coalesce(sum(case when AD.ApplicationStatusId not in(1,14,16) and SSD.valueid in (78,79,80) then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId not in(1,14,16) and SSD.valueid=81 then 1 end),0) as Pendingbeyondtime,coalesce(sum(case when AD.ApplicationStatusId in(@VERLOTHS) and SSD.valueid=81 then 1 end),0) as OtherStateVer from dbo.ApplicationDetails AD  left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode left outer join (select distinct applicationno from (select applicationno from verifierapplicationdetails union select applicationno from applicationverificationletterdetails)a) VD on VD.ApplicationNo=AD.ApplicationNo left outer join (select applicationno,case when daystype = 0 or Sm.servicecode=@Marriage then case when pendays<=OldProcessingDays-10 then 78 when pendays>OldProcessingDays-10 and pendays<=OldProcessingDays-5 then 79 when pendays>OldProcessingDays-5 and pendays<=OldProcessingDays then 80 when pendays>OldProcessingDays then 81 end when daystype = 1 then case when pendays<=ProcessingDays-8 then 78 when pendays>ProcessingDays-8 and pendays<=ProcessingDays-3 then 79 when pendays>ProcessingDays-3 and pendays<=ProcessingDays then 80 when pendays>ProcessingDays then 81 end end as valueid from (select AD.ApplicationNo,AD.servicecode,AD.applicationdate,case when AD.applicationdate < '2015-12-01 00:00:01' then (to_char(now(),'YYYYMMDD')::date-to_char(AD.ApplicationDate,'YYYYMMDD')::date) when AD.applicationdate > '2015-11-30 23:59:59' then (to_char(now(),'YYYYMMDD')::date-to_char(AD.ApplicationDate,'YYYYMMDD')::date) - COALESCE(VD.totalverificationdays,0) end as pendays,case when AD.applicationdate < '2015-12-01 00:00:01' then 0 when AD.applicationdate > '2015-11-30 23:59:59' then 1 end as daystype from ApplicationDetails AD left outer join applicationverificationletterdetails VD on VD.applicationno=AD.applicationno where AD.ApplicationStatusId not in(1,14,16)) ab inner join servicemaster sm on sm.servicecode=ab.servicecode ) SSD on SSD.Applicationno=AD.Applicationno where AD.applicationsubdivcode=@SubDivCode ";
            if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by AD.applicationsubdivcode,SM.SubDivDescription,DM.DistrictName,DM.DistrictCode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName)rs";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@VERLOTHS", (int)Status.VERLOTHS);
            cmd.Parameters.AddWithValue("@Marriage", (int)ServiceList.Marriage);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult CzDistWiseReport(string DTF, string DTT)
        {
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { return RedirectToAction("SubDivWiseReport"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = @"select  @DisplayFromDate as FromDate,@DisplayToDate as ToDate,DM.DistrictCode,DM.DistrictName,coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) CitizenReceived,
                            coalesce(sum(case when ApplicationStatusId not in(@ApplicationStatus1,@ApplicationStatus6,@ApplicationStatus14,@ApplicationStatus16,@ApplicationStatus35) and ApplicationSourceId=@ApplicationSourceId1 and whetherdocumentSeen=false then 1 end),0) as PendingDocumentSeen,
                            coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus41)and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as PendingUnderEditing,
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus21)and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as PendingatDA,
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus3,@ApplicationStatus39,@ApplicationStatus40)and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as PendingatVerifier,
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus5)and ApplicationSourceId=@ApplicationSourceId1 and WhetherVerified=False then 1 end),0) as Pendingbeforeverification,
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus5)and ApplicationSourceId=@ApplicationSourceId1 and WhetherVerified=True then 1 end),0) as Pendingafterverification,
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus6,@ApplicationStatus7,@ApplicationStatus36)and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as PendingforSigning,
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus12,@ApplicationStatus27)and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as underobjection,
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus16)and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as Disposed,
                            coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus14)and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as rejected,
                            coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus1)and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as Canceled 
                            from dstc.ScheduledStaticData  AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode  where DM.deptcode=@ParamDeptCode and DM.stateid=@stateid";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@DistrictCode"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by AD.districtcode,DM.DistrictCode,DM.DistrictName order by DM.DistrictName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { cmd.Parameters.AddWithValue("@DistrictCode", Sessions.getEmployeeUser().DistrictCode); }
            cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@ApplicationStatus35", (int)Status.SCOM035);
            cmd.Parameters.AddWithValue("@ApplicationStatus41", (int)Status.CSCEDT);
            cmd.Parameters.AddWithValue("@ApplicationStatus21", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ApplicationStatus3", (int)Status.VERSENT);
            cmd.Parameters.AddWithValue("@ApplicationStatus39", (int)Status.VERLGAZ);
            cmd.Parameters.AddWithValue("@ApplicationStatus40", (int)Status.VERLOTHS);
            cmd.Parameters.AddWithValue("@ApplicationStatus5", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@ApplicationStatus6", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ApplicationStatus7", (int)Status.NOTIACT);
            cmd.Parameters.AddWithValue("@ApplicationStatus36", (int)Status.SCOM036);
            cmd.Parameters.AddWithValue("@ApplicationStatus12", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus27", (int)Status.WEBJST);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult CzDistWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("CzDistWiseReport", "Report", new { q = QueryString });
            }
            return View("CzDistWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult CzSubDivWiseReport(int? dist, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            if (dist.Equals(null)) { dist = Convert.ToInt32(Sessions.getEmployeeUser().DistrictCode); }

            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
            model.ApplicationSubDivCode = Sessions.getEmployeeUser().SubDivCode;
            string Qry = @"select  @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SM.SubDivDescription,SM.DistrictCode,DM.DistrictName,AD.subdivcode,coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) CitizenReceived,
                            coalesce(sum(case when ApplicationStatusId not in(@ApplicationStatus1,@ApplicationStatus6,@ApplicationStatus14,@ApplicationStatus16,@ApplicationStatus35) and ApplicationSourceId=@ApplicationSourceId1 and whetherdocumentSeen=false then 1 end),0) as PendingDocumentSeen,
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus21) and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as PendingatDA,
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus3,@ApplicationStatus39,@ApplicationStatus40) and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as PendingatVerifier, 
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus5) and ApplicationSourceId=@ApplicationSourceId1 and WhetherVerified=False then 1 end),0) as Pendingbeforeverification,
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus5) and ApplicationSourceId=@ApplicationSourceId1 and WhetherVerified=True then 1 end),0) as Pendingafterverification,
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus6,@ApplicationStatus7,@ApplicationStatus36) and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as PendingforSigning,
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus12,@ApplicationStatus27) and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as underobjection,
                            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus16) and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as Disposed,
                            coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus14) and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as rejected,
                            coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus1) and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as Canceled from dstc.ScheduledStaticData  AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode where SM.DistrictCode=@DistrictCode";
            if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry += " and SM.SubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by AD.subdivcode,DM.DistrictName,SM.SubDivDescription,SM.DistrictCode order by SM.SubDivDescription";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DistrictCode", dist);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@ApplicationStatus35", (int)Status.SCOM035);
            cmd.Parameters.AddWithValue("@ApplicationStatus41", (int)Status.CSCEDT);
            cmd.Parameters.AddWithValue("@ApplicationStatus21", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ApplicationStatus3", (int)Status.VERSENT);
            cmd.Parameters.AddWithValue("@ApplicationStatus39", (int)Status.VERLGAZ);
            cmd.Parameters.AddWithValue("@ApplicationStatus40", (int)Status.VERLOTHS);
            cmd.Parameters.AddWithValue("@ApplicationStatus5", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@ApplicationStatus6", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ApplicationStatus7", (int)Status.NOTIACT);
            cmd.Parameters.AddWithValue("@ApplicationStatus36", (int)Status.SCOM036);
            cmd.Parameters.AddWithValue("@ApplicationStatus12", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus27", (int)Status.WEBJST);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult CzSubDivWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("CzSubDivWiseReport", "Report", new { q = QueryString });
            }
            return View("CzSubDivWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult CzServiceWiseReport(int subDiv, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
            string Qry = @"select  @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SC.ServiceName,SC.ServiceCode,DM.DistrictName,DM.DistrictCode,AD.subdivcode,SM.SubDivDescription,coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) CitizenReceived,
                        coalesce(sum(case when ApplicationStatusId not in(@ApplicationStatus1,@ApplicationStatus6,@ApplicationStatus14,@ApplicationStatus16,@ApplicationStatus35) and ApplicationSourceId=@ApplicationSourceId1 and whetherdocumentSeen=false then 1 end),0) as PendingDocumentSeen,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus21) and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as PendingatDA,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus3,@ApplicationStatus39,@ApplicationStatus40) and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as PendingatVerifier, 
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus5) and ApplicationSourceId=@ApplicationSourceId1 and WhetherVerified=False then 1 end),0) as Pendingbeforeverification,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus5) and ApplicationSourceId=@ApplicationSourceId1 and WhetherVerified=True then 1 end),0) as Pendingafterverification,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus6,@ApplicationStatus7,@ApplicationStatus36) and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as PendingforSigning,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus12,@ApplicationStatus27) and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as underobjection,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus16) and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as Disposed,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus14) and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as rejected,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus1)  and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as Canceled from dstc.ScheduledStaticData  AD left outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where AD.SubDivcode=@SubDivCode";
            if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by AD.subdivcode,SM.SubDivDescription,DM.DistrictName,DM.DistrictCode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@ApplicationStatus35", (int)Status.SCOM035);
            cmd.Parameters.AddWithValue("@ApplicationStatus41", (int)Status.CSCEDT);
            cmd.Parameters.AddWithValue("@ApplicationStatus21", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ApplicationStatus3", (int)Status.VERSENT);
            cmd.Parameters.AddWithValue("@ApplicationStatus39", (int)Status.VERLGAZ);
            cmd.Parameters.AddWithValue("@ApplicationStatus40", (int)Status.VERLOTHS);
            cmd.Parameters.AddWithValue("@ApplicationStatus5", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@ApplicationStatus6", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ApplicationStatus7", (int)Status.NOTIACT);
            cmd.Parameters.AddWithValue("@ApplicationStatus36", (int)Status.SCOM036);
            cmd.Parameters.AddWithValue("@ApplicationStatus12", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus27", (int)Status.WEBJST);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DistCertificateReport(string DTF, string DTT)
        {
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { return RedirectToAction("SubDivCertificateReport"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string CerDate = string.Empty;
            string AppDate = string.Empty;
            if (!string.IsNullOrEmpty(DTF)) { CerDate = " and to_char(AD.signeddate,'YYYYMMDD')::date >= @FromDate and to_char(AD.signeddate,'YYYYMMDD')::date <= @ToDate"; }
            if (!string.IsNullOrEmpty(DTT)) { AppDate = " and to_char(AD.lastactiondate,'YYYYMMDD')::date >= @FromDate and to_char(AD.lastactiondate,'YYYYMMDD')::date <= @ToDate"; }

            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,DM.DistrictCode, DM.DistrictName,coalesce(sum(case when AD.ApplicationStatusId=@ApplicationStatus16 " + CerDate + " then 1 end),0) as Disposed,coalesce(sum(case when AD.ApplicationStatusId=@ApplicationStatus14 " + AppDate + " then 1 end),0) as Rejected,coalesce(sum(case when AD.ApplicationStatusId=@ApplicationStatus1 then 1 end),0) as Canceled  from dstc.ScheduledStaticData AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode  where DM.deptcode=@ParamDeptCode";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            Qry += " group by AD.districtcode,DM.DistrictCode,DM.DistrictName order by DM.DistrictName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DistCertificateReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("DistCertificateReport", "Report", new { q = QueryString });
            }
            return View("DistCertificateReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult SubDivCertificateReport(int? dist, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            if (dist.Equals(null)) { dist = Convert.ToInt32(Sessions.getEmployeeUser().DistrictCode); }

            string CerDate = string.Empty;
            string AppDate = string.Empty;
            if (!string.IsNullOrEmpty(DTF)) { CerDate = " and to_char(AD.signeddate,'YYYYMMDD')::date >= @FromDate and to_char(AD.signeddate,'YYYYMMDD')::date <= @ToDate"; }
            if (!string.IsNullOrEmpty(DTT)) { AppDate = " and to_char(AD.lastactiondate,'YYYYMMDD')::date >= @FromDate and to_char(AD.lastactiondate,'YYYYMMDD')::date <= @ToDate"; }

            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
            model.ApplicationSubDivCode = Sessions.getEmployeeUser().SubDivCode;
            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SM.SubDivDescription,SM.DistrictCode,DM.DistrictName,AD.subdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatus16 " + CerDate + " then 1 end),0) as Disposed,coalesce(sum(case when ApplicationStatusId=@ApplicationStatus14 " + AppDate + " then 1 end),0) as Rejected,coalesce(sum(case when ApplicationStatusId=@ApplicationStatus1 " + AppDate + " then 1 end),0) as Canceled  from dstc.ScheduledStaticData AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SR on AD.servicecode=SR.servicecode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode where SM.DistrictCode=@DistrictCode";
            if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry += " and SM.SubDivCode in (@ParamSubDivCode)"; }
            //if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.signeddate,'YYYYMMDD')::date >= @FromDate"; }
            //if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.signeddate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by AD.subdivcode,DM.DistrictName,SM.SubDivDescription,SM.DistrictCode order by SM.SubDivDescription";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DistrictCode", dist);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            if (!string.IsNullOrEmpty(DTF)) { cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true)); }
            if (!string.IsNullOrEmpty(DTT)) { cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true)); }
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult SubDivCertificateReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("SubDivCertificateReport", "Report", new { q = QueryString });
            }
            return View("DistCertificateReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult ServiceCertificateReport(int? subDiv, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;

            string CerDate = string.Empty;
            string AppDate = string.Empty;
            if (!string.IsNullOrEmpty(DTF)) { CerDate = " and to_char(AD.signeddate,'YYYYMMDD')::date >= @FromDate and to_char(AD.signeddate,'YYYYMMDD')::date <= @ToDate"; }
            if (!string.IsNullOrEmpty(DTT)) { AppDate = " and to_char(AD.lastactiondate,'YYYYMMDD')::date >= @FromDate and to_char(AD.lastactiondate,'YYYYMMDD')::date <= @ToDate"; }


            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SC.ServiceName,SC.ServiceCode,AD.subdivcode,SM.SubDivDescription,DM.DistrictCode,DM.DistrictName,coalesce(sum(case when ApplicationStatusId=@ApplicationStatus16 " + CerDate + " then 1 end),0) as Disposed,coalesce(sum(case when ApplicationStatusId=@ApplicationStatus14 " + AppDate + " then 1 end),0) as Rejected,coalesce(sum(case when ApplicationStatusId=@ApplicationStatus1 " + AppDate + " then 1 end),0) as Canceled  from dstc.ScheduledStaticData AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SR on AD.servicecode=SR.servicecode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where AD.subdivcode=@SubDivCode";
            if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            //if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.signeddate,'YYYYMMDD')::date >= @FromDate"; }
            //if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.signeddate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by DM.DistrictName,DM.DistrictCode,AD.subdivcode,SM.SubDivDescription,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult CertificateDetails(int? subDiv, int? service, int? status, string DTF, string DTT)
        {
            if (subDiv == null && service == null && status == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }
            string statusId = string.Empty;

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            if (status == 7) { statusId = " and AD.ApplicationStatusId in(16) and to_char(DD.signeddate,'YYYYMMDD')::date >= @FromDate and to_char(DD.signeddate,'YYYYMMDD')::date <= @ToDate"; }
            if (status == 500) { statusId = " and AD.ApplicationStatusId in(14) and to_char(AD.lastactiondate,'YYYYMMDD')::date >= @FromDate and to_char(AD.lastactiondate,'YYYYMMDD')::date <= @ToDate"; }
            if (status == 101) { statusId = " and AD.ApplicationStatusId in(1) and to_char(AD.lastactiondate,'YYYYMMDD')::date >= @FromDate and to_char(AD.lastactiondate,'YYYYMMDD')::date <= @ToDate"; }

            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,AD.ServiceCode,AD.applicationsubdivcode,SM.SubDivDescription,DM.DistrictCode,DM.DistrictName,AD.ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode left outer join dsgn.digitaldocumentdetails DD on AD.ApplicationNo=DD.ApplicationNo where AD.ServiceCode=@ServiceCode and AD.applicationsubdivcode=@SubDivCode " + statusId + " order by AD.applicationno";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ZoneWiseDistSLAReport(string DTF, string DTT)
        {
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { return RedirectToAction("ZoneWiseSubDivSLAReport"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            if (!string.IsNullOrEmpty(DTF))
            {
                model.DateFrom = DTF;
            }
            if (!string.IsNullOrEmpty(DTT))
            {
                model.DateTo = DTT;
            }
            string whereCondition = string.Empty;
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { whereCondition += " and SD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { whereCondition += " and to_char(ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { whereCondition += " and to_char(ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,DM.DistrictCode,DistrictName,
                            (select count(*) from dstc.scheduledstaticdata SD inner join servicemaster SR on SR.servicecode=SD.servicecode where DistrictCode=DM.DistrictCode and valueid=@GreenZone and SR.WhetherIncludeInSLA=@True " + whereCondition + @")GreenZone,
                            (select count(*) from dstc.scheduledstaticdata SD inner join servicemaster SR on SR.servicecode=SD.servicecode where DistrictCode=DM.DistrictCode and valueid=@YellowZone and SR.WhetherIncludeInSLA=@True " + whereCondition + @")YellowZone,
                            (select count(*) from dstc.scheduledstaticdata SD inner join servicemaster SR on SR.servicecode=SD.servicecode where DistrictCode=DM.DistrictCode and valueid=@RedZone and SR.WhetherIncludeInSLA=@True " + whereCondition + @")RedZone,
                            (select count(*) from dstc.scheduledstaticdata SD inner join servicemaster SR on SR.servicecode=SD.servicecode where DistrictCode=DM.DistrictCode and valueid=@SLA and SR.WhetherIncludeInSLA=@True " + whereCondition + @")SLA
                            from dbo.DistrictMaster DM where WhetherActive=@True and DM.stateId=@stateid and DM.deptcode=@ParamDeptCode";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            Qry += " order by DistrictName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
            cmd.Parameters.AddWithValue("@GreenZone", (int)ValueId.GreenZone);
            cmd.Parameters.AddWithValue("@YellowZone", (int)ValueId.YellowZone);
            cmd.Parameters.AddWithValue("@RedZone", (int)ValueId.RedZone);
            cmd.Parameters.AddWithValue("@SLA", (int)ValueId.SlaZone);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            cmd.Parameters.AddWithValue("@True", CustomText.True.ToString());
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ZoneWiseDistSLAReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("ZoneWiseDistSLAReport", "Report", new { q = QueryString });
            }
            return View("ZoneWiseDistSLAReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult ZoneWiseSubDivSLAReport(int? dist, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;
            if (dist.Equals(null)) { dist = Convert.ToInt32(Sessions.getEmployeeUser().DistrictCode); }
            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
            model.ApplicationSubDivCode = Sessions.getEmployeeUser().SubDivCode;
            if (!string.IsNullOrEmpty(model.ServiceCode)) { whereCondition += " and SD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { whereCondition += " and SubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { whereCondition += " and to_char(ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { whereCondition += " and to_char(ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }

            string Qry = @"select  @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SM.SubDivcode,SubDivDescription,SM.DistrictCode,DistrictName,
		                    (select count(*) from dstc.scheduledstaticdata SD inner join servicemaster SR on SR.servicecode=SD.servicecode where DistrictCode=SM.DistrictCode and SubDivcode=SM.SubDivcode and valueid=@GreenZone and SR.whetherincludeinsla=@True " + whereCondition + @")GreenZone,
		                    (select count(*) from dstc.scheduledstaticdata SD inner join servicemaster SR on SR.servicecode=SD.servicecode where DistrictCode=SM.DistrictCode and SubDivcode=SM.SubDivcode and valueid=@YellowZone and SR.whetherincludeinsla=@True " + whereCondition + @")YellowZone,
		                    (select count(*) from dstc.scheduledstaticdata SD inner join servicemaster SR on SR.servicecode=SD.servicecode where DistrictCode=SM.DistrictCode and SubDivcode=SM.SubDivcode and valueid=@RedZone and SR.whetherincludeinsla=@True " + whereCondition + @")RedZone,
		                    (select count(*) from dstc.scheduledstaticdata SD inner join servicemaster SR on SR.servicecode=SD.servicecode where DistrictCode=SM.DistrictCode and SubDivcode=SM.SubDivcode and valueid=@SLA and SR.whetherincludeinsla=@True " + whereCondition + @")SLA
		                    from dbo.subdivmaster SM inner join DistrictMaster DM on DM.DistrictCode=SM.DistrictCode where SM.WhetherActive=true and SM.DistrictCode=@DistrictCode";
            if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry += " and SubDivCode in (@ParamSubDivCode)"; }
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@GreenZone", (int)ValueId.GreenZone);
            cmd.Parameters.AddWithValue("@YellowZone", (int)ValueId.YellowZone);
            cmd.Parameters.AddWithValue("@RedZone", (int)ValueId.RedZone);
            cmd.Parameters.AddWithValue("@SLA", (int)ValueId.SlaZone);
            cmd.Parameters.AddWithValue("@DistrictCode", dist);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            cmd.Parameters.AddWithValue("@True", CustomText.True.ToString());
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ZoneWiseSubDivSLAReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("ZoneWiseSubDivSLAReport", "Report", new { q = QueryString });
            }
            return View("ZoneWiseSubDivSLAReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult ZoneWiseServiceSLAReport(int subDiv, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate, SC.ServiceName,SC.ServiceCode,DM.DistrictName,DM.DistrictCode,SSD.subdivcode,SM.SubDivDescription,
                            coalesce(sum(case when ValueId in(@GreenZone) then 1 end),0) as GreenZone,
                            coalesce(sum(case when ValueId in(@YellowZone) then 1 end),0) as YellowZone,coalesce(sum(case when ValueId in (@RedZone) then 1 end),0) as RedZone,
                            coalesce(sum(case when ValueId in (@SLA) then 1 end),0) as SLA
                             from dstc.scheduledstaticdata SSD left outer join dbo.DistrictMaster DM on SSD.districtcode=DM.DistrictCode 
                             right outer join dbo.SubDivMaster SM on SSD.subdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on SSD.ServiceCode=SC.ServiceCode  where SSD.subdivcode=@SubDivCode and SC.whetherincludeinsla=@True";
            if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and SSD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(SSD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(SSD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by SSD.subdivcode,SM.SubDivDescription,DM.DistrictName,DM.DistrictCode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@GreenZone", (int)ValueId.GreenZone);
            cmd.Parameters.AddWithValue("@YellowZone", (int)ValueId.YellowZone);
            cmd.Parameters.AddWithValue("@RedZone", (int)ValueId.RedZone);
            cmd.Parameters.AddWithValue("@SLA", (int)ValueId.SlaZone);
            cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            cmd.Parameters.AddWithValue("@True", CustomText.True.ToString());
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult ZoneWiseBasicApplicationDetails(int? subDiv, int? service, int? status, string DTF, string DTT)
        {
            if (subDiv == null && service == null && status == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }

            string statusId = string.Empty;
            if (status == 1) { statusId = " and valueId in(@GreenZone)"; }
            else if (status == 2) { statusId = "  and valueId in(@YellowZone)"; }
            else if (status == 3) { statusId = "  and valueId in(@RedZone)"; }
            else if (status == 4) { statusId = "  and valueId in(@SLA)"; }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate, SSD.ServiceCode,SSD.subdivcode,SM.SubDivDescription,DM.DistrictCode,DM.DistrictName,
                            SSD.ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,
                            AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,
                            to_char(SSD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob
                            from dstc.scheduledstaticdata SSD left outer join dbo.ApplicationDetails AD on SSD.ApplicationNo=AD.ApplicationNo left outer join  dbo.DistrictMaster DM on SSD.districtcode=DM.DistrictCode 
                            left outer join dbo.SubDivMaster SM on SSD.subdivcode=SM.SubDivCode 
                            inner join dbo.ServiceMaster SR on SR.ServiceCode=SSD.ServiceCode where SR.whetherincludeinsla=@True and SSD.ServiceCode=@ServiceCode and SSD.subdivcode=@SubDivCode " + statusId;
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " order by ApplicationDate";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@GreenZone", (int)ValueId.GreenZone);
            cmd.Parameters.AddWithValue("@YellowZone", (int)ValueId.YellowZone);
            cmd.Parameters.AddWithValue("@RedZone", (int)ValueId.RedZone);
            cmd.Parameters.AddWithValue("@SLA", (int)ValueId.SlaZone);
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            cmd.Parameters.AddWithValue("@True", CustomText.True.ToString());
            model.data = data.GetDataTable(cmd);
            return View(model);
        }

        [EncryptedActionParameter]
        public ActionResult SubDivWiseVerifierReport(int? dist, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            if (dist.Equals(null)) { dist = Convert.ToInt32(Sessions.getEmployeeUser().DistrictCode); }

            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
            model.ApplicationSubDivCode = Sessions.getEmployeeUser().SubDivCode;
            string Qry = "select  @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SM.SubDivDescription,SM.DistrictCode,DM.DistrictName,AD.subdivcode,coalesce(sum(case when ApplicationStatusId in (3,39,40) then 1 end),0) as PendingatVerifier from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode where SM.DistrictCode=@DistrictCode";
            if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry += " and SM.SubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by AD.subdivcode,DM.DistrictName,SM.SubDivDescription,SM.DistrictCode order by SM.SubDivDescription";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DistrictCode", dist);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult SubDivWiseVerifierReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("SubDivWiseVerifierReport", "Report", new { q = QueryString });
            }
            return View("SubDivWiseVerifierReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult VerifierWiseReport(int? subDiv, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
            model.ApplicationSubDivCode = Sessions.getEmployeeUser().SubDivCode;
            string Qry1 = "select * from (select   @DisplayFromDate::text as FromDate,@DisplayToDate::text as ToDate,UM.UID,UM.UserId,UM.Username ||' ('||SM.SubDivDescription||') ' as Username,SM.SubDivDescription,SM.DistrictCode,DM.DistrictName,AD.subdivcode,coalesce(sum(case when ApplicationStatusId in (3) then 1 end),0) as PendingatVerifier from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode inner join dbo.verifierapplicationdetails AV on AV.applicationno=AD.applicationno inner join dbo.usermaster UM on UM.Uid=AV.Sentto where AD.subdivcode=@SubDivCode";
            string Qry2 = "select * from (select   @DisplayFromDate::text as FromDate,@DisplayToDate::text as ToDate,ST.StatusId as UID,ST.StatusName as UserId,ST.StatusName as Username,SM.SubDivDescription,SM.DistrictCode,DM.DistrictName,AD.subdivcode,coalesce(sum(case when ApplicationStatusId in (40) then 1 end),0) as PendingVerificationLetter from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode inner join dbo.statusmaster ST on ST.statusid=AD.Applicationstatusid where AD.subdivcode=@SubDivCode and AD.applicationstatusid=@VERLOTHS";
            string Qry3 = "select * from (select   @DisplayFromDate::text as FromDate,@DisplayToDate::text as ToDate,ST.StatusId as UID,ST.StatusName as UserId,ST.StatusName as Username,SM.SubDivDescription,SM.DistrictCode,DM.DistrictName,AD.subdivcode,coalesce(sum(case when ApplicationStatusId in (39) then 1 end),0) as PendingVerificationLetter from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode inner join dbo.statusmaster ST on ST.statusid=AD.Applicationstatusid where AD.subdivcode=@SubDivCode and AD.applicationstatusid=@VERLGAZ ";

            if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry1 += " and AD.ServiceCode in (@ParamServiceCode)"; Qry2 += " and AD.ServiceCode in (@ParamServiceCode)"; Qry3 += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry1 += " and SM.SubDivCode in (@ParamSubDivCode)"; Qry2 += " and SM.SubDivCode in (@ParamSubDivCode)"; Qry3 += " and SM.SubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry1 += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; Qry2 += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; Qry3 += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry1 += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; Qry2 += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; Qry3 += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }

            Qry1 += "  group by UM.Username,UM.UID,UM.UserId,AD.subdivcode,DM.DistrictName,SM.SubDivDescription,SM.DistrictCode order by SM.SubDivDescription )as a";
            Qry2 += "  group by AD.subdivcode,DM.DistrictName,SM.SubDivDescription,SM.DistrictCode,ST.StatusName,ST.StatusId order by SM.SubDivDescription) as b";
            Qry3 += "  group by AD.subdivcode,DM.DistrictName,SM.SubDivDescription,SM.DistrictCode,ST.StatusName,ST.StatusId order by SM.SubDivDescription) as c";
            string Qry = Qry1 + " union all " + Qry2 + " union all " + Qry3;
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            cmd.Parameters.AddWithValue("@VERLGAZ", (int)Status.VERLGAZ);
            cmd.Parameters.AddWithValue("@VERLOTHS", (int)Status.VERLOTHS);
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult VerifierWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("VerifierWiseReport", "Report", new { q = QueryString });
            }
            return View("VerifierWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult VerifierApplicationDetails(int? subDiv, int? UID, int? status, string DTF, string DTT, int? PageIndex = 1)
        {
            if (subDiv == null && UID == null && status == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }
            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "subDiv=" + subDiv.ToString());
            Parameters.Add(1, "UID=" + UID.ToString());
            Parameters.Add(2, "status=" + status.ToString());
            if (!string.IsNullOrEmpty(DTF)) { Parameters.Add(3, "DTF=" + DTF.ToString()); }
            if (!string.IsNullOrEmpty(DTT)) { Parameters.Add(4, "DTT=" + DTT.ToString()); }
            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                string statusId = string.Empty;
                if (UID == (int)Status.VERLOTHS) { statusId = " and AD.applicationstatusid in (40)"; }
                else if (UID == (int)Status.VERLGAZ) { statusId = " and AD.applicationstatusid in (39)"; }
                else { statusId = " and AV.Sentto=@UID and AD.applicationstatusid in (3)"; }
                GetData data = new GetData();
                string Qry = string.Empty;
                if (UID == (int)Status.VERLOTHS) { Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,AD.ServiceCode,AD.applicationsubdivcode,SM.SubDivDescription,DM.DistrictCode,DM.DistrictName,AD.ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName from dstc.scheduledstaticdata SSD inner join dbo.ApplicationDetails AD on Ad.ApplicationNo=SSD.ApplicationNo left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode where AD.applicationsubdivcode=@SubDivCode " + statusId; }
                else if (UID == (int)Status.VERLGAZ) { Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,AD.ServiceCode,AD.applicationsubdivcode,SM.SubDivDescription,DM.DistrictCode,DM.DistrictName,AD.ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName from dstc.scheduledstaticdata SSD inner join dbo.ApplicationDetails AD on Ad.ApplicationNo=SSD.ApplicationNo left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode  where AD.applicationsubdivcode=@SubDivCode " + statusId; }
                else { Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,AD.ServiceCode,AD.applicationsubdivcode,SM.SubDivDescription,DM.DistrictCode,DM.DistrictName,AD.ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName from dstc.scheduledstaticdata SSD inner join dbo.ApplicationDetails AD on Ad.ApplicationNo=SSD.ApplicationNo left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode inner join dbo.verifierapplicationdetails AV on AV.applicationno=AD.applicationno inner join dbo.usermaster UM on UM.Uid=AV.Sentto where AD.applicationsubdivcode=@SubDivCode " + statusId; }
                if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
                if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
                Qry += " order by ApplicationDate";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@UID", UID);
                cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
                cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
                cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
                cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
                cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "BasicApplicationDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "BasicApplicationDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View("BasicApplicationDetails", model);
        }
        [EncryptedActionParameter]
        public ActionResult EnclousreAnalysisReport(ReportModels model)
        {
            return View();

            //GetData data = new GetData();
            //string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,a.departmentid,a.deptname,c.servicename,c.validationmessage,c.sampledocumentvalue,sum(a.totaldoc) as totaldoc,sum(a.invaliddoc) as invaliddoc,sum(a.validdoc) as validdoc,sum(a.verified) as verified,sum(a.notverified) as notverified,sum(a.pendingdoc) as pendingdoc from (select rs.departmentid,rs.DeptName,rs.documentid,rs.servicename,rs.webservicemethodid,count(rs.departmentid) as totaldoc,sum(rs.invaliddoc) as invaliddoc,sum(rs.validdoc) as validdoc,sum(rs.verified) as verified,sum(rs.notverified) as notverified,(sum(rs.validdoc) - (sum(rs.verified) + sum(rs.notverified))) as pendingdoc from (select ED.departmentid,ED.DeptName,DM.documentid,WM.servicename,WE.webservicemethodid,(case when WE.webservicemethodid is not null  then 'Yes' else 'No' end) as whetherAvailable,case when (length(dbo.udf_general_decrypt(AE.documentno)) < WM.minlength or length(dbo.udf_general_decrypt(AE.documentno)) > WM.maxlength) then 1 else 0 end as invaliddoc,case when (length(dbo.udf_general_decrypt(AE.documentno)) < WM.minlength or length(dbo.udf_general_decrypt(AE.documentno)) > WM.maxlength) then 0 else 1 end as validdoc,case when (length(dbo.udf_general_decrypt(AE.documentno)) >= WM.minlength and length(dbo.udf_general_decrypt(AE.documentno)) <= WM.maxlength) and AE.whetherverified=true then 1 else 0 end as verified,case when (length(dbo.udf_general_decrypt(AE.documentno)) >= WM.minlength and length(AE.documentno) <= WM.maxlength) and AE.whetherverified=false and SVM.valueid=59 then 1 else 0 end as notverified from dstc.scheduledstaticenclousredata  AE left outer join dbo.enclosuredepartmentmaster ED on ED.DepartmentId=AE.DepartmentId left outer join dbo.selectmastervaluedetails SVM on AE.Verifyvalueid=SVM.valueid left outer join dbo.wcfdocumentmappingdetails WE on AE.documentid=WE.documentid and AE.DepartmentId=WE.DepartmentId left outer join dbo.documentmaster DM on AE.documentid=DM.documentid left outer join wcfwebservicemethoddetails WD on WD.webservicemethodid=WE.webservicemethodid left outer join wcfwebservicemethoddetails WM on WM.webservicemethodid=WD.webservicemethodid where WE.Webservicemethodid is not null";
            //if (!string.IsNullOrEmpty(model.DateFrom)) { Qry += " and to_char(AE.DocumentEntryDate,'YYYYMMDD')::date >= @FromDate"; }
            //if (!string.IsNullOrEmpty(model.DateTo)) { Qry += " and to_char(AE.DocumentEntryDate,'YYYYMMDD')::date <= @ToDate"; }
            //Qry += ") rs group by rs.departmentid,rs.DeptName,rs.documentid,rs.servicename,rs.webservicemethodid) a left outer join (select a.departmentid,c.documentname from wcfdocumentmappingdetails a inner join enclosuredepartmentmaster b on b.departmentid=a.departmentid inner join documentmaster c on c.documentid=a.documentid where a.departmentid in (select departmentid from wcfdocumentmappingdetails group by departmentid having count(*)=1)) b on b.departmentid=a.departmentid left outer join wcfwebservicemethoddetails c on c.webservicemethodid=a.webservicemethodid group by a.departmentid,a.DeptName,c.servicename,a.webservicemethodid,c.minlength,c.maxlength,c.validationmessage,c.sampledocumentvalue order by c.servicename,a.DeptName";
            //NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            //cmd.Parameters.AddWithValue("@DisplayFromDate", model.DateFrom);
            //cmd.Parameters.AddWithValue("@DisplayToDate", model.DateTo);
            //cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(model.DateFrom, '/', true));
            //cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(model.DateTo, '/', true));
            //model.data = data.GetDataTable(cmd);

            //model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.EnclosureData);
            //return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ServiceWiseDownloadAppReport(string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            if (!string.IsNullOrEmpty(DTF))
            {
                model.DateFrom = DTF;
            }
            if (!string.IsNullOrEmpty(DTT))
            {
                model.DateTo = DTT;
            }
            string SubDivQry = string.Empty, ServiceQry = string.Empty, DistrictQry = string.Empty, DateQry = string.Empty;
            if (!string.IsNullOrEmpty(DTF)) { DateQry += " and to_char(ATD.ActionDateTime,'YYYYMMDD')::date >= @FromDate "; }
            if (!string.IsNullOrEmpty(DTT)) { DateQry += " and to_char(ATD.ActionDateTime,'YYYYMMDD')::date <= @ToDate "; }
            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,count(ATD.applicationNo) as Downloaded,AD.ServiceCode,ServiceName from applicationdetails AD inner join  applicationtrackingdetails  ATD on ATD.applicationNo=Ad.applicationNo inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where typevalueId=@typevalueId " + DateQry + " group by AD.ServiceCode,ServiceName ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@typevalueId", ((int)ValueId.DownloadCertificate));
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);

        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ServiceWiseDownloadAppReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("ServiceWiseDownloadAppReport", "Report", new { q = QueryString });
            }
            return View("ServiceWiseDownloadAppReport", model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult DayWiseVerifierReport()
        {
            ReportModels model = new ReportModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult DayWiseVerifierReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                StringBuilder Qry = new StringBuilder("select verifieruid,verifiername,designation,sum(col1) as col1,sum(col2) as col2,sum(col3) as col3,sum(col4) as col4 from (select verifieruid,verifiername,designation,case when pendingdays<11 then 1 else 0 end as col1,case when (pendingdays>10 and pendingdays<21) then 1 else 0 end as col2,case when (pendingdays>20 and pendingdays<31) then 1 else 0 end as col3 ,case when pendingdays>30 then 1 else 0 end as col4 from dstc.scheduledverifierstatus where 1=1");
                if (!string.IsNullOrEmpty(model.ApplicantDistrictCode)) { Qry.Append(" and districtcode=@districtcode"); }
                if (!string.IsNullOrEmpty(model.ApplicantSubDivCode)) { Qry.Append(" and subdivcode=@subdivcode"); }
                if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry.Append(" and ServiceCode=@ServiceCode"); } else { model.ServiceCode = ((int)CountList.Type000).ToString(); }
                Qry.Append(" ) rs group by verifieruid,verifiername,designation order by 1");
                NpgsqlCommand cmd = new NpgsqlCommand(Qry.ToString());
                cmd.Parameters.AddWithValue("@districtcode", model.ApplicantDistrictCode);
                cmd.Parameters.AddWithValue("@subdivcode", model.ApplicantSubDivCode);
                cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                model.data = data.GetDataTable(cmd);

                model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledverifierstatusData);
            }
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult DayWiseVerifierAppDetails(int Dis, int Sub, int Ser, int Typ, int Uid)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string QryStr = string.Empty;
            if (Typ == (int)CountList.Type001) { QryStr += " and SD.pendingdays<11"; }
            if (Typ == (int)CountList.Type002) { QryStr += " and SD.pendingdays>10 and SD.pendingdays<21"; }
            if (Typ == (int)CountList.Type003) { QryStr += " and SD.pendingdays>20 and SD.pendingdays<31"; }
            if (Typ == (int)CountList.Type004) { QryStr += " and SD.pendingdays>30"; }

            StringBuilder Qry = new StringBuilder("select AD.ServiceCode,AD.applicationsubdivcode,AD.ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName from dbo.ApplicationDetails AD left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode inner join dstc.scheduledverifierstatus SD on SD.applicationno=AD.applicationno where AD.applicationdistrictcode=@DistrictCode and AD.applicationsubdivcode=@SubDivCode and SD.verifieruid=@verifieruid");
            if (Ser != 0) { Qry.Append(" and AD.ServiceCode=@ServiceCode"); }
            Qry.Append(QryStr);
            Qry.Append(" order by ApplicationDate");
            NpgsqlCommand cmd = new NpgsqlCommand(Qry.ToString());
            cmd.Parameters.AddWithValue("@DistrictCode", Dis);
            cmd.Parameters.AddWithValue("@SubDivCode", Sub);
            cmd.Parameters.AddWithValue("@ServiceCode", Ser);
            cmd.Parameters.AddWithValue("@verifieruid", Uid);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }

        public ActionResult DuplicateMobileDetails()
        {
            ReportModels model = new ReportModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult DuplicateMobileDetails(ReportModels model)
        {
            GetData data = new GetData();
            string Qry = "select a.applicantmobileno,b.regcount,c.appcount,b.applicantdistrictcode,c.applicantdistrictcode from (select applicantmobileno from web.registrationmaster union select applicantmobileno from dbo.applicationdetails) a left outer join (select applicantmobileno,applicantdistrictcode,count(registrationid) as regcount from web.registrationmaster where applicantdistrictcode=@districtcode group by applicantmobileno,applicantdistrictcode having count(registrationid) >= @regcount) b on b.applicantmobileno=a.applicantmobileno left outer join (select applicantmobileno,applicantdistrictcode,count(applicationno) as appcount from dbo.applicationdetails where applicantdistrictcode=@districtcode group by applicantmobileno,applicantdistrictcode having count(applicationno) >= @appcount) c on c.applicantmobileno=a.applicantmobileno where b.regcount is not null and c.appcount is not null order by b.regcount,c.appcount";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@regcount", model.RegCount);
            cmd.Parameters.AddWithValue("@appcount", model.AppCount);
            cmd.Parameters.AddWithValue("@districtcode", model.ApplicantDistrictCode);
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult DuplicateMobileApplicationDetails(Int64 MobNo, string Flag, int Dist)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = string.Empty;
            model.Flag = Flag.ToString();
            if (Flag == CustomText.TRUE.ToString()) { Qry = "select b.registrationid,b.applicantname,b.applicantfathername,b.applicantmobileno,b.regcount,b.ApplicantAddress from (select registrationid,applicantname,applicantfathername,applicantmobileno,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantlocalityid,applicantsubdivcode,applicantdistrictcode,applicantstateid,applicantcountryid,applicantpincode) as ApplicantAddress,count(registrationid) as regcount from web.registrationmaster where applicantdistrictcode=@applicantdistrictcode group by applicantname,ApplicantAddress,applicantfathername,applicantmobileno,registrationid ) b where b.regcount is not null and b.applicantmobileno=@applicantmobileno order by b.applicantname"; }
            if (Flag == CustomText.FALSE.ToString()) { Qry = "select b.ApplicationNo,b.applicantname,b.ApplicationSourceId,b.ServiceName,b.applicantmobileno,b.ApplicantAddress,b.applicationdate from (select ApplicationNo,SM.ServiceName,ApplicationSourceId,applicantname,applicantmobileno,to_char(applicationdate,'dd/mm/yyyy') as applicationdate,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantlocalityid,applicantsubdivcode,applicantdistrictcode,stateid,countryid,applicantpincode) as ApplicantAddress,count(ApplicationNo) as appcount from dbo.applicationdetails AD  inner join dbo.servicemaster SM on SM.ServiceCode=AD.ServiceCode where applicantdistrictcode=@applicantdistrictcode group by applicantname,ApplicantAddress,applicantmobileno,ApplicationNo,SM.ServiceName,to_char(applicationdate,'dd/mm/yyyy')) b where b.appcount is not null and b.applicantmobileno=@applicantmobileno order by b.applicantname"; }
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@applicantmobileno", MobNo.ToString());
            Cmd.Parameters.AddWithValue("@applicantdistrictcode", Dist);
            model.data = data.GetDataTable(Cmd);
            return View(model);
        }

        [EncryptedActionParameter]
        public ActionResult IssuedCertificateReport()
        {
            ReportModels model = new ReportModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult IssuedCertificateReportPost(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                StringBuilder Qry = new StringBuilder("select AD.ApplicationNo,AD.ApplicantName,SR.ServiceCode,SR.ServiceName,DM.DistrictCode,DM.DistrictName,SM.SubdivCode,SM.SubdivDescription,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.signeddate,'DD/MM/YYYY') as SignedDate,(DATE_PART('day',(to_char(AD.signeddate,'YYYY/MM/DD')::timestamp)-(to_char(AD.ApplicationDate,'YYYY/MM/DD')::timestamp))+1)as DaysTaken from dstc.scheduledstaticdata AD inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode inner join dbo.DistrictMaster DM on DM.DistrictCode= AD.DistrictCode inner join SubdivMaster SM on SM.SubdivCode=AD.SubdivCode where AD.ApplicationStatusId  in(@ISSUCER)   and (select DATE_PART('day',(to_char(AD.signeddate,'YYYY/MM/DD')::timestamp)-(to_char(AD.ApplicationDate,'YYYY/MM/DD')::timestamp))+1 >= @DaysCountFrom) and (select DATE_PART('day',(to_char(AD.signeddate,'YYYY/MM/DD')::timestamp)-(to_char(AD.ApplicationDate,'YYYY/MM/DD')::timestamp))+1 <= @DaysCountTo)");
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry.Append(" and AD.DistrictCode in (@ParamDistrictCode)"); }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry.Append(" and AD.SubdivCode in (@ParamSubDivCode)"); }
                if (!string.IsNullOrEmpty(model.DistrictCode))
                {
                    Qry.Append(" and AD.DistrictCode=@districtcode");
                }
                if (!string.IsNullOrEmpty(model.ApplicationSubDivCode))
                {
                    Qry.Append(" and AD.SubdivCode=@SubDivCode");
                }
                if (!string.IsNullOrEmpty(model.ServiceCode))
                {
                    Qry.Append(" and AD.ServiceCode=@ServiceCode");
                }
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry.ToString()));
                cmd.Parameters.AddWithValue("@DaysCountFrom", model.DaysCountFrom);
                cmd.Parameters.AddWithValue("@DaysCountTo", model.DaysCountTo);
                cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { cmd.Parameters.AddWithValue("@SubDivCode", model.ApplicationSubDivCode); }
                if (!string.IsNullOrEmpty(model.DistrictCode)) { cmd.Parameters.AddWithValue("@districtcode", model.DistrictCode); }
                model.data = data.GetDataTable(cmd);

                model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            }
            return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DisposalPieReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select 7 as code,'Delhi' as name,coalesce(count(AD.ApplicationNo),0) TotalReceived,coalesce(sum(case when AD.applicationstatusid=@statusid then 1 end),0) as TotalDisposed,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays<1 then 1 end),0) as DisposedInTime,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>0 and AD.sladays<=10 then 1 end),0) as sla10days,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>10 and AD.sladays<=20 then 1 end),0) as sla20days,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>20 then 1 end),0) as sla30days from (select applicationno,AD.ApplicationStatusId,DM.DistrictCode,DM.DistrictName,SDM.subdivcode,SDM.SubDivDescription,SM.oldprocessingdays,SM.processingdays,DATE_PART('day',AD.signeddate-AD.applicationdate) as diifdays,DATE_PART('day',AD.signeddate-AD.applicationdate)-(case when AD.applicationdate<'2015-12-01' then SM.oldprocessingdays else SM.processingdays end) as sladays from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode inner join SubDivMaster SDM on SDM.SubDivCode=AD.SubDivCode where DM.deptcode=@ParamDeptCode) AD";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@statusid", ((int)Status.ISSUCER));
            if (!string.IsNullOrEmpty(model.ServiceCode)) { Cmd.Parameters.AddWithValue("@servicecode", model.ServiceCode); }
            model.data = data.GetDataTable(Cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult DisposalPieReport(ReportModels model)
        {
            GetData data = new GetData();
            string whethercondition = string.Empty;
            if (ModelState.IsValid)
            {
                string Qry = "select 7 as code,'Delhi' as name,coalesce(count(AD.ApplicationNo),0) TotalReceived,coalesce(sum(case when AD.applicationstatusid=@statusid then 1 end),0) as TotalDisposed,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays<1 then 1 end),0) as DisposedInTime,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>0 and AD.sladays<=10 then 1 end),0) as sla10days,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>10 and AD.sladays<=20 then 1 end),0) as sla20days,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>20 then 1 end),0) as sla30days from (select applicationno,AD.ApplicationStatusId,DM.DistrictCode,DM.DistrictName,SDM.subdivcode,SDM.SubDivDescription,SM.oldprocessingdays,SM.processingdays,DATE_PART('day',AD.signeddate-AD.applicationdate) as diifdays,DATE_PART('day',AD.signeddate-AD.applicationdate)-(case when AD.applicationdate<'2015-12-01' then SM.oldprocessingdays else SM.processingdays end) as sladays from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode inner join SubDivMaster SDM on SDM.SubDivCode=AD.SubDivCode where DM.deptcode=@ParamDeptCode";
                if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry = Qry + " and AD.servicecode=@servicecode "; }
                Qry = Qry + " ) AD";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@statusid", ((int)Status.ISSUCER));
                if (!string.IsNullOrEmpty(model.ServiceCode)) { Cmd.Parameters.AddWithValue("@servicecode", model.ServiceCode); }
                model.data = data.GetDataTable(Cmd);

                if (Convert.ToInt32(model.DistrictCode) != 0) { whethercondition = whethercondition + " and AD.DistrictCode=@ApplicationDistrictCode "; }
                if (!string.IsNullOrEmpty(model.DistrictCode))
                {
                    Qry = @"select DistrictCode as code,DistrictName as name,coalesce(count(AD.ApplicationNo),0) TotalReceived,coalesce(sum(case when AD.applicationstatusid=@statusid then 1 end),0) as TotalDisposed,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays<1 then 1 end),0) as DisposedInTime,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>0 and AD.sladays<=10 then 1 end),0) as sla10days,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>10 and AD.sladays<=20 then 1 end),0) as sla20days,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>20 then 1 end),0) as sla30days from (select applicationno,AD.ApplicationStatusId,DM.DistrictCode,DM.DistrictName,SDM.subdivcode,SDM.SubDivDescription,SM.oldprocessingdays,SM.processingdays,DATE_PART('day',AD.signeddate-AD.applicationdate) as diifdays,DATE_PART('day',AD.signeddate-AD.applicationdate)-(case when AD.applicationdate<'2015-12-01' then SM.oldprocessingdays else SM.processingdays end) as sladays from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode inner join SubDivMaster SDM on SDM.SubDivCode=AD.SubDivCode where DM.deptcode=@ParamDeptCode";
                    if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry = Qry + " and AD.servicecode=@servicecode "; }
                    if (!string.IsNullOrEmpty(model.DistrictCode)) { Qry = Qry + " and AD.DistrictCode=@DistrictCode "; }
                    Qry += " ) AD group by code,name order by name";
                    Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    Cmd.Parameters.AddWithValue("@statusid", ((int)Status.ISSUCER));
                    if (!string.IsNullOrEmpty(model.ServiceCode)) { Cmd.Parameters.AddWithValue("@servicecode", model.ServiceCode); }
                    if (!string.IsNullOrEmpty(model.DistrictCode)) { Cmd.Parameters.AddWithValue("@DistrictCode", model.DistrictCode); }
                    model.dataS = data.GetDataTable(Cmd);

                    Qry = @"select SubDivCode as code,SubDivDescription as name,coalesce(count(AD.ApplicationNo),0) TotalReceived,coalesce(sum(case when AD.applicationstatusid=@statusid then 1 end),0) as TotalDisposed,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays<1 then 1 end),0) as DisposedInTime,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>0 and AD.sladays<=10 then 1 end),0) as sla10days,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>10 and AD.sladays<=20 then 1 end),0) as sla20days,coalesce(sum(case when AD.applicationstatusid=@statusid and AD.sladays>20 then 1 end),0) as sla30days from (select applicationno,AD.ApplicationStatusId,DM.DistrictCode,DM.DistrictName,SDM.subdivcode,SDM.SubDivDescription,SM.oldprocessingdays,SM.processingdays,DATE_PART('day',AD.signeddate-AD.applicationdate) as diifdays,DATE_PART('day',AD.signeddate-AD.applicationdate)-(case when AD.applicationdate<'2015-12-01' then SM.oldprocessingdays else SM.processingdays end) as sladays from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode inner join SubDivMaster SDM on SDM.SubDivCode=AD.SubDivCode where DM.deptcode=@ParamDeptCode";
                    if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry = Qry + " and AD.servicecode=@servicecode "; }
                    if (!string.IsNullOrEmpty(model.DistrictCode)) { Qry = Qry + " and AD.DistrictCode=@DistrictCode "; }
                    Qry += " ) AD group by code,name order by name";
                    Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    Cmd.Parameters.AddWithValue("@statusid", ((int)Status.ISSUCER));
                    if (!string.IsNullOrEmpty(model.ServiceCode)) { Cmd.Parameters.AddWithValue("@servicecode", model.ServiceCode); }
                    if (!string.IsNullOrEmpty(model.DistrictCode)) { Cmd.Parameters.AddWithValue("@DistrictCode", model.DistrictCode); }
                    model.dataa = data.GetDataTable(Cmd);

                }
                if (model.dataS != null)
                {
                    foreach (DataRow dr in model.dataS.Rows)
                    {
                        model.data.Rows.Add(dr.ItemArray);
                    }
                }
                if (model.dataa != null)
                {
                    foreach (DataRow dr in model.dataa.Rows)
                    {
                        model.data.Rows.Add(dr.ItemArray);
                    }
                }

                model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            }
            return View(model);
        }

        [HttpGet]
        public ActionResult PendingAppPieReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = @"SELECT 7 as code,'Delhi' as name,coalesce(count(AD.ApplicationNo),0) TotalReceived,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) then 1 end),0) as TotalPending,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid in (@GreenZone,@YellowZone,@RedZone) then 1 end),0) as Pendingintime,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays <= 10 then 1 else 0 end) as sla10days,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays >10 and AD.sladays <= 20 then 1 else 0 end) as sla20days,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays >20 then 1 else 0 end) as sla30days from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode inner join SubDivMaster SDM on SDM.SubDivCode=AD.SubDivCode where DM.deptcode=@ParamDeptCode group by code,name order by name";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@CANCEL", ((int)Status.CANCEL));
            Cmd.Parameters.AddWithValue("@TEHSREJ", ((int)Status.TEHSREJ));
            Cmd.Parameters.AddWithValue("@ISSUCER", ((int)Status.ISSUCER));
            Cmd.Parameters.AddWithValue("@GreenZone", ((int)ValueId.GreenZone));
            Cmd.Parameters.AddWithValue("@YellowZone", ((int)ValueId.YellowZone));
            Cmd.Parameters.AddWithValue("@RedZone", ((int)ValueId.RedZone));
            model.data = data.GetDataTable(Cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingAppPieReport(ReportModels model)
        {
            GetData data = new GetData();
            string whethercondition = string.Empty;
            if (ModelState.IsValid)
            {
                string Qry = "SELECT 7 as code,'Delhi' as name,coalesce(count(AD.ApplicationNo),0) TotalReceived,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) then 1 end),0) as TotalPending,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid in (@GreenZone,@YellowZone,@RedZone) then 1 end),0) as Pendingintime,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays <= 10 then 1 else 0 end) as sla10days,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays >10 and AD.sladays <= 20 then 1 else 0 end) as sla20days,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays >20 then 1 else 0 end) as sla30days from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode inner join SubDivMaster SDM on SDM.SubDivCode=AD.SubDivCode where DM.deptcode=@ParamDeptCode";
                if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry = Qry + " and AD.servicecode=@servicecode "; }
                Qry = Qry + " group by code,name order by name";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@CANCEL", ((int)Status.CANCEL));
                Cmd.Parameters.AddWithValue("@TEHSREJ", ((int)Status.TEHSREJ));
                Cmd.Parameters.AddWithValue("@ISSUCER", ((int)Status.ISSUCER));
                Cmd.Parameters.AddWithValue("@GreenZone", ((int)ValueId.GreenZone));
                Cmd.Parameters.AddWithValue("@YellowZone", ((int)ValueId.YellowZone));
                Cmd.Parameters.AddWithValue("@RedZone", ((int)ValueId.RedZone));
                if (!string.IsNullOrEmpty(model.ServiceCode)) { Cmd.Parameters.AddWithValue("@servicecode", model.ServiceCode); }
                model.data = data.GetDataTable(Cmd);

                if (Convert.ToInt32(model.DistrictCode) != 0) { whethercondition = whethercondition + " and AD.DistrictCode=@ApplicationDistrictCode "; }
                if (!string.IsNullOrEmpty(model.DistrictCode))
                {
                    Qry = @"select AD.DistrictCode as code,DistrictName as name,coalesce(count(AD.ApplicationNo),0) TotalReceived,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) then 1 end),0) as TotalPending,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid in (@GreenZone,@YellowZone,@RedZone) then 1 end),0) as Pendingintime,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays <= 10 then 1 else 0 end) as sla10days,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays >10 and AD.sladays <= 20 then 1 else 0 end) as sla20days,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays >20 then 1 else 0 end) as sla30days from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode inner join SubDivMaster SDM on SDM.SubDivCode=AD.SubDivCode where DM.deptcode=@ParamDeptCode";
                    if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry = Qry + " and AD.servicecode=@servicecode "; }
                    if (!string.IsNullOrEmpty(model.DistrictCode)) { Qry = Qry + " and AD.DistrictCode=@DistrictCode "; }
                    Qry += " group by code,name order by name";
                    Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    Cmd.Parameters.AddWithValue("@CANCEL", ((int)Status.CANCEL));
                    Cmd.Parameters.AddWithValue("@TEHSREJ", ((int)Status.TEHSREJ));
                    Cmd.Parameters.AddWithValue("@ISSUCER", ((int)Status.ISSUCER));
                    Cmd.Parameters.AddWithValue("@GreenZone", ((int)ValueId.GreenZone));
                    Cmd.Parameters.AddWithValue("@YellowZone", ((int)ValueId.YellowZone));
                    Cmd.Parameters.AddWithValue("@RedZone", ((int)ValueId.RedZone));
                    if (!string.IsNullOrEmpty(model.ServiceCode)) { Cmd.Parameters.AddWithValue("@servicecode", model.ServiceCode); }
                    if (!string.IsNullOrEmpty(model.DistrictCode)) { Cmd.Parameters.AddWithValue("@DistrictCode", model.DistrictCode); }
                    model.dataS = data.GetDataTable(Cmd);

                    Qry = @"select AD.SubDivCode as code,SubDivDescription as name,coalesce(count(AD.ApplicationNo),0) TotalReceived,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) then 1 end),0) as TotalPending,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid in (@GreenZone,@YellowZone,@RedZone) then 1 end),0) as Pendingintime,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays <= 10 then 1 else 0 end) as sla10days,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays >10 and AD.sladays <= 20 then 1 else 0 end) as sla20days,sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) and AD.valueid=81 and AD.sladays >20 then 1 else 0 end) as sla30days from dstc.scheduledstaticdata AD right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode inner join SubDivMaster SDM on SDM.SubDivCode=AD.SubDivCode where DM.deptcode=@ParamDeptCode";
                    if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry = Qry + " and AD.servicecode=@servicecode "; }
                    if (!string.IsNullOrEmpty(model.DistrictCode)) { Qry = Qry + " and AD.DistrictCode=@DistrictCode "; }
                    Qry += " group by code,name order by name";
                    Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    Cmd.Parameters.AddWithValue("@CANCEL", ((int)Status.CANCEL));
                    Cmd.Parameters.AddWithValue("@TEHSREJ", ((int)Status.TEHSREJ));
                    Cmd.Parameters.AddWithValue("@ISSUCER", ((int)Status.ISSUCER));
                    Cmd.Parameters.AddWithValue("@GreenZone", ((int)ValueId.GreenZone));
                    Cmd.Parameters.AddWithValue("@YellowZone", ((int)ValueId.YellowZone));
                    Cmd.Parameters.AddWithValue("@RedZone", ((int)ValueId.RedZone));
                    if (!string.IsNullOrEmpty(model.ServiceCode)) { Cmd.Parameters.AddWithValue("@servicecode", model.ServiceCode); }
                    if (!string.IsNullOrEmpty(model.DistrictCode)) { Cmd.Parameters.AddWithValue("@DistrictCode", model.DistrictCode); }
                    model.dataa = data.GetDataTable(Cmd);

                }
                if (model.dataS != null)
                {
                    foreach (DataRow dr in model.dataS.Rows)
                    {
                        model.data.Rows.Add(dr.ItemArray);
                    }
                }
                if (model.dataa != null)
                {
                    foreach (DataRow dr in model.dataa.Rows)
                    {
                        model.data.Rows.Add(dr.ItemArray);
                    }
                }
                model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            }
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DisposalBarReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whethercondition = string.Empty;
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DeptCode)) { whethercondition = whethercondition + " and SM.Deptcode=@Deptcode"; }
            string Qry = @"select * from (select a.ApplicationDateMonth,upper(to_char(to_timestamp (a.ApplicationDateMonth::text, 'MM'), 'TMmon')) as ShortMonth, a.TotalReceived,b.TotalDisposed from (select Extract(month from AD.ApplicationDate)as ApplicationDateMonth, coalesce(count(ApplicationNo),0) TotalReceived from dstc.ScheduledStaticData AD inner join Servicemaster SM on SM.Servicecode=AD.serviceCode inner join Deptmaster DM on DM.Deptcode=SM.deptcode  where 1=1  group by Extract(month from AD.ApplicationDate),Extract(year from AD.ApplicationDate) order by Extract(year from AD.ApplicationDate) desc,Extract(month from AD.ApplicationDate) desc limit 4)a
                            inner join 
                            (SELECT Extract(month from AD.LastActionDate)as ApplicationDateMonth,coalesce(count(AD.ApplicationNo),0)  TotalDisposed
                            from dstc.ScheduledStaticData AD where ApplicationStatusId in (@ApplicationStatusId,@ApplicationStatusId1,@ApplicationStatusId2) ";
            Qry = Qry + " group by Extract(month from AD.LastActionDate),Extract(year from AD.LastActionDate) order by Extract(year from AD.LastActionDate) desc,Extract(month from AD.LastActionDate) desc limit 4)b on a.ApplicationDateMonth=b.ApplicationDateMonth) rs order by 1";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationStatusId", ((int)Status.ISSUCER));
            Cmd.Parameters.AddWithValue("@ApplicationStatusId1", ((int)Status.CANCEL));
            Cmd.Parameters.AddWithValue("@ApplicationStatusId2", ((int)Status.TEHSREJ));
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DeptCode)) { Cmd.Parameters.AddWithValue("@Deptcode", Convert.ToInt32(Sessions.getEmployeeUser().DeptCode)); }
            model.data = data.GetDataTable(Cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DisposalBarReport(ReportModels model)
        {
            GetData data = new GetData();
            string whethercondition = string.Empty;
            if (ModelState.IsValid)
            {
                if (Convert.ToInt32(model.ServiceCode) != 0) { whethercondition = " and AD.ServiceCode=@ServiceCode "; }
                if (Convert.ToInt32(model.DistrictCode) != 0) { whethercondition = whethercondition + " and AD.DistrictCode=@ApplicationDistrictCode "; }
                if (Convert.ToInt32(model.ApplicationSubDivCode) != 0) { whethercondition = whethercondition + " and AD.SubDivCode=@ApplicationSubDivCode "; }
                string Qry = @"select * from (select a.ApplicationDateMonth,upper(to_char(to_timestamp (a.ApplicationDateMonth::text, 'MM'), 'TMmon')) as ShortMonth, a.TotalReceived,b.TotalDisposed from (select Extract(month from AD.ApplicationDate)as ApplicationDateMonth, coalesce(count(ApplicationNo),0) TotalReceived from dstc.ScheduledStaticData AD inner join Servicemaster SM on SM.Servicecode=AD.serviceCode inner join Deptmaster DM on DM.Deptcode=SM.deptcode  where 1=1 " + whethercondition + @" group by Extract(month from AD.ApplicationDate),Extract(year from AD.ApplicationDate) order by Extract(year from AD.ApplicationDate) desc,Extract(month from AD.ApplicationDate) desc limit 4)a
                               inner join 
                            (SELECT Extract(month from AD.LastActionDate)as ApplicationDateMonth,coalesce(count(AD.ApplicationNo),0)  TotalDisposed
                            from dstc.ScheduledStaticData AD where ApplicationStatusId in (@ApplicationStatusId,@ApplicationStatusId1,@ApplicationStatusId2) " + whethercondition + @"";
                Qry = Qry + " group by Extract(month from AD.LastActionDate),Extract(year from AD.LastActionDate) order by Extract(year from AD.LastActionDate) desc,Extract(month from AD.LastActionDate) desc limit 4)b on a.ApplicationDateMonth=b.ApplicationDateMonth) rs order by 1";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", ((int)Status.ISSUCER));
                Cmd.Parameters.AddWithValue("@ApplicationStatusId1", ((int)Status.CANCEL));
                Cmd.Parameters.AddWithValue("@ApplicationStatusId2", ((int)Status.TEHSREJ));
                Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                Cmd.Parameters.AddWithValue("@ApplicationDistrictCode", model.DistrictCode);
                Cmd.Parameters.AddWithValue("@ApplicationSubDivCode", model.ApplicationSubDivCode);
                model.data = data.GetDataTable(Cmd);

                model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            }
            return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ReportOperatorWiseReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ReportOperatorWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string whereCondition = string.Empty;
                string Qry = @"select  to_char(ActionDate,'DD/MM/YYYY') as ActDate,ApplicationDistrictCode,ApplicationSubDivCode,Permission,ActionBy,coalesce(sum(case when ActionmessageId=@MSG007 then 1 end),0) BasicDetails,coalesce(sum(case when ActionmessageId=@MSG014 then 1 end),0) serviceSpecificDetails,coalesce(sum(case when ActionmessageId=@MSG015 then 1 end),0) encloserAttached from DepartmentAuditTrail  DAT inner join ApplicationDetails AD on AD.ApplicationNO=DAT.ApplicationNO inner join UserMaster UM on UM.Userid=DAT.ActionBy where AD.ApplicationDistrictCode=@ApplicationDistrictCode and AD.ApplicationSubDivCode=@ApplicationSubDivCode and UM.Permission=@Permission and DAT.ActionBy=@ActionBy  and to_char(ActionDate,'YYYYMMDD')::date=@ActionDate group by to_char(ActionDate,'DD/MM/YYYY') , ApplicationDistrictCode,ApplicationSubDivCode,Permission,ActionBy";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ActionDate", Utility.ConvertDateSequenceForDatabase(model.ActionDate, '/', true));
                cmd.Parameters.AddWithValue("@ApplicationDistrictCode", model.ApplicantDistrictCode);
                cmd.Parameters.AddWithValue("@ApplicationSubDivCode", model.ApplicantSubDivCode);
                cmd.Parameters.AddWithValue("@Permission", model.Pcode);
                cmd.Parameters.AddWithValue("@ActionBy", model.UserId);
                cmd.Parameters.AddWithValue("@MSG007", (int)ApplicationHistoryMessage.MSG007);
                cmd.Parameters.AddWithValue("@MSG014", (int)ApplicationHistoryMessage.MSG014);
                cmd.Parameters.AddWithValue("@MSG015", (int)ApplicationHistoryMessage.MSG015);
                model.data = data.GetDataTable(cmd);
            }
            return View("ReportOperatorWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult OperatorWiseApplicationDetailsReport(int ActionMesageId, string ActionDate, int DistCode, int SubDivCode, int Pcode, string Uid, int? PageIndex = 1)
        {
            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "ActionMesageId=" + ActionMesageId.ToString());
            Parameters.Add(1, "ActionDate=" + ActionDate.ToString());
            Parameters.Add(2, "DistCode=" + DistCode.ToString());
            Parameters.Add(3, "SubDivCode=" + SubDivCode.ToString());
            Parameters.Add(4, "Pcode=" + Pcode.ToString());
            Parameters.Add(5, "Uid=" + Uid.ToString());
            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                GetData data = new GetData();

                string Qry = "select AD.ServiceCode,AD.applicationsubdivcode,SM.SubDivDescription,DM.DistrictCode,DM.DistrictName,AD.ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,to_char(ActionDate,'DD/MM/YYYY') as ActionDate from dbo.ApplicationDetails AD inner join DepartmentAuditTrail  DAT on DAT.ApplicationNo=AD.ApplicationNo inner join UserMaster UM on UM.Userid=DAT.ActionBy left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode where AD.ApplicationDistrictCode=@ApplicationDistrictCode and AD.ApplicationSubDivCode=@ApplicationSubDivCode and UM.Permission=@Permission and DAT.ActionBy=@ActionBy and to_char(ActionDate,'YYYYMMDD')::date=@ActionDate and ActionMessageId=@ActionMessageId order by ApplicantName";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@ApplicationDistrictCode", DistCode);
                cmd.Parameters.AddWithValue("@ApplicationSubDivCode", SubDivCode);
                cmd.Parameters.AddWithValue("@Permission", Pcode.ToString());
                cmd.Parameters.AddWithValue("@ActionBy", Uid);
                cmd.Parameters.AddWithValue("@ActionDate", Utility.ConvertDateSequenceForDatabase(ActionDate, '/', true));
                cmd.Parameters.AddWithValue("@ActionMessageId", ActionMesageId);
                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "ApplicationDetailsReport", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "ApplicationDetailsReport", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View(model);
        }




        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult DocumentwiseRegistrationReport()
        {
            ReportModels model = new ReportModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult DocumentwiseRegistrationReport(ReportModels model)
        {
            GetData data = new GetData();
            string Qry = "select RM.documentid,DC.documentname,coalesce(count(RegistrationId),0) Registered from web.registrationmaster RM  inner join dbo.documentmaster DC on DC.documentid=RM.documentid right outer join dbo.DistrictMaster DM on RM.applicantdistrictcode=DM.DistrictCode inner join dbo.SubdivMaster SM on SM.SubdivCode=RM.applicantsubdivcode where DM.deptcode=@ParamDeptCode and DM.DistrictCode=@DistrictCode and SM.SubdivCode=@SubdivCode group by RM.documentid,DC.documentname";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DistrictCode", model.ApplicantDistrictCode);
            cmd.Parameters.AddWithValue("@SubDivCode", model.ApplicantSubDivCode);
            model.data = data.GetDataTable(cmd);

            model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult InspectionMISReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select to_char(AI.inspectiondate,'DD/MM/YYYY') as inspectiondate,coalesce(sum(case when whetherinspected=true then 1 end),0) as Completed,coalesce(sum(case when whetherinspected=false then 1 end),0) as Pending from dgen.applicationinspectiondetails AI group by AI.inspectiondate";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult InspectionApplicationDetails(string idate, int type)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select AI.InspectionId,AI.cid,AD.applicationno,AD.servicecode,AD.applicationstatusid,AC.cinemaname,AC.cinemaaddress,AC.noofscreens,to_char(AI.inspectiondate,'DD/MM/YYYY') as inspectiondate,AI.officername,AI.officercontactno,AI.whetheractive,AI.whetherinspected from dgen.applicationinspectiondetails AI left outer join applicationdetails AD on AI.applicationno=AD.applicationno left outer join dgen.applicationdetailscinematograph AC on AC.applicationno=AD.applicationno where AD.servicecode in (@Pro,@Renew,@Fresh) and AI.InspectionDate=@InspectionDate and WhetherInspected=@WhetherInspected union all select a.InspectionId,a.cid,a.applicationno,null as servicecode,null as applicationstatusid,b.cinemaname,b.cinemaaddress,1 as noofscreens,to_char(a.inspectiondate,'DD/MM/YYYY') as inspectiondate,a.officername,a.officercontactno,a.whetheractive,a.whetherinspected  from dgen.applicationinspectiondetails a inner join dgen.ApplicationDetailsExistingCinema b on b.cid=a.cid and a.InspectionDate=@InspectionDate and a.WhetherInspected=@WhetherInspected";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            if (type == (int)CountList.Type001) { cmd.Parameters.AddWithValue("@WhetherInspected", CustomText.True.ToString()); }
            else if (type == (int)CountList.Type002) { cmd.Parameters.AddWithValue("@WhetherInspected", CustomText.False.ToString()); }
            cmd.Parameters.AddWithValue("@InspectionDate", Utility.GetDateYYYYMMDD(idate, '/', "0/1/2"));
            cmd.Parameters.AddWithValue("@Pro", (int)ServiceList.ProvisionalCinema);
            cmd.Parameters.AddWithValue("@Renew", (int)ServiceList.RenewalCinemaLicense);
            cmd.Parameters.AddWithValue("@Fresh", (int)ServiceList.FreshCinemaLicense);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DeptAuditTrailReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
            model.DistrictCode = Sessions.getEmployeeUser().DistrictCode;
            model.ApplicationSubDivCode = Sessions.getEmployeeUser().SubDivCode;
            string Qry = @"select Count(distinct AD.ApplicationNo),AD.ServiceCode,ServiceName from departmentaudittrail DAT inner join ApplicationDetails AD on AD.ApplicationNo=DAT.ApplicationNo inner join UserMaster UM on UM.UserId=DAT.ActionBy inner join applicationsourcemaster ASM on ASM.ApplicationSourceId=DAT.ActionSourceId  inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where 1=1  ";
            if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(model.DistrictCode)) { Qry += " and AD.ApplicationDistrictCode in (@ParamDistrictCode)"; }
            if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
            Qry = Qry + " group by AD.ServiceCode,ServiceName order by ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DeptAuditTrailReport(ReportModels model)
        {
            GetData data = new GetData();
            string whethercondition = string.Empty;
            if (ModelState.IsValid)
            {
                model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;

                if (!string.IsNullOrEmpty(model.ActionDate)) { whethercondition = whethercondition + " and to_char(DAT.ActionDate,'YYYYMMDD')::date = @ActionDate"; }
                if (Convert.ToInt32(model.ActionSourceId) != 0) { whethercondition = whethercondition + " and DAT.ActionSourceId=@ActionSourceId "; }
                if (Convert.ToInt32(model.ApplicantDistrictCode) != 0) { whethercondition = whethercondition + " and AD.ApplicationDistrictCode=@ApplicationDistrictCode "; }
                if (Convert.ToInt32(model.ApplicantSubDivCode) != 0) { whethercondition = whethercondition + " and AD.ApplicationSubDivCode=@ApplicationSubDivCode "; }
                if (Convert.ToInt32(model.PermissionCode) != 0) { whethercondition = whethercondition + " and UM.Permission=@Permission "; }
                if (!string.IsNullOrEmpty(model.CSCUserId)) { whethercondition = whethercondition + " and DAT.ActionBy=@ActionBy "; }
                if (!string.IsNullOrEmpty(model.ServiceCode)) { whethercondition = whethercondition + " and AD.ServiceCode in (@ParamServiceCode)"; }

                string Qry = @"select Count(distinct AD.ApplicationNo),AD.ServiceCode,ServiceName from departmentaudittrail DAT inner join ApplicationDetails AD on AD.ApplicationNo=DAT.ApplicationNo inner join UserMaster UM on UM.UserId=DAT.ActionBy inner join applicationsourcemaster ASM on ASM.ApplicationSourceId=DAT.ActionSourceId  inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where 1=1 " + whethercondition + @"";
                Qry = Qry + " group by AD.ServiceCode,ServiceName order by ServiceName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@ActionDate", Utility.ConvertDateSequenceForDatabase(model.ActionDate, '/', true));
                Cmd.Parameters.AddWithValue("@ActionSourceId", model.ActionSourceId);
                Cmd.Parameters.AddWithValue("@ApplicationDistrictCode", model.ApplicantDistrictCode);
                Cmd.Parameters.AddWithValue("@ApplicationSubDivCode", model.ApplicantSubDivCode);
                Cmd.Parameters.AddWithValue("@Permission", model.PermissionCode);
                Cmd.Parameters.AddWithValue("@ActionBy", model.CSCUserId);
                model.data = data.GetDataTable(Cmd);

            }
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult DeptAuditBasicApplicationDetails(int Servicode, string ActionDate, string Uid, int? Pcode, int? DistCode, int? ActionType, int? SubDivCode, int? PageIndex = 1)
        {
            //if (subDiv == null && service == null && status == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }
            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "Servicode=" + Servicode.ToString());
            if (!string.IsNullOrEmpty(ActionDate)) { Parameters.Add(1, "ActionDate=" + ActionDate.ToString()); }
            if (!string.IsNullOrEmpty(Pcode.ToString())) { Parameters.Add(2, "Pcode=" + Pcode.ToString()); }
            if (!string.IsNullOrEmpty(Uid)) { Parameters.Add(3, "Uid=" + Uid.ToString()); }
            if (!string.IsNullOrEmpty(DistCode.ToString())) { Parameters.Add(4, "DistCode=" + DistCode.ToString()); }
            if (!string.IsNullOrEmpty(ActionType.ToString())) { Parameters.Add(5, "ActionType=" + ActionType.ToString()); }
            if (!string.IsNullOrEmpty(SubDivCode.ToString())) { Parameters.Add(6, "SubDivCode=" + SubDivCode.ToString()); }


            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                string statusId = string.Empty;
                GetData data = new GetData();

                string Qry = "select distinct AD.ServiceCode,AD.applicationsubdivcode,SM.SubDivDescription,DM.DistrictCode,DM.DistrictName,AD.ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName from dbo.ApplicationDetails AD inner join departmentaudittrail DAT on DAT.ApplicationNo=AD.ApplicationNo inner join UserMaster UM on UM.UserId=DAT.ActionBy inner join applicationsourcemaster ASM on ASM.ApplicationSourceId=DAT.ActionSourceId  left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode where AD.ServiceCode=@ServiceCode   ";

                if (!string.IsNullOrEmpty(ActionDate)) { Qry += " and to_char(DAT.ActionDate,'YYYYMMDD')::date = @ActionDate"; }
                if (!string.IsNullOrEmpty(DistCode.ToString())) { Qry += " and AD.ApplicationDistrictCode=@ApplicationDistrictCode "; }
                if (!string.IsNullOrEmpty(ActionType.ToString())) { Qry += " and DAT.ActionSourceId=@ActionSourceId"; }
                if (!string.IsNullOrEmpty(SubDivCode.ToString())) { Qry += " and AD.applicationsubdivcode=@applicationsubdivcode"; }

                if (!string.IsNullOrEmpty(Pcode.ToString())) { Qry += " and UM.Permission=@Permission"; }
                if (!string.IsNullOrEmpty(Uid)) { Qry += "  and DAT.ActionBy=@ActionBy "; }
                Qry += " order by ApplicationDate";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@ServiceCode", Servicode);
                cmd.Parameters.AddWithValue("@applicationsubdivcode", SubDivCode);
                cmd.Parameters.AddWithValue("@ApplicationDistrictCode", DistCode);
                cmd.Parameters.AddWithValue("@ActionBy", Uid);
                cmd.Parameters.AddWithValue("@ActionSourceId", ActionType);
                cmd.Parameters.AddWithValue("@Permission", Pcode.ToString());
                cmd.Parameters.AddWithValue("@ActionDate", Utility.ConvertDateSequenceForDatabase(ActionDate, '/', true));

                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "DeptAuditBasicApplicationDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "DeptAuditBasicApplicationDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult BasicDistWiseTrainingReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select count(AD.ApplicationNo) TotalReceived, coalesce(sum(case when VenueId is not null then 1 end),0)as TrainingAllocated,coalesce(sum(case when WhetherTrainingCompleted=True then 1 end),0)as TrainingCompleted  from ApplicationDetails AD inner join dgen.ApplicationDetailsCDV ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo left Outer join dgen.CDVTrainingSessions CDVTS on CDVTS.ApplicationNo=AD.ApplicationNo Inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode where DM.deptcode=@ParamDeptCode";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult TechEducationWiseReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select Count(AD.ApplicationNO) as total,TechnicalEducationId,ValueName from dgen.applicationdetailscdv ADCDV inner join applicationdetails  AD on AD.ApplicationNO=ADCDV.ApplicationNO inner join dgen.cdvtrainingsessions  CDV on AD.ApplicationNO=CDV.ApplicationNO Right Outer join ApplicationTechnicalEducationDetail ATEM on ATEM.ApplicationNo=AD.ApplicationNo Right Outer join SelectMasterValueDetails SMVD on SMVD.Valueid=ATEM.TechnicalEducationId where ApplicationStatusId=@TEHSREC and WhetherTrainingAllocated=@WhetherTrainingAllocated and WhetherTrainingCompleted=@WhetherTrainingCompleted  group by TechnicalEducationId,ValueName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@WhetherTrainingAllocated", CustomText.TRUE.ToString());
            cmd.Parameters.AddWithValue("@WhetherTrainingCompleted", CustomText.TRUE.ToString());
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult TechEducationWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = "select Count(AD.ApplicationNO) as total,TechnicalEducationId,ValueName from dgen.applicationdetailscdv ADCDV inner join applicationdetails  AD on AD.ApplicationNO=ADCDV.ApplicationNO inner join dgen.cdvtrainingsessions  CDV on AD.ApplicationNO=CDV.ApplicationNO Right Outer join ApplicationTechnicalEducationDetail ATEM on ATEM.ApplicationNo=AD.ApplicationNo Right Outer join SelectMasterValueDetails SMVD on SMVD.Valueid=ATEM.TechnicalEducationId where ApplicationStatusId=@TEHSREC and WhetherTrainingAllocated=@WhetherTrainingAllocated and WhetherTrainingCompleted=@WhetherTrainingCompleted and ApplicationDistrictCode=@ApplicationDistrictCode and ApplicationSubDivCode=@ApplicationSubDivCode group by TechnicalEducationId,ValueName";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
                cmd.Parameters.AddWithValue("@ApplicationDistrictCode", model.ApplicantDistrictCode);
                cmd.Parameters.AddWithValue("@ApplicationSubDivCode", model.ApplicantSubDivCode);
                cmd.Parameters.AddWithValue("@WhetherTrainingAllocated", CustomText.TRUE.ToString());
                cmd.Parameters.AddWithValue("@WhetherTrainingCompleted", CustomText.TRUE.ToString());
                model.data = data.GetDataTable(cmd);
            }
            return View("TechEducationWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult EducationWiseReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select Count(AD.ApplicationNO) as total,EQualificationId,ValueName from dgen.applicationdetailscdv ADCDV inner join applicationdetails  AD on AD.ApplicationNO=ADCDV.ApplicationNO inner join dgen.cdvtrainingsessions  CDV on AD.ApplicationNO=CDV.ApplicationNO Right Outer join SelectMasterValueDetails SMVD on SMVD.Valueid=ADCDV.EQualificationId where ApplicationStatusId=@TEHSREC and WhetherTrainingAllocated=@WhetherTrainingAllocated and WhetherTrainingCompleted=@WhetherTrainingCompleted group by EQualificationId,ValueName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@WhetherTrainingAllocated", CustomText.TRUE.ToString());
            cmd.Parameters.AddWithValue("@WhetherTrainingCompleted", CustomText.TRUE.ToString());
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult EducationWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = "select Count(AD.ApplicationNO) as total,EQualificationId,ValueName from dgen.applicationdetailscdv ADCDV inner join applicationdetails  AD on AD.ApplicationNO=ADCDV.ApplicationNO inner join dgen.cdvtrainingsessions  CDV on AD.ApplicationNO=CDV.ApplicationNO Right Outer join SelectMasterValueDetails SMVD on SMVD.Valueid=ADCDV.EQualificationId where ApplicationStatusId=@TEHSREC and WhetherTrainingAllocated=@WhetherTrainingAllocated and WhetherTrainingCompleted=@WhetherTrainingCompleted and ApplicationDistrictCode=@ApplicationDistrictCode and ApplicationSubDivCode=@ApplicationSubDivCode group by EQualificationId,ValueName";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
                cmd.Parameters.AddWithValue("@ApplicationDistrictCode", model.ApplicantDistrictCode);
                cmd.Parameters.AddWithValue("@ApplicationSubDivCode", model.ApplicantSubDivCode);
                cmd.Parameters.AddWithValue("@WhetherTrainingAllocated", CustomText.TRUE.ToString());
                cmd.Parameters.AddWithValue("@WhetherTrainingCompleted", CustomText.TRUE.ToString());
                model.data = data.GetDataTable(cmd);
            }
            return View("EducationWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult PoliceStationWiseReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select Count(AD.ApplicationNO) as total,ApplicantLocalityId,LocalityName,PSM.PoliceStationId,PoliceStationName from dgen.applicationdetailscdv ADCDV inner join applicationdetails  AD on AD.ApplicationNO=ADCDV.ApplicationNO inner join dgen.cdvtrainingsessions  CDV on AD.ApplicationNO=CDV.ApplicationNO inner join LocalityMaster LM on LM.LocalityId=AD.ApplicantLocalityId right outer join PSToLocalityMaster PSSM on PSSM.LocalityId=AD.ApplicantLocalityId right outer join PoliceStationMaster PSM on PSM.PoliceStationId=PSSM.PoliceStationId where ApplicationStatusId=@TEHSREC and WhetherTrainingAllocated=@WhetherTrainingAllocated and WhetherTrainingCompleted=@WhetherTrainingCompleted group by ApplicantLocalityId ,LocalityName,PSM.PoliceStationId,PoliceStationName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@WhetherTrainingAllocated", CustomText.TRUE.ToString());
            cmd.Parameters.AddWithValue("@WhetherTrainingCompleted", CustomText.TRUE.ToString());
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult PoliceStationWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = "select Count(AD.ApplicationNO) as total,ApplicantLocalityId,LocalityName,PSM.PoliceStationId,PoliceStationName from dgen.applicationdetailscdv ADCDV inner join applicationdetails  AD on AD.ApplicationNO=ADCDV.ApplicationNO inner join dgen.cdvtrainingsessions  CDV on AD.ApplicationNO=CDV.ApplicationNO inner join LocalityMaster LM on LM.LocalityId=AD.ApplicantLocalityId right outer join PSToLocalityMaster PSSM on PSSM.LocalityId=AD.ApplicantLocalityId right outer join PoliceStationMaster PSM on PSM.PoliceStationId=PSSM.PoliceStationId where ApplicationStatusId=@TEHSREC and WhetherTrainingAllocated=@WhetherTrainingAllocated and WhetherTrainingCompleted=@WhetherTrainingCompleted and ApplicationDistrictCode=@ApplicationDistrictCode and ApplicationSubDivCode=@ApplicationSubDivCode group by ApplicantLocalityId ,LocalityName,PSM.PoliceStationId,PoliceStationName";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
                cmd.Parameters.AddWithValue("@ApplicationDistrictCode", model.ApplicantDistrictCode);
                cmd.Parameters.AddWithValue("@ApplicationSubDivCode", model.ApplicantSubDivCode);
                cmd.Parameters.AddWithValue("@WhetherTrainingAllocated", CustomText.TRUE.ToString());
                cmd.Parameters.AddWithValue("@WhetherTrainingCompleted", CustomText.TRUE.ToString());
                model.data = data.GetDataTable(cmd);
            }
            return View("PoliceStationWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult ApplicationDetailsReport(int? DistCode, int? SubDivCode, int? Tid, int? Eid, int? Lid)
        {
            ReportModels model = new ReportModels();
            GetData data = new GetData();
            string WhetherCondition = string.Empty;
            if (!string.IsNullOrEmpty(DistCode.ToString()) && !string.IsNullOrEmpty(SubDivCode.ToString()))
            {
                WhetherCondition = WhetherCondition + " and ApplicationDistrictCode=@ApplicationDistrictCode and ApplicationSubDivCode=@ApplicationSubDivCode";
            }
            string Qry = "select AD.ServiceCode,AD.applicationsubdivcode,SM.SubDivDescription,DM.DistrictCode,DM.DistrictName,AD.ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName from dbo.ApplicationDetails AD ";
            if (!string.IsNullOrEmpty(Tid.ToString()))
            {
                Qry = Qry + " inner join ApplicationTechnicalEducationDetail ATED on ATED.ApplicationNo=AD.ApplicationNo";
            }
            if (!string.IsNullOrEmpty(Lid.ToString()))
            {
                Qry = Qry + " inner join LocalityMaster LM on LM.LocalityId=AD.ApplicantLocalityId right outer join PSToLocalityMaster PSSM on PSSM.LocalityId=AD.ApplicantLocalityId right outer join PoliceStationMaster PSM on PSM.PoliceStationId=PSSM.PoliceStationId";
            }
            Qry = Qry + " inner join dgen.applicationdetailscdv ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo inner join dgen.cdvtrainingsessions CDVTS on CDVTS.ApplicationNo=AD.ApplicationNo left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode where whetherTrainingAllocated=@whetherTrainingAllocated and whetherTrainingCompleted=@whetherTrainingCompleted and AD.ApplicationStatusId=@ApplicationStatusId";
            if (!string.IsNullOrEmpty(Tid.ToString()))
            {
                Qry = Qry + " and ATED.TechnicalEducationId=@TechnicalEducationId";
            }
            if (!string.IsNullOrEmpty(Eid.ToString()))
            {
                Qry = Qry + " and ADCDV.EQualificationId=@EQualificationId";
            }
            if (!string.IsNullOrEmpty(Lid.ToString()))
            {
                Qry = Qry + " and AD.ApplicantLocalityId=@ApplicantLocalityId";
            }
            Qry += "" + WhetherCondition + " order by ApplicantName";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            if (!string.IsNullOrEmpty(Tid.ToString()))
            {
                cmd.Parameters.AddWithValue("@TechnicalEducationId", Tid);
            }
            if (!string.IsNullOrEmpty(Eid.ToString()))
            {
                cmd.Parameters.AddWithValue("@EQualificationId", Eid);
            }
            if (!string.IsNullOrEmpty(Lid.ToString()))
            {
                cmd.Parameters.AddWithValue("@ApplicantLocalityId", Lid);
            }
            if (!string.IsNullOrEmpty(DistCode.ToString()) && !string.IsNullOrEmpty(SubDivCode.ToString()))
            {
                cmd.Parameters.AddWithValue("@ApplicationDistrictCode", DistCode);
                cmd.Parameters.AddWithValue("@ApplicationSubDivCode", SubDivCode);
            }
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@whetherTrainingAllocated", CustomText.TRUE.ToString());
            cmd.Parameters.AddWithValue("@whetherTrainingCompleted", CustomText.TRUE.ToString());
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ViewAllLocalityReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ViewAllLocalityReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string whereCondition = string.Empty, Qry = string.Empty;

                if (Convert.ToInt32(Sessions.getEmployeeUser().DeptCode) == (int)Department.Dept002 || Convert.ToInt32(Sessions.getEmployeeUser().DeptCode) == (int)Department.Dept008)
                {
                    Qry = "select LocalityName,subDivDescription,DistrictName,PinCode,constituencyName from LocalityMaster LM inner join LocalityToSubdivMaster LTSM on LTSM.LocalityId=LM.LocalityId Inner join SubDivMaster SDM on SDM.SubDivCode=LTSM.SubDivCode Inner Join DistrictMaster DM on DM.DistrictCode=SDM.DistrictCode Inner Join localitytoconstituencymaster LCM on LCM.LocalityId=LM.LocalityId inner join assemblyconstituencymaster ACM on ACM.constituencyId=LCM.constituencyId where LTSM.SubDivCode=@SubDivCode and SDM.DistrictCode=@DistrictCode and LTSM.WhetherActive=@WhetherActive and LCM.Deptcode=@Deptcode ";
                }
                else
                {
                    Qry = @"select LocalityName,subDivDescription,DistrictName,PinCode from LocalityMaster LM inner join LocalityToSubdivMaster LTSM on LTSM.LocalityId=LM.LocalityId Inner join SubDivMaster SDM on SDM.SubDivCode=LTSM.SubDivCode Inner Join DistrictMaster DM on DM.DistrictCode=SDM.DistrictCode where LTSM.SubDivCode=@SubDivCode and SDM.DistrictCode=@DistrictCode and LTSM.WhetherActive=@WhetherActive";
                }
                if (!string.IsNullOrEmpty(model.LocalityName)) { Qry += " and lower(LocalityName) like lower(@LocalityName) "; }
                if (Convert.ToInt32(Sessions.getEmployeeUser().DeptCode) == (int)Department.Dept002 || Convert.ToInt32(Sessions.getEmployeeUser().DeptCode) == (int)Department.Dept008) { Qry += " order by constituencyName,LocalityName"; }
                else { Qry += " order by LocalityName"; }
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@DistrictCode", model.ApplicantDistrictCode);
                cmd.Parameters.AddWithValue("@SubDivCode", model.ApplicantSubDivCode);
                cmd.Parameters.AddWithValue("@Deptcode", Sessions.getEmployeeUser().DeptCode);
                if (!string.IsNullOrEmpty(model.LocalityName)) { cmd.Parameters.AddWithValue("@LocalityName", string.Format("%{0}%", model.LocalityName)); }
                cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                model.data = data.GetDataTable(cmd);
            }
            return View("ViewAllLocalityReport", model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult AppoinmentPendingReport()
        {
            ReportModels model = new ReportModels();
            GetData data = new GetData();
            return View(model);

        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult AppoinmentPendingReport(ReportModels model)
        {
            GetData data = new GetData();
            StringBuilder Qry = new StringBuilder("select AD.ServiceCode,AD.ApplicationId,NULL as ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,to_char(AppointmentDate,'DD/MM/YYYY') as AppointmentDate,SM.statusname from appointmentmaster AM inner join wgen.applicationmarriagedetails AMD on AMD.AppointmentId=AM.AppointmentId inner join web.applicationdetails AD on AD.ApplicationId=AMD.ApplicationId inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode::smallint inner join statusmaster SM on SM.statusid=AD.applicationstatusid where applicationStatusId in (@PENDFEE) and AD.servicecode=@Marriage and to_char(appointmentDate,'DD/MM/YYYY') = @Date ");
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry.Append(" and AD.applicationdistrictcode=@ParamDistrictCode"); }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry.Append(" and AD.ApplicationSubDivCode=@ParamSubDivCode"); }
            if (!string.IsNullOrEmpty(model.ApplicantSubDivCode)) { Qry.Append(" and AD.ApplicationSubDivCode=@applicantsubdivcode"); }
            if (!string.IsNullOrEmpty(model.ApplicantDistrictCode)) { Qry.Append(" and AD.applicationdistrictcode=@applicationdistrictcode"); }
            Qry.Append(" union all ");
            Qry.Append("select AD.ServiceCode,NULL as ApplicationId,AD.ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,to_char(AppointmentDate,'DD/MM/YYYY') as AppointmentDate,SM.statusname from appointmentmaster AM inner join dgen.applicationmarriagedetails AMD on AMD.AppointmentId=AM.AppointmentId inner join applicationdetails AD on AD.ApplicationNo=AMD.ApplicationNo inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode inner join statusmaster SM on SM.statusid=AD.applicationstatusid where AD.servicecode=@Marriage  and to_char(appointmentDate,'DD/MM/YYYY') =@Date");
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry.Append(" and AD.applicationdistrictcode=@ParamDistrictCode"); }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry.Append(" and AD.ApplicationSubDivCode=@ParamSubDivCode"); }
            if (!string.IsNullOrEmpty(model.ApplicantSubDivCode)) { Qry.Append(" and AD.ApplicationSubDivCode=@applicantsubdivcode"); }
            if (!string.IsNullOrEmpty(model.ApplicantDistrictCode)) { Qry.Append(" and AD.applicationdistrictcode=@applicationdistrictcode"); }
            Qry.Append(" union all ");
            Qry.Append("select AD.ServiceCode,AD.ApplicationId,NULL as ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,to_char(AppointmentDate,'DD/MM/YYYY') as AppointmentDate,SM.statusname from appointmentmaster AM inner join wgen.applicationmarriagesolemnizationdetails AMD on AMD.AppointmentId=AM.AppointmentId inner join web.applicationdetails AD on AD.ApplicationId=AMD.ApplicationId inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode::smallint inner join statusmaster SM on SM.statusid=AD.applicationstatusid where applicationStatusId in (@PENDFEE) and AD.servicecode=@Solemnization and to_char(appointmentDate,'DD/MM/YYYY') = @Date ");
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry.Append(" and AD.applicationdistrictcode=@ParamDistrictCode"); }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry.Append(" and AD.ApplicationSubDivCode=@ParamSubDivCode"); }
            if (!string.IsNullOrEmpty(model.ApplicantSubDivCode)) { Qry.Append(" and AD.ApplicationSubDivCode=@applicantsubdivcode"); }
            if (!string.IsNullOrEmpty(model.ApplicantDistrictCode)) { Qry.Append(" and AD.applicationdistrictcode=@applicationdistrictcode"); }
            Qry.Append(" union all ");
            Qry.Append("select AD.ServiceCode,NULL as ApplicationId,AD.ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,to_char(AppointmentDate,'DD/MM/YYYY') as AppointmentDate,SM.statusname from appointmentmaster AM inner join dgen.applicationmarriagesolemnizationdetails AMD on AMD.AppointmentId=AM.AppointmentId inner join applicationdetails AD on AD.ApplicationNo=AMD.ApplicationNo inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode inner join statusmaster SM on SM.statusid=AD.applicationstatusid where AD.servicecode=@Solemnization  and to_char(appointmentDate,'DD/MM/YYYY') =@Date");
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry.Append(" and AD.applicationdistrictcode=@ParamDistrictCode"); }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry.Append(" and AD.ApplicationSubDivCode=@ParamSubDivCode"); }
            if (!string.IsNullOrEmpty(model.ApplicantSubDivCode)) { Qry.Append(" and AD.ApplicationSubDivCode=@applicantsubdivcode"); }
            if (!string.IsNullOrEmpty(model.ApplicantDistrictCode)) { Qry.Append(" and AD.applicationdistrictcode=@applicationdistrictcode"); }

            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry.ToString()));
            cmd.Parameters.AddWithValue("@PENDFEE", (int)Status.SCOM034);
            cmd.Parameters.AddWithValue("@Solemnization", (int)ServiceList.Solemnization);
            cmd.Parameters.AddWithValue("@Marriage", (int)ServiceList.Marriage);
            cmd.Parameters.AddWithValue("@Date", model.DateFrom);
            if (!string.IsNullOrEmpty(model.ApplicantSubDivCode)) { cmd.Parameters.AddWithValue("@applicantsubdivcode", model.ApplicantSubDivCode); }
            if (!string.IsNullOrEmpty(model.ApplicantDistrictCode)) { cmd.Parameters.AddWithValue("@applicationdistrictcode", model.ApplicantDistrictCode); }
            model.data = data.GetDataTable(cmd);
            return View(model);
        }

        [EncryptedActionParameter]
        public ActionResult DayWiseApplicationReport()
        {
            ReportModels model = new ReportModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult DayWiseApplicationReportDetails(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                ArrayList Values = new ArrayList();
                DataTable dtt = new DataTable();
                string qry = string.Empty;
                if ((string.IsNullOrEmpty(model.Year)) && (string.IsNullOrEmpty(model.Month)))
                {
                    ViewBag.DisplayMessage = "Please fill period of issuance";
                    return View(model);
                }

                StringBuilder Qry = new StringBuilder("select to_char(ApplicationDate,'DD/MM/YYYY') as AppDate,coalesce(sum(case when ApplicationSourceId=2 then 1 end),0) CSCReceived,coalesce(sum(case when ApplicationSourceId=1 then 1 end),0) CitizenReceived from dstc.ScheduledStaticData AD  right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode where 1=1 and SM.deptcode in (@ParamDeptCode) ");
                if (!string.IsNullOrEmpty(model.ServiceCode))
                {
                    Qry.Append(" and AD.ServiceCode=@ServiceCode");
                }
                if (!string.IsNullOrEmpty(model.Year))
                {
                    Qry.Append(" and (extract(year from AD.ApplicationDate))=@Year");
                }
                if (!string.IsNullOrEmpty(model.Month))
                {
                    Qry.Append(" and (extract(month from AD.ApplicationDate))=@Month");
                }
                if (!string.IsNullOrEmpty(model.DistrictCode))
                {
                    Qry.Append(" and AD.DistrictCode=@districtcode");
                }
                if (!string.IsNullOrEmpty(model.ApplicationSubDivCode))
                {
                    Qry.Append(" and AD.SubdivCode=@SubDivCode");
                }
                Qry.Append(" group by AppDate order by AppDate");
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry.ToString()));
                cmd.Parameters.AddWithValue("@Year", model.Year);
                cmd.Parameters.AddWithValue("@Month", model.Month);
                if (!string.IsNullOrEmpty(model.ServiceCode)) cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { cmd.Parameters.AddWithValue("@SubDivCode", model.ApplicationSubDivCode); }
                if (!string.IsNullOrEmpty(model.DistrictCode)) { cmd.Parameters.AddWithValue("@districtcode", model.DistrictCode); }
                model.data = data.GetDataTable(cmd);

                model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            }
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult DayWiseApplicationDetails(string AppDate, int SourceId, int? DistrictCode, int? SubDivCode, int? ServiceCode, int? PageIndex = 1)
        {

            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "AppDate=" + AppDate.ToString());
            Parameters.Add(1, "SourceId=" + SourceId.ToString());
            if (DistrictCode != 0) { Parameters.Add(2, "DistrictCode=" + DistrictCode.ToString()); } else { Parameters.Add(2, "DistrictCode=null"); }
            if (SubDivCode != 0) { Parameters.Add(3, "SubDivCode=" + SubDivCode.ToString()); } else { Parameters.Add(3, "SubDivCode=null"); }
            if (ServiceCode != 0) { Parameters.Add(4, "ServiceCode=" + ServiceCode.ToString()); } else { Parameters.Add(4, "ServiceCode=null"); }
            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                GetData data = new GetData();
                string Source = string.Empty;
                if (SourceId == 1) { Source = " and AD.ApplicationSourceId =@ApplicationSourceId"; }
                if (SourceId == 2) { Source = " and AD.ApplicationSourceId =@ApplicationSourceId"; }
                string Qry = "select to_char(ApplicationDate,'DD/MM/YYYY') as AppDate,AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode  inner join dbo.ServiceMaster SR on AD.servicecode=SR.servicecode where to_char(AD.ApplicationDate,'DD/MM/YYYY')=@ApplicationDate and SR.deptcode=@deptcode " + Source;
                if (DistrictCode != 0) { Qry = Qry + " and AD.ApplicationDistrictCode=@DistrictCode"; }
                if (SubDivCode != 0) { Qry = Qry + " and AD.ApplicationSubdivCode=@SubDivCode"; }
                if (ServiceCode != 0) { Qry = Qry + " and AD.ServiceCode=@ServiceCode"; }
                Qry = Qry + " order by AppDate";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry.ToString());
                cmd.Parameters.AddWithValue("@ApplicationDate", AppDate);
                cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
                cmd.Parameters.AddWithValue("@SubDivCode", SubDivCode);
                cmd.Parameters.AddWithValue("@DistrictCode", DistrictCode);
                cmd.Parameters.AddWithValue("@ApplicationSourceId", SourceId);
                cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "DayWiseApplicationDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "DayWiseApplicationDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DistWiseObservationReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            //           model.ApplicantDistrictCode = Sessions.getEmployeeUser().DistrictCode;
            //           model.ApplicationSubDivCode = Sessions.getEmployeeUser().SubDivCode;
            //           string Qry = @"select AD.applicationdistrictcode,DistrictName,AD.applicationsubdivcode,SubDivDescription,count(AO.ApplicationNo) TotalApp,coalesce(sum(case when whetherObservationEntered=true then 1 end),0) ObsDone,coalesce(sum(case when whetherObservationEntered=false then 1 end),0) ObsPending
            //                                from dbo.authorityobservationdetails AO left outer join dbo.ApplicationDetails AD on AO.applicationno=AD.Applicationno left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode  inner join dbo.ServiceMaster SR on AD.servicecode=SR.servicecode where 
            //                                1=1 ";
            //           if (!string.IsNullOrEmpty(model.ApplicantDistrictCode)) { Qry += " and AD.applicationdistrictcode in (@ParamDistrictCode)"; }
            //           if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry += " and AD.applicationsubdivcode in (@ParamSubDivCode)"; }
            //           Qry += " group by AD.applicationdistrictcode,DistrictName,AD.applicationsubdivcode,SubDivDescription order by DistrictName,SubDivDescription";
            //           NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            //           model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DistWiseObservationReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string whereCondition = string.Empty;
                model.ApplicantDistrictCode = Sessions.getEmployeeUser().DistrictCode;
                model.ApplicantSubDivCode = Sessions.getEmployeeUser().SubDivCode;
                string Qry = @"select AD.applicationdistrictcode,DistrictName,AD.applicationsubdivcode,SubDivDescription,AO.PendingWith,count(AO.ApplicationNo) TotalApp,coalesce(sum(case when whetherObservationEntered=true then 1 end),0) ObsDone,coalesce(sum(case when whetherObservationEntered=false then 1 end),0) ObsPending from dbo.authorityobservationdetails AO left outer join dbo.ApplicationDetails AD on AO.applicationno=AD.Applicationno left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode  inner join dbo.ServiceMaster SR on AD.servicecode=SR.servicecode where 1=1 and AO.PendingWith=@PendingWith ";
                if (!string.IsNullOrEmpty(model.Month)) { Qry += " and (extract(month from AO.insertdate))=@Month"; }
                if (!string.IsNullOrEmpty(model.Year)) { Qry += " and (extract(year from AO.insertdate))=@Year"; }
                if (!string.IsNullOrEmpty(model.ApplicantDistrictCode)) { Qry += " and AD.applicationdistrictcode in (@ParamDistrictCode)"; }
                if (!string.IsNullOrEmpty(model.ApplicantSubDivCode)) { Qry += " and AD.applicationsubdivcode in (@ParamSubDivCode)"; }
                if (!string.IsNullOrEmpty(model.DistrictCode)) { Qry += " and AD.applicationdistrictcode=@applicationdistrictcode"; }
                if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry += " and AD.applicationsubdivcode=@applicationsubdivcode "; }
                Qry += " group by AD.applicationdistrictcode,DistrictName,AD.applicationsubdivcode,SubDivDescription,AO.PendingWith";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                if (!string.IsNullOrEmpty(model.Month)) { cmd.Parameters.AddWithValue("@Month", model.Month); }
                if (!string.IsNullOrEmpty(model.Year)) { cmd.Parameters.AddWithValue("@Year", model.Year); }
                if (!string.IsNullOrEmpty(model.DistrictCode)) { cmd.Parameters.AddWithValue("@applicationdistrictcode", model.DistrictCode); }
                if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { cmd.Parameters.AddWithValue("@applicationsubdivcode", model.ApplicationSubDivCode); }
                if (!string.IsNullOrEmpty(model.ApplicantDistrictCode)) { cmd.Parameters.AddWithValue("@ParamDistrictCode", model.ApplicantDistrictCode); }
                if (!string.IsNullOrEmpty(model.ApplicantSubDivCode)) { cmd.Parameters.AddWithValue("@ParamSubDivCode", model.ApplicantSubDivCode); }
                cmd.Parameters.AddWithValue("@PendingWith", model.PermissionCode);
                model.data = data.GetDataTable(cmd);
            }
            return View("DistWiseObservationReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult DistWiseObservationDetailsReport(int Flag, Int32 DistCode, Int32 SubDivCode, int Month, int Year, Int32 Permission, int? PageIndex = 1)
        {
            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "Flag=" + Flag.ToString());
            Parameters.Add(1, "DistCode=" + DistCode.ToString());
            Parameters.Add(2, "SubDivCode=" + SubDivCode.ToString());
            if (!string.IsNullOrEmpty(Month.ToString())) { Parameters.Add(3, "Month=" + Month.ToString()); }
            if (!string.IsNullOrEmpty(Year.ToString())) { Parameters.Add(4, "Year=" + Year.ToString()); }
            Parameters.Add(5, "PendingWith=" + Permission.ToString());

            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                GetData data = new GetData();

                string Qry = @"select AOD,RowId,AD.ServiceCode,AD.applicationsubdivcode,SM.SubDivDescription,DM.DistrictCode,DM.DistrictName,AD.ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName from dbo.ApplicationDetails AD inner join dbo.AuthorityObservationDetails  AOD on AOD.ApplicationNo=AD.ApplicationNo
                               inner join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode inner join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode inner join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode where AD.ApplicationDistrictCode=@ApplicationDistrictCode and AD.ApplicationSubDivCode=@ApplicationSubDivCode and AOD.PendingWith=@PendingWith";
                if (Flag == (int)CountList.Type001)
                {
                    Qry += " and whetherObservationEntered=true";
                }
                if (Flag == (int)CountList.Type002)
                {
                    Qry += " and whetherObservationEntered=false";
                }
                if (Convert.ToInt32(Month) > 0 && Convert.ToInt32(Year) > 0)
                {
                    Qry += " and (extract(month from AOD.insertdate))=@Month and (extract(year from AOD.insertdate))=@Year";
                }
                Qry += " order by ApplicantName";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@ApplicationDistrictCode", DistCode);
                cmd.Parameters.AddWithValue("@ApplicationSubDivCode", SubDivCode);
                cmd.Parameters.AddWithValue("@PendingWith", Permission.ToString());
                if (Convert.ToInt32(Month) > 0 && Convert.ToInt32(Year) > 0)
                {
                    cmd.Parameters.AddWithValue("@Month", Month.ToString());
                    cmd.Parameters.AddWithValue("@Year", Year.ToString());
                }
                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "DistWiseObservationDetailsReport", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "DistWiseObservationDetailsReport", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ReliefTypeWiseReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select  relieftypeid,SMVD.valuename as relieftypename,count(AD.ApplicationNo) as totalRecveived,sum(mm.memcount) as totalMembers,coalesce(sum(case when ApplicationStatusId= @ISSUCER then 1 end),0) as totalDisposed,coalesce(sum(case when ApplicationStatusId not in(@ISSUCER,@CANCEL,@TEHSREJ) then 1 end),0) as totalpending from dbo.applicationdetails AD inner join drev.applicationdetailsmigration AM on AD.ApplicationNo=AM.ApplicationNo inner join selectmastervaluedetails SMVD on SMVD.valueid=AM.relieftypeid left outer join (select applicationno,count(applicationno) as memcount from drev.migrationmembersdetails group by applicationno) mm on mm.applicationno=AD.applicationno ";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " where AD.applicationdistrictcode in (@ParamDistrictCode)"; }
            Qry += "group by relieftypeid,SMVD.valuename";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }

        [EncryptedActionParameter]
        public ActionResult ReliefTypeDisWiseReport(int RelfType)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select relieftypeid,SMVD.valuename as relieftypename, AD.applicationdistrictcode,DistrictName,count(AD.ApplicationNo) as totalRecveived,sum(mm.memcount) as totalMembers,coalesce(sum(case when ApplicationStatusId= @ISSUCER then 1 end),0) as totalDisposed,coalesce(sum(case when ApplicationStatusId not in(@ISSUCER,@CANCEL,@TEHSREJ) then 1 end),0) as totalpending from dbo.applicationdetails AD inner join drev.applicationdetailsmigration AM on AD.ApplicationNo=AM.ApplicationNo inner join selectmastervaluedetails SMVD on SMVD.valueid=AM.relieftypeid left outer join (select applicationno,count(applicationno) as memcount from drev.migrationmembersdetails group by applicationno) mm on mm.applicationno=AD.applicationno left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode where relieftypeid=@relieftypeid ";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.applicationdistrictcode in (@ParamDistrictCode)"; }
            Qry += " group by relieftypeid,SMVD.valuename,AD.applicationdistrictcode,DistrictName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@relieftypeid", RelfType);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult ReliefTypeSubdivWiseReport(int Dist, int RelfType)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select relieftypeid,SMVD.valuename as relieftypename, AD.applicationdistrictcode,DistrictName,AD.applicationsubdivcode,SubDivDescription,count(AD.ApplicationNo) as totalRecveived,sum(mm.memcount) as totalMembers,coalesce(sum(case when ApplicationStatusId= 16 then 1 end),0) as totalDisposed,coalesce(sum(case when ApplicationStatusId not in(16,1,14) then 1 end),0) as totalpending from dbo.applicationdetails AD inner join drev.applicationdetailsmigration AM on AD.ApplicationNo=AM.ApplicationNo inner join selectmastervaluedetails SMVD on SMVD.valueid=AM.relieftypeid left outer join (select applicationno,count(applicationno) as memcount from drev.migrationmembersdetails group by applicationno) mm on mm.applicationno=AD.applicationno left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode where relieftypeid=@relieftypeid  and AD.ApplicationDistrictCode=@DistrictCode group by relieftypeid,SMVD.valuename,AD.applicationdistrictcode,DistrictName,AD.applicationsubdivcode,SubDivDescription";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@relieftypeid", RelfType);
            cmd.Parameters.AddWithValue("@DistrictCode", Dist);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }

        [EncryptedActionParameter]
        public ActionResult ReliefTypeApplicationDetails(int SubDiv, int Dist, int RelfType, int? Typ)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = string.Empty;
            if (string.IsNullOrEmpty(Typ.ToString()))
            {
                Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName from dbo.ApplicationDetails AD inner join drev.applicationdetailsmigration AM on AM.ApplicationNo=AD.ApplicationNo left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode inner join dbo.ServiceMaster SR on AD.servicecode=SR.servicecode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where AD.ServiceCode=@ServiceCode and AD.ApplicationSubdivCode=@SubdivCode and AM.relieftypeid=@relieftypeid group by AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,AD.ApplicantDob,SL.StatusName,AD.ServiceCode order by SL.StatusName";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@SubDivCode", SubDiv);
                cmd.Parameters.AddWithValue("@ServiceCode", ((int)ServiceList.Migration).ToString());
                cmd.Parameters.AddWithValue("@relieftypeid", RelfType);
                cmd.Parameters.AddWithValue("@DistrictCode", Dist);
                model.data = data.GetDataTable(cmd);
            }
            else
            {
                Qry = "select AM.Applicationno,NameofMember,NameofFather,to_char(AM.DOB,'DD/MM/YYYY') as DOB,AM.RelationId,SMVD.ValueName,MM.relieftypeid from drev.migrationmembersdetails AM left outer join dbo.applicationdetails AD on AD.ApplicationNo=AM.Applicationno left outer join drev.applicationdetailsmigration MM on AM.ApplicationNo=MM.ApplicationNo inner join dbo.selectmastervaluedetails SMVD on AM.RelationId=SMVD.valueid left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode where AD.ApplicationDistrictCode=@DistrictCode and AD.ApplicationSubdivCode=@SubdivCode and MM.relieftypeid=@relieftypeid";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@SubDivCode", SubDiv);
                cmd.Parameters.AddWithValue("@DistrictCode", Dist);
                cmd.Parameters.AddWithValue("@relieftypeid", RelfType);
                model.dataa = data.GetDataTable(cmd);
            }


            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ExistingCDVDistWiseReport(string DTF, string DTT, int? CDVTypeId)
        {
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { return RedirectToAction("ExistingCDVSubDivWiseReport"); }
            if (CDVTypeId.Equals(null)) { CDVTypeId = (int)CountList.Type000; }
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = "select @CDVTypeId as CDVType, @DisplayFromDate as FromDate,@DisplayToDate as ToDate,AD.Applicationdistrictcode,DM.DistrictName, coalesce(count(AD.ApplicationNo),0) Received,coalesce(sum(case when AD.ApplicationStatusId not in (@ISSUED,@TEHSREJ,@CANCEL,@SCOM009)  then 1 end),0) as pending,coalesce(sum(case when AD.ApplicationStatusId=@ISSUED and whetherbasictrainingcomplete=true then 1 end),0) as TrainingComplete,coalesce(sum(case when AD.ApplicationStatusId=@ISSUED and whetherbasictrainingcomplete=false then 1 end),0) as TrainingPending,coalesce(sum(case when AD.ApplicationStatusId=@SCOM009 then 1 end),0) as Discharge,coalesce(sum(case when AD.ApplicationStatusId=@TEHSREJ then 1 end),0) as Rejected from applicationdetails AD inner join dgen.ApplicationDetailsCDV ADCDV on ADCDV.ApplicationNO=AD.ApplicationNO inner join dbo.DistrictMaster DM on AD.Applicationdistrictcode=DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode where DM.deptcode=@ParamDeptCode and AD.servicecode=@servicecode ";
            if (CDVTypeId == (int)CountList.Type001) { Qry += " and whetheroldcdventry=@whetheroldcdventry1  "; }
            if (CDVTypeId == (int)CountList.Type002) { Qry += " and whetheroldcdventry=@whetheroldcdventry  "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by AD.Applicationdistrictcode,DM.DistrictName order by DM.DistrictName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUED", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@SCOM002", (int)Status.SCOM002);
            cmd.Parameters.AddWithValue("@SCOM009", (int)Status.SCOM009);
            cmd.Parameters.AddWithValue("@servicecode", (int)ServiceList.CDVolunteer);
            cmd.Parameters.AddWithValue("@whetheroldcdventry", CustomText.TRUE.ToString());
            cmd.Parameters.AddWithValue("@whetheroldcdventry1", CustomText.FALSE.ToString());
            cmd.Parameters.AddWithValue("@CDVTypeId", CDVTypeId);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ExistingCDVDistWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT", "CDVTypeId" }, new ArrayList() { model.DateFrom, model.DateTo, model.CDVEntryType });
                return RedirectToAction("ExistingCDVDistWiseReport", "Report", new { q = QueryString });
            }
            return View("ExistingCDVDistWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult ExistingCDVSubDivWiseReport(int? dist, int? CDVTypeId, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            if (dist.Equals(null)) { dist = Convert.ToInt32(Sessions.getEmployeeUser().DistrictCode); }
            if (CDVTypeId.Equals(null)) { CDVTypeId = (int)CountList.Type000; }
            model.ApplicationSubDivCode = Sessions.getEmployeeUser().SubDivCode;

            string Qry = "select @CDVTypeId as CDVType,@DisplayFromDate as FromDate,@DisplayToDate as ToDate,AD.Applicationsubdivcode,SDM.SubDivDescription,AD.Applicationdistrictcode,DM.DistrictName, coalesce(count(AD.ApplicationNo),0) Received,coalesce(sum(case when AD.ApplicationStatusId not in (@ISSUED,@TEHSREJ,@CANCEL,@SCOM009)  then 1 end),0) as pending,coalesce(sum(case when AD.ApplicationStatusId=@ISSUED and whetherbasictrainingcomplete=true then 1 end),0) as TrainingComplete,coalesce(sum(case when AD.ApplicationStatusId=@ISSUED and whetherbasictrainingcomplete=false then 1 end),0) as TrainingPending,coalesce(sum(case when AD.ApplicationStatusId=@SCOM009 then 1 end),0) as Discharge,coalesce(sum(case when AD.ApplicationStatusId=@TEHSREJ then 1 end),0) as Rejected from applicationdetails AD inner join dgen.ApplicationDetailsCDV ADCDV on ADCDV.ApplicationNO=AD.ApplicationNO inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode right outer  join dbo.DistrictMaster DM on AD.Applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SDM on AD.Applicationsubdivcode=SDM.SubDivCode  where AD.Applicationdistrictcode=@DistrictCode and AD.servicecode=@servicecode ";
            if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry += " and AD.Applicationsubdivcode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            if (CDVTypeId == (int)CountList.Type001) { Qry += " and  whetheroldcdventry=@whetheroldcdventry1  "; }
            if (CDVTypeId == (int)CountList.Type002) { Qry += " and  whetheroldcdventry=@whetheroldcdventry  "; }
            Qry += " group by AD.Applicationsubdivcode,SDM.SubDivDescription,AD.Applicationdistrictcode,DM.DistrictName order by SDM.SubDivDescription";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUED", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@SCOM002", (int)Status.SCOM002);
            cmd.Parameters.AddWithValue("@SCOM009", (int)Status.SCOM009);
            cmd.Parameters.AddWithValue("@servicecode", (int)ServiceList.CDVolunteer);
            cmd.Parameters.AddWithValue("@whetheroldcdventry", CustomText.TRUE.ToString());
            cmd.Parameters.AddWithValue("@whetheroldcdventry1", CustomText.FALSE.ToString());
            cmd.Parameters.AddWithValue("@CDVTypeId", CDVTypeId);
            cmd.Parameters.AddWithValue("@DistrictCode", dist);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ExistingCDVSubDivWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "CDVTypeId", "DTF", "DTT" }, new ArrayList() { model.CDVEntryType, model.DateFrom, model.DateTo });
                return RedirectToAction("ExistingCDVSubDivWiseReport", "Report", new { q = QueryString });
            }
            return View("ExistingCDVSubDivWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult ExistingCDVServiceWiseReport(int subDiv, int CDVTypeId, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = "select @CDVTypeId as CDVType,@DisplayFromDate as FromDate,@DisplayToDate as ToDate,SM.ServiceName,SM.ServiceCode,AD.Applicationsubdivcode,SDM.SubDivDescription,AD.Applicationdistrictcode,DM.DistrictName, coalesce(count(AD.ApplicationNo),0) Received,coalesce(sum(case when AD.ApplicationStatusId not in (@ISSUED,@TEHSREJ,@CANCEL,@SCOM009)  then 1 end),0) as pending,coalesce(sum(case when AD.ApplicationStatusId=@ISSUED and whetherbasictrainingcomplete=true then 1 end),0) as TrainingComplete,coalesce(sum(case when AD.ApplicationStatusId=@ISSUED and whetherbasictrainingcomplete=false then 1 end),0) as TrainingPending,coalesce(sum(case when AD.ApplicationStatusId=@SCOM009 then 1 end),0) as Discharge,coalesce(sum(case when AD.ApplicationStatusId=@TEHSREJ then 1 end),0) as Rejected from applicationdetails AD inner join dgen.ApplicationDetailsCDV ADCDV on ADCDV.ApplicationNO=AD.ApplicationNO inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode right outer  join dbo.DistrictMaster DM on AD.Applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SDM on AD.Applicationsubdivcode=SDM.SubDivCode  where AD.Applicationsubdivcode=@SubDivCode and AD.servicecode=@servicecode  ";
            if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            if (CDVTypeId == (int)CountList.Type001) { Qry += " and  whetheroldcdventry=@whetheroldcdventry1  "; }
            if (CDVTypeId == (int)CountList.Type002) { Qry += " and  whetheroldcdventry=@whetheroldcdventry  "; }
            Qry += " group by SM.ServiceName,SM.ServiceCode,AD.Applicationsubdivcode,SDM.SubDivDescription,AD.Applicationdistrictcode,DM.DistrictName order by SM.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUED", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@SCOM002", (int)Status.SCOM002);
            cmd.Parameters.AddWithValue("@SCOM009", (int)Status.SCOM009);
            cmd.Parameters.AddWithValue("@servicecode", (int)ServiceList.CDVolunteer);
            cmd.Parameters.AddWithValue("@whetheroldcdventry", CustomText.TRUE.ToString());
            cmd.Parameters.AddWithValue("@whetheroldcdventry1", CustomText.FALSE.ToString());
            cmd.Parameters.AddWithValue("@CDVTypeId", CDVTypeId);
            cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult EnrolledCDVReport(int? subDiv, int? service, int? CDVTypeId, int? status, string DTF, string DTT, int? PageIndex = 1)
        {
            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "service=" + service.ToString());
            Parameters.Add(1, "status=" + status.ToString());
            Parameters.Add(2, "subDiv=" + subDiv.ToString());
            Parameters.Add(3, "CDVTypeId=" + CDVTypeId.ToString());
            if (!string.IsNullOrEmpty(DTF)) { Parameters.Add(4, "DTF=" + DTF.ToString()); }
            if (!string.IsNullOrEmpty(DTT)) { Parameters.Add(5, "DTT=" + DTT.ToString()); }
            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                GetData data = new GetData();
                string statusId = string.Empty, Qry = string.Empty;
                if (status == (int)CountList.Type002) { statusId = " and AD.ApplicationStatusId not in (@ISSUED,@TEHSREJ,@CANCEL,@SCOM009) "; }
                else if (status == (int)CountList.Type003) { statusId = " and AD.ApplicationStatusId=@ISSUED and whetherbasictrainingcomplete=FALSE "; }
                else if (status == (int)CountList.Type005) { statusId = " and AD.ApplicationStatusId=@ISSUED and whetherbasictrainingcomplete=TRUE "; }
                else if (status == (int)CountList.Type004) { statusId = " and AD.ApplicationStatusId=@SCOM009 "; }
                else if (status == (int)CountList.Type006) { statusId = " and AD.ApplicationStatusId=@TEHSREJ "; }

                Qry = "Select @CDVTypeId as CDVType,@DisplayFromDate as FromDate,@DisplayToDate as ToDate,ADCDV.EnrollmentNo,ADCDV.EnrollmentIdOld,AD.ApplicantName,to_char(AD.ApplicantDoB,'DD/MM/YYYY') as ApplicantDoB,SMVD.ValueName as ApplicantQualification,AD.Applicationdistrictcode,AD.ApplicantMobileNo,AD.ApplicationSubDivCode,CDM.CDVSubdivName,SDM.SubDivDescription,DM.DistrictName,DM.DistrictCode,dbo.displaycompleteaddressfromid(RM.ApplicantHouseNumber,RM.ApplicantStreetNumber,RM.ApplicantSubLocality,RM.ApplicantLocalityId,RM.ApplicantSubDivCode,RM.ApplicantDistrictCode,RM.ApplicantStateId,RM.ApplicantCountryId,RM.ApplicantPinCode) as ApplicantAddress,to_char(ADCDV.EnrollmentDate,'DD/MM/YYYY') as EnrollmentDate,case When ADCDV.WhetherBasicTrainingComplete = true Then 'Completed' else 'Not Completed' end as BasicTrainingStatus,StatusName from applicationdetails AD inner join web.RegistrationMaster RM on RM.RegistrationId = AD.RegistrationId inner join dgen.ApplicationDetailsCDV ADCDV on ADCDV.ApplicationNO = AD.ApplicationNO inner join StatusMaster STM on STM.StatusId=AD.ApplicationStatusId inner join dbo.DistrictMaster DM on AD.Applicationdistrictcode = DM.DistrictCode inner join dbo.ServiceMaster SM on AD.servicecode = SM.servicecode inner join SelectMasterValueDetails SMVD on SMVD.ValueId = ADCDV.EqualificationId inner join dbo.CdvSubdivmaster CDM on CDM.CDVSubdivcode = ADCDV.CDVSubdivcode right outer join dbo.Subdivmaster SDM on AD.Applicationsubdivcode = SDM.SubDivCode where DM.deptcode = @ParamDeptCode and AD.Applicationsubdivcode = @SubDivCode and AD.Servicecode = @Servicecode " + statusId;
                if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
                if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
                if (CDVTypeId == (int)CountList.Type001) { Qry += " and  whetheroldcdventry=@whetheroldcdventry1  "; }
                if (CDVTypeId == (int)CountList.Type002) { Qry += " and  whetheroldcdventry=@whetheroldcdventry  "; }

                Qry += " Order by AD.ApplicantName";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ServiceCode", service);
                cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
                cmd.Parameters.AddWithValue("@ISSUED", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
                cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
                cmd.Parameters.AddWithValue("@SCOM009", (int)Status.SCOM009);
                cmd.Parameters.AddWithValue("@whetheroldcdventry", CustomText.TRUE.ToString());
                cmd.Parameters.AddWithValue("@whetheroldcdventry1", CustomText.FALSE.ToString());
                cmd.Parameters.AddWithValue("@CDVTypeId", CDVTypeId);
                cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
                cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
                cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
                cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
                model.data = data.GetDataTable(cmd);

                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "EnrolledCDVReport", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "EnrolledCDVReport", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DistWiseOtherStateVerReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = @"select count ( AD.ApplicationNo) as TotalPending, rstateid,StateName from ApplicationDetails AD inner join applicationverificationletterdetails AVLD on AVLD.Applicationno=AD.Applicationno 
                            inner join (select applicationno,rstateid from drev.applicationdetailsobc where rstateid is not null and rstateid<>@StateId union all
                            select applicationno,rstateid from drev.applicationdetailsscst where rstateid is not null and rstateid<>@StateId union all
                            select applicationno,rstateid from drev.applicationdetailsst where rstateid is not null and rstateid<>@StateId) ADST on ADST.Applicationno=AD.Applicationno 
                            inner join StateMaster SM on SM.StateId=ADST.rstateid
                            inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode
                            inner join SubDivMaster SDM on SDM.SubDivCode=AD.ApplicationSubDivCode
                            where TypeValueId=@TypeValueId and ApplicationStatusId=@ApplicationStatusId ";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and SDM.SubDivCode in (@ParamSubDivCode) "; }
            Qry += " group by rstateid,StateName order by TotalPending";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@TypeValueId", (int)ValueId.OtherStateLetter);
            cmd.Parameters.AddWithValue("@StateId", (int)State.Delhi);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.VERLOTHS);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DistWiseOtherStateVerReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string whereCondition = string.Empty;
                string Qry = @"select  count ( AD.ApplicationNo) as TotalPending,  rstateid,StateName from ApplicationDetails AD inner join applicationverificationletterdetails AVLD on AVLD.Applicationno=AD.Applicationno 
                            inner join (select applicationno,rstateid from drev.applicationdetailsobc where rstateid is not null and rstateid<>@StateId union all
                            select applicationno,rstateid from drev.applicationdetailsscst where rstateid is not null and rstateid<>@StateId union all
                            select applicationno,rstateid from drev.applicationdetailsst where rstateid is not null and rstateid<>@StateId) ADST on ADST.Applicationno=AD.Applicationno 
                            inner join StateMaster SM on SM.StateId=ADST.rstateid
                            inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode
                            inner join SubDivMaster SDM on SDM.SubDivCode=AD.ApplicationSubDivCode
                            where TypeValueId=@TypeValueId and ApplicationStatusId=@ApplicationStatusId  ";
                if (string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode))
                {
                    if (!string.IsNullOrEmpty(model.ApplicantDistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode "; }
                    if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry += " and SDM.SubDivCode in (@ParamSubDivCode) "; }
                }
                Qry += " group by rstateid,StateName order by TotalPending";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                if (string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode))
                {
                    cmd.Parameters.AddWithValue("@ParamDistrictCode", model.ApplicantDistrictCode);
                    cmd.Parameters.AddWithValue("@ParamSubDivCode", model.ApplicationSubDivCode);
                }

                cmd.Parameters.AddWithValue("@TypeValueId", (int)ValueId.OtherStateLetter);
                cmd.Parameters.AddWithValue("@StateId", (int)State.Delhi);
                cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.VERLOTHS);
                model.data = data.GetDataTable(cmd);
            }
            return View("DistWiseOtherStateVerReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult ApplicationDetailsOtherStateVer(int StateId, int? DistCode, int? SubDivCode)
        {
            string statusId = string.Empty;
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = @"select AD.Applicationno,ApplicantName,to_char(ApplicantDob,'DD/MM/YYYY') as ApplicantDob, ApplicantFatherName,ApplicantMobileNo,ServiceName,to_char(GenerateDate,'DD/MM/YYYY') as GeneratedDate from ApplicationDetails AD inner join applicationverificationletterdetails AVLD on AVLD.Applicationno=AD.Applicationno 
                            inner join (select applicationno,rstateid from drev.applicationdetailsobc where rstateid is not null and rstateid<>7 union all
                            select applicationno,rstateid from drev.applicationdetailsscst where rstateid is not null and rstateid<>7 union all
                            select applicationno,rstateid from drev.applicationdetailsst where rstateid is not null and rstateid<>7) ADST on ADST.Applicationno=AD.Applicationno 
                            inner join StateMaster SM on SM.StateId=ADST.rstateid
                            inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode
                            inner join SubDivMaster SDM on SDM.SubDivCode=AD.ApplicationSubDivCode
                            inner join ServiceMaster SR on SR.ServiceCode=AD.ServiceCode
                            where TypeValueId=@TypeValueId and ApplicationStatusId=@ApplicationStatusId and rstateid =@StateId  ";
            if (DistCode != null)
            {
                Qry += " and DM.DistrictCode=@ParamDistrictCode  ";
            }
            if (SubDivCode != null)
            {
                Qry += " and SDM.SubDivCode in (@ParamSubDivCode) ";
            }
            Qry += " order by AD.Applicationno";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);

            cmd.Parameters.AddWithValue("@TypeValueId", (int)ValueId.OtherStateLetter);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.VERLOTHS);

            cmd.Parameters.AddWithValue("@StateId", StateId);
            cmd.Parameters.AddWithValue("@ParamDistrictCode", DistCode);
            cmd.Parameters.AddWithValue("@ParamSubDivCode", SubDivCode);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult CitizenPublicAuditTrail()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select AD.ServiceCode,ServiceName,Count(ApplicationNo) as TotalApp ,Count(ApplicationNo) as TotalAppProcessed,coalesce(sum(case when AD.ApplicationStatusId in (@CANCEL,@ISSUCER,@TEHSREJ) then 1 end),0) as Disposed,coalesce(sum(case when AD.ApplicationStatusId not in (@CANCEL,@ISSUCER,@TEHSREJ) then 1 end),0) as Pending,case when AD.servicecode=@Mutation then @MutationEffectDate else @NocEffectDate end as effectdate from applicationdetails AD inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode  where AD.servicecode in (@Mutation,@NOC) group by  AD.ServiceCode,ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@Mutation", (int)ServiceList.Mutation);
            cmd.Parameters.AddWithValue("@NOC", (int)ServiceList.NOC);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@MutationEffectDate", "28/04/2017");
            cmd.Parameters.AddWithValue("@NocEffectDate", "13/09/2016");
            model.data = data.GetDataTable(cmd);

            Qry = "select 'Revenue Court Cases' as ServiceName, count(trailId) as TotalApp, sum(case when whetherprocessed=true then 1 else 0 end) as TotalAppProcessed,@effectdate as effectdate from citizenpublicaudittrail ";
            cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@effectdate", "16/06/2017");
            model.dataa = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult CitizenPublicAuditTrailList(Int32 service, Int32 status, int? PageIndex = 1)
        {
            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "service=" + service.ToString());
            Parameters.Add(1, "status=" + status.ToString());

            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                GetData data = new GetData();
                string strStatus = string.Empty;
                if (status == 1)
                { strStatus = " and AD.ApplicationStatusId not in (@CANCEL,@ISSUCER,@TEHSREJ)"; }
                else if (status == 2)
                { strStatus = " and AD.ApplicationStatusId in (@CANCEL,@ISSUCER,@TEHSREJ)"; }


                string Qry = @"select DM.districtname,SD.subdivdescription,case when AD.ApplicationStatusId in (@TEHSREJ) then 1 else 0 end as RejectionFlag,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,SR.ServiceName,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,SL.StatusName,AD.LastActionDate,case when AD.rejectionreasoncode=@OtherReason then AD.applicationremarks else RE.reasondetail end as rejectionreason,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress  from dbo.ApplicationDetails AD left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode left outer join reasonmaster RE on RE.reasoncode=AD.rejectionreasoncode inner join subdivmaster SD on SD.subdivcode=AD.applicationsubdivcode inner join districtmaster DM on DM.districtcode=AD.applicationdistrictcode where AD.ServiceCode=@ServiceCode " + strStatus + " order by AD.ApplicantName";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@ServiceCode", service);
                cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
                cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
                cmd.Parameters.AddWithValue("@OtherReason", (int)RejectionReason.Other);
                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "CitizenPublicAuditTrailList", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "CitizenPublicAuditTrailList", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult IssuedObcCasteDetails()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult IssuedObcCasteDetails(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("IssuedObcCasteDetailsView", "Report", new { q = QueryString });
            }
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult IssuedObcCasteDetailsView(string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,d.stateid,d.StateName,UPPER(trim(lower(c.casteName))) as CasteName,sum(case when b.whethercentrecaste=FALSE then 1 else 0 end) as isstate ,sum(case when b.whethercentrecaste=TRUE then 1 else 0 end) as iscentre,(COALESCE(sum(case when b.whethercentrecaste=FALSE then 1 else 0 end))+ sum(case when b.whethercentrecaste=TRUE then 1 else 0 end)) as TotalReceived from applicationdetails a inner join drev.applicationdetailsobc b on b.applicationno=a.applicationno  inner join castemaster c on c.casteid=b.casteid inner join statemaster d on  d.stateId=b.stateid where applicationstatusid =@applicationstatusid and a.servicecode =@servicecode and a.lastactiondate between @FromDate and @ToDate ";
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(A.LastActionDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(A.LastActionDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by d.stateid,d.StateName,upper(trim(lower(c.CasteName))) Order by d.StateName,upper(trim(lower(c.casteName)))";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@servicecode", (int)ServiceList.OBC);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View("IssuedObcCasteDetails", model);

        }
        [HttpGet]
        public ActionResult DownloadRevenueReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult DownloadRevenueReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string DTF = model.ServiceDateFrom, DTT = model.ServiceDateTo;

                string Qry = "select SM.ServiceName as \"Service Name\",AD.ApplicationNo as \"Certificate No.\",Applicantname as \"Applicant Name\",ApplicantGender as \"Gender\",ApplicantFatherName as \"Father Name\",ApplicantMotherName as \"Mother Name\",ApplicantHusbandName as \"Spouse Name\",ApplicantMobileNo as \"Mobile No.\",dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as Address,DM.DistrictName as \"District Name\",SDM.SubDivDescription as \"Subdivision Name\" from dbo.ApplicationDetails AD right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SDM on AD.applicationsubdivcode=SDM.subdivcode inner join ServiceMaster SM on SM.ServiceCode=AD.Servicecode where DM.deptcode = @deptcode and DM.stateid = @stateid and AD.ApplicationDistrictcode=@ApplicationDistrictcode and AD.ApplicationSubDivcode=@ApplicationSubDivcode and AD.ServiceCode=@ServiceCode and AD.applicationstatusid=@applicationstatusid";
                if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
                if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
                Qry += " group by AD.ApplicationNo,SM.ServiceName,SDM.SubDivDescription,DM.DistrictCode,DM.DistrictName order by DM.DistrictName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
                Cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
                Cmd.Parameters.AddWithValue("@Deptcode", Sessions.getEmployeeUser().DeptCode);
                Cmd.Parameters.AddWithValue("@ApplicationDistrictcode", model.DistrictCode);
                Cmd.Parameters.AddWithValue("@applicationstatusid", (int)Status.ISSUCER);
                Cmd.Parameters.AddWithValue("@ApplicationSubDivcode", model.ApplicantSubDivCode);
                Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                Cmd.Parameters.AddWithValue("@Stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
                Cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
                DataTable dt = new DataTable();
                dt = data.GetDataTable(Cmd);

                var grid = new System.Web.UI.WebControls.GridView();
                grid.DataSource = dt;
                grid.DataBind();
                Response.ClearContent();
                Response.AddHeader("content-disposition", "attachment; filename=Edistrict_Report_" + System.DateTime.Now.ToString("yyyyMMdd_hhmmss") + ".xls");
                Response.ContentType = "application/excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                grid.RenderControl(htw);
                Response.Write(sw.ToString());
                Response.End();
            }
            return RedirectToAction("DownloadRevenueReport");
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult NULMReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult NULMReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string whereCondition = string.Empty;

                string Qry = @"select AD.applicationsubdivcode,SM.SubDivDescription,DM.DistrictCode, DM.DistrictName,c.servicecode,c.servicename,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo, dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,SL.StatusName from applicationdetails AD inner join servicemaster c on c.servicecode=AD.servicecode  inner join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId  inner join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode  inner join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode  inner join drev.applicationdetailsincome ADI on ADI.applicationno = AD.applicationno  where AD.servicecode=@servicecode and ADI.pforcertificateid=@pforcertificateid and  AD.ApplicationDistrictCode=ApplicationDistrictCode and AD.ApplicationSubDivCode=@ApplicationSubDivCode ";
                if (model.StatusId == "0") { Qry += " and AD.applicationstatusid NOT IN (" + (int)Status.CANCEL + "," + (int)Status.ISSUCER + "," + (int)Status.TEHSREJ + ")"; }
                if (model.StatusId == ((int)Status.ISSUCER).ToString() || model.StatusId == ((int)Status.CANCEL).ToString() || model.StatusId == ((int)Status.TEHSREJ).ToString()) { Qry += " and AD.applicationstatusid=@applicationstatusid"; }
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@servicecode", (int)ServiceList.Income);
                cmd.Parameters.AddWithValue("@ApplicationDistrictCode", model.ApplicantDistrictCode);
                cmd.Parameters.AddWithValue("@ApplicationSubDivCode", model.ApplicantSubDivCode);
                cmd.Parameters.AddWithValue("@pforcertificateid", (int)ValueId.pForCertificateId);
                cmd.Parameters.AddWithValue("@applicationstatusid", model.StatusId);
                model.data = data.GetDataTable(cmd);
            }
            return View("NULMReport", model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult IssuedEdistrictApplication()
        {
            ReportModels model = new ReportModels();
            //NpgsqlCommand cmd = new NpgsqlCommand("select to_char(max(applicationdate),'DD/MM/YYYY HH24:MI:SS') as lastupdatedate from dstc.scheduledapplicationdetails");
            //ViewBag.LastUpdateDate = new GetData().SelectColumns(cmd)[0];
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult IssuedEdistrictApplication(ReportModels model)
        {
            GetData data = new GetData();

            //string Qry = "select applicationno as  \"Application No.\",applicantname as \"Name of Applicant\",applicantfathername as \"Applicant Father Name\",applicantmothername as \"Applicant Mother Name\",dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantlocalityid,applicantsubdivcode,applicantdistrictcode,stateid,@countryId,applicantpincode) as \"Address of Applicant\",sm.Servicename  as \"Type of Service\",documentname as \"Type of Document\",applicantmobileno  as \"Mobile No.\"  from dstc.scheduledapplicationdetails inner join servicemaster sm using (servicecode) inner join documentmaster dm using (documentid) where applicationdistrictcode=@districtcode and applicationsubdivcode=@subdivcode and sm.deptcode=@deptcode and applicationstatusid=@applicationstatusid and isvalid=@isvalid;";
            string Qry = "select applicationno as  \"Application No.\",applicantname as \"Name of Applicant\",applicantfathername as \"Father Name of Applicant\",sm.Servicename  as \"Type of Service\",documentname as \"Document Type for Registration\",'XXXXXXX' || right(applicantmobileno,3) as  \"Applicant Mobile No.\" from applicationdetails inner join servicemaster sm using (servicecode) inner join documentmaster dm using (documentid) where applicationdistrictcode=@districtcode and applicationsubdivcode=@subdivcode and sm.deptcode=@deptcode and applicationstatusid=@applicationstatusid";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@countryId", (int)CountList.Type001);
            cmd.Parameters.AddWithValue("@deptcode", (int)CountList.Type001);
            cmd.Parameters.AddWithValue("@applicationstatusid", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@isvalid", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@districtcode", model.ApplicantDistrictCode);
            cmd.Parameters.AddWithValue("@subdivcode", model.ApplicantSubDivCode);
            DataTable dt = data.GetDataTable(cmd);

            if (dt.Rows.Count > 0)
            {
                var grid = new System.Web.UI.WebControls.GridView();
                grid.DataSource = dt;
                grid.DataBind();
                Response.Clear();
                Response.AddHeader("content-disposition", "attachment; filename=ApplicationDetails.xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.xls";
                System.IO.StringWriter stringWrite = new System.IO.StringWriter();
                System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
                grid.RenderControl(htmlWrite);
                string style = @"<style> td { mso-number-format:\@; } </style>";
                Response.Write(style);
                Response.Write(stringWrite.ToString());
                Response.End();
            }
            else
            {
                ViewData["message"] = "No data found for selected criteria...!!!";
                return View("message");
            }

            ViewData["message"] = "File Downloaded Sucessfully on selected criteria...!!!";
            return View("Message");
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult CasteWiseReport()
        {
            ReportModels model = new ReportModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult CasteWiseReport(ReportModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,DM.DistrictCode,DM.DistrictName,SDM.SubDivCode,subdivdescription,coalesce(count(AD.ApplicationNo),0) Received,coalesce(sum(case when AD.ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) then 1 end),0) as Pendingintime,coalesce(sum(case when AD.ApplicationStatusId=@ISSUCER then 1 end),0) as Disposed,coalesce(sum(case when AD.ApplicationStatusId in(@TEHSREJ) then 1 end),0) as rejected,coalesce(sum(case when AD.ApplicationStatusId=@CANCEL then 1 end),0) as canceled from dstc.scheduledstaticdata AD ";
                if (Convert.ToInt32(model.ServiceId) == (int)ServiceList.OBC) { Qry += " inner join drev.applicationdetailsobc ADCaste on ADCaste.ApplicationNo=AD.ApplicationNo "; }
                else if (Convert.ToInt32(model.ServiceId) == (int)ServiceList.SCST) { Qry += " inner join drev.applicationdetailsscst ADCaste on ADCaste.ApplicationNo=AD.ApplicationNo "; }
                if (Convert.ToInt32(model.ServiceId) == (int)ServiceList.ST) { Qry += " inner join drev.applicationdetailsst ADCaste on ADCaste.ApplicationNo=AD.ApplicationNo "; }
                Qry += " inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode right outer join dbo.SubDivMaster SDM on AD.SubDivCode=SDM.SubDivCode  where DM.deptcode=@ParamDeptCode and AD.servicecode=@ServiceCode and ADCaste.StateId=@StateId and ADCaste.CasteId=@CasteId ";
                if (Convert.ToInt32(model.ServiceId) == (int)ServiceList.OBC) { Qry += " and ADCaste.WhetherCentreCaste=@WhetherCentreCaste "; }
                if (!string.IsNullOrEmpty(model.DateFrom)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
                if (!string.IsNullOrEmpty(model.DateTo)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
                Qry += " group by AD.districtcode,DM.DistrictCode,DM.DistrictName,SDM.SubDivCode,subdivdescription order by DM.DistrictName,subdivdescription";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
                cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
                cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceId);
                cmd.Parameters.AddWithValue("@StateId", model.StateCode);
                cmd.Parameters.AddWithValue("@WhetherCentreCaste", model.WhetherCentreCaste);
                cmd.Parameters.AddWithValue("@CasteId", model.CasteId);
                cmd.Parameters.AddWithValue("@DisplayFromDate", model.DateFrom);
                cmd.Parameters.AddWithValue("@DisplayToDate", model.DateTo);
                cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(model.DateFrom, '/', true));
                cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(model.DateTo, '/', true));
                model.data = data.GetDataTable(cmd);

                Qry = "select CasteName,StateName,resolutionno,resolutiondate,whethercentrecaste,cresolutionno,cresolutiondate  from castemaster CM inner join StateMaster SM on SM.StateId=CM.StateId where casteid =@CasteId";
                cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@CasteId", model.CasteId);
                model.dataa = data.GetDataTable(cmd);

                model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.ScheduledStaticData);
            }
            return View("CasteWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult CasteWiseDetailsReport(int TypeId, int DistrictCode, int SubDivCode, int ServiceCode, int CasteId, int StateId, string WhetherCentreCaste, string DTF, string DTT, int? PageIndex = 1)
        {
            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "TypeId=" + TypeId.ToString());
            Parameters.Add(1, "DistrictCode=" + DistrictCode.ToString());
            Parameters.Add(2, "SubDivCode=" + SubDivCode.ToString());
            Parameters.Add(3, "ServiceCode=" + ServiceCode.ToString());
            Parameters.Add(4, "CasteId=" + CasteId.ToString());
            Parameters.Add(5, "StateId=" + StateId.ToString());
            if (!string.IsNullOrEmpty(WhetherCentreCaste)) { Parameters.Add(6, "WhetherCentreCaste=" + WhetherCentreCaste.ToString()); }
            if (!string.IsNullOrEmpty(DTF)) { Parameters.Add(7, "DTF=" + DTF.ToString()); }
            if (!string.IsNullOrEmpty(DTT)) { Parameters.Add(8, "DTT=" + DTT.ToString()); }
            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                GetData data = new GetData();
                string statusId = string.Empty, Qry = string.Empty;
                if (TypeId == (int)CountList.Type000) { }
                if (TypeId == (int)CountList.Type001) { statusId = " and AD.ApplicationStatusId not in (@CANCEL,@TEHSREJ,@ISSUCER) "; }
                else if (TypeId == (int)CountList.Type002) { statusId = " and AD.ApplicationStatusId in (@ISSUCER)"; }
                else if (TypeId == (int)CountList.Type003) { statusId = " and AD.ApplicationStatusId in (@TEHSREJ) "; }
                else if (TypeId == (int)CountList.Type004) { statusId = " and AD.ApplicationStatusId in (@CANCEL) "; }


                Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,AD.ApplicationNo,SM.ServiceName,DM.DistrictCode,DM.DistrictName,SDM.SubDivCode,subdivdescription,ApplicantName,SL.StatusName,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate from dstc.scheduledstaticdata AD ";
                if (Convert.ToInt32(ServiceCode) == (int)ServiceList.OBC) { Qry += " inner join drev.applicationdetailsobc ADCaste on ADCaste.ApplicationNo=AD.ApplicationNo "; }
                else if (Convert.ToInt32(ServiceCode) == (int)ServiceList.SCST) { Qry += " inner join drev.applicationdetailsscst ADCaste on ADCaste.ApplicationNo=AD.ApplicationNo "; }
                if (Convert.ToInt32(ServiceCode) == (int)ServiceList.ST) { Qry += " inner join drev.applicationdetailsst ADCaste on ADCaste.ApplicationNo=AD.ApplicationNo "; }

                Qry += " inner join dbo.ServiceMaster SM on AD.servicecode=SM.servicecode right outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode inner join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId right outer join dbo.SubDivMaster SDM on AD.SubDivCode=SDM.SubDivCode  where DM.deptcode=@ParamDeptCode and AD.servicecode=@ServiceCode and ADCaste.StateId=@StateId and ADCaste.CasteId=@CasteId and  AD.SubDivCode=@SubDivCode and  AD.districtcode=@districtcode " + statusId;
                if (Convert.ToInt32(ServiceCode) == (int)ServiceList.OBC) { Qry += " and ADCaste.WhetherCentreCaste=@WhetherCentreCaste "; }
                if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate "; }
                if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate "; }
                Qry += " order by AD.ApplicationNo";


                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
                cmd.Parameters.AddWithValue("@districtcode", DistrictCode);
                cmd.Parameters.AddWithValue("@SubDivCode", SubDivCode);
                cmd.Parameters.AddWithValue("@StateId", StateId);
                cmd.Parameters.AddWithValue("@CasteId", CasteId);
                cmd.Parameters.AddWithValue("@WhetherCentreCaste", WhetherCentreCaste);
                cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
                cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
                cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
                cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
                cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
                cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "CasteWiseDetailsReport", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "CasteWiseDetailsReport", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View(model);
        }

        #endregion 

        #region Social welfare Reports
        public ActionResult CategoryWiseSocialWelafreReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { whereCondition += " and DM.DistrictCode=@ParamDistrictCode"; }

            string Qry = @"select categoryid,categoryname,sum(totalRecveived) as totalRecveived,sum(totalDisposed) as totalDisposed,sum(totalpending) as totalpending from (
                            select CategoryId,CategoryName,coalesce(sum(totalRecveived)::int,0) as totalRecveived,coalesce(sum(totalDisposed)::int,0) as totalDisposed,coalesce(sum(totalpending)::int,0) as totalpending
                             from (select ADHC.CategoryId,CategoryName,count(AD.ApplicationNO) totalRecveived,coalesce(sum(case when ApplicationStatusId=16 then 1 end),0) as totalDisposed,coalesce(sum(case when ApplicationStatusId not in(16,1,14) then 1 end),0) as totalpending from ApplicationDetails AD inner join dgen.applicationdetailshandicapped ADHC on ADHC.ApplicationNO=AD.ApplicationNO inner join categorymaster CM on CM.CategoryId=ADHC.CategoryId inner join DistrictMaster DM  on DM.DistrictCode=AD.ApplicationDistrictCode where servicecode in (2601,2605,2604) " + whereCondition + @" group by ADHC.CategoryId,CategoryName order by CategoryName)a group by CategoryId,CategoryName
                            union all  
                            select CategoryId,CategoryName,coalesce(sum(totalRecveived)::int,0) as totalRecveived,coalesce(sum(totalDisposed)::int,0) as totalDisposed,coalesce(sum(totalpending)::int,0) as totalpending from(
                            select ADHC.CategoryId,CategoryName,count(AD.ApplicationNO) totalRecveived,coalesce(sum(case when ApplicationStatusId=16 then 1 end),0) as totalDisposed,coalesce(sum(case when ApplicationStatusId not in(16,1,14) then 1 end),0) as totalpending from ApplicationDetails AD inner join dgen.applicationdetailsoldage ADHC on ADHC.ApplicationNO=AD.ApplicationNO inner join categorymaster CM on CM.CategoryId=ADHC.CategoryId inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode where servicecode in (2601,2605,2604)  " + whereCondition + @" group by ADHC.CategoryId,CategoryName order by CategoryName) b  group by CategoryId,CategoryName
                            ) rs group by categoryid,categoryname";

            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        public ActionResult DisabilityWiseSocialWelafreReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { whereCondition += " and DM.DistrictCode=@ParamDistrictCode"; }

            string Qry = @"select ADHC.disabilityTypeId,disabilityTypeName,count(AD.ApplicationNO) totalRecveived,coalesce(sum(case when ApplicationStatusId=16 then 1 end),0) as totalDisposed,coalesce(sum(case when ApplicationStatusId not in(16,1,14) then 1 end),0) as totalpending from ApplicationDetails AD inner join dgen.applicationdetailshandicapped ADHC on ADHC.ApplicationNO=AD.ApplicationNO inner join disabilitytypemaster CM on CM.disabilityTypeId=ADHC.disabilityTypeId inner join DistrictMaster DM  on DM.DistrictCode=AD.ApplicationDistrictCode where servicecode in (2601,2605,2604) " + whereCondition + " group by ADHC.disabilityTypeId,disabilityTypeName order by disabilityTypeName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        public ActionResult OccupationSocialWelafreReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { whereCondition += " and DM.DistrictCode=@ParamDistrictCode"; }

            string Qry = @"select OccupationId,OccupationType,coalesce(sum(totalRecveived)::int,0) as totalRecveived,coalesce(sum(totalDisposed)::int,0) as totalDisposed,coalesce(sum(totalpending)::int,0) as totalpending
                         from (select ADHC.OccupationId,OccupationType,count(AD.ApplicationNO) totalRecveived,coalesce(sum(case when ApplicationStatusId=16 then 1 end),0) as totalDisposed,coalesce(sum(case when ApplicationStatusId not in(16,1,14) then 1 end),0) as totalpending from ApplicationDetails AD inner join dgen.applicationdetailshandicapped ADHC on ADHC.ApplicationNO=AD.ApplicationNO inner join OccupationMaster CM on CM.OccupationId=ADHC.OccupationId inner join DistrictMaster DM  on DM.DistrictCode=AD.ApplicationDistrictCode where servicecode in (2601,2605,2604) " + whereCondition + @" group by ADHC.OccupationId,OccupationType order by OccupationType)a group by OccupationId,OccupationType
                            union all  
                        select OccupationId,OccupationType,coalesce(sum(totalRecveived)::int,0) as totalRecveived,coalesce(sum(totalDisposed)::int,0) as totalDisposed,coalesce(sum(totalpending)::int,0) as totalpending from(
                        select ADHC.OccupationId,OccupationType,count(AD.ApplicationNO) totalRecveived,coalesce(sum(case when ApplicationStatusId=16 then 1 end),0) as totalDisposed,coalesce(sum(case when ApplicationStatusId not in(16,1,14) then 1 end),0) as totalpending from ApplicationDetails AD inner join dgen.applicationdetailsoldage ADHC on ADHC.ApplicationNO=AD.ApplicationNO inner join OccupationMaster CM on CM.OccupationId=ADHC.OccupationId inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode where servicecode in (2601,2605,2604) " + whereCondition + @" group by ADHC.OccupationId,OccupationType order by OccupationType) b  group by OccupationId,OccupationType order by OccupationType";

            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [HttpGet]
        public ActionResult ServiceWiseCidrStatus()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select c.servicename,c.servicecode,count(applicationno) as tot,sum(case when b.documentid=1 then 1 else 0 end) as csd,sum(case when b.documentid=1 and b.documentstatusid=58 then 1 else 0 end) as ddv,sum(case when b.documentid=1 and b.documentstatusid=59 then 1 else 0 end) as dnv,sum(case when b.documentid=1 and (b.documentstatusid=61 or b.documentstatusid=87) then 1 else 0 end) as dvp ,sum(case when b.documentid<>1 then 1 else 0 end) as nsd from applicationdetails a inner join web.registrationmaster b on b.registrationid=a.registrationid inner join servicemaster c on c.servicecode=a.servicecode where c.deptcode=@ParamDeptCode group by c.servicename,c.servicecode order by c.servicename";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [HttpGet]
        public ActionResult AadharSeeding()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { whereCondition += " and DM.DistrictCode=@ParamDistrictCode"; }
            string Qry = "select AD.ApplicationNo,AD.ApplicantName,AD.ApplicantMobileNo,AD.ServiceCode,SM.ServiceName,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate from dbo.ApplicationDetails AD left outer join web.RegistrationMaster RM on RM.RegistrationId=AD.RegistrationId left outer join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where Rm.DocumentId<>1 and AD.ServiceCode in (@ParamServiceCode)";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            model.dataS = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult AadharSeedingDetails(Int64 AppNo)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.ApplicantDetails = Utility.GetApplicantDetails(AppNo.ToString(), DB.LS.ToString());
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult AadharSeedingDetailsPost(AdminModels model)
        {
            GetData data = new GetData();
            ViewData["message"] = "Aadhar No has been saved successfully";
            return View("message");
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DistConstituencyWiseReport(string DTF, string DTT)
        {
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { return RedirectToAction("DistConstituencyWiseReport"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,DM.DistrictCode,DM.DistrictName,
                        coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) CSCReceived,
                        coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) CitizenReceived,
                        (coalesce(SUM(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) + coalesce(SUM(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0)) as TotalReceived,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus25,@ApplicationStatus29,@ApplicationStatus32,@ApplicationStatus33) then 1 end),0) as PendingatOperator,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus5) then 1 end),0) as PendingforApproval,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus21) then 1 end),0) as PendingforScruitney,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus3) then 1 end),0) as PendingforphysicallyVerifier,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus16) then 1 end),0) as Applicationgrantedforsanction,
                        coalesce(sum(case when AD.ApplicationStatusId in (@ApplicationStatus12) then 1 end),0) as UnderObjection,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus14) then 1 end),0) as ApplicationRejected,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus1) then 1 end),0) as ApplicationCanceled  
                        from dbo.ApplicationDetails AD right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode  where DM.deptcode = @ParamDeptCode and DM.stateid = @stateid";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by DM.DistrictCode,DM.DistrictName order by DM.DistrictName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@ApplicationSourceId2", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ApplicationStatus25", (int)Status.WEBPENC);
            cmd.Parameters.AddWithValue("@ApplicationStatus29", (int)Status.SCOM029);
            cmd.Parameters.AddWithValue("@ApplicationStatus32", (int)Status.SCOM032);
            cmd.Parameters.AddWithValue("@ApplicationStatus33", (int)Status.SCOM033);
            cmd.Parameters.AddWithValue("@ApplicationStatus5", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@ApplicationStatus3", (int)Status.VERSENT);
            cmd.Parameters.AddWithValue("@ApplicationStatus21", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@ApplicationStatus12", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DistConstituencyWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("DistConstituencyWiseReport", "Report", new { q = QueryString });
            }
            return View("DistConstituencyWiseReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ConstiWiseReport(int? distId, string DTF, string DTT)
        {
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { return RedirectToAction("ConstiWiseReport"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,LCM.constituencyid,ACM.constituencyname,
            coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) CSCReceived,
            coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) CitizenReceived,
            (COALESCE(SUM(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) + COALESCE(SUM(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0)) as TotalReceived,
            coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus25,@ApplicationStatus29,@ApplicationStatus32,@ApplicationStatus33) then 1 end),0) as PendingatOperator,
            coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus5) then 1 end),0) as PendingforApproval,
            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus21) then 1 end),0) as PendingforScruitney,
            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus3) then 1 end),0) as PendingforphysicallyVerifier,
            coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus16) then 1 end),0) as Applicationgrantedforsanction,
            coalesce(sum(case when AD.ApplicationStatusId in (@ApplicationStatus12) then 1 end),0) as UnderObjection,
            coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus14) then 1 end),0) as ApplicationRejected,
            coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus1) then 1 end),0) as ApplicationCanceled  
            from dbo.ApplicationDetails AD 
            inner join dbo.localitymaster LM on LM.localityid=AD.Applicantlocalityid
            inner join localitytoconstituencymaster LCM on LCM.localityid=LM.localityid  and deptcode=@ParamDeptCode 
            inner join assemblyconstituencymaster ACM on ACM.constituencyid = LCM.constituencyid 
            right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode where DM.deptcode=@ParamDeptCode";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (distId != null) { Qry += " and DM.DistrictCode=@DistrictCode"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by LCM.constituencyid,ACM.constituencyname order by ACM.ConstituencyName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DistrictCode", distId);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@ApplicationSourceId2", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ApplicationStatus25", (int)Status.WEBPENC);
            cmd.Parameters.AddWithValue("@ApplicationStatus29", (int)Status.SCOM029);
            cmd.Parameters.AddWithValue("@ApplicationStatus32", (int)Status.SCOM032);
            cmd.Parameters.AddWithValue("@ApplicationStatus33", (int)Status.SCOM033);
            cmd.Parameters.AddWithValue("@ApplicationStatus5", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@ApplicationStatus3", (int)Status.VERSENT);
            cmd.Parameters.AddWithValue("@ApplicationStatus21", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@ApplicationStatus12", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            if (distId != null)
            {
                Qry = " Select DistrictCode,DistrictName from dbo.DistrictMaster where deptcode=@ParamDeptCode ";
                if (distId != null) { Qry += " and DistrictCode=@DistrictCode"; }
                NpgsqlCommand cmd1 = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd1.Parameters.AddWithValue("@DistrictCode", distId);
                model.dataa = data.GetDataTable(cmd1);

                model.DistrictCode = distId.ToString();
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ConstiWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("ConstiWiseReport", "Report", new { q = QueryString });
            }
            return View("ConstiWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult ConstiServiceWiseReport(int ConstituencyId, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;

            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,LCM.constituencyid,ACM.constituencyname,SC.ServiceCode,SC.ServiceName,
                        coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) CSCReceived,
                        coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) CitizenReceived,
                        (COALESCE(SUM(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) + COALESCE(SUM(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0)) as TotalReceived,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus25,@ApplicationStatus29,@ApplicationStatus32,@ApplicationStatus33) then 1 end),0) as PendingatOperator,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus5) then 1 end),0) as PendingforApproval,
                        coalesce(sum(case when AD.ApplicationStatusId in (@ApplicationStatus12) then 1 end),0) as UnderObjection,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus21) then 1 end),0) as PendingforScruitney,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus3) then 1 end),0) as PendingforphysicallyVerifier,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus16) then 1 end),0) as Applicationgrantedforsanction,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus14) then 1 end),0) as ApplicationRejected,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus1) then 1 end),0) as ApplicationCanceled
                        from dbo.ApplicationDetails AD 
                        inner join dbo.localitymaster LM on LM.localityid=AD.Applicantlocalityid
                        inner join localitytoconstituencymaster LCM on LCM.localityid=LM.localityid and deptcode=@ParamDeptCode
                        inner join assemblyconstituencymaster ACM on ACM.constituencyid = LCM.constituencyid 
                        right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode
                        right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and LCM.ConstituencyId = @ConstituencyId";
            if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by LCM.constituencyid,ACM.constituencyname,SC.ServiceCode,SC.ServiceName order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ConstituencyId", ConstituencyId);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@ApplicationSourceId2", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ApplicationStatus25", (int)Status.WEBPENC);
            cmd.Parameters.AddWithValue("@ApplicationStatus29", (int)Status.SCOM029);
            cmd.Parameters.AddWithValue("@ApplicationStatus32", (int)Status.SCOM032);
            cmd.Parameters.AddWithValue("@ApplicationStatus33", (int)Status.SCOM033);
            cmd.Parameters.AddWithValue("@ApplicationStatus5", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@ApplicationStatus3", (int)Status.VERSENT);
            cmd.Parameters.AddWithValue("@ApplicationStatus21", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@ApplicationStatus12", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            return View("ConstiServiceWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult ConstiApplicationDetails(int? ConstituencyId, int? service, int? status, string DTF, string DTT, int? PageIndex = 1)
        {
            if (ConstituencyId == null && service == null && status == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }
            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "ConstituencyId=" + ConstituencyId.ToString());
            Parameters.Add(1, "service=" + service.ToString());
            Parameters.Add(2, "status=" + status.ToString());
            if (!string.IsNullOrEmpty(DTF)) { Parameters.Add(3, "DTF=" + DTF.ToString()); }
            if (!string.IsNullOrEmpty(DTT)) { Parameters.Add(4, "DTT=" + DTT.ToString()); }
            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                GetData data = new GetData();
                string statusId = string.Empty, Qry = string.Empty;
                if (status == 8) { statusId = " and AD.ApplicationStatusId =@ApplicationStatus14"; }
                else if (status == 1) { statusId = " and AD.ApplicationStatusId in(@ApplicationStatus25,@ApplicationStatus29,@ApplicationStatus32,@ApplicationStatus33)"; }
                else if (status == 3) { statusId = " and AD.ApplicationStatusId in(@ApplicationStatus21)"; }
                else if (status == 4) { statusId = " and AD.ApplicationStatusId in(@ApplicationStatus3)"; }
                else if (status == 5) { statusId = " and AD.ApplicationStatusId in(@ApplicationStatus5)"; }
                else if (status == 7) { statusId = " and AD.ApplicationStatusId in(@ApplicationStatus16)"; }
                else if (status == 101) { statusId = " and AD.ApplicationStatusId in(@ApplicationStatus1)"; }
                else if (status == 11) { statusId = " and AD.ApplicationSourceId =@ApplicationSourceId1"; }
                else if (status == 13) { statusId = " and AD.ApplicationSourceId =@ApplicationSourceId2"; }
                else if (status == 10) { statusId = " and AD.ApplicationStatusId in(@ApplicationStatus12)"; }

                Qry = "select distinct LCM.constituencyid as constituencyid,ACM.ConstituencyName as ConstituencyName,@DisplayFromDate as FromDate,@DisplayToDate as ToDate,@RejectionFlag as RejectionFlag,to_char(AD.LastActionDate,'DD/MM/YYYY') as LastActionDate,AD.ServiceCode,DM.DistrictCode,DM.DistrictName,AD.ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,case when AD.rejectionreasoncode=@OtherReason then AD.applicationremarks else RE.reasondetail end as rejectionreason from dbo.ApplicationDetails AD left outer join (select distinct applicationno from (select applicationno from verifierapplicationdetails union select applicationno from applicationverificationletterdetails)a) VD on VD.ApplicationNo=AD.ApplicationNo left outer join applicationverificationletterdetails LD on LD.ApplicationNo=AD.ApplicationNo left outer join reasonmaster RE on RE.reasoncode=AD.rejectionreasoncode left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join dbo.localitymaster LM on LM.localityid=AD.Applicantlocalityid inner join localitytoconstituencymaster LCM on LCM.localityid=LM.localityid inner join assemblyconstituencymaster ACM on ACM.constituencyid = LCM.constituencyid inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode where AD.ServiceCode=@ServiceCode and LCM.constituencyid = @ConstituencyId " + statusId;
                if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
                if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
                if (status == 8 || status == 14) { Qry += " order by LastActionDate Desc"; } else { Qry += " order by AD.ApplicationNo"; }

                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ServiceCode", service);
                cmd.Parameters.AddWithValue("@ConstituencyId", ConstituencyId);
                cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
                cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
                cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
                cmd.Parameters.AddWithValue("@ApplicationSourceId2", (int)ApplicationSource.Window);
                cmd.Parameters.AddWithValue("@ApplicationStatus25", (int)Status.WEBPENC);
                cmd.Parameters.AddWithValue("@ApplicationStatus29", (int)Status.SCOM029);
                cmd.Parameters.AddWithValue("@ApplicationStatus32", (int)Status.SCOM032);
                cmd.Parameters.AddWithValue("@ApplicationStatus33", (int)Status.SCOM033);
                cmd.Parameters.AddWithValue("@ApplicationStatus5", (int)Status.TEHSPEN);
                cmd.Parameters.AddWithValue("@ApplicationStatus3", (int)Status.VERSENT);
                cmd.Parameters.AddWithValue("@ApplicationStatus21", (int)Status.DEALOLR);
                cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
                cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
                cmd.Parameters.AddWithValue("@ApplicationStatus12", (int)Status.TEHSOBJ);

                cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
                cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
                cmd.Parameters.AddWithValue("@OtherReason", (int)RejectionReason.Other);
                cmd.Parameters.AddWithValue("@RejectionFlag", status == 14 || status == 8);
                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "ConstiApplicationDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "ConstiApplicationDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DistConstiServiceWiseReport(string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = @" select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SC.ServiceName,SC.ServiceCode,
                        coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) CSCReceived,
                        coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) CitizenReceived,
                        (coalesce(SUM(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) + coalesce(SUM(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0)) as TotalReceived,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus25,@ApplicationStatus29,@ApplicationStatus32,@ApplicationStatus33) then 1 end),0) as PendingatOperator,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus5) then 1 end),0) as PendingforApproval,
                        coalesce(sum(case when AD.ApplicationStatusId in (@ApplicationStatus12) then 1 end),0) as UnderObjection,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus21) then 1 end),0) as PendingforScruitney,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus3) then 1 end),0) as PendingforphysicallyVerifier,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus16) then 1 end),0) as Applicationgrantedforsanction,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus14) then 1 end),0) as ApplicationRejected,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus1) then 1 end),0) as ApplicationCanceled 
                        from dbo.ApplicationDetails AD inner join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode ";
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@ApplicationSourceId2", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ApplicationStatus25", (int)Status.WEBPENC);
            cmd.Parameters.AddWithValue("@ApplicationStatus29", (int)Status.SCOM029);
            cmd.Parameters.AddWithValue("@ApplicationStatus32", (int)Status.SCOM032);
            cmd.Parameters.AddWithValue("@ApplicationStatus33", (int)Status.SCOM033);
            cmd.Parameters.AddWithValue("@ApplicationStatus5", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@ApplicationStatus3", (int)Status.VERSENT);
            cmd.Parameters.AddWithValue("@ApplicationStatus21", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@ApplicationStatus12", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            return View(model);
        }
        [ValidateOnlyIncomingValues]
        public ActionResult DistConstiServiceWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("DistConstiServiceWiseReport", "Report", new { q = QueryString });
            }
            return View("DistConstiServiceWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult DistrictConstiWiseReport(int? service, string DTF, string DTT)
        {
            if (service == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,DM.DistrictCode,DM.DistrictName, SC.ServiceName,SC.ServiceCode,
                        coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) CSCReceived,
                        coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) CitizenReceived,
                        (coalesce(SUM(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) + coalesce(SUM(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0)) as TotalReceived,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus25,@ApplicationStatus29,@ApplicationStatus32,@ApplicationStatus33) then 1 end),0) as PendingatOperator,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus5) then 1 end),0) as PendingforApproval,
                        coalesce(sum(case when AD.ApplicationStatusId in (@ApplicationStatus12) then 1 end),0) as UnderObjection,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus21) then 1 end),0) as PendingforScruitney,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus3) then 1 end),0) as PendingforphysicallyVerifier,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus16) then 1 end),0) as Applicationgrantedforsanction,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus14) then 1 end),0) as ApplicationRejected,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus1) then 1 end),0) as ApplicationCanceled 
                        from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode 
                        right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where AD.ServiceCode = @ServiceCode  ";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += "  group by DM.DistrictName,SC.ServiceCode,SC.ServiceName,DM.DistrictCode order by DM.DistrictName";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@ApplicationSourceId2", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ApplicationStatus25", (int)Status.WEBPENC);
            cmd.Parameters.AddWithValue("@ApplicationStatus29", (int)Status.SCOM029);
            cmd.Parameters.AddWithValue("@ApplicationStatus32", (int)Status.SCOM032);
            cmd.Parameters.AddWithValue("@ApplicationStatus33", (int)Status.SCOM033);
            cmd.Parameters.AddWithValue("@ApplicationStatus5", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@ApplicationStatus3", (int)Status.VERSENT);
            cmd.Parameters.AddWithValue("@ApplicationStatus21", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@ApplicationStatus12", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult DistConstiDetailsReport(int? service, int? dist, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,LCM.constituencyid,ACM.constituencyname,SC.ServiceCode,SC.ServiceName,DM.DistrictCode,DM.DistrictName,
                        coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) CSCReceived,
                        coalesce(sum(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) CitizenReceived,
                        (coalesce(SUM(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) + coalesce(SUM(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0)) as TotalReceived,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus25,@ApplicationStatus29,@ApplicationStatus32,@ApplicationStatus33) then 1 end),0) as PendingatOperator,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus5) then 1 end),0) as PendingforApproval,
                        coalesce(sum(case when AD.ApplicationStatusId in (@ApplicationStatus12) then 1 end),0) as UnderObjection,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus21) then 1 end),0) as PendingforScruitney,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus3) then 1 end),0) as PendingforphysicallyVerifier,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus16) then 1 end),0) as Applicationgrantedforsanction,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus14) then 1 end),0) as ApplicationRejected,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus1) then 1 end),0) as ApplicationCanceled  
                        from dbo.ApplicationDetails AD inner join dbo.localitymaster LM on LM.localityid=AD.Applicantlocalityid
                        inner join localitytoconstituencymaster LCM on LCM.localityid=LM.localityid  and deptcode=@ParamDeptCode 
                        inner join assemblyconstituencymaster ACM on ACM.constituencyid = LCM.constituencyid right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode 
                        right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and SC.ServiceCode = @ServiceCode ";
            if (dist != null) { Qry += " and DM .DistrictCode=@DistrictCode"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += "  group by LCM.constituencyid,ACM.constituencyname,SC.ServiceCode,SC.ServiceName,DM.DistrictCode,DM.DistrictName order by ACM.ConstituencyName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@ApplicationSourceId2", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ApplicationStatus25", (int)Status.WEBPENC);
            cmd.Parameters.AddWithValue("@ApplicationStatus29", (int)Status.SCOM029);
            cmd.Parameters.AddWithValue("@ApplicationStatus32", (int)Status.SCOM032);
            cmd.Parameters.AddWithValue("@ApplicationStatus33", (int)Status.SCOM033);
            cmd.Parameters.AddWithValue("@ApplicationStatus5", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@ApplicationStatus3", (int)Status.VERSENT);
            cmd.Parameters.AddWithValue("@ApplicationStatus21", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@ApplicationStatus12", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@DistrictCode", dist);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            return View(model);
        }
        [HttpGet]
        public ActionResult ConsWiseOldAgeReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = @"select constituencyid,constituencyname,cscreceived,citizenreceived,totalreceived,caplimit-@newcapp as oldreceived,totalreceived - (caplimit-@newcapp) as newreceived,caplimit,caplimit-@newcapp as oldcapp,@newcapp as newcapp,iscapplimitfull from (select LCM.constituencyid,ACM.constituencyname, COALESCE(SUM(case when ApplicationSourceId=@ApplicationSourceId2 then 1 end),0) CSCReceived, COALESCE(SUM(case when ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) CitizenReceived, (COALESCE(SUM(case when ApplicationSourceId=2 then 1 end),0) + COALESCE(SUM(case when ApplicationSourceId=1 then 1 end),0)) as TotalReceived,ACM.CapLimit,CASE When (COALESCE(sum(case when ApplicationSourceId=2 then 1 end),0)+ COALESCE(sum(case when ApplicationSourceId=1 then 1 end),0)) >= ACM.CapLimit then 'Yes' else 'No' end as IsCappLimitFull from dbo.ApplicationDetails AD inner join dbo.localitymaster LM on LM.localityid=AD.Applicantlocalityid inner join localitytoconstituencymaster LCM on LCM.localityid=LM.localityid  and deptcode=@ParamDeptCode  inner join assemblyconstituencymaster ACM on ACM.constituencyid = LCM.constituencyid right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode where AD.ServiceCode = @ServiceCode  and DM.deptcode=@ParamDeptCode";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.districtcode=@ParamDistrictCode"; }
            Qry += " group by LCM.constituencyid,ACM.constituencyname,ACM.CapLimit order by ACM.ConstituencyName) rs";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@ApplicationSourceId2", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.OldAge);
            cmd.Parameters.AddWithValue("@newcapp", (int)CountList.Type500);
            model.data = data.GetDataTable(cmd);

            Qry = @"select a.valuename as usertype,@staticcap as caplimit,coalesce(b.appcount,0) as appcount,case when coalesce(b.appcount,0) >= @staticcap then 'Yes' else 'No' end as IsCappLimitFull from selectmastervaluedetails a left outer join (select officecode,count(applicationno) as appcount from applicationdetails where servicecode=@Oldage and receivedpermission=@CscUser and officecode in (@CmUser,@MinUser) ";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and applicationdistrictcode=@ParamDistrictCode"; }
            Qry += " group by officecode) b on b.officecode=a.valueid where a.valueid in (@CmUser,@MinUser)";
            cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@staticcap", (int)CountList.Type500);
            cmd.Parameters.AddWithValue("@Oldage", (int)ServiceList.OldAge);
            cmd.Parameters.AddWithValue("@CscUser", (int)Permission.WIND);
            cmd.Parameters.AddWithValue("@CmUser", (int)ValueId.AuthorizationDeoForCM);
            cmd.Parameters.AddWithValue("@MinUser", (int)ValueId.AuthorizationDeoForMin);
            model.dataa = data.GetDataTable(cmd);

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult SWDDownloadStaticData()
        {
            ReportModels model = new ReportModels();
            //model.dataS = Utility.GetLastUpdateDateForReport((int)ValueId.SWScheduledStaticData);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SWDDownloadStaticData(ReportModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                //string Qry = @"select AD.userid as ""Entered User Id(form_entered_through_User_Id)"",username as ""Entered User Name"", designation as ""Designation"",SM.ServiceName as ""Service Name"",constituencyid as ""Constituency(Id)"",applicationno as ""Application Number"",ApplicantName as ""Applicant Name"",applicantaddress as ""Address"",applicationdate as ""Application Date"",StatusName as ""Current Status"",pendingdays as ""Pending_days/Processing Days"",objectiondate as ""Date on which query Raised"",applicationremarks as ""Reason Remarks"" from dstc.swscheduledstaticdata AD inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join StatusMaster SMM on SMM.StatusId=AD.applicationstatusid";
                string Qry = @"select userid as ""Entered User Id(form_entered_through_User_Id)"",username as ""Entered User Name"", designation as ""Designation"",ServiceName as ""Service Name"",constituencyid as ""Constituency(Id)"",applicationno as ""Application Number"",ApplicantName as ""Applicant Name"",applicantaddress as ""Address"",applicationdate as ""Application Date"",StatusName as ""Current Status"",pendingdays as ""Pending_days/Processing Days"",applicationremarks as ""Reason Remarks"" from dstc.vw_swdapplicationstatusdetails where ServiceCode=@ServiceCode and to_char(Applicationdate,'yyyymmdd')::int between  @FromDate and  @ToDate";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ServiceCode", model.ReqServiceCode);
                cmd.Parameters.AddWithValue("@FromDate", Convert.ToInt32(Utility.ConvertDateSequenceForDatabase(model.ReqDateFrom, '/', true)));
                cmd.Parameters.AddWithValue("@ToDate", Convert.ToInt32(Utility.ConvertDateSequenceForDatabase(model.ReqDateTo, '/', true)));
                model.data = data.GetDataTable(cmd);
                if (model.data.Rows.Count > 0)
                {
                    var grid = new System.Web.UI.WebControls.GridView();
                    grid.DataSource = model.data;
                    grid.DataBind();
                    Response.Clear();
                    Response.AddHeader("content-disposition", "attachment; filename=CitizenWiseApplication.xls");
                    Response.Charset = "";
                    Response.ContentType = "application/vnd.xls";
                    System.IO.StringWriter stringWrite = new System.IO.StringWriter();
                    System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
                    grid.RenderControl(htmlWrite);
                    string style = @"<style> td { mso-number-format:\@; } </style>";
                    Response.Write(style);
                    Response.Write(stringWrite.ToString());
                    Response.End();

                    ViewData["message"] = "File Downloaded Successfully";
                    return View("message");
                }
                else
                {
                    ViewData["message"] = "No Record Found";
                    return View("message");
                }
            }
            return View(model);

        }
        #endregion

        #region Higher Education ReportS
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DistWiseHEReport(string DTF, string DTT, int? ApplicationDistrictCode = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;

            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { whereCondition += " and LoanBankId=@ParamAuthorizationId "; }
            if (Convert.ToInt32(ApplicationDistrictCode) != (int)CountList.Type000) { whereCondition += " and AD.ApplicationDistrictCode=@ApplicationDistrictCode "; }
            if (!string.IsNullOrEmpty(DTF)) { whereCondition += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { whereCondition += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,AD.ApplicationDistrictCode,DistrictName ,Count(AD.ApplicationNo) as TotalApplication,coalesce(sum(case when WhetherDocumentShown=true then 1 end),0) as physicallyreceived,coalesce(sum(case when ApplicationStatusId not in (@CANCEL) and WhetherDocumentShown=false then 1 end),0) as PendingDocSeen,coalesce(sum(case when ApplicationStatusId in (@CANCEL) and WhetherDocumentShown=false then 1 end),0) as CancelPendingDocSeen,coalesce(sum(case when ApplicationStatusId=@DEALOLR and WhetherDocumentShown=true then 1 end),0) as PendingDecision,coalesce(sum(case when ApplicationStatusId=@TEHSREJ then 1 end),0) as Rejected,coalesce(sum(case when ApplicationStatusId=@CANCEL  and WhetherDocumentShown=true then 1 end),0) as Canceled,coalesce(sum(case when ApplicationStatusId=@TEHSREC then 1 end),0) as Approved,coalesce(sum(ApproveLoanAmount),0) as LoanAmountSanction,sum(case when installmentcount>0 then 1 else 0 end) AS disbursal,coalesce(sum(disbursalAmount),0) as disbursalAmount from ApplicationDetails AD inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNO=AD.ApplicationNo inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join SubDivMaster SDM on SDM.SubDIvCode=AD.ApplicationSubDIvCode left outer join (select applicationno,sum(disbursalAmount) as disbursalAmount from dgen.hedisbursaldetails group by applicationno) HDD on HDD.ApplicationNo=HSDS.ApplicationNo where 1=1 " + whereCondition + "  group by AD.ApplicationDistrictCode,DistrictName order by  DistrictName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@SERVICECODE", (int)ServiceList.HigherEducationSKGS);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            if (Convert.ToInt32(ApplicationDistrictCode) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@ApplicationDistrictCode", ApplicationDistrictCode); }
            model.data = data.GetDataTable(cmd);
            model.DistrictCode = ApplicationDistrictCode.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DistWiseHEReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int ApplicationDistrictCode = 0;
                if (!string.IsNullOrEmpty(model.DistrictCode)) { ApplicationDistrictCode = Convert.ToInt32(model.DistrictCode); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT", "ApplicationDistrictCode" }, new ArrayList() { model.DateFrom, model.DateTo, ApplicationDistrictCode });
                return RedirectToAction("DistWiseHEReport", "Report", new { q = QueryString });
            }
            return View("DistWiseHEReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult BankWiseHEReport(string DTF, string DTT, int? LoanBankId = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { whereCondition += " and LoanBankId=@ParamAuthorizationId "; }
            if (Convert.ToInt32(LoanBankId) != (int)CountList.Type000) { whereCondition += " and LoanBankId=@LoanBankId "; }
            if (!string.IsNullOrEmpty(DTF)) { whereCondition += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { whereCondition += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            string Qry = "select  @DisplayFromDate as FromDate,@DisplayToDate as ToDate,HeBankCode,BankName ,Count(AD.ApplicationNo) as TotalApplication,coalesce(sum(case when WhetherDocumentShown=true then 1 end),0) as physicallyreceived,coalesce(sum(case when ApplicationStatusId not in (@CANCEL) and WhetherDocumentShown=false then 1 end),0) as PendingDocSeen,coalesce(sum(case when ApplicationStatusId in (@CANCEL) and WhetherDocumentShown=false then 1 end),0) as CancelPendingDocSeen,coalesce(sum(case when ApplicationStatusId=@DEALOLR and WhetherDocumentShown=true then 1 end),0) as PendingDecision,coalesce(sum(case when ApplicationStatusId=@TEHSREJ then 1 end),0) as Rejected,coalesce(sum(case when ApplicationStatusId=@CANCEL  and WhetherDocumentShown=true then 1 end),0) as Canceled,coalesce(sum(case when ApplicationStatusId=@TEHSREC then 1 end),0) as Approved,coalesce(sum(ApproveLoanAmount),0) as LoanAmountSanction,sum(case when installmentcount>0 then 1 else 0 end) AS disbursal,coalesce(sum(disbursalAmount),0) as disbursalAmount from ApplicationDetails AD inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNO=AD.ApplicationNo inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join SubDivMaster SDM on SDM.SubDIvCode=AD.ApplicationSubDIvCode Right Outer join HeBankMaster HBM on HBM.HeBankCode=HSDS.LoanBankId left outer join (select applicationno,sum(disbursalAmount) as disbursalAmount from dgen.hedisbursaldetails group by applicationno) HDD on HDD.ApplicationNo=HSDS.ApplicationNo where 1=1 " + whereCondition + " group by HeBankCode,BankName order by  BankName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@SERVICECODE", (int)ServiceList.HigherEducationSKGS);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            if (Convert.ToInt32(LoanBankId) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@LoanBankId", LoanBankId); }

            model.data = data.GetDataTable(cmd);
            model.LoanBankId = LoanBankId.ToString();
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { model.LoanBankId = Sessions.getEmployeeUser().AuthorizationId; }

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult BankWiseHEReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int LoanBankId = 0;
                if (!string.IsNullOrEmpty(model.LoanBankId)) { LoanBankId = Convert.ToInt32(model.LoanBankId); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT", "LoanBankId" }, new ArrayList() { model.DateFrom, model.DateTo, LoanBankId });
                return RedirectToAction("BankWiseHEReport", "Report", new { q = QueryString });
            }
            return View("BankWiseHEReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult MonthWiseHEReport(string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { whereCondition += " and LoanBankId=@ParamAuthorizationId "; }
            if (!string.IsNullOrEmpty(DTF)) { whereCondition += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { whereCondition += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,a.ApplicationDateMonth,to_char(to_timestamp(a.ApplicationDateMonth::text, 'MM'), 'Month') as ShortMonth ,coalesce(TotalApplication,0) as TotalApplication,coalesce(physicallyreceived,0) as physicallyreceived ,coalesce(PendingDocSeen,0) as PendingDocSeen ,coalesce(CancelPendingDocSeen,0) as CancelPendingDocSeen ,coalesce(PendingDecision,0) as PendingDecision, coalesce(Rejected,0) as Rejected ,coalesce(Canceled,0) as Canceled ,coalesce(Approved,0) as Approved ,coalesce(LoanAmountSanction,0) as LoanAmountSanction ,coalesce(disbursal,0) as disbursal ,coalesce(disbursalAmount,0) as disbursalAmount  from (select Extract(month from generate_series('2015-01-01'::timestamp, '2015-12-01'::timestamp, interval '1 month')) as ApplicationDateMonth) a left outer join  (select Extract(month from AD.ApplicationDate)as ApplicationDateMonth,Count(AD.ApplicationNo) as TotalApplication,coalesce(sum(case when WhetherDocumentShown=true then 1 end),0) as physicallyreceived,coalesce(sum(case when ApplicationStatusId not in (@CANCEL) and WhetherDocumentShown=false then 1 end),0) as PendingDocSeen,coalesce(sum(case when ApplicationStatusId in (@CANCEL) and WhetherDocumentShown=false then 1 end),0) as CancelPendingDocSeen,coalesce(sum(case when ApplicationStatusId=@DEALOLR and WhetherDocumentShown=true then 1 end),0) as PendingDecision,coalesce(sum(case when ApplicationStatusId=@TEHSREJ then 1 end),0) as Rejected,coalesce(sum(case when ApplicationStatusId=@CANCEL  and WhetherDocumentShown=true then 1 end),0) as Canceled,coalesce(sum(case when ApplicationStatusId=@TEHSREC then 1 end),0) as Approved,coalesce(sum(ApproveLoanAmount),0) as LoanAmountSanction,sum(case when installmentcount>0 then 1 else 0 end) AS disbursal,coalesce(sum(disbursalAmount),0) as disbursalAmount from ApplicationDetails AD inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNO=AD.ApplicationNo inner join HeBankMaster HBM on HBM.HeBankCode=HSDS.LoanBankId inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join SubDivMaster SDM on SDM.SubDIvCode=AD.ApplicationSubDIvCode left outer join (select applicationno,sum(disbursalAmount) as disbursalAmount from dgen.hedisbursaldetails group by applicationno) HDD on HDD.ApplicationNo=HSDS.ApplicationNo where 1=1 " + whereCondition + " group by ApplicationDateMonth) b on b.ApplicationDateMonth=a.ApplicationDateMonth order by  a.ApplicationDateMonth";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@SERVICECODE", (int)ServiceList.HigherEducationSKGS);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult MonthWiseHEReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("MonthWiseHEReport", "Report", new { q = QueryString });
            }
            return View("MonthWiseHEReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult BankWiseLoanApproval(string DTF, string DTT)
        {
            GetData data = new GetData();
            string whereCondition = string.Empty;
            ReportModels model = new ReportModels();
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { whereCondition += " and LoanBankId=@LoanBankId"; }
            if (!string.IsNullOrEmpty(DTF)) { whereCondition += " and to_char(AD.ApprovedDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { whereCondition += " and to_char(AD.ApprovedDate,'YYYYMMDD')::date <= @ToDate"; }
            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,HeBankCode,BankName ,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId then 1 end),0) as Approved,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId then ApproveLoanAmount end),0) as LoanApproved from ApplicationDetails AD inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNO=AD.ApplicationNo  ";
            Qry += " inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join SubDivMaster SDM on SDM.SubDIvCode=AD.ApplicationSubDIvCode Right Outer join HeBankMaster HBM on HBM.HeBankCode=HSDS.LoanBankId where 1=1 " + whereCondition + " group by HeBankCode,BankName order by  BankName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@LoanBankId", Sessions.getEmployeeUser().AuthorizationId); }
            model.data = data.GetDataTable(cmd);

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult BankWiseLoanApproval(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("BankWiseLoanApproval", "Report", new { q = QueryString });
            }
            return View("BankWiseLoanApproval", model);
        }
        [EncryptedActionParameter]
        public ActionResult HeBankWiseLoanApprovalDetails(string DTF, string DTT, int BankId)
        {
            string statusId = string.Empty;
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = "select to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantMobileNo,coalesce(sum(HFD.LoanAmount),0) as RequiredLoan,coalesce(ApproveLoanAmount,0) as AmountSanctioned,BranchName,BranchContactNo,BranchEmail,BankName,BankContactNo,BankEmail,Extract(month from ApplicationDate) as month ,AD.ServiceCode,SL.StatusName,to_char(AD.LastActiondate,'DD/MM/YYYY') as LastActiondate from ApplicationDetails AD inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNO=AD.ApplicationNo inner join HeBankMaster HBM on HBM.HeBankCode=HSDS.LoanBankId inner join hebankbranchmaster HBBM on HBBM.HeBranchCode=HSDS.BranchId  inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join SubDivMaster SDM on SDM.SubDIvCode=AD.ApplicationSubDIvCode inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId left outer join dgen.hefinancedetails HFD on HFD.ApplicationNo=HSDS.ApplicationNo where 1=1 and ApplicationStatusId=@ApplicationStatusId  and HSDS.LoanBankId in (@BankId)";
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApprovedDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApprovedDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by AD.ApplicationDate,AD.ApplicationNo,SL.StatusName,BranchName,BranchContactNo,BranchEmail,ApproveLoanAmount,BankName,BankContactNo,BankEmail order by  AD.ApplicationDate desc";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@BankId", BankId);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult BankWiseAppApproval()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;
            string Qry = "select HeBankCode,BankName ,coalesce(sum(case when ApplicationStatusId=6 then 1 end),0) as Approved from ApplicationDetails AD inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNO=AD.ApplicationNo inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join SubDivMaster SDM on SDM.SubDIvCode=AD.ApplicationSubDIvCode Right outer join HeBankMaster HBM on HBM.HeBankCode=HSDS.LoanBankId where 1=1 group by HeBankCode,BankName order by  BankName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            model.data = data.GetDataTable(cmd);

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult BankWiseAppApproval(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = "select HeBankCode,BankName ,coalesce(sum(case when ApplicationStatusId=6 then 1 end),0) as Approved from ApplicationDetails AD inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNO=AD.ApplicationNo ";
                if (!string.IsNullOrEmpty(model.Month)) { Qry += " and  Extract(Month from AD.ApprovedDate)=@Month "; }
                if (!string.IsNullOrEmpty(model.Year)) { Qry += " and  Extract(Year from AD.ApprovedDate)=@Year "; }
                Qry += " inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join SubDivMaster SDM on SDM.SubDIvCode=AD.ApplicationSubDIvCode Right outer join HeBankMaster HBM on HBM.HeBankCode=HSDS.LoanBankId where 1=1 group by HeBankCode,BankName order by  BankName";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@Month", model.Month);
                cmd.Parameters.AddWithValue("@Year", model.Year);
                model.data = data.GetDataTable(cmd);
            }
            return View("BankWiseAppApproval", model);
        }
        [EncryptedActionParameter]
        public ActionResult HeApplicationDetails(string DTF, string DTT, int status = 0, int? DistCode = 0, int? BankId = 0, int? CourseId = 0, int? Month = 0, int? InstituteId = 0, int? Year = 0, int? UniversityId = 0, int? StateId = 0, string CollegeName = null)
        {
            string statusId = string.Empty;
            if (status == 1) { statusId = " and ApplicationStatusId=6 "; }
            if (status == 2) { statusId = " and ApplicationStatusId=14 "; }
            if (status == 4) { statusId = " and ApplicationStatusId not in (1) and WhetherDocumentShown=False "; }
            if (status == 5) { statusId = " and WhetherDocumentShown=true "; }
            if (status == 6) { statusId = " and installmentcount>0 "; }
            if (status == 8) { statusId = " and ApplicationStatusId=1 and WhetherDocumentShown=true "; }
            if (status == 9) { statusId = ""; }
            if (status == 10) { statusId = " and ApplicationStatusId in (1) and WhetherDocumentShown=False "; }
            if (status == 11) { statusId = " and ApplicationStatusId=21 and WhetherDocumentShown=true "; }

            if (status == 3) { statusId = " and ApplicationStatusId=21 and WhetherDocumentShown=true "; }
            if (status == 7) { statusId = " and installmentcount<1 and ApplicationStatusId=6 "; }


            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantMobileNo,coalesce(sum(HFD.LoanAmount),0) as RequiredLoan,coalesce(ApproveLoanAmount,0) as AmountSanctioned, BranchName,BranchContactNo,BranchEmail,BankName,BankContactNo,BankEmail,Extract(month from ApplicationDate) as month ,AD.ServiceCode,SL.StatusName,to_char(AD.LastActiondate,'DD/MM/YYYY') as LastActiondate from ApplicationDetails AD inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNO=AD.ApplicationNo inner join HeBankMaster HBM on HBM.HeBankCode=HSDS.LoanBankId inner join hebankbranchmaster HBBM on HBBM.HeBranchCode=HSDS.BranchId inner join HeCourseMaster HCM on HCM.HeCourseId=HSDS.CourseId inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join SubDivMaster SDM on SDM.SubDIvCode=AD.ApplicationSubDIvCode inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId left outer join dgen.hefinancedetails HFD on HFD.ApplicationNo=HSDS.ApplicationNo  where 1=1 " + statusId;

            if (Convert.ToInt32(DistCode) != (int)CountList.Type000) { Qry += " and AD.ApplicationDistrictCode in (@DistrictCode)"; }
            if (Convert.ToInt32(BankId) != (int)CountList.Type000) { Qry += " and HSDS.LoanBankId in (@BankId)"; }
            if (Convert.ToInt32(CourseId) != (int)CountList.Type000) { Qry += " and HSDS.CourseId in (@CourseId)"; }
            if (Convert.ToInt32(Month) != (int)CountList.Type000) { Qry += " and Extract(month from ApplicationDate)=@Month "; }
            if (Convert.ToInt32(Year) != (int)CountList.Type000) { Qry += " and Extract(Year from AD.ApplicationDate)=@Year "; }
            if (Convert.ToInt32(InstituteId) != (int)CountList.Type000) { Qry += "and HSDS.InstitutionId in (@InstituteId) "; }
            if (Convert.ToInt32(UniversityId) != (int)CountList.Type000)
            {
                Qry += "and HSDS.UniversityId in (@UniversityId) ";
                if (Convert.ToInt32(UniversityId) == (int)CountList.Type043)
                {
                    if (Convert.ToInt32(StateId) != (int)CountList.Type000) { Qry += "and HSDS.CollegeState in (@StateId) "; }
                    if (!string.IsNullOrEmpty(CollegeName)) { Qry += "and HSDS.OutUniversityName in (@OutUniversityName) "; }
                }
            }


            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { Qry += " and LoanBankId=@ParamAuthorizationId "; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by AD.ApplicationDate,AD.ApplicationNo,SL.StatusName,BranchName,BranchContactNo,BranchEmail,ApproveLoanAmount,BankName,BankContactNo,BankEmail order by  AD.ApplicationDate desc";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));

            if (Convert.ToInt32(DistCode) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@DistrictCode", DistCode); }
            if (Convert.ToInt32(BankId) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@BankId", BankId); }
            if (Convert.ToInt32(Month) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@Month", Month); }
            if (Convert.ToInt32(Year) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@Year", Year); }
            if (Convert.ToInt32(InstituteId) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@InstituteId", InstituteId); }

            if (Convert.ToInt32(UniversityId) != (int)CountList.Type000)
            {
                cmd.Parameters.AddWithValue("@UniversityId", UniversityId);
                if (Convert.ToInt32(UniversityId) == (int)CountList.Type043)
                {
                    if (Convert.ToInt32(StateId) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@StateId", StateId); }
                    if (!string.IsNullOrEmpty(CollegeName)) { cmd.Parameters.AddWithValue("@OutUniversityName", CollegeName); }
                }
            }

            if (Convert.ToInt32(CourseId) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@CourseId", CourseId); }
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult HeAddedSchoolList(int TypeId)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.Flag = TypeId.ToString();
            string Qry = "select SchoolName, ValueName as SchoolCategory from HeSchoolMaster HSM inner join selectmastervaluedetails SMVD on SMVD.Valueid = HSM.Schoolcategoryid inner join selectmastervalueTodetails SMVTD on SMVTD.Valueid = SMVD.Valueid and mastervalueid = @MasterValueId  where HSM.whetheractive = true order by SchoolCategory,SchoolName";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            if (TypeId == (int)CountList.Type000)
            {
                cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.HigherEducationSchoolCategory);
            }
            else
            {
                cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.HigherEducationSchoolCategory1);
            }

            model.data = data.GetDataTable(cmd);

            return View(model);
        }
        [HttpGet]
        public ActionResult HeAddedBankList()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select BankName,BranchName,BranchAddress,BranchIfscCode from hebankmaster HBM inner join hebankbranchmaster HBBM on HBM.HeBankCode=HBBM.HeBankCode order by BankName,BranchName";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            model.data = data.GetDataTable(cmd);

            return View(model);
        }


        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult HeAddedInstituitonList(int? ServiceCode = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = string.Empty;
            NpgsqlCommand cmd = null;
            if (Convert.ToInt32(Sessions.getEmployeeUser().Permission) == (int)Permission.SDMG)
            {
                Qry = "select UniversityName,InstituitonName,InstitutionAddress,InstitutionEmail,InstitutionContact,NodalOfficer,HM.WhetherActive  from HeInstitutionMaster HM inner join HeUniversityMaster  HUM on HUM.UniversityId=HM.UniversityId Where HUM.UniversityId=@UniversityId and HUM.WhetherActive=true order by UniversityName,InstituitonName";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@UniversityId", Sessions.getEmployeeUser().AuthorizationId);
                model.data = data.GetDataTable(cmd);
            }
            else
            {
                Qry = "select UniversityName,InstituitonName,InstitutionAddress,InstitutionEmail,InstitutionContact,NodalOfficer,HM.WhetherActive  from HeInstitutionMaster HM inner join HeUniversityMaster  HUM on HUM.UniversityId=HM.UniversityId Where ServiceCode=@ServiceCode and HUM.WhetherActive=true order by UniversityName,InstituitonName";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
                model.data = data.GetDataTable(cmd);
            }
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult HeAddedInstituitonList(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int ServiceCode = 0;
                if (!string.IsNullOrEmpty(model.ServiceId)) { ServiceCode = Convert.ToInt32(model.ServiceId); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "ServiceCode" }, new ArrayList() { ServiceCode });
                return RedirectToAction("HeAddedInstituitonList", "Report", new { q = QueryString });
            }
            return View("HeAddedInstituitonList", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult HeAddeduniversityList(int? ServiceCode = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = string.Empty;
            NpgsqlCommand cmd = null;
            if (Convert.ToInt32(Sessions.getEmployeeUser().Permission) == (int)Permission.SDMG)
            {
                Qry = "select UniversityName,universityAddress,universityEmail,universityContactNo,WhetherActive from HeUniversityMaster  HUM Where HUM.UniversityId=@UniversityId order by UniversityName";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@UniversityId", Sessions.getEmployeeUser().AuthorizationId);
                model.data = data.GetDataTable(cmd);
            }
            else
            {
                Qry = "select UniversityName,universityAddress,universityEmail,universityContactNo,WhetherActive from HeUniversityMaster  HUM Where ServiceCode=@ServiceCode order by UniversityName";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
                model.data = data.GetDataTable(cmd);
            }
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult HeAddeduniversityList(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int ServiceCode = 0;
                if (!string.IsNullOrEmpty(model.ServiceId)) { ServiceCode = Convert.ToInt32(model.ServiceId); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "ServiceCode" }, new ArrayList() { ServiceCode });
                return RedirectToAction("HeAddeduniversityList", "Report", new { q = QueryString });
            }
            return View("HeAddeduniversityList", model);
        }


        [HttpGet]
        public ActionResult HeCourseWiseFee()
        {
            GetData data = new GetData();
            string Qry = string.Empty;
            NpgsqlCommand cmd = new NpgsqlCommand();
            ReportModels model = new ReportModels();
            model.HeInstitutionMaster = new HeInstitutionMaster();

            if (Sessions.getEmployeeUser().Permission != ((int)Permission.P120).ToString())
            {

                Qry = "select InstituitonId,InstituitonName from HeuniversityMaster HUM inner join heinstitutionmaster HIM on HIM.UniversityId=HUM.UniversityId where HUM.ServiceCode=@ServiceCode and HIM.WhetherActive=@WhetherActive";
                if (Sessions.getEmployeeUser().Permission == ((int)Permission.SDMG).ToString())
                {
                    Qry += " and HUM.UniversityId=@UniversityId ";
                }
                Qry += " order by InstituitonName ";
                cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@UniversityId", Sessions.getEmployeeUser().AuthorizationId);
                cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.HeFinancialAssistance);
                List<HeInstitutionMaster> HeInstitutionList = HeInstitutionMaster.List<HeInstitutionMaster>(cmd);
                model.HeInstitutionList = new SelectList(HeInstitutionList, "InstituitonId", "InstituitonName");
            }

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult HeCourseWiseFee(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string whereCondition = string.Empty;
                string Qry = "select HUM.UniversityId,UniversityName,InstituitonName,InstitutionAddress,AffiliationCode,CourseName,FeeAmount,HTCF.WhetherActive,WhetherApproved,ApprovedBy,SMVD.ValueName,(academicsession||'-'||academicsession::integer + 1) as academicsession from HeuniversityMaster HUM Left Outer join heinstitutionmaster HIM on HIM.UniversityId = HUM.UniversityId Left Outer join institutetoclassfeesdetails HTCF on HTCF.institutionid = HIM.instituitonid Left Outer join HecourseMaster HM on HM.HeCOurseId = HTCF.HeCOurseId  Left Outer join SelectMasterValueDetails SMVD on SMVD.ValueId=HTCF.hecoursesession where HUM.ServiceCode = @ServiceCode and HIM.instituitonid=@instituitonid and HTCF.AcademicSession=@AcademicSession  order by UniversityName,InstituitonName,CourseName,SMVD.ValueName,academicsession";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.HeFinancialAssistance);
                cmd.Parameters.AddWithValue("@AcademicSession", model.AcademicSession);
                if (Sessions.getEmployeeUser().Permission == ((int)Permission.P120).ToString()) { cmd.Parameters.AddWithValue("@instituitonid", Sessions.getEmployeeUser().AuthorizationId); }
                else { cmd.Parameters.AddWithValue("@instituitonid", model.HeInstitutionMaster.InstituitonId); }
                model.data = data.GetDataTable(cmd);
            }
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.P120).ToString())
            {
                string Qruery = "select InstituitonId,InstituitonName from HeuniversityMaster HUM inner join heinstitutionmaster HIM on HIM.UniversityId=HUM.UniversityId where HUM.ServiceCode=@ServiceCode and HIM.WhetherActive=@WhetherActive";
                if (Sessions.getEmployeeUser().Permission == ((int)Permission.SDMG).ToString()) { Qruery += " and HUM.UniversityId=@UniversityId "; }
                Qruery += " order by InstituitonName ";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qruery));
                Cmd.Parameters.AddWithValue("@UniversityId", Sessions.getEmployeeUser().AuthorizationId);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.HeFinancialAssistance);
                List<HeInstitutionMaster> HeInstitutionList = HeInstitutionMaster.List<HeInstitutionMaster>(Cmd);
                model.HeInstitutionList = new SelectList(HeInstitutionList, "InstituitonId", "InstituitonName");
            }
            return View("HeCourseWiseFee", model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult HeCategoryWiseReport(int? AcademicSession = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;

            string Qry = "select SMVD.ValueId,SMVD.ValueName,count(AD.ApplicationNo) TotalApp,coalesce(sum(case when ApplicationStatusId in (@OBSPEND,@CSCEDT) then 1 end),0) as PendingVerification,coalesce(sum(case when ApplicationStatusId not in (@OBSPEND,@CSCEDT) and whetherrecommended=true then 1 end),0) as PositiveVerification,coalesce(sum(case when ApplicationStatusId not in (@OBSPEND,@CSCEDT) and whetherrecommended=false then 1 end),0) as NegativeVerification,coalesce(sum(case when ApplicationStatusId=@TEHSPEN then 1 end),0) as PendingForApproval,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Approved,coalesce(sum(case when ApplicationStatusId=@TEHSREJ then 1 end),0) as Rejected from ApplicationDetails AD inner join dgen.hemcmfinancialassistance HMFA on HMFA.ApplicationNo=AD.ApplicationNo inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dgen.heapplicationprocess HAP on HAP.ApplicationNo=AD.ApplicationNo right outer join SelectMasterValueDetails SMVD on SMVD.ValueId=HMFA.FinancialAssistanceCategoryId where deptcode=@ParamDeptCode and AD.serviceCode=@SERVICECODE  ";
            if (Sessions.getEmployeeUser().AuthorizationId != ((int)CountList.Type000).ToString()) { Qry += " and (HMFA.universityId in (@ParamAuthorizationId) or HMFA.InstitutionId in (@ParamAuthorizationId)) "; }
            if (AcademicSession != (int)CountList.Type000) { Qry += " and HAP.AcademicSession=@AcademicSession"; }
            Qry += " group by SMVD.ValueId,SMVD.ValueName order by SMVD.ValueId";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@CSCEDT", (int)Status.CSCEDT);
            cmd.Parameters.AddWithValue("@SERVICECODE", (int)ServiceList.HeFinancialAssistance);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult HeCategoryWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AcademicSession" }, new ArrayList() { AcademicSession });
                return RedirectToAction("HeCategoryWiseReport", "Report", new { q = QueryString });
            }
            return View("HeCategoryWiseReport", model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult HeUniversityWiseReport(int? AcademicSession = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;

            string Qry = "select HUM.universityid,HUM.Universityname,count(AD.ApplicationNo) TotalApp,coalesce(sum(case when ApplicationStatusId in(@OBSPEND,@CSCEDT) then 1 end),0) as PendingVerification,coalesce(sum(case when ApplicationStatusId not in (@OBSPEND,@CSCEDT) and whetherrecommended=true then 1 end),0) as PositiveVerification,coalesce(sum(case when ApplicationStatusId not in (@OBSPEND,@CSCEDT) and whetherrecommended=false then 1 end),0) as NegativeVerification,coalesce(sum(case when ApplicationStatusId=@TEHSPEN then 1 end),0) as PendingForApproval,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Approved,coalesce(sum(case when ApplicationStatusId=@TEHSREJ then 1 end),0) as Rejected  from Heuniversitymaster HUM left outer join  dgen.hemcmfinancialassistance HMFA  on HUM.universityid=HMFA.universityid left outer join  ApplicationDetails AD on AD.applicationno=HMFA.applicationno   left outer join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode left outer join dgen.heapplicationprocess HAP on HAP.ApplicationNo=AD.ApplicationNo   where deptcode=@ParamDeptCode and AD.serviceCode=@SERVICECODE ";
            if (Sessions.getEmployeeUser().AuthorizationId != ((int)CountList.Type000).ToString()) { Qry += " and (HMFA.universityId in (@ParamAuthorizationId) or HMFA.InstitutionId in (@ParamAuthorizationId)) "; }
            if (AcademicSession != (int)CountList.Type000) { Qry += " and HAP.AcademicSession=@AcademicSession"; }
            Qry += " group by HUM.universityid,HUM.Universityname order by HUM.Universityname";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@CSCEDT", (int)Status.CSCEDT);
            cmd.Parameters.AddWithValue("@SERVICECODE", (int)ServiceList.HeFinancialAssistance);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult HeUniversityWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AcademicSession" }, new ArrayList() { AcademicSession });
                return RedirectToAction("HeUniversityWiseReport", "Report", new { q = QueryString });
            }
            return View("HeUniversityWiseReport", model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult HeInstituteWiseReport(int UniversityId, int? AcademicSession = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;

            string Qry = "select HUM.universityid,HUM.Universityname,HIM.instituitonid,HIM.instituitonname,count(AD.ApplicationNo) TotalApp,coalesce(sum(case when ApplicationStatusId in(@OBSPEND,@CSCEDT) then 1 end), 0) as PendingVerification,coalesce(sum(case when ApplicationStatusId not in(@OBSPEND,@CSCEDT) and whetherrecommended = true then 1 end), 0) as PositiveVerification,coalesce(sum(case when ApplicationStatusId not in(@OBSPEND,@CSCEDT) and whetherrecommended = false then 1 end), 0) as NegativeVerification,coalesce(sum(case when ApplicationStatusId = @TEHSPEN   then 1 end), 0) as PendingForApproval,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end), 0) as Approved,coalesce(sum(case when ApplicationStatusId=@TEHSREJ then 1 end),0) as Rejected from heinstitutionmaster HIM left outer join Heuniversitymaster HUM on HUM.UniversityId=HIM.UniversityId left outer join  dgen.hemcmfinancialassistance HMFA  on HIM.instituitonid = HMFA.institutionid left outer join ApplicationDetails AD on AD.applicationno = HMFA.applicationno   left outer join ServiceMaster SM on SM.ServiceCode = AD.ServiceCode left outer join dgen.heapplicationprocess HAP on HAP.ApplicationNo = AD.ApplicationNo  where deptcode =@ParamDeptCode and AD.serviceCode = @SERVICECODE and HIM.universityid = @universityid ";
            if (Sessions.getEmployeeUser().AuthorizationId != ((int)CountList.Type000).ToString()) { Qry += " and (HMFA.universityId in (@ParamAuthorizationId) or HMFA.InstitutionId in (@ParamAuthorizationId)) "; }
            if (AcademicSession != (int)CountList.Type000) { Qry += " and HAP.AcademicSession=@AcademicSession"; }
            Qry += " group by HUM.universityid,HUM.Universityname,HIM.instituitonid,HIM.instituitonname order by HIM.instituitonname ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@CSCEDT", (int)Status.CSCEDT);
            cmd.Parameters.AddWithValue("@SERVICECODE", (int)ServiceList.HeFinancialAssistance);
            cmd.Parameters.AddWithValue("@universityid", UniversityId);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();
            return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult HeCasteCategoryWiseReport(int? AcademicSession = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;

            string Qry = "select SMVD.ValueId,SMVD.ValueName,count(AD.ApplicationNo) TotalApp,coalesce(sum(case when ApplicationStatusId in (@OBSPEND,@CSCEDT) then 1 end),0) as PendingVerification,coalesce(sum(case when ApplicationStatusId not in (@OBSPEND,@CSCEDT) and whetherrecommended=true then 1 end),0) as PositiveVerification,coalesce(sum(case when ApplicationStatusId not in (@OBSPEND,@CSCEDT) and whetherrecommended=false then 1 end),0) as NegativeVerification,coalesce(sum(case when ApplicationStatusId=@TEHSPEN then 1 end),0) as PendingForApproval,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Approved,coalesce(sum(case when ApplicationStatusId=@TEHSREJ then 1 end),0) as Rejected from SelectMasterValueDetails SMVD inner join selectmastervaluetodetails SMVTD on SMVTD.ValueId=SMVD.ValueId left outer  join  dgen.hemcmfinancialassistance HMFA on SMVD.ValueId=HMFA.CategoryId left outer join  ApplicationDetails AD on AD.ApplicationNo=HMFA.ApplicationNo left outer join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode left outer join dgen.heapplicationprocess HAP on HAP.ApplicationNo=AD.ApplicationNo where deptcode=@ParamDeptCode and AD.serviceCode=@SERVICECODE and MasterValueId=@MasterValueId ";
            if (Sessions.getEmployeeUser().AuthorizationId != ((int)CountList.Type000).ToString()) { Qry += " and (HMFA.universityId in (@ParamAuthorizationId) or HMFA.InstitutionId in (@ParamAuthorizationId)) "; }
            if (AcademicSession != (int)CountList.Type000) { Qry += " and HAP.AcademicSession=@AcademicSession"; }
            Qry += " group by SMVD.ValueId,SMVD.ValueName order by SMVD.ValueName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@CSCEDT", (int)Status.CSCEDT);
            cmd.Parameters.AddWithValue("@SERVICECODE", (int)ServiceList.HeFinancialAssistance);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.HigherEducationCategory);

            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult HeCasteCategoryWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AcademicSession" }, new ArrayList() { AcademicSession });
                return RedirectToAction("HeCasteCategoryWiseReport", "Report", new { q = QueryString });
            }
            return View("HeCasteCategoryWiseReport", model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult HeCourseWiseReport(int? AcademicSession = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;

            string Qry = "select HeCourseId,CourseName,count(AD.ApplicationNo) TotalApp,coalesce(sum(case when ApplicationStatusId in (@OBSPEND,@CSCEDT) then 1 end),0) as PendingVerification,coalesce(sum(case when ApplicationStatusId not in(@OBSPEND,@CSCEDT) and whetherrecommended=true then 1 end),0) as PositiveVerification,coalesce(sum(case when ApplicationStatusId not in (@OBSPEND,@CSCEDT) and whetherrecommended=false then 1 end),0) as NegativeVerification,coalesce(sum(case when ApplicationStatusId=@TEHSPEN then 1 end),0) as PendingForApproval,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Approved,coalesce(sum(case when ApplicationStatusId=@TEHSREJ then 1 end),0) as Rejected from HeCourseMaster HCM left outer  join  dgen.hemcmfinancialassistance HMFA on HMFA.Courseid=HCM.HeCourseid left outer join  ApplicationDetails AD on AD.ApplicationNo=HMFA.ApplicationNo left outer join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode left outer join dgen.heapplicationprocess HAP on HAP.ApplicationNo=AD.ApplicationNo  where deptcode=@ParamDeptCode and AD.serviceCode=@SERVICECODE ";
            if (Sessions.getEmployeeUser().AuthorizationId != ((int)CountList.Type000).ToString()) { Qry += " and (HMFA.universityId in (@ParamAuthorizationId) or HMFA.InstitutionId in (@ParamAuthorizationId)) "; }
            if (AcademicSession != (int)CountList.Type000) { Qry += " and HAP.AcademicSession=@AcademicSession "; }
            Qry += " group by HeCourseId,CourseName order by CourseName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@CSCEDT", (int)Status.CSCEDT);
            cmd.Parameters.AddWithValue("@SERVICECODE", (int)ServiceList.HeFinancialAssistance);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.HigherEducationCategory);

            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult HeCourseWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AcademicSession" }, new ArrayList() { AcademicSession });
                return RedirectToAction("HeCourseWiseReport", "Report", new { q = QueryString });
            }
            return View("HeCourseWiseReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult HeStateWiseReport(int? AcademicSession = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;

            string Qry = "select STM.StateId,StateName,count(AD.ApplicationNo) TotalApp,coalesce(sum(case when ApplicationStatusId in (@OBSPEND,@CSCEDT) then 1 end),0) as PendingVerification,coalesce(sum(case when ApplicationStatusId not in (@OBSPEND,@CSCEDT) and whetherrecommended=true then 1 end),0) as PositiveVerification,coalesce(sum(case when ApplicationStatusId not in(@OBSPEND,@CSCEDT) and whetherrecommended=false then 1 end),0) as NegativeVerification,coalesce(sum(case when ApplicationStatusId=@TEHSPEN then 1 end),0) as PendingForApproval,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Approved,coalesce(sum(case when ApplicationStatusId=@TEHSREJ then 1 end),0) as Rejected from StateMaster STM left outer  join ApplicationDetails AD on AD.StateId=STM.StateId  left outer join  dgen.hemcmfinancialassistance HMFA on HMFA.ApplicationNo=AD.ApplicationNo   left outer join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode left outer join dgen.heapplicationprocess HAP on HAP.ApplicationNo=AD.ApplicationNo  where deptcode=@ParamDeptCode and AD.serviceCode=@SERVICECODE ";
            if (Sessions.getEmployeeUser().AuthorizationId != ((int)CountList.Type000).ToString()) { Qry += " and (HMFA.universityId in (@ParamAuthorizationId) or HMFA.InstitutionId in (@ParamAuthorizationId)) "; }
            if (AcademicSession != (int)CountList.Type000) { Qry += " and HAP.AcademicSession=@AcademicSession "; }
            Qry += " group by STM.StateId,StateName order by StateName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@CSCEDT", (int)Status.CSCEDT);
            cmd.Parameters.AddWithValue("@SERVICECODE", (int)ServiceList.HeFinancialAssistance);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult HeStateWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AcademicSession" }, new ArrayList() { AcademicSession });
                return RedirectToAction("HeStateWiseReport", "Report", new { q = QueryString });
            }
            return View("HeStateWiseReport", model);
        }


        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult HeFundRequiredReport(int? AcademicSession = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;

            string Qry = "select FinancialAssistanceCategoryId,SMVD.ValueName as FinancialAssistanceCategory, count(AD.ApplicationNo) as Total,coalesce(sum(case when Annualincome<100000 then 1 end),0) as belowlac,coalesce(sum(case when Annualincome>=100000 and Annualincome<=250000 then 1 end),0) as abovelac,coalesce(sum(case when whethernfssscheme=true then 1 end),0) as havingNFSScard,coalesce(sum(case when CategoryId in (@SC,@ST) then 1 end),0) as scstapplicant,coalesce(sum(case when CategoryId in (@OBC) then 1 end),0) as obcapplicant,coalesce(sum(case when CategoryId in (@Minority,@General) then 1 end),0) as otherapplicant,coalesce(sum(Feeamount)) as FundRequired from ApplicationDetails AD inner join  dgen.hemcmfinancialassistance HMFA on HMFA.ApplicationNo=AD.ApplicationNo inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dgen.hefeedetails HFD on HFD.ApplicationNo=AD.ApplicationNo inner join SelectMasterValueDetails SMVD on SMVD.ValueId=HMFA.FinancialAssistanceCategoryId where deptcode=@ParamDeptCode and AD.serviceCode=@SERVICECODE and FinancialAssistanceCategoryId=@FinancialAssistanceCategoryId and Feeinitiateby=@Feeinitiateby and ApplicationStatusId=@ApplicationStatusId ";
            if (AcademicSession != (int)CountList.Type000) { Qry += " and HMFA.AcademicSession=@AcademicSession "; }
            if (Sessions.getEmployeeUser().AuthorizationId != ((int)CountList.Type000).ToString()) { Qry += " and HMFA.universityId in (@ParamAuthorizationId) "; }
            Qry += " group by FinancialAssistanceCategoryId,SMVD.ValueName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@FinancialAssistanceCategoryId", (int)ValueId.HeCategory1);
            cmd.Parameters.AddWithValue("@Feeinitiateby", (int)ValueId.Department);
            cmd.Parameters.AddWithValue("@SC", (int)ValueId.SC);
            cmd.Parameters.AddWithValue("@ST", (int)ValueId.ST);
            cmd.Parameters.AddWithValue("@OBC", (int)ValueId.OBC);
            cmd.Parameters.AddWithValue("@Minority", (int)ValueId.Minority);
            cmd.Parameters.AddWithValue("@General", (int)ValueId.General);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@SERVICECODE", (int)ServiceList.HeFinancialAssistance);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.data = data.GetDataTable(cmd);

            Qry = "select FinancialAssistanceCategoryId,SMVD.ValueName as FinancialAssistanceCategory, count(AD.ApplicationNo) as Total,coalesce(sum(case when Annualincome<100000 then 1 end),0) as belowlac,coalesce(sum(case when Annualincome>=100000 and Annualincome<=250000 then 1 end),0) as abovelac,coalesce(sum(case when CategoryId in (@SC,@ST) then 1 end),0) as scstapplicant,coalesce(sum(case when CategoryId in (@OBC) then 1 end),0) as obcapplicant,coalesce(sum(case when CategoryId in (@Minority,@General) then 1 end),0) as otherapplicant,coalesce(sum(Feeamount)) as FundRequired from ApplicationDetails AD inner join  dgen.hemcmfinancialassistance HMFA on HMFA.ApplicationNo=AD.ApplicationNo inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dgen.hefeedetails HFD on HFD.ApplicationNo=AD.ApplicationNo inner join SelectMasterValueDetails SMVD on SMVD.ValueId=HMFA.FinancialAssistanceCategoryId where deptcode=@ParamDeptCode and AD.serviceCode=@SERVICECODE and FinancialAssistanceCategoryId=@FinancialAssistanceCategoryId and Feeinitiateby=@Feeinitiateby and ApplicationStatusId=@ApplicationStatusId ";
            if (AcademicSession != (int)CountList.Type000) { Qry += " and HMFA.AcademicSession=@AcademicSession "; }
            if (Sessions.getEmployeeUser().AuthorizationId != ((int)CountList.Type000).ToString()) { Qry += " and HMFA.universityId in (@ParamAuthorizationId) "; }
            Qry += " group by FinancialAssistanceCategoryId,SMVD.ValueName";
            cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@FinancialAssistanceCategoryId", (int)ValueId.HeCategory2);
            cmd.Parameters.AddWithValue("@Feeinitiateby", (int)ValueId.Department);
            cmd.Parameters.AddWithValue("@SC", (int)ValueId.SC);
            cmd.Parameters.AddWithValue("@ST", (int)ValueId.ST);
            cmd.Parameters.AddWithValue("@OBC", (int)ValueId.OBC);
            cmd.Parameters.AddWithValue("@Minority", (int)ValueId.Minority);
            cmd.Parameters.AddWithValue("@General", (int)ValueId.General);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@SERVICECODE", (int)ServiceList.HeFinancialAssistance);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.dataa = data.GetDataTable(cmd);

            Qry = "select FinancialAssistanceCategoryId,SMVD.ValueName as FinancialAssistanceCategory, count(AD.ApplicationNo) as Total,coalesce(sum(case when Annualincome>250000 and Annualincome<=600000 then 1 end),0) as abovelac,coalesce(sum(case when CategoryId in (@SC,@ST) then 1 end),0) as scstapplicant,coalesce(sum(case when CategoryId in (@OBC) then 1 end),0) as obcapplicant,coalesce(sum(case when CategoryId in (@Minority,@General) then 1 end),0) as otherapplicant,coalesce(sum(Feeamount)) as FundRequired from ApplicationDetails AD inner join  dgen.hemcmfinancialassistance HMFA on HMFA.ApplicationNo=AD.ApplicationNo inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dgen.hefeedetails HFD on HFD.ApplicationNo=AD.ApplicationNo inner join SelectMasterValueDetails SMVD on SMVD.ValueId=HMFA.FinancialAssistanceCategoryId where deptcode=@ParamDeptCode and AD.serviceCode=@SERVICECODE and FinancialAssistanceCategoryId=@FinancialAssistanceCategoryId and Feeinitiateby=@Feeinitiateby and ApplicationStatusId=@ApplicationStatusId ";
            if (AcademicSession != (int)CountList.Type000) { Qry += " and HMFA.AcademicSession=@AcademicSession "; }
            if (Sessions.getEmployeeUser().AuthorizationId != ((int)CountList.Type000).ToString()) { Qry += " and HMFA.universityId in (@ParamAuthorizationId) "; }
            Qry += " group by FinancialAssistanceCategoryId,SMVD.ValueName";
            cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@FinancialAssistanceCategoryId", (int)ValueId.HeCategory3);
            cmd.Parameters.AddWithValue("@Feeinitiateby", (int)ValueId.Department);
            cmd.Parameters.AddWithValue("@SC", (int)ValueId.SC);
            cmd.Parameters.AddWithValue("@ST", (int)ValueId.ST);
            cmd.Parameters.AddWithValue("@OBC", (int)ValueId.OBC);
            cmd.Parameters.AddWithValue("@Minority", (int)ValueId.Minority);
            cmd.Parameters.AddWithValue("@General", (int)ValueId.General);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@SERVICECODE", (int)ServiceList.HeFinancialAssistance);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.dataS = data.GetDataTable(cmd);

            model.AcademicSession = AcademicSession.ToString();

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult HeFundRequiredReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AcademicSession" }, new ArrayList() { AcademicSession });
                return RedirectToAction("HeFundRequiredReport", "Report", new { q = QueryString });
            }
            return View("HeFundRequiredReport", model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult HeApplicationDetailsList(int Type, int? FaCategoryId = 0, int? AcademicSession = 0, int? UniversityId = 0, int? Instituitonid = 0, int? CategoryId = 0, int? CourseId = 0, int? StateId = 0, int? PageIndex = 1)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();

            Parameters.Add(0, "Type=" + Type.ToString());
            Parameters.Add(1, "FaCategoryId=" + FaCategoryId.ToString());
            Parameters.Add(2, "AcademicSession=" + AcademicSession.ToString());
            Parameters.Add(3, "UniversityId=" + UniversityId.ToString());
            Parameters.Add(4, "Instituitonid=" + Instituitonid.ToString());
            Parameters.Add(5, "CategoryId=" + CategoryId.ToString());
            Parameters.Add(6, "CourseId=" + CourseId.ToString());
            Parameters.Add(7, "StateId=" + StateId.ToString());

            string WhetherCondition = string.Empty, Qry = string.Empty;
            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {

                if (Type == (int)CountList.Type001) { WhetherCondition = " and AD.ApplicationStatusId in (@OBSPEND,@CSCEDT)"; }
                else if (Type == (int)CountList.Type002) { WhetherCondition = " and AD.ApplicationStatusId not in (@OBSPEND,@CSCEDT) and whetherrecommended=true "; }
                else if (Type == (int)CountList.Type003) { WhetherCondition = " and AD.ApplicationStatusId not in (@OBSPEND,@CSCEDT) and whetherrecommended=false "; }
                else if (Type == (int)CountList.Type004) { WhetherCondition = " and AD.ApplicationStatusId=@TEHSPEN  "; }
                else if (Type == (int)CountList.Type014) { WhetherCondition = " and AD.ApplicationStatusId=@TEHSREJ  "; }
                else if (Type == (int)CountList.Type005 || Type == (int)CountList.Type006) { WhetherCondition = " and AD.ApplicationStatusId =@ISSUCER "; }
                else if (Type == (int)CountList.Type007) { WhetherCondition = " and AD.ApplicationStatusId =@ISSUCER and Annualincome<100000 "; }
                else if (Type == (int)CountList.Type008) { WhetherCondition = " and AD.ApplicationStatusId =@ISSUCER and Annualincome>=100000 and Annualincome<=250000 "; }
                else if (Type == (int)CountList.Type009) { WhetherCondition = " and AD.ApplicationStatusId =@ISSUCER and whethernfssscheme=true "; }
                else if (Type == (int)CountList.Type010) { WhetherCondition = " and AD.ApplicationStatusId =@ISSUCER and CategoryId in (67,68) "; }
                else if (Type == (int)CountList.Type011) { WhetherCondition = " and AD.ApplicationStatusId =@ISSUCER and CategoryId in (387) "; }
                else if (Type == (int)CountList.Type012) { WhetherCondition = " and AD.ApplicationStatusId =@ISSUCER and CategoryId in (388,389) "; }
                else if (Type == (int)CountList.Type013) { WhetherCondition = " and AD.ApplicationStatusId =@ISSUCER and and Annualincome>250000 and Annualincome<=600000"; }

                Qry += "select AD.ApplicationNo,ApplicantName,ApplicantMobileNo,SMVD.ValueName as Category,SMVD1.ValueName as FinancialAssistanceCategory,UniversityName,InstituitonName,CourseName,HFDC.Feeamount as CouserFee,(HMFA.AcademicSession ||'-'||HMFA.AcademicSession + 1) as AcademicSession,HFDD.FeeAmount as Recommended,StatusName  from applicationdetails AD inner join dgen.hemcmfinancialassistance HMFA on HMFA.ApplicationNo=AD.ApplicationNo inner join ServiceMaster SMV on SMV.ServiceCode=AD.ServiceCode  inner join SelectMasterValueDetails SMVD on SMVD.ValueId=HMFA.CategoryId inner join SelectMasterValueDetails SMVD1 on SMVD1.ValueId=HMFA.FinancialAssistanceCategoryId inner join StateMaster SM on SM.StateId=AD.StateId inner join HeUniversityMaster HUM on HUM.UniversityId=HMFA.UniversityId inner join HeInstitutionMaster HIM on HIM.InstituitonId=HMFA.InstitutionId inner join HeCourseMaster HCM on HCM.HecourseId=HMFA.CourseId inner join StatusMaster SMM on SMM.StatusId=AD.ApplicationStatusId inner join dgen.heapplicationprocess hap on  hap.applicationno=hmfa.applicationno inner join dgen.hefeedetails HFDC on HFDC.ApplicationNo=AD.ApplicationNo and HFDC.FeeInitiateBy=@FeeCitizenBy left outer join dgen.hefeedetails HFDD on HFDD.ApplicationNo=AD.ApplicationNo and HFDD.FeeInitiateBy=@FeeDepartmentBy where deptcode = @ParamDeptCode and AD.serviceCode = @serviceCode " + WhetherCondition + " ";
                if (Sessions.getEmployeeUser().AuthorizationId != ((int)CountList.Type000).ToString()) { Qry += " and (HMFA.universityId in (@ParamAuthorizationId) or HMFA.InstitutionId in (@ParamAuthorizationId)) "; }
                if (AcademicSession != (int)CountList.Type000) { Qry += " and hap.AcademicSession=@AcademicSession "; }
                if (FaCategoryId != (int)CountList.Type000) { Qry += " and  SMVD1.ValueId=@FaCategoryId "; }
                if (UniversityId != (int)CountList.Type000) { Qry += " and  HMFA.universityId=@UniversityId "; }
                if (Instituitonid != (int)CountList.Type000) { Qry += " and  HMFA.InstitutionId=@Instituitonid "; }
                if (CategoryId != (int)CountList.Type000) { Qry += " and  HMFA.CategoryId=@CategoryId "; }
                if (CourseId != (int)CountList.Type000) { Qry += " and  HMFA.CourseId=@CourseId "; }
                if (StateId != (int)CountList.Type000) { Qry += " and  AD.StateId=@StateId "; }
                Qry += " order by HMFA.marks desc,AD.ApplicationNo asc";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@serviceCode", (int)ServiceList.HeFinancialAssistance);
                cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
                cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
                cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
                cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
                cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
                cmd.Parameters.AddWithValue("@CSCEDT", (int)Status.CSCEDT);
                cmd.Parameters.AddWithValue("@FeeDepartmentBy", (int)ValueId.Department);
                cmd.Parameters.AddWithValue("@FeeCitizenBy", (int)ValueId.Applicant);
                cmd.Parameters.AddWithValue("@FaCategoryId", FaCategoryId);
                cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
                cmd.Parameters.AddWithValue("@UniversityId", UniversityId);
                cmd.Parameters.AddWithValue("@Instituitonid", Instituitonid);
                cmd.Parameters.AddWithValue("@CategoryId", CategoryId);
                cmd.Parameters.AddWithValue("@CourseId", CourseId);
                cmd.Parameters.AddWithValue("@StateId", StateId);


                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "HeApplicationDetailsList", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "HeApplicationDetailsList", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View(model);
        }

        [HttpGet]
        public ActionResult HeStatusWiseReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.HeMCMFinancialAssistance = new HeMCMFinancialAssistance();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult HeStatusWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string whereCondition = string.Empty;
                if (!string.IsNullOrEmpty(model.ApplicationStatusId))
                {
                    whereCondition += " and AD.ApplicationStatusId=@ApplicationStatusId ";
                }
                if (!string.IsNullOrEmpty(model.AcademicSession))
                {
                    whereCondition += " and HMFA.academicsession=@academicsession ";
                }
                if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.SDMG).ToString() || !string.IsNullOrEmpty(model.UniversityId))
                {
                    whereCondition += " and HMFA.universityid=@universityid ";
                }
                if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.P120).ToString() || !string.IsNullOrEmpty(model.InstitutionId))
                {
                    whereCondition += " and HMFA.institutionid=@institutionid ";
                }
                if (!string.IsNullOrEmpty(model.CourseId))
                {
                    whereCondition += " and HMFA.CourseId=@CourseId ";
                }
                if (!string.IsNullOrEmpty(model.ApplicantCategory))
                {
                    whereCondition += " and HMFA.CategoryId=@CategoryId ";
                }
                if (!string.IsNullOrEmpty(model.FinancialCategory))
                {
                    whereCondition += " and HMFA.FinancialAssistanceCategoryId=@FinancialAssistanceCategoryId ";
                }
                string Qry = @"select AD.ApplicationNo as ""Application No"",to_char(ApplicationDate,'DD/MM/YYYY') as ""Application Date"",ApplicantName as ""Applicant Name"",ApplicantMobileNo as ""Applicant Mobile No"",dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ""Applicant Address"",SMVD.ValueName as Category,AnnualIncome ""Annual Income"",SMVD1.ValueName as ""Financial Assistance Category"",case when Whethernfssscheme=true then 'Yes' else 'No' end as ""NFSS Card"",NfssCardNo as ""Nfss Card No"",StateName as State,UniversityName as University,InstituitonName as Institution,CourseName as Course,ICFD.Feeamount as ""Couse Tution Fee"",(HMFA.AcademicSession ||'-'||HMFA.AcademicSession + 1) as ""Academic Session"",HFD.FeeAmount as ""Recommended"",StatusName as Status,ApplicationRemarks as Remarks,to_char(AD.LastActiondate,'DD/MM/YYYY') as ""Status Date"",AccountHolderName as ""Account Holder Name"",AccountNo as ""Account No"",HMFA.IFSCCODE,HMFA.MICRCode,BranchAddress||' '||BankName as ""Bank Name""   from applicationdetails AD inner join dgen.hemcmfinancialassistance HMFA on HMFA.ApplicationNo=AD.ApplicationNo inner join SelectMasterValueDetails SMVD on SMVD.ValueId=HMFA.CategoryId inner join SelectMasterValueDetails SMVD1 on SMVD1.ValueId=HMFA.FinancialAssistanceCategoryId inner join StateMaster SM on SM.StateId=AD.StateId inner join HeUniversityMaster HUM on HUM.UniversityId=HMFA.UniversityId inner join HeInstitutionMaster HIM on HIM.InstituitonId=HMFA.InstitutionId inner join HeCourseMaster HCM on HCM.HecourseId=HMFA.CourseId inner join StatusMaster SMM on SMM.StatusId=AD.ApplicationStatusId inner join Institutetoclassfeesdetails ICFD on ICFD.InstitutionId=HMFA.InstitutionId and ICFD.HecourseId=HMFA.CourseId and ICFD.HecourseSession=HMFA.CurrentStudyingClass and ICFD.AcademicSession=HMFA.AcademicSession and ICFD.whetheractive=true and ICFD.Whetherapproved=true inner join BankMaster BM on BM.BankCOde=HMFA.Bankcode inner join bankmappingmaster BMM on BMM.BankCOde=HMFA.Bankcode and HMFA.IFSCCODE=BMM.IFSCCODE and HMFA.MICRCode=BMM.MICRCode left outer join dgen.hefeedetails HFD on HFD.ApplicationNo=AD.ApplicationNo and FeeInitiateBy=@FeeInitiateBy where AD.ServiceCode=@ServiceCode " + whereCondition + " order by AD.ApplicationNo";
                //string Qry = @"select AD.ApplicationNo as ""Application No"",to_char(ApplicationDate,'DD/MM/YYYY') as ""Application Date"",ApplicantName as ""Applicant Name"",ApplicantMobileNo as ""Applicant Mobile No"",dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ""Applicant Address"",SMVD.ValueName as Category,AnnualIncome ""Annual Income"",SMVD1.ValueName as ""Financial Assistance Category"",case when Whethernfssscheme=true then 'Yes' else 'No' end as ""NFSS Card"",NfssCardNo as ""Nfss Card No"",StateName as State,UniversityName as University,InstituitonName as Institution,CourseName as Course,ICFD.Feeamount as ""Couse Tution Fee"",(HMFA.AcademicSession ||'-'||HMFA.AcademicSession + 1) as ""Academic Session"",HFD.FeeAmount as ""Recommended"",StatusName as Status,ApplicationRemarks as Remarks,to_char(AD.LastActiondate,'DD/MM/YYYY') as ""Status Date""   from applicationdetails AD inner join dgen.hemcmfinancialassistance HMFA on HMFA.ApplicationNo=AD.ApplicationNo inner join SelectMasterValueDetails SMVD on SMVD.ValueId=HMFA.CategoryId inner join SelectMasterValueDetails SMVD1 on SMVD1.ValueId=HMFA.FinancialAssistanceCategoryId inner join StateMaster SM on SM.StateId=AD.StateId inner join HeUniversityMaster HUM on HUM.UniversityId=HMFA.UniversityId inner join HeInstitutionMaster HIM on HIM.InstituitonId=HMFA.InstitutionId inner join HeCourseMaster HCM on HCM.HecourseId=HMFA.CourseId inner join StatusMaster SMM on SMM.StatusId=AD.ApplicationStatusId inner join Institutetoclassfeesdetails ICFD on ICFD.InstitutionId=HMFA.InstitutionId and ICFD.HecourseId=HMFA.CourseId and ICFD.HecourseSession=HMFA.CurrentStudyingClass and ICFD.AcademicSession=HMFA.AcademicSession and ICFD.whetheractive=true and ICFD.Whetherapproved=true left outer join dgen.hefeedetails HFD on HFD.ApplicationNo=AD.ApplicationNo and FeeInitiateBy=@FeeInitiateBy where AD.ServiceCode=@ServiceCode " + whereCondition + " order by AD.ApplicationNo";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                if (!string.IsNullOrEmpty(model.ApplicationStatusId)) { cmd.Parameters.AddWithValue("@ApplicationStatusId", model.ApplicationStatusId); }
                if (!string.IsNullOrEmpty(model.AcademicSession)) { cmd.Parameters.AddWithValue("@AcademicSession", model.AcademicSession); }
                cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.HeFinancialAssistance);
                cmd.Parameters.AddWithValue("@FeeInitiateBy", (int)ValueId.Department);
                cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.True.ToString());
                if (!string.IsNullOrEmpty(model.CourseId)) { cmd.Parameters.AddWithValue("@CourseId", model.CourseId); }
                if (!string.IsNullOrEmpty(model.ApplicantCategory)) { cmd.Parameters.AddWithValue("@CategoryId", model.ApplicantCategory); }
                if (!string.IsNullOrEmpty(model.FinancialCategory)) { cmd.Parameters.AddWithValue("@FinancialAssistanceCategoryId", model.FinancialCategory); }
                if (!string.IsNullOrEmpty(model.UniversityId)) { cmd.Parameters.AddWithValue("@universityid", model.UniversityId); }
                if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.SDMG).ToString()) { cmd.Parameters.AddWithValue("@universityid", Sessions.getEmployeeUser().AuthorizationId.ToString()); }
                if (!string.IsNullOrEmpty(model.InstitutionId)) { cmd.Parameters.AddWithValue("@institutionid", model.InstitutionId); }
                if (Sessions.getEmployeeUser().Permission.ToString() == ((int)Permission.P120).ToString()) { cmd.Parameters.AddWithValue("@institutionid", Sessions.getEmployeeUser().AuthorizationId.ToString()); }

                model.data = data.GetDataTable(cmd);
                if (model.data.Rows.Count > 0)
                {
                    var grid = new System.Web.UI.WebControls.GridView();
                    grid.DataSource = model.data;
                    grid.DataBind();
                    Response.Clear();
                    Response.AddHeader("content-disposition", "attachment; filename=FileName.xls");
                    Response.Charset = "";
                    Response.ContentType = "application/vnd.xls";
                    System.IO.StringWriter stringWrite = new System.IO.StringWriter();
                    System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
                    grid.RenderControl(htmlWrite);
                    string style = @"<style> td { mso-number-format:\@; } </style>";
                    Response.Write(style);

                    Response.Write(stringWrite.ToString());
                    Response.End();


                }
                else
                {
                    ViewData["message"] = "No Record Found";
                    return View("message");
                }

            }
            return View("HeStatusWiseReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult UniversityWiseReport(string DTF, string DTT, int? StateId = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;
            model.HeSkillDevelopmentScheme = new HeSkillDevelopmentScheme();

            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,HUM.universityid, case when HUM.universityid=43 then OutUniversityName else HUM.Universityname end as Universityname, case when CollegeState is null then 7 else CollegeState end as CollegeState,case when CollegeState is null then 'Delhi' else StateName end as CollegeStateName,Count(AD.ApplicationNo) as TotalApplication,coalesce(sum(case when WhetherDocumentShown=true then 1 end),0) as physicallyreceived,coalesce(sum(case when ApplicationStatusId not in (@CANCEL) and WhetherDocumentShown=false then 1 end),0) as PendingDocSeen,coalesce(sum(case when ApplicationStatusId in (@CANCEL) and WhetherDocumentShown=false then 1 end),0) as CancelPendingDocSeen,coalesce(sum(case when ApplicationStatusId=@DEALOLR and WhetherDocumentShown=true then 1 end),0) as PendingDecision,coalesce(sum(case when ApplicationStatusId=@TEHSREJ then 1 end),0) as Rejected,coalesce(sum(case when ApplicationStatusId=@CANCEL  and WhetherDocumentShown=true then 1 end),0) as Canceled,coalesce(sum(case when ApplicationStatusId=@TEHSREC then 1 end),0) as Approved,coalesce(sum(ApproveLoanAmount),0) as LoanAmountSanction,sum(case when installmentcount>0 then 1 else 0 end) AS disbursal,coalesce(sum(disbursalAmount),0) as disbursalAmount from  dgen.heskilldevelopmentscheme HSDS inner join  ApplicationDetails AD on AD.applicationno=HSDS.applicationno left outer join Heuniversitymaster HUM on HUM.universityid=HSDS.universityid left outer join StateMaster STM on STM.StateId=HSDS.CollegeState left outer join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode left outer join (select applicationno,sum(disbursalAmount) as disbursalAmount from dgen.hedisbursaldetails group by applicationno) HDD on HDD.ApplicationNo=HSDS.ApplicationNo  where deptcode=@ParamDeptCode and AD.serviceCode=@SERVICECODE ";
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { Qry += " and LoanBankId=@LoanBankId "; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }

            if (StateId == (int)State.Delhi) { Qry += " and CollegeState is null "; } else if (StateId == (int)CountList.Type100) { Qry += " and CollegeState is not null "; }

            Qry += "  group by HUM.universityid,HUM.Universityname,OutUniversityName,CollegeState,StateName order by StateName,HUM.Universityname ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@SERVICECODE", (int)ServiceList.HigherEducationSKGS);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@LoanBankId", Sessions.getEmployeeUser().AuthorizationId); }
            model.data = data.GetDataTable(cmd);
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { model.HeSkillDevelopmentScheme.LoanBankId = Sessions.getEmployeeUser().AuthorizationId; }
            else { model.HeSkillDevelopmentScheme.LoanBankId = ((int)CountList.Type000).ToString(); }
            model.StateId = StateId.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult UniversityWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int StateId = 0;
                if (!string.IsNullOrEmpty(model.StateId)) { StateId = Convert.ToInt32(model.StateId); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT", "StateId" }, new ArrayList() { model.DateFrom, model.DateTo, StateId });
                return RedirectToAction("UniversityWiseReport", "Report", new { q = QueryString });
            }
            return View("UniversityWiseReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult InstituteWiseReport(int UniversityId, int StateId, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;

            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,HUM.universityid,case when HSDS.universityid=43 then OutUniversityName else HUM.Universityname end as Universityname,HSDS.institutionid,case when HSDS.universityid=43 then CollegeName else HIM.instituitonname end as instituitonname,case when CollegeState is null then 7 else CollegeState end as CollegeState,case when CollegeState is null then 'Delhi' else StateName end as CollegeStateName,Count(AD.ApplicationNo) as TotalApplication,coalesce(sum(case when WhetherDocumentShown=true then 1 end),0) as physicallyreceived,coalesce(sum(case when ApplicationStatusId not in (@CANCEL) and WhetherDocumentShown=false then 1 end),0) as PendingDocSeen,coalesce(sum(case when ApplicationStatusId in (@CANCEL) and WhetherDocumentShown=false then 1 end),0) as CancelPendingDocSeen,coalesce(sum(case when ApplicationStatusId=@DEALOLR and WhetherDocumentShown=true then 1 end),0) as PendingDecision,coalesce(sum(case when ApplicationStatusId=@TEHSREJ then 1 end),0) as Rejected,coalesce(sum(case when ApplicationStatusId=@CANCEL  and WhetherDocumentShown=true then 1 end),0) as Canceled,coalesce(sum(case when ApplicationStatusId=@TEHSREC then 1 end),0) as Approved,coalesce(sum(ApproveLoanAmount),0) as LoanAmountSanction,sum(case when installmentcount>0 then 1 else 0 end) AS disbursal,coalesce(sum(disbursalAmount),0) as disbursalAmount from  dgen.heskilldevelopmentscheme HSDS inner join  ApplicationDetails AD on AD.applicationno=HSDS.applicationno inner join heinstitutionmaster HIM on HIM.instituitonId=HSDS.institutionId inner join Heuniversitymaster HUM on HUM.universityid=HSDS.universityid left outer join StateMaster STM on STM.StateId=HSDS.CollegeState left outer join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode left outer join (select applicationno,sum(disbursalAmount) as disbursalAmount from dgen.hedisbursaldetails group by applicationno) HDD on HDD.ApplicationNo=HSDS.ApplicationNo    where deptcode=@ParamDeptCode and AD.serviceCode=@SERVICECODE and HUM.universityid=@universityid  ";
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { Qry += " and LoanBankId=@LoanBankId "; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            if (StateId == (int)State.Delhi) { Qry += " and CollegeState is null "; } else if (StateId == (int)CountList.Type100) { Qry += " and CollegeState is not null "; }
            Qry += " group by StateName,HUM.universityid,HUM.Universityname,HSDS.universityid,HSDS.institutionid,HIM.instituitonname,OutUniversityName,CollegeName,CollegeState order by HIM.instituitonname";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@SERVICECODE", (int)ServiceList.HigherEducationSKGS);
            cmd.Parameters.AddWithValue("@universityid", UniversityId);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@LoanBankId", Sessions.getEmployeeUser().AuthorizationId); }
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult CourseyWiseReport(string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;
            model.HeSkillDevelopmentScheme = new HeSkillDevelopmentScheme();

            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,HCM.HeCourseid,HCM.CourseName,Count(AD.ApplicationNo) as TotalApplication,coalesce(sum(case when WhetherDocumentShown=true then 1 end),0) as physicallyreceived,coalesce(sum(case when ApplicationStatusId not in (@CANCEL) and WhetherDocumentShown=false then 1 end),0) as PendingDocSeen,coalesce(sum(case when ApplicationStatusId in (@CANCEL) and WhetherDocumentShown=false then 1 end),0) as CancelPendingDocSeen,coalesce(sum(case when ApplicationStatusId=@DEALOLR and WhetherDocumentShown=true then 1 end),0) as PendingDecision,coalesce(sum(case when ApplicationStatusId=@TEHSREJ then 1 end),0) as Rejected,coalesce(sum(case when ApplicationStatusId=@CANCEL  and WhetherDocumentShown=true then 1 end),0) as Canceled,coalesce(sum(case when ApplicationStatusId=@TEHSREC then 1 end),0) as Approved,coalesce(sum(ApproveLoanAmount),0) as LoanAmountSanction,sum(case when installmentcount>0 then 1 else 0 end) AS disbursal,coalesce(sum(disbursalAmount),0) as disbursalAmount from  dgen.heskilldevelopmentscheme HSDS inner join  ApplicationDetails AD on AD.applicationno=HSDS.applicationno inner join hecoursemaster HCM on HCM.HecourseId=HSDS.CourseId left outer join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode left outer join (select applicationno,sum(disbursalAmount) as disbursalAmount from dgen.hedisbursaldetails group by applicationno) HDD on HDD.ApplicationNo=HSDS.ApplicationNo  where deptcode=@ParamDeptCode and AD.serviceCode=@SERVICECODE ";
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { Qry += " and LoanBankId=@LoanBankId "; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by HCM.HeCourseid,HCM.CourseName order by CourseName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@SERVICECODE", (int)ServiceList.HigherEducationSKGS);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@LoanBankId", Sessions.getEmployeeUser().AuthorizationId); }
            model.data = data.GetDataTable(cmd);
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { model.HeSkillDevelopmentScheme.LoanBankId = Sessions.getEmployeeUser().AuthorizationId; }
            else { model.HeSkillDevelopmentScheme.LoanBankId = ((int)CountList.Type000).ToString(); }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult CourseyWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("CourseyWiseReport", "Report", new { q = QueryString });
            }
            return View("CourseyWiseReport", model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult HeAgfDetails()
        {

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select count(AD.ApplicationNo) as received,coalesce(sum(case when ApplicationStatusId =@TEHSREC then 1 else 0 end),0) as sanctioned,coalesce(sum(ApproveloanAmount),0) as ApproveloanAmount,coalesce(sum(disbursal),0) as disbursal,coalesce(sum(AGFAmount),0)as AGFAmount,trustaccno,HDD.BankCode,BankName,BranchAddress from applicationdetails AD inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNo=AD.ApplicationNo left outer join (select ApplicationNo,coalesce(sum(disbursalamount),0) as disbursal,coalesce(sum(AFgAmount),0) as AGFAmount,BankCode,MICRCode,trustaccno from dgen.hedisbursaldetails  group by ApplicationNo,BankCode,MICRCode,trustaccno ) HDD on HDD.ApplicationNo=AD.ApplicationNo left outer join bankmaster BM on BM.BankCode=HDD.BankCode left outer join  bankmappingmaster BMM on BMM.MICRCode=HDD.MICRCode where  1=1  group by trustaccno,HDD.BankCode,BankName,BranchAddress";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult AgfDetailBankWise()
        {

            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = "select AD.applicationno,coalesce(hsds.ApproveloanAmount,0) as ApproveloanAmount,coalesce(sum(disbursal),0) as disbursal,coalesce(sum(AGFAmount),0)as AGFAmount,BankName,BranchAddress,trustaccno,paymentafgdate from applicationdetails ad inner join  dgen.HeSkillDevelopmentScheme HSDS on  HSDS.ApplicationNo=AD.ApplicationNo left outer join  (select ApplicationNo,coalesce(sum(disbursalamount),0) as disbursal,coalesce(sum(AFgAmount),0) as AGFAmount,to_char(paymentafgdate,'DD/MM/YYYY') as paymentafgdate ,BankCode,MICRCode,trustaccno,to_char(disbursaldate,'DD/MM/YYYY') as  disbursaldate from dgen.hedisbursaldetails  group by ApplicationNo,BankCode,MICRCode,trustaccno,disbursaldate,paymentafgdate ) HDD  on HDD.ApplicationNo=AD.ApplicationNo left outer join bankmaster BM on BM.BankCode=HDD.BankCode left outer join  bankmappingmaster BMM on BMM.MICRCode=HDD.MICRCode where AD.ApplicationStatusId=@ApplicationStatusId group by ad.applicationno,disbursaldate,hsds.ApproveloanAmount,BankName,BranchAddress,trustaccno,paymentafgdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult HeLoanWeeklyReport()
        {
            ReportModels model = new ReportModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult HeLoanWeeklyReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,count(distinct AD.ApplicationNo) as Totalreceived,count(distinct HDD.ApplicationNo) as disbursal,sum(disbursalAmount) as disbursalAmount,sum(case when to_char(disbursaldate,'YYYYMMDD')::date>=@FromDate and to_char(disbursaldate,'YYYYMMDD')::date <=@ToDate  then 1 else 0 end) as disbursalWeek,sum(case when to_char(disbursaldate,'YYYYMMDD')::date>=@FromDate and to_char(disbursaldate,'YYYYMMDD')::date <=@ToDate  then disbursalAmount else 0 end) as disbursalAmountWeek from applicationdetails AD inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNo=AD.ApplicationNo left outer join dgen.hedisbursaldetails HDD on HDD.ApplicationNo=HSDS.ApplicationNo";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@DisplayFromDate", model.DateFrom);
                cmd.Parameters.AddWithValue("@DisplayToDate", model.DateTo);
                cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(model.DateFrom, '/', true));
                cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(model.DateTo, '/', true));
                model.data = data.GetDataTable(cmd);
            }
            return View("HeLoanWeeklyReport", model);
        }
        [HttpGet]
        public ActionResult AppWiseStatusReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { whereCondition += " and LoanBankId=@ParamAuthorizationId "; }
            string Qry = "select to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantMobileNo, coalesce(sum(HFD.LoanAmount),0) as Required, coalesce(ApproveLoanAmount,0) as LoanApproved,SL.StatusName,AD.ApplicationRemarks,HSDS.LoanBankId,HSDS.BranchId, BankName,BranchName||' '||BranchAddress as BranchName,case when applicationstatusid in (@TEHSPEN,@DEALOLR) and  DATE_PART('day',now()-AD.lastactiondate) > 30 then 1 else 0 end as isdelaypending from ApplicationDetails AD inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNO=AD.ApplicationNo inner join dgen.hefinancedetails HFD on HFD.ApplicationNo=HSDS.ApplicationNo inner join HeBankMaster HBM on HBM.HeBankCode=HSDS.LoanBankId inner join hebankbranchmaster HBBM on HBBM.HeBranchCode=HSDS.BranchId inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join SubDivMaster SDM on SDM.SubDIvCode=AD.ApplicationSubDIvCode inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId  where 1=1" + whereCondition;
            Qry += " group by AD.ApplicationNo,ApproveLoanAmount,SL.StatusName,HSDS.LoanBankId,HSDS.BranchId,BankName,BranchName,BranchAddress order by  AD.ApplicationNo ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AllowAnonymous]
        public ActionResult DownloadLoanReportExcel()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { whereCondition += " and LoanBankId=@ParamAuthorizationId "; }
            string Qry = "select to_char(AD.ApplicationDate,'DD/MM/YYYY') as \"Application Date\", AD.ApplicationNo as \"Application No\", AD.ApplicantName as \"Name of Applicant\", AD.ApplicantGender as \"Gender\", to_char(AD.ApplicantDOB,'DD/MM/YYYY') as \"Date of Birth\", ApplicantFatherName as \"Name of Father\", ApplicantMotherName as \"Name of Mother\", AD.ApplicantMobileNo as \"Mobile No\", dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as \"Present Address\", InstituitonName as \"Name of College / Institution\", UniversityName as \"University / Board from which College/ Institution Affilated\", CourseName as \"Name of Course\", coalesce(sum(HFD.LoanAmount),0) as \"Required Loan\", BankName as \"Controling Bank\", BankAddress as \"Bank Address\", BankEmail as \"Bank Email ID\", BankContactNo as \"Bank Contact No\", BranchName as \"Dealing Bank Branch\", BranchAddress as \"Branch Address\", BranchContactNo as \"Branch Contact No\", BranchEmail as \"Branch Email ID\", coalesce(ApproveLoanAmount,0) as \"Sanctioned Loan\", SL.StatusName as \"Status\", AD.ApplicationRemarks as \"Remarks\"  from ApplicationDetails AD inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNO=AD.ApplicationNo inner join dgen.hefinancedetails HFD on HFD.ApplicationNo=HSDS.ApplicationNo inner join HeBankMaster HBM on HBM.HeBankCode=HSDS.LoanBankId  inner join hebankbranchmaster HBBM on HBBM.HeBranchCode=HSDS.BranchId  inner join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId  inner join heinstitutionmaster HIM on HIM.Instituitonid=HSDS.InstitutionId  inner join heuniversitymaster HUM on HUM.UniversityId=HSDS.UniversityId  inner join hecoursemaster HCM on HCM.HecourseId=HSDS.courseId where 1=1 " + whereCondition + " group by AD.ApplicationNo,ApproveLoanAmount,SL.StatusName,BankName,BranchName,BranchAddress,BankEmail,BankAddress,BankContactNo,BranchContactNo,BranchEmail,InstituitonName,UniversityName,CourseName order by AD.ApplicationNo";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            DataTable dt = new DataTable();
            dt = data.GetDataTable(Cmd);

            if (dt.Rows.Count > 0)
            {
                var grid = new System.Web.UI.WebControls.GridView();
                grid.DataSource = dt;
                grid.DataBind();
                Response.Clear();
                Response.AddHeader("content-disposition", "attachment; filename=Student_Loan_Data_Report_" + System.DateTime.Now.ToString("yyyyMMdd_hhmmss") + ".xls");
                Response.Charset = "";
                Response.ContentType = "application/vnd.xls";
                System.IO.StringWriter stringWrite = new System.IO.StringWriter();
                System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
                grid.RenderControl(htmlWrite);
                string style = @"<style> td { mso-number-format:\@; } </style>";
                Response.Write(style);

                Response.Write(stringWrite.ToString());
                Response.End();
            }
            else
            {
                ViewData["message"] = "No Record Found";
                return View("message");
            }

            ViewData["message"] = "File Downloaded Sucessfully.";
            return View("Message");
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DateWiseLoanReport(string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { whereCondition += " and LoanBankId=@ParamAuthorizationId "; }
            if (!string.IsNullOrEmpty(DTF)) { whereCondition += " and to_char(AD.LastActiondate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { whereCondition += " and to_char(AD.LastActiondate,'YYYYMMDD')::date <= @ToDate"; }
            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,AD.ApplicationDistrictCode,DistrictName ,Count(AD.ApplicationNo) as TotalApplication,coalesce(sum(case when ApplicationStatusId=@TEHSREJ then 1 end),0) as Rejected,coalesce(sum(case when ApplicationStatusId=@CANCEL then 1 end),0) as Canceled,coalesce(sum(case when ApplicationStatusId=@TEHSREC then 1 end),0) as Approved,coalesce(sum(ApproveLoanAmount),0) as LoanAmountSanction,sum(case when installmentcount>0 then 1 else 0 end) AS disbursal,coalesce(sum(disbursalAmount),0) as disbursalAmount from ApplicationDetails AD  inner join dgen.HeSkillDevelopmentScheme HSDS on HSDS.ApplicationNO=AD.ApplicationNo  inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode  inner join SubDivMaster SDM on SDM.SubDIvCode=AD.ApplicationSubDIvCode  left outer join (select applicationno,sum(disbursalAmount) as disbursalAmount  from dgen.hedisbursaldetails group by applicationno) HDD on HDD.ApplicationNo=HSDS.ApplicationNo  where 1=1 " + whereCondition + " group by AD.ApplicationDistrictCode,DistrictName order by  DistrictName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@SERVICECODE", (int)ServiceList.HigherEducationSKGS);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DateWiseLoanReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("DateWiseLoanReport", "Report", new { q = QueryString });
            }
            return View("DateWiseLoanReport", model);
        }
        #endregion

        #region SC/ST Department ReportS
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ServiceWiseVerifiedReport(int? AcademicSession = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty, Qry = string.Empty;
            if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
            if (AcademicSession == (int)CountList.Type000) { AcademicSession = 2016; }
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { whereCondition += " and PAP.Schoolid=@Schoolid"; }
            Qry = "select AD.ServiceCode,ServiceName,count(AD.ApplicationNo) as TotalReceived,coalesce(sum(case when whetherrecommended=true and ApplicationStatusId<>@OBSPEND then 1 end),0) as Recmended,coalesce(sum(case when whetherrecommended=false and ApplicationStatusId<>@OBSPEND then 1 end),0) as NotRecmended,coalesce(sum(case when ApplicationStatusId=@OBSPEND then 1 end),0) as Pending from dbo.applicationdetails AD inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo inner join dgen.prematschoolmaster PSM on PSM.SchoolId=PAP.SchoolId inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where 1=1 and AcademicSession=@AcademicSession and AD.ServiceCode in (@ParamServiceCode) " + whereCondition + " group by AD.ServiceCode,ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@Schoolid", Sessions.getEmployeeUser().AuthorizationId); }
            if (AcademicSession != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession); }
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ServiceWiseVerifiedReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AcademicSession" }, new ArrayList() { AcademicSession });
                return RedirectToAction("ServiceWiseVerifiedReport", "Report", new { q = QueryString });
            }
            return View("ServiceWiseVerifiedReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ServiceWiseVerifiedList(int ServiceCode, int Type, int AcademicSession)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string WhetherCondition = string.Empty;
            if (Type == (int)CountList.Type000) { WhetherCondition = " and whetherrecommended=true and ApplicationStatusId<>@OBSPEND"; }
            else if (Type == (int)CountList.Type001) { WhetherCondition = " and whetherrecommended=false and ApplicationStatusId<>@OBSPEND"; }
            else if (Type == (int)CountList.Type002) { WhetherCondition = " and ApplicationStatusId=@OBSPEND"; }
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition += " and PAP.Schoolid=@Schoolid"; }
            string Qry = "select ServiceName,PAP.SchoolID,SchoolName,AD.ApplicationNo,ApplicantName,ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,ValueName as PresentClassStudy,case when AD.ApplicantGender='M' then 'Male' when AD.ApplicantGender='F' then 'Female' end as  ApplicantGender   from dbo.applicationdetails AD inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo inner join (select ApplicationNo,PresentClass from dgen.applicationdetailsfinancialassistance union all select ApplicationNo,PresentClass from dgen.applicationdetailsprematssc union all select ApplicationNo,PresentClass  from dgen.applicationdetailsmeritscholarshipschool union all select ApplicationNo,PresentClass from dgen.applicationdetailsbrambedkar union all select ApplicationNo,PresentClass from dgen.applicationdetailsmeritprofessional union all select ApplicationNo,PresentClass from dgen.applicationdetailsprematobc union all select ApplicationNo,PresentClass from dgen.applicationdetailspostmatobc union all  select ApplicationNo,PresentClass from dgen.applicationdetailsprematscssd union all select ApplicationNo,PresentClass from dgen.applicationdetailspostmatscssd) ADSC on AD.ApplicationNo=ADSC.ApplicationNo inner join dgen.prematschoolmaster PSM on PSM.SchoolId=PAP.SchoolId inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode  inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADSC.PresentClass where AD.ServiceCode=@ServiceCode and PAP.AcademicSession=@AcademicSession " + WhetherCondition + " order by AD.ApplicationNo";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@Schoolid", Sessions.getEmployeeUser().AuthorizationId); }
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.data = data.GetDataTable(cmd);

            model.AcademicSessionType = AcademicSession + "-" + (AcademicSession + 1);
            model.AcademicSession = AcademicSession.ToString();
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ServiceWiseSCSTReport(string GenderId, int? CategoryId = 0, int? AcademicSession = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            NpgsqlCommand cmd = new NpgsqlCommand();
            string whereCondition = string.Empty, Qry = string.Empty;
            if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
            if (AcademicSession == (int)CountList.Type000)
            {
                AcademicSession = 2016;
            }

            Qry = "select AD.ServiceCode,ServiceName,count(AD.ApplicationNo) as TotalReceived,coalesce(sum(case when ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and PAP.ProcessStatusId=@ProcessStatusId and whetherrevertback=false  then 1 end),0) as PendingVerification,coalesce(sum(case when ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and whetherrevertback=true then 1 end),0) as PendingReverification ,coalesce(sum(case when ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=true then 1 end),0) as PositiveVerification,coalesce(sum(case when ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=false then 1 end),0) as NegativeVerification,coalesce(sum(case when ApplicationStatusId=@TEHSPEN and PAP.SchoolId is not null then 1 end),0) as PendingForApproval,coalesce(sum(case when ApplicationStatusId not in (@TEHSPEN,@OBSPEND,@TEHSREJ)  and PAP.SchoolId is not null then 1 end),0) as Approved,coalesce(sum(case when ApplicationStatusId=@TEHSREJ and PAP.SchoolId is not null then 1 end),0) as RejectedBySchool,coalesce(sum(case when ApplicationStatusId=@DEALOLR and PAP.SchoolId is null and PAP.ProcessStatusId=@ProcessStatusId then 1 end),0) as PendingSecrutny,coalesce(sum(case when ApplicationStatusId<>@DEALOLR and PAP.SchoolId is null and whetherrecommended=true then 1 end),0) as PositiveSecrutny,coalesce(sum(case when ApplicationStatusId<>@DEALOLR and PAP.SchoolId is null and whetherrecommended=false then 1 end),0) as NegativeSecrutny, coalesce(sum(case when ApplicationStatusId=@TEHSPEN and PAP.SchoolId is null then 1 end),0) as PendingApproval,coalesce(sum(case when ApplicationStatusId not in (@TEHSPEN,@DEALOLR,@TEHSREJ) and PAP.SchoolId is null then 1 end),0) as ApprovalBySCST,coalesce(sum(case when ApplicationStatusId=@TEHSREJ and PAP.SchoolId is null then 1 end),0) as RejectedBySCST,coalesce(sum(case when ApplicationStatusId=@TEHSREC then 1 end),0) as PendingForSanction,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Sanctioned from dbo.applicationdetails AD inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo  where 1=1 and PAP.AcademicSession=@AcademicSession and AD.ServiceCode in (@ParamServiceCode) and AD.ServiceCode not in(@DrbrAmbedkarToppers) ";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@ParamDistrictCode"; }

            if (!string.IsNullOrEmpty(GenderId)) { Qry += " and AD.ApplicantGender= @ApplicantGender"; }
            if (CategoryId != (int)CountList.Type000) { Qry += " and PAP.CategoryId= @ApplicantCategory"; }

            Qry += " group by AD.ServiceCode,ServiceName";
            cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@DrbrAmbedkarToppers", (int)ServiceList.DrbrAmbedkarToppers);
            cmd.Parameters.AddWithValue("@ApplicantGender", GenderId);
            cmd.Parameters.AddWithValue("@ApplicantCategory", CategoryId);
            cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.PendingVerification);
            if (AcademicSession != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession); }
            model.data = data.GetDataTable(cmd);

            Qry = "select AD.ServiceCode,ServiceName,count(AD.ApplicationNo) as TotalReceived,coalesce(sum(case when ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and PAP.ProcessStatusId=@ProcessStatusId and whetherrevertback=false then 1 end),0) as PendingVerification,coalesce(sum(case when ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=true then 1 end),0) as PositiveVerification,coalesce(sum(case when ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=false then 1 end),0) as NegativeVerification,coalesce(sum(case when ApplicationStatusId=@TEHSREJ and PAP.SchoolId is not null then 1 end),0) as RejectedBySchool,coalesce(sum(case when ApplicationStatusId=@TEHSPEN and PAP.SchoolId is not null then 1 end),0) as PendingApproval,coalesce(sum(case when ApplicationStatusId not in (@TEHSPEN,@OBSPEND) and PAP.SchoolId is not null then 1 end),0) as ApprovalBySCST,coalesce(sum(case when ApplicationStatusId=@TEHSREJ and PAP.SchoolId is not null then 1 end),0) as RejectedBySCST,coalesce(sum(case when ApplicationStatusId=@TEHSREC then 1 end),0) as PendingForSanction,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Sanctioned from dbo.applicationdetails AD inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where 1=1 and PAP.AcademicSession=@AcademicSession and AD.ServiceCode in (@ParamServiceCode) and AD.ServiceCode in (@ServiceCode) ";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@ParamDistrictCode"; }
            if (!string.IsNullOrEmpty(GenderId)) { Qry += " and AD.ApplicantGender= @ApplicantGender"; }
            if (CategoryId != (int)CountList.Type000) { Qry += " and PAP.CategoryId= @ApplicantCategory"; }
            Qry += " group by AD.ServiceCode,ServiceName";
            cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.DrbrAmbedkarToppers);
            cmd.Parameters.AddWithValue("@ApplicantGender", GenderId);
            cmd.Parameters.AddWithValue("@ApplicantCategory", CategoryId);
            cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.PendingVerification);
            if (AcademicSession != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession); }
            model.dataa = data.GetDataTable(cmd);

            model.AcademicSession = AcademicSession.ToString();
            if (!string.IsNullOrEmpty(GenderId)) { model.ApplicantGender = GenderId; } else { model.ApplicantGender = null; }
            if (CategoryId != (int)CountList.Type000)
            {
                model.ApplicantCategory = CategoryId.ToString();
                Qry = "select valueid ,valuename from selectmastervaluedetails where valueId=@valueId";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@valueId", CategoryId);
                model.dataS = data.GetDataTable(cmd);
            }
            else { model.ApplicantCategory = null; }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ServiceWiseSCSTReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int ApplicantCategory = 0, AcademicSession = 0;
                //if(!string.IsNullOrEmpty(model.ApplicantGender)){ApplicantGender=Convert.ToInt32(model.ApplicantGender); }
                if (!string.IsNullOrEmpty(model.ApplicantCategory)) { ApplicantCategory = Convert.ToInt32(model.ApplicantCategory); }
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "GenderId", "CategoryId", "AcademicSession" }, new ArrayList() { model.ApplicantGender, ApplicantCategory, AcademicSession });
                return RedirectToAction("ServiceWiseSCSTReport", "Report", new { q = QueryString });
            }
            return View("ServiceWiseSCSTReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult SchoolWiseSCSTReport(int ServiceCode, int AcademicSession, string GenderId, int? CategoryId = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;

            string Qry = "select AD.ServiceCode,ServiceName,case when PAP.SchoolId is null then '0' else PAP.SchoolId end as SchoolId,case when SchoolName is null then 'Out of Delhi' else SchoolName end as SchoolName,count(AD.ApplicationNo) as TotalReceived,coalesce(sum(case when ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and PAP.ProcessStatusId=@ProcessStatusId  and whetherrevertback=false then 1 end),0) as PendingVerification,coalesce(sum(case when ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and whetherrevertback=true then 1 end),0) as PendingReverification,coalesce(sum(case when ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=true then 1 end),0) as PositiveVerification,coalesce(sum(case when ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=false then 1 end),0) as NegativeVerification,coalesce(sum(case when ApplicationStatusId=@TEHSPEN and PAP.SchoolId is not null then 1 end),0) as PendingForApproval,coalesce(sum(case when ApplicationStatusId not in (@TEHSPEN,@OBSPEND,@TEHSREJ)  and PAP.SchoolId is not null then 1 end),0) as Approved,coalesce(sum(case when ApplicationStatusId=@TEHSREJ and PAP.SchoolId is not null then 1 end),0) as RejectedBySchool,coalesce(sum(case when ApplicationStatusId=@DEALOLR and PAP.SchoolId is null  and PAP.ProcessStatusId=@ProcessStatusId then 1 end),0) as PendingSecrutny,coalesce(sum(case when ApplicationStatusId<>@DEALOLR and PAP.SchoolId is null and whetherrecommended=true then 1 end),0) as PositiveSecrutny,coalesce(sum(case when ApplicationStatusId<>@DEALOLR and PAP.SchoolId is null and whetherrecommended=false then 1 end),0) as NegativeSecrutny, coalesce(sum(case when ApplicationStatusId=@TEHSPEN and PAP.SchoolId is null then 1 end),0) as PendingApproval,coalesce(sum(case when ApplicationStatusId not in (@TEHSPEN,@DEALOLR,@TEHSREJ) and PAP.SchoolId is null then 1 end),0) as ApprovalBySCST,coalesce(sum(case when ApplicationStatusId=@TEHSREJ and PAP.SchoolId is null then 1 end),0) as RejectedBySCST,coalesce(sum(case when ApplicationStatusId=@TEHSREC then 1 end),0) as PendingForSanction,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Sanctioned,SMVVD.ValueName as DepartmentName,PAP.DepartmentId  from dbo.applicationdetails AD inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join selectMasterValuedetails SMVVD on SMVVD.ValueId=PAP.DepartmentId  left outer join dgen.prematschoolmaster PSM on PSM.SchoolId=PAP.SchoolId  where AD.ServiceCode=@ServiceCode and PAP.AcademicSession=@AcademicSession ";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@ParamDistrictCode"; }
            if (!string.IsNullOrEmpty(GenderId)) { Qry += " and AD.ApplicantGender= @ApplicantGender"; }
            if (CategoryId != (int)CountList.Type000) { Qry += " and PAP.CategoryId= @ApplicantCategory"; }
            Qry += " group by PAP.SchoolId,SchoolName,AD.ServiceCode,ServiceName,DepartmentName,PAP.DepartmentId order by DepartmentName,SchoolName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ApplicantGender", GenderId);
            cmd.Parameters.AddWithValue("@ApplicantCategory", CategoryId);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.PendingVerification);
            model.data = data.GetDataTable(cmd);

            model.AcademicSession = AcademicSession.ToString();
            model.AcademicSessionType = AcademicSession + "-" + (AcademicSession + 1);

            if (!string.IsNullOrEmpty(GenderId)) { model.ApplicantGender = GenderId; } else { model.ApplicantGender = null; }
            if (CategoryId != (int)CountList.Type000)
            {
                model.ApplicantCategory = CategoryId.ToString();
                Qry = "select valueid ,valuename from selectmastervaluedetails where valueId=@valueId";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@valueId", CategoryId);
                model.dataS = data.GetDataTable(cmd);
            }
            else { model.ApplicantCategory = null; }

            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult SCSTApplicationList(int ServiceCode, int SchoolId, int Type, int AcademicSession, int? DepartmentId = 0, int? PageIndex = 1)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "ServiceCode=" + ServiceCode.ToString());
            Parameters.Add(1, "SchoolId=" + SchoolId.ToString());
            Parameters.Add(2, "Type=" + Type.ToString());
            //Parameters.Add(3, "AcademicSession=" + Type.ToString());
            Parameters.Add(3, "AcademicSession=" + AcademicSession.ToString());
            Parameters.Add(4, "DepartmentId=" + DepartmentId.ToString());


            string WhetherCondition = string.Empty, Qry = string.Empty;
            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                if (Type == (int)CountList.Type001) { WhetherCondition = " and ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and PAP.ProcessStatusId=@ProcessStatusId and whetherrevertback=false "; }
                else if (Type == (int)CountList.Type002) { WhetherCondition = " and ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=true "; }
                else if (Type == (int)CountList.Type012) { WhetherCondition = " and ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=false "; }


                else if (Type == (int)CountList.Type003) { WhetherCondition = " and ApplicationStatusId=@TEHSPEN and PAP.SchoolId is not null "; }
                else if (Type == (int)CountList.Type004) { WhetherCondition = " and ApplicationStatusId not in (@TEHSPEN,@OBSPEND,@TEHSREJ) and PAP.SchoolId is not null "; }
                else if (Type == (int)CountList.Type005) { WhetherCondition = " and ApplicationStatusId=@TEHSREJ and PAP.SchoolId is not null "; }
                else if (Type == (int)CountList.Type006) { WhetherCondition = " and ApplicationStatusId=@DEALOLR and PAP.SchoolId is null and PAP.ProcessStatusId=@ProcessStatusId "; }
                else if (Type == (int)CountList.Type007) { WhetherCondition = " and ApplicationStatusId not in (@DEALOLR) and PAP.SchoolId is null and whetherrecommended=true "; }
                else if (Type == (int)CountList.Type013) { WhetherCondition = " and ApplicationStatusId not in (@DEALOLR) and PAP.SchoolId is null and whetherrecommended=false "; }
                else if (Type == (int)CountList.Type008) { WhetherCondition = " and ApplicationStatusId=@TEHSPEN and PAP.SchoolId is null "; }
                else if (Type == (int)CountList.Type009) { WhetherCondition = " and ApplicationStatusId not in (@TEHSPEN,@DEALOLR,@TEHSREJ) and PAP.SchoolId is null "; }
                else if (Type == (int)CountList.Type010) { WhetherCondition = " and ApplicationStatusId=@TEHSREJ and PAP.SchoolId is null "; }
                else if (Type == (int)CountList.Type011) { WhetherCondition = " and ApplicationStatusId=@TEHSREC "; }
                else if (Type == (int)CountList.Type014) { WhetherCondition = " and ApplicationStatusId=@ISSUCER "; }
                else if (Type == (int)CountList.Type015) { WhetherCondition = " and ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and whetherrevertback=true "; }

                if (DepartmentId != (int)CountList.Type000) { WhetherCondition += " and PAP.DepartmentId=@DepartmentId "; }

                if (SchoolId == (int)CountList.Type000) { Qry += " select 'Out of Delhi' as SchoolName,"; }
                else { Qry += "select SchoolName,"; }
                Qry += "PAP.SchoolID,AD.ApplicationNo,ApplicantName,ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,SMVD.ValueName as PresentClassStudy,case when AD.ApplicantGender='M' then 'Male' when AD.ApplicantGender='F' then 'Female' end as  ApplicantGender,ServiceName,SMVVD.ValueName as DepartmentName  from dbo.applicationdetails AD inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo inner join (select ApplicationNo,PresentClass from dgen.applicationdetailsfinancialassistance union all select ApplicationNo,PresentClass from dgen.applicationdetailsprematssc union all select ApplicationNo,PresentClass  from dgen.applicationdetailsmeritscholarshipschool union all select ApplicationNo,PresentClass from dgen.applicationdetailsbrambedkar union all select ApplicationNo,PresentClass from dgen.applicationdetailsmeritprofessional union all select ApplicationNo,PresentClass from dgen.applicationdetailsprematobc union all select ApplicationNo,PresentClass from dgen.applicationdetailspostmatobc  union all select ApplicationNo,PresentClass from dgen.ApplicationDetailsPrematSCssd union all select ApplicationNo,PresentClass from dgen.ApplicationDetailsPostmatSCssd) ADSC on AD.ApplicationNo=ADSC.ApplicationNo ";
                if (SchoolId != (int)CountList.Type000) { Qry += " inner join dgen.prematschoolmaster PSM on PSM.SchoolId=PAP.SchoolId "; }
                Qry += " inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADSC.PresentClass inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join selectMasterValuedetails SMVVD on SMVVD.ValueId=PAP.DepartmentId where AD.ServiceCode=@ServiceCode and PAP.AcademicSession=@AcademicSession " + WhetherCondition + "  ";
                if (SchoolId == (int)CountList.Type000) { Qry += " and PAP.SchoolID is null"; }
                else { Qry += " and PAP.SchoolID=@SchoolId"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@ParamDistrictCode"; }
                Qry += " order by AD.ApplicationNo";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
                cmd.Parameters.AddWithValue("@SchoolId", SchoolId);

                cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
                cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
                cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
                cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
                cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
                cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
                cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.PendingVerification);
                if (DepartmentId != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@DepartmentId", DepartmentId); }
                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "SCSTApplicationList", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "SCSTApplicationList", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }

            model.AcademicSessionType = AcademicSession + "-" + (AcademicSession + 1);
            return View(model);
        }

        [EncryptedActionParameter]
        public ActionResult SCSTWelfareBasicAppPreview(Int64? app, int? Const)
        {
            if (app == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.readOnly = Const.ToString();

            model.ApplicantDetails = Utility.GetApplicantDetails(app.ToString(), DB.LS.ToString());
            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", string.Empty, string.Empty, model.ApplicantDetails.ApplicationNo, DB.LS.ToString(), CustomText.N.ToString());
            ViewData["dtPhotoData"] = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", string.Empty, string.Empty, model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            ViewData["dtObjectionData"] = Utility.GetObjectionDetails(model.ApplicantDetails.ApplicationNo.ToString());
            ViewData["dtVerServiceSpecific"] = Utility.GetServiceSpecificVerificationDetails(model.ApplicantDetails.ApplicationNo);
            ViewData["dtApplicationTrail"] = Utility.GetApplicationAuditTrail(model.ApplicantDetails.ApplicationNo);

            model.ApplicationDetails = new ApplicationDetails();
            string Qry = "select ServiceCode,ApplicationStatusId from ApplicationDetails where ApplicationNo=@ApplicationNo";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
            string[] GetValues = data.SelectColumns(Cmd);
            model.ApplicationDetails.ServiceCode = GetValues[0];
            model.ApplicationDetails.StatusId = GetValues[1];

            Qry = "select ApplicantName,to_char(ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB, Case When ApplicantGender='M' Then 'Male' When ApplicantGender='F' Then 'Female' When ApplicantGender='T' Then 'Transgender' end as ApplicantGender from dgen.scstupdatedapplicationdetail where ApplicationNo=@ApplicationNo";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
            model.dataa = data.GetDataTable(Cmd);

            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PrematricScholarshipSC)
            {
                model.ApplicationDetailsPrematsSC = Utility.GetPrematsSCDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.DrbrAmbedkarToppers)
            {
                model.ApplicationDetailsDrbrAmbedkarToppers = Utility.GetDrbrAmbedkarToppersDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MeritscholarshipSchool)
            {
                model.ApplicationDetailsMeritscholarshipSchool = Utility.GetMeritscholarshipSchoolDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MeritscholarshipProfessional)
            {
                model.ApplicationDetailsMeritProfessional = Utility.GetMeritscholarshipProfessionalDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PostmatricScholarshipOBC)
            {
                model.ApplicationDetailsPostmatOBC = Utility.GetPostmatOBCDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PrematricScholarshipOBC)
            {
                model.ApplicationDetailsPrematOBC = Utility.GetPrematsOBCDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.FinancialAssistanceStationery)
            {
                model.ApplicationDetailsFinancialAssistance = Utility.GetFinancialAssistanceDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PostmatricSC)
            {
                model.ApplicationDetailsPostmatSCssd = Utility.GetPostmatSCSSDDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PrematricSC)
            {
                model.ApplicationDetailsPrematSCssd = Utility.GetPrematSCSSDDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
            }
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DepartmentWiseSCSTReport(int? AcademicSession = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty, Qry = string.Empty;
            if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
            if (AcademicSession == (int)CountList.Type000)
            {
                AcademicSession = 2016;
            }

            Qry = "select SMVVD.ValueName as DepartmentName,SMVVD.ValueId as DepartmentId,count(AD.ApplicationNo) as TotalReceived,coalesce(sum(case when ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and PAP.ProcessStatusId=@ProcessStatusId and whetherrevertback=false then 1 end),0) as PendingVerification,coalesce(sum(case when ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and whetherrevertback=true then 1 end),0) as PendingReverification,coalesce(sum(case when ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=true then 1 end),0) as PositiveVerification,coalesce(sum(case when ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=false then 1 end),0) as NegativeVerification,coalesce(sum(case when ApplicationStatusId=@TEHSPEN and PAP.SchoolId is not null then 1 end),0) as PendingForApproval,coalesce(sum(case when ApplicationStatusId not in (@TEHSPEN,@OBSPEND,@TEHSREJ) and PAP.SchoolId is not null then 1 end),0) as Approved,coalesce(sum(case when ApplicationStatusId=@TEHSREJ and PAP.SchoolId is not null then 1 end),0) as RejectedBySchool,coalesce(sum(case when ApplicationStatusId=@DEALOLR and PAP.SchoolId is null and PAP.ProcessStatusId=@ProcessStatusId then 1 end),0) as PendingSecrutny,coalesce(sum(case when ApplicationStatusId<>@DEALOLR and PAP.SchoolId is null and whetherrecommended=true then 1 end),0) as PositiveSecrutny,coalesce(sum(case when ApplicationStatusId<>@DEALOLR and PAP.SchoolId is null and whetherrecommended=false then 1 end),0) as NegativeSecrutny,coalesce(sum(case when ApplicationStatusId=@TEHSPEN and PAP.SchoolId is null then 1 end),0) as PendingApproval,coalesce(sum(case when ApplicationStatusId not in (@TEHSPEN,@DEALOLR,@TEHSREJ) and PAP.SchoolId is null then 1 end),0) as ApprovalBySCST,coalesce(sum(case when ApplicationStatusId=@TEHSREJ and PAP.SchoolId is null then 1 end),0) as RejectedBySCST,coalesce(sum(case when ApplicationStatusId=@TEHSREC then 1 end),0) as PendingForSanction,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Sanctioned from selectmastervaluetodetails SMVTD inner join selectMasterValuedetails SMVVD on SMVVD.ValueId=SMVTD.ValueId inner join selectmastervalue smv on smv.mastervalueid=SMVTD.mastervalueid left outer join dgen.prematapplicationprocess PAP on PAP.DepartmentId=SMVVD.ValueId left outer join applicationdetails AD on AD.ApplicationNo=PAP.ApplicationNo and AD.ServiceCode in (@ParamServiceCode) and AD.ServiceCode not in(4015) where  SMVTD.MasterValueId=@MasterValueId and AcademicSession=@AcademicSession ";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@ParamDistrictCode"; }
            Qry += " group by SMVVD.ValueId,DepartmentName order by DepartmentName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SCSTApprovingDeptType);
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.PendingVerification);
            if (AcademicSession != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession); }
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DepartmentWiseSCSTReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AcademicSession" }, new ArrayList() { AcademicSession });
                return RedirectToAction("DepartmentWiseSCSTReport", "Report", new { q = QueryString });
            }
            return View("DepartmentWiseSCSTReport", model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult SCSTServiceWiseReport(int DepartmentId, int AcademicSession)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;

            string Qry = "select AD.ServiceCode,ServiceName,SMVVD.ValueId as DepartmentId,SMVVD.ValueName as DepartmentName,count(AD.ApplicationNo) as TotalReceived,coalesce(sum(case when ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and PAP.ProcessStatusId=@ProcessStatusId and whetherrevertback=false then 1 end),0) as PendingVerification,coalesce(sum(case when ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and whetherrevertback=true then 1 end),0) as PendingReverification,coalesce(sum(case when ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=true then 1 end),0) as PositiveVerification,coalesce(sum(case when ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=false then 1 end),0) as NegativeVerification,coalesce(sum(case when ApplicationStatusId=@TEHSPEN and PAP.SchoolId is not null then 1 end),0) as PendingForApproval,coalesce(sum(case when ApplicationStatusId   not in (@TEHSPEN,@OBSPEND,@TEHSREJ) and PAP.SchoolId is not null then 1 end),0) as Approved,coalesce(sum(case when ApplicationStatusId=@TEHSREJ and PAP.SchoolId is not null then 1 end),0) as RejectedBySchool,coalesce(sum(case when ApplicationStatusId=@DEALOLR and PAP.SchoolId is null and PAP.ProcessStatusId=@ProcessStatusId then 1 end),0) as PendingSecrutny,coalesce(sum(case when ApplicationStatusId<>@DEALOLR and PAP.SchoolId is null and whetherrecommended=true then 1 end),0) as PositiveSecrutny,coalesce(sum(case when ApplicationStatusId<>@DEALOLR and PAP.SchoolId is null and whetherrecommended=false then 1 end),0) as NegativeSecrutny,coalesce(sum(case when ApplicationStatusId=@TEHSPEN and PAP.SchoolId is null then 1 end),0) as PendingApproval,coalesce(sum(case when ApplicationStatusId not in (@TEHSPEN,@DEALOLR,@TEHSREJ) and PAP.SchoolId is null then 1 end),0) as ApprovalBySCST,coalesce(sum(case when ApplicationStatusId=@TEHSREJ and PAP.SchoolId is null then 1 end),0) as RejectedBySCST,coalesce(sum(case when ApplicationStatusId=@TEHSREC then 1 end),0) as PendingForSanction,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Sanctioned  from ServiceMaster SM left outer join dbo.applicationdetails AD on AD.ServiceCode=SM.ServiceCode inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo inner join selectMasterValuedetails SMVVD on SMVVD.ValueId=PAP.DepartmentId where 1=1 and AD.ServiceCode in (@ParamServiceCode) and AD.ServiceCode not in(4015) and PAP.DepartmentId=@DepartmentId and PAP.AcademicSession=@AcademicSession ";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@ParamDistrictCode"; }
            Qry += " group by AD.ServiceCode,ServiceName,SMVVD.ValueId,DepartmentName order by ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DepartmentId", DepartmentId);
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.PendingVerification);
            model.data = data.GetDataTable(cmd);

            model.AcademicSession = AcademicSession.ToString();
            model.AcademicSessionType = AcademicSession + "-" + (AcademicSession + 1);
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult SCSTApplicationDetailsList(int ServiceCode, int DepartmentId, int Type, int AcademicSession, int? PageIndex = 1)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "ServiceCode=" + ServiceCode.ToString());
            Parameters.Add(1, "DepartmentId=" + DepartmentId.ToString());
            Parameters.Add(2, "Type=" + Type.ToString());
            //Parameters.Add(3, "AcademicSession=" + Type.ToString());
            Parameters.Add(3, "AcademicSession=" + AcademicSession.ToString());

            string WhetherCondition = string.Empty, Qry = string.Empty;
            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                if (Type == (int)CountList.Type001) { WhetherCondition = " and ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and PAP.ProcessStatusId=@ProcessStatusId and whetherrevertback=false "; }
                else if (Type == (int)CountList.Type002) { WhetherCondition = " and ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=true "; }
                else if (Type == (int)CountList.Type012) { WhetherCondition = " and ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=false "; }


                else if (Type == (int)CountList.Type003) { WhetherCondition = " and ApplicationStatusId=@TEHSPEN and PAP.SchoolId is not null "; }
                else if (Type == (int)CountList.Type004) { WhetherCondition = " and ApplicationStatusId not in (@TEHSPEN,@OBSPEND,@TEHSREJ) and PAP.SchoolId is not null "; }
                else if (Type == (int)CountList.Type005) { WhetherCondition = " and ApplicationStatusId=@TEHSREJ and PAP.SchoolId is not null "; }
                else if (Type == (int)CountList.Type006) { WhetherCondition = " and ApplicationStatusId=@DEALOLR and PAP.SchoolId is null and PAP.ProcessStatusId=@ProcessStatusId "; }
                else if (Type == (int)CountList.Type007) { WhetherCondition = " and ApplicationStatusId not in (@DEALOLR) and PAP.SchoolId is null and whetherrecommended=true "; }
                else if (Type == (int)CountList.Type013) { WhetherCondition = " and ApplicationStatusId not in (@DEALOLR) and PAP.SchoolId is null and whetherrecommended=false "; }
                else if (Type == (int)CountList.Type008) { WhetherCondition = " and ApplicationStatusId=@TEHSPEN and PAP.SchoolId is null "; }
                else if (Type == (int)CountList.Type009) { WhetherCondition = " and ApplicationStatusId not in (@TEHSPEN,@DEALOLR,@TEHSREJ) and PAP.SchoolId is null "; }
                else if (Type == (int)CountList.Type010) { WhetherCondition = " and ApplicationStatusId=@TEHSREJ and PAP.SchoolId is null "; }
                else if (Type == (int)CountList.Type011) { WhetherCondition = " and ApplicationStatusId=@TEHSREC "; }
                else if (Type == (int)CountList.Type014) { WhetherCondition = " and ApplicationStatusId=@ISSUCER "; }
                else if (Type == (int)CountList.Type015) { WhetherCondition = " and ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and whetherrevertback=true "; }

                Qry = "select case when PAP.SchoolID is null then 'Out Of Delhi' else SchoolName end as SchoolName,PAP.SchoolID,AD.ApplicationNo,ApplicantName,ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,SMVD.ValueName as PresentClassStudy,case when AD.ApplicantGender='M' then 'Male' when AD.ApplicantGender='F' then 'Female' end as  ApplicantGender,ServiceName,SMVVD.ValueName as DepartmentName from dbo.applicationdetails AD inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo inner join (select ApplicationNo,PresentClass from dgen.applicationdetailsfinancialassistance union all select ApplicationNo,PresentClass from dgen.applicationdetailsprematssc union all select ApplicationNo,PresentClass  from dgen.applicationdetailsmeritscholarshipschool union all select ApplicationNo,PresentClass from dgen.applicationdetailsbrambedkar union all select ApplicationNo,PresentClass from dgen.applicationdetailsmeritprofessional union all select ApplicationNo,PresentClass from dgen.applicationdetailsprematobc union all select ApplicationNo,PresentClass from dgen.applicationdetailspostmatobc union all select ApplicationNo,PresentClass from dgen.ApplicationDetailsPrematSCssd union all select ApplicationNo,PresentClass from dgen.ApplicationDetailsPostmatSCssd) ADSC on AD.ApplicationNo=ADSC.ApplicationNo left outer join dgen.prematschoolmaster PSM on PSM.SchoolId=PAP.SchoolId inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADSC.PresentClass inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join selectMasterValuedetails SMVVD on SMVVD.ValueId=PAP.DepartmentId where AD.ServiceCode=@ServiceCode and PAP.DepartmentId=@DepartmentId and PAP.AcademicSession=@AcademicSession " + WhetherCondition;
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@ParamDistrictCode"; }
                Qry += " order by AD.ApplicationNo ";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
                cmd.Parameters.AddWithValue("@DepartmentId", DepartmentId);
                cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
                cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
                cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
                cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
                cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
                cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
                cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.PendingVerification);
                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "SCSTApplicationDetailsList", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "SCSTApplicationDetailsList", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            model.AcademicSessionType = AcademicSession + "-" + (AcademicSession + 1);
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ServiceWiseSanction(int? AcademicSession = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty, Qry = string.Empty;
            if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
            if (AcademicSession == (int)CountList.Type000)
            {
                AcademicSession = 2016;
            }
            Qry = "select coalesce(sum(case when ApplicationStatusId=@ISSUCER or ApplicationStatusId=@SCOM046 then 1 end),0) as Approved, coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as PendingSanction,coalesce(sum(case when ApplicationStatusId=@SCOM046 then 1 end),0) as TotalSanction,SM.ServiceCode,ServiceName from dbo.applicationdetails AD inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo left outer join sanctionapplicationdetails SAD on SAD.ApplicationNo=AD.ApplicationNo right outer join ServiceMaster Sm on SM.ServiceCode=AD.ServiceCode  where deptcode=@ParamDeptCode group by SM.ServiceCode,ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@SCOM046", (int)Status.SCOM046);
            if (AcademicSession != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession); }
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ServiceWiseSanction(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AcademicSession" }, new ArrayList() { AcademicSession });
                return RedirectToAction("ServiceWiseSanction", "Report", new { q = QueryString });
            }
            return View("ServiceWiseSanction", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult SchoolWiseSanction(int ServiceCode, int AcademicSession)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;
            string Qry = "select ServiceName,case when PAP.SchoolId is null then '0' else PAP.SchoolId end as SchoolId,case when SchoolName is null then 'Out of Delhi' else SchoolName end as SchoolName,coalesce(sum(case when ApplicationStatusId=@ISSUCER or ApplicationStatusId=@SCOM046 then 1 end),0) as Approved, coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as PendingSanction,coalesce(sum(case when ApplicationStatusId=@SCOM046 then 1 end),0) as TotalSanction,SM.ServiceCode,ServiceName from dbo.applicationdetails AD inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo  left outer join dgen.prematschoolmaster PSM on PSM.SchoolId=PAP.SchoolId right outer join ServiceMaster Sm on SM.ServiceCode=AD.ServiceCode where AD.ServiceCode=@ServiceCode and PAP.AcademicSession=@AcademicSession";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@ParamDistrictCode"; }
            Qry += "  group by PAP.SchoolId,SchoolName,SM.ServiceCode,ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@SCOM046", (int)Status.SCOM046);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();
            model.AcademicSessionType = AcademicSession + "-" + (AcademicSession + 1);
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult SanctionApplicationList(int ServiceCode, int SchoolId, int Type, int AcademicSession)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string WhetherCondition = string.Empty, Qry = string.Empty;
            if (Type == (int)CountList.Type001) { WhetherCondition = " and ApplicationStatusId=@ISSUCER or ApplicationStatusId=@SCOM046 "; }
            else if (Type == (int)CountList.Type002) { WhetherCondition = " and ApplicationStatusId=@ISSUCER "; }
            else if (Type == (int)CountList.Type003) { WhetherCondition = " and ApplicationStatusId=@SCOM046 "; }

            if (SchoolId == (int)CountList.Type000) { Qry += " select 'Out of Delhi' as SchoolName,"; } else { Qry += "select SchoolName,"; }

            Qry += "PAP.SchoolID,AD.ApplicationNo,ApplicantName,ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,ValueName as PresentClassStudy,case when AD.ApplicantGender='M' then 'Male' when AD.ApplicantGender='F' then 'Female' end as  ApplicantGender from dbo.applicationdetails AD inner join dgen.prematapplicationprocess PAP on AD.ApplicationNo=AD.ApplicationNo inner join (select ApplicationNo,PresentClass from dgen.applicationdetailsfinancialassistance union all select ApplicationNo,PresentClass from dgen.applicationdetailsprematssc union all select ApplicationNo,PresentClass  from dgen.applicationdetailsmeritscholarshipschool union all select ApplicationNo,PresentClass from dgen.applicationdetailsbrambedkar union all select ApplicationNo,PresentClass from dgen.applicationdetailsmeritprofessional union all select ApplicationNo,PresentClass from dgen.applicationdetailsprematobc union all select ApplicationNo,PresentClass from dgen.applicationdetailspostmatobc union all select ApplicationNo,PresentClass from dgen.applicationdetailsprematscssd union all select ApplicationNo,PresentClass from dgen.applicationdetailspostmatscssd) ADSC on AD.ApplicationNo=ADSC.ApplicationNo ";
            if (SchoolId != (int)CountList.Type000) { Qry += " inner join dgen.prematschoolmaster PSM on PSM.SchoolId=PAP.SchoolId "; }
            Qry += " inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADSC.PresentClass inner join sanctionapplicationdetails SAD on SAD.ApplicationNo=AD.ApplicationNo inner join Sanctionpaymentdetails SPD  on SPD.SanctionId=SAD.SanctionId where AD.ServiceCode=@ServiceCode " + WhetherCondition + "  ";
            if (SchoolId == (int)CountList.Type000) { Qry += " and PAP.SchoolID is null"; }
            else { Qry += " and PAP.SchoolID=@SchoolId"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@ParamDistrictCode"; }
            Qry += " order by AD.ApplicationNo";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@SchoolId", SchoolId);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@SCOM046", (int)Status.SCOM046);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.data = data.GetDataTable(cmd);
            model.AcademicSessionType = AcademicSession + "-" + (AcademicSession + 1);
            return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ServiceWiseSanctionAmt(int? AcademicSession = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty, Qry = string.Empty;
            if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
            if (AcademicSession == (int)CountList.Type000)
            {
                AcademicSession = 2016;
            }

            Qry = "select coalesce(sum(case when ApplicationStatusId=@SCOM046 then 1 end),0) as TotalSanction,SM.ServiceCode,ServiceName,SPD.SanctionDate,coalesce(SPD.SanctionAmount,0) as SanctionAmount from dbo.applicationdetails AD inner join dgen.prematapplicationprocess  PAP on PAP.ApplicationNo=AD.ApplicationNo inner join sanctionapplicationdetails SAD on SAD.ApplicationNo=AD.ApplicationNo inner join Sanctionpaymentdetails SPD  on SPD.SanctionId=SAD.SanctionId  right outer join ServiceMaster Sm on SM.ServiceCode=SPD.ServiceCode where deptcode=@ParamDeptCode and AcademicSession=@AcademicSession group by SM.ServiceCode,ServiceName,SPD.SanctionDate,SPD.SanctionAmount";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@SCOM046", (int)Status.SCOM046);
            if (AcademicSession != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession); }
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ServiceWiseSanctionAmt(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AcademicSession" }, new ArrayList() { AcademicSession });
                return RedirectToAction("ServiceWiseSanctionAmt", "Report", new { q = QueryString });
            }
            return View("ServiceWiseSanctionAmt", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult SchoolWiseSanctionAmt(int ServiceCode, int AcademicSession)
        {
            GetData data = new GetData();
            string whereCondition = string.Empty;
            ReportModels model = new ReportModels();

            string Qry = " select ServiceName,case when PAP.SchoolId is null then '0' else PAP.SchoolId end as SchoolId,case when SchoolName is null then 'Out of Delhi' else SchoolName end as SchoolName,coalesce(sum(case when ApplicationStatusId=46 then 1 end),0) as TotalSanction,SM.ServiceCode,ServiceName,SPD.SanctionDate,coalesce(SPD.SanctionAmount,0) as SanctionAmount from dbo.applicationdetails AD inner join dgen.prematapplicationprocess  PAP on PAP.ApplicationNo=AD.ApplicationNo inner join sanctionapplicationdetails SAD on SAD.ApplicationNo=AD.ApplicationNo inner join Sanctionpaymentdetails SPD  on SPD.SanctionId=SAD.SanctionId left outer join dgen.prematschoolmaster PSM on PSM.SchoolId=PAP.SchoolId right outer join ServiceMaster Sm on SM.ServiceCode=SPD.ServiceCode  where AD.ServiceCode=@ServiceCode";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@ParamDistrictCode"; }
            Qry += " group by ADSC.SchoolId,SchoolName,SM.ServiceCode,ServiceName,SPD.SanctionDate,SPD.SanctionAmount";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();
            model.AcademicSessionType = AcademicSession + "-" + (AcademicSession + 1);
            return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult AddedSchoolList()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.ApplicationDetailsPrematsSC = new ApplicationDetailsPrematsSC();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult DeptWiseAddedSchoolList(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();

                //string Qry = "select SchoolName,SchoolCode,SchoolAddress,DistrictName,ZoneName,PinCode,SchoolAffiliationId,'Delhi' as State,MobileNo,EmailId,NodalOfficer,SMV.ValueName as SchoolType, SMVD.ValueName as ApprovingDepartment from dgen.prematschoolmaster PCM inner join selectmastervaluedetails SMV on SMV.ValueId=PCM.SchoolTypeId inner join selectmastervaluedetails SMVD on SMVD.ValueId=PCM.DepartmentId left outer  join dgen.prematdistrictmaster PDM on PDM.DistrictId=PCM.District left outer  join dgen.prematzonemaster PZM on PZM.ZoneId=PCM.SubDivision where PCM.Departmentid=@Departmentid order by ApprovingDepartment,SchoolType";
                string Qry = "select SchoolName,SchoolCode,SchoolAddress,DistrictName,ZoneName,PinCode,SchoolAffiliationId,'Delhi' as State,MobileNo,EmailId,NodalOfficer,SMV.ValueName as SchoolType, SMVD.ValueName as ApprovingDepartment,PCM.WhetherActive from dgen.prematschoolmaster PCM inner join selectmastervaluedetails SMV on SMV.ValueId=PCM.SchoolTypeId inner join selectmastervaluedetails SMVD on SMVD.ValueId=PCM.DepartmentId left outer  join dgen.prematdistrictmaster PDM on PDM.DistrictId=PCM.District left outer  join dgen.prematzonemaster PZM on PZM.ZoneId=PCM.SubDivision where PCM.Departmentid=@Departmentid order by ApprovingDepartment,SchoolType";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@Departmentid", model.ApplicationDetailsPrematsSC.DepartmentId);
                model.data = data.GetDataTable(cmd);
                return View(model);
            }
            return RedirectToAction("AddedSchoolList");
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult SchoolWiseSCSTBRReport(int ServiceCode)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;
            string Qry = "select AD.ServiceCode,ServiceName,case when ADSC.SchoolId is null then '0' else ADSC.SchoolId end as SchoolId,case when SchoolName is null then 'Out of Delhi' else SchoolName end as SchoolName,count(AD.ApplicationNo) as TotalReceived,coalesce(sum(case when ApplicationStatusId=44 and ADSC.SchoolId is not null then 1 end),0) as PendingVerification,coalesce(sum(case when ApplicationStatusId<>44 and ADSC.SchoolId is not null then 1 end),0) as CompletedVerification,coalesce(sum(case when ApplicationStatusId=5 and ADSC.SchoolId is not null then 1 end),0) as PendingApproval,coalesce(sum(case when ApplicationStatusId not in (5,44) and ADSC.SchoolId is not null then 1 end),0) as ApprovalBySCST,coalesce(sum(case when ApplicationStatusId=14 and ADSC.SchoolId is null then 1 end),0) as RejectedBySCST,coalesce(sum(case when ApplicationStatusId=16 then 1 end),0) as PendingForSanction,coalesce(sum(case when ApplicationStatusId=46 then 1 end),0) as Sanctioned,SMVVD.ValueName as DepartmentName,ADSC.DepartmentId  from dbo.applicationdetails AD inner join (select ApplicationNo,SchoolId,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsfinancialassistance union all select ApplicationNo,SchoolId,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsprematssc union all select ApplicationNo,SchoolId,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsmeritscholarshipschool union all select ApplicationNo,SchoolId,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsbrambedkar union all select ApplicationNo,SchoolId,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsmeritprofessional union all select ApplicationNo,SchoolId,whetherschoolrecomended,DepartmentId from dgen.applicationdetailsprematobc union all select ApplicationNo,SchoolId,whetherschoolrecomended,DepartmentId from dgen.applicationdetailspostmatobc) ADSC on AD.ApplicationNo=ADSC.ApplicationNo  inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join selectMasterValuedetails SMVVD on SMVVD.ValueId=ADSC.DepartmentId  left outer join dgen.prematschoolmaster PSM on PSM.SchoolId=ADSC.SchoolId  where AD.ServiceCode=@ServiceCode";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@ParamDistrictCode"; }
            Qry += " group by ADSC.SchoolId,SchoolName,AD.ServiceCode,ServiceName,DepartmentName,ADSC.DepartmentId order by DepartmentName,SchoolName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@SCOM046", (int)Status.SCOM046);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]

        public ActionResult SchoolWisePendingRevertApp(int? AcademicSession = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty, Qry = string.Empty;
            if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
            if (AcademicSession == (int)CountList.Type000)
            {
                AcademicSession = 2016;
            }
            Qry = "select count(AD.ApplicationNo) as Pending,SchoolName,PAP.SchoolId from dbo.applicationdetails AD inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo inner join dgen.prematschoolmaster PSM on PSM.SchoolId=PAP.SchoolId inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where WhetherRevertBack=@WhetherRevertBack and AcademicSession=@AcademicSession  group by SchoolName,PAP.SchoolId  order by 1 desc";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.True.ToString());
            if (AcademicSession != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession); }
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult SchoolWisePendingRevertApp(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AcademicSession" }, new ArrayList() { AcademicSession });
                return RedirectToAction("SchoolWisePendingRevertApp", "Report", new { q = QueryString });
            }
            return View("SchoolWisePendingRevertApp", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult SchoolWisePendingRevertList(int SchoolId, int AcademicSession)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string WhetherCondition = string.Empty;
            string Qry = "select ServiceName,PAP.SchoolID,SchoolName,AD.ApplicationNo,ApplicantName,ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,case when AD.ApplicantGender='M' then 'Male' when AD.ApplicantGender='F' then 'Female' end as  ApplicantGender  from dbo.applicationdetails AD inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo inner join dgen.prematschoolmaster PSM on PSM.SchoolId=PAP.SchoolId inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where WhetherRevertBack=@WhetherRevertBack and PAP.SchoolId=@SchoolId and AcademicSession=@AcademicSession order by AD.ApplicationNo";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@SchoolId", SchoolId);
            cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();
            model.AcademicSessionType = AcademicSession + "-" + (AcademicSession + 1);
            return View(model);
        }




        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ScStApprovedSchoolListReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = @"select DepartmentName,a.DepartmentId,TotalSchool,TotalEntryDone,PendingforEntry,EntryApproved,PendingApproved from (select SMVVD.ValueName as DepartmentName,SMVVD.ValueId as DepartmentId,
                                count(PSM.SchoolId) as TotalSchool,count(PCM.SchoolId) as TotalEntryDone,sum(case when whetherapproved=true then 1 else 0 end) as EntryApproved,
                                sum(case when whetherapproved=false then 1 else 0 end) as PendingApproved
                                from dgen.prematschoolmaster PSM  left outer join selectmastervaluetodetails SMVTD on  PSM.DepartmentId=SMVTD.ValueId
                                inner join selectMasterValuedetails SMVVD on SMVVD.ValueId=SMVTD.ValueId 
                                inner join selectmastervalue smv on smv.mastervalueid=SMVTD.mastervalueid
                                left outer join dgen.prematcoursemaster PCM on PCM.SchoolId=PSM.SchoolId where  SMVTD.MasterValueId=@MasterValueId
                                group by SMVVD.ValueId,DepartmentName
                                )a inner join (select SMVVD.ValueId as DepartmentId,count(PCM1.SchoolId) as PendingforEntry from dgen.prematschoolmaster PCM1 
                                left outer join selectmastervaluetodetails SMVTD on  PCM1.DepartmentId=SMVTD.ValueId
                                inner join selectMasterValuedetails SMVVD on SMVVD.ValueId=SMVTD.ValueId 
                                inner join selectmastervalue smv on smv.mastervalueid=SMVTD.mastervalueid
                                where PCM1.SchoolId Not in (select SchoolId from dgen.prematcoursemaster) and SMVTD.MasterValueId=133
                                group by SMVVD.ValueId) b on a.DepartmentId=b.DepartmentId order by DepartmentName ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SCSTApprovingDeptType);
            model.data = data.GetDataTable(cmd);

            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult ScStApprovedSchoolDetailsReport(int deptId, int typeId, int? PageIndex = 1)
        {
            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "deptId=" + deptId.ToString());
            Parameters.Add(1, "typeId=" + typeId.ToString());
            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                GetData data = new GetData();
                string statusId = string.Empty, Qry = string.Empty;
                string whetherCondition = string.Empty;
                if (typeId == (int)CountList.Type001)
                {
                    whetherCondition += " and PCM.SchoolId in (Select distinct SchoolId from dgen.PrematCourseMaster) ";
                }
                else if (typeId == (int)CountList.Type002)
                {
                    whetherCondition += " and PCM.SchoolId not in (Select  distinct SchoolId from dgen.PrematCourseMaster) ";
                }
                else if (typeId == (int)CountList.Type003)
                {
                    whetherCondition += " and PCM.SchoolId in (Select distinct SchoolId from dgen.PrematCourseMaster Where WhetherApproved= true) ";
                }
                else if (typeId == (int)CountList.Type004)
                {
                    whetherCondition += " and PCM.SchoolId in (Select distinct SchoolId from dgen.PrematCourseMaster Where WhetherApproved= false) ";
                }
                Qry = "select PCM.SchoolId,SchoolName,Schoolcode,Schooladdress,DistrictName,ZoneName,Pincode,SchoolaffiliationId,MobileNo,PCM.EmailId,PCM.SchooltypeId,SMV.ValueName as SchoolType, SMVD.ValueName as ApprovingDepartment from dgen.prematschoolmaster PCM inner join selectmastervaluedetails SMV on SMV.ValueId=PCM.SchoolTypeId inner join selectmastervaluedetails SMVD on SMVD.ValueId=PCM.DepartmentId left outer  join dgen.prematdistrictmaster PDM on PDM.DistrictId=PCM.District left outer  join dgen.prematzonemaster PZM on PZM.ZoneId=PCM.SubDivision left outer join dgen.prematcoursemaster PCM1 on PCM1.SchoolId=PCM.SchoolId  where PCM.DepartmentId=@DepartmentId" + whetherCondition;

                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@DepartmentId", deptId);
                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "MISApplicationDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "MISApplicationDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult ScStSanctioningProcessSummary(int? AcademicSession = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty, Qry = string.Empty;
            if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
            if (AcademicSession == (int)CountList.Type000)
            {
                AcademicSession = 2016;
            }
            model.ApplicationDetailsPrematsSC = new ApplicationDetailsPrematsSC();
            Qry = "select AD.ServiceCode,ServiceName,sum(case when ApplicationStatusId in (@TEHSREC,@ISSUCER)  and ProcessstatusId<>@Verified then 1 else 0 end) as TotalApp,sum(case when ApplicationStatusId = @TEHSREC and ProcessstatusId in (@PFMSValidateComplete, @PFMSFileGenerated) then 1 else 0 end) as PendingApp,sum(case when ApplicationStatusId in (@TEHSREC, @ISSUCER) and ProcessstatusId in (@SanctionIssued, @SanctionProcessed)  then 1 else 0 end) as SantionedProcessedApp,sum(case when ApplicationStatusId = @TEHSREC and ProcessstatusId = @SanctionProcessed then 1 else 0 end) as PendingsanctionApp,sum(case when ApplicationStatusId = @ISSUCER and ProcessstatusId = @SanctionIssued then 1 else 0 end) as SantionedApprovedApp from applicationdetails AD inner join dgen.PrematApplicationProcess PAP on PAP.ApplicationNo = AD.ApplicationNo inner join ServiceMaster Sm on SM.ServiceCode = AD.ServiceCode inner join dgen.prematschoolmaster PSM on PSM.SchoolId = PAP.SchoolId inner join SelectMasterValueDetails SMVD on SMVD.ValueId = PAP.ProcessstatusId inner join dgen.prematdistrictmaster PDM on PDM.DistrictId = PSM.District left outer join dgen.prematzonemaster PZM on PZM.ZoneId = PSM.SubDivision where AD.ServiceCode in (@ParamServiceCode) and PAP.AcademicSession=@AcademicSession group by ServiceName, AD.ServiceCode";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@Verified", (int)ValueId.Verified);
            cmd.Parameters.AddWithValue("@Approved", (int)ValueId.Approved);
            cmd.Parameters.AddWithValue("@PFMSFileGenerated", (int)ValueId.PFMSFileGenerated);
            cmd.Parameters.AddWithValue("@PFMSValidateComplete", (int)ValueId.PFMSValidateComplete);
            cmd.Parameters.AddWithValue("@SanctionProcessed", (int)ValueId.SanctionProcessed);
            cmd.Parameters.AddWithValue("@SanctionIssued", (int)ValueId.SanctionIssued);
            if (AcademicSession != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession); }
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ScStSanctioningProcessSummary(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AcademicSession" }, new ArrayList() { AcademicSession });
                return RedirectToAction("ScStSanctioningProcessSummary", "Report", new { q = QueryString });
            }
            return View("ScStSanctioningProcessSummary", model);
        }
        [EncryptedActionParameter]
        public ActionResult ScStSanctioningProcessList(int ServiceCode, int ReportType, int AcademicSession)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Whethercondition = string.Empty;

            if (ReportType == (int)CountList.Type000) { Whethercondition += " and ApplicationStatusId in (@TEHSREC,@ISSUCER)  and ProcessstatusId<>@Verified  "; }
            if (ReportType == (int)CountList.Type001) { Whethercondition += " and ApplicationStatusId=@TEHSREC and ProcessstatusId in (@PFMSValidateComplete,@PFMSFileGenerated)   "; }
            if (ReportType == (int)CountList.Type002) { Whethercondition += " and ApplicationStatusId in (@TEHSREC,@ISSUCER) and ProcessstatusId in (@SanctionIssued,@SanctionProcessed) "; }
            if (ReportType == (int)CountList.Type003) { Whethercondition += " and ApplicationStatusId=@TEHSREC and ProcessstatusId=@SanctionProcessed "; }
            if (ReportType == (int)CountList.Type004) { Whethercondition += " and ApplicationStatusId=@ISSUCER and ProcessstatusId=@SanctionIssued "; }
            string Qry = @"select  AD.ApplicationNo,ApplicantName,to_char(ApplicantDob,'DD/MM/YYYY') as ApplicantDob,ApplicantGender,AD.ServiceCode,ServiceName,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,SchoolName, PAP.DepartmentId,SMVD1.ValueName as Department,to_char(AD.ApplicantDob,'DD/MM/YYYY') as DOB,AD.ApplicationStatusId,coalesce(sum(Feeamount),0) as Recomended,to_char(AD.ApprovedDate,'DD/MM/YYYY') as ApprovedDate,SMVDD.ValueName as Category from applicationdetails AD inner join dgen.PrematApplicationProcess  PAP on PAP.ApplicationNo=AD.ApplicationNo inner join dgen.scstfeedetails  SCSTFD on SCSTFD.applicationNo=AD.ApplicationNo inner join ServiceMaster Sm on SM.ServiceCode=AD.ServiceCode inner join dgen.prematschoolmaster PSM on PSM.SchoolId = PAP.SchoolId inner join SelectMasterValueDetails SMVD on SMVD.ValueId=PAP.ProcessstatusId  inner join dgen.prematdistrictmaster PDM on PDM.DistrictId = PSM.District inner join SelectMasterValueDetails SMVDD on SMVDD.ValueId = PAP.CategoryId left outer join SelectMasterValueDetails SMVD1 on SMVD1.ValueId = PAP.DepartmentId  left outer join dgen.prematzonemaster PZM on PZM.ZoneId = PSM.SubDivision where AD.ServiceCode in (@ServiceCode)  and FeeinitiateBy=@FeeinitiateBy and PAP.AcademicSession=@AcademicSession " + Whethercondition + " group by  AD.ApplicationNo,ApplicantName, ApplicantDob,ApplicantGender,AD.ServiceCode,ServiceName,ApplicationDate,SchoolName, PAP.DepartmentId,SMVD1.ValueName,AD.ApplicantDob,AD.ApplicationStatusId,SMVD.ValueName,SMVDD.ValueName";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@Verified", (int)ValueId.Verified);
            cmd.Parameters.AddWithValue("@Approved", (int)ValueId.Approved);
            cmd.Parameters.AddWithValue("@PFMSFileGenerated", (int)ValueId.PFMSFileGenerated);
            cmd.Parameters.AddWithValue("@PFMSValidateComplete", (int)ValueId.PFMSValidateComplete);
            cmd.Parameters.AddWithValue("@SanctionProcessed", (int)ValueId.SanctionProcessed);
            cmd.Parameters.AddWithValue("@SanctionIssued", (int)ValueId.SanctionIssued);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();
            model.AcademicSessionType = AcademicSession + "-" + (AcademicSession + 1);
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ZoneDepartmentWiseSCSTReport(int? AcademicSession = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string whereCondition = string.Empty, Qry = string.Empty;
            if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
            if (AcademicSession == (int)CountList.Type000)
            {
                AcademicSession = 2016;
            }

            if (Sessions.getEmployeeUser().AuthorizationId != ((int)CountList.Type000).ToString())
            {
                model.Flag = Utility.SelectColumnsValue("dgen.prematzonemaster", "ZoneId", "ZoneId", Sessions.getEmployeeUser().AuthorizationId)[0];
            }
            else
            {
                model.Flag = ((int)CountList.Type000).ToString();
            }

            Qry = "select SMVVD.ValueName as DepartmentName,SMVVD.ValueId as DepartmentId,count(AD.ApplicationNo) as TotalReceived,coalesce(sum(case when ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and PAP.ProcessStatusId=@ProcessStatusId and whetherrevertback=false then 1 end),0) as PendingVerification,coalesce(sum(case when ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and WhetherRevertBack=true then 1 end),0) as PendingReVerification,coalesce(sum(case when ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=true then 1 end),0) as PositiveVerification,coalesce(sum(case when ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=false then 1 end),0) as NegativeVerification,coalesce(sum(case when ApplicationStatusId=@TEHSPEN and PAP.SchoolId is not null then 1 end),0) as PendingForApproval,coalesce(sum(case when ApplicationStatusId not in (@TEHSPEN,@OBSPEND,@TEHSREJ) and PAP.SchoolId is not null then 1 end),0) as Approved,coalesce(sum(case when ApplicationStatusId=@TEHSREJ and PAP.SchoolId is not null then 1 end),0) as RejectedBySchool,coalesce(sum(case when ApplicationStatusId=@TEHSREC then 1 end),0) as PendingForSanction,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Sanctioned from selectmastervaluetodetails SMVTD inner join selectMasterValuedetails SMVVD on SMVVD.ValueId=SMVTD.ValueId inner join selectmastervalue smv on smv.mastervalueid=SMVTD.mastervalueid inner join dgen.prematschoolmaster PSM on PSM.DepartmentID = SMVVD.ValueId inner join dgen.prematzonemaster PZM on PZM.ZoneId = PSM.SubDivision left outer join dgen.prematapplicationprocess PAP on PAP.DepartmentId = SMVVD.ValueId and PSM.SchoolId = PAP.SchoolId left outer join applicationdetails AD on AD.ApplicationNo = PAP.ApplicationNo and AD.ServiceCode in (@ParamServiceCode) and AD.ServiceCode not in(4015) where SMVTD.mastervalueid=@MasterValueId and AcademicSession=@AcademicSession";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@ParamDistrictCode"; }
            if (Sessions.getEmployeeUser().AuthorizationId != ((int)CountList.Type000).ToString()) { Qry += " and ZoneId =@ParamAuthorizationId"; }
            else { Qry += " and SMVVD.ValueId in (select distinct DepartmentId from dgen.prematdistrictmaster PDM inner join  dgen.prematzonemaster PZM on PZM.DistrictCode=PDM.DistrictId) "; }
            Qry += " group by SMVVD.ValueId,DepartmentName order by DepartmentName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SCSTApprovingDeptType);
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.PendingVerification);
            if (AcademicSession != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession); }
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ZoneDepartmentWiseSCSTReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AcademicSession" }, new ArrayList() { AcademicSession });
                return RedirectToAction("ZoneDepartmentWiseSCSTReport", "Report", new { q = QueryString });
            }
            return View("ZoneDepartmentWiseSCSTReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ZoneWiseSCSTRepor(int DepartmentId, int AcademicSession)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;

            string Qry = "select  SMVVD.ValueName as DepartmentName,SMVVD.ValueId as DepartmentId ,ZoneName,ZoneId,count(AD.ApplicationNo) as TotalReceived,coalesce(sum(case when ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and PAP.ProcessStatusId=@ProcessStatusId and whetherrevertback=false then 1 end),0) as PendingVerification,coalesce(sum(case when ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and WhetherRevertBack=true then 1 end),0) as PendingReVerification,coalesce(sum(case when ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=true then 1 end),0) as PositiveVerification,coalesce(sum(case when ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=false then 1 end),0) as NegativeVerification,coalesce(sum(case when ApplicationStatusId=@TEHSPEN and PAP.SchoolId is not null then 1 end),0) as PendingForApproval,coalesce(sum(case when ApplicationStatusId not in (@TEHSPEN,@OBSPEND,@TEHSREJ) and PAP.SchoolId is not null then 1 end),0) as Approved,coalesce(sum(case when ApplicationStatusId=@TEHSREJ and PAP.SchoolId is not null then 1 end),0) as RejectedBySchool,coalesce(sum(case when ApplicationStatusId=@TEHSREC then 1 end),0) as PendingForSanction,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Sanctioned from selectmastervaluetodetails SMVTD inner join selectMasterValuedetails SMVVD on SMVVD.ValueId=SMVTD.ValueId inner join selectmastervalue smv on smv.mastervalueid=SMVTD.mastervalueid inner join dgen.prematdistrictmaster PDM on PDM.DepartmentId=SMVTD.ValueId inner join  dgen.prematzonemaster PZM on PZM.DistrictCode=PDM.DistrictId inner join dgen.prematapplicationprocess PAP on PAP.DepartmentId=SMVVD.ValueId inner join  dgen.prematschoolmaster PSM on PSM.DepartmentId=SMVVD.ValueId and PSM.District=PDM.DistrictId and PSM.SubDivision=PZM.ZoneId and PSM.SchoolId=PAP.SchoolId inner join applicationdetails AD on AD.ApplicationNo=PAP.ApplicationNo and AD.ServiceCode in (@ParamServiceCode) and AD.ServiceCode not in(4015) where SMVTD.mastervalueid=@MasterValueId and SMVVD.ValueId =@DepartmentId  and AcademicSession=@AcademicSession ";
            if (Sessions.getEmployeeUser().AuthorizationId != ((int)CountList.Type000).ToString()) { Qry += " and ZoneId=@ParamAuthorizationId "; }
            Qry += " group by DepartmentName,SMVVD.ValueId,ZoneName,ZoneId order by ZoneName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DepartmentId", DepartmentId);
            cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SCSTApprovingDeptType);
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.PendingVerification);
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();
            model.AcademicSessionType = AcademicSession + "-" + (AcademicSession + 1);
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ZoneWiseSchoolSCSTReport(int DepartmentId, int ZoneId, int AcademicSession)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;

            string Qry = "select SM.valueid as DepartmentId,SM.valuename as DepartmentName,SMM.valuename as SchoolType,ZoneName,ZoneId,PSM.SchoolId,SchoolName,SchoolAddress, count(AD.ApplicationNo) as TotalReceived,coalesce(sum(case when ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and PAP.ProcessStatusId=@ProcessStatusId and whetherrevertback=false then 1 end),0) as PendingVerification,coalesce(sum(case when ApplicationStatusId=@OBSPEND and PAP.SchoolId is not null and WhetherRevertBack=true then 1 end),0) as PendingReVerification,coalesce(sum(case when ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=true then 1 end),0) as PositiveVerification,coalesce(sum(case when ApplicationStatusId<>@OBSPEND and PAP.SchoolId is not null and whetherrecommended=false then 1 end),0) as NegativeVerification,coalesce(sum(case when ApplicationStatusId=@TEHSPEN and PAP.SchoolId is not null then 1 end),0) as PendingForApproval,coalesce(sum(case when ApplicationStatusId not in (@TEHSPEN,@OBSPEND,@TEHSREJ) and PAP.SchoolId is not null then 1 end),0) as Approved,coalesce(sum(case when ApplicationStatusId=@TEHSREJ and PAP.SchoolId is not null then 1 end),0) as RejectedBySchool,coalesce(sum(case when ApplicationStatusId=@TEHSREC then 1 end),0) as PendingForSanction,coalesce(sum(case when ApplicationStatusId=@ISSUCER then 1 end),0) as Sanctioned from dgen.prematschoolmaster PSM inner join  dgen.prematzonemaster PZM on PZM.zoneid=PSM.subdivision inner join selectmastervaluedetails SM on SM.valueid=PSM.departmentid inner join selectmastervaluedetails SMM on SMM.valueid=PSM.SchoolTypeId left outer join dgen.prematapplicationprocess PAP on PSM.SchoolId=PAP.SchoolId left outer join applicationdetails AD on AD.ApplicationNo=PAP.ApplicationNo  and AD.ServiceCode in (@ParamServiceCode) and AD.ServiceCode not in(4015)  where PSM.departmentid =@DepartmentId and PZM.ZoneId=@ZoneId and AcademicSession=@AcademicSession group by ZoneName,ZoneId,PSM.SchoolId,SchoolName,SchoolAddress,SM.valueid,SM.valuename,SMM.valuename order by  SchoolName,ZoneName ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DepartmentId", DepartmentId);
            cmd.Parameters.AddWithValue("@ZoneId", ZoneId);
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.PendingVerification);
            model.data = data.GetDataTable(cmd);
            model.AcademicSession = AcademicSession.ToString();
            model.AcademicSessionType = AcademicSession + "-" + (AcademicSession + 1);
            return View(model);
        }




        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult UsersNotLoggedInYet()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string whereCondition = string.Empty;

            string Qry = "select um.userid,sm.schoolid,sm.schoolname,sm.schooladdress,mv.valuename as departmentname, dm.districtname, zm.zonename from usermaster um inner join dgen.prematschoolmaster sm on sm.schoolid=um.authorizationid inner join dgen.prematdistrictmaster dm on dm.districtid=sm.district inner join selectmastervaluedetails mv on mv.valueid=sm.departmentid left outer join dgen.prematzonemaster zm on zm.zoneid=sm.subdivision where deptcode=@ParamDeptCode and whetherpasswordchange = false order by mv.valuename, sm.schoolname";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult SchoolWiseTotalReceived()
        {
            ReportModels model = new ReportModels();
            model.data = new DataTable();
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult SchoolWiseTotalReceived(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = @"select ServiceName,ValueName as DepartmentName,SCD.SchoolId,case when SCD.SchoolId is null then 'Outside Delhi' else SchoolName end as SchoolName,case when SCD.SchoolId is null then 'Outside Delhi' else SchoolAddress end as SchoolAddress ,case when SCD.SchoolId is null then 'Outside Delhi' else DistrictName end as DistrictName ,case when SCD.SchoolId is null then 'Outside Delhi' else ZoneName end as ZoneName , count(SCD.ApplicationNo) as applications  from selectmastervaluedetails SMVD inner join (select  ApplicationNo,SchoolId,DepartmentId from dgen.applicationdetailsprematssc union all  select  ApplicationNo,SchoolId,DepartmentId from dgen.applicationdetailsprematobc union all 
                                select  ApplicationNo,SchoolId,DepartmentId from dgen.applicationdetailspostmatobc union all
                                select  ApplicationNo,SchoolId,DepartmentId from dgen.applicationdetailsfinancialassistance union all
                                select  ApplicationNo,SchoolId,DepartmentId from dgen.applicationdetailsmeritprofessional union all
                                select  ApplicationNo,SchoolId,DepartmentId from dgen.applicationdetailsmeritscholarshipschool union all
                                select  ApplicationNo,SchoolId,DepartmentId from dgen.applicationdetailsbrambedkar) SCD on SCD.DepartmentId=SMVD.ValueId
                                inner join ApplicationDetails AD on AD.ApplicationNo=SCD.ApplicationNo
                                inner join ServiceMaster Sm on SM.ServiceCode=AD.ServiceCode
                                left outer join dgen.PrematSchoolMaster PSM on PSM.SchoolId=SCD.SchoolId
                                left outer join dgen.PrematDistrictMaster PDM on PDM.districtId=PSM.District
                                left outer join dgen.PrematZoneMaster PZM on PZM.ZoneId=PSM.SubDivision
                                where SCD.DepartmentId=@DepartmentId
                                group by DepartmentName,ServiceName,SCD.SchoolId,SchoolName,SchoolAddress,DistrictName,ZoneName
                                order by SchoolName,ServiceName";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@DepartmentId", model.DepartmentId);
                model.data = data.GetDataTable(cmd);
                return View(model);
            }
            return View("SchoolWiseTotalReceived", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult VerificationPendingList()
        {
            ReportModels model = new ReportModels();
            model.data = new DataTable();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult VerificationPendingList(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = @"select SMVD.ValueName as DepartmentName,SCD.SchoolId,case when SCD.SchoolId is null then 'Outside Delhi' else SchoolName end as SchoolName,case when SCD.SchoolId is null then 'Outside Delhi' else SchoolAddress end as SchoolAddress ,case when SCD.SchoolId is null then 'Outside Delhi' else DistrictName end as DistrictName ,case when SCD.SchoolId is null then 'Outside Delhi' else ZoneName end as ZoneName , count(SCD.ApplicationNo) as applications  from selectmastervaluedetails SMVD inner join (select  ApplicationNo,SchoolId,DepartmentId,whetherverified from dgen.applicationdetailsprematssc union all 
                                select  ApplicationNo,SchoolId,DepartmentId,whetherverified from dgen.applicationdetailsprematobc union all 
                                select  ApplicationNo,SchoolId,DepartmentId,whetherverified from dgen.applicationdetailspostmatobc union all
                                select  ApplicationNo,SchoolId,DepartmentId,whetherverified from dgen.applicationdetailsfinancialassistance union all
                                select  ApplicationNo,SchoolId,DepartmentId,whetherverified from dgen.applicationdetailsmeritprofessional union all
                                select  ApplicationNo,SchoolId,DepartmentId,whetherverified from dgen.applicationdetailsmeritscholarshipschool union all
                                select  ApplicationNo,SchoolId,DepartmentId,whetherverified from dgen.applicationdetailsbrambedkar) SCD on SCD.DepartmentId=SMVD.ValueId
                                left outer join dgen.PrematSchoolMaster PSM on PSM.SchoolId=SCD.SchoolId
                                left outer join dgen.PrematDistrictMaster PDM on PDM.districtId=PSM.District
                                left outer join dgen.PrematZoneMaster PZM on PZM.ZoneId=PSM.SubDivision
                                where SCD.DepartmentId=@DepartmentId and whetherverified=false
                                group by DepartmentName,SCD.SchoolId,SchoolName,SchoolAddress,DistrictName,ZoneName
                                order by applications desc";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@DepartmentId", model.DepartmentId);
                model.data = data.GetDataTable(cmd);
                return View(model);
            }
            return View("VerificationPendingList", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ApplicaionWiseFeeDetails()
        {
            ReportModels model = new ReportModels();
            model.data = new DataTable();
            return View(model);
        }
        public ActionResult DownloadStatusWiseSCSTFile(int? AcademicSession = 0)
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.P118).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.ApplicationDetailsPrematsSC = new ApplicationDetailsPrematsSC();
            string join = string.Empty, cond = string.Empty;

            if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
            string Qry = string.Empty;
            NpgsqlCommand cmd = new NpgsqlCommand();
            if (AcademicSession == (int)CountList.Type000)
            {
                Qry = "select s1.valuename from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SCSTWelfareAcadmicSession);
                AcademicSession = Convert.ToInt32(data.SelectColumns(cmd)[0]);
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DownloadStatusWiseSCSTFile(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string cond = string.Empty;


                string Qry = @"select AD.ApplicationNo as ""Application No"",case when SUD.ApplicantName is null then AD.ApplicantName else SUD.ApplicantName end as ""Applicant Name"",case when SUD.ApplicantGender is null then AD.ApplicantGender else SUD.ApplicantGender end as Gender,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ""Address"",ApplicantMobileNo as ""Applicant Mobile No"",case when PAP.SchoolId is null then 'Out Side Delhi' else PSM.SchoolName end as ""School Name"",case when PAP.SchoolId is null then 'Out Side Delhi' else PSM.SchoolAddress end as ""School Address"", BM.BankName as ""Bank Name"",IFSCCode,AccountNo as ""Account Number"",coalesce(sum(Feeamount),0) as ""Payment Amount"" from applicationdetails AD inner join dgen.PrematApplicationProcess  PAP on PAP.ApplicationNo=AD.ApplicationNo  inner join (select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailsfinancialassistance union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailsprematssc union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailsmeritscholarshipschool union all select ApplicationNo,AccountNo,Ifsccode,bankcode from  dgen.applicationdetailsbrambedkar union all select ApplicationNo,AccountNo,Ifsccode,bankcode from  dgen.applicationdetailsmeritprofessional union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailsprematobc union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailspostmatobc union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailsprematscssd union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailspostmatscssd  ) SCD on AD.ApplicationNo=SCD.ApplicationNo  inner join applicationenclosuredetails AED on AED.ApplicationNo=AD.ApplicationNo  inner join ServiceMaster Sm on SM.ServiceCode=AD.ServiceCode inner join BankMaster BM on BM.BankCode=SCD.BankCode inner join SelectMasterValueDetails SMVVD on SMVVD.ValueId=PAP.ProcessstatusId left outer join dgen.scstfeedetails  SCSTFD on SCSTFD.applicationNo=AD.ApplicationNo  and FeeinitiateBy=@FeeinitiateBy left outer join dgen.prematschoolmaster PSM on PSM.SchoolId = PAP.SchoolId  left outer  join dgen.prematdistrictmaster PDM on PDM.DistrictId = PSM.District left outer join SelectMasterValueDetails SMVD1 on SMVD1.ValueId = PAP.DepartmentId  left outer join dgen.scstupdatedapplicationdetail SUD on SUD.ApplicationNo=AD.ApplicationNo left outer join dgen.prematzonemaster PZM on PZM.ZoneId = PSM.SubDivision where AD.ServiceCode in (@ServiceCode) and AED.DocumentId=@DocumentId and PAP.AcademicSession = @AcademicSession ";
                if (!string.IsNullOrEmpty(model.SCSTDepartmentId)) { Qry += " and PAP.DepartmentId = @DepartmentId "; }
                if (!string.IsNullOrEmpty(model.DistrictCode)) { Qry += " and PSM.District = @DistrictId "; }
                if (!string.IsNullOrEmpty(model.SCSTZoneId)) { Qry += " and PSM.SubDivision = @ZoneId "; }
                if (!string.IsNullOrEmpty(model.SchoolId)) { Qry += " and PAP.SchoolId = @SchoolId"; }
                if (!string.IsNullOrEmpty(model.ApplicantCategory)) { Qry += " and PAP.CategoryId = @CategoryId"; }

                if (Convert.ToInt32(model.StatusId) == (int)CountList.Type000) { Qry += " and AD.ApplicationStatusId in (@OBSPEND,@DEALOLR) "; }
                else if (Convert.ToInt32(model.StatusId) == (int)CountList.Type001) { Qry += " and AD.ApplicationStatusId in (@TEHSPEN) "; }
                else if (Convert.ToInt32(model.StatusId) == (int)CountList.Type002) { Qry += " and AD.ApplicationStatusId in (@TEHSREC) "; }
                else if (Convert.ToInt32(model.StatusId) == (int)CountList.Type003) { Qry += " and AD.ApplicationStatusId in (@ISSUCER) "; }
                else if (Convert.ToInt32(model.StatusId) == (int)CountList.Type004) { Qry += " and AD.ApplicationStatusId in (@TEHSREC) and PAP.ProcessStatusId=@PFMSValidateComplete "; }
                else if (Convert.ToInt32(model.StatusId) == (int)CountList.Type005) { Qry += " and AD.ApplicationStatusId not in (@OBSPEND,@DEALOLR) and PAP.whetherrecommended=false "; }
                else if (Convert.ToInt32(model.StatusId) == (int)CountList.Type006) { Qry += " and AD.ApplicationStatusId in (@TEHSREJ) "; }

                Qry += " and AD.ApplicationNo not in (select applicationno from applicationdetailstempcheck where detailstypeid=@detailstypeid)"; // to skip the duplicate records from temp table
                Qry += " group by AD.ApplicationNo,SUD.ApplicantName,SUD.ApplicantGender,PAP.SchoolId,PSM.SchoolName,PSM.SchoolAddress,BM.BankName,IFSCCode,AccountNo order By AD.ApplicationNo ";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                cmd.Parameters.AddWithValue("@DepartmentId", model.SCSTDepartmentId);
                cmd.Parameters.AddWithValue("@DistrictId", model.DistrictCode);
                cmd.Parameters.AddWithValue("@ZoneId", model.SCSTZoneId);
                cmd.Parameters.AddWithValue("@SchoolId", model.SchoolId);
                cmd.Parameters.AddWithValue("@CategoryId", model.ApplicantCategory);
                cmd.Parameters.AddWithValue("@ApplicationStatusId", model.StatusId);
                cmd.Parameters.AddWithValue("@AcademicSession", model.AcademicSession);
                cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                cmd.Parameters.AddWithValue("@DocumentId", (int)DocumentId.AadhaarCardCopy);
                cmd.Parameters.AddWithValue("@detailstypeid", (int)AppTempCheck.Value0858);

                cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
                cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
                cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
                cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
                cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
                cmd.Parameters.AddWithValue("@PFMSValidateComplete", (int)ValueId.PFMSValidateComplete);

                model.data = data.GetDataTable(cmd);

                if (model.data.Rows.Count > 0)
                {
                    var grid = new System.Web.UI.WebControls.GridView();
                    grid.DataSource = model.data;
                    grid.DataBind();
                    Response.Clear();
                    Response.AddHeader("content-disposition", "attachment; filename=DownloadData.xls");
                    Response.Charset = "";
                    Response.ContentType = "application/vnd.xls";
                    System.IO.StringWriter stringWrite = new System.IO.StringWriter();
                    System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
                    grid.RenderControl(htmlWrite);
                    string style = @"<style> td { mso-number-format:\@; } </style>";
                    Response.Write(style);

                    Response.Write(stringWrite.ToString());
                    Response.End();


                }
                else
                {
                    ViewData["message"] = "No Record Found";
                    return View("message");
                }

            }
            return View("DownloadStatusWiseSCSTFile", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ServiceWisePreMatReport(string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = " select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SM.ServiceName,SM.ServiceCode,DM.DistrictName,DM.DistrictCode,AD.applicationsubdivcode,SD.SubDivDescription,coalesce(sum(case when ApplicationSourceId=@Offline then 1 end),0) as  CSCReceived,coalesce(sum(case when ApplicationSourceId=@Online then 1 end),0) CitizenReceived,coalesce(sum(case when SC.SchoolId is not null then 1 end),0) as  delhiapp,coalesce(sum(case when SC.SchoolId is null then 1 end),0) oodelhiapp,coalesce(sum(case when Applicationstatusid=@OBSPEND then 1 end),0) SchoolPend,coalesce(sum(case when Applicationstatusid=@DEALOLR then 1 end),0) DelPend,coalesce(sum(case when Applicationstatusid=@TEHSPEN then 1 end),0) ApprovalPend,coalesce(sum(case when Applicationstatusid=@ISSUCER then 1 end),0) Issued from applicationdetails  AD inner join dgen.applicationdetailsprematssc SC on AD.ApplicationNo=SC.ApplicationNo left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SD on AD.applicationsubdivcode=SD.SubDivCode right outer join dbo.ServiceMaster SM on AD.ServiceCode=SM.ServiceCode where AD.ServiceCode in (@ParamServiceCode)";
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by SD.SubDivDescription,AD.applicationsubdivcode,DM.DistrictCode,DM.DistrictName,SM.ServiceCode,SM.ServiceName order by SM.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
            cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
            cmd.Parameters.AddWithValue("@Online", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@Offline", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult ApplicationDetails(int? subDiv, int? service, int? status)
        {
            if (subDiv == null && service == null && status == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }
            string statusId = string.Empty;
            if (status == 4) { statusId = " and AD.ApplicationStatusId not in(16,12,13) and (select DATE_PART('day',now()- AD.applicationdate)>SR.processingdays)"; }
            if (status == 5) { statusId = " and AD.ApplicationStatusId not in(16,12,13) and (select DATE_PART('day',now()- AD.applicationdate)<=SR.processingdays)"; }
            else if (status == (int)Status.ISSUCER) { statusId = " and AD.ApplicationStatusId in (16)"; }
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode  inner join dbo.ServiceMaster SR on AD.servicecode=SR.servicecode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where AD.ServiceCode=@ServiceCode and AD.applicationsubdivcode=@SubDivCode " + statusId + "  group by AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,AD.ApplicantAddress,AD.ApplicantDob,SL.StatusName,AD.ServiceCode order by SL.StatusName";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        #endregion

        #region Labour Department Reports
        [ValidateOnlyIncomingValues]
        public ActionResult DistrictwiseLabourReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("DistrictwiseLabourReport", "Report", new { q = QueryString });
            }
            return View("DistrictwiseLabourReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DistrictwiseLabourReport(int? service, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,DM.DistrictCode,DM.DistrictName,
                        coalesce(count(applicationno)) TotalApplicationReceived,
                        coalesce(sum(case when ApplicationStatusId not in (@ApplicationStatus6,@ApplicationStatus16,@ApplicationStatus1,@ApplicationStatus14) then 1 end),0) as UnderProcess,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus6) then 1 end),0) as ApplicationApproved,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus16) then 1 end),0) as CertificateIssued,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus1) then 1 end),0) as CertificateCancel,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus14) then 1 end),0) as ApplicationRejected  
                        from dbo.ApplicationDetails AD right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode 
                        right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode  
                        where DM.deptcode = @ParamDeptCode and SC.whetheractive = @whetheractive ";
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            Qry += " group by DM.DistrictCode,DM.DistrictName order by DM.DistrictName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@whetheractive", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus6", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult LabourServicewiseReport(int? distId, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,DM.DistrictCode,DM.DistrictName,SC.ServiceCode,SC.ServiceName,
                        coalesce(count(applicationno)) TotalApplicationReceived,
                        coalesce(sum(case when ApplicationStatusId not in (@ApplicationStatus6,@ApplicationStatus16,@ApplicationStatus1,@ApplicationStatus14) then 1 end),0) as UnderProcess,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus6) then 1 end),0) as ApplicationApproved,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus16) then 1 end),0) as CertificateIssued,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus1) then 1 end),0) as CertificateCancel,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus14) then 1 end),0) as ApplicationRejected  
                        from dbo.ApplicationDetails AD right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode  
                        right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode = @ParamDeptCode and SC.WhetherActive = @WhetherActive";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }   
            if (!string.IsNullOrEmpty(distId.ToString())) { Qry += " and DM.DistrictCode=@Districtcode"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by DM.DistrictCode,DM.DistrictName,SC.ServiceCode,SC.ServiceName order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@Districtcode", distId);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus6", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult LabourApplicationListDetails(int? distId, int? service, int? status, string DTF, string DTT, int? PageIndex = 1)
        {
            if (distId == null && service == null && status == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }
            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "distId=" + distId.ToString());
            Parameters.Add(1, "service=" + service.ToString());
            Parameters.Add(2, "status=" + status.ToString());
            if (!string.IsNullOrEmpty(DTF)) { Parameters.Add(3, "DTF=" + DTF.ToString()); }
            if (!string.IsNullOrEmpty(DTT)) { Parameters.Add(4, "DTT=" + DTT.ToString()); }
            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                GetData data = new GetData();
                string statusId = string.Empty, Qry = string.Empty;
                if (status == 1) { statusId = " and AD.ApplicationStatusId not in (6,16,1,14)"; }
                else if (status == 2) { statusId = " and AD.ApplicationStatusId in(6)"; }
                else if (status == 3) { statusId = " and AD.ApplicationStatusId in(16)"; }
                else if (status == 4) { statusId = " and AD.ApplicationStatusId in(1)"; }
                else if (status == 5) { statusId = " and AD.ApplicationStatusId in(14)"; }
                else if (status == 11) { statusId = " "; }

                Qry = "Select distinct @DisplayFromDate as FromDate, @DisplayToDate as ToDate,@RejectionFlag as RejectionFlag,DM.DistrictCode,DM.DistrictName,to_char(AD.LastActionDate,'DD/MM/YYYY') as LastActionDate,AD.ServiceCode,DM.DistrictCode,DM.DistrictName,AD.ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,case when AD.rejectionreasoncode=@OtherReason then AD.applicationremarks else RE.reasondetail end as rejectionreason from dbo.ApplicationDetails AD left outer join (select distinct applicationno from (select applicationno from verifierapplicationdetails union select applicationno from applicationverificationletterdetails)a) VD on VD.ApplicationNo=AD.ApplicationNo left outer join applicationverificationletterdetails LD on LD.ApplicationNo=AD.ApplicationNo left outer join reasonmaster RE on RE.reasoncode=AD.rejectionreasoncode left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode where AD.ServiceCode=@ServiceCode and  DM.DistrictCode = @DistrictCode " + statusId;
                if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
                if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
                Qry += " order by AD.ApplicationNo";

                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ServiceCode", service);
                cmd.Parameters.AddWithValue("@DistrictCode", distId);
                cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
                cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
                cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
                cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
                cmd.Parameters.AddWithValue("@OtherReason", (int)RejectionReason.Other);
                cmd.Parameters.AddWithValue("@RejectionFlag", status == 14 || status == 8);
                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "LabourApplicationListDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "LabourApplicationListDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View(model);
        }
        [ValidateOnlyIncomingValues]
        public ActionResult LabourServiceReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("LabourServiceReport", "Report", new { q = QueryString });
            }
            return View("LabourServiceReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult LabourServiceReport(string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SC.ServiceCode,SC.ServiceName,
                        coalesce(count(applicationno)) TotalApplicationReceived,
                        coalesce(sum(case when ApplicationStatusId not in (@ApplicationStatus6,@ApplicationStatus16,@ApplicationStatus1,@ApplicationStatus14) then 1 end),0) as UnderProcess,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus6) then 1 end),0) as ApplicationApproved,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus16) then 1 end),0) as CertificateIssued,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus1) then 1 end),0) as CertificateCancel,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus14) then 1 end),0) as ApplicationRejected  
                        from dbo.ApplicationDetails AD right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode
                        right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where SC.deptcode = @ParamDeptCode and SC.Whetheractive = @Whetheractive";
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            Qry += " group by SC.ServiceCode,SC.ServiceName order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@Whetheractive", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus6", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult LabourServiceDistrictReport(int? service, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,DM.DistrictCode,DM.DistrictName,SC.ServiceCode,SC.ServiceName,
                        coalesce(count(Applicationno)) TotalApplicationReceived,
                        coalesce(sum(case when ApplicationStatusId not in (@ApplicationStatus6,@ApplicationStatus16,@ApplicationStatus1,@ApplicationStatus14) then 1 end),0) as UnderProcess,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus6) then 1 end),0) as ApplicationApproved,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus16) then 1 end),0) as CertificateIssued,
                        coalesce(sum(case when ApplicationStatusId in (@ApplicationStatus1) then 1 end),0) as CertificateCancel,
                        coalesce(sum(case when ApplicationStatusId in(@ApplicationStatus14) then 1 end),0) as ApplicationRejected  
                        from dbo.ApplicationDetails AD right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode
                        right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode";
            if (!string.IsNullOrEmpty(service.ToString())) { Qry += " and AD.ServiceCode = @ServiceCode"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            Qry += " group by DM.DistrictCode,DM.DistrictName,SC.ServiceCode,SC.ServiceName order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@ApplicationStatus16", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@ApplicationStatus6", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ApplicationStatus1", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@ApplicationStatus14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        #endregion

        #region NFS Department Report
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult NFSDistWiseApplicationStatus(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("NFSDistWiseApplicationStatus", "Report", new { q = QueryString });
            }
            return View("NFSDistWiseApplicationStatus", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult NFSDistWiseApplicationStatus(string DTF, string DTT)
        {
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { return RedirectToAction("NFSCircleWiseApplicationStatus"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,DM.DistrictCode,DM.DistrictName,
                        coalesce(count(applicationno)) TotalReceived,
                        coalesce(sum(case when ApplicationStatusId in (@status25,@status29,@status32,@status33) then 1 end),0) as UnderProcess,
                        coalesce(sum(case when ApplicationStatusId not in (@status25,@status29,@status32,@status33,@status6,@status14) then 1 end),0) as PendingforApproval,
                        coalesce(sum(case when ApplicationStatusId in (@status6) then 1 end),0) as ApplicationApproved,
                        coalesce(sum(case when ApplicationStatusId in (@status14) then 1 end),0) as ApplicationRejected  
                        from dbo.ApplicationDetails AD right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode  
                        where DM.deptcode = @ParamDeptCode and DM.stateid = @stateid ";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by DM.DistrictCode,DM.DistrictName order by DM.DistrictName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@status25", (int)Status.WEBPENC);
            cmd.Parameters.AddWithValue("@status29", (int)Status.SCOM029);
            cmd.Parameters.AddWithValue("@status32", (int)Status.SCOM032);
            cmd.Parameters.AddWithValue("@status33", (int)Status.SCOM033);
            cmd.Parameters.AddWithValue("@status6", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@status14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult NFSDistrictServiceWiseReport(int distId, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,DM.DistrictCode,DM.DistrictName,SC.ServiceCode,SC.ServiceName,
                        COALESCE(count(applicationno)) TotalReceived,
                        coalesce(sum(case when ApplicationStatusId in (@status25,@status29,@status32,@status33) then 1 end),0) as UnderProcess,
                        COALESCE(sum(case when ApplicationStatusId not in (@status25,@status29,@status32,@status33,@status6,@status14) then 1 end),0) as PendingforApproval,
                        COALESCE(sum(case when ApplicationStatusId in (@status6) then 1 end),0) as ApplicationApproved,
                        COALESCE(sum(case when ApplicationStatusId in (@status14) then 1 end),0) as ApplicationRejected
                        from dbo.ApplicationDetails AD right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode
                        right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(distId.ToString())) { Qry += " and DM.DistrictCode=@Districtcode"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by DM.DistrictCode,DM.DistrictName,SC.ServiceCode,SC.ServiceName order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@Districtcode", distId);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@status25", (int)Status.WEBPENC);
            cmd.Parameters.AddWithValue("@status29", (int)Status.SCOM029);
            cmd.Parameters.AddWithValue("@status32", (int)Status.SCOM032);
            cmd.Parameters.AddWithValue("@status33", (int)Status.SCOM033);
            cmd.Parameters.AddWithValue("@status6", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@status14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            return View("NFSDistrictServiceWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult NfsApplicationListDetails(int? distId, int? service, int? status, string DTF, string DTT, int? PageIndex = 1)
        {
            if (distId == null && service == null && status == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }
            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "distId=" + distId.ToString());
            Parameters.Add(1, "service=" + service.ToString());
            Parameters.Add(2, "status=" + status.ToString());
            if (!string.IsNullOrEmpty(DTF)) { Parameters.Add(3, "DTF=" + DTF.ToString()); }
            if (!string.IsNullOrEmpty(DTT)) { Parameters.Add(4, "DTT=" + DTT.ToString()); }
            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                GetData data = new GetData();
                string statusId = string.Empty, Qry = string.Empty;
                if (status == 14) { statusId = " and AD.ApplicationStatusId=14"; }
                else if (status == 5) { statusId = " and AD.ApplicationStatusId not in (25,29,32,33,6,14)"; }
                else if (status == 6) { statusId = " and AD.ApplicationStatusId in (6)"; }
                else if (status == 32) { statusId = " and AD.ApplicationStatusId in (25,29,32,33)"; }
                else if (status == 11) { statusId = " "; }

                Qry = "Select distinct @DisplayFromDate as FromDate, @DisplayToDate as ToDate,@RejectionFlag as RejectionFlag,DM.DistrictCode,DM.DistrictName,to_char(AD.LastActionDate,'DD/MM/YYYY') as LastActionDate,AD.ServiceCode,DM.DistrictCode,DM.DistrictName,AD.ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,case when AD.rejectionreasoncode=@OtherReason then AD.applicationremarks else RE.reasondetail end as rejectionreason from dbo.ApplicationDetails AD left outer join (select distinct applicationno from (select applicationno from verifierapplicationdetails union select applicationno from applicationverificationletterdetails)a) VD on VD.ApplicationNo=AD.ApplicationNo left outer join applicationverificationletterdetails LD on LD.ApplicationNo=AD.ApplicationNo left outer join reasonmaster RE on RE.reasoncode=AD.rejectionreasoncode left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode where AD.ServiceCode=@ServiceCode and  DM.DistrictCode = @DistrictCode " + statusId;
                if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
                if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
                if (status == 14) { Qry += " order by LastActionDate Desc"; }
                else { Qry += " order by AD.ApplicationNo"; }
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ServiceCode", service);
                cmd.Parameters.AddWithValue("@DistrictCode", distId);
                cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
                cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
                cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
                cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
                cmd.Parameters.AddWithValue("@OtherReason", (int)RejectionReason.Other);
                cmd.Parameters.AddWithValue("@RejectionFlag", status == 14 || status == 8);
                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "NfsApplicationListDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "NfsApplicationListDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult NFSServiceWiseApplicationStatus(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("NFSServiceWiseApplicationStatus", "Report", new { q = QueryString });
            }
            return View("NFSServiceWiseApplicationStatus", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult NFSServiceWiseApplicationStatus(string DTF, string DTT)
        {
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { return RedirectToAction("NFSCircleWiseApplicationStatus"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SC.ServiceCode,SC.ServiceName,
                        coalesce(count(applicationno)) TotalReceived,
                        coalesce(sum(case when ApplicationStatusId in (@status25,@status29,@status32,@status33) then 1 end),0) as UnderProcess,
                        coalesce(sum(case when ApplicationStatusId not in (@status25,@status29,@status32,@status33,@status6,@status14) then 1 end),0) as PendingforApproval,
                        coalesce(sum(case when ApplicationStatusId in (@status6) then 1 end),0) as ApplicationApproved,
                        coalesce(sum(case when ApplicationStatusId in (@status14) then 1 end),0) as ApplicationRejected  
                        from dbo.ApplicationDetails AD inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode
                        where SC.deptcode = @ParamDeptCode ";
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by SC.ServiceCode,SC.ServiceName order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@status25", (int)Status.WEBPENC);
            cmd.Parameters.AddWithValue("@status29", (int)Status.SCOM029);
            cmd.Parameters.AddWithValue("@status32", (int)Status.SCOM032);
            cmd.Parameters.AddWithValue("@status33", (int)Status.SCOM033);
            cmd.Parameters.AddWithValue("@status6", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@status14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult NFSServiceDistWiseReport(int service, string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,DM.DistrictCode,DM.DistrictName,SC.ServiceCode,SC.ServiceName,
                        coalesce(count(applicationno)) TotalReceived,
                        coalesce(sum(case when ApplicationStatusId in (@status25,@status29,@status32,@status33) then 1 end),0) as UnderProcess,
                        coalesce(sum(case when ApplicationStatusId not in (@status25,@status29,@status32,@status33,@status6,@status14) then 1 end),0) as PendingforApproval,
                        coalesce(sum(case when ApplicationStatusId in (@status6) then 1 end),0) as ApplicationApproved,
                        coalesce(sum(case when ApplicationStatusId in (@status14) then 1 end),0) as ApplicationRejected
                        from dbo.ApplicationDetails AD right outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode
                        right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode";
            if (!string.IsNullOrEmpty(service.ToString())) { Qry += " and AD.ServiceCode in (@ServiceCode)"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by DM.DistrictCode,DM.DistrictName,SC.ServiceCode,SC.ServiceName order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@status25", (int)Status.WEBPENC);
            cmd.Parameters.AddWithValue("@status29", (int)Status.SCOM029);
            cmd.Parameters.AddWithValue("@status32", (int)Status.SCOM032);
            cmd.Parameters.AddWithValue("@status33", (int)Status.SCOM033);
            cmd.Parameters.AddWithValue("@status6", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@status14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);

            return View("NFSServiceDistWiseReport", model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult NFSCircleWiseApplicationStatus(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("NFSCircleWiseApplicationStatus", "Report", new { q = QueryString });
            }
            return View("NFSCircleWiseApplicationStatus", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult NFSCircleWiseApplicationStatus(string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = @"select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SDM.SubDivCode,SDM.subdivdescription,coalesce(count(applicationno)) TotalReceived,coalesce(sum(case when ApplicationStatusId in (@status25,@status29,@status32,@status33) then 1 end),0) as UnderProcess,coalesce(sum(case when ApplicationStatusId not in (@status25,@status29,@status32,@status33,@status6,@status14) then 1 end),0) as PendingforApproval,coalesce(sum(case when ApplicationStatusId in (@status6) then 1 end),0) as ApplicationApproved,coalesce(sum(case when ApplicationStatusId in(@status14) then 1 end),0) as ApplicationRejected  from DistrictMaster DM inner join dbo.SubDivMaster SDM on SDM.DistrictCode=DM.DistrictCode left outer join dbo.ApplicationDetails AD  on SDM.SubDivCode=AD.ApplicationSubDivCode where DM.DeptCode=@ParamDeptCode ";
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by SDM.SubDivCode,SDM.subdivdescription order by subdivdescription";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@status25", (int)Status.WEBPENC);
            cmd.Parameters.AddWithValue("@status29", (int)Status.SCOM029);
            cmd.Parameters.AddWithValue("@status32", (int)Status.SCOM032);
            cmd.Parameters.AddWithValue("@status33", (int)Status.SCOM033);
            cmd.Parameters.AddWithValue("@status6", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@status14", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult NfsAppListDetails(int TypeId, int SubDivCode, string DTF, string DTT, int? PageIndex = 1)
        {
            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "TypeId=" + TypeId.ToString());
            Parameters.Add(1, "SubDivCode=" + SubDivCode.ToString());
            if (!string.IsNullOrEmpty(DTF)) { Parameters.Add(2, "DTF=" + DTF.ToString()); }
            if (!string.IsNullOrEmpty(DTT)) { Parameters.Add(3, "DTT=" + DTT.ToString()); }
            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                GetData data = new GetData();
                string statusId = string.Empty, Qry = string.Empty;
                if (TypeId == (int)CountList.Type001) { statusId = " and AD.ApplicationStatusId in (@status25,@status29,@status32,@status33) "; }
                else if (TypeId == (int)CountList.Type002) { statusId = " and AD.ApplicationStatusId not in (@status25,@status29,@status32,@status33,@status6,@status14)"; }
                else if (TypeId == (int)CountList.Type003) { statusId = " and AD.ApplicationStatusId in (@status6)"; }
                else if (TypeId == (int)CountList.Type004) { statusId = " and AD.ApplicationStatusId in (@status14)"; }

                Qry = "Select distinct @DisplayFromDate as FromDate, @DisplayToDate as ToDate,DM.DistrictCode,DM.DistrictName,to_char(AD.LastActionDate,'DD/MM/YYYY') as LastActionDate,AD.ServiceCode,DM.DistrictCode,DM.DistrictName,AD.ApplicationNo,AD.ApplicantName,SR.ServiceName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,case when AD.rejectionreasoncode=@OtherReason then AD.applicationremarks else RE.reasondetail end as rejectionreason from dbo.ApplicationDetails AD left outer join (select distinct applicationno from (select applicationno from verifierapplicationdetails union select applicationno from applicationverificationletterdetails)a) VD on VD.ApplicationNo=AD.ApplicationNo left outer join applicationverificationletterdetails LD on LD.ApplicationNo=AD.ApplicationNo left outer join reasonmaster RE on RE.reasoncode=AD.rejectionreasoncode left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join dbo.ServiceMaster SR on SR.ServiceCode=AD.ServiceCode where AD.ApplicationSubDivCode=@SubDivCode  " + statusId;
                if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
                if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
                Qry += " order by AD.ApplicationNo";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@SubDivCode", SubDivCode);
                cmd.Parameters.AddWithValue("@status25", (int)Status.WEBPENC);
                cmd.Parameters.AddWithValue("@status29", (int)Status.SCOM029);
                cmd.Parameters.AddWithValue("@status32", (int)Status.SCOM032);
                cmd.Parameters.AddWithValue("@status33", (int)Status.SCOM033);
                cmd.Parameters.AddWithValue("@status6", (int)Status.TEHSREC);
                cmd.Parameters.AddWithValue("@status14", (int)Status.TEHSREJ);
                cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
                cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
                cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
                cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
                cmd.Parameters.AddWithValue("@OtherReason", (int)RejectionReason.Other);
                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "NfsAppListDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "NfsAppListDetails", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View(model);
        }
        #endregion

        #region Administrative Reforms Department
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult MobileSahayakWiseReport(string DTF, string DTT, int? ServiceCode = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,receiveduser,count(Applicationno) as Received,coalesce(sum(case when Applicationstatusid not in (@CANCEL,@TEHSREJ,@ISSUCER,@TEHSOBJ) then 1 end),0) Pending,coalesce(sum(case when Applicationstatusid in (@TEHSOBJ) then 1 end),0) QueryRaised,coalesce(sum(case when Applicationstatusid in (@CANCEL,@ISSUCER) then 1 end),0) Disposed,coalesce(sum(case when Applicationstatusid in (@TEHSREJ) then 1 end),0) Rejected from applicationdetails AD inner join servicemaster SM on SM.ServiceCode=AD.ServiceCode inner join serviceattributemaster SAM on SAM.ServiceCode=SM.ServiceCode where whethersahayakapply=@WhetherSahayakApply and receivedpermission=@P136 ";
            if (ServiceCode != (int)CountList.Type000) { Qry += " and AD.ServiceCode=@ServiceCode "; }
            if (Sessions.getEmployeeUser().Permission == ((int)Permission.P136).ToString()) { Qry += " and receiveduser=@receiveduser"; }
            if (Sessions.getEmployeeUser().DeptCode != ((int)Department.Dept015).ToString()) { Qry += " and SM.deptcode=@ParamDeptCode"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@ParamDistrictCode"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by receiveduser";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@P136", (int)Permission.P136);
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@WhetherSahayakApply", CustomText.TRUE.ToString());
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            if (Sessions.getEmployeeUser().Permission == ((int)Permission.P136).ToString()) { cmd.Parameters.AddWithValue("@receiveduser", Sessions.getEmployeeUser().UserId); }
            model.data = data.GetDataTable(cmd);
            model.ServiceId = ServiceCode.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult MobileSahayakWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int ServiceCode = (int)CountList.Type000;
                if (!string.IsNullOrEmpty(model.ServiceCode)) { ServiceCode = Convert.ToInt32(model.ServiceCode); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT", "ServiceCode" }, new ArrayList() { model.DateFrom, model.DateTo, ServiceCode });
                return RedirectToAction("MobileSahayakWiseReport", "Report", new { q = QueryString });
            }
            return View("BasicDistWiseReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult MobileSahayakWiseDetailsReport(int TypeId, string UserId, int? ServiceCode, string DTF, string DTT, int? PageIndex = 1)
        {
            if (string.IsNullOrEmpty(UserId)) { return RedirectToAction("UnauthorizedRequest", "Error"); }

            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "TypeId=" + TypeId.ToString());
            Parameters.Add(1, "UserId=" + UserId.ToString());
            Parameters.Add(2, "ServiceCode=" + ServiceCode.ToString());
            if (!string.IsNullOrEmpty(DTF)) { Parameters.Add(3, "DTF=" + DTF.ToString()); }
            if (!string.IsNullOrEmpty(DTT)) { Parameters.Add(4, "DTT=" + DTT.ToString()); }
            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                GetData data = new GetData();
                string statusId = string.Empty, Qry = string.Empty;
                if (TypeId == (int)CountList.Type000) { }
                if (TypeId == (int)CountList.Type001) { statusId = " and AD.ApplicationStatusId not in (@CANCEL,@TEHSREJ,@ISSUCER,@TEHSOBJ)"; }
                else if (TypeId == (int)CountList.Type002) { statusId = " and AD.ApplicationStatusId in (@TEHSOBJ)"; }
                else if (TypeId == (int)CountList.Type003) { statusId = " and AD.ApplicationStatusId in (@CANCEL,@ISSUCER)"; }
                else if (TypeId == (int)CountList.Type004) { statusId = " and AD.ApplicationStatusId in (@TEHSREJ)"; }

                Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SM.DeptCode,DeptName,ApplicationRemarks,AD.ApplicationNo,AD.ApplicantName,SM.ServiceName,AD.ApplicantGender,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,AD.ApplicationStatusid,SL.StatusName,receiveduser,DistrictName,subdivdescription from applicationdetails AD inner join servicemaster SM on SM.ServiceCode=AD.ServiceCode inner join serviceattributemaster SAM on SAM.ServiceCode=SM.ServiceCode inner join DeptMaster DMM on DMM.DeptCode=SM.DeptCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId left outer join districtmaster DM on DM.districtcode=AD.ApplicationdistrictCode left outer join subdivmaster SDM on SDM.subdivcode=AD.ApplicationSubdivCode where receivedpermission=@P136 and whethersahayakapply=@WhetherSahayakApply and receiveduser=@ReceivedUser " + statusId;
                if (ServiceCode != (int)CountList.Type000) { Qry += " and AD.ServiceCode=@ServiceCode "; }
                if (Sessions.getEmployeeUser().Permission == ((int)Permission.P136).ToString()) { Qry += " and receiveduser=@receiveduser"; }
                if (Sessions.getEmployeeUser().DeptCode != ((int)Department.Dept015).ToString()) { Qry += " and SM.deptcode=@ParamDeptCode"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@ParamDistrictCode"; }
                if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate "; }
                if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate "; }
                Qry += " order by AD.ApplicationNo";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
                cmd.Parameters.AddWithValue("@ReceivedUser", UserId);
                cmd.Parameters.AddWithValue("@P136", (int)Permission.P136);
                cmd.Parameters.AddWithValue("@WhetherSahayakApply", CustomText.TRUE.ToString());
                cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
                cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
                cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
                cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
                cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
                cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
                cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
                if (Sessions.getEmployeeUser().Permission == ((int)Permission.P136).ToString()) { cmd.Parameters.AddWithValue("@receiveduser", Sessions.getEmployeeUser().UserId); }
                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "MobileSahayakWiseDetailsReport", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "MobileSahayakWiseDetailsReport", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DpMobileSahayakWiseReport(string DTF, string DTT, int? ServiceCode = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,receiveduser,count(Applicationno) as Received,coalesce(sum(case when Applicationstatusid not in (@CANCEL,@TEHSREJ,@ISSUCER,@TEHSOBJ) then 1 end),0) Pending,coalesce(sum(case when Applicationstatusid in (@TEHSOBJ) then 1 end),0) QueryRaised,coalesce(sum(case when Applicationstatusid in (@CANCEL,@ISSUCER) then 1 end),0) Disposed,coalesce(sum(case when Applicationstatusid in (@TEHSREJ) then 1 end),0) Rejected from applicationdetails AD inner join servicemaster SM on SM.ServiceCode=AD.ServiceCode inner join serviceattributemaster SAM on SAM.ServiceCode=SM.ServiceCode where SAM.whethersahayakapply=@WhetherSahayakApply and AD.receivedpermission=@CscOperator and AD.officecode=@AuthMobileSahayk ";
            if (ServiceCode != (int)CountList.Type000) { Qry += " and AD.ServiceCode=@ServiceCode "; }
            if (Sessions.getEmployeeUser().DeptCode != ((int)Department.Dept015).ToString()) { Qry += " and SM.deptcode=@ParamDeptCode"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@ParamDistrictCode"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            if (Convert.ToInt32(Sessions.getEmployeeUser().Permission) == (int)Permission.WIND && Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) == (int)ValueId.MobileSahakValueId)  { 
                Qry += " and receiveduser=@receiveduser"; 
            }
            Qry += " group by receiveduser";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@CscOperator", (int)Permission.WIND);
            cmd.Parameters.AddWithValue("@AuthMobileSahayk", (int)ValueId.MobileSahakValueId);
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@WhetherSahayakApply", CustomText.TRUE.ToString());
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            if (Convert.ToInt32(Sessions.getEmployeeUser().Permission) == (int)Permission.WIND && Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) == (int)ValueId.MobileSahakValueId) { 
                cmd.Parameters.AddWithValue("@receiveduser", Sessions.getEmployeeUser().UserId); 
            }
            model.data = data.GetDataTable(cmd);
            model.ServiceId = ServiceCode.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DpMobileSahayakWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int ServiceCode = (int)CountList.Type000;
                if (!string.IsNullOrEmpty(model.ServiceCode)) { ServiceCode = Convert.ToInt32(model.ServiceCode); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT", "ServiceCode" }, new ArrayList() { model.DateFrom, model.DateTo, ServiceCode });
                return RedirectToAction("DpMobileSahayakWiseReport", "Report", new { q = QueryString });
            }
            return View("BasicDistWiseReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DpMobileSahayakWiseDetailsReport(int TypeId, string UserId, int? ServiceCode, string DTF, string DTT, int? PageIndex = 1)
        {
            if (string.IsNullOrEmpty(UserId)) { return RedirectToAction("UnauthorizedRequest", "Error"); }

            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "TypeId=" + TypeId.ToString());
            Parameters.Add(1, "UserId=" + UserId.ToString());
            Parameters.Add(2, "ServiceCode=" + ServiceCode.ToString());
            if (!string.IsNullOrEmpty(DTF)) { Parameters.Add(3, "DTF=" + DTF.ToString()); }
            if (!string.IsNullOrEmpty(DTT)) { Parameters.Add(4, "DTT=" + DTT.ToString()); }
            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                GetData data = new GetData();
                string statusId = string.Empty, Qry = string.Empty;
                if (TypeId == (int)CountList.Type000) { }
                if (TypeId == (int)CountList.Type001) { statusId = " and AD.ApplicationStatusId not in (@CANCEL,@TEHSREJ,@ISSUCER,@TEHSOBJ)"; }
                else if (TypeId == (int)CountList.Type002) { statusId = " and AD.ApplicationStatusId in (@TEHSOBJ)"; }
                else if (TypeId == (int)CountList.Type003) { statusId = " and AD.ApplicationStatusId in (@CANCEL,@ISSUCER)"; }
                else if (TypeId == (int)CountList.Type004) { statusId = " and AD.ApplicationStatusId in (@TEHSREJ)"; }

                Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SM.DeptCode,DeptName,ApplicationRemarks,AD.ApplicationNo,AD.ApplicantName,SM.ServiceName,AD.ApplicantGender,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,AD.ApplicationStatusid,SL.StatusName,receiveduser,DistrictName,subdivdescription from applicationdetails AD inner join servicemaster SM on SM.ServiceCode=AD.ServiceCode inner join serviceattributemaster SAM on SAM.ServiceCode=SM.ServiceCode inner join DeptMaster DMM on DMM.DeptCode=SM.DeptCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId left outer join districtmaster DM on DM.districtcode=AD.ApplicationdistrictCode left outer join subdivmaster SDM on SDM.subdivcode=AD.ApplicationSubdivCode where SAM.whethersahayakapply=@WhetherSahayakApply and AD.receiveduser=@ReceivedUser and AD.receivedpermission=@CscOperator and AD.officecode=@AuthMobileSahayk " + statusId;
                if (ServiceCode != (int)CountList.Type000) { Qry += " and AD.ServiceCode=@ServiceCode "; }
                if (Sessions.getEmployeeUser().DeptCode != ((int)Department.Dept015).ToString()) { Qry += " and SM.deptcode=@ParamDeptCode"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@ParamDistrictCode"; }
                if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate "; }
                if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate "; }
                if (Convert.ToInt32(Sessions.getEmployeeUser().Permission) == (int)Permission.WIND && Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) == (int)ValueId.MobileSahakValueId) { 
                    Qry += " and receiveduser=@receiveduser"; 
                }
                Qry += " order by AD.ApplicationNo";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
                cmd.Parameters.AddWithValue("@ReceivedUser", UserId);
                //cmd.Parameters.AddWithValue("@P136", (int)Permission.P136);
                cmd.Parameters.AddWithValue("@CscOperator", (int)Permission.WIND);
                cmd.Parameters.AddWithValue("@AuthMobileSahayk", (int)ValueId.MobileSahakValueId);
                cmd.Parameters.AddWithValue("@WhetherSahayakApply", CustomText.TRUE.ToString());
                cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
                cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
                cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
                cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
                cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
                cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
                cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
                if (Convert.ToInt32(Sessions.getEmployeeUser().Permission) == (int)Permission.WIND && Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) == (int)ValueId.MobileSahakValueId) { 
                    cmd.Parameters.AddWithValue("@receiveduser", Sessions.getEmployeeUser().UserId); 
                }
                model.data = data.GetDataTable(cmd);
                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "DpMobileSahayakWiseDetailsReport", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "DpMobileSahayakWiseDetailsReport", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DownloadMobileSahayakWiseReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DownloadMobileSahayakWiseReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();

                string Qry = @"select AD.ApplicationNo as ""Application No"",to_char(AD.ApplicationDate,'DD/MM/YYYY') as ""Date of application"",subdivdescription as ""Zone/SubDivision"",DistrictName as ""District"",AD.ApplicantName as ""Citizen Name"",receiveduser as ""Mobile Sahayak Id"",UserName as ""Mobile Sahayak Name"",DeptName as ""Department"",SM.ServiceName as ""Service Name"",SL.StatusName as ""Current status of application"", case when AD.ApplicationStatusid in (@TEHSREJ,@CANCEL,@TEHSOBJ) then ApplicationRemarks else NUll end as ""Remarks"" from applicationdetails AD inner join servicemaster SM on SM.ServiceCode=AD.ServiceCode inner join serviceattributemaster SAM on SAM.ServiceCode=SM.ServiceCode inner join DeptMaster DMM on DMM.DeptCode=SM.DeptCode inner join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId inner join usermaster UM on UM.UserId=AD.receiveduser left outer join districtmaster DM on DM.districtcode=AD.ApplicationdistrictCode left outer join subdivmaster SDM on SDM.subdivcode=AD.ApplicationSubdivCode where receivedpermission=@P136 and whethersahayakapply=@WhetherSahayakApply ";
                if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode=@ServiceCode "; }
                if (Sessions.getEmployeeUser().DeptCode != ((int)Department.Dept015).ToString()) { Qry += " and SM.deptcode=@ParamDeptCode"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode)"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@ParamDistrictCode"; }
                if (!string.IsNullOrEmpty(model.DateFrom)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate "; }
                if (!string.IsNullOrEmpty(model.DateTo)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate "; }
                Qry += " order by AD.ApplicationNo";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                cmd.Parameters.AddWithValue("@P136", (int)Permission.P136);
                cmd.Parameters.AddWithValue("@WhetherSahayakApply", CustomText.TRUE.ToString());
                cmd.Parameters.AddWithValue("@DisplayFromDate", model.DateFrom);
                cmd.Parameters.AddWithValue("@DisplayToDate", model.DateTo);
                cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
                cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
                cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
                cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(model.DateFrom, '/', true));
                cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(model.DateTo, '/', true));
                model.data = data.GetDataTable(cmd);
                if (model.data.Rows.Count > 0)
                {
                    var grid = new System.Web.UI.WebControls.GridView();
                    grid.DataSource = model.data;
                    grid.DataBind();
                    Response.Clear();
                    Response.AddHeader("content-disposition", "attachment; filename=DownloadData.xls");
                    Response.Charset = "";
                    Response.ContentType = "application/vnd.xls";
                    System.IO.StringWriter stringWrite = new System.IO.StringWriter();
                    System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
                    grid.RenderControl(htmlWrite);
                    string style = @"<style> td { mso-number-format:\@; } </style>";
                    Response.Write(style);

                    Response.Write(stringWrite.ToString());
                    Response.End();


                }
                else
                {
                    ViewData["message"] = "No Record Found";
                    return View("message");
                }
            }
            return View("DownloadMobileSahayakWiseReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult QueryRaisedOnApplication(Int64 ApplicationNo)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select SM.DeptCode,DeptName,ApplicationRemarks,AD.ApplicationNo,AD.ApplicantName,SM.ServiceName,AD.ApplicantGender,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,AD.ApplicationStatusid,SL.StatusName,receiveduser,DistrictName,subdivdescription from applicationdetails AD inner join servicemaster SM on SM.ServiceCode=AD.ServiceCode inner join serviceattributemaster SAM on SAM.ServiceCode=SM.ServiceCode inner join DeptMaster DMM on DMM.DeptCode=SM.DeptCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId left outer join districtmaster DM on DM.districtcode=AD.ApplicationdistrictCode left outer join subdivmaster SDM on SDM.subdivcode=AD.ApplicationSubdivCode where receivedpermission=@P136 and whethersahayakapply=@WhetherSahayakApply and AD.ApplicationStatusId in (@TEHSOBJ)  and AD.Applicationno=@Applicationno order by AD.ApplicationNo";

            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@Applicationno", ApplicationNo);
            cmd.Parameters.AddWithValue("@P136", (int)Permission.P136);
            cmd.Parameters.AddWithValue("@WhetherSahayakApply", CustomText.TRUE.ToString());
            cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
            //if (Sessions.getEmployeeUser().Permission == ((int)Permission.P136).ToString()) { cmd.Parameters.AddWithValue("@receiveduser", Sessions.getEmployeeUser().UserId); }
            model.data = data.GetDataTable(cmd);

            ViewData["dtObjectionData"] = Utility.GetObjectionDetails(ApplicationNo.ToString());
            return View(model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult MobileSahayakSLAReport(string DTF, string DTT, int? ServiceCode = 0, int? DistrictCode = 0, int? SubDivCode = 0)
        {
            int? DistCode = 0, sdcode = 0;
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            if (Convert.ToInt32(Sessions.getEmployeeUser().DistrictCode) != 0) { DistCode = Convert.ToInt32(Sessions.getEmployeeUser().DistrictCode); } else if (DistrictCode != 0) { DistCode = DistrictCode; }
            if (Convert.ToInt32(Sessions.getEmployeeUser().SubDivCode) != 0) { sdcode = Convert.ToInt32(Sessions.getEmployeeUser().SubDivCode); } else if (DistrictCode != 0) { sdcode = SubDivCode; }

            string Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SM.servicecode, SD.subdivcode, DM.districtcode, districtname,subdivdescription, servicename, count(applicationno) Received , sum((case when ApplicationStatusId  not in(@ISSUCER, @TEHSREJ, @CANCEL)  then 1 else 0 end)) as Pending, sum((case when DATE_PART('day', now() - applicationdate) <= processingdays and ApplicationStatusId not in(@ISSUCER, @TEHSREJ, @CANCEL) then 1 else 0 end)) as withinsla, sum((case when DATE_PART('day', now() - applicationdate) > processingdays and ApplicationStatusId not in(@ISSUCER, @TEHSREJ, @CANCEL)  then 1 else 0 end)) as beyondsla, sum((case when ApplicationStatusId = @TEHSOBJ  then 1 else 0 end)) as QueryRaised, sum((case when ApplicationStatusId in ( @CANCEL,@ISSUCER)  then 1 else 0 end)) as Disposed, sum((case when ApplicationStatusId = @TEHSREJ  then 1 else 0 end)) as Rejected from applicationdetails AD inner join servicemaster SM on AD.servicecode = SM.servicecode inner join subdivmaster SD on AD.applicationsubdivcode = SD.subdivcode inner join districtmaster DM on AD.applicationdistrictcode = DM.districtcode where officecode=@MobileSahakValueId  ";
            if (ServiceCode != (int)CountList.Type000) { Qry += " and AD.ServiceCode=@ServiceCode "; }
            if (Sessions.getEmployeeUser().DeptCode != null) { Qry += " and SM.deptcode=@ParamDeptCode"; }
            if (sdcode != 0) { Qry += " and AD.ApplicationSubDivCode in (@SubDivCode)"; }
            if (DistCode != 0) { Qry += " and AD.ApplicationDistrictCode=@DistrictCode"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate"; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate"; }
            Qry += " group by SM.servicecode,servicename,SD.subdivcode,subdivdescription,DM.districtcode,districtname order by districtname, subdivdescription, servicename";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
            cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
            cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            cmd.Parameters.AddWithValue("@MobileSahakValueId", (int)ValueId.MobileSahakValueId);
            cmd.Parameters.AddWithValue("@SubDivCode", sdcode);
            cmd.Parameters.AddWithValue("@DistrictCode", DistCode);
            model.data = data.GetDataTable(cmd);

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult MobileSahayakSLAReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                int ServiceCode = (int)CountList.Type000, SubDivCode = (int)CountList.Type000, DistrictCode = (int)CountList.Type000;
                if (!string.IsNullOrEmpty(model.ServiceCode)) { ServiceCode = Convert.ToInt32(model.ServiceCode); }
                if (!string.IsNullOrEmpty(model.ApplicantSubDivCode)) { SubDivCode = Convert.ToInt32(model.ApplicantSubDivCode); }
                if (!string.IsNullOrEmpty(model.ApplicantDistrictCode)) { DistrictCode = Convert.ToInt32(model.ApplicantDistrictCode); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT", "ServiceCode", "DistrictCode", "SubDivCode" }, new ArrayList() { model.DateFrom, model.DateTo, ServiceCode, DistrictCode, SubDivCode });
                return RedirectToAction("MobileSahayakSLAReport", "Report", new { q = QueryString });
            }
            return View("BasicDistWiseReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult MobileSahayakSLADetailsReport(int TypeId, int ServiceCode, string DTF, string DTT, int DistrictCode, int SubDivCode, int? PageIndex = 1)
        {
            ReportModels model = new ReportModels();
            model.PagingModel = new PagingModel();
            model.PagingModel.PageIndex = (int)PageIndex;
            Dictionary<int, string> Parameters = new Dictionary<int, string>();
            Parameters.Add(0, "TypeId=" + TypeId.ToString());
            Parameters.Add(1, "ServiceCode=" + ServiceCode.ToString());
            Parameters.Add(2, "DistrictCode=" + DistrictCode.ToString());
            Parameters.Add(3, "SubDivCode=" + SubDivCode.ToString());
            if (!string.IsNullOrEmpty(DTF)) { Parameters.Add(4, "DTF=" + DTF.ToString()); }
            if (!string.IsNullOrEmpty(DTT)) { Parameters.Add(5, "DTT=" + DTT.ToString()); }
            if (TempData[Constant._pageData] == null || PageIndex == 1)
            {
                GetData data = new GetData();
                string statusId = string.Empty, Qry = string.Empty;
                if (TypeId == (int)CountList.Type000) { }
                if (TypeId == (int)CountList.Type001) { statusId = " and AD.ApplicationStatusId not in (@CANCEL,@TEHSREJ,@ISSUCER)"; }
                else if (TypeId == (int)CountList.Type002) { statusId = " and DATE_PART('day', now() - applicationdate) <= processingdays and ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) "; }
                else if (TypeId == (int)CountList.Type003) { statusId = " and DATE_PART('day', now() - applicationdate) > processingdays and ApplicationStatusId not in(@CANCEL,@TEHSREJ,@ISSUCER) "; }
                else if (TypeId == (int)CountList.Type004) { statusId = " and AD.ApplicationStatusId in (@TEHSOBJ)"; }
                else if (TypeId == (int)CountList.Type005) { statusId = " and AD.ApplicationStatusId in (@ISSUCER,@CANCEL)"; }
                else if (TypeId == (int)CountList.Type006) { statusId = " and AD.ApplicationStatusId in (@TEHSREJ)"; }

                Qry = "select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SM.DeptCode,DeptName,ApplicationRemarks,AD.ApplicationNo,AD.ApplicantName,SM.ServiceName,AD.ApplicantGender,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,AD.ApplicationStatusid,SL.StatusName,DistrictName,subdivdescription from applicationdetails AD inner join servicemaster SM on SM.ServiceCode=AD.ServiceCode inner join serviceattributemaster SAM on SAM.ServiceCode=SM.ServiceCode inner join DeptMaster DMM on DMM.DeptCode=SM.DeptCode left outer join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId left outer join districtmaster DM on DM.districtcode=AD.ApplicationdistrictCode left outer join subdivmaster SDM on SDM.subdivcode=AD.ApplicationSubdivCode where AD.ServiceCode=@ServiceCode and AD.ApplicationSubDivCode in (@SubDivCode) and AD.ApplicationDistrictCode=@DistrictCode and officecode=@officecode " + statusId;
                if (Sessions.getEmployeeUser().DeptCode != null) { Qry += " and SM.deptcode=@ParamDeptCode"; }
                if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate "; }
                if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate "; }
                Qry += " order by AD.ApplicationNo";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
                cmd.Parameters.AddWithValue("@officecode", (int)ValueId.MobileSahakValueId);
                cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
                cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
                cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
                cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
                cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
                cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
                cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
                cmd.Parameters.AddWithValue("@DistrictCode", DistrictCode);
                cmd.Parameters.AddWithValue("@SubDivCode", SubDivCode);
                model.data = data.GetDataTable(cmd);

                TempData[Constant._pageData] = model.data;
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "MobileSahayakSLADetailsReport", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            else
            {
                model.data = (DataTable)TempData[Constant._pageData];
                model.PagingModel = Utility.SetPagingModel(model.PagingModel.PageIndex, model.data, model.PagingModel.PageIndex, "MobileSahayakSLADetailsReport", "Report", "GET", null, null, Parameters);
                model.data = Utility.GetPaginatedData(model.PagingModel);
            }
            return View(model);
        }
        #endregion

        #region Payment Gateway Transaction Reports
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult ServiceWisePaymentTransactionReport(string DTF, string DTT, int? DistCode = 0, int? SubDivCode = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            if (DistCode == 0) { DistCode = null; } else { model.DistrictCode = DistCode.ToString(); }
            if (SubDivCode == 0) { SubDivCode = null; } else { model.ApplicationSubDivCode = SubDivCode.ToString(); }

            string Qry = " select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SM.ServiceName,SM.ServiceCode,coalesce(count(APR.paymentid),0) as  Total,coalesce(sum(case when APR.paymentstatusid=@Pending then 1 end),0) as  Pending, coalesce(sum(case when APR.paymentstatusid=@Success then 1 end),0) Success,coalesce(sum(case when APR.paymentstatusid=@Success then PaymentAmount end),0)  as PaymentAmount,coalesce(sum(case when APR.paymentstatusid  in (@Fail,@Cancel) then 1 end),0) as  Fail from applicationpaymentrequest  APR inner join web.applicationdetails AD on AD.ApplicationId=APR.ApplicationId left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join (select PaymentId,sum(PaymentAmount) as PaymentAmount from applicationpaymentdescription group by PaymentId) APD on APD.PaymentId=APR.PaymentId  right outer join dbo.SubDivMaster SD on AD.applicationsubdivcode=SD.SubDivCode right outer join dbo.ServiceMaster SM on AD.ServiceCode=SM.ServiceCode  where APR.paymentmodeid=@Online and SM.deptcode=@ParamDeptCode ";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode) "; }
            //if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate "; }
            //if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate "; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(APR.paymentgeneratedate, 'YYYYMMDD')::date >= @FromDate "; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(APR.paymentgeneratedate,'YYYYMMDD')::date <= @ToDate "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode) "; }
            else { if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@SubDivCode) "; } }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode in (@ParamDistrictCode) "; }
            else { if (!string.IsNullOrEmpty(model.DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@DistrictCode "; } }
            Qry += " group by SM.ServiceCode,SM.ServiceName order by SM.ServiceName ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            if (string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode))
            {
                if (!string.IsNullOrEmpty(DistCode.ToString())) { cmd.Parameters.AddWithValue("@DistrictCode", DistCode); }
            }
            if (string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode))
            {
                if (!string.IsNullOrEmpty(SubDivCode.ToString())) { cmd.Parameters.AddWithValue("@SubDivCode", SubDivCode); }
            }
            cmd.Parameters.AddWithValue("@Pending", (int)ValueId.SbiEpayNewPayment);
            cmd.Parameters.AddWithValue("@Success", (int)ValueId.SbiEpaySuccess);
            cmd.Parameters.AddWithValue("@Fail", (int)ValueId.SbiEpayFail);
            cmd.Parameters.AddWithValue("@Cancel", (int)ValueId.SbiEpayCancel);
            cmd.Parameters.AddWithValue("@Online", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            if (model.data.Rows.Count == 0)
            {
                if (!string.IsNullOrEmpty(DTF)) { model.DateFrom = DTF; }
                if (!string.IsNullOrEmpty(DTT)) { model.DateTo = DTT; }
            }
            if (string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode))
            {
                if (!string.IsNullOrEmpty(DistCode.ToString())) { model.DistrictName = Utility.SelectColumnsValue("DistrictMaster", "DistrictName", "DistrictCode", DistCode.ToString())[0]; model.DistrictCode = DistCode.ToString(); }
                if (!string.IsNullOrEmpty(SubDivCode.ToString())) { model.SubDivName = Utility.SelectColumnsValue("SubDivMaster", "SubDivDescription", "SubDivCode", SubDivCode.ToString())[0]; model.ApplicationSubDivCode = SubDivCode.ToString(); }
            }
            else
            {
                model.DistrictCode = Sessions.getEmployeeUser().DistrictCode;
                model.DistrictName = Utility.SelectColumnsValue("DistrictMaster", "DistrictName", "DistrictCode", Sessions.getEmployeeUser().DistrictCode)[0];
                if (string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode))
                {
                    if (!string.IsNullOrEmpty(SubDivCode.ToString())) { model.SubDivName = Utility.SelectColumnsValue("SubDivMaster", "SubDivDescription", "SubDivCode", SubDivCode.ToString())[0]; model.ApplicationSubDivCode = SubDivCode.ToString(); }
                }
                else
                {
                    model.ApplicationSubDivCode = Sessions.getEmployeeUser().SubDivCode;
                    model.SubDivName = Utility.SelectColumnsValue("SubDivMaster", "SubDivDescription", "SubDivCode", Sessions.getEmployeeUser().SubDivCode)[0];
                }
            }
            if (string.IsNullOrEmpty(model.DistrictCode)) { model.DistrictCode = ((int)CountList.Type000).ToString(); }
            if (string.IsNullOrEmpty(model.ApplicationSubDivCode)) { model.ApplicationSubDivCode = ((int)CountList.Type000).ToString(); }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ServiceWisePaymentTransactionReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                if (string.IsNullOrEmpty(model.DistrictCode)) { model.DistrictCode = ((int)CountList.Type000).ToString(); }
                if (string.IsNullOrEmpty(model.ApplicationSubDivCode)) { model.ApplicationSubDivCode = ((int)CountList.Type000).ToString(); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT", "DistCode", "SubDivCode" }, new ArrayList() { model.DateFrom, model.DateTo, model.DistrictCode, model.ApplicationSubDivCode });
                return RedirectToAction("ServiceWisePaymentTransactionReport", "Report", new { q = QueryString });
            }
            return View("ServiceWisePaymentTransactionReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DistWisePaymentTransactionReport(string DTF, string DTT, int? service = 0)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            if (service == 0) { service = null; } else { model.ServiceCode = service.ToString(); }

            string Qry = @" select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,DM.DistrictName,DM.DistrictCode,coalesce(count(APR.paymentid),0) as  Total,coalesce(sum(case when APR.paymentstatusid=@Pending then 1 end),0) as  Pending, coalesce(sum(case when APR.paymentstatusid=@Success then 1 end),0) Success,coalesce(sum(case when APR.paymentstatusid=@Success then PaymentAmount end),0)  as PaymentAmount,coalesce(sum(case when APR.paymentstatusid in (@Fail,@Cancel) then 1 end),0) as  Fail from applicationpaymentrequest  APR inner join web.applicationdetails AD on AD.ApplicationId=APR.ApplicationId left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode left outer join (select PaymentId,sum(PaymentAmount) as PaymentAmount from applicationpaymentdescription group by PaymentId) APD on APD.PaymentId=APR.PaymentId  right outer join dbo.SubDivMaster SD on AD.applicationsubdivcode=SD.SubDivCode  right outer join dbo.ServiceMaster SM on AD.ServiceCode=SM.ServiceCode where APR.paymentmodeid=@Online and SM.deptcode=@ParamDeptCode ";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DeptCode)) { Qry += " and DM.DeptCode in (@ParamDeptCode) "; }
            if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ServiceCode) "; }
            else { if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode) "; } }
            //if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate "; }
            //if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate "; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(APR.paymentgeneratedate, 'YYYYMMDD')::date >= @FromDate "; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(APR.paymentgeneratedate,'YYYYMMDD')::date <= @ToDate "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode) "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode in (@ParamDistrictCode) "; }
            Qry += " group by  DM.DistrictCode,DM.DistrictName order by DM.DistrictName  ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            if (!string.IsNullOrEmpty(model.ServiceCode))
            { cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode); }
            cmd.Parameters.AddWithValue("@Pending", (int)ValueId.SbiEpayNewPayment);
            cmd.Parameters.AddWithValue("@Success", (int)ValueId.SbiEpaySuccess);
            cmd.Parameters.AddWithValue("@Fail", (int)ValueId.SbiEpayFail);
            cmd.Parameters.AddWithValue("@Cancel", (int)ValueId.SbiEpayCancel);
            cmd.Parameters.AddWithValue("@Online", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            if (model.data.Rows.Count == 0)
            {
                if (!string.IsNullOrEmpty(DTF)) { model.DateFrom = DTF; }
                if (!string.IsNullOrEmpty(DTT)) { model.DateTo = DTT; }
            }
            if (!string.IsNullOrEmpty(model.ServiceCode))
            {
                model.ServiceName = Utility.SelectColumnsValue("ServiceMaster", "ServiceName", "ServiceCode", model.ServiceCode)[0];
            }
            else { model.ServiceCode = ((int)CountList.Type000).ToString(); }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DistWisePaymentTransactionReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                if (string.IsNullOrEmpty(model.ServiceCode)) { model.ServiceCode = ((int)CountList.Type000).ToString(); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT", "service" }, new ArrayList() { model.DateFrom, model.DateTo, model.ServiceCode });
                return RedirectToAction("DistWisePaymentTransactionReport", "Report", new { q = QueryString });
            }
            return View("DistWisePaymentTransactionReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult PaymentTransactionReportList(Int64? PayOrderNo, string DTF, string DTT, int status, int? service = 0, int? DistCode = 0, int? SubDivCode = 0)
        {
            GetData data = new GetData();
            string strPaymentId = string.Empty;
            ReportModels model = new ReportModels();

            if (DistCode == 0) { DistCode = null; } else { model.DistrictCode = DistCode.ToString(); }
            if (SubDivCode == 0) { SubDivCode = null; } else { model.ApplicationSubDivCode = SubDivCode.ToString(); }
            if (status == (int)ValueId.SbiEpayFail) { strPaymentId = ((int)ValueId.SbiEpayFail).ToString() + "," + ((int)ValueId.SbiEpayCancel).ToString(); } else { strPaymentId = status.ToString(); }

            string Qry = @"select  @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SM.ServiceCode,SM.ServiceName,AD.ApplicationID,AD.ApplicationNo,SV.valuename as PaymentStatus,APR.paymentorderno,APR.PaymentStatusId,to_char(APR.paymentgeneratedate, 'DD/MM/YYYY') as paymentgeneratedate,DM.DistrictName,sum(PaymentAmount) as PaymentAmount
                        from applicationpaymentrequest  APR 
                        inner join web.applicationdetails AD on AD.ApplicationId=APR.ApplicationId 
                        inner join selectmastervaluedetails SV on SV.valueid=APR.paymentstatusid
                        left outer join applicationpaymentdescription APD on APD.PaymentId=APR.PaymentId
                        left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode 
                        right outer join dbo.SubDivMaster SD on AD.applicationsubdivcode=SD.SubDivCode 
                        right outer join dbo.ServiceMaster SM on AD.ServiceCode=SM.ServiceCode 
                        where APR.paymentmodeid=@Online ";
            if (service != 0) { Qry += " and AD.ServiceCode=@ServiceCode "; }
            if (status != 0) { Qry += " and APR.paymentstatusid in (" + strPaymentId + ")"; }
            //if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date >= @FromDate "; }
            //if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(AD.ApplicationDate,'YYYYMMDD')::date <= @ToDate "; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(APR.paymentgeneratedate, 'YYYYMMDD')::date >= @FromDate "; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(APR.paymentgeneratedate,'YYYYMMDD')::date <= @ToDate "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode) "; }
            else { if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@SubDivCode) "; } }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode in (@ParamDistrictCode) "; }
            else { if (!string.IsNullOrEmpty(model.DistrictCode)) { Qry += " and AD.ApplicationDistrictCode=@DistrictCode "; } }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and AD.ApplicationSubDivCode in (@ParamSubDivCode) "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and AD.ApplicationDistrictCode in (@ParamDistrictCode) "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode) "; }
            
            Qry += " group by SM.ServiceCode,SM.ServiceName,AD.ApplicationID,AD.ApplicationNo,SV.valuename,APR.paymentorderno,APR.PaymentStatusId,APR.paymentgeneratedate,DM.DistrictName order by APR.Paymentgeneratedate desc ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            if (string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode))
            {
                if (!string.IsNullOrEmpty(DistCode.ToString())) { cmd.Parameters.AddWithValue("@DistrictCode", DistCode); }
                if (!string.IsNullOrEmpty(SubDivCode.ToString())) { cmd.Parameters.AddWithValue("@SubDivCode", SubDivCode); }
            }
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            //cmd.Parameters.AddWithValue("@PaymentStatus", strFailCancel);
            cmd.Parameters.AddWithValue("@Online", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            if (string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode))
            {
                if (!string.IsNullOrEmpty(DistCode.ToString())) { model.DistrictName = Utility.SelectColumnsValue("DistrictMaster", "DistrictName", "DistrictCode", DistCode.ToString())[0]; model.DistrictCode = DistCode.ToString(); }
                if (!string.IsNullOrEmpty(SubDivCode.ToString())) { model.SubDivName = Utility.SelectColumnsValue("SubDivMaster", "SubDivDescription", "SubDivCode", SubDivCode.ToString())[0]; model.ApplicationSubDivCode = SubDivCode.ToString(); }
            }
            else
            {
                model.DistrictCode = Sessions.getEmployeeUser().DistrictCode;
                model.DistrictName = Utility.SelectColumnsValue("DistrictMaster", "DistrictName", "DistrictCode", Sessions.getEmployeeUser().DistrictCode)[0];
                if (string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode))
                {
                    if (!string.IsNullOrEmpty(SubDivCode.ToString())) { model.SubDivName = Utility.SelectColumnsValue("SubDivMaster", "SubDivDescription", "SubDivCode", SubDivCode.ToString())[0]; model.ApplicationSubDivCode = SubDivCode.ToString(); }
                }
                else
                {
                    model.ApplicationSubDivCode = Sessions.getEmployeeUser().SubDivCode;
                    model.SubDivName = Utility.SelectColumnsValue("SubDivMaster", "SubDivDescription", "SubDivCode", Sessions.getEmployeeUser().SubDivCode)[0];
                }
            }
            return View(model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult PaymentResponseDetails(Int64? PayOrderNo, int? Status)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.StatusId = Status.ToString();

            string Qry = @"select  APR.ApplicationID,APR.ApplicationNo,APR.PaymentOrderNo,to_char(APR.PaymentGenerateDate,'DD/MM/YYYY') as PaymentGenerateDate,APR.PaymentStatusId,SV.ValueName,APR1.PaymentStatus,APR1.GatewayReferenceId,APR1.BankCode,APR1.BankReferenceNo,APR1.TransactionCIN as CINNO,APR1.PaymentAmount,APR.PaymentStatusId from ApplicationPaymentRequest APR left outer join ApplicationPaymentResponse APR1 on APR1.MerchantOrderNo = APR.PaymentOrderNo inner join SelectMasterValueDetails SV on SV.ValueId=APR.PaymentStatusId where APR.PaymentOrderNo = @PaymentOrderNo order by APR.PaymentOrderNo ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@PaymentOrderNo", PayOrderNo);
            model.data = data.GetDataTable(cmd);

            return View("PaymentResponseDetails", model);
        }

        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult PaymentTransactionReportFailed(string DTF, string DTT)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();

            string Qry = " select @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SM.ServiceName,SM.ServiceCode,coalesce(count(APR.paymentid),0) as  Total,coalesce(sum(case when APR.paymentstatusid=@Pending then 1 end),0) as  Pending, coalesce(sum(case when APR.paymentstatusid=@Success then 1 end),0) Success,coalesce(sum(case when APR.paymentstatusid=@Success then PaymentAmount end),0)  as PaymentAmount,coalesce(sum(case when APR.paymentstatusid  in (@Fail,@Cancel) then 1 end),0) as  Fail from applicationpaymentrequest  APR left outer join web.applicationdetails AD on AD.ApplicationId=APR.ApplicationId left outer join (select PaymentId,sum(PaymentAmount) as PaymentAmount from applicationpaymentdescription group by PaymentId) APD on APD.PaymentId=APR.PaymentId left outer join dbo.ServiceMaster SM on APR.Otherdetails::integer=SM.ServiceCode where APR.paymentmodeid=@Online and SM.deptcode=@ParamDeptCode and  APR.applicationid is not null and AD.applicationid is null ";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and SM.ServiceCode in (@ParamServiceCode) "; }

            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(APR.paymentgeneratedate, 'YYYYMMDD')::date >= @FromDate "; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(APR.paymentgeneratedate,'YYYYMMDD')::date <= @ToDate "; }

            Qry += " group by SM.ServiceCode,SM.ServiceName order by SM.ServiceName ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@Pending", (int)ValueId.SbiEpayNewPayment);
            cmd.Parameters.AddWithValue("@Success", (int)ValueId.SbiEpaySuccess);
            cmd.Parameters.AddWithValue("@Fail", (int)ValueId.SbiEpayFail);
            cmd.Parameters.AddWithValue("@Cancel", (int)ValueId.SbiEpayCancel);
            cmd.Parameters.AddWithValue("@Online", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            if (model.data.Rows.Count == 0)
            {
                if (!string.IsNullOrEmpty(DTF)) { model.DateFrom = DTF; }
                if (!string.IsNullOrEmpty(DTT)) { model.DateTo = DTT; }
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult PaymentTransactionReportFailed(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DTF", "DTT" }, new ArrayList() { model.DateFrom, model.DateTo });
                return RedirectToAction("PaymentTransactionReportFailed", "Report", new { q = QueryString });
            }
            return View("PaymentTransactionReportFailed", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult PaymentTransactionReportFailedList(Int64? PayOrderNo, string DTF, string DTT, int status, int service)
        {
            GetData data = new GetData();
            string strPaymentId = string.Empty;
            ReportModels model = new ReportModels();

            if (status == (int)ValueId.SbiEpayFail) { strPaymentId = ((int)ValueId.SbiEpayFail).ToString() + "," + ((int)ValueId.SbiEpayCancel).ToString(); } else { strPaymentId = status.ToString(); }

            string Qry = @"select  @DisplayFromDate as FromDate,@DisplayToDate as ToDate,SM.ServiceCode,SM.ServiceName,APR.ApplicationID,AD.ApplicationNo,SV.valuename as PaymentStatus,APR.paymentorderno,APR.PaymentStatusId,to_char(APR.paymentgeneratedate, 'DD/MM/YYYY') as paymentgeneratedate,Sum(PaymentAmount) as PaymentAmount from applicationpaymentrequest  APR inner join selectmastervaluedetails SV on SV.valueid=APR.paymentstatusid  left outer join web.applicationdetails AD on AD.ApplicationId=APR.ApplicationId left outer join applicationpaymentdescription APD on APD.PaymentId=APR.PaymentId left outer join dbo.ServiceMaster SM on APR.Otherdetails::integer=SM.ServiceCode where APR.paymentmodeid=@Online and APR.Otherdetails::integer=@ServiceCode and APR.applicationid is not null and AD.applicationid is null ";
            if (status != 0) { Qry += " and APR.paymentstatusid in (" + strPaymentId + ")"; }
            if (!string.IsNullOrEmpty(DTF)) { Qry += " and to_char(APR.paymentgeneratedate, 'YYYYMMDD')::date >= @FromDate "; }
            if (!string.IsNullOrEmpty(DTT)) { Qry += " and to_char(APR.paymentgeneratedate,'YYYYMMDD')::date <= @ToDate "; }

            Qry += " group by SM.ServiceCode,SM.ServiceName,APR.ApplicationID,AD.ApplicationNo,SV.valuename,APR.paymentorderno,APR.PaymentStatusId,APR.paymentgeneratedate order by APR.Paymentgeneratedate desc ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@Online", (int)ApplicationSource.Online);
            cmd.Parameters.AddWithValue("@DisplayFromDate", DTF);
            cmd.Parameters.AddWithValue("@DisplayToDate", DTT);
            cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(DTF, '/', true));
            cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(DTT, '/', true));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        #endregion

        #region Sanction Payment ReportS
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult DistWisePaymentReport()
        {
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { return RedirectToAction("SubDivWisePaymentReport"); }

            GetData data = new GetData();
            ReportModels model = new ReportModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DistWisePaymentReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = "select @PaymentYear as PaymentYear,@PaymentMonth as PaymentMonth,AD.ApplicationDistrictCode,DistrictName ,Count(AD.ApplicationNo) as PaymentGenerated,coalesce(sum(case when WhetherFileGenerated=True then 1 end),0) as FileGenerated,coalesce(sum(case when WhetherFileGenerated=False then 1 end),0) as PendingFileGenerated,coalesce(sum(case when WhetherResponseUploaded=True then 1 end),0) as ResponseUpload,coalesce(sum(case when ResponseStatusId=1 then 1 end),0) as TransationSuccess,coalesce(sum(case when ResponseStatusId=2 then 1 end),0) as TransationFail from ApplicationDetails AD inner join ApplicationPaymentDetails  APD on APD.ApplicationNo=AD.ApplicationNo inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join SubDivMaster SDM on SDM.SubDIvCode=AD.ApplicationSubDIvCode where 1=1 ";
                if (!string.IsNullOrEmpty(model.Year)) { Qry += " and PaymentYear = @PaymentYear"; }
                if (!string.IsNullOrEmpty(model.Month)) { Qry += " and PaymentMonth = @PaymentMonth"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
                Qry += " group by AD.ApplicationDistrictCode,DistrictName order by  DistrictName";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@PaymentYear", model.Year);
                cmd.Parameters.AddWithValue("@PaymentMonth", model.Month);
                model.data = data.GetDataTable(cmd);
            }
            return View("DistWisePaymentReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult SubDivWisePaymentReport(int? dist, int? Month, int? Year)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            if (dist.Equals(null)) { dist = Convert.ToInt32(Sessions.getEmployeeUser().DistrictCode); }
            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
            model.ApplicationSubDivCode = Sessions.getEmployeeUser().SubDivCode;
            if (String.IsNullOrEmpty(model.ApplicationSubDivCode))
            {
                string Qry = "select @PaymentYear as PaymentYear,@PaymentMonth as PaymentMonth,AD.ApplicationSubDivCode,SubDivDescription,AD.ApplicationDistrictCode,DistrictName,Count(AD.ApplicationNo) as PaymentGenerated,coalesce(sum(case when WhetherFileGenerated=True then 1 end),0) as FileGenerated,coalesce(sum(case when WhetherFileGenerated=False then 1 end),0) as PendingFileGenerated,coalesce(sum(case when WhetherResponseUploaded=True then 1 end),0) as ResponseUpload,coalesce(sum(case when ResponseStatusId=1 then 1 end),0) as TransationSuccess,coalesce(sum(case when ResponseStatusId=2 then 1 end),0) as TransationFail from ApplicationDetails AD inner join ApplicationPaymentDetails  APD on APD.ApplicationNo=AD.ApplicationNo inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join SubDivMaster SDM on SDM.SubDIvCode=AD.ApplicationSubDIvCode where AD.ApplicationDistrictCode=@DistrictCode ";
                if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
                if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry += " and SDM.SubDivCode in (@ParamSubDivCode)"; }
                if (Month != null) { Qry += " and PaymentMonth= @PaymentMonth "; }
                if (Year != null) { Qry += " and PaymentYear= @PaymentYear "; }
                Qry += " group by AD.ApplicationSubDivCode,SubDivDescription,AD.ApplicationDistrictCode,DistrictName order by  SubDivDescription";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@DistrictCode", dist);
                if (Month != null) { cmd.Parameters.AddWithValue("@PaymentMonth", Month.ToString()); }
                if (Year != null) { cmd.Parameters.AddWithValue("@PaymentYear", Year.ToString()); }
                model.data = data.GetDataTable(cmd);
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult SubDivWisePaymentReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string dist = Sessions.getEmployeeUser().DistrictCode;
                model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
                model.ApplicationSubDivCode = Sessions.getEmployeeUser().SubDivCode;
                string Qry = "select @PaymentYear as PaymentYear,@PaymentMonth as PaymentMonth,AD.ApplicationSubDivCode,SubDivDescription,AD.ApplicationDistrictCode,DistrictName,Count(AD.ApplicationNo) as PaymentGenerated,coalesce(sum(case when WhetherFileGenerated=True then 1 end),0) as FileGenerated,coalesce(sum(case when WhetherFileGenerated=False then 1 end),0) as PendingFileGenerated,coalesce(sum(case when WhetherResponseUploaded=True then 1 end),0) as ResponseUpload,coalesce(sum(case when ResponseStatusId=1 then 1 end),0) as TransationSuccess,coalesce(sum(case when ResponseStatusId=2 then 1 end),0) as TransationFail from ApplicationDetails AD inner join ApplicationPaymentDetails  APD on APD.ApplicationNo=AD.ApplicationNo inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join SubDivMaster SDM on SDM.SubDIvCode=AD.ApplicationSubDIvCode where AD.ApplicationDistrictCode=@DistrictCode ";
                if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
                if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry += " and SDM.SubDivCode in (@ParamSubDivCode)"; }
                if (!string.IsNullOrEmpty(model.Month)) { Qry += " and PaymentMonth= @PaymentMonth "; }
                if (!string.IsNullOrEmpty(model.Year)) { Qry += " and PaymentYear= @PaymentYear "; }
                Qry += " group by AD.ApplicationSubDivCode,SubDivDescription,AD.ApplicationDistrictCode,DistrictName order by  SubDivDescription";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@DistrictCode", dist);
                if (!string.IsNullOrEmpty(model.Month)) { cmd.Parameters.AddWithValue("@PaymentMonth", model.Month); }
                if (!string.IsNullOrEmpty(model.Year)) { cmd.Parameters.AddWithValue("@PaymentYear", model.Year); }
                model.data = data.GetDataTable(cmd);
            }
            return View("SubDivWisePaymentReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult ServiceWisePaymentReport(int? subDiv, int? Month, int? Year)
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
            if (subDiv != null)
            {
                model.Flag = "False";
                string Qry = "select @PaymentYear as PaymentYear,@PaymentMonth as PaymentMonth,AD.ServiceCode,ServiceName,AD.ApplicationSubDivCode,SubDivDescription,AD.ApplicationDistrictCode,DistrictName,Count(AD.ApplicationNo) as PaymentGenerated,coalesce(sum(case when WhetherFileGenerated=True then 1 end),0) as FileGenerated,coalesce(sum(case when WhetherFileGenerated=False then 1 end),0) as PendingFileGenerated,coalesce(sum(case when WhetherResponseUploaded=True then 1 end),0) as ResponseUpload,coalesce(sum(case when ResponseStatusId=1 then 1 end),0) as TransationSuccess,coalesce(sum(case when ResponseStatusId=2 then 1 end),0) as TransationFail from ApplicationDetails AD inner join ApplicationPaymentDetails  APD on APD.ApplicationNo=AD.ApplicationNo inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join SubDivMaster SDM on SDM.SubDIvCode=AD.ApplicationSubDIvCode inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where AD.ApplicationSubDivCode=@SubDivCode  ";
                if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
                if (Month != null) { Qry += " and PaymentMonth= @PaymentMonth "; }
                if (Year != null) { Qry += " and PaymentYear= @PaymentYear "; }
                Qry += " group by AD.ServiceCode,ServiceName,AD.ApplicationSubDivCode,SubDivDescription,AD.ApplicationDistrictCode,DistrictName order by  ServiceName";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@SubDivCode", subDiv);
                if (Month != null) { cmd.Parameters.AddWithValue("@PaymentMonth", Month.ToString()); }
                if (Year != null) { cmd.Parameters.AddWithValue("@PaymentYear", Year.ToString()); }

                model.data = data.GetDataTable(cmd);
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ServiceWisePaymentReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                model.DistrictCode = Sessions.getEmployeeUser().DistrictCode;
                model.ServiceCode = Sessions.getEmployeeUser().ServiceCode;
                model.ApplicationSubDivCode = Sessions.getEmployeeUser().SubDivCode;
                string Qry = "select @PaymentYear as PaymentYear,@PaymentMonth as PaymentMonth,AD.ServiceCode,ServiceName,'' as ApplicationSubDivCode,'' as ApplicationDistrictCode,Count(AD.ApplicationNo) as PaymentGenerated,coalesce(sum(case when WhetherFileGenerated=True then 1 end),0) as FileGenerated,coalesce(sum(case when WhetherFileGenerated=False then 1 end),0) as PendingFileGenerated,coalesce(sum(case when WhetherResponseUploaded=True then 1 end),0) as ResponseUpload,coalesce(sum(case when ResponseStatusId=1 then 1 end),0) as TransationSuccess,coalesce(sum(case when ResponseStatusId=2 then 1 end),0) as TransationFail from ApplicationDetails AD inner join ApplicationPaymentDetails  APD on APD.ApplicationNo=AD.ApplicationNo inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join SubDivMaster SDM on SDM.SubDIvCode=AD.ApplicationSubDIvCode inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where 1=1  ";
                if (!string.IsNullOrEmpty(model.DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
                if (!string.IsNullOrEmpty(model.ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
                if (!string.IsNullOrEmpty(model.ApplicationSubDivCode)) { Qry += " and SDM.SubDivCode in (@ParamSubDivCode)"; }
                if (!string.IsNullOrEmpty(model.Month)) { Qry += " and PaymentMonth= @PaymentMonth "; }
                if (!string.IsNullOrEmpty(model.Year)) { Qry += " and PaymentYear= @PaymentYear "; }
                Qry += " group by AD.ServiceCode,ServiceName order by  ServiceName";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@SubDivCode", model.ApplicationSubDivCode);
                if (!string.IsNullOrEmpty(model.Month)) { cmd.Parameters.AddWithValue("@PaymentMonth", model.Month); }
                if (!string.IsNullOrEmpty(model.Year)) { cmd.Parameters.AddWithValue("@PaymentYear", model.Year); }
                model.data = data.GetDataTable(cmd);
            }
            return View("ServiceWisePaymentReport", model);
        }
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult YearWisePaymentReport()
        {
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult YearWisePaymentReport(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = "select to_char(( (@PaymentYear) :: text ||'-'|| (PaymentMonth):: text || '-01')::date , 'Month') as PayMonth,PaymentMonth,@PaymentYear as PaymentYear,'' as ApplicationSubDivCode,'' as ApplicationDistrictCode, Count(AD.ApplicationNo) as PaymentGenerated,coalesce(sum(case when WhetherFileGenerated=True then 1 end),0) as FileGenerated,coalesce(sum(case when WhetherFileGenerated=False then 1 end),0) as PendingFileGenerated,coalesce(sum(case when WhetherResponseUploaded=True then 1 end),0) as ResponseUpload,coalesce(sum(case when ResponseStatusId=1 then 1 end),0) as TransationSuccess,coalesce(sum(case when ResponseStatusId=2 then 1 end),0) as TransationFail from ApplicationDetails AD inner join ApplicationPaymentDetails  APD on APD.ApplicationNo=AD.ApplicationNo inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join SubDivMaster SDM on SDM.SubDIvCode=AD.ApplicationSubDIvCode inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where 1=1 ";
                if (!string.IsNullOrEmpty(model.Year)) { Qry += " and PaymentYear = @PaymentYear"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and SDM.SubDivCode in (@ParamSubDivCode)"; }
                Qry += "  group by PaymentYear,PaymentMonth order by  PaymentMonth";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@PaymentYear", model.Year);
                cmd.Parameters.AddWithValue("@PaymentMonth", model.Month);
                model.data = data.GetDataTable(cmd);
            }
            return View("YearWisePaymentReport", model);
        }
        [EncryptedActionParameter]
        public ActionResult PaymentWiseApplicationDetails(int? subDiv, int? service, int status, int Month, int Year)
        {
            string statusId = string.Empty;
            if (status == 0) { }
            if (status == 1) { statusId = " and WhetherFileGenerated=True "; }
            if (status == 2) { statusId = " and WhetherFileGenerated=False "; }
            if (status == 3) { statusId = " and WhetherResponseUploaded=True "; }
            if (status == 4) { statusId = " and ResponseStatusId=1 "; }
            if (status == 5) { statusId = " and ResponseStatusId=2 "; }
            GetData data = new GetData();
            ReportModels model = new ReportModels();
            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName from ApplicationDetails AD inner join ApplicationPaymentDetails  APD on APD.ApplicationNo=AD.ApplicationNo inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join SubDivMaster SDM on SDM.SubDIvCode=AD.ApplicationSubDIvCode inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where PaymentMonth= @PaymentMonth and PaymentYear= @PaymentYear " + statusId + "";
            if (subDiv != null) { Qry += " and AD.ApplicationSubDivCode in (@SubDivCode)"; }
            if (service != null) { Qry += " and AD.ServiceCode in (@ServiceCode)"; }

            Qry += " order by  ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@PaymentMonth", Month);
            cmd.Parameters.AddWithValue("@PaymentYear", Year);
            if (service != null) { cmd.Parameters.AddWithValue("@ServiceCode", service); }
            if (subDiv != null) { cmd.Parameters.AddWithValue("@SubDivCode", subDiv); }
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        #endregion


    }
}

