﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Web.UI;
using Edistrict.Models;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.DataService;
using Edistrict.Models.Entities;
using Edistrict.Models.LogonAuthorize;
using System.Collections;
using Npgsql;
using Edistrict.Models.CustomClass;
using System.Data;
using System.Collections.Generic;
using System.Text;

namespace Edistrict.Controllers
{
    [Authorize]
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class AccountController : Controller
    {
        #region Department Authentication Module
        [AllowAnonymous]
        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult EmployeeLogin(string AppData, string returnUrl, int? Flag = 0)
        {
            if ((Request.IsAuthenticated) && Sessions.getEmployeeUser() != null)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "Type", "Source" }, new ArrayList() { ((int)CountList.Type001).ToString(), ((int)CountList.Type002).ToString() });
                return RedirectToAction("MessagePage", "Public", new { q = QueryString });
            }

            LoginModel model = new LoginModel();
            if (AppData != null) { model.CustomText = AppData; }
            model.Flag = Flag.ToString();
            Sessions.setSalt(Utility.GetRandomString(50));
            ViewBag.ReturnUrl = returnUrl;

            if (TempData[KeyName._Key02] != null) { ModelState.AddModelError("", TempData[KeyName._Key02].ToString()); }
            return View(model);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult EmployeeLogin(LoginModel model, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.Captcha) == false)
                {
                    ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                    return View(model);
                }

                if (!string.IsNullOrEmpty(model.ClientTimeZone))
                {
                    if (!model.ClientTimeZone.ToLower().Equals(Constant._IndianTimeZone))
                    {
                        TempData[KeyName._Key02] = "Your local machine Time Zone does not match to Indian Standard Timezone (UTC+05:30) Chennai, Kolkata, kindly change it and login again.";
                        return RedirectToAction("EmployeeLogin");
                    }
                }

                if (Utility.IsUserLoggedIn(model.EmployeeUserName) == true)
                {
                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "Uid" }, new ArrayList() { model.EmployeeUserName });
                    return RedirectToAction("VerifyLastSession", "Account", new { q = QueryString });
                }
                else
                {
                    ////Temp Process To Chnage MD5 Password to SHA512 at change password
                    //string whetherchange = Utility.SelectColumnsValue("usermaster", "temp_whetherlogout", "userid", model.EmployeeUserName)[0];
                    //if (!string.IsNullOrEmpty(whetherchange))
                    //{
                    //    if (whetherchange.ToUpper() == CustomText.FALSE.ToString())
                    //    {
                    //        PreserveModelState(KeyName._Key06, model.EmployeeUserName, false, true);
                    //        PreserveModelState(KeyName._Key08, model.EmployeeUserName, false, true);
                    //        PreserveModelState(KeyName._Key07, DB.LS.ToString(), false, true);
                    //        return RedirectToAction("ChangeLoginPassword");
                    //    }
                    //}

                    ////Temnp process to duplicate User-Id information
                    //GetData tGetData = new GetData();
                    //string tQry = "select newuserid from test_usermaster where olduserid=@olduserid and informcount < 4";
                    //NpgsqlCommand tCmd = new NpgsqlCommand(tQry);
                    //tCmd.Parameters.AddWithValue("@olduserid", model.EmployeeUserName);
                    //string IsDuplicateMatch = tGetData.SelectColumns(tCmd)[0];
                    //if (!string.IsNullOrEmpty(IsDuplicateMatch))
                    //{
                    //    tQry = "update test_usermaster set informcount=informcount+1 where olduserid=@olduserid";
                    //    tCmd = new NpgsqlCommand(tQry);
                    //    tCmd.Parameters.AddWithValue("@olduserid", model.EmployeeUserName);
                    //    tGetData.UpdateData(tCmd);
                    //    ModelState.AddModelError("", "Due to security measurement your User-Id (" + model.EmployeeUserName + ") has been changed to (" + IsDuplicateMatch + "). In future kindly login with (" + IsDuplicateMatch + ") for access your account. Password is same as your old password.");
                    //    return View(model);
                    //}

                    GetData data = new GetData();
                    int MaxLoginAttempt = Utility.CheckLoginAttempt(model.EmployeeUserName, DB.LS.ToString(), Dml.Select.ToString());
                    if (MaxLoginAttempt > 4) { ModelState.AddModelError("", "The password has been blocked due to maximum hit, Kindly contact to administrator"); }
                    else
                    {
                        UserMaster DepartmentUser = Authorize.ValidateDeprtmentUser(model.EmployeeUserName, model.Password);
                        if (DepartmentUser != null)
                        {
                            DepartmentUser.RememberMe = model.RememberMe;

                            // process for check validaity, time and ipadress
                            string WhetherCheck = Utility.GetValidateDeptUser(DepartmentUser.UserId);
                            if (!string.IsNullOrEmpty(WhetherCheck))
                            {
                                TempData[KeyName._Key02] = WhetherCheck;
                                return RedirectToAction("EmployeeLogin");
                            }

                            // check which type of login enetered Department/mobile Sahayak
                            if (model.Flag == ((int)CountList.Type001).ToString() && DepartmentUser.Permission == ((int)Permission.P136).ToString())
                            {
                                TempData[KeyName._Key02] = "The facility to LOGIN on e-District Delhi on your USER-ID is available on this link.";
                                return RedirectToAction("EmployeeLogin");
                            }
                            else if (model.Flag == ((int)CountList.Type002).ToString() && DepartmentUser.Permission != ((int)Permission.P136).ToString())
                            {
                                TempData[KeyName._Key02] = "The facility to LOGIN on e-District Delhi on your USER-ID is available on this link.";
                                return RedirectToAction("EmployeeLogin");
                            }

                            //check whether departmental user login in NIC-NET only.
                            if (DepartmentUser.Permission != ((int)Permission.TEHS).ToString() && DepartmentUser.Permission != ((int)Permission.DC).ToString() && DepartmentUser.Permission != ((int)Permission.MONT).ToString() && DepartmentUser.Permission != ((int)Permission.DCOM).ToString() && DepartmentUser.Permission != ((int)Permission.ADMN).ToString() && DepartmentUser.Permission != ((int)Permission.P116).ToString() && DepartmentUser.Permission != ((int)Permission.P118).ToString() && DepartmentUser.Permission != ((int)Permission.P119).ToString() && DepartmentUser.Permission != ((int)Permission.P120).ToString() && DepartmentUser.Permission != ((int)Permission.P129).ToString())
                            {
                                if (DepartmentUser.DeptCode == ((int)Department.Dept001).ToString() || DepartmentUser.DeptCode == ((int)Department.Dept002).ToString())
                                {
                                    // allowed operator to access the reciving module over public domain for SWD & Revenue department
                                    if ((DepartmentUser.Permission != ((int)Permission.WIND).ToString()))
                                    {
                                        if (Utility.IsNicNetRequest() == false)
                                        {
                                            TempData[KeyName._Key02] = "The facility to LOGIN on e-District Delhi on your USER-ID is available on your NICNET domain only. For any query kindly contact to DIO of your district.";
                                            return RedirectToAction("EmployeeLogin");
                                        }
                                    }
                                }
                                else if (DepartmentUser.DeptCode != ((int)Department.Dept009).ToString() && DepartmentUser.DeptCode != ((int)Department.Dept010).ToString() && DepartmentUser.DeptCode != ((int)Department.Dept015).ToString())
                                {
                                    if (Utility.IsNicNetRequest() == false)
                                    {
                                        TempData[KeyName._Key02] = "The facility to LOGIN on e-District Delhi on your USER-ID is available on your NICNET domain only. For any query kindly contact to DIO of your district.";
                                        return RedirectToAction("EmployeeLogin");
                                    }
                                }
                            }

                            //code for check password change 
                            int LastPasswordChange = Utility.CheckChangePassword(model.EmployeeUserName);
                            if (LastPasswordChange > 30)
                            {
                                PreserveModelState(KeyName._Key06, DepartmentUser.UserId, false, true);
                                PreserveModelState(KeyName._Key07, DB.LS.ToString(), false, true);
                                PreserveModelState(KeyName._Key08, DepartmentUser.UserId, false, true);

                                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "Type" }, new ArrayList() { ((int)CountList.Type000).ToString() });
                                return RedirectToAction("ChangePasswordAtFirstLogin", "Account", new { q = QueryString });
                            }

                            //set null value of Captcha
                            PreserveModelState(KeyName._Key05, null, false, true);

                            ////check whether SDM has enetered all the observation
                            //if (DepartmentUser.Permission == ((int)Permission.TEHS).ToString())
                            //{
                            //    bool WhetherActive = Utility.CheckSdmObservation(model.EmployeeUserName, DepartmentUser.SubDivCode);
                            //    if (WhetherActive == true)
                            //    {
                            //        PreserveModelState(KeyName._Key02, "The Random Observation in Certificate for " + DateTime.Now.AddMonths(-2).ToString("MMMM") + " Month did not Entered,Kindly Contact to Your Concern SDM.", false, true);
                            //        return RedirectToAction("EmployeeLogin");
                            //    }
                            //}


                            //check whether user is disabled or not
                            if (DepartmentUser.WhetherActive.ToString().ToLower() == CustomText.False.ToString().ToLower())
                            {
                                ModelState.AddModelError("", "The userid account has been disabled by your concerned Administrator. Kindly contact them for further process.");
                                Sessions.setSalt(Utility.GetRandomString(50));
                                return View(model);
                            }

                            //check whether password change require a first login
                            if (DepartmentUser.WhetherPasswordChange.ToUpper() == CustomText.FALSE.ToString())
                            {
                                PreserveModelState(KeyName._Key06, DepartmentUser.UserId, false, true);
                                PreserveModelState(KeyName._Key07, DB.LS.ToString(), false, true);
                                PreserveModelState(KeyName._Key08, DepartmentUser.UserId, false, true);

                                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "Type" }, new ArrayList() { ((int)CountList.Type000).ToString() });
                                return RedirectToAction("ChangePasswordAtFirstLogin", "Account", new { q = QueryString });
                            }

                            // Update maxloginattempt value = 0
                            Utility.CheckLoginAttempt(model.EmployeeUserName, DB.LS.ToString(), Dml.Update.ToString());

                            // Set Applicationo in Tempdata for Application Preview
                            PreserveModelState(KeyName._Key09, model.CustomText, false, true);

                            if (Convert.ToInt32(DepartmentUser.AuthenticationTypeId) == (int)ValueId.AuthDigital)
                            {
                                PreserveModelState(KeyName._Key01, DepartmentUser, false, true);
                                return RedirectToAction("EmployeeDigitalLogin");
                            }
                            else if (Convert.ToInt32(DepartmentUser.AuthenticationTypeId) == (int)ValueId.AuthOtp)
                            {
                                List<NpgsqlCommand> CmdList = new List<NpgsqlCommand>();
                                string Otp = Utility.GetRandomString(6, 2);
                                DepartmentUser.OTP = Otp;

                                Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                smsDic.Add("ParamOTP", Otp);
                                smsDic.Add("ParamMobileNo", DepartmentUser.ContactNo);
                                CmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS028, smsDic));

                                if (DepartmentUser.EmailId != null)
                                {
                                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                                    EmailDic.Add("ParamOTP", Otp);
                                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                                    EmailDic.Add("ParamEmailId", DepartmentUser.EmailId);
                                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS028).ToString());
                                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                                    CmdList.Add(EmailCmd);
                                }
                                data.SaveData(CmdList);

                                PreserveModelState(KeyName._Key01, DepartmentUser, false, true);
                                return RedirectToAction("EmployeeOTPLogin");
                            }
                            else if (Convert.ToInt32(DepartmentUser.AuthenticationTypeId) == (int)ValueId.AutheKYC)
                            {
                                PreserveModelState(KeyName._Key01, DepartmentUser, false, true);
                            }

                            PreserveModelState(KeyName._Key01, DepartmentUser, false, true);
                            return RedirectToAction("EmployeeAuthenticatLogin");
                        }
                        else
                        {
                            Utility.InsertDepartmentLoginTrail(model.EmployeeUserName, Dml.Insert.ToString(), (int)ValueId.WrongPassword);
                            ModelState.AddModelError("", "The provided user name or password is incorrect.");
                        }
                    }
                }
            }
            Sessions.setSalt(Utility.GetRandomString(50));
            return View(model);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult EmployeeAuthenticatLogin(int? Flag = 0)
        {
            try
            {
                //get department user object from session
                UserMaster DepartmentUser = (UserMaster)TempData[KeyName._Key01];
                if (DepartmentUser == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }

                // check if user account approved by thier concerned administrator
                string[] routereidrectValue = Utility.SelectColumnsValue("dbo.usermaster", "whetherdetailupdate,whetherdetailapprove", "UserId", DepartmentUser.UserId);
                if (routereidrectValue[0].ToUpper() == CustomText.FALSE.ToString())
                {
                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "UserId" }, new ArrayList() { DepartmentUser.UserId });
                    return RedirectToAction("UpdateUserEntryDetails", "Common", new { q = QueryString });
                }

                if (DepartmentUser.Permission != ((int)Permission.P118).ToString())
                {
                    if (routereidrectValue[0].ToUpper() == CustomText.TRUE.ToString() && routereidrectValue[1].ToUpper() == CustomText.FALSE.ToString())
                    {
                        ViewData["message"] = "The account details is not approved by Administrator, kindly contact to your Administrator of your concerned department/nodal department.";
                        return View("message");
                    }
                }

                if (Flag == (int)CountList.Type000)
                {
                    GetData data = new GetData();
                    LoginModel model = new LoginModel();
                    model.DeptCode = DepartmentUser.DeptCode;
                    model.DeptName = Utility.SelectColumnsValue("DeptMaster", "DeptName", "DeptCode", DepartmentUser.DeptCode)[0];
                    PreserveModelState(KeyName._Key09, null, true, false);
                    TempData[KeyName._Key01] = DepartmentUser;

                    string Qry = "select UM.UserId,UserName,case when Gender='M' then 'Male' when Gender='F' then 'Female' end as Gender,to_char(DateofBirth,'DD/MM/YYYY') as DateofBirth,ContactNo,Pname as PermissionType,DistrictName,SubDivdescription,SMVD.ValueName as AuthenticationType,UM.AuthenticationTypeId,SMVDD.ValueName as SigningType,usertimefrom::text,usertimeto::text,to_char(CreateDate,'DD/MM/YYYY') as CreateDate,to_char(LastPassowrdChange,'DD/MM/YYYY') as LastPassowrdChange  from usermaster UM inner join PermissionMaster PM on PM.Pcode=UM.Permission inner join SelectMasterValueDetails SMVD on SMVD.ValueId=UM.AuthenticationTypeId inner join SelectMasterValueDetails SMVDD on SMVDD.ValueId=UM.SigningTypeId left outer join DistrictMaster DM on DM.DistrictCode=UM.DistrictCode left outer join usertosubdivmaster USDM on USDM.Uid=UM.Uid and USDM.WhetherActive=@WhetherActive  left outer join subdivmaster SDM on SDM.SubDivCode=USDM.SubDivCode  where UM.UserId=@UserId";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@UserId", DepartmentUser.UserId);
                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                    model.data = data.GetDataTable(Cmd);

                    StringBuilder str = new StringBuilder();
                    Qry = "select case when userdatefrom='1900-01-01 00:00:00' then 'FALSE' else 'TRUE' end as NotCorrectDate,case when authenticationtypeid not in (@AuthOtp,@AuthDigital) then 'FALSE' else 'TRUE' end as authenticationNotCorrect,case when documentdata is null then 'FALSE' else 'TRUE' end as FormNotUploaded from usermaster UM left outer join usercreationenclosuredetails UCED on UCED.UserId=UM.UserId where UM.userid=@UserId";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@UserId", DepartmentUser.UserId);
                    Cmd.Parameters.AddWithValue("@AuthOtp", (int)ValueId.AuthOtp);
                    Cmd.Parameters.AddWithValue("@AuthDigital", (int)ValueId.AuthDigital);
                    string[] values = data.SelectColumns(Cmd);
                    if (values != null)
                    {
                        str.Append("Keeping in view the changing scenario of the technology and growing security threats and suggestion from cyber security wing, it is proposed that security features/valid details should be required to implemented in user authentication prior to June 10, 2018. The Administrator of your concerned District/Department is authorized to make changes in your e-District account. \n\n ");
                        str.Append("The give below following feature should be required to implemented in your account for proper authentication at e - District Delhi. \n\n ");
                        if (values[0] == CustomText.FALSE.ToString())
                        {
                            str.Append("* IP Address Binding for user. \n ");
                            str.Append("* Working Timing hours to be bound. \n ");
                        }
                        if (values[1] == CustomText.FALSE.ToString())
                        {
                            str.Append("* Additional security authentication check like OPT based or Digital Signature bases. \n ");
                        }
                        if (values[2] == CustomText.FALSE.ToString())
                        {
                            str.Append("* Approved user creation form from concerned authority.");
                        }

                    }
                    model.Flag = str.ToString();

                    return View("DepartmentSelfDeclaration", model);
                }

                DepartmentUserDetails objDeptUser = new DepartmentUserDetails();
                objDeptUser = Utility.GetDepartmentUser(DepartmentUser);
                Sessions.setEmployeeUser(objDeptUser);

                //check whether maximum account exceed per role
                string MaxRoleMessege = Utility.CheckMaxUserCreated();
                if (!string.IsNullOrEmpty(MaxRoleMessege))
                {
                    TempData[KeyName._Key02] = MaxRoleMessege;
                    return RedirectToAction("EmployeeLogin");
                }

                //FormsAuthentication.SetAuthCookie(model.EmployeeUserName, false);
                FormsAuthentication.SetAuthCookie(DepartmentUser.UserId, false);
                var authTicket = new FormsAuthenticationTicket(1,                    // version
                                                               DepartmentUser.UserName, // user name
                                                               DateTime.Now,         // created 
                                                               DateTime.Now.AddMinutes(30),// expires
                                                               DepartmentUser.RememberMe,  // persistent Remeber me?
                                                               DepartmentUser.Permission // can be used to store roles
                                                               );
                string encryptedTicket = FormsAuthentication.Encrypt(authTicket);
                var authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);
                HttpContext.Response.Cookies.Add(authCookie);

                Utility.UpdateLoginLastAttempt(objDeptUser.UserId);
                Utility.InsertDepartmentLoginTrail(DepartmentUser.UserId, Dml.Insert.ToString(), (int)ValueId.LoginSuccess);

                // check data and reditect to view application
                if (TempData[KeyName._Key09] != null)
                {
                    return RedirectToAction("PublicAppPreviewDetails", "Public", new { AppData = TempData[KeyName._Key09] });

                    //string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { TempData[KeyName._Key09] });
                    //return RedirectToAction("PublicAppPreview", "Public", new { q = QueryString });
                }

                //Verify document from department server
                if (Sessions.getEmployeeUser().Permission == ((int)Permission.DEAL).ToString() || Sessions.getEmployeeUser().Permission == ((int)Permission.TEHS).ToString())
                {
                    //Utility.AutoVerifyDocument();

                    // for social welfare department [handicapped pension scheme]
                    if (Convert.ToInt32(Sessions.getEmployeeUser().DeptCode) == (int)Department.Dept002)
                    {
                        Utility.HandicapReminderMsg();
                    }
                }


                ////temp process for locality approval
                //if (Sessions.getEmployeeUser().Permission == ((int)Permission.TEHS).ToString())
                //{
                //    if (Convert.ToInt32(Sessions.getEmployeeUser().DeptCode) == (int)Department.Dept001)
                //    {
                //        string routereidrect = Utility.SelectColumnsValue("dbo.temp_localitycheck", "whethercomplete", "subdivcode", Sessions.getEmployeeUser().SubDivCode)[0];
                //        if (routereidrect.ToUpper() == CustomText.FALSE.ToString())
                //        {
                //            return RedirectToAction("MapPendingLocality", "Common");
                //        }
                //    }
                //}


                //// temp code for skip the modification
                //if (routereidrectValue[0].ToUpper() == CustomText.FALSE.ToString())
                //{
                //    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "UserId" }, new ArrayList() { DepartmentUser.UserId });
                //    return RedirectToAction("UpdateUserEntryDetails", "Common", new { q = QueryString });
                //}



                //// form for display the message of modification of use details 
                //if (DepartmentUser.Permission != ((int)Permission.P118).ToString())
                //{
                //    if (routereidrectValue[0].ToUpper() == CustomText.TRUE.ToString() && routereidrectValue[1].ToUpper() == CustomText.FALSE.ToString())
                //    {
                //        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "flag", "UserId" }, new ArrayList() { (int)CountList.Type001, DepartmentUser.UserId });
                //        return RedirectToAction("ApproveUserEntryDetails", "Common", new { q = QueryString });
                //    }
                //}

                //if (Convert.ToInt32(DepartmentUser.DeptCode) == (int)Department.Dept010)
                //{
                //    if (DepartmentUser.Permission == ((int)Permission.P120).ToString() || DepartmentUser.Permission == ((int)Permission.SDMG).ToString() || DepartmentUser.Permission == ((int)Permission.DEAL).ToString())
                //    {
                //        if (routereidrectValue[0].ToUpper() == CustomText.TRUE.ToString() && routereidrectValue[1].ToUpper() == CustomText.FALSE.ToString())
                //        {
                //            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "flag", "UserId" }, new ArrayList() { (int)CountList.Type001, DepartmentUser.UserId });
                //            return RedirectToAction("ApproveUserEntryDetails", "Common", new { q = QueryString });
                //        }
                //    }
                //}
                //else
                //{
                //    if (DepartmentUser.Permission != ((int)Permission.P118).ToString())
                //    {
                //        if (routereidrectValue[0].ToUpper() == CustomText.TRUE.ToString() && routereidrectValue[1].ToUpper() == CustomText.FALSE.ToString())
                //        {
                //            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "flag", "UserId" }, new ArrayList() { (int)CountList.Type001, DepartmentUser.UserId });
                //            return RedirectToAction("ApproveUserEntryDetails", "Common", new { q = QueryString });
                //        }
                //    }
                //}


                return RedirectToAction("DepartmentIndex", "Home");
            }
            catch
            {
                return RedirectToAction("InternalError", "Error");
            }
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult EmployeeOTPLogin()
        {
            try
            {
                UserMaster DepartmentUser = (UserMaster)TempData[KeyName._Key01];
                if (DepartmentUser == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }

                GetData data = new GetData();
                LoginModel model = new LoginModel();
                model.EmployeeUserName = DepartmentUser.UserId;

                if (TempData[KeyName._Key02] != null) { ModelState.AddModelError("", TempData[KeyName._Key02].ToString()); }
                PreserveModelState(KeyName._Key01, DepartmentUser, false, true);
                return View(model);
            }
            catch
            {
                return RedirectToAction("InternalError", "Error");
            }
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult EmployeeOTPLogin(LoginModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    GetData data = new GetData();
                    UserMaster DepartmentUser = (UserMaster)TempData[KeyName._Key01];
                    if (DepartmentUser.OTP.ToLower() != model.OTP.ToLower())
                    {
                        PreserveModelState(KeyName._Key02, "The OTP you have entered didn't match with our record. Please try again.", false, true);
                        PreserveModelState(KeyName._Key01, DepartmentUser, false, true);
                        return RedirectToAction("EmployeeOTPLogin");
                    }
                    return RedirectToAction("EmployeeAuthenticatLogin");
                }
                return View((LoginModel)TempData[KeyName._Key01]);
            }
            catch
            {
                return RedirectToAction("InternalError", "Error");
            }
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult EmployeeDigitalLogin()
        {
            try
            {
                UserMaster DepartmentUser = (UserMaster)TempData[KeyName._Key01];
                if (DepartmentUser == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }

                // check if user account approved by thier concerned administrator
                string[] routereidrectValue = null;
                if (DepartmentUser.Permission != ((int)Permission.P118).ToString())
                {
                    routereidrectValue = Utility.SelectColumnsValue("dbo.usermaster", "whetherdetailupdate,whetherdetailapprove", "UserId", DepartmentUser.UserId);
                    if (routereidrectValue[0].ToUpper() == CustomText.FALSE.ToString())
                    {
                        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "UserId" }, new ArrayList() { DepartmentUser.UserId });
                        return RedirectToAction("UpdateUserEntryDetails", "Common", new { q = QueryString });
                    }
                    if (routereidrectValue[0].ToUpper() == CustomText.TRUE.ToString() && routereidrectValue[1].ToUpper() == CustomText.FALSE.ToString())
                    {
                        ViewData["message"] = "The account details is not approved by Administrator, kindly contact to your Administrator.";
                        return View("message");
                    }
                }

                
                //if (Convert.ToInt32(DepartmentUser.DeptCode) == (int)Department.Dept010)
                //{
                //    if (DepartmentUser.Permission == ((int)Permission.P120).ToString() || DepartmentUser.Permission == ((int)Permission.SDMG).ToString() || DepartmentUser.Permission == ((int)Permission.DEAL).ToString())
                //    {
                //        routereidrectValue = Utility.SelectColumnsValue("dbo.usermaster", "whetherdetailupdate,whetherdetailapprove", "UserId", DepartmentUser.UserId);
                //        if (routereidrectValue[0].ToUpper() == CustomText.FALSE.ToString())
                //        {
                //            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "UserId" }, new ArrayList() { DepartmentUser.UserId });
                //            return RedirectToAction("UpdateUserEntryDetails", "Common", new { q = QueryString });
                //        }
                //        //if (routereidrectValue[0].ToUpper() == CustomText.TRUE.ToString() && routereidrectValue[1].ToUpper() == CustomText.FALSE.ToString())
                //        //{
                //        //    ViewData["message"] = "The account details is not approved by Administrator, kindly contact to your Administrator.";
                //        //    return View("message");
                //        //}
                //    }
                //}
                ////DeficiancyChanges
                //else
                //{
                //    if (DepartmentUser.Permission != ((int)Permission.P118).ToString())
                //    {
                //        routereidrectValue = Utility.SelectColumnsValue("dbo.usermaster", "whetherdetailupdate,whetherdetailapprove", "UserId", DepartmentUser.UserId);
                //        if (routereidrectValue[0].ToUpper() == CustomText.FALSE.ToString())
                //        {
                //            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "UserId" }, new ArrayList() { DepartmentUser.UserId });
                //            return RedirectToAction("UpdateUserEntryDetails", "Common", new { q = QueryString });
                //        }
                //        //if (routereidrectValue[0].ToUpper() == CustomText.TRUE.ToString() && routereidrectValue[1].ToUpper() == CustomText.FALSE.ToString())
                //        //{
                //        //    ViewData["message"] = "The account details is not approved by Administrator, kindly contact to your Administrator.";
                //        //    return View("message");
                //        //}
                //    }
                //}

                GetData data = new GetData();
                LoginModel model = new LoginModel();
                model.EmployeeUserName = DepartmentUser.UserId;

                string Qry = "select dc.cardpath,dc.cardtypename,ud.serialno as sessionserialno,dc.jaraccountname,dc.jaraccountlogin,um.username from usermaster um inner join digitalcardtypemaster dc on dc.cardtypeid=um.cardtypeid left outer join userdigitalmaster ud on (ud.userid=um.userid and ud.whetheractive=@whetheractive) where um.userid=@userid";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@userid", model.EmployeeUserName);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.True.ToString());
                model.DigitalCardTypeMaster = DigitalCardTypeMaster.Get<DigitalCardTypeMaster>(new DigitalCardTypeMaster(), Cmd);
                if (string.IsNullOrEmpty(model.DigitalCardTypeMaster.SessionSerialNo)) { model.DigitalCardTypeMaster.SessionSerialNo = string.Empty; }

                model.FilePath = Utility.SaveAndDisplayFileForMudraLogin(model.EmployeeUserName, "eDistrictString");
                PreserveModelState(KeyName._Key01, null, true, false);
                return View(model);
            }
            catch
            {
                return RedirectToAction("InternalError", "Error");
            }
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult EmployeeDigitalLogin(LoginModel model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    GetData data = new GetData();
                    UserMaster DepartmentUser = (UserMaster)TempData[KeyName._Key01];
                    string[] CardUserDetails = null;
                    if (!string.IsNullOrEmpty(model.textname)) { CardUserDetails = model.textname.Split(','); }
                    if (CardUserDetails.Length > 0) { model.textname = CardUserDetails[0].ToString(); }
                    if (DepartmentUser.UserName.ToLower() != model.textname.ToLower())
                    {
                        PreserveModelState(KeyName._Key02, "The User Name of your Digital USB does not match with your login name.", false, true);
                        return RedirectToAction("EmployeeLogin");
                    }

                    //module for checking details of inactive mapping of digital user
                    string Qry = "select du.userid,du.username,du.serialno,du.certificatechain,to_char(du.validfrom,'DD/MM/YYYY') as validfrom,to_char(du.validto,'DD/MM/YYYY') as validto from userdigitalmaster du inner join usermaster um on (du.userid=um.userid and du.whetheractive=@whetheractive) where um.userid=@userid";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@userid", DepartmentUser.UserId);
                    Cmd.Parameters.AddWithValue("@whetheractive", CustomText.False.ToString());
                    DataTable dta = data.GetDataTable(Cmd);
                    if (dta != null)
                    {
                        if (dta.Rows.Count > 0)
                        {
                            //Verify Validity of Digital USB with current date
                            if (Convert.ToDateTime(model.tilldate) < Convert.ToDateTime((DateTime.Now.ToString("dd-MM-yyyy"))))
                            {
                                PreserveModelState(KeyName._Key02, "The Validity of your Digital USB has been expired, Kindly contact to your district administrator", false, true);
                                return RedirectToAction("EmployeeLogin");
                            }

                            //Verify User Name and Digital USB Mapping from DataBase 
                            if (dta.Rows[0]["username"].ToString().ToLower() == model.textname.ToLower() && dta.Rows[0]["serialno"].ToString().ToLower() == model.serialnum.ToLower() && dta.Rows[0]["certificatechain"].ToString().ToLower() == model.certificationChain.ToLower() && (dta.Rows[0]["validfrom"].ToString() == model.fromdate.Replace('-', '/')) && (dta.Rows[0]["validto"].ToString() == model.tilldate.Replace('-', '/')))
                            {
                                PreserveModelState(KeyName._Key02, "The Mapping of your User Name and Digital USB is already exist in our record in Deactivated Form. Kindly Contact to the Administrator", false, true);
                                return RedirectToAction("EmployeeLogin");
                            }
                        }
                    }


                    Qry = "select du.userid,du.username,du.serialno,du.certificatechain,to_char(du.validfrom,'DD/MM/YYYY') as validfrom,to_char(du.validto,'DD/MM/YYYY') as validto from userdigitalmaster du inner join usermaster um on (du.userid=um.userid and du.whetheractive=@whetheractive) where um.userid=@userid";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@userid", DepartmentUser.UserId);
                    Cmd.Parameters.AddWithValue("@whetheractive", CustomText.True.ToString());
                    model.UserDigitalMaster = UserDigitalMaster.Get<UserDigitalMaster>(new UserDigitalMaster(), Cmd);
                    if (string.IsNullOrEmpty(model.UserDigitalMaster.UserName))
                    {
                        //check mapping with details exist or not?
                        Qry = "select case when validto::date >= now()::date then true else false end as whethertrue from userdigitalmaster where userid=@userid and serialno=@serialno";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@userid", DepartmentUser.UserId);
                        Cmd.Parameters.AddWithValue("@serialno", model.serialnum);
                        string WhetherTrue = data.SelectColumns(Cmd)[0];
                        if (!string.IsNullOrEmpty(WhetherTrue))
                        {
                            if (WhetherTrue.ToUpper() == CustomText.FALSE.ToString())
                            {
                                PreserveModelState(KeyName._Key02, "System has detected that token already mapped with User Id:" + DepartmentUser.UserId + " in deactivated state, for activation of mapping kindly contact to district administrator.", false, true);
                                return RedirectToAction("EmployeeLogin");
                            }
                        }

                        Qry = "insert into userdigitalmaster(userid,username,serialno,certificatechain,validfrom,validto,whetheractive) values(@userid,@username,@serialno,@certificatechain,@validfrom,@validto,@whetheractive)";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@userid", DepartmentUser.UserId);
                        Cmd.Parameters.AddWithValue("@username", model.textname);
                        Cmd.Parameters.AddWithValue("@serialno", model.serialnum);
                        Cmd.Parameters.AddWithValue("@certificatechain", model.certificationChain);
                        Cmd.Parameters.AddWithValue("@validfrom", Utility.ConvertDateSequenceForDatabase(model.fromdate, '-', true));
                        Cmd.Parameters.AddWithValue("@validto", Utility.ConvertDateSequenceForDatabase(model.tilldate, '-', true));
                        Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                        data.UpdateData(Cmd);

                        PreserveModelState(KeyName._Key02, "Digital USB token has been mapped successfully, Kindly login to access your service.", false, true);
                        return RedirectToAction("EmployeeLogin");
                    }
                    //Verify User Name of Digital USB
                    if (model.UserDigitalMaster.UserName.ToLower() != model.textname.ToLower())
                    {
                        PreserveModelState(KeyName._Key02, "The User Name of your Digital USB does not match with our record.", false, true);
                        return RedirectToAction("EmployeeLogin");
                    }
                    //Verify Serial Number of Digital USB
                    if (model.UserDigitalMaster.SerialNo.ToLower() != model.serialnum.ToLower())
                    {
                        PreserveModelState(KeyName._Key02, "The Serial No. of your Digital USB does not match with our record.", false, true);
                        return RedirectToAction("EmployeeLogin");
                    }
                    //Verify Certification Chain of Digital USB
                    if (model.UserDigitalMaster.CertificateChain.ToLower() != model.certificationChain.ToLower())
                    {
                        PreserveModelState(KeyName._Key02, "The Certificate Chain of your Digital USB does not match with our record.", false, true);
                        return RedirectToAction("EmployeeLogin");
                    }
                    //Verify Validity of Digital USB with database
                    if ((model.UserDigitalMaster.ValidFrom != model.fromdate.Replace('-', '/')) || (model.UserDigitalMaster.ValidTo != model.tilldate.Replace('-', '/')))
                    {
                        PreserveModelState(KeyName._Key02, "The Validity of your Digital USB does not match with our record, Kindly contact to your district administrator", false, true);
                        return RedirectToAction("EmployeeLogin");
                    }
                    //Verify Validity of Digital USB with current date
                    if (Convert.ToDateTime(model.tilldate) < Convert.ToDateTime((DateTime.Now.ToString("dd-MM-yyyy"))))
                    {
                        PreserveModelState(KeyName._Key02, "The Validity of your Digital USB has been expired, Kindly contact to your district administrator", false, true);
                        return RedirectToAction("EmployeeLogin");
                    }

                    PreserveModelState(KeyName._Key01, DepartmentUser, false, true);
                    return RedirectToAction("EmployeeAuthenticatLogin");

                }
                return View();
            }
            catch
            {
                return RedirectToAction("InternalError", "Error");
            }
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult DepartmentSelfDeclaration(LoginModel model)
        {
            if (model.AcceptDeclaration)
            {
                return RedirectToAction("EmployeeAuthenticatLogin", "Account", new { Flag = ((int)CountList.Type001).ToString() });
            }
            return View(model);
        }
        [AllowAnonymous]
        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult VerifyLastSession(string Uid, int Rsd = (int)CountList.Type000)
        {
            if (string.IsNullOrEmpty(Uid)) { return RedirectToAction("BadRequest", "Error"); }
            if (Rsd == (int)CountList.Type000 || Convert.ToString(TempData[KeyName._Key09]) == ((int)CountList.Type001).ToString()) {
                if (TempData[KeyName._Key10] != null) { TempData.Remove(KeyName._Key09); TempData.Remove(KeyName._Key10); return RedirectToAction("BadRequest", "Error"); }
                PreserveModelState(KeyName._Key10, KeyName._Key01.ToString(), false, true);
            }

            GetData data = new GetData();
            UserMaster DepartmentUser = Utility.GetUserDetail(Uid);
            List<NpgsqlCommand> CmdList = new List<NpgsqlCommand>();

            if (Rsd == (int)CountList.Type000 || Rsd == (int)CountList.Type001)
            {
                string Otp = Utility.GetRandomString(6, 2);
                PreserveModelState(KeyName._Key03, Otp, false, true);
                if (Rsd == (int)CountList.Type001) { PreserveModelState(KeyName._Key09, (int)CountList.Type001, false, true); }

                Dictionary<string, string> smsDic = new Dictionary<string, string>();
                smsDic.Add("ParamOTP", Otp);
                smsDic.Add("ParamMobileNo", DepartmentUser.ContactNo);
                CmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS028, smsDic));

                if (DepartmentUser.EmailId != null)
                {
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamOTP", Otp);
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamEmailId", DepartmentUser.EmailId);
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS028).ToString());
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    CmdList.Add(EmailCmd);
                }
                data.SaveData(CmdList);
            }
            PreserveModelState(KeyName._Key09, null, true, false);
            PreserveModelState(Constant._ModelStateParent, DepartmentUser, false, true);
            return View(DepartmentUser);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        [EncryptedActionParameter]
        [ValidateOnlyIncomingValues]
        public ActionResult VerifyLastSession(UserMaster model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                if (model.OTP == TempData[KeyName._Key03].ToString())
                {
                    string Qry = "update useronlinedetails set whetherlogout=@whetherlogout where userid=@userid";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@UserId", model.UserId);
                    Cmd.Parameters.AddWithValue("@whetherlogout", CustomText.True.ToString());
                    data.UpdateData(Cmd);

                    ViewData["message"] = "Your improper session has been fixed. Kindly login again at e-District Delhi.";
                    return View("message");
                }

                ViewBag.DisplayMessage = "The OTP you have provided doesn't matched with our record. Please enter valid OTP to further process.";

            }
            PreserveModelState(KeyName._Key03, null, true, false);
            PreserveModelState(KeyName._Key09, null, true, false);
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View((UserMaster)TempData[Constant._ModelStateParent]);

        }
        #endregion

        #region Mobile Sahayak Authentication
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult VerifyCitizen()
        {
            RegisterModel model = new RegisterModel();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult VerifyCitizen(RegisterModel model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = string.Empty;

                Qry = "select ApplicantUserId from web.RegistrationMaster where registrationId=@registrationId and ApplicantName=@ApplicantName and ApplicantGender=@ApplicantGender";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@registrationId", model.RegistrationId);
                Cmd.Parameters.AddWithValue("@ApplicantName", model.RegistrationMasterTemp.ApplicantName.ToUpper());
                Cmd.Parameters.AddWithValue("@ApplicantGender", model.RegistrationMasterTemp.ApplicantGender);
                Cmd.Parameters.AddWithValue("@ApplicantDOB", model.RegistrationMasterTemp.ApplicantDOB);
                string ApplicantUserId = data.SelectColumns(Cmd)[0];
                if (!string.IsNullOrEmpty(ApplicantUserId))
                {
                    bool IsValidAge = Utility.IsChildProfileLogin(model.RegistrationId.ToString());
                    if (IsValidAge)
                    {
                        ViewData["Message"] = "Date of Birth of Citizen User is less than 18 years, So you are not authorized to process further at e-district Delhi Portal.";
                        return View("Message");
                    }

                    int MaxLoginAttempt = Utility.CheckLoginAttempt(model.RegistrationId.ToString(), DB.RS.ToString(), Dml.Select.ToString());
                    if (MaxLoginAttempt > 10)
                    {
                        ViewData["Message"] = "The password of your citizen profile has been blocked due to maximum hit, Kindly reset the password or contact to Contact to your concerned SubDivision/District Office.";
                        return View("Message");
                    }
                    else
                    {
                        string WhetherActive = Utility.SelectColumnsValue("web.RegistrationMaster", "WhetherActive", "registrationId", model.RegistrationId.ToString())[0];
                        if (WhetherActive.ToUpper() == CustomText.TRUE.ToString())
                        {
                            model.RegistrationId = model.RegistrationId;
                            //string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "RegistrationId" }, new ArrayList() { Convert.ToInt32(model.RegistrationId) });
                            //return RedirectToAction("VerifyCitizenOTP", "Account", new { q = QueryString });

                            model.SahayakId = Sessions.getEmployeeUser().UserId;
                            FormsAuthentication.SignOut();
                            if (Sessions.getEmployeeUser() != null)
                            {
                                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().UserId))
                                {
                                    Utility.UpdateLogOutAttempt(Sessions.getEmployeeUser().UserId);
                                    Utility.InsertDepartmentLoginTrail(Sessions.getEmployeeUser().UserId, Dml.Update.ToString(), null);
                                }
                            }
                            Session.Clear();
                            Session.Abandon();
                            Session.RemoveAll();
                            if (Request.Cookies["ASP.NET_SessionId"] != null)
                            {
                                Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
                                Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddMonths(-20);
                            }
                            if (Request.Cookies["__RequestVerificationToken"] != null)
                            {
                                Response.Cookies["__RequestVerificationToken"].Value = string.Empty;
                                Response.Cookies["__RequestVerificationToken"].Expires = DateTime.Now.AddMonths(-20);
                            }
                            if (Request.Cookies[".ASPXAUTH"] != null)
                            {
                                Response.Cookies[".ASPXAUTH"].Value = string.Empty;
                                Response.Cookies[".ASPXAUTH"].Expires = DateTime.Now.AddMonths(-20);
                            }
                            return View("AuthenticateCitizen", model);
                        }
                        else
                        {
                            ViewData["Message"] = "Your Citizen details at e-District Delhi has been deactivated, Kindly Contact to Concerned SubDivision/District Office";
                            return View("Message");
                        }
                    }
                }
                else
                {
                    ViewData["Message"] = "The provided citizen details doesn't matched with our records.";
                    return View("Message");
                }

            }
            return View(model);
        }
        //[EncryptedActionParameter]
        //[AcceptVerbs(HttpVerbs.Get)]
        //public ActionResult VerifyCitizenOTP(int RegistrationId, int? ResendAttempt = 1)
        //{
        //    try
        //    {
        //        GetData data = new GetData();
        //        RegisterModel model = new RegisterModel();
        //        List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
        //        string validupto = string.Empty, CurrDateTime = string.Empty;
        //        if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }

        //        model.RegistrationId = RegistrationId;
        //        model.ResendAttempt = Convert.ToInt32(ResendAttempt);

        //        string[] values = Utility.SelectColumnsValue("web.RegistrationMaster", "ApplicantMobileNo,ApplicantEmail", "registrationId", model.RegistrationId.ToString());

        //        string Qry = "select otpdetails,to_char(validupto,'yyyyMMddHH24MISS') as validupto,to_char(now(),'yyyyMMddHH24MISS') as CurrDateTime  from smsotpdetails where referenceno=@RegistrationId and referencetype=@referencetype order by otpid desc limit 1";
        //        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@RegistrationId", model.RegistrationId);
        //        Cmd.Parameters.AddWithValue("@referencetype", (int)ValueId.OTPMobileCitizenAuthenticate);
        //        model.data = data.GetDataTable(Cmd);
        //        if (model.data != null && model.data.Rows.Count > 0)
        //        {
        //            model.OTPGet = model.data.Rows[0]["otpdetails"].ToString();
        //            validupto = model.data.Rows[0]["validupto"].ToString();
        //            CurrDateTime = model.data.Rows[0]["CurrDateTime"].ToString();
        //            if (Convert.ToInt64(CurrDateTime) > Convert.ToInt64(validupto))
        //            {
        //                model.OTPGet = Utility.GetRandomString(5, 2);

        //                Qry = "insert into dbo.smsotpdetails(otpdetails,createdate,validupto,referencetype,referenceno) values(@otpdetails,now(),now() + INTERVAL '10 min',@referencetype,@referenceno)";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@otpdetails", model.OTPGet);
        //                Cmd.Parameters.AddWithValue("@referencetype", (int)ValueId.OTPMobileCitizenAuthenticate);
        //                Cmd.Parameters.AddWithValue("@referenceno", model.RegistrationId);
        //                cmdList.Add(Cmd);

        //                Dictionary<string, string> smsDic = new Dictionary<string, string>();
        //                smsDic.Add("ParamMobileNo", values[0]);
        //                smsDic.Add("ParamOTP", model.OTPGet);
        //                cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS028, smsDic));

        //                if (!string.IsNullOrEmpty(values[1].ToString()))
        //                {
        //                    //send email to applicant and insert record in table
        //                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
        //                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
        //                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS028).ToString());
        //                    EmailDic.Add("ParamOTP", model.OTPGet);
        //                    EmailDic.Add("ParamEmailId", values[1]);
        //                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
        //                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }
        //                }
        //                data.SaveData(cmdList);

        //                ViewBag.DisplayMessage = "The existing OTP has been expried and new OTP for authentication of citizen profile has been sent to registered Mobile No. of citizen.";
        //            }
        //        }
        //        else
        //        {
        //            model.OTPGet = Utility.GetRandomString(5, 2);
        //            Qry = "insert into dbo.smsotpdetails(otpdetails,createdate,validupto,referencetype,referenceno) values(@otpdetails,now(),now() + INTERVAL '10 min',@referencetype,@referenceno)";
        //            Cmd = new NpgsqlCommand(Qry);
        //            Cmd.Parameters.AddWithValue("@otpdetails", model.OTPGet);
        //            Cmd.Parameters.AddWithValue("@referencetype", (int)ValueId.OTPMobileCitizenAuthenticate);
        //            Cmd.Parameters.AddWithValue("@referenceno", model.RegistrationId);
        //            cmdList.Add(Cmd);

        //            Dictionary<string, string> smsDic = new Dictionary<string, string>();
        //            smsDic.Add("ParamMobileNo", values[0]);
        //            smsDic.Add("ParamOTP", model.OTPGet);
        //            cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS028, smsDic));

        //            if (!string.IsNullOrEmpty(values[1]))
        //            {
        //                //send email to applicant and insert record in table
        //                Dictionary<string, string> EmailDic = new Dictionary<string, string>();
        //                EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
        //                EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS028).ToString());
        //                EmailDic.Add("ParamOTP", model.OTPGet);
        //                EmailDic.Add("ParamEmailId", values[1]);
        //                NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
        //                if (EmailCmd != null) { cmdList.Add(EmailCmd); }
        //            }
        //            data.SaveData(cmdList);

        //            ViewBag.DisplayMessage = "The OTP for authentication of citizen profile has been sent to registered Mobile No. of citizen.";
        //        }
        //        return View(model);
        //    }
        //    catch
        //    {
        //        return RedirectToAction("InternalError", "Error");
        //    }
        //}
        //[AcceptVerbs(HttpVerbs.Post)]
        //[ValidateAntiForgeryToken]
        //[ValidateOnlyIncomingValues]
        //public ActionResult VerifyCitizenOTP(RegisterModel model)
        //{
        //    try
        //    {
        //        if (ModelState.IsValid)
        //        {
        //            GetData data = new GetData();
        //            string QueryString = string.Empty;
        //            if (model.OTPGet.ToLower() != model.OTPPost.ToLower())
        //            {
        //                PreserveModelState(Constant._ActionMessage, "The OTP you have entered did not match with our record. Please try again.", false, true);
        //                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "RegistrationId", "ResendAttempt" }, new ArrayList() { Convert.ToInt32(model.RegistrationId), model.ResendAttempt });//MobSahayakChanges
        //                return RedirectToAction("VerifyCitizenOTP", "Account", new { q = QueryString });
        //            }

        //            model.SahayakId = Sessions.getEmployeeUser().UserId;
        //            FormsAuthentication.SignOut();
        //            if (Sessions.getEmployeeUser() != null)
        //            {
        //                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().UserId))
        //                {
        //                    Utility.UpdateLogOutAttempt(Sessions.getEmployeeUser().UserId);
        //                    Utility.InsertDepartmentLoginTrail(Sessions.getEmployeeUser().UserId, Dml.Update.ToString(), null);
        //                }
        //            }
        //            Session.Clear();
        //            Session.Abandon();
        //            Session.RemoveAll();
        //            if (Request.Cookies["ASP.NET_SessionId"] != null)
        //            {
        //                Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
        //                Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddMonths(-20);
        //            }
        //            if (Request.Cookies["__RequestVerificationToken"] != null)
        //            {
        //                Response.Cookies["__RequestVerificationToken"].Value = string.Empty;
        //                Response.Cookies["__RequestVerificationToken"].Expires = DateTime.Now.AddMonths(-20);
        //            }
        //            if (Request.Cookies[".ASPXAUTH"] != null)
        //            {
        //                Response.Cookies[".ASPXAUTH"].Value = string.Empty;
        //                Response.Cookies[".ASPXAUTH"].Expires = DateTime.Now.AddMonths(-20);
        //            }
        //            return View("AuthenticateCitizen", model);
        //        }
        //        return RedirectToAction("InternalError", "Error");
        //    }
        //    catch
        //    {
        //        return RedirectToAction("InternalError", "Error");
        //    }
        //}
        //[AcceptVerbs(HttpVerbs.Post)]
        //[ValidateAntiForgeryToken]
        //[ValidateOnlyIncomingValues]
        //public ActionResult ResendOTP(RegisterModel model)
        //{
        //    GetData data = new GetData();
        //    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
        //    if (model.ResendAttempt == (int)CountList.Type000) { ViewData["message"] = "Session Timed out! Please retry later!"; return View("message"); }

        //    model.OTPGet = Utility.GetRandomString(5, 2);
        //    string[] values = Utility.SelectColumnsValue("web.RegistrationMaster", "ApplicantMobileNo,ApplicantEmail", "registrationId", model.RegistrationId.ToString());

        //    string Qry = "insert into dbo.smsotpdetails(otpdetails,createdate,validupto,referencetype,referenceno) values(@otpdetails,now(),now() + INTERVAL '10 min',@referencetype,@referenceno)";
        //    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
        //    Cmd.Parameters.AddWithValue("@otpdetails", model.OTPGet);
        //    Cmd.Parameters.AddWithValue("@referencetype", (int)ValueId.OTPMobileCitizenAuthenticate);
        //    Cmd.Parameters.AddWithValue("@referenceno", model.RegistrationId);
        //    cmdList.Add(Cmd);

        //    Dictionary<string, string> smsDic = new Dictionary<string, string>();
        //    smsDic.Add("ParamMobileNo", values[0]);
        //    smsDic.Add("ParamOTP", model.OTPGet);
        //    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS028, smsDic));

        //    if (!string.IsNullOrEmpty(values[1]))
        //    {
        //        //send email to applicant and insert record in table
        //        Dictionary<string, string> EmailDic = new Dictionary<string, string>();
        //        EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
        //        EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS028).ToString());
        //        EmailDic.Add("ParamOTP", model.OTPGet);
        //        EmailDic.Add("ParamEmailId", values[1]);
        //        NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
        //        if (EmailCmd != null) { cmdList.Add(EmailCmd); }
        //    }
        //    data.SaveData(cmdList);

        //    model.ResendAttempt = model.ResendAttempt + 1;
        //    PreserveModelState(Constant._ActionMessage, "OTP Resend successfully", false, true);

        //    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "RegistrationId", "ResendAttempt" }, new ArrayList() { model.RegistrationId, model.ResendAttempt });
        //    return RedirectToAction("VerifyCitizenOTP", "Account", new { q = QueryString });
        //}
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult AuthenticateCitizen(RegisterModel model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                CitizenUserDetails objCtzUser = new CitizenUserDetails();
                objCtzUser.RegistrationId = model.RegistrationId.ToString();
                objCtzUser.SahayakId = model.SahayakId;

                string Qry = "select ApplicantName from web.RegistrationMaster where RegistrationID=@RegistrationID and ParentRegistrationId is null";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RegistrationID", model.RegistrationId);
                string ApplicantName = data.SelectColumns(Cmd)[0];

                if (!string.IsNullOrEmpty(ApplicantName))
                {
                    Sessions.setCurrentUser(objCtzUser);
                    FormsAuthentication.SetAuthCookie(model.RegistrationId.ToString(), false);
                    var authTicket = new FormsAuthenticationTicket(1,                    // version
                                                                   ApplicantName,       // user name
                                                                   DateTime.Now,         // created 
                                                                   DateTime.Now.AddMinutes(30),// expires
                                                                   false,                // persistent Remeber me?
                                                                   ((int)Permission.CITZ).ToString() // can be used to store roles
                                                                   );
                    string encryptedTicket = FormsAuthentication.Encrypt(authTicket);
                    var authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);
                    HttpContext.Response.Cookies.Add(authCookie);

                    Utility.CheckLoginAttempt(model.RegistrationId.ToString(), DB.RS.ToString(), Dml.Update.ToString());
                    Utility.InsertCitizenLoginTrail(model.RegistrationId.ToString(), Dml.Insert.ToString(), (int)ValueId.LoginSuccess);

                    return RedirectToAction("CzAvaiableServicesAtCitizen", "Receiving");
                }
                else
                {
                    return RedirectToAction("UnauthorizedRequest");
                }

            }
            return View(model);
        }
        #endregion

        #region Citizen Authentication Module
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult Login(string returnUrl)
        {
            if ((Request.IsAuthenticated) && Sessions.getCurrentUser() != null)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "Type", "Source" }, new ArrayList() { ((int)CountList.Type001).ToString(), ((int)CountList.Type001).ToString() });
                return RedirectToAction("MessagePage", "Public", new { q = QueryString });
            }

            Sessions.setSalt(Utility.GetRandomString(50));
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult Login(LoginModel model, string returnUrl, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.Captcha) == false)
                {
                    ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                    return View(model);
                }

                //tempraroy work for update userid of applicant
                string Qry = "update web.registrationmaster set applicantuserid=registrationid where applicantuserid is null";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                new GetData().UpdateData(Cmd);

                string UserName = model.CitizenUserName;
                model.CitizenUserName = Utility.SelectColumnsValue("web.RegistrationMaster", "registrationId", "ApplicantUserId", model.CitizenUserName)[0];
                if (!string.IsNullOrEmpty(model.CitizenUserName))
                {
                    bool IsValidAge = Utility.IsChildProfileLogin(model.CitizenUserName);
                    if (IsValidAge)
                    {
                        ViewData["Message"] = "Date of Birth of User is less than 18 years, So you are not authorized to Login in the e-district Delhi Portal.";
                        return View("Message");
                    }

                    int MaxLoginAttempt = Utility.CheckLoginAttempt(model.CitizenUserName, DB.RS.ToString(), Dml.Select.ToString());
                    if (MaxLoginAttempt > 10) { ModelState.AddModelError("", "The password has been blocked due to maximum hit, Kindly contact to administrator"); }
                    else
                    {
                        //Temp Process To Chnage MD5 Password to SHA512 at change password
                        string whetherchange = Utility.SelectColumnsValue("web.RegistrationMaster", "whethermd5change", "registrationId", model.CitizenUserName)[0];
                        if (whetherchange.ToUpper() == CustomText.FALSE.ToString())
                        {
                            PreserveModelState(KeyName._Key06, model.CitizenUserName, false, true);
                            PreserveModelState(KeyName._Key07, DB.RS.ToString(), false, true);
                            PreserveModelState(KeyName._Key08, UserName, false, true);
                            return RedirectToAction("ChangeLoginPassword");
                        }

                        RegistrationMaster CitizenUser = Authorize.ValidateCitizenUser(model.CitizenUserName, model.Password);
                        if (CitizenUser != null)
                        {
                            model.WhetherActive = Utility.SelectColumnsValue("web.RegistrationMaster", "WhetherActive", "registrationId", model.CitizenUserName)[0];
                            if (model.WhetherActive.ToUpper() == CustomText.TRUE.ToString())
                            {
                                PreserveModelState(KeyName._Key05, null, false, true);
                                int LastPasswordChange = Utility.CheckChangePasswordCitizen(CitizenUser.RegistrationID.ToString());
                                if (CitizenUser.WhetherPasswordChange.ToUpper() == CustomText.FALSE.ToString() || LastPasswordChange > 30)
                                {
                                    PreserveModelState(KeyName._Key06, CitizenUser.RegistrationID, false, true);
                                    PreserveModelState(KeyName._Key07, DB.RS.ToString(), false, true);
                                    PreserveModelState(KeyName._Key08, UserName, false, true);

                                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "Type" }, new ArrayList() { ((int)CountList.Type000).ToString() });
                                    return RedirectToAction("ChangePasswordAtFirstLogin", "Account", new { q = QueryString });
                                }

                                CitizenUserDetails objCtzUser = new CitizenUserDetails();
                                //objCtzUser.ApplicantUserID = CitizenUser.DocumentNo;
                                objCtzUser.RegistrationId = CitizenUser.RegistrationID.ToString();

                                Sessions.setCurrentUser(objCtzUser);
                                FormsAuthentication.SetAuthCookie(model.CitizenUserName, false);
                                var authTicket = new FormsAuthenticationTicket(1,                    // version
                                                                               CitizenUser.ApplicantName,       // user name
                                                                               DateTime.Now,         // created 
                                                                               DateTime.Now.AddMinutes(30),// expires
                                                                               model.RememberMe,                // persistent Remeber me?
                                                                               ((int)Permission.CITZ).ToString() // can be used to store roles
                                                                               );
                                string encryptedTicket = FormsAuthentication.Encrypt(authTicket);
                                var authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);
                                HttpContext.Response.Cookies.Add(authCookie);

                                Utility.CheckLoginAttempt(model.CitizenUserName, DB.RS.ToString(), Dml.Update.ToString());
                                Utility.InsertCitizenLoginTrail(model.CitizenUserName, Dml.Insert.ToString(), (int)ValueId.LoginSuccess);
                                return RedirectToLocal(returnUrl);

                            }
                            else
                            {
                                ModelState.AddModelError("", "Your Account has been Deactivated,Kindly Contact to Concerned SubDivision/District Office");
                            }
                        }
                        else
                        {
                            ModelState.AddModelError("", "The provided user name or password is incorrect.");
                        }
                    }
                }
                else
                {
                    ModelState.AddModelError("", "The provided user name or password is incorrect.");
                }
            }
            Sessions.setSalt(Utility.GetRandomString(50));
            return View(model);
        }
        #endregion

        #region Citizen Registration Module
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult Register()
        {
            RegisterModel model = new RegisterModel();
            return View(model);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult CheckRegistration(RegisterModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.FirstCaptcha) == false)
                    {
                        ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                        return View("Register", model);
                    }


                    if (string.IsNullOrEmpty(model.DocumentNo)) { model.DocumentNo = RijndaelSimple.DecryptStringAES(model.AadhaarNo); }
                    else { model.DocumentNo = RijndaelSimple.DecryptStringAES(model.DocumentNo); }
                    if (string.IsNullOrEmpty(model.DocumentNo))
                    {
                        ViewBag.DisplayMessage = "Please provide a Document No.";
                        return View("Register", model);
                    }

                    GetData data = new GetData();
                    string Qry = "SELECT TempRegistrationID,dbo.udf_general_decrypt(RM.DocumentNo) as DocumentNo,DM.DocumentName,ApplicantName,ApplicantGender,ApplicantFatherName,ApplicantMotherName,ApplicantSpouseName,to_char(ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantlocalityid,applicantsubdivcode,applicantdistrictcode,applicantstateid,applicantcountryid,applicantpincode) as CompleteAddress,ApplicantPinCode,ApplicantMobileNo,ApplicantEmail,RegistrationDate,ApplicantIpAddress,RM.LastActionPerformed from web.RegistrationMasterTemp RM left outer join dbo.DocumentMaster DM on DM.DocumentId=RM.DocumentId where RM.DocumentNo=@DocumentNo";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(model.DocumentNo.ToUpper()));
                    model.RegistrationMasterTemp = RegistrationMasterTemp.Get<RegistrationMasterTemp>(new RegistrationMasterTemp(), Cmd);
                    if (!string.IsNullOrEmpty(model.RegistrationMasterTemp.DocumentNo))
                    {
                        if (DateTime.Now > Convert.ToDateTime(model.RegistrationMasterTemp.RegistrationDate).AddHours(48))
                        {
                            Qry = "delete from web.RegistrationMasterTemp where DocumentNo=@DocumentNo";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(model.DocumentNo.ToUpper()));
                            data.UpdateData(Cmd);

                            ViewBag.DisplayMessage = "Server has detected that you have already registered your basic details.\\n But as per our registration policy your access code and password has been experied.\\n Kindly register again to start your account.";
                            return View("Register", model);
                        }
                        else
                        {
                            ViewBag.DisplayMessage = "Server has detected that you have already registered your basic details.\\n Kindly enter Access Code and Password to Complete Registration.";
                            PreserveModelState(Constant._SecondLastActionId, null, false, true);
                            Sessions.setSalt(Utility.GetRandomString(50));
                            model.RegistrationMasterTemp.DocumentNo = model.DocumentNo;
                            PreserveModelState(KeyName._Key09, model.RegistrationMasterTemp.ApplicantMobileNo + "," + model.DocumentNo.ToUpper(), false, true);

                            return View("ViewRegisterApplicant", model);
                        }
                    }

                    Qry = "select RegistrationId from registrationtodocumentmaster where documentid=@documentid and documentno=@documentno";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@documentid", model.DocId);
                    Cmd.Parameters.AddWithValue("@documentno", Utility.GetByteFromDocumentNo(model.DocumentNo.ToUpper()));
                    string WhetherAadhaarExist = data.SelectColumns(Cmd)[0];
                    if (!string.IsNullOrEmpty(WhetherAadhaarExist))
                    {
                        model.RegistrationMasterTemp = null;
                        ViewBag.DisplayMessage = "Provided Document No.[" + model.DocumentNo + "] has been already registered.";
                    }
                    else
                    {
                        model.RegistrationMasterTemp.DocumentNo = model.DocumentNo;
                        model.RegistrationMasterTemp.DocumentName = Utility.SelectColumnsValue("dbo.DocumentMaster", "DocumentName", "DocumentId", model.DocId)[0];
                    }
                    PreserveModelState(KeyName._Key05, null, false, true);
                    return View("Register", model);
                }
                catch
                {
                    return RedirectToAction("Index", "Error");
                }
            }
            return View("Register", model);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult Register(RegisterModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.SecondCaptcha) == false)
                    {
                        ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                        return View(model);
                    }

                    // Check duplicate mobile number
                    string DupMobileMessage = Utility.CheckDuplicateMobileNo(model.RegistrationMasterTemp.ApplicantMobileNo);
                    if (!string.IsNullOrEmpty(DupMobileMessage))
                    {
                        ViewBag.DisplayMessage = DupMobileMessage;
                        return View("Register", model);
                    }

                    //HttpPostedFile appImage = System.Web.HttpContext.Current.Request.Files["ApplicantPhoto"];
                    //byte[] imageByte = Utility.HttpFilePhotoData(System.Web.HttpContext.Current.Request.Files["ApplicantPhoto"]);
                    //if (!Utility.IsImage(appImage))
                    //{
                    //    ViewBag.DisplayMessage = "Invalid/Wrong image file does not allowed";
                    //    return View("Register", model);
                    //}

                    // Document authentication from thier concerend department
                    if (model.DocId == ((int)DocumentId.AadhaarCard).ToString())
                    {
                        int DocStatusId = Utility.VerifyRegistrationDocument(model.RegistrationMasterTemp.ApplicantName, model.RegistrationMasterTemp.ApplicantGender.ToString(), model.RegistrationMasterTemp.ApplicantDOB, model.RegistrationMasterTemp.DocumentNo, (int)DocumentId.AadhaarCard);
                        if (DocStatusId != (int)WebServiceResponse.Verified)
                        {
                            ViewBag.DisplayMessage = "The provided AADHAAR No. is not validated with entered details, Kindly enter the correct details. \\n To locate your nearest UIDAI center, go to 'Locate UIDAI Center' link on HOME Page.";
                            return View("Register", model);
                        }
                        model.RegistrationMasterTemp.documentstatusid = ((int)WebServiceResponse.Verified).ToString();
                    }
                    else if (model.DocId == ((int)DocumentId.VoterID).ToString())
                    {
                        int DocStatusId = Utility.VerifyRegistrationDocument(model.RegistrationMasterTemp.ApplicantName, model.RegistrationMasterTemp.ApplicantGender.ToString(), model.RegistrationMasterTemp.ApplicantDOB, model.RegistrationMasterTemp.DocumentNo, (int)DocumentId.VoterID);
                        if (DocStatusId != (int)WebServiceResponse.Verified)
                        {
                            ViewBag.DisplayMessage = "The provided Voter Id is not validated with entered details, \\n Kindly enter the correct details.";
                            return View("Register", model);
                        }
                        model.RegistrationMasterTemp.documentstatusid = ((int)WebServiceResponse.Verified).ToString();
                    }
                    else
                    {
                        return RedirectToAction("BadRequest", "Error");
                    }


                    //check Locality Mapping
                    bool CheckMapping = Utility.CheckCorrectMapping(model.RegistrationMasterTemp.ApplicantLocalityId, model.RegistrationMasterTemp.ApplicantSubDivCode, model.RegistrationMasterTemp.ApplicantDistrictCode, null, null);
                    if (CheckMapping == false)
                    {
                        ViewBag.DisplayMessage = "The mapping of your locality does not mapped, \\n Kindly contact to conccerened department.";
                        return View("Register", model);
                    }

                    // check duplicate on the basis of applicant details
                    GetData data = new GetData();
                    string Qry = "select registrationid  from web.registrationmaster where ApplicantName=@ApplicantName and ApplicantFatherName=@ApplicantFatherName and to_char(Applicantdob,'YYYYMMDD')::date =@ApplicantDOB and ApplicantGender=@ApplicantGender";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicantName", model.RegistrationMasterTemp.ApplicantName.ToUpper());
                    Cmd.Parameters.AddWithValue("@ApplicantFatherName", model.RegistrationMasterTemp.ApplicantFatherName.ToUpper());
                    Cmd.Parameters.AddWithValue("@ApplicantGender", model.RegistrationMasterTemp.ApplicantGender.ToUpper());
                    Cmd.Parameters.AddWithValue("@ApplicantDOB", Utility.ConvertDateSequenceForDatabase(model.RegistrationMasterTemp.ApplicantDOB, '/', true));
                    string WhetherAlreadyExist = data.SelectColumns(Cmd)[0];
                    if (!string.IsNullOrEmpty(WhetherAlreadyExist))
                    {
                        ViewBag.DisplayMessage = "The provided information is already exist, \\n Kindly enter the correct details.";
                        return View("Register", model);
                    }

                    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                    string AccessCode = Utility.GetRandomString(5, 1);
                    string SimplePassword = Utility.GetRandomString(8, 3);
                    string HashPassword = Utility.GenerateSHA512(SimplePassword).ToString().ToLower();
                    //model.RegistrationMasterTemp.ApplicantPhoto = Utility.CompareFileCapturePhotoData(model.PhotoData, imageByte); //removed by security audit pannel

                    //Qry = "insert into web.RegistrationMasterTemp(DocumentId,DocumentNo,ApplicantName,ApplicantGender,AadharApplicantFatherName,ApplicantMotherName,ApplicantSpouseName,ApplicantFatherName,AadharApplicantDOB,ApplicantDOB,AadharApplicantAddress,ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,applicantstateid,applicantcountryid,ApplicantDistrictCode,ApplicantSubDivCode,AadharApplicantPinCode,ApplicantPinCode,ApplicantLocalityId,ApplicantMobileNo,ApplicantEmail,ApplicantPhoto,ApplicantPassword,ApplicantAccessCode,RegistrationDate,ApplicantIpAddress,LastActionPerformed,documentstatusid,ApplicantPermanentAddress,WhetherSameAddress,ConsentId) values(@DocumentId,dbo.udf_general_encrypt(@DocumentNo),@ApplicantName,@ApplicantGender,@AadharApplicantFatherName,@ApplicantMotherName,@ApplicantSpouseName,@ApplicantFatherName,@AadharApplicantDOB,@ApplicantDOB,@AadharApplicantAddress,@ApplicantHouseNumber,@ApplicantStreetNumber,@ApplicantSubLocality,@applicantstateid,@applicantcountryid,@ApplicantDistrictCode,@ApplicantSubDivCode,@AadharApplicantPinCode,@ApplicantPinCode,@ApplicantLocalityId,@ApplicantMobileNo,@ApplicantEmail,@ApplicantPhoto,@ApplicantPassword,@ApplicantAccessCode,now(),@ApplicantIpAddress,now(),@documentstatusid,@ApplicantPermanentAddress,@WhetherSameAddress,@ConsentId); SELECT currval(pg_get_serial_sequence('web.registrationmastertemp','tempregistrationid'))";
                    Qry = "insert into web.RegistrationMasterTemp(DocumentId,DocumentNo,ApplicantName,ApplicantGender,AadharApplicantFatherName,ApplicantMotherName,ApplicantSpouseName,ApplicantFatherName,AadharApplicantDOB,ApplicantDOB,AadharApplicantAddress,ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,applicantstateid,applicantcountryid,ApplicantDistrictCode,ApplicantSubDivCode,AadharApplicantPinCode,ApplicantPinCode,ApplicantLocalityId,ApplicantMobileNo,ApplicantEmail,ApplicantPassword,ApplicantAccessCode,RegistrationDate,ApplicantIpAddress,LastActionPerformed,documentstatusid,ApplicantPermanentAddress,WhetherSameAddress,ConsentId) values(@DocumentId,dbo.udf_general_encrypt(@DocumentNo),@ApplicantName,@ApplicantGender,@AadharApplicantFatherName,@ApplicantMotherName,@ApplicantSpouseName,@ApplicantFatherName,@AadharApplicantDOB,@ApplicantDOB,@AadharApplicantAddress,@ApplicantHouseNumber,@ApplicantStreetNumber,@ApplicantSubLocality,@applicantstateid,@applicantcountryid,@ApplicantDistrictCode,@ApplicantSubDivCode,@AadharApplicantPinCode,@ApplicantPinCode,@ApplicantLocalityId,@ApplicantMobileNo,@ApplicantEmail,@ApplicantPassword,@ApplicantAccessCode,now(),@ApplicantIpAddress,now(),@documentstatusid,@ApplicantPermanentAddress,@WhetherSameAddress,@ConsentId); SELECT currval(pg_get_serial_sequence('web.registrationmastertemp','tempregistrationid'))";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@DocumentNo", model.RegistrationMasterTemp.DocumentNo.ToUpper());
                    Cmd.Parameters.AddWithValue("@ApplicantName", model.RegistrationMasterTemp.ApplicantName.ToUpper());
                    Cmd.Parameters.AddWithValue("@ApplicantGender", model.RegistrationMasterTemp.ApplicantGender.ToUpper());
                    Cmd.Parameters.AddWithValue("@AadharApplicantFatherName", model.RegistrationMasterTemp.AadharApplicantFatherName);
                    Cmd.Parameters.AddWithValue("@ApplicantFatherName", model.RegistrationMasterTemp.ApplicantFatherName.ToUpper());
                    Cmd.Parameters.AddWithValue("@ApplicantMotherName", model.RegistrationMasterTemp.ApplicantMotherName.ToUpper());
                    Cmd.Parameters.AddWithValue("@ApplicantSpouseName", model.RegistrationMasterTemp.ApplicantSpouseName);
                    Cmd.Parameters.AddWithValue("@AadharApplicantDOB", Utility.GetDateYYYYMMDD(model.RegistrationMasterTemp.AadharApplicantDOB, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@ApplicantDOB", Utility.GetDateYYYYMMDD(model.RegistrationMasterTemp.ApplicantDOB, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@AadharApplicantAddress", model.RegistrationMasterTemp.AadharApplicantAddress);
                    Cmd.Parameters.AddWithValue("@ApplicantHouseNumber", model.RegistrationMasterTemp.ApplicantHouseNumber);
                    Cmd.Parameters.AddWithValue("@ApplicantStreetNumber", model.RegistrationMasterTemp.ApplicantStreetNumber);
                    Cmd.Parameters.AddWithValue("@ApplicantSubLocality", model.RegistrationMasterTemp.ApplicantSubLocality);
                    Cmd.Parameters.AddWithValue("@applicantstateid", model.RegistrationMasterTemp.StateId);
                    Cmd.Parameters.AddWithValue("@applicantcountryid", model.RegistrationMasterTemp.CountryId);
                    Cmd.Parameters.AddWithValue("@ApplicantDistrictCode", model.RegistrationMasterTemp.ApplicantDistrictCode);
                    Cmd.Parameters.AddWithValue("@ApplicantSubDivCode", model.RegistrationMasterTemp.ApplicantSubDivCode);
                    Cmd.Parameters.AddWithValue("@AadharApplicantPinCode", model.RegistrationMasterTemp.AadharApplicantPinCode);
                    Cmd.Parameters.AddWithValue("@ApplicantPinCode", model.RegistrationMasterTemp.ApplicantPinCode);
                    Cmd.Parameters.AddWithValue("@ApplicantLocalityId", model.RegistrationMasterTemp.ApplicantLocalityId);
                    Cmd.Parameters.AddWithValue("@ApplicantMobileNo", model.RegistrationMasterTemp.ApplicantMobileNo);
                    Cmd.Parameters.AddWithValue("@ApplicantEmail", model.RegistrationMasterTemp.ApplicantEmail);
                    //Cmd.Parameters.AddWithValue("@ApplicantPhoto", model.RegistrationMasterTemp.ApplicantPhoto);
                    Cmd.Parameters.AddWithValue("@ApplicantPassword", HashPassword);
                    Cmd.Parameters.AddWithValue("@ApplicantAccessCode", AccessCode);
                    Cmd.Parameters.AddWithValue("@ApplicantIpAddress", Utility.GetIP4Address());
                    Cmd.Parameters.AddWithValue("@documentstatusid", model.RegistrationMasterTemp.documentstatusid);
                    Cmd.Parameters.AddWithValue("@DocumentId", model.DocId);
                    Cmd.Parameters.AddWithValue("@ConsentId", model.consentcheckid);
                    Cmd.Parameters.AddWithValue("@ApplicantPermanentAddress", model.RegistrationMasterTemp.ApplicantPermanentAddress);
                    Cmd.Parameters.AddWithValue("@WhetherSameAddress", model.RegistrationMasterTemp.WhetherSameAddress);
                    cmdList.Add(Cmd);

                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamAccessCode", AccessCode);
                    smsDic.Add("ParamPassword", SimplePassword);
                    smsDic.Add("ParamMobileNo", model.RegistrationMasterTemp.ApplicantMobileNo);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS008, smsDic));

                    if (!string.IsNullOrEmpty(model.RegistrationMasterTemp.ApplicantEmail))
                    {
                        Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                        EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS008).ToString());
                        EmailDic.Add("ParamEmailId", model.RegistrationMasterTemp.ApplicantEmail);
                        EmailDic.Add("ParamAccessCode", AccessCode);
                        EmailDic.Add("ParamPassword", SimplePassword);
                        EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                        NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                        if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                    }

                    data.SaveData(cmdList);

                    Qry = "select dbo.displaycompleteaddressfromid(@ApplicantHouseNumber,@ApplicantStreetNumber,@ApplicantSubLocality,@ApplicantLocalityId,@ApplicantSubDivCode,@ApplicantDistrictCode,@applicantstateid,@applicantcountryid,@ApplicantPinCode) as CompleteAddress";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicantHouseNumber", model.RegistrationMasterTemp.ApplicantHouseNumber);
                    Cmd.Parameters.AddWithValue("@ApplicantStreetNumber", model.RegistrationMasterTemp.ApplicantStreetNumber);
                    Cmd.Parameters.AddWithValue("@ApplicantSubLocality", model.RegistrationMasterTemp.ApplicantSubLocality);
                    Cmd.Parameters.AddWithValue("@ApplicantLocalityId", model.RegistrationMasterTemp.ApplicantLocalityId);
                    Cmd.Parameters.AddWithValue("@ApplicantSubDivCode", model.RegistrationMasterTemp.ApplicantSubDivCode);
                    Cmd.Parameters.AddWithValue("@ApplicantDistrictCode", model.RegistrationMasterTemp.ApplicantDistrictCode);
                    Cmd.Parameters.AddWithValue("@applicantstateid", model.RegistrationMasterTemp.StateId);
                    Cmd.Parameters.AddWithValue("@applicantcountryid", model.RegistrationMasterTemp.CountryId);
                    Cmd.Parameters.AddWithValue("@ApplicantPinCode", model.RegistrationMasterTemp.ApplicantPinCode);
                    model.RegistrationMasterTemp.CompleteAddress = data.SelectColumns(Cmd)[0];

                    PreserveModelState(KeyName._Key09, model.RegistrationMasterTemp.ApplicantMobileNo + "," + model.RegistrationMasterTemp.DocumentNo.ToUpper(), false, true);
                    PreserveModelState(Constant._LastActionId, Constant._LastActionId, false, true);
                    PreserveModelState(Constant._ModelStateParent, model, false, true);
                    Sessions.setSalt(Utility.GetRandomString(50));
                    return View("ViewRegisterApplicant", model);
                }
                catch
                {
                    return RedirectToAction("Index", "Error");
                }
            }
            return View(model);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult FinalRegister(RegisterModel model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                try
                {
                    // temp code for document no untill C# AES encryption
                    string str = string.Empty;
                    if (TempData[KeyName._Key09] != null)
                    {
                        str = TempData[KeyName._Key09].ToString();
                        string[] Val = str.Split(',');
                        model.RegistrationMasterTemp.DocumentNo = Val[1];
                    }
                    else { return RedirectToAction("BadRequest", "Error"); }

                    if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.FirstCaptcha) == false)
                    {
                        //string Qry2 = "SELECT TempRegistrationID,dbo.udf_general_decrypt(RM.DocumentNo) as DocumentNo,DM.DocumentName,ApplicantName,ApplicantGender,ApplicantFatherName,ApplicantMotherName,ApplicantSpouseName,to_char(ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantlocalityid,applicantsubdivcode,applicantdistrictcode,applicantstateid,applicantcountryid,applicantpincode) as CompleteAddress,ApplicantPinCode,ApplicantMobileNo,ApplicantEmail,RegistrationDate,ApplicantIpAddress,LastActionPerformed,ApplicantPermanentAddress from web.RegistrationMasterTemp RM  left outer join dbo.DocumentMaster DM on DM.DocumentId=RM.DocumentId where upper(dbo.udf_general_decrypt(RM.DocumentNo))=@DocumentNo";
                        string Qry2 = "SELECT TempRegistrationID,dbo.udf_general_decrypt(RM.DocumentNo) as DocumentNo,DM.DocumentName,ApplicantName,ApplicantGender,ApplicantFatherName,ApplicantMotherName,ApplicantSpouseName,to_char(ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantlocalityid,applicantsubdivcode,applicantdistrictcode,applicantstateid,applicantcountryid,applicantpincode) as CompleteAddress,ApplicantPinCode,ApplicantMobileNo,ApplicantEmail,RegistrationDate,ApplicantIpAddress,LastActionPerformed,ApplicantPermanentAddress from web.RegistrationMasterTemp RM  left outer join dbo.DocumentMaster DM on DM.DocumentId=RM.DocumentId where RM.DocumentNo=@DocumentNo";
                        NpgsqlCommand Cmd2 = new NpgsqlCommand(Qry2);
                        Cmd2.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(model.RegistrationMasterTemp.DocumentNo.ToUpper()));
                        model.RegistrationMasterTemp = RegistrationMasterTemp.Get<RegistrationMasterTemp>(new RegistrationMasterTemp(), Cmd2);

                        PreserveModelState(KeyName._Key09, str, false, true);
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                        return View("ViewRegisterApplicant", model);
                    }
                    if (TempData[Constant._SecondLastActionId] != null) { return RedirectToAction("Refresh", "Error"); }

                    List<CMDInfoList> cmdList = new List<CMDInfoList>();
                    CMDInfoList CmdInfo = new CMDInfoList();
                    //string Qry = "select ApplicantAccessCode,ApplicantPassword,DocumentId,documentstatusid,ConsentId from web.RegistrationMasterTemp where upper(dbo.udf_general_decrypt(DocumentNo))=@DocumentNo;";
                    string Qry = "select ApplicantAccessCode,ApplicantPassword,DocumentId,documentstatusid,ConsentId from web.RegistrationMasterTemp where DocumentNo=@DocumentNo;";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(model.RegistrationMasterTemp.DocumentNo.ToUpper()));
                    string[] GetDetails = data.SelectColumns(Cmd);
                    string ApplicantAccessCode = GetDetails[0].ToString();
                    string ApplicantPassword = GetDetails[1].ToString();
                    string ConsentId = GetDetails[4].ToString();


                    string SimplePassword = Utility.GetRandomString(8, 3);
                    ApplicantPassword = Utility.GenerateSHA512(ApplicantPassword + Sessions.getSalt()).ToString().ToLower();

                    if (model.RegistrationMasterTemp.ApplicantPassword.Equals(ApplicantPassword) && model.RegistrationMasterTemp.ApplicantAccessCode.Equals(ApplicantAccessCode))
                    {
                        ApplicantPassword = Utility.GenerateSHA512(SimplePassword).ToString().ToLower();

                        //Qry = "insert into web.RegistrationMaster(DocumentId,DocumentNo,ApplicantName,ApplicantGender,AadharApplicantFatherName,ApplicantFatherName,ApplicantMotherName,ApplicantSpouseName,AadharApplicantDOB,ApplicantDOB,AadharApplicantAddress,ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,applicantstateid,applicantcountryid,ApplicantDistrictCode,ApplicantSubDivCode,AadharApplicantPinCode,ApplicantPinCode,ApplicantLocalityId,ApplicantMobileNo,ApplicantEmail,ApplicantPhoto,ApplicantPassword,ApplicantAccessCode,RegistrationDate,RegistrationSourceId,documentstatusid,ApplicantIpAddress,LastActionPerformed,ApplicantPermanentAddress,WhetherSameAddress) select DocumentId,DocumentNo,ApplicantName,ApplicantGender,AadharApplicantFatherName,ApplicantFatherName,ApplicantMotherName,ApplicantSpouseName,AadharApplicantDOB,ApplicantDOB,AadharApplicantAddress,ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,applicantstateid,applicantcountryid,ApplicantDistrictCode,ApplicantSubDivCode,AadharApplicantPinCode,ApplicantPinCode,ApplicantLocalityId,ApplicantMobileNo,ApplicantEmail,ApplicantPhoto,@ApplicantPassword,ApplicantAccessCode,now(),@RegistrationSourceId as RegistrationSourceId,documentstatusid,@ApplicantIpAddress,now(),ApplicantPermanentAddress,WhetherSameAddress from web.RegistrationMasterTemp where DocumentNo=@DocumentNo LIMIT 1; SELECT currval(pg_get_serial_sequence('web.registrationmaster','registrationid'))";
                        Qry = "insert into web.RegistrationMaster(DocumentId,DocumentNo,ApplicantName,ApplicantGender,AadharApplicantFatherName,ApplicantFatherName,ApplicantMotherName,ApplicantSpouseName,AadharApplicantDOB,ApplicantDOB,AadharApplicantAddress,ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,applicantstateid,applicantcountryid,ApplicantDistrictCode,ApplicantSubDivCode,AadharApplicantPinCode,ApplicantPinCode,ApplicantLocalityId,ApplicantMobileNo,ApplicantEmail,ApplicantPassword,ApplicantAccessCode,RegistrationDate,RegistrationSourceId,documentstatusid,ApplicantIpAddress,LastActionPerformed,ApplicantPermanentAddress,WhetherSameAddress) select DocumentId,DocumentNo,ApplicantName,ApplicantGender,AadharApplicantFatherName,ApplicantFatherName,ApplicantMotherName,ApplicantSpouseName,AadharApplicantDOB,ApplicantDOB,AadharApplicantAddress,ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,applicantstateid,applicantcountryid,ApplicantDistrictCode,ApplicantSubDivCode,AadharApplicantPinCode,ApplicantPinCode,ApplicantLocalityId,ApplicantMobileNo,ApplicantEmail,@ApplicantPassword,ApplicantAccessCode,now(),@RegistrationSourceId as RegistrationSourceId,documentstatusid,@ApplicantIpAddress,now(),ApplicantPermanentAddress,WhetherSameAddress from web.RegistrationMasterTemp where DocumentNo=@DocumentNo LIMIT 1; SELECT currval(pg_get_serial_sequence('web.registrationmaster','registrationid'))";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(model.RegistrationMasterTemp.DocumentNo.ToUpper()));
                        Cmd.Parameters.AddWithValue("@ApplicantIpAddress", Utility.GetIP4Address());
                        Cmd.Parameters.AddWithValue("@ApplicantPassword", ApplicantPassword);
                        Cmd.Parameters.AddWithValue("@RegistrationSourceId", (int)ApplicationSource.Online);
                        CmdInfo = new CMDInfoList();
                        CmdInfo.Cmd = Cmd; CmdInfo.Returns = true; CmdInfo.ParamenterIndex = null;
                        cmdList.Add(CmdInfo);

                        //if (WhetherUidVerified.ToString().ToUpper() == CustomText.TRUE.ToString())
                        //{
                        //    Qry = "insert into dbo.verificationdatamaster(RegistrationId,documentid, documentno,departmentid,aadhaarno, name, fathername, gender, dob, address,issuedby, whetheractive,actionuserid,actionipaddress,actiondatetime) select @Parameter0,@documentid,@DocumentNo,@departmentid,@DocumentNo,ApplicantName,ApplicantFatherName,ApplicantGender,ApplicantDOB,dbo.displaycompleteaddressfromid(ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,ApplicantLocalityId,ApplicantSubDivCode,ApplicantDistrictCode,applicantstateid,applicantcountryid,AadharApplicantPinCode) as Address,@issuedby,@whetheractive,@Parameter0,@actionipaddress,now() from web.RegistrationMasterTemp where upper(DocumentNo)=@DocumentNo LIMIT 1; SELECT currval(pg_get_serial_sequence('verificationdatamaster','verificationdataid'))";
                        //    Cmd = new NpgsqlCommand(Qry);
                        //    Cmd.Parameters.AddWithValue("@DocumentNo", model.RegistrationMasterTemp.DocumentNo.ToUpper());
                        //    Cmd.Parameters.AddWithValue("@documentid", (int)DocumentId.AadhaarCard);
                        //    Cmd.Parameters.AddWithValue("@departmentid", (int)EnclosureDepartment.UID);
                        //    Cmd.Parameters.AddWithValue("@issuedby", EnclosureDepartment.UID.ToString());
                        //    Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                        //    Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                        //    CmdInfo = new CMDInfoList();
                        //    CmdInfo.Cmd = Cmd; CmdInfo.Returns = true; CmdInfo.ParamenterIndex = new int[] { 0 };
                        //    cmdList.Add(CmdInfo);

                        //    Qry = "insert into dbo.applicantenclosuredetails(RegistrationId,DocumentId,DepartmentId,DocumentNo,VerifyValueId,WhetherVerified,WhetherActive,DocumentEntryDate,VerificationDataId,userid,ipaddress,lastupdatedate) values (@Parameter0,@DocumentId,@DepartmentId,@DocumentNo,@VerifyValueId,@WhetherVerified,@WhetherActive,now(),@Parameter1,@Parameter0,@ipaddress,now())";
                        //    Cmd = new NpgsqlCommand(Qry);
                        //    Cmd.Parameters.AddWithValue("@DocumentId", (int)DocumentId.AadhaarCard);
                        //    Cmd.Parameters.AddWithValue("@DocumentNo", model.RegistrationMasterTemp.DocumentNo.ToUpper());
                        //    Cmd.Parameters.AddWithValue("@DepartmentId", (int)EnclosureDepartment.UID);
                        //    Cmd.Parameters.AddWithValue("@VerifyValueId", (int)WebServiceResponse.Verified);
                        //    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                        //    Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.TRUE.ToString());
                        //    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        //    CmdInfo = new CMDInfoList();
                        //    CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = new int[] { 0, 1 };
                        //    cmdList.Add(CmdInfo);
                        //}

                        //Qry = "delete from web.RegistrationMasterTemp where upper(dbo.udf_general_decrypt(DocumentNo))=@DocumentNo;";
                        Qry = "delete from web.RegistrationMasterTemp where DocumentNo=@DocumentNo;";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(model.RegistrationMasterTemp.DocumentNo.ToUpper()));
                        CmdInfo = new CMDInfoList();
                        CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
                        cmdList.Add(CmdInfo);

                        Qry = "insert into dbo.registrationtodocumentmaster (RegistrationID,DocumentId,DepartmentId,DocumentNo,DocumentStatusId,WhetherVerified,ConsentId,userid,ipaddress) values (@Parameter0,@DocumentId,@DepartmentId,dbo.udf_general_encrypt(@DocumentNo),@DocumentStatusId,@WhetherVerified,@ConsentId,@Parameter0,@ipaddress)";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@DocumentId", GetDetails[2]);
                        Cmd.Parameters.AddWithValue("@DocumentNo", model.RegistrationMasterTemp.DocumentNo.ToUpper());
                        Cmd.Parameters.AddWithValue("@DepartmentId", Utility.GetDepartmentId(GetDetails[2]));
                        Cmd.Parameters.AddWithValue("@DocumentStatusId", GetDetails[3]);
                        Cmd.Parameters.AddWithValue("@ConsentId", ConsentId);
                        Cmd.Parameters.AddWithValue("@WhetherVerified", (GetDetails[3] == ((int)WebServiceResponse.Verified).ToString()) ? CustomText.TRUE.ToString() : CustomText.FALSE.ToString());
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        CmdInfo = new CMDInfoList();
                        CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = new int[] { 0 };
                        cmdList.Add(CmdInfo);

                        model.RegistrationId = Convert.ToInt32(data.SaveTransactionalDataCustom(cmdList)[1].ToString());

                        string[] value = Utility.SelectColumnsValue("web.registrationmaster", "applicantmobileno,ApplicantEmail", "registrationid", model.RegistrationId.ToString());
                        string MobileNo = value[0];
                        string ApplicantEmail = value[1];

                        Dictionary<string, string> smsDic = new Dictionary<string, string>();
                        smsDic.Add("ParamRegistrationId", model.RegistrationId.ToString());
                        smsDic.Add("ParamPassword", SimplePassword);
                        smsDic.Add("ParamMobileNo", MobileNo);
                        data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS001, smsDic));

                        if (!string.IsNullOrEmpty(ApplicantEmail))
                        {
                            Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                            EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS001).ToString());
                            EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                            EmailDic.Add("ParamRegistrationId", model.RegistrationId.ToString());
                            EmailDic.Add("ParamEmailId", ApplicantEmail);
                            EmailDic.Add("ParamPassword", SimplePassword);
                            NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                            if (EmailCmd != null) { data.UpdateData(EmailCmd); }
                        }

                        PreserveModelState(Constant._ModelStateParent, null, false, true);
                        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "UserId" }, new ArrayList() { model.RegistrationId.ToString() });
                        return RedirectToAction("PubRegistrationReciept", "Print", new { q = QueryString });
                    }
                    else
                    {
                        //Qry = "SELECT TempRegistrationID,dbo.udf_general_decrypt(RM.DocumentNo) as DocumentNo,DM.DocumentName,ApplicantName,ApplicantGender,AadharApplicantFatherName,ApplicantFatherName,ApplicantMotherName,ApplicantSpouseName,to_char(AadharApplicantDOB,'DD/MM/YYYY') as AadharApplicantDOB,to_char(ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,AadharApplicantAddress,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantlocalityid,applicantsubdivcode,applicantdistrictcode,applicantstateid,applicantcountryid,applicantpincode) as CompleteAddress,ApplicantPinCode,ApplicantMobileNo,ApplicantEmail,RegistrationDate,ApplicantIpAddress,LastActionPerformed,ApplicantPermanentAddress from web.RegistrationMasterTemp RM  left outer join dbo.DocumentMaster DM on DM.DocumentId=RM.DocumentId where upper(dbo.udf_general_decrypt(RM.DocumentNo))=@DocumentNo";
                        Qry = "SELECT TempRegistrationID,dbo.udf_general_decrypt(RM.DocumentNo) as DocumentNo,DM.DocumentName,ApplicantName,ApplicantGender,AadharApplicantFatherName,ApplicantFatherName,ApplicantMotherName,ApplicantSpouseName,to_char(AadharApplicantDOB,'DD/MM/YYYY') as AadharApplicantDOB,to_char(ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,AadharApplicantAddress,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantlocalityid,applicantsubdivcode,applicantdistrictcode,applicantstateid,applicantcountryid,applicantpincode) as CompleteAddress,ApplicantPinCode,ApplicantMobileNo,ApplicantEmail,RegistrationDate,ApplicantIpAddress,LastActionPerformed,ApplicantPermanentAddress from web.RegistrationMasterTemp RM  left outer join dbo.DocumentMaster DM on DM.DocumentId=RM.DocumentId where RM.DocumentNo=@DocumentNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(model.RegistrationMasterTemp.DocumentNo.ToUpper()));
                        model.RegistrationMasterTemp = RegistrationMasterTemp.Get<RegistrationMasterTemp>(new RegistrationMasterTemp(), Cmd);

                        ModelState.AddModelError("", "The Access Code or Password are wrong.");
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        PreserveModelState(KeyName._Key09, str, false, true);
                        Sessions.setSalt(Utility.GetRandomString(50));
                        return View("ViewRegisterApplicant", model);
                    }
                }
                catch
                {
                    return RedirectToAction("Index", "Error");
                }
            }
            //string Qry1 = "SELECT TempRegistrationID,dbo.udf_general_decrypt(RM.DocumentNo) as DocumentNo,DM.DocumentName,ApplicantName,ApplicantGender,ApplicantFatherName,ApplicantMotherName,ApplicantSpouseName,to_char(ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantlocalityid,applicantsubdivcode,applicantdistrictcode,applicantstateid,applicantcountryid,applicantpincode) as CompleteAddress,ApplicantPinCode,ApplicantMobileNo,ApplicantEmail,RegistrationDate,ApplicantIpAddress,LastActionPerformed,ApplicantPermanentAddress from web.RegistrationMasterTemp RM  left outer join dbo.DocumentMaster DM on DM.DocumentId=RM.DocumentId where upper(dbo.udf_general_decrypt(RM.DocumentNo))=@DocumentNo";
            string Qry1 = "SELECT TempRegistrationID,dbo.udf_general_decrypt(RM.DocumentNo) as DocumentNo,DM.DocumentName,ApplicantName,ApplicantGender,ApplicantFatherName,ApplicantMotherName,ApplicantSpouseName,to_char(ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantlocalityid,applicantsubdivcode,applicantdistrictcode,applicantstateid,applicantcountryid,applicantpincode) as CompleteAddress,ApplicantPinCode,ApplicantMobileNo,ApplicantEmail,RegistrationDate,ApplicantIpAddress,LastActionPerformed,ApplicantPermanentAddress from web.RegistrationMasterTemp RM  left outer join dbo.DocumentMaster DM on DM.DocumentId=RM.DocumentId where RM.DocumentNo=@DocumentNo";
            NpgsqlCommand Cmd1 = new NpgsqlCommand(Qry1);
            Cmd1.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(model.RegistrationMasterTemp.DocumentNo.ToUpper()));
            model.RegistrationMasterTemp = RegistrationMasterTemp.Get<RegistrationMasterTemp>(new RegistrationMasterTemp(), Cmd1);
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            PreserveModelState(KeyName._Key09, null, true, false);
            return View("ViewRegisterApplicant", model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult ManageRegistration(Int32? pId)
        {
            GetData data = new GetData();
            RegisterModel model = new RegisterModel();
            if (pId != null) { model.RegistrationId = pId; } else { model.RegistrationId = Convert.ToInt32(Sessions.getCurrentUser().RegistrationId.ToString()); }

            string Qry = "select RegistrationID,dbo.udf_general_decrypt(DocumentNo) as DocumentNo,ApplicantName,ApplicantGender,AadharApplicantFatherName,ApplicantFatherName,ApplicantMotherName,ApplicantSpouseName,AadharApplicantDOB,to_char(ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB, AadharApplicantAddress,ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,applicantstateid,applicantcountryid, ApplicantSubDivCode,ApplicantDistrictCode,AadharApplicantPinCode,ApplicantPinCode,ApplicantLocalityId,localityname,subdivdescription,districtname,statename,countryname, ApplicantMobileNo,ApplicantEmail,ApplicantPassword, ApplicantAccessCode,RegistrationDate,ApplicantIpAddress,LastActionPerformed,LastLoginAttempt,applicantpermanentaddress,WhetherSameAddress from web.RegistrationMaster RM inner join dbo.districtmaster DM  on DM.DistrictCode=RM.ApplicantDistrictCode  inner join dbo.SubDivMaster SD on SD.SubDivCode=RM.ApplicantSubDivCode inner join dbo.statemaster SM on SM.stateid=RM.applicantstateid inner join dbo.countrymaster CM on CM.countryid=RM.applicantcountryid inner join dbo.LocalityMaster LM on RM.applicantlocalityid=LM.localityid where RegistrationID=@RegistrationID";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@RegistrationID", model.RegistrationId);
            model.RegistrationMaster = RegistrationMaster.Get<RegistrationMaster>(new RegistrationMaster(), Cmd);

            model.PhotoData = CustomValue.None.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ManageRegistration(RegisterModel model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                if (TempData["RegisterModel"] != null)
                {
                    string otppost = model.OTPPost;
                    model = (RegisterModel)TempData["RegisterModel"];
                    model.OTPPost = otppost;

                }
                // Check if department has trigger the action
                if (Sessions.getEmployeeUser() != null && !string.IsNullOrEmpty(model.ApplicationNo)) { return RedirectToAction("BadRequest", "Error"); }


                // Check Locality Mapping
                bool CheckMapping = Utility.CheckCorrectMapping(model.RegistrationMaster.ApplicantLocalityId, model.RegistrationMaster.ApplicantSubDivCode, model.RegistrationMaster.ApplicantDistrictCode, null, null);
                if (CheckMapping == false)
                {
                    ViewBag.DisplayMessage = "The mapping of your locality does not mapped, \\n Kindly contact to conccerened department.";
                    return View("ManageRegistration", model);
                }

                // Check duplicate mobile no
                string DupMobileMessage = Utility.CheckDuplicateMobileNo(model.RegistrationMaster.ApplicantMobileNo, (int)CountList.Type006);
                if (!string.IsNullOrEmpty(DupMobileMessage))
                {
                    ViewBag.DisplayMessage = DupMobileMessage;
                    return View("ManageRegistration", model);
                }
                if (TempData["RegisterModel"] == null)
                {
                    HttpPostedFile appImage = System.Web.HttpContext.Current.Request.Files["ApplicantPhoto"];
                    byte[] imageByte = Utility.HttpFilePhotoData(System.Web.HttpContext.Current.Request.Files["ApplicantPhoto"]);
                    if (!string.IsNullOrEmpty(appImage.FileName.ToString()))
                    {
                        if (!Utility.IsImage(appImage))
                        {
                            ViewBag.DisplayMessage = "Invalid/Wrong image file does not allowed";
                            return View("Register", model);
                        }
                    }
                    if (appImage != null)
                    {
                        TempData["imageByte"] = imageByte;
                    }
                }
                //send otp mobile no
                if (string.IsNullOrEmpty(model.OTPGet) && string.IsNullOrEmpty(Sessions.getCurrentUser().SahayakId))
                {
                    TempData["RegisterModel"] = model;
                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "RegistrationId" }, new ArrayList() { Convert.ToInt32(model.RegistrationMaster.RegistrationID) });
                    return RedirectToAction("UpdateProfileOTP", "Account", new { q = QueryString });
                }
                else
                {
                    if (model.OTPGet != model.OTPPost)
                    {

                        PreserveModelState(Constant._ActionMessage, "The OTP you have entered did not match with our record. Please try again.", false, true);
                        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "RegistrationId", "ResendAttempt" }, new ArrayList() { Convert.ToInt32(model.RegistrationId), model.ResendAttempt });
                        return RedirectToAction("UpdateProfileOTP", "Account", new { q = QueryString });
                    }
                }

                byte[] imageByte1 = (byte[])TempData["imageByte"];
                if ((!string.IsNullOrEmpty(model.PhotoData) && model.PhotoData != CustomValue.None.ToString()) || imageByte1.Length > 0)
                {
                    model.RegistrationMaster.ApplicantPhoto = Utility.CompareFileCapturePhotoData(model.PhotoData, imageByte1);
                }

                // insert Photograph details
                if (model.RegistrationMaster.ApplicantPhoto != null)
                {
                    cmdList.Add(Utility.InsertPhotographdetails(CustomText.TRUE.ToString(), null, model.RegistrationMaster.ApplicantPhoto));
                }

                //// Check if department has trigger the action
                //if (Sessions.getEmployeeUser() != null && !string.IsNullOrEmpty(model.ApplicationNo)) { return RedirectToAction("BadRequest", "Error"); }

                //// Check Locality Mapping
                //bool CheckMapping = Utility.CheckCorrectMapping(model.RegistrationMaster.ApplicantLocalityId, model.RegistrationMaster.ApplicantSubDivCode, model.RegistrationMaster.ApplicantDistrictCode, null, null);
                //if (CheckMapping == false)
                //{
                //    ViewBag.DisplayMessage = "The mapping of your locality does not mapped, \\n Kindly contact to conccerened department.";
                //    return View("ManageRegistration", model);
                //}

                //// Check duplicate mobile no
                //string DupMobileMessage = Utility.CheckDuplicateMobileNo(model.RegistrationMaster.ApplicantMobileNo, (int)CountList.Type006);
                //if (!string.IsNullOrEmpty(DupMobileMessage))
                //{
                //    ViewBag.DisplayMessage = DupMobileMessage;
                //    return View("ManageRegistration", model);
                //}
                
                //HttpPostedFile appImage = System.Web.HttpContext.Current.Request.Files["ApplicantPhoto"];
                //byte[] imageByte = Utility.HttpFilePhotoData(System.Web.HttpContext.Current.Request.Files["ApplicantPhoto"]); ;
                //if (!string.IsNullOrEmpty(appImage.FileName.ToString())) {
                //    if (!Utility.IsImage(appImage)) {
                //        ViewBag.DisplayMessage = "Invalid/Wrong image file does not allowed";
                //        return View("Register", model);
                //    }
                //}
                //if ((!string.IsNullOrEmpty(model.PhotoData) && model.PhotoData != CustomValue.None.ToString()) || imageByte.Length > 0) {
                //    model.RegistrationMaster.ApplicantPhoto = Utility.CompareFileCapturePhotoData(model.PhotoData, imageByte);
                //}

                //// insert Photograph details
                //if (model.RegistrationMaster.ApplicantPhoto != null)
                //{
                //    cmdList.Add(Utility.InsertPhotographdetails(CustomText.TRUE.ToString(), null, model.RegistrationMaster.ApplicantPhoto));
                //}




                // update in Registration Master
                string Qry = "update web.RegistrationMaster set ApplicantSpouseName=@ApplicantSpouseName,ApplicantHouseNumber=@ApplicantHouseNumber,ApplicantStreetNumber=@ApplicantStreetNumber,ApplicantSubLocality=@ApplicantSubLocality,applicantstateid=@applicantstateid,applicantcountryid=@applicantcountryid,applicantdistrictcode=@applicantdistrictcode,applicantsubdivcode=@applicantsubdivcode,ApplicantPinCode=@ApplicantPinCode,ApplicantLocalityId=@ApplicantLocalityId,ApplicantMobileNo=@ApplicantMobileNo,ApplicantEmail=@ApplicantEmail,ApplicantIpAddress=@ApplicantIpAddress,LastActionPerformed=now(),ApplicantPermanentAddress=@ApplicantPermanentAddress,WhetherSameAddress=@WhetherSameAddress,ActionPerformedBy=@ActionPerformedBy";
                if (model.RegistrationMaster.ApplicantPhoto != null) { Qry += ",refphotoid=@LastInsertedId "; }
                Qry += " where RegistrationId=@RegistrationId";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ActionPerformedBy", Sessions.getCurrentUser().RegistrationId);
                Cmd.Parameters.AddWithValue("@RegistrationId", model.RegistrationMaster.RegistrationID);
                Cmd.Parameters.AddWithValue("@ApplicantSpouseName", model.RegistrationMaster.ApplicantSpouseName);
                Cmd.Parameters.AddWithValue("@ApplicantHouseNumber", model.RegistrationMaster.ApplicantHouseNumber);
                Cmd.Parameters.AddWithValue("@ApplicantStreetNumber", model.RegistrationMaster.ApplicantStreetNumber);
                Cmd.Parameters.AddWithValue("@ApplicantSubLocality", model.RegistrationMaster.ApplicantSubLocality);
                Cmd.Parameters.AddWithValue("@ApplicantLocalityId", model.RegistrationMaster.ApplicantLocalityId);
                Cmd.Parameters.AddWithValue("@applicantstateid", model.RegistrationMaster.ApplicantStateId);
                Cmd.Parameters.AddWithValue("@applicantcountryid", model.RegistrationMaster.ApplicantCountryId);
                Cmd.Parameters.AddWithValue("@applicantdistrictcode", model.RegistrationMaster.ApplicantDistrictCode);
                Cmd.Parameters.AddWithValue("@applicantsubdivcode", model.RegistrationMaster.ApplicantSubDivCode);
                Cmd.Parameters.AddWithValue("@ApplicantPinCode", model.RegistrationMaster.ApplicantPinCode);
                Cmd.Parameters.AddWithValue("@ApplicantMobileNo", model.RegistrationMaster.ApplicantMobileNo);
                Cmd.Parameters.AddWithValue("@ApplicantEmail", model.RegistrationMaster.ApplicantEmail);
                Cmd.Parameters.AddWithValue("@ApplicantPermanentAddress", model.RegistrationMaster.ApplicantPermanentAddress);
                Cmd.Parameters.AddWithValue("@WhetherSameAddress", model.RegistrationMaster.WhetherSameAddress);
                //if (model.RegistrationMaster.ApplicantPhoto != null) { Cmd.Parameters.AddWithValue("@ApplicantPhoto", model.RegistrationMaster.ApplicantPhoto); }
                Cmd.Parameters.AddWithValue("@ApplicantIpAddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "insert into web.registartionmodificationhistory(registrationid,actiontype,usertype,actionby,actiondate,actionipaddress) values(@registrationid,@actiontype,@usertype,@actionby,now(),@actionipaddress)";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@registrationid", model.RegistrationMaster.RegistrationID);
                Cmd.Parameters.AddWithValue("@actiontype", (int)ValueId.DetailsModifyBySelfParent);
                Cmd.Parameters.AddWithValue("@usertype", (int)ValueId.Applicant);
                Cmd.Parameters.AddWithValue("@actionby", Sessions.getCurrentUser().RegistrationId);
                Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                if (model.RegistrationMaster.ApplicantPhoto != null) { data.SaveTransactionalData(cmdList); } else { data.SaveData(cmdList); }
                return View("Message", ViewData["message"] = "Your registration details has been update successfully.");
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult AddProfileRegistration()
        {
            RegisterModel model = new RegisterModel();
            GetData data = new GetData();
            string Qry = "select count(parentregistrationid) as TotalCount  from web.registrationmaster where parentregistrationid=@RegistrationId group by parentregistrationid";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@RegistrationId", Sessions.getCurrentUser().RegistrationId);
            string TotalCount = data.SelectColumns(Cmd)[0];
            if (!string.IsNullOrEmpty(TotalCount))
            {
                if (Convert.ToInt32(TotalCount) >= (int)CountList.Type005)
                {
                    ViewData["message"] = " You Have Already Added 5 Child Profile in Your Profile.";
                    return View("message");
                }
            }
            model.RegistrationMaster = new RegistrationMaster();
            model.RegistrationMasterTemp = new RegistrationMasterTemp();
            string[] values = Utility.SelectColumnsValue("web.registrationmaster", "ApplicantGender,ApplicantName", "RegistrationId", Sessions.getCurrentUser().RegistrationId);
            model.RegistrationMaster.ApplicantGender = values[0];
            if (model.RegistrationMaster.ApplicantGender == Gender.M.ToString())
            {
                model.RegistrationMasterTemp.ApplicantFatherName = values[1];
            }
            else
            {
                model.RegistrationMasterTemp.ApplicantMotherName = values[1];
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult AddProfileRegistration(RegisterModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    string Qry = string.Empty;
                    GetData data = new GetData();
                    NpgsqlCommand Cmd = new NpgsqlCommand();
                    CMDInfoList CmdInfo = new CMDInfoList();
                    List<CMDInfoList> cmdList = new List<CMDInfoList>();

                    string AccessCode = Utility.GetRandomString(5, 1);
                    string SimplePassword = Utility.GetRandomString(8, 3);
                    string HashPassword = Utility.GenerateSHA512(SimplePassword).ToString().ToLower();

                    model.RegistrationMasterTemp.ApplicantPhoto = Utility.CompareFileCapturePhotoData(model.PhotoData, System.Web.HttpContext.Current.Request.Files["ApplicantPhoto"]);
                    if (string.IsNullOrEmpty(model.RegistrationMasterTemp.DocumentNo)) { model.RegistrationMasterTemp.DocumentNo = model.RegistrationMasterTemp.AadhaarNo; }

                    // Check duplicate mobile number
                    string DupMobileMessage = Utility.CheckDuplicateMobileNo(model.RegistrationMasterTemp.ApplicantMobileNo, (int)CountList.Type006);
                    if (!string.IsNullOrEmpty(DupMobileMessage))
                    {
                        ViewBag.DisplayMessage = DupMobileMessage;
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View("AddProfileRegistration", (RegisterModel)TempData[Constant._ModelStateParent]);
                    }

                    int result = Utility.CheckExistingChildRecord(model.RegistrationMasterTemp.DocumentNo.ToUpper(), model.RegistrationMasterTemp.ApplicantName.ToUpper(), model.RegistrationMasterTemp.MinorApplicantDOB.ToUpper(), model.RegistrationMasterTemp.ApplicantGender.ToUpper(), model.RegistrationMasterTemp.ApplicantFatherName.ToUpper(), model.DocId);

                    if (result == (int)CountList.Type000) { }
                    else if (result == (int)CountList.Type001)
                    {
                        model.RegistrationMaster = new RegistrationMaster();
                        string[] values = Utility.SelectColumnsValue("web.registrationmaster", "ApplicantGender,ApplicantName", "RegistrationId", Sessions.getCurrentUser().RegistrationId);
                        model.RegistrationMaster.ApplicantGender = values[0];

                        ViewBag.DisplayMessage = "The provided document no. already exist but provided deatils does not matched with our record.\\n Please enter the correct details.";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View("AddProfileRegistration", (RegisterModel)TempData[Constant._ModelStateParent]);
                    }
                    else if (result == (int)CountList.Type002)
                    {
                        model.RegistrationMaster = new RegistrationMaster();
                        string[] values = Utility.SelectColumnsValue("web.registrationmaster", "ApplicantGender,ApplicantName", "RegistrationId", Sessions.getCurrentUser().RegistrationId);
                        model.RegistrationMaster.ApplicantGender = values[0];

                        Qry = "select a.ParentRegistrationId,c.ApplicantName,d.documentname from web.RegistrationMaster a inner join registrationtodocumentmaster b on b.registrationid=a.registrationid inner Join web.RegistrationMaster c on c.RegistrationId=a.ParentRegistrationId inner join documentmaster d on d.documentid=c.documentid where b.documentno=@documentno and b.documentid=@documentid";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@documentno", Utility.GetByteFromDocumentNo(model.RegistrationMasterTemp.DocumentNo.ToUpper()));
                        Cmd.Parameters.AddWithValue("@documentid", model.DocId);
                        string[] value = data.SelectColumns(Cmd);

                        ViewBag.DisplayMessage = "The profile which is wants to add is already attached with profile (Registered with " + value[2] + " and RegistrationId: " + value[0] + ") of " + value[1] + ". \\n Please enter the correct details or contact to your concerned department.";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View("AddProfileRegistration", (RegisterModel)TempData[Constant._ModelStateParent]);
                    }
                    else
                    {
                        model.RegistrationMaster = new RegistrationMaster();
                        string[] values = Utility.SelectColumnsValue("web.registrationmaster", "ApplicantGender,ApplicantName", "RegistrationId", Sessions.getCurrentUser().RegistrationId);
                        model.RegistrationMaster.ApplicantGender = values[0];

                        string[] value = Utility.SelectColumnsValue("web.registrationmaster", "ApplicantFatherName,ApplicantMotherName", "RegistrationId", result.ToString());
                        model.RegistrationMaster.ApplicantFatherName = value[0];
                        model.RegistrationMaster.ApplicantMotherName = value[1];

                        if (model.RegistrationMaster.ApplicantGender == Gender.M.ToString())
                        {
                            if (model.RegistrationMaster.ApplicantFatherName.ToUpper().Trim() != model.RegistrationMasterTemp.ApplicantFatherName.ToUpper().Trim())
                            {
                                ViewData["message"] = "The Father Name is Not Matched With the Existing Registration.";
                                return View("message");
                            }
                        }
                        else if (model.RegistrationMaster.ApplicantGender == Gender.F.ToString())
                        {
                            if (model.RegistrationMaster.ApplicantMotherName.ToUpper().Trim() != model.RegistrationMasterTemp.ApplicantMotherName.ToUpper().Trim())
                            {
                                ViewData["message"] = "The Mother Name is Not Matched With the Existing Registration.";
                                return View("message");
                            }
                        }
                        else
                        {
                            RedirectToAction("BadRequest", "Error");
                        }


                        Qry = "update web.RegistrationMaster set ParentRegistrationId=@ParentRegistrationId,ApplicantRelationId=@ApplicantRelationId where RegistrationId=@RegistrationId";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ParentRegistrationId", Sessions.getCurrentUser().RegistrationId);
                        Cmd.Parameters.AddWithValue("@ApplicantRelationId", model.RegistrationMasterTemp.ApplicantRelationId);
                        //Cmd.Parameters.AddWithValue("@DocumentNo", model.RegistrationMasterTemp.DocumentNo.ToUpper());
                        Cmd.Parameters.AddWithValue("@RegistrationId", result);
                        data.UpdateData(Cmd);

                        return View("Message", ViewData["message"] = "Profile Attached Ssssuccessfully.");
                    }


                    //Check Locality Mapping
                    bool CheckMapping = Utility.CheckCorrectMapping(model.RegistrationMasterTemp.ApplicantLocalityId, model.RegistrationMasterTemp.ApplicantSubDivCode, model.RegistrationMasterTemp.ApplicantDistrictCode, null, null);
                    if (CheckMapping == false)
                    {
                        ViewBag.DisplayMessage = "The mapping of your locality does not mapped, \\n Kindly contact to conccerened department.";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View("AddProfileRegistration", (RegisterModel)TempData[Constant._ModelStateParent]);
                    }

                    if (model.DocId == ((int)DocumentId.AadhaarCard).ToString())
                    {
                        int DocStatusId = Utility.VerifyRegistrationDocument(model.RegistrationMasterTemp.ApplicantName, model.RegistrationMasterTemp.ApplicantGender.ToString(), model.RegistrationMasterTemp.MinorApplicantDOB, model.RegistrationMasterTemp.DocumentNo, (int)DocumentId.AadhaarCard);
                        if (DocStatusId != (int)WebServiceResponse.Verified)
                        {
                            model.RegistrationMaster = new RegistrationMaster();
                            string[] values = Utility.SelectColumnsValue("web.registrationmaster", "ApplicantGender,ApplicantName", "RegistrationId", Sessions.getCurrentUser().RegistrationId);
                            model.RegistrationMaster.ApplicantGender = values[0];

                            ViewBag.DisplayMessage = "The provided AADHAAR No. is not validated with entered details, Kindly enter the correct details. \\n To locate your nearest UIDAI center, go to 'Locate UIDAI Center' link on HOME Page.";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("AddProfileRegistration", (RegisterModel)TempData[Constant._ModelStateParent]);
                        }
                        model.RegistrationMasterTemp.documentstatusid = ((int)WebServiceResponse.Verified).ToString();
                    }
                    else
                    {
                        //set document status "pending for verification"
                        model.RegistrationMasterTemp.documentstatusid = ((int)WebServiceResponse.WebServiceNotAvailable).ToString();
                    }

                    CmdInfo = new CMDInfoList();
                    CmdInfo.Cmd = Utility.InsertPhotographdetails(CustomText.TRUE.ToString(), null, model.RegistrationMasterTemp.ApplicantPhoto);
                    CmdInfo.ParamenterIndex = null; CmdInfo.Returns = true;
                    cmdList.Add(CmdInfo);

                    Qry = "insert into web.RegistrationMaster(DocumentNo,DocumentId,ApplicantName,ApplicantGender,AadharApplicantFatherName,ApplicantMotherName,ApplicantFatherName,AadharApplicantDOB,ApplicantDOB,AadharApplicantAddress,ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,applicantstateid,applicantcountryid,ApplicantDistrictCode,ApplicantSubDivCode,AadharApplicantPinCode,ApplicantPinCode,ApplicantLocalityId,ApplicantMobileNo,ApplicantEmail,refphotoid,ApplicantPassword,ApplicantAccessCode,RegistrationDate,ApplicantIpAddress,LastActionPerformed,ApplicantRelationId,ParentRegistrationId,documentstatusid,RegistrationSourceId,ApplicantPermanentAddress,WhetherSameAddress,ActionPerformedBy) values(dbo.udf_general_encrypt(@DocumentNo),@DocumentId,@ApplicantName,@ApplicantGender,@AadharApplicantFatherName,@ApplicantMotherName,@ApplicantFatherName,@AadharApplicantDOB,@ApplicantDOB,@AadharApplicantAddress,@ApplicantHouseNumber,@ApplicantStreetNumber,@ApplicantSubLocality,@applicantstateid,@applicantcountryid,@ApplicantDistrictCode,@ApplicantSubDivCode,@AadharApplicantPinCode,@ApplicantPinCode,@ApplicantLocalityId,@ApplicantMobileNo,@ApplicantEmail,@Parameter0,@ApplicantPassword,@ApplicantAccessCode,now(),@ApplicantIpAddress,now(),@ApplicantRelationId,@ParentRegistrationId,@documentstatusid,@RegistrationSourceId,@ApplicantPermanentAddress,@WhetherSameAddress,@ParentRegistrationId); SELECT currval(pg_get_serial_sequence('web.registrationmaster','registrationid'))";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@DocumentNo", model.RegistrationMasterTemp.DocumentNo.ToUpper());
                    Cmd.Parameters.AddWithValue("@DocumentId", model.DocId);
                    Cmd.Parameters.AddWithValue("@ApplicantName", model.RegistrationMasterTemp.ApplicantName.ToUpper());
                    Cmd.Parameters.AddWithValue("@ApplicantGender", model.RegistrationMasterTemp.ApplicantGender.ToUpper());
                    Cmd.Parameters.AddWithValue("@AadharApplicantFatherName", model.RegistrationMasterTemp.AadharApplicantFatherName);
                    Cmd.Parameters.AddWithValue("@ApplicantFatherName", model.RegistrationMasterTemp.ApplicantFatherName.ToUpper());
                    Cmd.Parameters.AddWithValue("@ApplicantMotherName", model.RegistrationMasterTemp.ApplicantMotherName.ToUpper());
                    Cmd.Parameters.AddWithValue("@AadharApplicantDOB", Utility.GetDateYYYYMMDD(model.RegistrationMasterTemp.AadharMinorApplicantDOB, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@ApplicantDOB", Utility.GetDateYYYYMMDD(model.RegistrationMasterTemp.MinorApplicantDOB, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@AadharApplicantAddress", model.RegistrationMasterTemp.AadharApplicantAddress);
                    Cmd.Parameters.AddWithValue("@ApplicantHouseNumber", model.RegistrationMasterTemp.ApplicantHouseNumber);
                    Cmd.Parameters.AddWithValue("@ApplicantStreetNumber", model.RegistrationMasterTemp.ApplicantStreetNumber);
                    Cmd.Parameters.AddWithValue("@ApplicantSubLocality", model.RegistrationMasterTemp.ApplicantSubLocality);
                    Cmd.Parameters.AddWithValue("@applicantstateid", model.RegistrationMasterTemp.StateId);
                    Cmd.Parameters.AddWithValue("@applicantcountryid", model.RegistrationMasterTemp.CountryId);
                    Cmd.Parameters.AddWithValue("@ApplicantDistrictCode", model.RegistrationMasterTemp.ApplicantDistrictCode);
                    Cmd.Parameters.AddWithValue("@ApplicantSubDivCode", model.RegistrationMasterTemp.ApplicantSubDivCode);
                    Cmd.Parameters.AddWithValue("@AadharApplicantPinCode", model.RegistrationMasterTemp.AadharApplicantPinCode);
                    Cmd.Parameters.AddWithValue("@ApplicantPinCode", model.RegistrationMasterTemp.ApplicantPinCode);
                    Cmd.Parameters.AddWithValue("@ApplicantLocalityId", model.RegistrationMasterTemp.ApplicantLocalityId);
                    Cmd.Parameters.AddWithValue("@ApplicantMobileNo", model.RegistrationMasterTemp.ApplicantMobileNo);
                    Cmd.Parameters.AddWithValue("@ApplicantEmail", model.RegistrationMasterTemp.ApplicantEmail);
                    Cmd.Parameters.AddWithValue("@ApplicantRelationId", model.RegistrationMasterTemp.ApplicantRelationId);
                    Cmd.Parameters.AddWithValue("@ApplicantPassword", HashPassword);
                    Cmd.Parameters.AddWithValue("@ApplicantAccessCode", AccessCode);
                    Cmd.Parameters.AddWithValue("@ApplicantIpAddress", Utility.GetIP4Address());
                    Cmd.Parameters.AddWithValue("@WhetherPasswordChange", CustomText.FALSE.ToString());
                    Cmd.Parameters.AddWithValue("@ParentRegistrationId", Sessions.getCurrentUser().RegistrationId);
                    Cmd.Parameters.AddWithValue("@RegistrationSourceId", (int)ApplicationSource.Online);
                    Cmd.Parameters.AddWithValue("@documentstatusid", model.RegistrationMasterTemp.documentstatusid);
                    Cmd.Parameters.AddWithValue("@ApplicantPermanentAddress", model.RegistrationMasterTemp.ApplicantPermanentAddress);
                    Cmd.Parameters.AddWithValue("@WhetherSameAddress", model.RegistrationMasterTemp.WhetherSameAddress);
                    CmdInfo = new CMDInfoList();
                    CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = new int[] { 0 }; CmdInfo.Returns = true;
                    cmdList.Add(CmdInfo);

                    Qry = "insert into dbo.registrationtodocumentmaster (RegistrationID,DocumentId,DepartmentId,DocumentNo,DocumentStatusId,WhetherVerified,ConsentId,userid,ipaddress) values (@Parameter1,@DocumentId,@DepartmentId,dbo.udf_general_encrypt(@DocumentNo),@DocumentStatusId,@WhetherVerified,@ConsentId,@Parameter1,@ipaddress)";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@DocumentId", model.DocId);
                    Cmd.Parameters.AddWithValue("@ConsentId", model.consentcheckid);
                    Cmd.Parameters.AddWithValue("@DocumentNo", model.RegistrationMasterTemp.DocumentNo.ToUpper());
                    Cmd.Parameters.AddWithValue("@DepartmentId", Utility.GetDepartmentId(model.DocId));
                    Cmd.Parameters.AddWithValue("@DocumentStatusId", model.RegistrationMasterTemp.documentstatusid);
                    Cmd.Parameters.AddWithValue("@WhetherVerified", (model.RegistrationMasterTemp.documentstatusid == ((int)WebServiceResponse.Verified).ToString()) ? CustomText.TRUE.ToString() : CustomText.FALSE.ToString());
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    CmdInfo = new CMDInfoList();
                    CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = new int[] { 1 }; CmdInfo.Returns = false;
                    cmdList.Add(CmdInfo);

                    data.SaveTransactionalDataCustom(cmdList)[1].ToString();
                    return View("Message", ViewData["message"] = "New Profile has been created successfully.");
                }
                catch
                {
                    return RedirectToAction("Index", "Error");
                }
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("AddProfileRegistration", (RegisterModel)TempData[Constant._ModelStateParent]);
        }
        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult UpdateProfileOTP(int RegistrationId, int? ResendAttempt = 1)
        {
            try
            {
                GetData data = new GetData();
                RegisterModel model = (RegisterModel)TempData["RegisterModel"];
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string validupto = string.Empty, CurrDateTime = string.Empty;
                if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }

                model.RegistrationId = RegistrationId;
                model.ResendAttempt = Convert.ToInt32(ResendAttempt);

                string Qry = "select RegistrationId,ApplicantName, Case When ApplicantGender='M' then 'Male' When ApplicantGender='F' then 'Female' When ApplicantGender='T' then 'Transgender' end as ApplicantGender,Udf_general_decrypt(DocumentNo)as DocumentNo,ApplicantMobileNo,to_char(ApplicantDOB,'DD/MM/YYYY')as ApplicantDOB from web.RegistrationMaster where RegistrationId=@RegistrationId";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RegistrationId", model.RegistrationId);
                model.data = data.GetDataTable(Cmd);


                Qry = "select otpdetails,to_char(validupto,'yyyyMMddHH24MISS') as validupto,to_char(now(),'yyyyMMddHH24MISS') as CurrDateTime  from smsotpdetails where referenceno=@referenceno and referencetype=@referencetype order by otpid desc limit 1";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@referenceno", model.RegistrationId);
                Cmd.Parameters.AddWithValue("@referencetype", (int)ValueId.OTPSubmitOnlineApplication);
                DataTable dt = data.GetDataTable(Cmd);
                if (dt != null && dt.Rows.Count > 0)
                {
                    model.OTPGet = dt.Rows[0]["otpdetails"].ToString();
                    validupto = dt.Rows[0]["validupto"].ToString();
                    CurrDateTime = dt.Rows[0]["CurrDateTime"].ToString();
                    if (Convert.ToInt64(CurrDateTime) > Convert.ToInt64(validupto))
                    {
                        model.OTPGet = Utility.GetRandomString(5, 2);

                        Qry = "insert into dbo.smsotpdetails(otpdetails,createdate,validupto,referencetype,referenceno) values(@otpdetails,now(),now() + INTERVAL '10 min',@referencetype,@referenceno)";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@otpdetails", model.OTPGet);
                        Cmd.Parameters.AddWithValue("@referencetype", (int)ValueId.OTPSubmitOnlineApplication);
                        Cmd.Parameters.AddWithValue("@referenceno", model.RegistrationId);
                        cmdList.Add(Cmd);

                        Dictionary<string, string> smsDic = new Dictionary<string, string>();
                        smsDic.Add("ParamMobileNo", model.RegistrationMaster.ApplicantMobileNo);
                        smsDic.Add("ParamOTP", model.OTPGet);
                        cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS043, smsDic));

                        data.SaveData(cmdList);

                        ViewBag.DisplayMessage = "OTP Expried. New OTP For Modification of Application is send on Applicant Mobile No ";
                    }
                }
                else
                {
                    model.OTPGet = Utility.GetRandomString(5, 2);
                    Qry = "insert into dbo.smsotpdetails(otpdetails,createdate,validupto,referencetype,referenceno) values(@otpdetails,now(),now() + INTERVAL '10 min',@referencetype,@referenceno)";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@otpdetails", model.OTPGet);
                    Cmd.Parameters.AddWithValue("@referencetype", (int)ValueId.OTPSubmitOnlineApplication);
                    Cmd.Parameters.AddWithValue("@referenceno", model.RegistrationId);
                    cmdList.Add(Cmd);

                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamMobileNo", model.RegistrationMaster.ApplicantMobileNo);
                    smsDic.Add("ParamOTP", model.OTPGet);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS043, smsDic));
                    data.SaveData(cmdList);

                    ViewBag.DisplayMessage = "OTP For Submit Application is send on Applicant Mobile No";
                }
                TempData["RegisterModel"] = model;
                TempData.Keep("RegisterModel");
                return View(model);
            }
            catch
            {
                return RedirectToAction("InternalError", "Error");
            }
        }

        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ResendOTP(RegisterModel model)
        {
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            if (model.ResendAttempt == (int)CountList.Type000)
            {
                ViewData["message"] = "Session Timed out! Please retry later!"; return View("message");
            }

            model.OTPGet = Utility.GetRandomString(5, 2);

            string Qry = "select RegistrationId,ApplicantName, Case When ApplicantGender='M' then 'Male' When ApplicantGender='F' then 'Female' When ApplicantGender='T' then 'Transgender' end as ApplicantGender,Udf_general_decrypt(DocumentNo)as DocumentNo,ApplicantMobileNo,to_char(ApplicantDOB,'DD/MM/YYYY')as ApplicantDOB from web.RegistrationMaster where RegistrationId=@RegistrationId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@RegistrationId", model.RegistrationId);
            model.data = data.GetDataTable(Cmd);

            Qry = "insert into dbo.smsotpdetails(otpdetails,createdate,validupto,referencetype,referenceno) values(@otpdetails,now(),now() + INTERVAL '10 min',@referencetype,@referenceno)";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@otpdetails", model.OTPGet);
            Cmd.Parameters.AddWithValue("@referencetype", (int)ValueId.OTPSubmitOnlineApplication);
            Cmd.Parameters.AddWithValue("@referenceno", model.RegistrationId);
            cmdList.Add(Cmd);

            Dictionary<string, string> smsDic = new Dictionary<string, string>();
            smsDic.Add("ParamMobileNo", model.RegistrationMaster.ApplicantMobileNo);
            smsDic.Add("ParamOTP", model.OTPGet);
            cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS043, smsDic));
            data.SaveData(cmdList);

            model.ResendAttempt = model.ResendAttempt + 1;
            PreserveModelState(Constant._ActionMessage, "OTP Resend successfully", false, true);


            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "RegistrationId", "ResendAttempt" }, new ArrayList() { model.RegistrationId, model.ResendAttempt });
            return RedirectToAction("UpdateProfileOTP", "Account", new { q = QueryString });

        }
        #endregion

        #region Manage Citizen Profile
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult CheckProfile()
        {
            GetData data = new GetData();
            RegisterModel model = new RegisterModel();
            string Qry = "select RegistrationId,dbo.udf_general_decrypt(DocumentNo) as DocumentNo,ApplicantName,ParentRegistrationId from web.RegistrationMaster where RegistrationId=@RegistrationId or ParentRegistrationId=@RegistrationId;";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@RegistrationId", Sessions.getCurrentUser().RegistrationId);
            DataTable dt = new DataTable();
            dt = data.GetDataTable(Cmd);
            if (dt.Rows.Count == 1)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "eid" }, new ArrayList() { (int)CountList.Type000 });
                return RedirectToAction("MyDocuments", "Account", new { q = QueryString });
            }
            else
            {
                model.data = dt;
                return View(model);
            }
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [EncryptedActionParameter]
        public ActionResult CheckProfile(RegisterModel model)
        {
            string QueryString2 = Utility.CreateEncryptedQueyString(new ArrayList() { "eid" }, new ArrayList() { model.RegistrationId });
            return RedirectToAction("MyDocuments", "Account", new { q = QueryString2 });
        }
        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult MyDocuments(Int32 eid)
        {
            DocumentModel model = new DocumentModel();
            GetData data = new GetData();
            string Qry = string.Empty;
            NpgsqlCommand Cmd = new NpgsqlCommand();

            if (eid == 0)
            {
                Qry = "select RegistrationId,dbo.udf_general_decrypt(DocumentNo) as DocumentNo,ApplicantName,ParentRegistrationId from web.RegistrationMaster where RegistrationId=@RegistrationId or ParentRegistrationId=@RegistrationId;";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RegistrationId", Sessions.getCurrentUser().RegistrationId);
                DataTable dt = new DataTable();
                dt = data.GetDataTable(Cmd);
                if (dt.Rows.Count > 1)
                {
                    return RedirectToAction("CheckProfile", "Account");
                }

                Qry = "select AED.enclosureid,@ServerType as ServerType,RegistrationID,AED.documentid,DM.documentname,EDM.deptname,AED.departmentid,otherdepartment,dbo.udf_general_decrypt(documentno) as documentno,contenttype,documentdata,case whetherverified when TRUE then 'Yes' else 'No' end as whetherverified,case AED.whetheractive when TRUE then 'Yes' else 'No' end as whetheractive,to_char(documententrydate,'DD/MM/YYYY') as documententrydate,to_char(lastupdatedate,'DD/MM/YYYY') as lastupdatedate from dbo.applicantenclosuredetails AED inner join dbo.documentmaster DM on DM.documentid=AED.documentid inner join dbo.enclosuredepartmentmaster EDM on EDM.departmentid=AED.departmentid where RegistrationID=@RegistrationID order by DM.documentname";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RegistrationID", Sessions.getCurrentUser().RegistrationId);
                Cmd.Parameters.AddWithValue("@ServerType", DB.RS.ToString());
                model.data = data.GetDataTable(Cmd);
                model.ProfileId = Sessions.getCurrentUser().RegistrationId;
            }
            else
            {
                Qry = "select AED.enclosureid,@ServerType as ServerType,RegistrationID,AED.documentid,DM.documentname,EDM.deptname,AED.departmentid,otherdepartment,dbo.udf_general_decrypt(documentno) as documentno,contenttype,documentdata,case whetherverified when TRUE then 'Yes' else 'No' end as whetherverified,case AED.whetheractive when TRUE then 'Yes' else 'No' end as whetheractive,to_char(documententrydate,'DD/MM/YYYY') as documententrydate,to_char(lastupdatedate,'DD/MM/YYYY') as lastupdatedate from dbo.applicantenclosuredetails AED inner join dbo.documentmaster DM on DM.documentid=AED.documentid inner join dbo.enclosuredepartmentmaster EDM on EDM.departmentid=AED.departmentid where RegistrationID=@RegistrationID order by DM.documentname";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RegistrationID", eid.ToString());
                Cmd.Parameters.AddWithValue("@ServerType", DB.RS.ToString());
                model.data = data.GetDataTable(Cmd);
                model.ProfileId = eid.ToString();
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult MyDocuments(DocumentModel model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                byte[] fileData = null;
                string contentType = string.Empty;
                string LastInsertId = string.Empty;
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                HttpPostedFile file = System.Web.HttpContext.Current.Request.Files["ApplicantFile"];
                fileData = Utility.CompareFileCapturePhotoData(model.PhotoData, System.Web.HttpContext.Current.Request.Files["ApplicantFile"]);
                contentType = file.ContentType;

                string Qry = "select DocumentId from dbo.applicantenclosuredetails where DocumentId=@DocumentId and DocumentNo=@DocumentNo and RegistrationID=@RegistrationID and WhetherActive=@WhetherActive";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RegistrationID", model.ProfileId);
                Cmd.Parameters.AddWithValue("@DocumentId", model.DocumentId);
                Cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(model.DocumentNo.ToUpper()));
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                string CheckValue = data.SelectColumns(Cmd)[0];
                if (!string.IsNullOrEmpty(CheckValue)) { return View("Message", ViewData["message"] = "This Document has been already uploaded."); }

                bool rtnrsult = Utility.CheckDocumentMapping(Convert.ToInt32(model.DocumentId), Convert.ToInt32(model.DepartmentId));
                if (rtnrsult == false)
                {
                    ViewBag.DisplayMessage = "The current request contains some invalid input, please clear you browser cache and try again.";
                    PreserveModelState(Constant._ModelStateParent, null, true, false);
                    return View((DocumentModel)TempData[Constant._ModelStateParent]);
                }

                string Msg = Utility.GetWhetherStopApplication(null, DB.RS.ToString(), model.DocumentId, model.DepartmentId, string.IsNullOrEmpty(model.WhetherVerified) ? CustomText.FALSE.ToString() : model.WhetherVerified);
                if (!string.IsNullOrEmpty(Msg))
                {
                    ViewBag.DisplayMessage = Msg;
                    PreserveModelState(Constant._ModelStateParent, null, true, false);
                    return View((DocumentModel)TempData[Constant._ModelStateParent]);
                }

                string Response = string.Empty;
                LastInsertId = "@" + CustomText.LastInsertedId.ToString();

                if (TempData[KeyName._Key06] != null) { Response = TempData[KeyName._Key06].ToString(); }
                if (!string.IsNullOrEmpty(Response))
                {
                    string[] ArrResponse = Response.Split('|');
                    for (int i = 0; i < ArrResponse.Length; i++)
                    {
                        if (ArrResponse[i].ToString() == "NA")
                        {
                            ArrResponse[i] = null;
                        }
                    }

                    if (model.DocumentId == ArrResponse[16] && model.DocumentNo.ToLower() == ArrResponse[17].ToLower())
                    {
                        Qry = "INSERT INTO dbo.verificationdatamaster(DocumentNo,ReceivedTID,Name,DateOfIssue,IssuedBy,Address,DateOfValid,DOB,Gender,FatherName,MotherName,SpouseName,AadhaarNo,DocumentStatus,DeptLogId,DocumentId,DepartmentId,WhetherActive,RegistrationId,actionuserid,actionipaddress,actiondatetime)VALUES (dbo.udf_general_encrypt(@UniqueID), @RecvdTID,@Name, @IssuingDate, @IssuingAuthority, @Address, @ValidUpto, @DOB, @Gender, @FatherName, @MotherName,@SpouseName,dbo.udf_general_encrypt(@AadhaarNo),@DocumentStatus,@DeptLogId,@DocumentId,@DepartmentId,@WhetherActive,@RegistrationId,@actionuserid,@actionipaddress,now()); SELECT currval(pg_get_serial_sequence('verificationdatamaster','verificationdataid'))";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@UniqueID", string.IsNullOrEmpty(ArrResponse[1]) ? ArrResponse[17] : ArrResponse[1]);
                        Cmd.Parameters.AddWithValue("@RecvdTID", ArrResponse[2]);
                        Cmd.Parameters.AddWithValue("@Name", ArrResponse[3]);
                        Cmd.Parameters.AddWithValue("@FatherName", ArrResponse[4]);
                        Cmd.Parameters.AddWithValue("@MotherName", ArrResponse[5]);
                        Cmd.Parameters.AddWithValue("@SpouseName", ArrResponse[6]);
                        Cmd.Parameters.AddWithValue("@Gender", ArrResponse[7]);
                        Cmd.Parameters.AddWithValue("@DOB", Utility.GetDateYYYYMMDD(ArrResponse[8], '/', "0/1/2"));
                        Cmd.Parameters.AddWithValue("@Address", ArrResponse[9]);
                        Cmd.Parameters.AddWithValue("@AadhaarNo", ArrResponse[10]);
                        Cmd.Parameters.AddWithValue("@ValidUpto", Utility.GetDateYYYYMMDD(ArrResponse[11], '/', "0/1/2"));
                        Cmd.Parameters.AddWithValue("@IssuingDate", Utility.GetDateYYYYMMDD(ArrResponse[12], '/', "0/1/2"));
                        Cmd.Parameters.AddWithValue("@IssuingAuthority", ArrResponse[13]);
                        Cmd.Parameters.AddWithValue("@DocumentStatus", ArrResponse[14]);
                        Cmd.Parameters.AddWithValue("@DeptLogId", ArrResponse[15]);
                        Cmd.Parameters.AddWithValue("@DocumentId", model.DocumentId.ToString());
                        Cmd.Parameters.AddWithValue("@DepartmentId", model.DepartmentId.ToString());
                        Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@RegistrationID", model.ProfileId);
                        Cmd.Parameters.AddWithValue("@actionuserid", Sessions.getCurrentUser().RegistrationId);
                        Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                    else { LastInsertId = "NULL"; }
                    TempData[KeyName._Key06] = null;
                }
                else
                {
                    LastInsertId = "NULL";
                }

                Qry = "insert into dbo.applicantenclosuredetails (RegistrationID,DocumentId,DepartmentId,OtherDepartment,DocumentNo,ContentType,DocumentData,VerifyValueId,WhetherVerified,WhetherActive,DocumentEntryDate,VerificationDataId,ConsentId,userid,ipaddress,lastupdatedate) values (@RegistrationID,@DocumentId,@DepartmentId,@OtherDepartment,dbo.udf_general_encrypt(@DocumentNo),@ContentType,@DocumentData,@VerifyValueId,@WhetherVerified,@WhetherActive,now()," + LastInsertId + ",@ConsentId,@userid,@ipaddress,now())";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RegistrationID", model.ProfileId);
                Cmd.Parameters.AddWithValue("@EnclosureId", model.EnclosureId);
                Cmd.Parameters.AddWithValue("@DocumentId", (model.DocumentId == null) ? model.UpdateDocumentId : model.DocumentId);
                Cmd.Parameters.AddWithValue("@DocumentNo", model.DocumentNo);
                Cmd.Parameters.AddWithValue("@DepartmentId", model.DepartmentId);
                Cmd.Parameters.AddWithValue("@OtherDepartment", model.DeptName);
                Cmd.Parameters.AddWithValue("@DocumentData", fileData);
                Cmd.Parameters.AddWithValue("@ContentType", contentType);
                Cmd.Parameters.AddWithValue("@VerifyValueId", string.IsNullOrEmpty(model.VerifyValueId) ? ((int)WebServiceResponse.ExceptionOccurred).ToString() : model.VerifyValueId);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@ConsentId", model.consentcheckid);
                Cmd.Parameters.AddWithValue("@WhetherVerified", string.IsNullOrEmpty(model.WhetherVerified) ? CustomText.FALSE.ToString() : model.WhetherVerified);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getCurrentUser().RegistrationId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                if (LastInsertId.Equals("NULL")) { data.SaveData(cmdList); }
                else { data.SaveTransactionalData(cmdList); }
                return View("Message", ViewData["message"] = "Your document has been uploaded/updated successfully.");
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View((DocumentModel)TempData[Constant._ModelStateParent]);
        }
        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult UploadRegistrationDocument(Int32? RId)
        {
            GetData data = new GetData();
            NpgsqlCommand Cmd = new NpgsqlCommand();
            DocumentModel model = new DocumentModel();
            if (RId == null) { model.RegistrationId = Sessions.getCurrentUser().RegistrationId; } else { model.RegistrationId = RId.ToString(); }
            
            string Qry = "select @SelectedRegistrationId as SelectedRegistrationId,RegistrationId,dbo.udf_general_decrypt(DocumentNo) as DocumentNo,ApplicantName,ParentRegistrationId from web.RegistrationMaster where RegistrationId=@RegistrationId or ParentRegistrationId=@RegistrationId order by ApplicantName;";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@RegistrationId", Sessions.getCurrentUser().RegistrationId);
            Cmd.Parameters.AddWithValue("@SelectedRegistrationId", model.RegistrationId);
            model.data2 = data.GetDataTable(Cmd);

            Qry = "select RD.Rencid,RM.ApplicantName,DM.documentname,EDM.deptname,RD.registrationid,dbo.udf_general_decrypt(RD.documentno) as documentno,RD.documentstatusid,RD.documentid,case RD.whetherverified when TRUE then 'Yes' else 'No' end as whetherverified,case RD.whetheractive when TRUE then 'Yes' else 'No' end as whetheractive,to_char(RD.uploaddate,'DD/MM/YYYY') as uploaddate from dbo.registrationtodocumentmaster RD inner join dbo.documentmaster DM on DM.documentid=RD.documentid inner join dbo.enclosuredepartmentmaster EDM on EDM.departmentid=RD.departmentid inner join web.RegistrationMaster RM on RM.RegistrationId=RD.RegistrationId where RD.RegistrationID=@RegistrationID order by DM.documentname";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@RegistrationID", model.RegistrationId);
            model.data = data.GetDataTable(Cmd);

            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult UploadRegistrationDocument(DocumentModel model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                string Qry = "select DocumentId from dbo.registrationtodocumentmaster where DocumentId=@DocumentId and DocumentNo=@DocumentNo and WhetherActive=@WhetherActive";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@DocumentId", model.DocumentId);
                Cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(model.DocumentNo.ToUpper()));
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                string CheckValue = data.SelectColumns(Cmd)[0];
                if (!string.IsNullOrEmpty(CheckValue))
                {
                    ViewBag.DisplayMessage = "Document is already uploaded once!";
                    PreserveModelState(Constant._ModelStateParent, null, true, false);
                    return View((DocumentModel)TempData[Constant._ModelStateParent]);
                }

                string Response = string.Empty;
                if (TempData[KeyName._Key06] != null) { Response = TempData[KeyName._Key06].ToString(); }
                if (!string.IsNullOrEmpty(Response))
                {
                    string[] ArrResponse = Response.Split('|');
                    for (int i = 0; i < ArrResponse.Length; i++)
                    {
                        if (ArrResponse[i].ToString() == "NA")
                        {
                            ArrResponse[i] = null;
                        }
                    }

                    //changebyankur19122018
                    string ApplicantName = Utility.SelectColumnsValue("web.RegistrationMaster", "ApplicantName", "RegistrationId", model.RegistrationId)[0];
                    //if (model.DocumentId != ArrResponse[16] && model.DocumentNo.ToLower() != ArrResponse[17].ToLower())

                    string ResponseApplicantName = ArrResponse[3];
                    //int labelRemoveLenth = 13;

                    if (model.DocumentId == ((int)DocumentId.VoterID).ToString())
                    {
                        if (model.DocumentNo.Length > 10)
                        {
                            ResponseApplicantName = ArrResponse[3].Remove(0, 15);
                        }
                        else
                        {
                            ResponseApplicantName = ArrResponse[3].Remove(0, 13);
                        }
                    }
                    //if (model.DocumentId != ArrResponse[16] || model.DocumentNo.ToLower() != ArrResponse[17].ToLower() || ArrResponse[3].Remove(0, 13).ToUpper() != ApplicantName.ToUpper())
                    if (model.DocumentId != ArrResponse[16] || model.DocumentNo.ToLower() != ArrResponse[17].ToLower() || ResponseApplicantName.Trim().ToUpper() != ApplicantName.ToUpper())
                    {
                        ViewBag.DisplayMessage = "Data mismatch was found. Please retry after some time or login again.[E01]";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View((DocumentModel)TempData[Constant._ModelStateParent]);
                    }

                    TempData[KeyName._Key06] = null;
                }
                else
                {
                    if (!string.IsNullOrEmpty(model.VerifyValueId))
                    {
                        if (model.VerifyValueId != ((int)WebServiceResponse.AlreadyExist).ToString())
                        {
                            ViewBag.DisplayMessage = "Document is not verified from the department. Retry after some time.[E02]";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View((DocumentModel)TempData[Constant._ModelStateParent]);
                        }
                        //else
                        //{
                        //    ViewBag.DisplayMessage = "Document is already uploaded with another profile!";
                        //    PreserveModelState(Constant._ModelStateParent, null, true, false);
                        //    return View((DocumentModel)TempData[Constant._ModelStateParent]);
                        //}
                    }
                    else
                    {
                        ViewBag.DisplayMessage = "Document is not verified from the department. Retry after some time.[E02]";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View((DocumentModel)TempData[Constant._ModelStateParent]);
                    }
                }

                Qry = "insert into dbo.registrationtodocumentmaster (RegistrationID,DocumentId,DepartmentId,DocumentNo,DocumentStatusId,WhetherVerified,ConsentId,userid,ipaddress) values (@RegistrationID,@DocumentId,@DepartmentId,dbo.udf_general_encrypt(@DocumentNo),@DocumentStatusId,@WhetherVerified,@ConsentId,@userid,@ipaddress)";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RegistrationID", model.RegistrationId);
                Cmd.Parameters.AddWithValue("@DocumentId", model.DocumentId);
                Cmd.Parameters.AddWithValue("@DocumentNo", model.DocumentNo);
                Cmd.Parameters.AddWithValue("@DepartmentId", model.DepartmentId);
                Cmd.Parameters.AddWithValue("@ConsentId", Utility.GetConsent(model.DocumentId, DB.RS.ToString())[1]);
                Cmd.Parameters.AddWithValue("@DocumentStatusId", string.IsNullOrEmpty(model.VerifyValueId) ? ((int)WebServiceResponse.ExceptionOccurred).ToString() : model.VerifyValueId);
                Cmd.Parameters.AddWithValue("@WhetherVerified", string.IsNullOrEmpty(model.WhetherVerified) ? CustomText.FALSE.ToString() : model.WhetherVerified);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getCurrentUser().RegistrationId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                data.SaveData(cmdList);
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "RId" }, new ArrayList() { model.ProfileId });
                return RedirectToAction("UploadRegistrationDocument", "Account", new { q = QueryString });
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View((DocumentModel)TempData[Constant._ModelStateParent]);
        }
        #endregion

        #region Forget/Reset/Change Password Module for Department & Citizen
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult LogOff()
        {
            string Source = string.Empty;
            if (Sessions.getEmployeeUser() != null) { Source = ((int)CountList.Type002).ToString(); }
            if (Sessions.getCurrentUser() != null) { Source = ((int)CountList.Type001).ToString(); }
            FormsAuthentication.SignOut();

            if (Sessions.getCurrentUser() != null)
            {
                Utility.InsertCitizenLoginTrail(Sessions.getCurrentUser().RegistrationId, Dml.Update.ToString(), null);

                Session.Clear();
                Session.Abandon();
                Session.RemoveAll();

                if (Request.Cookies[ParamCookies.AspNetSessionId] != null)
                {
                    Response.Cookies[ParamCookies.AspNetSessionId].Value = string.Empty;
                    Response.Cookies[ParamCookies.AspNetSessionId].Expires = DateTime.Now.AddMonths(-20);
                }
                if (Request.Cookies[ParamCookies.AspAuthToken] != null)
                {
                    Response.Cookies[ParamCookies.AspAuthToken].Value = string.Empty;
                    Response.Cookies[ParamCookies.AspAuthToken].Expires = DateTime.Now.AddMonths(-20);
                }
                if (Request.Cookies[ParamCookies.RequestToken] != null)
                {
                    Response.Cookies[ParamCookies.RequestToken].Value = string.Empty;
                    Response.Cookies[ParamCookies.RequestToken].Expires = DateTime.Now.AddMonths(-20);
                }

                if (Request.Cookies[ParamCookies.SessionToken] != null)
                {
                    Response.Cookies[ParamCookies.SessionToken].Value = string.Empty;
                    Response.Cookies[ParamCookies.SessionToken].Expires = DateTime.Now.AddMonths(-20);
                }

                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "Type", "Source" }, new ArrayList() { ((int)CountList.Type002).ToString(), Source });
                return RedirectToAction("MessagePage", "Public", new { q = QueryString });
            }
            else
            {

                if (Sessions.getEmployeeUser() != null)
                {
                    if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().UserId))
                    {
                        Utility.UpdateLogOutAttempt(Sessions.getEmployeeUser().UserId);
                        Utility.InsertDepartmentLoginTrail(Sessions.getEmployeeUser().UserId, Dml.Update.ToString(), null);
                    }
                }

                Session.Clear();
                Session.Abandon();
                Session.RemoveAll();

                if (Request.Cookies[ParamCookies.AspNetSessionId] != null)
                {
                    Response.Cookies[ParamCookies.AspNetSessionId].Value = string.Empty;
                    Response.Cookies[ParamCookies.AspNetSessionId].Expires = DateTime.Now.AddMonths(-20);
                }
                if (Request.Cookies[ParamCookies.AspAuthToken] != null)
                {
                    Response.Cookies[ParamCookies.AspAuthToken].Value = string.Empty;
                    Response.Cookies[ParamCookies.AspAuthToken].Expires = DateTime.Now.AddMonths(-20);
                }
                if (Request.Cookies[ParamCookies.RequestToken] != null)
                {
                    Response.Cookies[ParamCookies.RequestToken].Value = string.Empty;
                    Response.Cookies[ParamCookies.RequestToken].Expires = DateTime.Now.AddMonths(-20);
                }

                if (Request.Cookies[ParamCookies.SessionToken] != null)
                {
                    Response.Cookies[ParamCookies.SessionToken].Value = string.Empty;
                    Response.Cookies[ParamCookies.SessionToken].Expires = DateTime.Now.AddMonths(-20);
                }

                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "Type", "Source" }, new ArrayList() { ((int)CountList.Type002).ToString(), Source });
                return RedirectToAction("MessagePage", "Public", new { q = QueryString });
            }
        }
        [AllowAnonymous]
        [EncryptedActionParameter]
        public ActionResult ChangePasswordAtFirstLogin(int Type)
        {
            if (TempData[KeyName._Key06] == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }

            LocalPasswordModel model = new LocalPasswordModel();
            model.UserName = TempData[KeyName._Key08].ToString();
            model.LoginPasswordType = Type.ToString();
            if (string.IsNullOrEmpty(System.Web.HttpContext.Current.Session["salt"].ToString()))
            {
                Sessions.setSalt(Utility.GetRandomString(50));
            }
            PreserveModelState(KeyName._Key06, null, true, false);
            PreserveModelState(KeyName._Key07, null, true, false);
            PreserveModelState(KeyName._Key08, null, true, false);
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ChangePasswordAtFirstLogin(LocalPasswordModel model)
        {
            if (ModelState.IsValid)
            {
                string UserId = TempData[KeyName._Key06].ToString();
                string UserType = TempData[KeyName._Key07].ToString();

                //check whether old and new passwrod is matched?
                string Salt = System.Web.HttpContext.Current.Session["salt"].ToString().Trim();
                string Pass = Utility.GenerateSHA512(model.NewPassword + Salt).ToString().ToLower();
                if (Pass == model.OldPassword)
                {
                    ModelState.AddModelError("NewPassword", "Old and new passwords cannot be the same");
                    PreserveModelState(KeyName._Key06, null, true, false);
                    PreserveModelState(KeyName._Key07, null, true, false);
                    PreserveModelState(KeyName._Key08, null, true, false);

                    return View("ChangePasswordAtFirstLogin", (LocalPasswordModel)TempData[Constant._ModelStateParent]);
                }

                if (UserType == DB.LS.ToString())
                {
                    if (model.LoginPasswordType == ((int)CountList.Type000).ToString())
                    {
                        UserMaster employeeUser = Authorize.ValidateDeprtmentUser(UserId, model.OldPassword);
                        if (employeeUser != null)
                        {
                            GetData data = new GetData();
                            string Qry = "update dbo.UserMaster set Password=@Password,WhetherPasswordChange=@WhetherPasswordChange,lastpassowrdchange=now(),actionuserid=@actionuserid,actionipaddress=@actionipaddress,actiondatetime=now() where UserId=@UserId";
                            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@Password", model.NewPassword);
                            Cmd.Parameters.AddWithValue("@WhetherPasswordChange", CustomText.TRUE.ToString());
                            Cmd.Parameters.AddWithValue("@UserId", employeeUser.UserId);
                            Cmd.Parameters.AddWithValue("@actionuserid", employeeUser.UserId);
                            Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                            data.UpdateData(Cmd);

                            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "Type", "Source" }, new ArrayList() { ((int)CountList.Type003).ToString(), ((int)CountList.Type002).ToString() });
                            return RedirectToAction("MessagePage", "Public", new { q = QueryString });
                        }
                        else
                        {
                            ModelState.AddModelError("", "The user name or password provided is incorrect.");
                        }
                    }
                    else
                    {
                        UserMaster employeeUser = Authorize.ValidateDeprtmentUser(UserId, model.OldPassword, null, true);
                        if (employeeUser != null)
                        {
                            GetData data = new GetData();
                            string Qry = "update dbo.UserMaster set TransactionPassword=@TransactionPassword,whethertransactionpwdchange=@whethertransactionpwdchange,lasttransactionpwdchange=now(),actionuserid=@actionuserid,actionipaddress=@actionipaddress,actiondatetime=now() where UserId=@UserId";
                            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@TransactionPassword", model.NewPassword);
                            Cmd.Parameters.AddWithValue("@whethertransactionpwdchange", CustomText.TRUE.ToString());
                            Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@actionuserid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                            data.UpdateData(Cmd);

                            ViewData["message"] = "Transaction Password Changed Successfully.";
                            return View("message");

                        }
                        else
                        {
                            ModelState.AddModelError("", "The user name or Transaction password provided is incorrect.");
                        }
                    }
                }
                else if (UserType == DB.RS.ToString())
                {
                    RegistrationMaster currentUser = Authorize.ValidateCitizenUser(UserId, model.OldPassword);
                    if (currentUser != null)
                    {
                        GetData data = new GetData();
                        string Qry = "update web.RegistrationMaster set ApplicantPassword=@ApplicantPassword,maxloginattempt=@maxloginattempt,WhetherPasswordChange=@WhetherPasswordChange,ApplicantIpAddress=@ApplicantIpAddress,LastActionPerformed=now(),lastpasswordchange=now(),ActionPerformedBy=@ActionPerformedBy where RegistrationId=@RegistrationId";
                        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicantPassword", model.NewPassword);
                        Cmd.Parameters.AddWithValue("@maxloginattempt", (int)CustomValue.No);
                        Cmd.Parameters.AddWithValue("@WhetherPasswordChange", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@ApplicantIpAddress", Utility.GetIP4Address());
                        Cmd.Parameters.AddWithValue("@RegistrationId", currentUser.RegistrationID);
                        Cmd.Parameters.AddWithValue("@ActionPerformedBy", currentUser.RegistrationID);
                        data.UpdateData(Cmd);

                        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "Type", "Source" }, new ArrayList() { ((int)CountList.Type003).ToString(), ((int)CountList.Type001).ToString() });
                        return RedirectToAction("MessagePage", "Public", new { q = QueryString });
                    }
                    else
                    {
                        ModelState.AddModelError("", "The old password provided is incorrect.");
                    }
                }
                else
                {
                    return RedirectToAction("UnauthorizedRequest", "Error");
                }
            }
            if (string.IsNullOrEmpty(System.Web.HttpContext.Current.Session["salt"].ToString()))
            {
                Sessions.setSalt(Utility.GetRandomString(50));
            }
            PreserveModelState(KeyName._Key06, null, true, false);
            PreserveModelState(KeyName._Key07, null, true, false);
            PreserveModelState(KeyName._Key08, null, true, false);
            return View("ChangePasswordAtFirstLogin", (LocalPasswordModel)TempData[Constant._ModelStateParent]);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ChangePassword()
        {
            Sessions.setSalt(Utility.GetRandomString(50));
            return View();
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ChangePasswordPost(LocalPasswordModel model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                //check whether a new and old password is matched?
                string Salt = System.Web.HttpContext.Current.Session["salt"].ToString().Trim();
                string Pass = Utility.GenerateSHA512(model.NewPassword + Salt).ToString().ToLower();
                if (Pass == model.OldPassword)
                {
                    ModelState.AddModelError("NewPassword", "Old and new passwords cannot be the same");
                    return View("ChangePassword", model);
                }

                if (Sessions.getCurrentUser() != null)
                {
                    RegistrationMaster currentUser = Authorize.ValidateCitizenUser(Sessions.getCurrentUser().RegistrationId, model.OldPassword);
                    if (currentUser != null)
                    {
                        string Qry = "update web.RegistrationMaster set maxloginattempt=@maxloginattempt,ApplicantPassword=@ApplicantPassword,LastActionPerformed=now(),ApplicantIpAddress=@ApplicantIpAddress,ActionPerformedBy=@RegistrationId where RegistrationId=@RegistrationId";
                        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicantPassword", model.NewPassword);
                        Cmd.Parameters.AddWithValue("@maxloginattempt", (int)CustomValue.No);
                        Cmd.Parameters.AddWithValue("@ApplicantIpAddress", Utility.GetIP4Address());
                        Cmd.Parameters.AddWithValue("@RegistrationId", Sessions.getCurrentUser().RegistrationId);
                        cmdList.Add(Cmd);

                        Dictionary<string, string> smsDic = new Dictionary<string, string>();
                        smsDic.Add("ParamMobileNo", currentUser.ApplicantMobileNo);
                        cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS011, smsDic));

                        data.SaveData(cmdList);

                        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "Type", "Source" }, new ArrayList() { ((int)CountList.Type003).ToString(), ((int)CountList.Type000).ToString() });
                        return RedirectToAction("MessagePage", "Public", new { q = QueryString });
                    }
                    else
                    {
                        ModelState.AddModelError("", "The old password provided is incorrect.");
                    }
                }
                else if (Sessions.getEmployeeUser() != null)
                {
                    UserMaster employeeUser = Authorize.ValidateDeprtmentUser(Sessions.getEmployeeUser().UserId, model.OldPassword);
                    if (employeeUser != null)
                    {
                        string Qry = "update dbo.UserMaster set Password=@Password,actionuserid=@actionuserid,actionipaddress=@actionipaddress,actiondatetime=now() where UserId=@UserId";
                        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@Password", model.NewPassword);
                        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@actionuserid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        Dictionary<string, string> smsDic = new Dictionary<string, string>();
                        smsDic.Add("ParamMobileNo", employeeUser.ContactNo);
                        cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS011, smsDic));

                        data.SaveData(cmdList);

                        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "Type", "Source" }, new ArrayList() { ((int)CountList.Type003).ToString(), ((int)CountList.Type000).ToString() });
                        return RedirectToAction("MessagePage", "Public", new { q = QueryString });
                    }
                    else
                    {
                        ModelState.AddModelError("", "The user name or password provided is incorrect.");
                    }
                }
                else { ModelState.AddModelError("", "Operational Error, Please try again later."); }
            }
            Sessions.setSalt(Utility.GetRandomString(50));
            return View("ChangePassword", model);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult ForgetPasswordDepartment()
        {
            ForgetPasswordModel model = new ForgetPasswordModel();
            model.UserType = DB.LS.ToString();
            Sessions.setSalt(Utility.GetRandomString(50));
            return View(model);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ForgetPasswordDepartment(ForgetPasswordModel model)
        {
            if (ModelState.IsValid)
            {
                if (Utility.IsCapchaValid(TempData[KeyName._Key05].ToString(), model.Captcha) == false)
                {
                    ModelState.AddModelError("Captcha", "The characters you entered didn't match the word verification. Please try again.");
                    return View(model);
                }

                GetData data = new GetData();
                string CurrPass = Utility.GenerateSHA512(model.CurrentPassword).ToString().ToLower();

                string Qry = "select UserId,contactno from dbo.usermaster where UserId=@UserId and contactno=@contactno and DateofBirth=@DateofBirth";
                if (!string.IsNullOrEmpty(model.CurrentPassword)) { Qry += " and Password = @Password"; }
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@UserId", model.UserId);
                Cmd.Parameters.AddWithValue("@contactno", model.ApplicantMobileNo);
                Cmd.Parameters.AddWithValue("@DateofBirth", Utility.GetDateYYYYMMDD(model.DOB, '/', "0/1/2"));
                if (!string.IsNullOrEmpty(model.CurrentPassword)) { Cmd.Parameters.AddWithValue("@Password", CurrPass); }
                UserMaster objUser = UserMaster.Get<UserMaster>(new UserMaster(), Cmd);
                if (objUser.UserId != null && objUser.UserId.Length > 0)
                {
                    string Otp = Utility.GetRandomString(5, 3);

                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamOTP", Otp);
                    smsDic.Add("ParamMobileNo", model.ApplicantMobileNo);
                    data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS009, smsDic));

                    TempData[KeyName._Key03] = Otp + "|" + objUser.UserId + "|" + model.UserType;
                    return View("ResetForgetPassword");
                }
                else
                {
                    ModelState.AddModelError("", "The provide information does not matched with our recrods, kindly check and try again.");
                }
            }

            Sessions.setSalt(Utility.GetRandomString(50));
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);

        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Get)]
        [ValidateAntiForgeryToken]
        public ActionResult ResetForgetPassword(int? Pid)
        {
            Sessions.setSalt(Utility.GetRandomString(50));
            ResetForgetPasswordModel model = new ResetForgetPasswordModel();
            model.PassTypeId = Pid.ToString();
            return View(model);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        public ActionResult ResetForgetPasswordPost(ResetForgetPasswordModel model)
        {
            if (ModelState.IsValid)
            {
                string info = TempData[KeyName._Key03].ToString();
                string[] arr = info.Split('|');
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                if (arr[0].ToString() == model.OTP.ToString())
                {
                    GetData data = new GetData();
                    if (arr[2].ToString() == DB.RS.ToString())
                    {
                        string RegistrationId = Utility.SelectColumnsValue("web.RegistrationMaster", "registrationid", "applicantuserid", arr[1].ToString())[0];

                        string Qry = "update web.RegistrationMaster set maxloginattempt=@maxloginattempt,ApplicantPassword=@ApplicantPassword,whethermd5change=@whethermd5change,whetherpasswordchange=@whetherpasswordchange,LastActionPerformed=now(),ApplicantIpAddress=@ApplicantIpAddress,ActionPerformedBy=@ActionPerformedBy where applicantuserid=@applicantuserid";
                        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicantPassword", model.NewPassword);
                        Cmd.Parameters.AddWithValue("@maxloginattempt", (int)CustomValue.No);
                        Cmd.Parameters.AddWithValue("@whethermd5change", CustomText.True.ToString());
                        Cmd.Parameters.AddWithValue("@whetherpasswordchange", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@ApplicantIpAddress", Utility.GetIP4Address());
                        Cmd.Parameters.AddWithValue("@applicantuserid", arr[1].ToString());
                        Cmd.Parameters.AddWithValue("@ActionPerformedBy", RegistrationId);
                        data.UpdateData(Cmd);

                        ViewData["message"] = "Password has been Reset successfully.";
                        return View("message");
                    }
                    else if (arr[2].ToString() == DB.LS.ToString())
                    {
                        if (model.PassTypeId == ((int)CountList.Type000).ToString())
                        {
                            string Qry = "update dbo.usermaster set TransactionPassword=@TransactionPassword,actiondatetime=now(),actionipaddress=@actionipaddress where UserId=@UserId";
                            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@TransactionPassword", model.NewPassword);
                            Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                            Cmd.Parameters.AddWithValue("@UserId", arr[1].ToString());
                            cmdList.Add(Cmd);
                        }
                        else
                        {
                            string Qry = "update dbo.usermaster set Password=@Password,whetherpasswordchange=@whetherpasswordchange,actiondatetime=now(),actionipaddress=@actionipaddress where UserId=@UserId";
                            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@Password", model.NewPassword);
                            Cmd.Parameters.AddWithValue("@whetherpasswordchange", CustomText.TRUE.ToString());
                            Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                            Cmd.Parameters.AddWithValue("@UserId", arr[1].ToString());
                            cmdList.Add(Cmd);

                            string IsUserIdExist = Utility.SelectColumnsValue("useronlinedetails", "userid", "userid", arr[1].ToString())[0];
                            if (string.IsNullOrEmpty(IsUserIdExist)) { Utility.InsertUserId(arr[1].ToString()); }

                            Qry = "update useronlinedetails set maxloginattempt=@maxloginattempt ,whetherlogout=@whetherlogout where userid=@userid;";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@userid", arr[1].ToString());
                            Cmd.Parameters.AddWithValue("@maxloginattempt", (int)CountList.Type000);
                            Cmd.Parameters.AddWithValue("@whetherlogout", CustomText.True.ToString());
                            cmdList.Add(Cmd);
                        }

                        data.SaveData(cmdList);
                        ViewData["message"] = "Password has been Reset successfully.";
                        return View("message");
                    }
                    else
                    {
                        return RedirectToAction("BadRequest", "Error");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "The OTP provided is incorrect.");
                    PreserveModelState(KeyName._Key03, info, true, false);
                    return View("ResetForgetPassword");
                }
            }
            Sessions.setSalt(Utility.GetRandomString(50));
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View("ResetForgetPassword");
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult ChangeUserId()
        {
            LocalUserIdModel model = new LocalUserIdModel();
            return View();
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult ChangeUserId(LocalUserIdModel model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                if (Sessions.getCurrentUser() != null)
                {
                    string UserId = Utility.SelectColumnsValue("web.RegistrationMaster", "ApplicantUserId", "RegistrationId", Sessions.getCurrentUser().RegistrationId)[0];
                    if (UserId != null)
                    {
                        string Qry = "select ApplicantUserId from  web.RegistrationMaster where lower(ApplicantUserId)=@ApplicantUserId";
                        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicantUserId", model.NewUserId.ToLower());
                        DataTable dt = data.GetDataTable(Cmd);
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            ViewBag.DisplayMessage = "UserId has been Already Exist.";
                        }
                        else
                        {
                            Qry = "update web.RegistrationMaster set ApplicantUserId=@ApplicantUserId,Applicantipaddress=@Applicantipaddress,LastactionPerformed=now(),ActionPerformedBy=@RegistrationId where RegistrationId=@RegistrationId";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicantUserId", model.NewUserId);
                            Cmd.Parameters.AddWithValue("@RegistrationId", Sessions.getCurrentUser().RegistrationId);
                            Cmd.Parameters.AddWithValue("@Applicantipaddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);

                            data.SaveData(cmdList);
                            ViewBag.DisplayMessage = "UserId has been changed successfully.";
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", "The old UserId provided is incorrect.");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Operational Error, Please try again later.");
                }
            }
            return View(model);
        }
        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult ResetPassword(int Pid)
        {
            ResetForgetPasswordModel model = new ResetForgetPasswordModel();
            model.PassTypeId = Pid.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult ResetPassword(ResetForgetPasswordModel model)
        {
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

            string SimplePassword = Utility.GetRandomString(8, 3);
            string HashPassword = Utility.GenerateSHA512(SimplePassword).ToString().ToLower();

            string Qry = "select UserId,ContactNo from dbo.usermaster where userid=@userid";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and districtcode=@districtcode"; }
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@userid", model.UserName);
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { cmd.Parameters.AddWithValue("@districtcode", Sessions.getEmployeeUser().DistrictCode); }
            string WhetheruseridExist = data.SelectColumns(cmd)[0];
            string UserContactNo = data.SelectColumns(cmd)[1];
            if (string.IsNullOrEmpty(WhetheruseridExist))
            {
                ViewBag.DisplayMessage = "UserID Provided is not Exist";
                return View("ResetPassword");
            }

            if (model.PassTypeId == ((int)CountList.Type000).ToString())
            {
                Qry = "Update dbo.usermaster set password=@password,whetherpasswordchange=@whetherpasswordchange,actionuserid=@actionuserid,actionipaddress=@actionipaddress,actiondatetime=now() where userid=@userid";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@userid", model.UserName);
                cmd.Parameters.AddWithValue("@password", HashPassword);
                cmd.Parameters.AddWithValue("@whetherpasswordchange", CustomText.False.ToString());
                cmd.Parameters.AddWithValue("@actionuserid", Sessions.getEmployeeUser().UserId);
                cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                cmdList.Add(cmd);

                string IsUserIdExist = Utility.SelectColumnsValue("useronlinedetails", "userid", "userid", model.UserName)[0];
                if (string.IsNullOrEmpty(IsUserIdExist)) { Utility.InsertUserId(model.UserName); }

                Qry = "update useronlinedetails set maxloginattempt=@maxloginattempt ,whetherlogout=@whetherlogout where userid=@userid;";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@userid", model.UserName);
                cmd.Parameters.AddWithValue("@maxloginattempt", (int)CountList.Type000);
                cmd.Parameters.AddWithValue("@whetherlogout", CustomText.True.ToString());
                cmdList.Add(cmd);
            }
            else
            {
                Qry = "Update dbo.usermaster set TransactionPassword=@TransactionPassword,actionuserid=@actionuserid,actionipaddress=@actionipaddress,actiondatetime=now() where userid=@userid";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@userid", model.UserName);
                cmd.Parameters.AddWithValue("@TransactionPassword", HashPassword);
                cmd.Parameters.AddWithValue("@actionuserid", Sessions.getEmployeeUser().UserId);
                cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                cmdList.Add(cmd);
            }

            Dictionary<string, string> smsDic = new Dictionary<string, string>();
            smsDic.Add("ParamMobileNo", UserContactNo);
            smsDic.Add("ParamPassword", SimplePassword);
            cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS010, smsDic));

            data.SaveData(cmdList);

            ViewBag.DisplayMessage = "The Password has been reset successfully for UserId [" + model.UserName + "] And new password is " + SimplePassword + ".\\n\\n Also password has been sent on registered Mobile No.";
            return View("ResetPassword", model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult ResetCitizenPassword()
        {
            ResetForgetPasswordModel model = new ResetForgetPasswordModel();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult ResetCitizenPassword(ResetForgetPasswordModel model, FormCollection frm)
        {
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            string SimplePassword = Utility.GetRandomString(8, 3);
            string HashPassword = Utility.GenerateSHA512(SimplePassword).ToString().ToLower();

            string Qry = "select ApplicantUserId,ApplicantMobileNo,ApplicantEmail from web.RegistrationMaster where ApplicantUserId=@ApplicantUserId";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ApplicantUserId", model.RegistrationMaster.ApplicantUserID);
            string[] values = data.SelectColumns(cmd);
            string WhetheruseridExist = values[0];
            string UserContactNo = values[1];
            string ApplicantEmail = values[2];

            if (string.IsNullOrEmpty(WhetheruseridExist))
            {
                ViewBag.DisplayMessage = "User-ID Provided is not Exist";
                return View("ResetCitizenPassword");
            }

            Qry = "Update web.RegistrationMaster set applicantpassword=@applicantpassword,maxloginattempt=@maxloginattempt,whetherpasswordchange=@whetherpasswordchange,whethermd5change=@whethermd5change,lastactionperformed=now(),Applicantipaddress=@Applicantipaddress,ActionPerformedBy=@ActionPerformedBy where ApplicantUserId=@ApplicantUserId";
            cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ApplicantUserId", model.RegistrationMaster.ApplicantUserID);
            cmd.Parameters.AddWithValue("@applicantpassword", HashPassword);
            cmd.Parameters.AddWithValue("@maxloginattempt", (int)CustomValue.No);
            cmd.Parameters.AddWithValue("@whethermd5change", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@whetherpasswordchange", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@ActionPerformedBy", Sessions.getEmployeeUser().UserId);
            cmd.Parameters.AddWithValue("@Applicantipaddress", Utility.GetIP4Address());
            cmdList.Add(cmd);

            if (model.WhetherAllowSms == true)
            {
                Dictionary<string, string> smsDic = new Dictionary<string, string>();
                smsDic.Add("ParamMobileNo", UserContactNo);
                smsDic.Add("ParamPassword", SimplePassword);
                cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS010, smsDic));

                if (!string.IsNullOrEmpty(ApplicantEmail))
                {
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS010).ToString());
                    EmailDic.Add("ParamEmailId", ApplicantEmail);
                    EmailDic.Add("ParamPassword", SimplePassword);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                }
            }
            data.SaveData(cmdList);

            ViewBag.DisplayMessage = "The Password has been reset successfully for UserId [" + model.RegistrationMaster.ApplicantUserID + "] And new password is " + SimplePassword + ".";
            return View("ResetCitizenPassword", model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult GetChildProfileDetails()
        {
            RegisterModel model = new RegisterModel();
            GetData data = new GetData();
            string Qry = "select RM.parentrelationid,RM.registrationid,RM.Parentregistrationid,RM.ApplicantName,to_char(RM.applicantdob,'DD/MM/YYYY') as applicantdob,to_char(RM.registrationdate,'DD/MM/YYYY') as registrationdate,RL.relationname,DM.documentname,dbo.udf_general_decrypt(RM.DocumentNo) as DocumentNo from web.RegistrationMaster RM inner join documentmaster DM on DM.documentid=RM.documentId left outer join relationmaster RL on RL.relationid=RM.applicantrelationId where ParentRegistrationId=@RegistrationId order by RM.ApplicantName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@RegistrationId", Sessions.getCurrentUser().RegistrationId);
            model.data = data.GetDataTable(Cmd);
            Qry = "select RM.parentrelationid,RM.registrationid,RM.Parentregistrationid,RM.ApplicantName,to_char(RM.applicantdob,'DD/MM/YYYY') as applicantdob,to_char(RM.registrationdate,'DD/MM/YYYY') as registrationdate,RL.relationname,DM.documentname,dbo.udf_general_decrypt(RM.DocumentNo) as DocumentNo from web.RegistrationMaster RM inner join documentmaster DM on DM.documentid=RM.documentId left outer join relationmaster RL on RL.relationid=RM.applicantrelationId where parentrelationid=@RegistrationId order by RM.ApplicantName";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@RegistrationId", Sessions.getCurrentUser().RegistrationId);
            model.data.Merge(data.GetDataTable(Cmd));
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult GetChildProfilePassword(Int32 RId, Int32 PId)
        {
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            string SimplePassword = Utility.GetRandomString(8, 3);
            string HashPassword = Utility.GenerateSHA512(SimplePassword).ToString().ToLower();

            Int32 checkAge = Convert.ToInt32(Utility.SelectColumnsValue("web.RegistrationMaster", "(to_char(now(),'YYYYMMDD')::date-to_char(applicantdob,'YYYYMMDD')::date)/ 365  as Age", "RegistrationId", RId.ToString())[0]);
            if (checkAge >= 18)
            {
                string Qry = "Update web.RegistrationMaster set applicantpassword=@applicantpassword,maxloginattempt=@maxloginattempt,whetherpasswordchange=@whetherpasswordchange,Applicantipaddress=@Applicantipaddress,lastactionperformed=now(),ActionPerformedBy=@ActionPerformedBy where RegistrationId=@RegistrationId";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@RegistrationId", RId.ToString());
                cmd.Parameters.AddWithValue("@applicantpassword", HashPassword);
                cmd.Parameters.AddWithValue("@maxloginattempt", (int)CustomValue.No);
                cmd.Parameters.AddWithValue("@whetherpasswordchange", CustomText.False.ToString());
                cmd.Parameters.AddWithValue("@ActionPerformedBy", Sessions.getCurrentUser().RegistrationId);
                cmd.Parameters.AddWithValue("@Applicantipaddress", Utility.GetIP4Address());
                cmdList.Add(cmd);

                Qry = "select RegistrationId,ApplicantMobileNo,ApplicantEmail from web.RegistrationMaster where RegistrationId=@RegistrationId";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@RegistrationId", PId.ToString());
                string[] values = data.SelectColumns(cmd);
                string WhetheruseridExist = values[0];
                string UserContactNo = values[1];
                string ApplicantEmail = values[2];

                Dictionary<string, string> smsDic = new Dictionary<string, string>();
                smsDic.Add("ParamMobileNo", UserContactNo);
                smsDic.Add("ParamRegistrationId", RId.ToString());
                smsDic.Add("ParamPassword", SimplePassword);
                cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS001, smsDic));

                if (!string.IsNullOrEmpty(ApplicantEmail))
                {
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS001).ToString());
                    EmailDic.Add("ParamEmailId", ApplicantEmail);
                    EmailDic.Add("ParamRegistrationId", RId.ToString());
                    EmailDic.Add("ParamPassword", SimplePassword);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                }

                data.SaveData(cmdList);

                PreserveModelState(Constant._ActionMessage, "The Password of the selected profile has been sent at registered mobile number.", false, true);
                return RedirectToAction("GetChildProfileDetails");
            }
            PreserveModelState(Constant._ActionMessage, "The Child is still a minor, therefore password cannot be generated.", false, true);
            return RedirectToAction("GetChildProfileDetails");
        }
        #endregion

        #region Temp Process For Change MD5 Password to SHA512
        [AllowAnonymous]
        public ActionResult ChangeLoginPassword()
        {
            if (TempData[KeyName._Key06] == null) { return RedirectToAction("UnauthorizedRequest", "Error"); }

            LocalPasswordModel model = new LocalPasswordModel();
            model.UserName = TempData[KeyName._Key06].ToString();
            Sessions.setSalt(Utility.GetRandomString(50));
            PreserveModelState(KeyName._Key06, null, true, false);
            PreserveModelState(KeyName._Key07, null, true, false);
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AllowAnonymous]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ChangeLoginPassword(LocalPasswordModel model)
        {
            if (ModelState.IsValid)
            {
                string UserId = TempData[KeyName._Key06].ToString();
                string UserType = TempData[KeyName._Key07].ToString();

                //check whether old and new passwrod is matched?
                string Salt = System.Web.HttpContext.Current.Session["salt"].ToString().Trim();
                string Pass = Utility.GenerateSHA512(model.NewPassword + Salt);
                if (Pass == model.OldPassword)
                {
                    ModelState.AddModelError("NewPassword", "Old and new passwords cannot be the same");
                    PreserveModelState(KeyName._Key06, null, true, false);
                    PreserveModelState(KeyName._Key07, null, true, false);
                    return View("ChangeLoginPassword", (LocalPasswordModel)TempData[Constant._ModelStateParent]);
                }

                if (UserType == DB.LS.ToString())
                {
                    UserMaster employeeUser = Authorize.ValidateDeprtmentUser(UserId, model.OldPassword, true);
                    if (employeeUser != null)
                    {
                        GetData data = new GetData();

                        string Qry = "update dbo.UserMaster set Password=@Password,WhetherPasswordChange=@WhetherPasswordChange,lastpassowrdchange=now(),actionuserid=@actionuserid,actionipaddress=@actionipaddress,actiondatetime=now() where UserId=@UserId";
                        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@Password", model.NewPassword);
                        Cmd.Parameters.AddWithValue("@WhetherPasswordChange", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@UserId", employeeUser.UserId);
                        Cmd.Parameters.AddWithValue("@actionuserid", employeeUser.UserId);
                        Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                        data.UpdateData(Cmd);

                        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "Type", "Source" }, new ArrayList() { ((int)CountList.Type003).ToString(), ((int)CountList.Type002).ToString() });
                        return RedirectToAction("MessagePage", "Public", new { q = QueryString });
                    }
                    else
                    {
                        ModelState.AddModelError("", "The user name or password provided is incorrect.");
                        PreserveModelState(KeyName._Key06, null, true, false);
                        PreserveModelState(KeyName._Key07, null, true, false);
                        return View("ChangeLoginPassword", (LocalPasswordModel)TempData[Constant._ModelStateParent]);
                    }
                }
                else if (UserType == DB.RS.ToString())
                {
                    RegistrationMaster currentUser = Authorize.ValidateCitizenUser(UserId, model.OldPassword, true);
                    if (currentUser != null)
                    {
                        GetData data = new GetData();
                        string Qry = "update web.RegistrationMaster set ApplicantPassword=@ApplicantPassword,whethermd5change=@whethermd5change,maxloginattempt=@maxloginattempt,WhetherPasswordChange=@WhetherPasswordChange,ApplicantIpAddress=@ApplicantIpAddress,LastActionPerformed=now(),lastpasswordchange=now(),ActionPerformedBy=@ActionPerformedBy where RegistrationId=@RegistrationId";
                        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicantPassword", model.NewPassword);
                        Cmd.Parameters.AddWithValue("@maxloginattempt", (int)CustomValue.No);
                        Cmd.Parameters.AddWithValue("@WhetherPasswordChange", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@whethermd5change", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@ApplicantIpAddress", Utility.GetIP4Address());
                        Cmd.Parameters.AddWithValue("@RegistrationId", currentUser.RegistrationID);
                        Cmd.Parameters.AddWithValue("@ActionPerformedBy", currentUser.RegistrationID);
                        data.UpdateData(Cmd);

                        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "Type", "Source" }, new ArrayList() { ((int)CountList.Type003).ToString(), ((int)CountList.Type001).ToString() });
                        return RedirectToAction("MessagePage", "Public", new { q = QueryString });
                    }
                    else
                    {
                        ModelState.AddModelError("", "The old password provided is incorrect.");
                    }
                }
                else
                {
                    return RedirectToAction("UnauthorizedRequest", "Error");
                }
            }
            Sessions.setSalt(Utility.GetRandomString(50));
            PreserveModelState(KeyName._Key06, null, true, false);
            PreserveModelState(KeyName._Key07, null, true, false);
            return View("ChangeLoginPassword", (LocalPasswordModel)TempData[Constant._ModelStateParent]);
        }
        #endregion

        #region global method current contoller
        //method for preserve nodel state
        public void PreserveModelState(string Key, object obj, bool IsKeep, bool IsRemove)
        {
            if (IsRemove == true) { TempData.Remove(Key); }
            if (obj != null) { TempData[Key] = obj; }
            if (IsKeep == true) { TempData.Keep(Key); }
        }
        #endregion global method current contoller

        #region Helpers

        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                if (Sessions.getEmployeeUser() != null)
                {
                    return RedirectToAction("DepartmentIndex", "Home");
                }
                else
                {
                    return RedirectToAction("CitizenIndex", "Home");
                }
            }
        }

        #endregion

    }
}
