﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.DataService;
using Edistrict.Models;
using System.Collections;
using System.Data;
using Edistrict.Models.Entities;
using Edistrict.Models.CustomClass;
using System.Text;
using System.IO;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Web.Security;
using System.Net;
using Newtonsoft.Json;


namespace Edistrict.Controllers
{
    [Authorize(Roles = "107,112,118,119,104,127")]
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class AdminController : Controller
    {
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult UserDetails()
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult UserDetails(AdminModels model)
        {
            GetData data = new GetData();
            StringBuilder Qry = new StringBuilder("select UM.Uid,UM.userid,UM.username,PM.pname,DM.DistrictName,UM.designation,to_char(UM.createdate,'DD/MM/YYYY') as createdate,UM.signingtypeid,UM.AuthenticationTypeId,UM.WhetherActive,SMVD.ValueName as authenticationtype,SMVDD.ValueName as signingtype from dbo.usermaster UM inner join dbo.permissionmaster PM on PM.pcode=UM.permission left outer join DistrictMaster DM on DM.DistrictCode=UM.DistrictCode left outer join usertosubdivmaster SM on SM.uid=UM.uid left outer join SelectMasterValueDetails SMVD on SMVD.ValueId=UM.authenticationtypeid left outer join SelectMasterValueDetails SMVDD on SMVDD.ValueId=UM.signingtypeid  where UM.deptcode=@deptcode");
            if (!string.IsNullOrEmpty(model.UserMaster.Permission)) { Qry.Append(" and Permission=@Permission"); }
            if ((!string.IsNullOrEmpty(model.UserMaster.DistCode)) || (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode))) { Qry.Append(" and UM.districtcode=@districtcode"); }
            if (!string.IsNullOrEmpty(model.UserMaster.SubDivisionCode)) { Qry.Append(" and subdivcode=@subdivcode"); }
            Qry.Append(" order by username");
            NpgsqlCommand cmd = new NpgsqlCommand(Qry.ToString());
            cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { cmd.Parameters.AddWithValue("@districtcode", Sessions.getEmployeeUser().DistrictCode); }
            else { cmd.Parameters.AddWithValue("@districtcode", model.UserMaster.DistCode); }
            cmd.Parameters.AddWithValue("@Permission", model.UserMaster.Permission);
            cmd.Parameters.AddWithValue("@subdivcode", model.UserMaster.SubDivisionCode);
            model.dataS = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult ViewUserDetails(string UserId)
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            string Qry = "select UM.userid, UM.username, PM.pname as permission, DM.districtname, UM.designation,UM.dateofbirth, UM.contactno, UM.permanentaddress, UM.presentaddress, UM.dateofjoining,to_char(UM.createdate,'DD/MM/YYYY') as createdate, UM.actionipaddress, to_char(UM.actiondatetime,'DD/MM/YYYY') as lastupdatedate, UM.whetheractive, UM.whetherpasswordchange, UM.deptcode,SD.SubDivDescription FROM usermaster UM inner join permissionmaster PM on PM.pcode=UM.permission left outer join districtmaster DM on DM.districtcode=UM.districtcode left outer join dbo.usertosubdivmaster UTSD on UTSD.uid=UM.uid left outer join dbo.SubDivMaster SD on SD.SUbDivCode=UTSD.SubDivCode where UM.userid=@userid";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@userid", UserId);
            model.dataS = data.GetDataTable(cmd);
            model.SubDivCode = string.Empty;
            if (model.dataS.Rows.Count > 0)
            {
                model.SubDivCode = model.dataS.Rows[0]["SubDivDescription"].ToString();
                if (model.dataS.Rows.Count > 1)
                {
                    for (int i = 1; i < model.dataS.Rows.Count; i++)
                    {
                        model.SubDivCode = model.SubDivCode + "," + model.dataS.Rows[i]["SubDivDescription"].ToString();
                    }
                }
            }
            return View(model);

        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult UserEntry(int? flag = 0, int? schoolid = 0)
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            model.flag = flag.ToString();
            model.Schoolid = schoolid.ToString();
            model.UserMaster = new UserMaster();
            if (model.flag == ((int)Permission.P120).ToString())
            {
                string[] PermissionName = Utility.SelectColumnsValue("PermissionMaster", "pname,pcode", "pcode", ((int)Permission.P120).ToString());
                model.PermissionName = PermissionName[0];
                model.UserMaster.Permission = PermissionName[1];
            }

            model.UserMaster.DeptCode = Sessions.getEmployeeUser().DeptCode;
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult UserEntry(AdminModels model, FormCollection frm)
        {
            string Qry = string.Empty;
            GetData data = new GetData();
            DataTable dt = new DataTable();
            NpgsqlCommand cmd = new NpgsqlCommand();

            if (ModelState.IsValid)
            {
                if (!string.IsNullOrEmpty(model.UserMaster.UserName))
                {
                    Qry = "Select servicecode,servicename,('chkbox' || cast(Servicecode as varchar)) as ServiceControlId from dbo.servicemaster where WhetherActive=@WhetherActive and DeptCode=@ParamDeptCode";
                    if (model.ServiceCode != null) { Qry += " and servicecode=@ServiceCode"; }
                    Qry += " order by servicename";
                    cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                    cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                    model.dataS = data.GetDataTable(cmd);

                    if (!string.IsNullOrEmpty(model.UserMaster.Permission))
                    {
                        Qry = "select WhetherDistRequired,WhetherSubdivRequired from DeptToPermissionMaster DTPM  inner join PermissionMaster PM on PM.Pcode::smallint=DTPM.Pcode where DTPM.Pcode=@Pcode and DeptCode=@ParamDeptCode";
                        cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                        cmd.Parameters.AddWithValue("@Pcode", model.UserMaster.Permission);
                        dt = data.GetDataTable(cmd);
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            model.UserMaster.WhetherDistRequired = dt.Rows[0]["WhetherDistRequired"].ToString();
                            model.UserMaster.WhetherSubdivRequired = dt.Rows[0]["WhetherSubdivRequired"].ToString();
                        }
                    }

                    List<NpgsqlCommand> cmdList1 = new List<NpgsqlCommand>();
                    ArrayList Values = new ArrayList();
                    ArrayList Values2 = new ArrayList();
                    data = new GetData();
                    Qry = "select UserId from dbo.usermaster where userid=@userid";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@userid", model.UserMaster.UserId);
                    string WhetheruseridExist = data.SelectColumns(Cmd)[0];
                    if (!string.IsNullOrEmpty(WhetheruseridExist))
                    {
                        ViewData["message"] = "UserID already Exist";
                        return View("message");
                    }

                    HttpPostedFile appImage = System.Web.HttpContext.Current.Request.Files["ApplicantPhoto"];
                    byte[] imageByte = Utility.HttpFilePhotoData(System.Web.HttpContext.Current.Request.Files["ApplicantPhoto"]);
                    if (!Utility.IsImage(appImage))
                    {
                        ViewBag.DisplayMessage = "Invalid/Wrong image file does not allowed";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View((AdminModels)TempData[Constant._ModelStateParent]);
                    }
                    model.UserPhoto = Utility.CompareFileCapturePhotoData(model.PhotoData, imageByte);


                    Qry = "select WhetherSubdivRequired,Maxuserallowed,WhetherentryAllowed from DeptToPermissionMaster where Pcode=@Permission and DeptCode=@ParamDeptCode ";
                    Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    Cmd.Parameters.AddWithValue("@Permission", model.UserMaster.Permission);
                    model.dataSC = data.GetDataTable(Cmd);

                    Qry = "select count(UM.UserId) as UserCreated from UserMaster UM ";
                    if ((Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.DC) && (Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.MONT) && (Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.P113) && (Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.P114) && (Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.P115) && (Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.ADMN)) { Qry += " inner join UserToSubdivMaster UTSM on UTSM.UId=UM.UId "; }
                    Qry += " where Permission=@Permission and DeptCode=@ParamDeptCode and DistrictCode=@DistrictCode and UM.Whetheractive=@WhetherActive ";
                    if ((Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.DC) && (Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.MONT) && (Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.P113) && (Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.P114) && (Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.P115) && (Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.ADMN)) { Qry += " and UTSM.Subdivcode=@SubDivCode "; }
                    Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    Cmd.Parameters.AddWithValue("@Permission", model.UserMaster.Permission);
                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@DistrictCode", model.UserMaster.DistrictCode);
                    if ((Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.DC) && (Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.MONT) && (Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.P113) && (Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.P114) && (Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.P115) && (Convert.ToInt16(model.UserMaster.Permission) != (int)Permission.ADMN)) { Cmd.Parameters.AddWithValue("@SubDivCode", model.UserMaster.SubDivCode); }
                    DataTable Dt = data.GetDataTable(Cmd);

                    if (model.dataSC != null && Dt != null)
                    {
                        if (model.dataSC.Rows.Count > 0 && Dt.Rows.Count > 0)
                        {
                            if (model.dataSC.Rows[0]["WhetherentryAllowed"].ToString().ToUpper() == CustomText.FALSE.ToString())
                            {
                                ViewData["message"] = "Not Allowed To Create the User";
                                return View("message");
                            }
                            if (Convert.ToInt32(Dt.Rows[0]["UserCreated"].ToString()) >= Convert.ToInt32(model.dataSC.Rows[0]["Maxuserallowed"].ToString()))
                            {
                                ViewData["message"] = "Maximum User Already Created. For New User Creation Please De-activate old User";
                                return View("message");
                            }
                        }
                        else
                        {
                            ViewData["message"] = "Not Created,Contact Administration";
                            return View("message");
                        }
                    }
                    else
                    {
                        ViewData["message"] = "Not Created,Contact Administration";
                        return View("message");
                    }

                    // check aadhaar no of user if user select eKyc or eSign
                    if (Convert.ToInt32(model.UserMaster.AuthenticationTypeId) == (int)ValueId.AutheKYC || Convert.ToInt32(model.UserMaster.SigningTypeId) == (int)ValueId.SignEsign)
                    {
                        if (string.IsNullOrEmpty(model.UserMaster.AadhaarNo))
                        {
                            ViewData["message"] = "AADHAAR No. is Required";
                            return View("message");
                        }
                        Qry = "select UserId from dbo.UserMaster where UserAadhaarNo=@UserAadhaarNo and Permission=@Permission and WhetherActive=@WhetherActive ";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@UserAadhaarNo", Utility.GetByteFromDocumentNo(model.UserMaster.AadhaarNo.ToUpper()));
                        Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@Permission", model.UserMaster.Permission);
                        string WhetherAadhaarExist = data.SelectColumns(Cmd)[0];
                        if (!string.IsNullOrEmpty(WhetherAadhaarExist))
                        {
                            ViewData["message"] = "The provided AADHAAR No. is already mapped with another UserId , Kindly enter the correct details.";
                            return View("message");
                        }

                        int DocStatusId = Utility.VerifyRegistrationDocument(model.UserMaster.UserName, model.UserMaster.Gender.ToString(), model.UserMaster.DateOfBirth, model.UserMaster.AadhaarNo, (int)DocumentId.AadhaarCard);
                        if (DocStatusId != (int)WebServiceResponse.Verified)
                        {
                            ViewData["message"] = "The provided AADHAAR No. is not validated with entered details, Kindly enter the correct details. \\n To locate your nearest UIDAI center, go to 'Locate UIDAI Center' link on HOME Page.";
                            return View("message");
                        }
                    }

                    Qry = "Select servicecode,servicename,('chkbox' || cast(Servicecode as varchar)) as ServiceControlId from dbo.servicemaster where WhetherActive=@WhetherActive and DeptCode=@ParamDeptCode";
                    if (model.ServiceCode != null) { Qry += " and servicecode=@ServiceCode"; }
                    Qry += " order by servicename";
                    cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                    cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                    DataTable dta = data.GetDataTable(cmd);
                    for (int i = 0; i < dta.Rows.Count; i++)
                    {
                        if (frm[dta.Rows[i]["ServiceControlId"].ToString()] != null)
                        {
                            Values.Add(frm[dta.Rows[i]["ServiceControlId"].ToString()]);
                        }
                        if (Values == null)
                        {
                            return View(model);
                        }
                    }


                    string SimplePassword = Utility.GetRandomString(8, 3);
                    string WhetherCon = string.Empty, WhetherConParm = string.Empty;
                    string TransactionSimplePassword = Utility.GetRandomString(8, 3);
                    string HashPassword = Utility.GenerateSHA512(SimplePassword).ToString().ToLower();
                    string TransactionHashPwd = Utility.GenerateSHA512(TransactionSimplePassword).ToString().ToLower();
                    string UserIpAddress = Convert.ToInt32(model.UserMaster.UserIpSeg1) + "." + Convert.ToInt32(model.UserMaster.UserIpSeg2) + "." + Convert.ToInt32(model.UserMaster.UserIpSeg3) + "." + Convert.ToInt32(model.UserMaster.UserIpSeg4);

                    string AuthorizationId = ((int)CountList.Type000).ToString();
                    if (Convert.ToInt32(Sessions.getEmployeeUser().DeptCode) == (int)Department.Dept009)
                    {
                        if (model.ServiceCode == ((int)ServiceList.HigherEducationSKGS).ToString())
                        {
                            AuthorizationId = model.HeBankBranchMaster.HeBranchCode;
                        }
                        else if (model.ServiceCode == ((int)ServiceList.HeFinancialAssistance).ToString())
                        {
                            if (model.UserMaster.Permission == ((int)Permission.SDMG).ToString())
                            {
                                AuthorizationId = model.HeUniversityMaster.UniversityId;
                            }
                            else
                            {
                                AuthorizationId = model.HeInstitutionMaster.InstituitonId;
                            }

                        }
                        else if (model.Schoolid != ((int)CountList.Type000).ToString())
                        {
                            AuthorizationId = model.Schoolid;
                        }
                    }
                    else if (Convert.ToInt32(Sessions.getEmployeeUser().DeptCode) == (int)Department.Dept010)
                    {
                        if (model.UserMaster.Permission == ((int)Permission.SDMG).ToString())
                        {
                            if (!string.IsNullOrEmpty(model.ZoneId)) { AuthorizationId = model.ZoneId; }
                            else { AuthorizationId = model.ApplicationDetailsPrematsSC.DepartmentId; }
                        }
                        else if (model.Schoolid != ((int)CountList.Type000).ToString())
                        {
                            AuthorizationId = model.Schoolid;
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(model.UserMaster.AuthorizationId))
                        {
                            if (Convert.ToInt32(model.UserMaster.AuthorizationId) != (int)ValueId.DefaultGeneralType)
                            {
                                AuthorizationId = model.UserMaster.AuthorizationId;
                            }
                        }
                    }

                    //string AuthorizationId = "0";
                    //if (model.ServiceCode == ((int)ServiceList.HigherEducationSKGS).ToString())
                    //{
                    //    AuthorizationId = model.HeBankBranchMaster.HeBranchCode;
                    //}
                    //else if (model.ServiceCode == ((int)ServiceList.HeFinancialAssistance).ToString())
                    //{
                    //    if (model.UserMaster.Permission == ((int)Permission.SDMG).ToString())
                    //    {
                    //        AuthorizationId = model.HeUniversityMaster.UniversityId;
                    //    }
                    //    else
                    //    {
                    //        AuthorizationId = model.HeInstitutionMaster.InstituitonId;
                    //    }

                    //}
                    //else if (model.Schoolid != ((int)CountList.Type000).ToString())
                    //{
                    //    AuthorizationId = model.Schoolid;
                    //}
                    //if (Convert.ToInt32(Sessions.getEmployeeUser().DeptCode) == (int)Department.Dept010)
                    //{
                    //    if (model.UserMaster.Permission == ((int)Permission.SDMG).ToString())
                    //    {
                    //        if (!string.IsNullOrEmpty(model.ZoneId)) { AuthorizationId = model.ZoneId; }
                    //        else { AuthorizationId = model.ApplicationDetailsPrematsSC.DepartmentId; }
                    //    }
                    //}

                    if (string.IsNullOrEmpty(model.UserMaster.WhetherPoliceVerDone)) { model.UserMaster.WhetherPoliceVerDone = CustomText.FALSE.ToString(); }

                    Qry = "insert into dbo.usermaster(UserId,UserName,password,transactionpassword,districtcode,permission,designation,contactno,emailid,dateofbirth,permanentaddress,presentaddress,dateofjoining,UserIpAddress,Userdatefrom,userdateto,usertimefrom,usertimeto,deptcode,whetherpasswordchange,Gender,SigningTypeId,authenticationtypeid,UserAadhaarNo,authorizationid,actionuserid,actionipaddress,actiondatetime,whetherdetailupdate,whetherdetailapprove,WhetherPoliceVerDone) values(@UserId,@UserName,@password,@transactionpassword,@districtcode,@permission,@designation,@contactno,@emailid,@dateofbirth,@permanentaddress,@presentaddress,@dateofjoining,@UserIpAddress,@Userdatefrom,@UserDateTo,@UserTimeFrom,@UserTimeTo,@deptcode,@whetherpasswordchange,@Gender,@SigningTypeId,@authenticationtypeid,dbo.udf_general_encrypt(@UserAadhaarNo),@authorizationid,@actionuserid,@actionipaddress,now(),@whetherdetailupdate,@whetherdetailapprove,@WhetherPoliceVerDone); SELECT currval(pg_get_serial_sequence('dbo.usermaster','uid'))";
                    Cmd = new NpgsqlCommand(Qry);
                    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                    Cmd.Parameters.AddWithValue("@userid", model.UserMaster.UserId);
                    Cmd.Parameters.AddWithValue("@UserName", model.UserMaster.UserName);
                    Cmd.Parameters.AddWithValue("@password", HashPassword);
                    Cmd.Parameters.AddWithValue("@transactionpassword", TransactionHashPwd);
                    Cmd.Parameters.AddWithValue("@districtcode", model.UserMaster.DistrictCode);
                    Cmd.Parameters.AddWithValue("@permission", model.UserMaster.Permission);
                    Cmd.Parameters.AddWithValue("@designation", model.UserMaster.Designation);
                    Cmd.Parameters.AddWithValue("@contactno", model.UserMaster.ContactNo);
                    Cmd.Parameters.AddWithValue("@emailid", model.UserMaster.EmailId);
                    Cmd.Parameters.AddWithValue("@dateofbirth", Utility.GetDateYYYYMMDD(model.UserMaster.DateOfBirth, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@permanentaddress", model.UserMaster.PermanentAddress);
                    Cmd.Parameters.AddWithValue("@presentaddress", model.UserMaster.PresentAddress);
                    Cmd.Parameters.AddWithValue("@dateofjoining", Utility.GetDateYYYYMMDD(model.UserMaster.DateOfJoining, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@UserIpAddress", UserIpAddress);
                    Cmd.Parameters.AddWithValue("@Userdatefrom", Utility.GetDateYYYYMMDD(model.UserMaster.DateFrom, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@UserDateTo", Utility.GetDateYYYYMMDD(model.UserMaster.DateTo, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@UserTimeFrom", model.UserMaster.TimeFrom);
                    Cmd.Parameters.AddWithValue("@UserTimeTo", model.UserMaster.TimeTo);
                    Cmd.Parameters.AddWithValue("@Gender", model.UserMaster.Gender);
                    Cmd.Parameters.AddWithValue("@authenticationtypeid", model.UserMaster.AuthenticationTypeId);
                    Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                    Cmd.Parameters.AddWithValue("@SigningTypeId", model.UserMaster.SigningTypeId);
                    Cmd.Parameters.AddWithValue("@AuthenticationTypeId", model.UserMaster.AuthenticationTypeId);
                    Cmd.Parameters.AddWithValue("@whetherpasswordchange", CustomText.FALSE.ToString());
                    Cmd.Parameters.AddWithValue("@UserAadhaarNo", model.UserMaster.AadhaarNo);
                    Cmd.Parameters.AddWithValue("@authorizationid", AuthorizationId);
                    Cmd.Parameters.AddWithValue("@whetherdetailupdate", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@whetherdetailapprove", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@WhetherPoliceVerDone", model.UserMaster.WhetherPoliceVerDone);
                    Cmd.Parameters.AddWithValue("@actionuserid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    if (Sessions.getEmployeeUser().DeptCode != ((int)Department.Dept015).ToString())
                    {
                        for (int i = 0; i < Values.Count; i++)
                        {
                            Qry = "insert into dbo.usertoservicemaster(uid,servicecode,userid,ipaddress,actiondatetime) values(@" + CustomText.LastInsertedId.ToString() + ",@servicecode,@userid,@ipaddress,now()) ";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@servicecode", (Values[i]).ToString());
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);
                        }
                    }
                    if (model.dataSC.Rows[0]["WhetherSubdivRequired"].ToString().ToUpper() == CustomText.TRUE.ToString())
                    {
                        Qry = "insert into dbo.usertosubdivmaster(uid,subdivcode,userid,ipaddress,actiondatetime) values(@" + CustomText.LastInsertedId.ToString() + ",@subdivcode,@userid,@ipaddress,now()) ";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@subdivcode", model.UserMaster.SubDivCode);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }

                    Qry = "delete from useronlinedetails where userid=@UserId; insert into dbo.useronlinedetails(UserId) values(@UserId);";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@UserId", model.UserMaster.UserId);
                    cmdList.Add(Cmd);

                    //process for attach a scanned document
                    HttpPostedFile file = System.Web.HttpContext.Current.Request.Files["DocumentData"];
                    byte[] fileData = Utility.CompareFileCapturePhotoData(null, file);
                    string ContentType = file.ContentType;
                    if (fileData == null)
                    {
                        ViewBag.DisplayMessage = "Upload Document is Required";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View((AdminModels)TempData[Constant._ModelStateParent]);
                    }
                    if (file.ContentLength > (int)LengthList.EncContent)
                    {
                        ViewBag.DisplayMessage = "Document has invalid size. (Max Limit: 100KB)";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View((AdminModels)TempData[Constant._ModelStateParent]);
                    }
                    if (ContentType.ToLower() != "application/pdf")
                    {
                        ViewBag.DisplayMessage = "Only PDF Document Is Uploaded";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View((AdminModels)TempData[Constant._ModelStateParent]);
                    }

                    //process for attach a scanned document
                    byte[] fileData1 = null;
                    string ContentType1 = string.Empty;
                    if (model.UserMaster.WhetherPoliceVerDone.ToUpper() == CustomText.TRUE.ToString())
                    {
                        HttpPostedFile file1 = System.Web.HttpContext.Current.Request.Files["PoliceDocumentData"];
                        fileData1 = Utility.CompareFileCapturePhotoData(null, file1);
                        ContentType1 = file1.ContentType;
                        if (fileData1 == null)
                        {
                            ViewBag.DisplayMessage = "Upload Document is Required";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View((AdminModels)TempData[Constant._ModelStateParent]);
                        }
                        if (file1.ContentLength > (int)LengthList.EncContent)
                        {
                            ViewBag.DisplayMessage = "Document has invalid size. (Max Limit: 100KB)";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View((AdminModels)TempData[Constant._ModelStateParent]);
                        }
                        if (ContentType1.ToLower() != "application/pdf")
                        {
                            ViewBag.DisplayMessage = "Only PDF Document Is Uploaded";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View((AdminModels)TempData[Constant._ModelStateParent]);
                        }
                    }

                    Qry = "insert into dbo.UserCreationEnclosureDetails (UserId,DocumentData,ContentType,userphotodata,policevercontenttype,policeverdocumentdata,actionuserId,actionipaddress,lastupdatedate) values (@UserId,@DocumentData,@ContentType,@userphotodata,@policevercontenttype,@policeverdocumentdata,@ActionuserId,@actionipaddress,now())";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@UserId", model.UserMaster.UserId);
                    Cmd.Parameters.AddWithValue("@DocumentData", fileData);
                    Cmd.Parameters.AddWithValue("@ContentType", ContentType);
                    Cmd.Parameters.AddWithValue("@userphotodata", model.UserPhoto);
                    Cmd.Parameters.AddWithValue("@policevercontenttype", ContentType1);
                    Cmd.Parameters.AddWithValue("@policeverdocumentdata", fileData1);
                    Cmd.Parameters.AddWithValue("@actionuserId", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamRegistrationId", model.UserMaster.UserId);
                    smsDic.Add("ParamMobileNo", model.UserMaster.ContactNo);
                    smsDic.Add("ParamPassword", SimplePassword);
                    smsDic.Add("ParamTransactionPassword", TransactionSimplePassword);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS014, smsDic));

                    if (model.UserMaster.EmailId != null)
                    {
                        Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                        EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                        EmailDic.Add("ParamRegistrationId", model.UserMaster.UserId);
                        EmailDic.Add("ParamPassword", SimplePassword);
                        EmailDic.Add("ParamEmailId", model.UserMaster.EmailId);
                        EmailDic.Add("ParamTransactionPassword", TransactionSimplePassword);
                        EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS014).ToString());
                        NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                        cmdList.Add(EmailCmd);
                    }

                    data.SaveTransactionalData(cmdList);

                    ViewData["message"] = "Your userid has been created successfully, and credential has been sent successfully on given mobile no.";
                    return View("message");
                }
                else
                {
                    Qry = "Select servicecode,servicename,('chkbox' || cast(Servicecode as varchar)) as ServiceControlId from dbo.servicemaster where WhetherActive=@WhetherActive and DeptCode=@ParamDeptCode ";
                    if (model.ServiceCode != null) { Qry += " and servicecode=@ServiceCode"; }
                    Qry += " order by servicename";
                    cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                    cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                    model.dataS = data.GetDataTable(cmd);

                    Qry = " select @UserId as UserId, Pname, Pcode from permissionmaster where Pcode=@Pcode ";
                    cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    cmd.Parameters.AddWithValue("@Pcode", model.UserMaster.Permission);
                    cmd.Parameters.AddWithValue("@UserId", model.UserMaster.UserId);
                    model.dtb = data.GetDataTable(cmd);

                    Qry = "select WhetherDistRequired,WhetherSubdivRequired from DeptToPermissionMaster DTPM  inner join PermissionMaster PM on PM.Pcode::smallint=DTPM.Pcode where DTPM.Pcode=@Pcode and DeptCode=@ParamDeptCode";
                    cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    cmd.Parameters.AddWithValue("@Pcode", model.UserMaster.Permission);
                    dt = data.GetDataTable(cmd);

                    if (dt != null && dt.Rows.Count > 0)
                    {
                        model.UserMaster.WhetherDistRequired = dt.Rows[0]["WhetherDistRequired"].ToString();
                        model.UserMaster.WhetherSubdivRequired = dt.Rows[0]["WhetherSubdivRequired"].ToString();
                    }

                    if (Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept010).ToString())
                    {
                        if (model.UserMaster.Permission == ((int)Permission.P120).ToString())
                        {
                            model.SchoolName = Utility.SelectColumnsValue("dgen.prematschoolmaster", "SchoolName", "SchoolId", model.Schoolid)[0];
                        }
                    }

                    PreserveModelState(Constant._ModelStateParent, model, false, true);
                    return View(model);
                }
            }

            if (!string.IsNullOrEmpty(model.UserMaster.UserName))
            {
                PreserveModelState(Constant._ModelStateParent, null, true, false);
                return View((AdminModels)TempData[Constant._ModelStateParent]);
            }

            ViewData["message"] = "The provided user details either in wrong format or does not fulfil the guideline of user creation policy. Kindly check the details and try again.";
            return View("message");
       
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult SearchForEditUserDetails()
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult SearchForEditUserDetails(AdminModels model)
        {
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "UserId" }, new ArrayList() { model.UserMaster.UserId });
                return RedirectToAction("ManageUserEntry", "Admin", new { q = QueryString });
            }
            return View("SearchForEditUserDetails", model);
        }
        [EncryptedActionParameter]
        public ActionResult ManageUserEntry(string UserId)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                AdminModels model = new AdminModels();
                model.UserMaster = new UserMaster();
                if (Convert.ToInt16(model.UserMaster.Permission) == (int)Permission.ADMN)
                {
                    return RedirectToAction("UnauthorizedRequest");
                }
                string Qry = "select UserId from dbo.usermaster where userid=@userid and deptcode=@deptcode";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@userid", UserId);
                cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                string WhetheruseridExist = data.SelectColumns(cmd)[0];
                if (string.IsNullOrEmpty(WhetheruseridExist))
                {
                    ViewBag.DisplayMessage = "UserID Provided is not Exist";
                    return View("SearchForEditUserDetails");
                }

                if (Sessions.getEmployeeUser().DeptCode != ((int)Department.Dept015).ToString())
                {
                    Qry = "select sm.servicecode,sm.servicename,('chkbox' || cast(sm.Servicecode as varchar)) as ServiceControlId,case when rs.servicecode is NULL then 0 else 1 end as whetherselected from dbo.servicemaster sm left outer join (select us.servicecode from usermaster um inner join usertoservicemaster us on us.uid=um.uid where um.userid=@userid) rs on rs.servicecode=sm.servicecode where sm.WhetherActive=@WhetherActive and DeptCode=@ParamDeptCode order by servicename";
                    cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    cmd.Parameters.AddWithValue("@userid", UserId);
                    cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                    string WhetherUserIdExist = data.SelectColumns(cmd)[0];
                    if (string.IsNullOrEmpty(WhetherUserIdExist))
                    {
                        ViewData["message"] = " The UserID Provided is not Exist";
                        return View("message");
                    }
                    model.dataS = data.GetDataTable(cmd);
                }

                Qry = "select SD.SubdivCode,SD.subdivdescription from dbo.subdivmaster SD inner join dbo.usertosubdivmaster US on SD.SubdivCode=US.SubdivCode  inner join UserMaster UM on UM.UID=US.UID where UM.userid=@userid";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@userid", UserId);
                model.dataSC = data.GetDataTable(cmd);

                Qry = "Select UM.DeptCode,UM.Permission as Pcode,UM.authorizationid,UM.UserId,UM.UserName,PM.pname as Permission,UM.designation,UM.Gender,UM.contactno,UM.emailid,UM.permanentaddress,UM.presentaddress,to_char(UM.dateofbirth,'DD/MM/YYYY') as dateofbirth,to_char(UM.dateofjoining,'DD/MM/YYYY') as dateofjoining,UM.UserIpAddress,to_char(UM.UserDateFrom,'DD/MM/YYYY') as DateFrom,to_char(UM.UserDateTo,'DD/MM/YYYY') as DateTo,to_char(UM.UserTimeTo, 'HH24:MI') as TimeTo,to_char(UM.UserTimeFrom ,'HH24:MI') as TimeFrom,UM.WhetherActive,AuthenticationTypeId,SigningTypeId,dbo.udf_general_decrypt(UserAadhaarNo),whetherdetailupdate,refencedocumenttypeid as DocId,userphotodata as UserPhoto,SMD.valuename as SelectUserTypeName from dbo.usermaster UM inner join dbo.permissionmaster PM on UM.permission=PM.pcode left outer join usercreationenclosuredetails UCED on UCED.UserId=UM.UserId left outer join selectmastervaluedetails SMD on SMD.valueid=UM.authorizationid where UM.userid=@userid";
                Qry = "Select UM.DeptCode,UM.Permission as Pcode,UM.authorizationid,SMD.valuename as authorizationname,UM.UserId,UM.UserName,PM.pname as Permission,UM.designation,UM.Gender,UM.contactno,UM.emailid,UM.permanentaddress,UM.presentaddress,to_char(UM.dateofbirth,'DD/MM/YYYY') as dateofbirth,to_char(UM.dateofjoining,'DD/MM/YYYY') as dateofjoining,UM.UserIpAddress,to_char(UM.UserDateFrom,'DD/MM/YYYY') as DateFrom,to_char(UM.UserDateTo,'DD/MM/YYYY') as DateTo,to_char(UM.UserTimeTo, 'HH24:MI') as TimeTo,to_char(UM.UserTimeFrom ,'HH24:MI') as TimeFrom,UM.WhetherActive,AuthenticationTypeId,SigningTypeId,dbo.udf_general_decrypt(UserAadhaarNo),whetherdetailupdate,refencedocumenttypeid as DocId,userphotodata as UserPhoto from dbo.usermaster UM inner join dbo.permissionmaster PM on UM.permission=PM.pcode left outer join usercreationenclosuredetails UCED on UCED.UserId=UM.UserId left outer join selectmastervaluedetails SMD on SMD.valueid=UM.authorizationid where UM.userid=@userid";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@userid", UserId);
                model.UserMaster = UserMaster.Get<UserMaster>(new UserMaster(), cmd);

                if (model.UserMaster.DeptCode == ((int)Department.Dept010).ToString())
                {
                    if (model.UserMaster.Pcode == ((int)Permission.P120).ToString())
                    {
                        Qry = "select SchoolName as subdivdescription from dgen.prematschoolmaster where schoolid=@AuthorizationId";
                        cmd = new NpgsqlCommand(Qry);
                        cmd.Parameters.AddWithValue("@AuthorizationId", model.UserMaster.AuthorizationId);
                        model.dataSC = data.GetDataTable(cmd);
                    }
                    if (model.UserMaster.Pcode == ((int)Permission.SDMG).ToString() && model.UserMaster.AuthorizationId != ((int)CountList.Type000).ToString())
                    {
                        Qry = "select  distinct ValueName as subdivdescription from selectmastervaluedetails SMV left outer join dgen.prematdistrictmaster PDM on PDM.DepartmentId=SMV.ValueId left outer join  dgen.prematzonemaster  PZM on PZM.DistrictCode=PDM.DistrictId where  (SMV.ValueId in (@AuthorizationId) or PDM.DistrictId in (@AuthorizationId) or PZM.ZoneId in (@AuthorizationId))";
                        cmd = new NpgsqlCommand(Qry);
                        cmd.Parameters.AddWithValue("@AuthorizationId", model.UserMaster.AuthorizationId);
                        model.dataSC = data.GetDataTable(cmd);
                    }
                }

                model.UserMaster.IsValidityExpired = false;
                DateTime CurrentDate = Convert.ToDateTime(DateTime.Now.Date);
                DateTime ExpiredDate = Convert.ToDateTime(model.UserMaster.DateTo);
                if (CurrentDate > ExpiredDate) { model.UserMaster.IsValidityExpired = true; }

                string Uip = model.UserMaster.UserIpAddress;
                string[] IPValues = Uip.Split('.');
                model.UserMaster.UserIpSeg1 = IPValues[0];
                model.UserMaster.UserIpSeg2 = IPValues[1];
                model.UserMaster.UserIpSeg3 = IPValues[2];
                model.UserMaster.UserIpSeg4 = IPValues[3];

                Qry = "Select UserId from Userdigitalmaster where UserId=@UserId and whetheractive=@whetheractive";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@UserId", UserId);
                cmd.Parameters.AddWithValue("@whetheractive", CustomText.True.ToString());
                string DSuserid = data.SelectColumns(cmd)[0];
                if (string.IsNullOrEmpty(DSuserid)) { model.UserMaster.WhetherUserDSMapped = false; }
                else { model.UserMaster.WhetherUserDSMapped = true; }

                Qry = "select UserId,RowId,UserName,SerialNo,to_char(ValidFrom,'DD/MM/YYYY') as ValidFrom ,to_char(ValidTo,'DD/MM/YYYY') as ValidTo,WhetherActive from Userdigitalmaster where UserId=@UserId  order by WhetherActive desc";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@UserId", UserId);
                model.dta = data.GetDataTable(cmd);

                PreserveModelState(Constant._ModelStateParent, model, false, true);
                return View(model);

            }
            return View("SearchForEditUserDetails");
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult SaveUserDetails(AdminModels model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                ArrayList Values = new ArrayList();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                //List<NpgsqlCommand> cmdList1 = new List<NpgsqlCommand>();
                
                string[] value = Utility.SelectColumnsValue("dbo.usermaster", "uid,UserName,dateofbirth", "userid", model.UserMaster.UserId.ToString());
                model.UserMaster.UID = Convert.ToInt16(value[0].ToString());
                model.UserMaster.UserName = value[1].ToString();
                model.UserMaster.DateOfBirth = value[2].ToString();
                string UserIpAddress = Convert.ToInt32(model.UserMaster.UserIpSeg1) + "." + Convert.ToInt32(model.UserMaster.UserIpSeg2) + "." + Convert.ToInt32(model.UserMaster.UserIpSeg3) + "." + Convert.ToInt32(model.UserMaster.UserIpSeg4);

                string Qry = "select sm.servicecode,sm.servicename,('chkbox' || cast(sm.Servicecode as varchar)) as ServiceControlId from dbo.servicemaster sm left outer join (select us.servicecode from usermaster um inner join usertoservicemaster us on us.uid=um.uid where um.userid=@userid) rs on rs.servicecode=sm.servicecode where sm.WhetherActive=@WhetherActive and DeptCode=@ParamDeptCode order by servicename";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@userid", model.UserMaster.UserId);
                cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                DataTable dta = data.GetDataTable(cmd);
                for (int i = 0; i < dta.Rows.Count; i++)
                {
                    if (frm[dta.Rows[i]["ServiceControlId"].ToString()] != null)
                    {
                        Values.Add(frm[dta.Rows[i]["ServiceControlId"].ToString()]);
                    }
                    if (Values == null)
                    {
                        return View(model);
                    }
                }

                // check aadhaar no of user if eKyc or eSign
                if (Convert.ToInt32(model.UserMaster.AuthenticationTypeId) == (int)ValueId.AutheKYC || Convert.ToInt32(model.UserMaster.SigningTypeId) == (int)ValueId.SignEsign)
                {
                    if (string.IsNullOrEmpty(model.UserMaster.AadhaarNo)) {
                        ViewData["message"] = "AADHAAR No. is Required";
                        return View("message");
                    }

                    model.UserMaster.Permission = Utility.SelectColumnsValue("dbo.usermaster", "Permission", "userid", model.UserMaster.UserId.ToString())[0];
                    Qry = "select count(UserId) from dbo.UserMaster where UserAadhaarNo=@UserAadhaarNo and Permission=@Permission and WhetherActive=@WhetherActive ";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@UserAadhaarNo", Utility.GetByteFromDocumentNo(model.UserMaster.AadhaarNo.ToUpper()));
                    cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                    cmd.Parameters.AddWithValue("@Permission", model.UserMaster.Permission);
                    string ExistUserId = data.SelectColumns(cmd)[0];
                    if (Convert.ToInt32(ExistUserId) > (int)CountList.Type001)
                    {
                        ViewData["message"] = "The provided AADHAAR No. is already mapped with another UserId , Kindly enter the correct details.";
                        return View("message");
                    }
                    int DocStatusId = Utility.VerifyRegistrationDocument(model.UserMaster.UserName, model.UserMaster.Gender.ToString(), model.UserMaster.DateOfBirth, model.UserMaster.AadhaarNo, (int)DocumentId.AadhaarCard);
                    if (DocStatusId != (int)WebServiceResponse.Verified)
                    {
                        ViewData["message"] = "The provided AADHAAR No. is not validated with entered details, Kindly enter the correct details. \\n To locate your nearest UIDAI center, go to 'Locate UIDAI Center' link on HOME Page.";
                        return View("message");
                    }
                }

                //if (string.IsNullOrEmpty(model.UserMaster.DocId))
                //{
                //    if (model.UserCreationEnclosureDetails.DocId == ((int)DocumentId.AadhaarCard).ToString())
                //    {
                //        int DocStatusId = Utility.VerifyRegistrationDocument(model.UserMaster.UserName, model.UserMaster.Gender, model.UserMaster.DateOfBirth, model.UserCreationEnclosureDetails.DocumentNo, (int)DocumentId.AadhaarCard);
                //        if (DocStatusId != (int)WebServiceResponse.Verified)
                //        {
                //            ViewData["message"] = "The provided AADHAAR No. is not validated with entered details, Kindly enter the correct details. \\n To locate your nearest UIDAI center, go to 'Locate UIDAI Center' link on HOME Page.";
                //            return View("message");
                //        }
                //    }
                //    else if (model.UserCreationEnclosureDetails.DocId == ((int)DocumentId.VoterID).ToString())
                //    {
                //        int DocStatusId = Utility.VerifyRegistrationDocument(model.UserMaster.UserName, model.UserMaster.Gender, model.UserMaster.DateOfBirth, model.UserCreationEnclosureDetails.DocumentNo, (int)DocumentId.VoterID);
                //        if (DocStatusId != (int)WebServiceResponse.Verified)
                //        {
                //            ViewData["message"] = "The provided Voter Id is not validated with entered details, \\n Kindly enter the correct details.";
                //            return View("message");
                //        }
                //    }
                //}

                HttpPostedFile appImage = System.Web.HttpContext.Current.Request.Files["ApplicantPhoto"];
                if (appImage != null)
                {
                    byte[] imageByte = Utility.HttpFilePhotoData(System.Web.HttpContext.Current.Request.Files["ApplicantPhoto"]);
                    if (!Utility.IsImage(appImage))
                    {
                        ViewData["message"] = "Invalid/Wrong image file does not allowed";
                        return View("message");
                    }
                    model.UserPhoto = Utility.CompareFileCapturePhotoData(model.PhotoData, imageByte);
                }

                Qry = "update dbo.usermaster set designation=@designation,contactno=@contactno,emailid=@emailid,permanentaddress=@permanentaddress,presentaddress=@presentaddress,UserIpAddress=@UserIpAddress,UserTimeFrom=@UserTimeFrom,UserTimeTo=@UserTimeTo,AuthenticationTypeId=@AuthenticationTypeId,SigningTypeId=@SigningTypeId,actionuserid=@actionuserid,actionipaddress=@actionipaddress,actiondatetime=now()";
                if (model.UserMaster.IsValidityExpired == true) { Qry += ",userdatefrom=@userdatefrom,userdateto=@userdateto"; }
                Qry += " where userid=@userid";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@userid", model.UserMaster.UserId);
                cmd.Parameters.AddWithValue("@designation", model.UserMaster.Designation);
                cmd.Parameters.AddWithValue("@contactno", model.UserMaster.ContactNo);
                cmd.Parameters.AddWithValue("@emailid", model.UserMaster.EmailId);
                cmd.Parameters.AddWithValue("@permanentaddress", model.UserMaster.PermanentAddress);
                cmd.Parameters.AddWithValue("@presentaddress", model.UserMaster.PresentAddress);
                cmd.Parameters.AddWithValue("@UserIpAddress", UserIpAddress);
                cmd.Parameters.AddWithValue("@UserTimeFrom", model.UserMaster.TimeFrom);
                cmd.Parameters.AddWithValue("@UserTimeTo", model.UserMaster.TimeTo);
                if (model.UserMaster.IsValidityExpired.ToString().ToUpper() == CustomText.TRUE.ToString())
                {
                    cmd.Parameters.AddWithValue("@userdatefrom", Utility.GetDateYYYYMMDD(model.UserMaster.DateFrom, '/', "0/1/2"));
                    cmd.Parameters.AddWithValue("@userdateto", Utility.GetDateYYYYMMDD(model.UserMaster.DateTo, '/', "0/1/2"));
                }
                cmd.Parameters.AddWithValue("@AuthenticationTypeId", model.UserMaster.AuthenticationTypeId);
                cmd.Parameters.AddWithValue("@SigningTypeId", model.UserMaster.SigningTypeId);
                cmd.Parameters.AddWithValue("@actionuserid", Sessions.getEmployeeUser().UserId);
                cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                cmdList.Add(cmd);

                if (Sessions.getEmployeeUser().DeptCode != ((int)Department.Dept015).ToString())
                {
                    Qry = "delete from dbo.usertoservicemaster where uid=@uid";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@uid", model.UserMaster.UID);
                    cmdList.Add(cmd);

                    for (int i = 0; i < Values.Count; i++)
                    {
                        Qry = "insert into dbo.usertoservicemaster (uid,servicecode,userid,ipaddress,actiondatetime) values (@uid,@servicecode,@userid,@ipaddress,now());";
                        cmd = new NpgsqlCommand(Qry);
                        cmd.Parameters.AddWithValue("@uid", model.UserMaster.UID);
                        cmd.Parameters.AddWithValue("@servicecode", (Values[i]).ToString());
                        cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(cmd);
                    }
                }

                if (model.UserMaster.WhetherDisableDSMapping)
                {
                    Qry = "Update dbo.userdigitalmaster set WhetherActive=@WhetherActive,deactivatedate=now(),actionuserid=@CurrentUserId,IpAddress=@IpAddress,actiondatetime=now() where userid=@UserId";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@WhetherActive", CustomText.False.ToString());
                    cmd.Parameters.AddWithValue("@UserId", model.UserMaster.UserId);
                    cmd.Parameters.AddWithValue("@CurrentUserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(cmd);
                }

                string ContentType1 = string.Empty, whethercond = string.Empty, whethercond1 = string.Empty;
                string RtnUserId = Utility.SelectColumnsValue("dbo.UserCreationEnclosureDetails", "UserId", "UserId", model.UserMaster.UserId)[0];

                //HttpPostedFile file1;
                //byte[] fileData1 = null;

                //if (string.IsNullOrEmpty(model.UserMaster.DocId))
                //{
                //    //process for attach a scanned document
                //    file1 = System.Web.HttpContext.Current.Request.Files["ReferenceDocumentData"];
                //    fileData1 = Utility.CompareFileCapturePhotoData(null, file1);
                //    ContentType1 = file1.ContentType;
                //    if (fileData1 == null)
                //    {
                //        ViewData["message"] = "Reference Document is Required";
                //        return View("message");
                //    }
                //    if (file1.ContentLength > (int)LengthList.EncContent)
                //    {
                //        ViewData["message"] = "Reference Document has invalid size. (Max Limit: 100KB)";
                //        return View("message");
                //    }
                //    if (ContentType1.ToLower() != "application/pdf")
                //    {
                //        ViewData["message"] = "Only PDF Document Is Uploaded in Reference Document";
                //        return View("message");
                //    }

                //    if (!string.IsNullOrEmpty(RtnUserId))
                //    {
                //        whethercond += ",refencedocumenttypeid=@refencedocumenttypeid,refencedocumentno=@refencedocumentno,refencedocumentcontenttype=@refencedocumentcontenttype,refencedocumentdocumentdata=@refencedocumentdocumentdata";
                //    }
                //}


                if (model.UserPhoto != null)
                {
                    if (!string.IsNullOrEmpty(RtnUserId))
                    {
                        whethercond += ",userphotodata=@userphotodata";
                    }
                }

                if (string.IsNullOrEmpty(RtnUserId))
                {
                    //Qry = "insert into dbo.UserCreationEnclosureDetails (UserId,refencedocumenttypeid,refencedocumentno,refencedocumentcontenttype,refencedocumentdocumentdata,userphotodata,actionuserId,actionipaddress,lastupdatedate) values (@UserId,@refencedocumenttypeid,@refencedocumentno,@refencedocumentcontenttype,@refencedocumentdocumentdata,@userphotodata,@ActionuserId,@actionipaddress,now())";
                    Qry = "insert into dbo.UserCreationEnclosureDetails (UserId,userphotodata,actionuserId,actionipaddress,lastupdatedate) values (@UserId,@userphotodata,@ActionuserId,@actionipaddress,now())";
                }
                else
                {
                    Qry = "update dbo.UserCreationEnclosureDetails set  actionuserId=@actionuserId,actionipaddress=@actionipaddress,lastupdatedate=now()" + whethercond + " where UserId=@UserId";
                }

                cmd = new NpgsqlCommand(Qry);
                //if (string.IsNullOrEmpty(model.UserMaster.DocId))
                //{
                //    cmd.Parameters.AddWithValue("@refencedocumenttypeid", model.UserCreationEnclosureDetails.DocId);
                //    cmd.Parameters.AddWithValue("@refencedocumentno", model.UserCreationEnclosureDetails.DocumentNo);
                //    cmd.Parameters.AddWithValue("@refencedocumentcontenttype", ContentType1);
                //    cmd.Parameters.AddWithValue("@refencedocumentdocumentdata", fileData1);
                //}
                cmd.Parameters.AddWithValue("@UserId", model.UserMaster.UserId);
                cmd.Parameters.AddWithValue("@userphotodata", model.UserPhoto);
                cmd.Parameters.AddWithValue("@actionuserId", Sessions.getEmployeeUser().UserId);
                cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                cmdList.Add(cmd);

                Dictionary<string, string> smsDic = new Dictionary<string, string>();
                smsDic.Add("ParamRegistrationId", model.UserMaster.UserId);
                smsDic.Add("ParamMobileNo", model.UserMaster.ContactNo);
                cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS022, smsDic));

                data.SaveData(cmdList);

                PreserveModelState(Constant._ModelStateParent, model, false, true);
                ViewData["message"] = "Your userid has been updated successfully";
                return View("message");
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("ManageUserEntry", TempData[Constant._ModelStateParent]);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult ActivateUser(AdminModels model)
        {
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            string Qry = "Update dbo.usermaster set whetheractive=@whetheractive where userid=@userid";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@userid", model.UserMaster.UserId);
            cmd.Parameters.AddWithValue("@whetheractive", CustomText.True.ToString());
            cmdList.Add(cmd);

            model.UserMaster.ContactNo = Utility.SelectColumnsValue("dbo.usermaster", "ContactNo", "userid", model.UserMaster.UserId.ToString())[0];

            if (string.IsNullOrEmpty(model.UserMaster.ContactNo))
            {
                ViewData["message"] = "The contact details is empty in selected user, kindly first update the details and try again.";
                return View("message");
            }

            Dictionary<string, string> smsDic = new Dictionary<string, string>();
            smsDic.Add("ParamRegistrationId", model.UserMaster.UserId);
            smsDic.Add("ParamMobileNo", model.UserMaster.ContactNo);
            cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS020, smsDic));

            data.SaveData(cmdList);
            ViewData["message"] = "Your userid has been Activated successfully";
            return View("message");

        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult DeactivateUser(AdminModels model)
        {
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            string Qry = "Update dbo.usermaster set whetheractive=@whetheractive where userid=@userid";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@userid", model.UserMaster.UserId);
            cmd.Parameters.AddWithValue("@whetheractive", CustomText.False.ToString());
            cmdList.Add(cmd);

            model.UserMaster.ContactNo = Utility.SelectColumnsValue("dbo.usermaster", "ContactNo", "userid", model.UserMaster.UserId.ToString())[0];

            if (!string.IsNullOrEmpty(model.UserMaster.ContactNo)) 
            {
                Dictionary<string, string> smsDic = new Dictionary<string, string>();
                smsDic.Add("ParamRegistrationId", model.UserMaster.UserId);
                smsDic.Add("ParamMobileNo", model.UserMaster.ContactNo);
                cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS021, smsDic));
            }

            data.SaveData(cmdList);
            ViewData["message"] = "Your userid has been Deactivated successfully";
            return View("message");
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult SelectMasterTable(int? UpdateId)
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult SelectMasterTable(AdminModels model)
        {
            GetData data = new GetData();
            if (model.UpdateId != null)
            {

                if (ModelState.IsValid)
                {
                    string TableName = Utility.SelectColumnsValue("dbo.MasterTableMaster", "tablename", "tableid", model.MasterTableId.ToString())[0];
                    string Qry = "select * from " + TableName + " where " + model.PKColumnName + "=" + model.UpdateId;
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@TableId", model.MasterTableId);
                    model.dtb = data.GetDataTable(Cmd);
                    model.dta = Utility.GetColumnsDataFromTableId(model.MasterTableId);

                    string value = string.Empty;
                    for (int i = 0; i < model.dta.Rows.Count; i++)
                    {

                        for (int j = 0; j < model.dtb.Rows.Count; j++)
                        {
                            if (model.dta.Rows[i]["datatype"].ToString() == "date")
                            {
                                if (!string.IsNullOrEmpty(model.dtb.Rows[j][model.dta.Rows[i]["columnname"].ToString()].ToString()))
                                {
                                    value = Utility.ConvertDateSequence(model.dtb.Rows[j][model.dta.Rows[i]["columnname"].ToString()].ToString(), '/', "0/1/2");
                                }
                            }
                            else
                            {
                                value = model.dtb.Rows[j][model.dta.Rows[i]["columnname"].ToString()].ToString();

                            }
                            ViewData[model.dta.Rows[i]["controlname"].ToString()] = value;
                        }
                    }

                    PreserveModelState(Constant._ModelStateParent, model, false, true);
                    return View("AddDataToMasterTable", model);
                }
            }
            if (ModelState.IsValid)
            {
                model.dta = Utility.GetColumnsDataFromTableId(model.MasterTableId);
                model.dtb = Utility.GetDataFromTableId(model.MasterTableId);
                PreserveModelState(Constant._ModelStateParent, model, false, true);
                return View("AddDataToMasterTable", model);
            }
            return View("AddDataToMasterTable", model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult AddDataToMasterTable(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Query = string.Empty, TableName = string.Empty, Column = string.Empty, Parameters = string.Empty, whereColumn = string.Empty;

                model.dta = Utility.GetColumnsDataFromTableId(model.MasterTableId);

                TableName = model.dta.Rows[0]["tablename"].ToString();
                if (model.UpdateId != null)
                {
                    whereColumn = model.PKColumnName;
                    Column = model.dta.Rows[0]["columnname"].ToString() + "=" + "@" + model.dta.Rows[0]["columnname"].ToString();
                    if (model.dta.Rows.Count > 0)
                    {
                        for (int i = 1; i < model.dta.Rows.Count; i++)
                        {
                            Column = Column + "," + model.dta.Rows[i]["columnname"].ToString() + "=" + "@" + model.dta.Rows[i]["columnname"].ToString();
                        }
                    }
                    Column = Column + " ,userid=@userid,ipaddress=@ipaddress,actiondatetime=now()";
                    string value = string.Empty;
                    Query = "update " + TableName + " set " + Column + " where " + whereColumn + "=" + model.UpdateId;
                    NpgsqlCommand Cmd = new NpgsqlCommand(Query);
                    for (int i = 0; i < model.dta.Rows.Count; i++)
                    {
                        if (model.dta.Rows[i]["datatype"].ToString() == "date") { value = Utility.GetDateYYYYMMDD(frm[model.dta.Rows[i]["controlname"].ToString()], '/', "0/1/2"); }

                        else { value = frm[model.dta.Rows[i]["controlname"].ToString()]; }

                        if (value == "")
                        {
                            value = null;
                        }
                        Cmd.Parameters.AddWithValue("@" + model.dta.Rows[i]["columnname"].ToString(), value);
                    }
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                    data.SaveData(cmdList);

                    model.dta = Utility.GetColumnsDataFromTableId(model.MasterTableId);
                    model.dtb = Utility.GetDataFromTableId(model.MasterTableId);

                    return View("AddDataToMasterTable", model);
                }

                Column = " (" + model.dta.Rows[0]["columnname"].ToString();
                Parameters = " (@" + model.dta.Rows[0]["columnname"].ToString();
                if (model.dta.Rows.Count > 0)
                {
                    for (int i = 1; i < model.dta.Rows.Count; i++)
                    {
                        Column = Column + "," + model.dta.Rows[i]["columnname"].ToString();
                        Parameters = Parameters + ",@" + model.dta.Rows[i]["columnname"].ToString();
                    }
                }
                Column = Column + " ,userid,ipaddress,actiondatetime) ";
                Parameters = Parameters + " ,@userid,@ipaddress,now()) ";

                string value1 = string.Empty;
                Query = "insert into " + TableName + Column + "values" + Parameters;
                NpgsqlCommand Cmd1 = new NpgsqlCommand(Query);
                for (int i = 0; i < model.dta.Rows.Count; i++)
                {
                    if (model.dta.Rows[i]["datatype"].ToString() == "date") { value1 = Utility.GetDateYYYYMMDD(frm[model.dta.Rows[i]["controlname"].ToString()], '/', "0/1/2"); }
                    else { value1 = frm[model.dta.Rows[i]["controlname"].ToString()]; }
                    if (value1 == "")
                    {
                        value1 = null;
                    }
                    Cmd1.Parameters.AddWithValue("@" + model.dta.Rows[i]["columnname"].ToString(), value1);

                }
                Cmd1.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd1.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd1);
                data.SaveData(cmdList);

                model.dta = Utility.GetColumnsDataFromTableId(model.MasterTableId);
                model.dtb = Utility.GetDataFromTableId(model.MasterTableId);
                return View("AddDataToMasterTable", model);
            }
            model.dta = Utility.GetColumnsDataFromTableId(model.MasterTableId);
            model.dtb = Utility.GetDataFromTableId(model.MasterTableId);
            ViewBag.DisplayMessage = "Error: Could not add data!";
            return View("AddDataToMasterTable", model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult UpdateDataToMasterTable(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Query = string.Empty, TableName = string.Empty, Column = string.Empty, Parameters = string.Empty, whereColumn = string.Empty;

                model.dta = Utility.GetColumnsDataFromTableId(model.MasterTableId);

                TableName = model.dta.Rows[0]["tablename"].ToString();
                if (model.UpdateId != null)
                {
                    if (model.ActionTaken == "2")
                    {
                        whereColumn = model.PKColumnName;
                        Query = "update " + TableName + " set WhetherActive=@WhetherActive where " + whereColumn + "=" + model.UpdateId;
                        NpgsqlCommand Cmd = new NpgsqlCommand(Query);
                        Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.FALSE.ToString());
                        cmdList.Add(Cmd);
                        data.SaveData(cmdList);
                    }
                    if (model.ActionTaken == "3")
                    {
                        whereColumn = model.PKColumnName;
                        Query = "update " + TableName + " set WhetherActive=@WhetherActive where " + whereColumn + "=" + model.UpdateId;
                        NpgsqlCommand Cmd = new NpgsqlCommand(Query);
                        Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                        cmdList.Add(Cmd);

                        data.SaveData(cmdList);
                    }


                    model.dta = Utility.GetColumnsDataFromTableId(model.MasterTableId);
                    model.dtb = Utility.GetDataFromTableId(model.MasterTableId);

                    return View("AddDataToMasterTable", model);
                }


            }
            model.dta = Utility.GetColumnsDataFromTableId(model.MasterTableId);
            model.dtb = Utility.GetDataFromTableId(model.MasterTableId);
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            ViewBag.DisplayMessage = "Error: Could not add data!";
            return View("AddDataToMasterTable", model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult SearchDataInMasterTable()
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult SearchDataInMasterTable(AdminModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string TableName = Utility.SelectColumnsValue("dbo.MasterTableMaster", "tablename", "tableid", model.MasterTableId)[0].ToLower();
                string Qry = "select * from " + TableName + " where lower(" + model.ColumnId.ToLower() + "::varchar) LIKE '%" + model.ColumnValue.ToLower() + "%'";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                model.dataS = data.GetDataTable(cmd);
                model.ColumnName = model.ColumnId;
            }
            return View(model);
        }


        #region Locality Management Module
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult LocalityManagement()
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult AddNewLocality(AdminModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string Qry = string.Empty;
                Qry = "select DistrictCode,DistrictName from dbo.DistrictMaster where deptcode=@deptcode order by DistrictName limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                model.DistList = new SelectList(DistrictMaster.List<DistrictMaster>(Cmd), "DistrictCode", "DistrictName");
                return View(model);
            }
            return View("LocalityManagement", model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult AddLocality(AdminModels model)
        {
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            if (ModelState.IsValid)
            {

                string Qry = "select DistrictCode,DistrictName from dbo.DistrictMaster where deptcode=@deptcode order by DistrictName limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                model.DistList = new SelectList(DistrictMaster.List<DistrictMaster>(Cmd), "DistrictCode", "DistrictName");

                if (!string.IsNullOrEmpty(Utility.SelectColumnsValue("localitymaster", "localityname", "lower(localityname)", model.LocalityMaster.LocalityName.ToLower())[0]))
                {
                    ViewBag.DisplayMessage = "You cannot add another locality with exactly the same name, we advise you to alter the locality name.\\n";
                    return View("LocalityManagement", model);
                }

                Qry = "select LM.LocalityId,LM.LocalityName,('chkbox' || cast(LM.LocalityId as varchar)) as LocalityControlId,SD.SubDivCode,SM.StateName,SD.SubDivDescription,LS.WhetherActive from LocalityMaster LM inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join SubDivMaster SD on SD.SubdivCode=LS.SubDivCode inner join dbo.districtmaster DM on DM.districtcode=SD.districtcode inner join dbo.statemaster SM on SM.stateid=DM.stateid where DM.deptcode=@deptcode and lower(LM.LocalityName)=lower(@LocalityName) and LS.whetheractive=@whetheractive order by LocalityName";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                Cmd.Parameters.AddWithValue("@LocalityName", model.LocalityMaster.LocalityName);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                model.dataS = data.GetDataTable(Cmd);
                if (model.dataS.Rows.Count > 0)
                {
                    ViewBag.DisplayMessage = "Provided locality already exist under e-District Delhi.";
                    return View("LocalityManagement", model);
                }
                if (!string.IsNullOrEmpty(Utility.SelectColumnsValue("localitymaster", "localityname", "lower(localityname)", model.LocalityMaster.LocalityName.ToLower())[0]))
                {
                    ViewBag.DisplayMessage = "You cannot add another locality with exactly the same name, we advise you to alter the locality name.\\n";
                    return View("LocalityManagement", model);
                }
                else if (Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept001).ToString())
                {
                    Qry = "insert into dbo.LocalityMaster(LocalityName,UserId,IpAddress)values(@LocalityName,@UserId,@IpAddress); SELECT currval(pg_get_serial_sequence('dbo.LocalityMaster','localityid'))";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@LocalityName", model.LocalityMaster.LocalityName);
                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    Qry = "insert into dbo.localitytosubdivmaster(localityid,subdivcode,whetheractive,userid,ipaddress,actiondatetime) values(@LastInsertedId,@subdivcode,@whetheractive,@userid,@ipaddress,now())";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@subdivcode", model.LocalityMaster.SubDivCode);
                    Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    data.SaveTransactionalData(cmdList);
                    ViewBag.DisplayMessage = "Provided locality has been successfully added under e-District Delhi.";
                    return View("LocalityManagement", model);
                }
                else
                {
                    Qry = "insert into dbo.departmenttolocalitydetails(LocalityName,DistrictCode,SubDivCode,DeptCode,WhetherApproved,Remarks,RequestedBy,RequestIpAddress)values(@LocalityName,@DistrictCode,@SubDivCode,@DeptCode,@WhetherApproved,@Remarks,@RequestedBy,@RequestIpAddress); SELECT currval(pg_get_serial_sequence('dbo.departmenttolocalitydetails','dlocalityid'))";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@LocalityName", model.LocalityMaster.LocalityName);
                    Cmd.Parameters.AddWithValue("@DistrictCode", model.LocalityMaster.DistrictCode);
                    Cmd.Parameters.AddWithValue("@SubDivCode", model.LocalityMaster.SubDivCode);
                    Cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.FALSE.ToString());
                    Cmd.Parameters.AddWithValue("@Remarks", model.LocalityMaster.Remarks);
                    Cmd.Parameters.AddWithValue("@DeptCode", Sessions.getEmployeeUser().DeptCode);
                    Cmd.Parameters.AddWithValue("@RequestedBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@RequestIpAddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    if (Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept002).ToString() || Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept008).ToString())
                    {
                        Qry = "insert into dbo.newlocalitytoconstituencymaster(dlocalityid,ConstituencyId,requestedby,requestedipaddress,requestdate)values(@LastInsertedId,@ConstituencyId,@UserId,@IpAddress,now())";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ConstituencyId", model.LocalityMaster.ConstituencyId);
                        Cmd.Parameters.AddWithValue("@DeptCode", Sessions.getEmployeeUser().DeptCode);
                        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }

                    data.SaveTransactionalData(cmdList);
                    ViewBag.DisplayMessage = "Your Request of Entry of Locality has been tansfer to Revenue Department. After Approval You will able to view this Locality";
                    return View("LocalityManagement", model);
                }
            }
            return View("AddNewLocality", model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult CheckLocality(AdminModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string Qry = "select LM.LocalityId,LM.LocalityName,LS.SubDivCode,SM.StateName,SD.SubDivDescription,case when (LM.WhetherActive=FALSE or LS.WhetherActive = FALSE) then FALSE else TRUE end as WhetherActive from LocalityMaster LM inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join SubDivMaster SD on SD.SubdivCode=LS.SubDivCode inner join dbo.districtmaster DM on DM.districtcode=SD.districtcode inner join dbo.statemaster SM on SM.stateid=DM.stateid where DM.deptcode=@deptcode and lower(LM.LocalityName) like '%" + model.LocalityMaster.LocalityName.ToLower() + "%' order by LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                model.dataS = data.GetDataTable(Cmd);
                return View("LocalityManagement", model);
            }
            return View("LocalityManagement", model);
        }
        [EncryptedActionParameter]
        public ActionResult LocalityMappingDetails(Int32 LocalityId, string flag)
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            string Qry = "select LM.LocalityId,LM.LocalityName,LS.SubDivCode,SM.StateName,SD.SubDivDescription,DM.DistrictName,SM.StateName,case when (LM.WhetherActive=FALSE or LS.WhetherActive = FALSE) then FALSE else TRUE end as WhetherActive,LM.PinCode from LocalityMaster LM inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join SubDivMaster SD on SD.SubdivCode=LS.SubDivCode inner join dbo.districtmaster DM on DM.districtcode=SD.districtcode inner join dbo.statemaster SM on SM.stateid=DM.stateid where DM.deptcode=@deptcode and  LM.localityId=@LocalityId order by LocalityName";//Changes20180316
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
            Cmd.Parameters.AddWithValue("@LocalityId", LocalityId);
            model.data = data.GetDataTable(Cmd);

            Qry = "select LM.LocalityId,LM.LocalityName,LS.SubDivCode,SM.StateName,SD.SubDivDescription,DM.DistrictName,SM.StateName,case when (LM.WhetherActive=FALSE or LS.WhetherActive = FALSE) then FALSE else TRUE end as WhetherActive,LM.PinCode,DePtName from LocalityMaster LM inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join SubDivMaster SD on SD.SubdivCode=LS.SubDivCode inner join dbo.districtmaster DM on DM.districtcode=SD.districtcode inner join dbo.statemaster SM on SM.stateid=DM.stateid inner join DeptMaster DeptM on DeptM.DeptCode=DM.DeptCode where DM.deptcode<>@deptcode and  LM.localityId=@LocalityId order by LocalityName";//Changes20180316
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
            Cmd.Parameters.AddWithValue("@LocalityId", LocalityId);
            model.dataS = data.GetDataTable(Cmd);

            model.LocalityId = LocalityId.ToString();
            model.flag = flag;
            return View(model);

        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult DisableLocality(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                ArrayList Values = new ArrayList();
                ArrayList ValuesSDM = new ArrayList();
                string Qry = "select LS.SubDivCode from LocalityMaster LM inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join SubDivMaster SD on SD.SubdivCode=LS.SubDivCode inner join dbo.districtmaster DM on DM.districtcode=SD.districtcode where DM.deptcode=@deptcode and LM.LocalityId=@LocalityId order by LocalityName";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                cmd.Parameters.AddWithValue("@LocalityId", model.LocalityId);
                model.SubDivCode = data.SelectColumns(cmd)[0];


                Qry = "Update dbo.localitytosubdivmaster set WhetherActive=@WhetherActive,UserId=@UserId,actiondatetime=now(),IpAddress=@IpAddress where LocalityId=@LocalityId";
                if (Sessions.getEmployeeUser().DeptCode != ((int)Department.Dept001).ToString()) { Qry += " and SubdivCode=@SubdivCode"; }
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@LocalityId", model.LocalityId);
                cmd.Parameters.AddWithValue("@SubdivCode", model.SubDivCode);
                cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                cmd.Parameters.AddWithValue("@WhetherActive", CustomText.FALSE.ToString());
                cmdList.Add(cmd);

                if (Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept001).ToString() || Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept002).ToString() || Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept008).ToString())
                {
                    Qry = "Update dbo.localitytoconstituencymaster set WhetherActive=@WhetherActive,UserId=@UserId,actiondatetime=now(),IpAddress=@IpAddress where LocalityId=@LocalityId ";
                    if (Sessions.getEmployeeUser().DeptCode != ((int)Department.Dept001).ToString()) { Qry += " and DeptCode=@DeptCode"; }
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@LocalityId", model.LocalityId);
                    cmd.Parameters.AddWithValue("@DeptCode", Sessions.getEmployeeUser().DeptCode);
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmd.Parameters.AddWithValue("@WhetherActive", CustomText.FALSE.ToString());
                    cmdList.Add(cmd);
                }
                if (Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept001).ToString())
                {
                    Qry = "Update dbo.localitymaster set WhetherActive=@WhetherActive,UserId=@UserId,actiondatetime=now(),IpAddress=@IpAddress where LocalityId=@LocalityId";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@LocalityId", model.LocalityId);
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmd.Parameters.AddWithValue("@WhetherActive", CustomText.FALSE.ToString());
                    cmdList.Add(cmd);
                }

                data.SaveData(cmdList);

                if (Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept001).ToString())
                {
                    //send sms to Other Department Admin and insert record in table
                    Qry = "select Contactno from usermaster where permission=@permission and deptcode<>@DeptCode and Contactno is not null ";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@permission", ((int)Permission.P118).ToString());
                    cmd.Parameters.AddWithValue("@DeptCode", Sessions.getEmployeeUser().DeptCode);
                    model.data = data.GetDataTable(cmd);
                    if (model.data != null && model.data.Rows.Count > 0)
                    {
                        for (int i = 0; i < model.data.Rows.Count; i++)
                        {
                            Dictionary<string, string> smsDic = new Dictionary<string, string>();
                            smsDic.Add("ParamMobileNo", model.data.Rows[i]["Contactno"].ToString());
                            data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS042, smsDic));
                        }
                    }
                }

                ViewData["message"] = "Selected Locality has been successfully disabled.";
                return View("message");

                //ViewBag.DisplayMessage = "Locality has been successfully Disabled";
                //Qry = "select DistrictCode,DistrictName from dbo.DistrictMaster where deptcode=@deptcode order by DistrictName limit 0";
                //cmd = new NpgsqlCommand(Qry);
                //cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                //model.DistList = new SelectList(DistrictMaster.List<DistrictMaster>(cmd), "DistrictCode", "DistrictName");

                //Qry = "select LM.LocalityId,LM.LocalityName,LS.SubDivCode,SM.StateName,SD.SubDivDescription,LS.WhetherActive from LocalityMaster LM inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join SubDivMaster SD on SD.SubdivCode=LS.SubDivCode inner join dbo.districtmaster DM on DM.districtcode=SD.districtcode inner join dbo.statemaster SM on SM.stateid=DM.stateid where DM.deptcode=@deptcode and lower(LM.LocalityName) like '%" + model.LocalityMaster.LocalityName.ToLower() + "%' order by LocalityName";
                //cmd = new NpgsqlCommand(Qry);
                //cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                //model.dataS = data.GetDataTable(cmd);
                //return View("LocalityManagement", model);

            }
            return View("LocalityManagement", model);
        }
        //[AcceptVerbs(HttpVerbs.Post)]
        //[ValidateOnlyIncomingValues]
        //[ValidateAntiForgeryToken]
        //public ActionResult EnableLocality(AdminModels model, FormCollection frm)
        //{
        //    GetData data = new GetData();
        //    if (ModelState.IsValid)
        //    {
        //        List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
        //        ArrayList Values = new ArrayList();
        //        ArrayList ValuesSDM = new ArrayList();

        //        string Qry = "select LS.SubDivCode,LM.LocalityName from LocalityMaster LM inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join SubDivMaster SD on SD.SubdivCode=LS.SubDivCode inner join dbo.districtmaster DM on DM.districtcode=SD.districtcode where DM.deptcode=@deptcode and LM.LocalityId=@LocalityId order by LocalityName";
        //        NpgsqlCommand cmd = new NpgsqlCommand(Qry);
        //        cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
        //        cmd.Parameters.AddWithValue("@LocalityId", model.LocalityId);
        //        string[] Value = data.SelectColumns(cmd);

        //        if (Value != null)
        //        {
        //            model.SubDivCode = Value[0];
        //            model.LocalityName = Value[1];
        //        }
        //        else
        //        {
        //            ViewData["message"] = "The Locality Mapping Not Found. Kindly Try Again";
        //            return View("message");
        //        }

        //        //DataTable dta = data.GetDataTable(cmd);
        //        //for (int i = 0; i < dta.Rows.Count; i++)
        //        //{
        //        //    if (frm[dta.Rows[i]["LocalityControlId"].ToString()] != null)
        //        //    {
        //        //        Values.Add(frm[dta.Rows[i]["LocalityControlId"].ToString()]);
        //        //        ValuesSDM.Add(dta.Rows[i]["SubDivCode"].ToString());
        //        //    }
        //        //    if (Values == null)
        //        //    {
        //        //        return View(model);
        //        //    }
        //        //}

        //        if (Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept001).ToString())
        //        {
        //            Qry = "select LocalityId from localitymaster where trim(lower(localityname))=@localityname and WhetherActive=@WhetherActive";
        //            cmd = new NpgsqlCommand(Qry);
        //            cmd.Parameters.AddWithValue("@localityname", model.LocalityName.ToLower().Trim());
        //            cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
        //            string LocId = data.SelectColumns(cmd)[0];
        //            if (!string.IsNullOrEmpty(LocId))
        //            {
        //                ViewData["message"] = "The selected locality can not be enabled becuase there is another Active recrods of same name locality found. Kindly user Search Option for further details.";
        //                return View("message");
        //            }
        //        }
        //        else
        //        {
        //            Qry = "select LocalityId from localitymaster where LocalityId=@LocalityId and WhetherActive=@WhetherActive";
        //            cmd = new NpgsqlCommand(Qry);
        //            cmd.Parameters.AddWithValue("@LocalityId", model.LocalityId);
        //            cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
        //            string LocId = data.SelectColumns(cmd)[0];
        //            if (string.IsNullOrEmpty(LocId))
        //            {
        //                ViewData["message"] = "The selected locality is marked Disabled by Nodal Department (Revenue Department). Kindly request to Nodal Department to enable or add new request of locality.";
        //                return View("message");
        //            }
        //        }

        //        Qry = "Update dbo.localitytosubdivmaster set WhetherActive=@WhetherActive,UserId=@UserId,actiondatetime=now(),IpAddress=@IpAddress where LocalityId=@LocalityId  and SubdivCode=@SubdivCode";
        //        cmd = new NpgsqlCommand(Qry);
        //        cmd.Parameters.AddWithValue("@LocalityId", model.LocalityId);
        //        cmd.Parameters.AddWithValue("@SubdivCode", model.SubDivCode);
        //        cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
        //        cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
        //        cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
        //        cmdList.Add(cmd);

        //        if (Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept001).ToString())
        //        {
        //            Qry = "Update dbo.localitymaster set WhetherActive=@WhetherActive,UserId=@UserId,actiondatetime=now(),IpAddress=@IpAddress where LocalityId=@LocalityId";
        //            cmd = new NpgsqlCommand(Qry);
        //            cmd.Parameters.AddWithValue("@LocalityId", model.LocalityId);
        //            cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
        //            cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
        //            cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
        //            cmdList.Add(cmd);
        //        }

        //        data.SaveData(cmdList);

        //        if (Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept001).ToString())
        //        {
        //            //send sms to Other Department Admin and insert record in table
        //            Qry = "select Contactno from usermaster where permission=@permission and deptcode<>@DeptCode and Contactno is not null ";
        //            cmd = new NpgsqlCommand(Qry);
        //            cmd.Parameters.AddWithValue("@permission", ((int)Permission.P118).ToString());
        //            cmd.Parameters.AddWithValue("@DeptCode", Sessions.getEmployeeUser().DeptCode);
        //            model.data = data.GetDataTable(cmd);
        //            if (model.data != null && model.data.Rows.Count > 0)
        //            {
        //                for (int i = 0; i < model.data.Rows.Count; i++)
        //                {
        //                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
        //                    smsDic.Add("ParamMobileNo", model.data.Rows[i]["Contactno"].ToString());
        //                    data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS041, smsDic));
        //                }
        //            }
        //        }

        //        ViewData["message"] = "Locality has been successfully Enabled";
        //        return View("message");

        //        //ViewBag.DisplayMessage = "Locality has been successfully Enabled";
        //        //Qry = "select DistrictCode,DistrictName from dbo.DistrictMaster where deptcode=@deptcode order by DistrictName limit 0";
        //        //cmd = new NpgsqlCommand(Qry);
        //        //cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
        //        //model.DistList = new SelectList(DistrictMaster.List<DistrictMaster>(cmd), "DistrictCode", "DistrictName");

        //        //Qry = "select LM.LocalityId,LM.LocalityName,('chkbox' || cast(LM.LocalityId as varchar)) as LocalityControlId,LS.SubDivCode,SM.StateName,SD.SubDivDescription,LS.WhetherActive from LocalityMaster LM inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join SubDivMaster SD on SD.SubdivCode=LS.SubDivCode inner join dbo.districtmaster DM on DM.districtcode=SD.districtcode inner join dbo.statemaster SM on SM.stateid=DM.stateid where DM.deptcode=@deptcode and lower(LM.LocalityName) like '%" + model.LocalityMaster.LocalityName.ToLower() + "%' order by LocalityName";
        //        //cmd = new NpgsqlCommand(Qry);
        //        //cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
        //        //model.dataS = data.GetDataTable(cmd);
        //        //return View("LocalityManagement", model);

        //    }
        //    return View("LocalityManagement", model);
        //}
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult AddRequestedLocality()
        {
            AdminModels model = new AdminModels();
            GetData data = new GetData();
            string Qry = "select DLocalityId,LocalityName,LM.DistrictCode,DM.DistrictName,LM.SubDivCode,SD.SubDivDescription,LM.WhetherApproved,LM.Remarks,LM.DeptCode,DP.DeptName,LM.RequestedBy,LM.RequestDate from departmenttolocalitydetails LM inner join SubDivMaster SD on SD.SubdivCode=LM.SubDivCode inner join dbo.districtmaster DM on DM.districtcode=LM.districtcode inner join Deptmaster DP on DP.deptcode=LM.deptcode where whetherapproved=@whetherapproved order by LocalityName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("whetherapproved", CustomText.FALSE.ToString());
            model.dta = data.GetDataTable(Cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult AddRequestedLocality(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            if (ModelState.IsValid)
            {
                ArrayList Values = new ArrayList();
                ArrayList ValuesSDM = new ArrayList();
                ArrayList ValuesLoc = new ArrayList();
                ArrayList ValuesDLId = new ArrayList();
                ArrayList ValuesDept = new ArrayList();

                string Qry = "select LM.DLocalityId,LM.LocalityName,('chkbox' || cast(LM.DLocalityId as varchar)) as LocalityControlId,LM.SubDivCode,SD.SubDivDescription,LM.Deptcode from departmenttolocalitydetails LM  inner join SubDivMaster SD on SD.SubdivCode=LM.SubDivCode inner join dbo.districtmaster DM on DM.districtcode=SD.districtcode inner join dbo.statemaster SM on SM.stateid=DM.stateid where whetherapproved=@whetherapproved order by LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("whetherapproved", CustomText.FALSE.ToString());
                DataTable dta = data.GetDataTable(Cmd);
                for (int i = 0; i < dta.Rows.Count; i++)
                {
                    if (frm[dta.Rows[i]["LocalityControlId"].ToString()] != null)
                    {
                        Values.Add(frm[dta.Rows[i]["LocalityControlId"].ToString()]);
                        ValuesSDM.Add(dta.Rows[i]["SubDivCode"].ToString());
                        ValuesLoc.Add(dta.Rows[i]["LocalityName"].ToString());
                        ValuesDLId.Add(dta.Rows[i]["DLocalityId"].ToString());
                        ValuesDept.Add(dta.Rows[i]["Deptcode"].ToString());
                    }
                    if (Values == null)
                    {
                        return View(model);
                    }
                }
                for (int i = 0; i < Values.Count; i++)
                {
                    Qry = "insert into dbo.LocalityMaster(LocalityName,UserId,IpAddress)values(@LocalityName,@UserId,@IpAddress); SELECT currval(pg_get_serial_sequence('dbo.LocalityMaster','localityid'))";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@LocalityName", (ValuesLoc[i]).ToString());
                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    Qry = "insert into dbo.localitytosubdivmaster(localityid,subdivcode,whetheractive,userid,ipaddress,actiondatetime) values(@LastInsertedId,@subdivcode,@whetheractive,@userid,@ipaddress,now())";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@subdivcode", model.LocalityMaster.SubDivCode);
                    Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    Qry = "insert into dbo.localitytosubdivmaster(localityid,subdivcode,whetheractive,userid,ipaddress,actiondatetime) values(@LastInsertedId,@subdivcode,@whetheractive,@userid,@ipaddress,now())";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@subdivcode", (ValuesSDM[i]).ToString());
                    Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    string chkconstituency = Utility.SelectColumnsValue("newlocalitytoconstituencymaster", "constituencyid", "DLocalityId", ValuesDLId[i].ToString())[0];
                    if (!string.IsNullOrEmpty(chkconstituency))
                    {
                        Qry = @"insert into dbo.localitytoconstituencymaster(localityid,ConstituencyID,DeptCode,whetheractive,userid,ipaddress,actiondatetime) select @LastInsertedId,ConstituencyID,DeptCode,@whetheractive,@userid,@ipaddress,now() from DepartmentToLocalityDetails DTLD inner join  NewLocalityToConstituencyMaster NLTCM on NLTCM.Dlocalityid=DTLD.Dlocalityid where DTLD.DLocalityId=@DLocalityId";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@DLocalityId", ValuesDLId[i].ToString());
                        Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                    else
                    {
                        ViewData["message"] = "The Mapping of Locality with Constituency is not Exist For the Locality (" + ValuesLoc[i].ToString() + ") !!!";
                        return View("Message");
                    }

                    Qry = "update departmenttolocalitydetails set WhetherApproved=@WhetherApproved,ApprovedBy=@ApprovedBy,ApprovedIpaddress=@ApprovedIpaddress,ApproveDate=now() where DLocalityId=@DLocalityId";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@DLocalityId", (ValuesDLId[i]).ToString());
                    Cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@ApprovedBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ApprovedIpaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                }

                data.SaveTransactionalData(cmdList);
                PreserveModelState(Constant._ActionMessage, "Provided locality has been successfully added under e-District Delhi. ", false, true);
                return RedirectToAction("AddRequestedLocality", "Admin");

            }
            return View("AddRequestedLocality", model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult MapLocality()
        {
            AdminModels model = new AdminModels();
            GetData data = new GetData();
            string Qry = "select a.* from (select LM.LocalityId,LM.LocalityName,LS.SubdivCode,SD.SubDivDescription,DM.DistrictName from dbo.localitymaster LM inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join SubDivMaster SD on SD.SubdivCode=LS.SubDivCode inner join dbo.districtmaster DM on DM.districtcode=SD.districtcode inner join dbo.statemaster SM on SM.stateid=DM.stateid where DM.deptcode=@revdeptcode and SM.stateid=@stateid and LS.whetheractive=TRUE and LM.whetheractive=TRUE) a left outer join (select LM.LocalityId,LM.LocalityName,LS.SubdivCode,SD.SubDivDescription,DM.DistrictName from dbo.localitymaster LM inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join SubDivMaster SD on SD.SubdivCode=LS.SubDivCode inner join dbo.districtmaster DM on DM.districtcode=SD.districtcode where DM.deptcode=@deptcode ) b on b.LocalityId=a.LocalityId where b.LocalityId is null order by DistrictName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
            Cmd.Parameters.AddWithValue("@revdeptcode", (int)Department.Dept001);
            Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
            Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
            model.dta = data.GetDataTable(Cmd);

            model.DeptCode = Sessions.getEmployeeUser().DeptCode;
            if (TempData[Constant._ActionMessage] != null) { ViewBag.message = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult MapLocality(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            if (ModelState.IsValid)
            {
                string checkboxvalue = frm["chkMyCHeck"];
                string[] Values = checkboxvalue.Split(',');
                for (int i = 0; i < Values.Length; i++)
                {
                    string Qry = "insert into dbo.localitytosubdivmaster(localityid,subdivcode,whetheractive,userid,ipaddress,actiondatetime) values(@localityid,@subdivcode,@whetheractive,@userid,@ipaddress,now())";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@localityid", (Values[i]).ToString());
                    Cmd.Parameters.AddWithValue("@subdivcode", model.LocalityMaster.SubDivCode);
                    Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    if (Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept002).ToString() || Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept008).ToString())
                    {
                        Qry = "insert into dbo.localitytoconstituencymaster(localityid,ConstituencyId,DeptCode,whetheractive,userid,ipaddress,actiondatetime) values(@localityid,@ConstituencyId,@DeptCode,@whetheractive,@userid,@ipaddress,now())";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@localityid", (Values[i]).ToString());
                        Cmd.Parameters.AddWithValue("@ConstituencyId", model.LocalityMaster.ConstituencyId);
                        Cmd.Parameters.AddWithValue("@DeptCode", Sessions.getEmployeeUser().DeptCode);
                        Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                }

                data.SaveData(cmdList);
                PreserveModelState(Constant._ActionMessage, "Provided locality has been successfully Mapped under e-District Delhi. ", false, true);
                return RedirectToAction("MapLocality", "Admin");
            }
            return View("MapLocality", model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult UpdateLocatiltyConstituency()
        {
            AdminModels model = new AdminModels();
            GetData data = new GetData();
            string Qry = "select LM.LocalityId,LM.LocalityName,LS.SubdivCode,SD.SubDivDescription,DM.DistrictName,ACM.ConstituencyID,ConstituencyName from dbo.localitymaster LM inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join localitytoconstituencymaster LCM on LCM.localityid=LM.localityid and LCM.deptcode=@deptcode  inner join assemblyconstituencymaster ACM on ACM.ConstituencyID=LCM.ConstituencyID inner join SubDivMaster SD on SD.SubdivCode=LS.SubDivCode inner join dbo.districtmaster DM on DM.districtcode=SD.districtcode inner join dbo.statemaster SM on SM.stateid=DM.stateid where DM.deptcode=@deptcode and SM.stateid=@StateId and LS.whetheractive=@whetheractive and LM.whetheractive=@whetheractive and ACM.whetheractive=@whetheractive and LCM.whetheractive=@whetheractive order by LocalityName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
            Cmd.Parameters.AddWithValue("@StateId", (int)State.Delhi);
            Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
            model.dta = data.GetDataTable(Cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult UpdateConstituency(Int32 LocalityId, Int32 ConstituencyID)
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();

            string Qry = "select LM.LocalityId,LM.LocalityName,LS.SubdivCode,SD.SubDivDescription,DM.DistrictName,ACM.ConstituencyID,ConstituencyName from dbo.localitymaster LM inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join localitytoconstituencymaster LCM on LCM.localityid=LM.localityid and LCM.deptcode=@deptcode  inner join assemblyconstituencymaster ACM on ACM.ConstituencyID=LCM.ConstituencyID inner join SubDivMaster SD on SD.SubdivCode=LS.SubDivCode inner join dbo.districtmaster DM on DM.districtcode=SD.districtcode inner join dbo.statemaster SM on SM.stateid=DM.stateid where DM.deptcode=@deptcode and SM.stateid=@StateId and LS.whetheractive=@whetheractive and LM.whetheractive=@whetheractive and ACM.whetheractive=@whetheractive and LCM.whetheractive=@whetheractive and LM.localityId=@LocalityId and ACM.ConstituencyID=@ConstituencyID order by LocalityName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
            Cmd.Parameters.AddWithValue("@StateId", (int)State.Delhi);
            Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
            Cmd.Parameters.AddWithValue("@LocalityId", LocalityId);
            Cmd.Parameters.AddWithValue("@ConstituencyID", ConstituencyID);
            model.dta = data.GetDataTable(Cmd);

            model.LocalityId = LocalityId.ToString();
            model.ConstituencyID = ConstituencyID.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateConstituency(AdminModels model)
        {
            GetData data = new GetData();
            string Qry = string.Empty;
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            if (ModelState.IsValid)
            {
                Qry = "select ApplicantLocalityId from web.ApplicationDetails where ApplicantLocalityId=@LocalityId and ServiceCode in (select Servicecode from Servicemaster Where Deptcode=@Deptcode) ";
                NpgsqlCommand Cmd1 = new NpgsqlCommand(Qry);
                Cmd1.Parameters.AddWithValue("@LocalityId", model.LocalityId);
                Cmd1.Parameters.AddWithValue("@Deptcode", Sessions.getEmployeeUser().DeptCode);
                string webLocalityId = data.SelectColumns(Cmd1)[0];

                Qry = "select ApplicantLocalityId from dbo.ApplicationDetails where ApplicantLocalityId=@LocalityId and ServiceCode in (select Servicecode from Servicemaster Where Deptcode=@Deptcode) ";
                Cmd1 = new NpgsqlCommand(Qry);
                Cmd1.Parameters.AddWithValue("@LocalityId", model.LocalityId);
                Cmd1.Parameters.AddWithValue("@Deptcode", Sessions.getEmployeeUser().DeptCode);
                string dboLocalityId = data.SelectColumns(Cmd1)[0];

                if (!string.IsNullOrEmpty(webLocalityId) && !string.IsNullOrEmpty(dboLocalityId))
                {
                    ViewData["message"] = "The modification in Constituency can not be applied becuase Application(s) has been recieved for selected locality.";
                    return View("Message");
                }
                else
                {
                    Qry = "update localitytoconstituencymaster set Whetheractive=@Whetheractive,UserId=@UserId,IpAddress=@IpAddress,actiondatetime=now() where LocalityId=@LocalityId and ConstituencyID=@ConstituencyID and Deptcode=@Deptcode";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@LocalityId", model.LocalityId);
                    Cmd.Parameters.AddWithValue("@ConstituencyID", model.ConstituencyID);
                    Cmd.Parameters.AddWithValue("@Whetheractive", CustomText.False.ToString());
                    Cmd.Parameters.AddWithValue("@Deptcode", Sessions.getEmployeeUser().DeptCode);
                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    Qry = "insert into dbo.localitytoconstituencymaster(LocalityId,ConstituencyID,Deptcode,Whetheractive,UserId,IpAddress,actiondatetime)values(@LocalityId,@ConstituencyID,@Deptcode,@Whetheractive,@UserId,@IpAddress,now())";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@LocalityId", model.LocalityId);
                    Cmd.Parameters.AddWithValue("@ConstituencyID", model.UpdatedConstituencyID);
                    Cmd.Parameters.AddWithValue("@Whetheractive", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@Deptcode", Sessions.getEmployeeUser().DeptCode);
                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                }

                data.SaveData(cmdList);
                ViewData["message"] = "Constituency Updated sucessfully!!!";
                return View("Message");
            }
            return View("UpdateConstituency", model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult CarryForwardLocality(int localityid)
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            model.LocalityMaster = new LocalityMaster();
            if (ModelState.IsValid)
            {
                string[] Array = Utility.SelectColumnsValue("localitymaster", "localityname,localityid", "localityid", localityid.ToString());
                model.LocalityMaster.LocalityName = Array[0];
                model.LocalityMaster.LocalityId = Array[1];
                return View(model);
            }
            return View("LocalityManagement", model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult CarryForwardLocality(AdminModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                
                if (Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept001).ToString())
                {
                    // first deactivate the status of existing locality
                    string Qry = @"Update LocalityMaster set whetheractive=@whetheractive,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where localityid=@localityid; Update localitytosubdivmaster set whetheractive=@whetheractive,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where localityid=@localityid;";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@localityid", model.LocalityMaster.LocalityId);
                    Cmd.Parameters.AddWithValue("@whetheractive", CustomText.FALSE.ToString());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    data.UpdateData(Cmd);
                    //cmdList.Add(Cmd);

                    // insert same locality with new auto id
                    Qry = "insert into dbo.LocalityMaster(LocalityName,whetheractive,userid,ipaddress,actiondatetime) values(@LocalityName,@whetheractive,@userid,@ipaddress,now()); SELECT currval(pg_get_serial_sequence('dbo.LocalityMaster','localityid'))";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@LocalityName", model.LocalityMaster.LocalityName);
                    Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    // insert mapping in subdivision
                    Qry = "insert into dbo.localitytosubdivmaster(localityid,subdivcode,whetheractive,userid,ipaddress,actiondatetime) values(@LastInsertedId,@subdivcode,@whetheractive,@userid,@ipaddress,now())";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@subdivcode", model.LocalityMaster.SubDivCode);
                    Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    data.SaveTransactionalData(cmdList);

                    //send sms to Other Department Admin and insert record in table
                    Qry = "select Contactno from usermaster where permission=@permission and deptcode<>@DeptCode and Contactno is not null ";
                    NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@permission", ((int)Permission.P118).ToString());
                    cmd.Parameters.AddWithValue("@DeptCode", Sessions.getEmployeeUser().DeptCode);
                    model.data = data.GetDataTable(cmd);
                    if (model.data != null && model.data.Rows.Count > 0)
                    {
                        for (int i = 0; i < model.data.Rows.Count; i++)
                        {
                            Dictionary<string, string> smsDic = new Dictionary<string, string>();
                            smsDic.Add("ParamMobileNo", model.data.Rows[i]["Contactno"].ToString());
                            data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS048, smsDic));
                        }
                    }

                    ViewBag.DisplayMessage = "Provided locality has been Carry Forward to new selected District and SubdivCode under e-District Delhi.";
                    return View("LocalityManagement", model);
                }
            }
            return View("CarryForwardLocality", model);
        }

        [HttpGet]
        public ActionResult DeactivatedLocalityDetails()
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();

            string Qry = "select DM.DistrictName,SDM.subdivdescription,LM.localityname,LM.pincode,LM.userid as DeactiveBy,to_char(LM.actiondatetime,'DD/MM/YYYY') as DeactiveDate from localitymaster LM inner join localitytosubdivmaster LSM on LSM.localityid=LM.localityid inner join dbo.subdivmaster SDM on SDM.subdivcode=LSM.subdivcode inner join dbo.districtmaster DM on DM.districtcode=SDM.districtcode where LM.whetheractive=@WhetherActive and LM.actiondatetime> @ActionDateTime";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@WhetherActive", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@ActionDateTime", "2018/11/28");
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        #endregion

        #region Caste Management Module
        public ActionResult CasteManagement()
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            AdminModels model = new AdminModels();
            GetData data = new GetData();

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult CasteManagement(AdminModels model)
        {
            GetData data = new GetData();
            string Qry = "select Casteid,CasteName,('chkbox' || cast(Casteid as varchar)) as CasteControlId, ST.StateName,SM.ServiceCode,SM.ServiceName,CM.ResolutionNo,CM.ResolutionDate,CM.CResolutionNo,CM.CResolutionDate,CM.Whetheractive,CM.WhetherCentreCaste from dbo.CasteMaster CM inner join dbo.serviceMaster SM on CM.ServiceCode=SM.ServiceCode left outer join StateMaster ST on CM.Stateid=ST.Stateid where lower(CasteName) like @CasteName ";
            if (!string.IsNullOrEmpty(model.CasteMaster.ServiceCode)) { Qry += " and CM.ServiceCode=@ServiceCode"; }
            if (!string.IsNullOrEmpty(model.CasteMaster.StateId)) { Qry += " and CM.StateId=@StateId"; }
            if (!string.IsNullOrEmpty(model.CasteMaster.ResolutionNo)) { Qry += " and lower(CM.ResolutionNo) like @ResolutionNo"; }
            if (!string.IsNullOrEmpty(model.CasteMaster.ResolutionDate)) { Qry += " and CM.ResolutionDate = @ResolutionDate"; }
            if (!string.IsNullOrEmpty(model.CasteMaster.WhetherCentreCaste)) { Qry += " and CM.WhetherCentreCaste=@WhetherCentreCaste"; }
            if (!string.IsNullOrEmpty(model.CasteMaster.CResolutionNo)) { Qry += " and lower(CM.CResolutionNo) like @CResolutionNo"; }
            if (!string.IsNullOrEmpty(model.CasteMaster.CResolutionDate)) { Qry += " CM.CResolutionDate=@CResolutionDate"; }
            Qry += " order by CasteName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@CasteName", string.Format("%{0}%", model.CasteMaster.CasteName.ToLower()));
            if (!string.IsNullOrEmpty(model.CasteMaster.ServiceCode)) { Cmd.Parameters.AddWithValue("@ServiceCode", model.CasteMaster.ServiceCode); }
            if (!string.IsNullOrEmpty(model.CasteMaster.StateId)) { Cmd.Parameters.AddWithValue("@StateId", model.CasteMaster.StateId); }
            if (!string.IsNullOrEmpty(model.CasteMaster.ResolutionNo)) { Cmd.Parameters.AddWithValue("@ResolutionNo", string.Format("%{0}%", model.CasteMaster.ResolutionNo.ToLower())); }
            if (!string.IsNullOrEmpty(model.CasteMaster.ResolutionDate)) { Cmd.Parameters.AddWithValue("@ResolutionDate", model.CasteMaster.ResolutionDate); }
            if (!string.IsNullOrEmpty(model.CasteMaster.WhetherCentreCaste)) { Cmd.Parameters.AddWithValue("@WhetherCentreCaste", model.CasteMaster.WhetherCentreCaste); }
            if (!string.IsNullOrEmpty(model.CasteMaster.CResolutionNo)) { Cmd.Parameters.AddWithValue("@CResolutionNo", string.Format("%{0}%", model.CasteMaster.CResolutionNo.ToLower())); }
            if (!string.IsNullOrEmpty(model.CasteMaster.CResolutionDate)) { Cmd.Parameters.AddWithValue("@CResolutionDate", model.CasteMaster.CResolutionDate); }
            model.dataS = data.GetDataTable(Cmd);

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult AddNewCaste(AdminModels model)
        {
            if (ModelState.IsValid)
            {
                PreserveModelState(KeyName._Key01, model, false, true);
                return View(model);
            }
            return View("CasteManagement", model);

        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult AddNewCastePost(AdminModels model)
        {

            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                string Qry = "select Casteid,CasteName,('chkbox' || cast(Casteid as varchar)) as CasteControlId, ST.StateName,SM.ServiceCode,SM.ServiceName,CM.ResolutionNo,CM.ResolutionDate,CM.CResolutionNo,CM.CResolutionDate,CM.Whetheractive,CM.WhetherCentreCaste from dbo.CasteMaster CM inner join dbo.serviceMaster SM on CM.ServiceCode=SM.ServiceCode left outer join StateMaster ST on CM.Stateid=ST.Stateid where trim(lower(CasteName))=@CasteName and CM.ServiceCode=@ServiceCode and CM.StateId=@StateId order by CasteName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@StateId", model.CasteMaster.StateId);
                Cmd.Parameters.AddWithValue("@ServiceCode", model.CasteMaster.ServiceCode);
                Cmd.Parameters.AddWithValue("@CasteName", model.CasteMaster.CasteName.ToLower().Trim());
                model.dataS = data.GetDataTable(Cmd);
                if (model.dataS.Rows.Count > 0)
                {
                    ViewBag.DisplayMessage = "The Caste is trying to enter has been already inserted under e-District Delhi.";
                    return View("AddNewCaste", model);
                }
                else
                {
                    Qry = "insert into dbo.castemaster(CasteName,StateId,ServiceCode,ResolutionNo,ResolutionDate,CResolutionNo,CResolutionDate,WhetherCentreCaste,UserId,IpAddress)values(@CasteName,@StateId,@ServiceCode,@ResolutionNo,@ResolutionDate,@CResolutionNo,@CResolutionDate,@WhetherCentreCaste,@UserId,@IpAddress)";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@CasteName", model.CasteMaster.CasteName);
                    Cmd.Parameters.AddWithValue("@StateId", model.CasteMaster.StateId);
                    Cmd.Parameters.AddWithValue("@ServiceCode", model.CasteMaster.ServiceCode);
                    Cmd.Parameters.AddWithValue("@ResolutionNo", model.CasteMaster.ResolutionNo);
                    Cmd.Parameters.AddWithValue("@ResolutionDate", model.CasteMaster.ResolutionDate);
                    Cmd.Parameters.AddWithValue("@CResolutionNo", model.CasteMaster.CResolutionNo);
                    Cmd.Parameters.AddWithValue("@CResolutionDate", model.CasteMaster.CResolutionDate);
                    Cmd.Parameters.AddWithValue("@WhetherCentreCaste", model.CasteMaster.WhetherCentreCaste);
                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    data.UpdateData(Cmd);

                    PreserveModelState(Constant._ActionMessage, "Caste has been added successfully under e-District.", false, true);
                    return RedirectToAction("CasteManagement", "Admin");
                }
            }
            PreserveModelState(KeyName._Key01, model, true, false);
            return View("AddNewCaste", (AdminModels)TempData[KeyName._Key01]);
        }        
        [HttpGet]
        [EncryptedActionParameter]
        public ActionResult UpdateCenterCaste(int? cst)
        {
            AdminModels model = new AdminModels();
            model.CasteMaster = new CasteMaster();
            model.CasteMaster.CasteId = cst.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult UpdateCenterCaste(AdminModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string Qry = "Update dbo.castemaster set WhetherCentreCaste=@WhetherCentreCaste,CResolutionNo=@CResolutionNo,CResolutionDate=@CResolutionDate,UserId=@UserId,IpAddress=@IpAddress,Actiondatetime=now() where casteid=@casteid";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@casteid", model.CasteMaster.CasteId);
                Cmd.Parameters.AddWithValue("@CResolutionNo", model.CasteMaster.CResolutionNo);
                Cmd.Parameters.AddWithValue("@CResolutionDate", model.CasteMaster.CResolutionDate);
                Cmd.Parameters.AddWithValue("@WhetherCentreCaste", model.CasteMaster.WhetherCentreCaste);
                Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                data.UpdateData(Cmd);

                ViewBag.DisplayMessage = "Center Caste has been successfully allowed ";
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "CasteId" }, new ArrayList() { model.CasteMaster.CasteId });
                return RedirectToAction("CasteDetails", "Admin", new { q = QueryString });
            }

            return View("UpdateCenterCaste", model);
        }
        [EncryptedActionParameter]
        public ActionResult CasteDetails(Int32 CasteId)
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            string Qry = "select CM.CasteName,ST.StateId,ST.StateName,SM.ServiceCode,SM.ServiceName,CM.ResolutionNo,CM.ResolutionDate ,CM.CResolutionNo,CM.CResolutionDate,CM.WhetherCentreCaste,CM.Whetheractive,CM.userid,CM.ipaddress,CM.actiondatetime from dbo.CasteMaster CM inner join dbo.serviceMaster SM on CM.ServiceCode=SM.ServiceCode left outer join StateMaster ST on CM.Stateid=ST.Stateid where casteid=@casteid";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@casteid", CasteId);
            model.dta = data.GetDataTable(Cmd);
            return View(model);

        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult EnableCaste(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string checkboxvalue = frm["chkMyCHeck"];
                string[] Values = checkboxvalue.Split(',');
                for (int i = 0; i < Values.Length; i++)
                {
                    string Qry = "Update dbo.CasteMaster set WhetherActive=@WhetherActive,UserId=@UserId,actiondatetime=now(),IpAddress=@IpAddress where Casteid=@Casteid";
                    NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@Casteid", (Values[i]).ToString());
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                    data.UpdateData(cmd);
                }
                PreserveModelState(Constant._ActionMessage, "Caste has been successfully Enabled. ", false, true);
                return RedirectToAction("CasteManagement", "Admin");

            }
            return View("CasteManagement", model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult DisableCaste(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string checkboxvalue = frm["chkMyCHeck"];
                string[] Values = checkboxvalue.Split(',');
                for (int i = 0; i < Values.Length; i++)
                {
                    string Qry = "Update dbo.CasteMaster set WhetherActive=@WhetherActive,UserId=@UserId,actiondatetime=now(),IpAddress=@IpAddress where Casteid=@Casteid";
                    NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@Casteid", (Values[i]).ToString());
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmd.Parameters.AddWithValue("@WhetherActive", CustomText.False.ToString());
                    data.UpdateData(cmd);
                }
                PreserveModelState(Constant._ActionMessage, "Caste has been successfully Disabled. ", false, true);
                return RedirectToAction("CasteManagement", "Admin");

            }
            return View("CasteManagement", model);
        }
        public ActionResult ApproveCaste()
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult CheckApproveCaste(AdminModels model)
        {
            GetData data = new GetData();
            string Qry = "select Casteid,CasteName,('chkbox' || cast(Casteid as varchar)) as CasteControlId, ST.StateName,SM.ServiceCode,SM.ServiceName,CM.ResolutionNo,CM.ResolutionDate,CM.CResolutionNo,CM.CResolutionDate,CM.Whetheractive,CM.WhetherCentreCaste,CM.WhetherApproved from dbo.CasteMaster CM inner join dbo.serviceMaster SM on CM.ServiceCode=SM.ServiceCode left outer join StateMaster ST on CM.Stateid=ST.Stateid where CM.WhetherApproved=@WhetherApproved and CM.ServiceCode=@ServiceCode and CM.StateId=@StateId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ServiceCode", model.CasteMaster.ServiceCode);
            Cmd.Parameters.AddWithValue("@StateId", model.CasteMaster.StateId);
            Cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.FALSE.ToString());
            model.dataS = data.GetDataTable(Cmd);
            return View("ApproveCaste", model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult ApproveCaste(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                ArrayList Values = new ArrayList();
                string Qry = "select CasteId,CasteName,('chkbox' || cast(CasteId as varchar)) as CasteControlId, ST.StateName,SM.ServiceCode,SM.ServiceName,CM.ResolutionNo,CM.ResolutionDate,CM.CResolutionNo,CM.CResolutionDate,CM.Whetheractive,CM.WhetherCentreCaste from dbo.CasteMaster CM inner join dbo.serviceMaster SM on CM.ServiceCode=SM.ServiceCode left outer join StateMaster ST on CM.Stateid=ST.Stateid where WhetherApproved=@WhetherApproved and CM.ServiceCode=@ServiceCode and CM.StateId=@StateId";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@ServiceCode", model.CasteMaster.ServiceCode);
                cmd.Parameters.AddWithValue("@StateId", model.CasteMaster.StateId);
                cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.FALSE.ToString());
                DataTable dta = data.GetDataTable(cmd);
                for (int i = 0; i < dta.Rows.Count; i++)
                {
                    if (frm[dta.Rows[i]["CasteControlId"].ToString()] != null)
                    {
                        Values.Add(frm[dta.Rows[i]["CasteControlId"].ToString()]);
                    }
                    if (Values == null)
                    {
                        return View(model);
                    }
                }
                for (int i = 0; i < Values.Count; i++)
                {
                    Qry = "Update dbo.CasteMaster set WhetherApproved=@WhetherApproved,ApprovedBy=@ApprovedBy,ApprovedDate=now(),ApprovedIpaddress=@ApprovedIpaddress,UserId=@UserId,actiondatetime=now(),IpAddress=@IpAddress where Casteid=@Casteid";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@Casteid", (Values[i]).ToString());
                    cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.True.ToString());
                    cmd.Parameters.AddWithValue("@ApprovedBy", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@ApprovedIpaddress", Utility.GetIP4Address());
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());

                    data.UpdateData(cmd);
                }
                ViewBag.DisplayMessage = "Caste has been successfully Approved";
                Qry = "select Casteid,CasteName,('chkbox' || cast(Casteid as varchar)) as CasteControlId, ST.StateName,SM.ServiceCode,SM.ServiceName,CM.ResolutionNo,CM.ResolutionDate,CM.CResolutionNo,CM.CResolutionDate,CM.Whetheractive,CM.WhetherCentreCaste,CM.WhetherApproved,CM.UserId,CM.IpAddress,CM.ActionDateTime from dbo.CasteMaster CM inner join dbo.serviceMaster SM on CM.ServiceCode=SM.ServiceCode left outer join StateMaster ST on CM.Stateid=ST.Stateid where CM.ServiceCode=@ServiceCode and CM.StateId=@StateId order by CasteName";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@ServiceCode", model.CasteMaster.ServiceCode);
                cmd.Parameters.AddWithValue("@StateId", model.CasteMaster.StateId);
                model.dataS = data.GetDataTable(cmd);
                return View("ApproveCaste", model);

            }
            return View("ApproveCaste", model);
        }
        #endregion

        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult VerifyPAN()
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            string Qry = "select count(enclosureid) as PendingCount from applicantenclosuredetails where DocumentId=@DocumentId and WhetherVerified=@WhetherVerified  and DepartmentId=@DepartmentId and VerifyValueId<>@VerifyValueId";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@DocumentId", (int)DocumentId.PANCard);
            cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@DepartmentId", (int)EnclosureDepartment.IncomTaxDepartment);
            cmd.Parameters.AddWithValue("@VerifyValueId", ((int)WebServiceResponse.NotVerified));
            model.dataS = data.GetDataTable(cmd);

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult VerifyPANPost()
        {
            GetData data = new GetData();
            StringBuilder str = new StringBuilder();
            StringBuilder str1 = new StringBuilder();
            AdminModels model = new AdminModels();
            int k = 0;
            string Qry = "select dbo.udf_general_decrypt(DocumentNo) as DocumentNo from applicantenclosuredetails where DocumentId=@DocumentId and WhetherVerified=@WhetherVerified and DepartmentId=@DepartmentId and VerifyValueId<>@VerifyValueId";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@DocumentId", (int)DocumentId.PANCard);
            cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@DepartmentId", (int)EnclosureDepartment.IncomTaxDepartment);
            cmd.Parameters.AddWithValue("@VerifyValueId", ((int)WebServiceResponse.NotVerified));

            model.dataS = data.GetDataTable(cmd);

            if (model.dataS.Rows.Count % 5 != 0)
            {
                if (model.dataS.Rows.Count < 5)
                {
                    int New = model.dataS.Rows.Count % 5;
                    str.Clear();
                    str.Append("V0116401");
                    for (int j = 0; j < New; j++)
                    {
                        str.Append("^" + model.dataS.Rows[j]["DocumentNo"].ToString());
                    }
                    str1.Append(str + Environment.NewLine);
                }
                else
                {
                    for (int i = 0; i < model.dataS.Rows.Count; i++)
                    {
                        if (i % 5 == 0)
                        {
                            str1.Append(str + Environment.NewLine);
                            str.Clear();
                            str.Append("V0116401");
                            k = i;
                        }
                        str.Append("^" + model.dataS.Rows[i]["DocumentNo"].ToString());

                    }
                    int New = model.dataS.Rows.Count % 5;
                    str.Clear();
                    str.Append("V0116401");
                    for (int j = 0; j < New; j++)
                    {
                        str.Append("^" + model.dataS.Rows[k]["DocumentNo"].ToString());
                        k++;
                    }
                    str1.Append(str + Environment.NewLine);
                }


            }
            else
            {
                for (int i = 0; i < model.dataS.Rows.Count; i++)
                {
                    if (i % 5 == 0)
                    {
                        str1.Append(str + Environment.NewLine);
                        str.Clear();
                        str.Append("V0116401");
                    }
                    str.Append("^" + model.dataS.Rows[i]["DocumentNo"].ToString());
                }
                str1.Append(str + Environment.NewLine);
            }

            MemoryStream memoryStream = new MemoryStream();
            TextWriter tw = new StreamWriter(memoryStream);
            tw.WriteLine(str1);
            tw.Flush();
            tw.Close();

            return File(memoryStream.GetBuffer(), "text/plain", "VerifyPANCard.txt");
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult UploadVerifyPAN()
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult UploadVerifyPAN(AdminModels model, FormCollection frm)
        {
            //Disable update at ApplicantEnclosureDetailsInherit
            return View("Message", ViewData["message"] = "Not able to perform action, please try again later.");

            //Code commented for above line [Do not Delete the code]
            //int x = 0, y = 0, z = 0;
            //GetData data = new GetData();
            //if (ModelState.IsValid)
            //{
            //    string Qry = string.Empty;
            //    string sub = model.OutputPAN.Substring(0, 2);
            //    if (sub == "1^") { model.OutputPAN = model.OutputPAN.Substring(2); }

            //    model.OutputPAN = model.OutputPAN.Replace("^^^^^^^^^", "^^^^");
            //    model.OutputPAN = model.OutputPAN.Replace("^^^^^^^^", "^^^^");
            //    model.OutputPAN = model.OutputPAN.Replace("^^^^^^^", "^^^^");
            //    model.OutputPAN = model.OutputPAN.Replace("^^^^^^", "^^^^");
            //    model.OutputPAN = model.OutputPAN.Replace("^^^^^", "^^^^");
            //    string[] PAN = model.OutputPAN.Split(new string[] { "^^^^" }, StringSplitOptions.None);

            //    for (int i = 0; i < PAN.Length; i++)
            //    {
            //        PAN[i] = PAN[i].Replace("^^^", "^");
            //        PAN[i] = PAN[i].Replace("^^", "^");
            //    }
            //    for (int i = 0; i < PAN.Length; i++)
            //    {
            //        List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            //        string[] PAN1 = PAN[i].Split(new string[] { "^" }, StringSplitOptions.None);
            //        if (PAN1.Length > 1)
            //        {

            //            //Qry = "select dbo.udf_general_decrypt(DocumentNo) as DocumentNo,DepartmentId,DocumentId  from applicantenclosuredetails where dbo.udf_general_decrypt(DocumentNo)=@DocumentNo and DocumentId=@DocumentId and WhetherVerified=@WhetherVerified and DepartmentId=@DepartmentId and VerifyValueId<>@VerifyValueId";
            //            Qry = "select dbo.udf_general_decrypt(DocumentNo) as DocumentNo,DepartmentId,DocumentId  from applicantenclosuredetails where DocumentNo=@DocumentNo and DocumentId=@DocumentId and WhetherVerified=@WhetherVerified and DepartmentId=@DepartmentId and VerifyValueId<>@VerifyValueId";
            //            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            //            cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(PAN1[0].ToString().ToUpper()));
            //            cmd.Parameters.AddWithValue("@DocumentId", (int)DocumentId.PANCard);
            //            cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
            //            cmd.Parameters.AddWithValue("@DepartmentId", (int)EnclosureDepartment.IncomTaxDepartment);
            //            cmd.Parameters.AddWithValue("@VerifyValueId", ((int)WebServiceResponse.NotVerified));
            //            model.dataS = data.GetDataTable(cmd);
            //            if (model.dataS != null && model.dataS.Rows.Count > 0)
            //            {
            //                if (!string.IsNullOrEmpty(model.dataS.Rows[0]["DocumentNo"].ToString()) && PAN1[1].ToString() == "E")
            //                {
            //                    Qry = "INSERT INTO dbo.verificationdatamaster(DocumentNo,Name,DocumentId,DepartmentId,WhetherActive,ActionUserId,ActionIpAddress)VALUES (dbo.udf_general_encrypt(@UniqueID),@Name,@DocumentId,@DepartmentId,@WhetherActive,@ActionUserId,@ActionIpAddress);   SELECT currval(pg_get_serial_sequence('verificationdatamaster','verificationdataid'))";
            //                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            //                    Cmd.Parameters.AddWithValue("@UniqueID", model.dataS.Rows[0]["DocumentNo"].ToString());
            //                    Cmd.Parameters.AddWithValue("@DocumentId", model.dataS.Rows[0]["DocumentId"].ToString());
            //                    Cmd.Parameters.AddWithValue("@DepartmentId", model.dataS.Rows[0]["DepartmentId"].ToString());
            //                    Cmd.Parameters.AddWithValue("@Name", PAN1[2].ToString());
            //                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
            //                    Cmd.Parameters.AddWithValue("@ActionUserId", Sessions.getEmployeeUser().UserId);
            //                    Cmd.Parameters.AddWithValue("@ActionIpAddress", Utility.GetIP4Address());
            //                    cmdList.Add(Cmd);


            //                    //Qry = "update dbo.ApplicantEnclosureDetails set WhetherVerified=@WhetherVerified,VerifyValueId=@VerifyValueId, VerificationDataId=@LastInsertedId where dbo.udf_general_decrypt(DocumentNo)=@DocumentNo";
            //                    Qry = "update dbo.ApplicantEnclosureDetails set WhetherVerified=@WhetherVerified,VerifyValueId=@VerifyValueId, VerificationDataId=@LastInsertedId where DocumentNo=@DocumentNo";
            //                    Cmd = new NpgsqlCommand(Qry);
            //                    Cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(model.dataS.Rows[0]["DocumentNo"].ToString().ToUpper()));
            //                    Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.TRUE.ToString());
            //                    Cmd.Parameters.AddWithValue("@VerifyValueId", (int)WebServiceResponse.Verified);
            //                    cmdList.Add(Cmd);

            //                    data.SaveTransactionalData(cmdList);
            //                    x++;
            //                }
            //                else if (!string.IsNullOrEmpty(model.dataS.Rows[0]["DocumentNo"].ToString()) && PAN1[1].ToString() == "N")
            //                {
            //                    //Qry = "update dbo.ApplicantEnclosureDetails set WhetherVerified=@WhetherVerified,VerifyValueId=@VerifyValueId where dbo.udf_general_decrypt(DocumentNo)=@DocumentNo";
            //                    Qry = "update dbo.ApplicantEnclosureDetails set WhetherVerified=@WhetherVerified,VerifyValueId=@VerifyValueId where DocumentNo=@DocumentNo";
            //                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            //                    Cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(model.dataS.Rows[0]["DocumentNo"].ToString().ToUpper()));
            //                    Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.FALSE.ToString());
            //                    Cmd.Parameters.AddWithValue("@VerifyValueId", (int)WebServiceResponse.NotVerified);
            //                    cmdList.Add(Cmd);

            //                    data.SaveData(cmdList);
            //                    y++;
            //                }
            //                else
            //                {
            //                    ViewBag.DisplayMessage = "Input String Was Not In Correct Format";
            //                }
            //            }
            //            else
            //            {
            //                z++;
            //            }
            //        }
            //    }
            //}
            //ViewBag.DisplayMessage = x + " PAN Card Verified, " + y + " PAN Card Not Verified, " + z + " PAN Cards Not Found on DataBase";
            //return View("UploadVerifyPAN");
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult DateWiseGrievancesSummary()
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            string WhetherCondition = string.Empty;
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode) && Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept001).ToString()) { WhetherCondition += " and AssignedSubdivision=@ParamSubDivCode "; }
            string Qry = "select a.SQueryDate,a.TQueryDate as QueryDate,a.TCountGrievance,case when c.CountPendingGrievance is null then 0 else c.CountPendingGrievance end as CountPendingGrievance ,case when b.CountGrievance is null then 0 else b.CountGrievance end as CountGrievance from (select to_char(QueryDate,'YYYYMMDD') as SQueryDate,to_char(QueryDate,'DD/MM/YYYY') as TQueryDate,count(GrievanceId) as TCountGrievance from  ApplicationGrievances where DepartmentId=@ParamDeptCode " + WhetherCondition + " group by SQueryDate, TQueryDate order by TQueryDate)a LEFT OUTER JOIN (select to_char(QueryDate,'DD/MM/YYYY') as QueryDatee,count(GrievanceId) as CountGrievance from ApplicationGrievances where whetherReplied=@whetherReplied and DepartmentId=@ParamDeptCode " + WhetherCondition + "  group by QueryDatee order by to_char(QueryDate,'DD/MM/YYYY') )b on 1=1 and TQueryDate=QueryDatee LEFT OUTER JOIN (select to_char(QueryDate,'DD/MM/YYYY') as QueryDate1,count(GrievanceId) as CountPendingGrievance from ApplicationGrievances  where whetherReplied=@whetherReplied1 and DepartmentId=@ParamDeptCode " + WhetherCondition + "  group by QueryDate1 order by to_char(QueryDate,'DD/MM/YYYY')) c  on 1=1  and TQueryDate=QueryDate1 order by SQueryDate desc";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@whetherReplied", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@whetherReplied1", CustomText.True.ToString());
            model.dataS = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult ProcessGrievancesDetails(string DTQ, string WQR, string Flag)
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            model.flag = Flag;
            string WhetherCondition = string.Empty;
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode) && Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept001).ToString()) { WhetherCondition += " and AssignedSubdivision=@ParamSubDivCode "; }
            string Qry = "select GrievanceId,ApplicantName,ApplicantMobileNo,ApplicantEmail,QueryDescription,to_char(QueryDate,'DD/MM/YYYY') as QueryDate,RepliedAnswer,whetherReplied,WhetherAssigned,SD.SubDivDescription from ApplicationGrievances AG left outer join dbo.subdivmaster SD on SD.SubDivCode=AG.AssignedSubdivision where to_char(QueryDate,'YYYYMMDD')::date = @QueryDate and DepartmentId=@ParamDeptCode " + WhetherCondition;
            if (!string.IsNullOrEmpty(WQR)) { Qry = Qry + " and whetherReplied=@whetherReplied"; }
            Qry += " order by WhetherAssigned,whetherReplied,GrievanceId";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@QueryDate", Utility.ConvertDateSequenceForDatabase(DTQ, '/', true));
            if (!string.IsNullOrEmpty(WQR)) { cmd.Parameters.AddWithValue("@whetherReplied", WQR); }
            model.dataS = data.GetDataTable(cmd);
            model.QueryDate = DTQ;

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ProcessGrievancesDetails(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            string WhetherCondition = string.Empty;
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode) && Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept001).ToString()) { WhetherCondition += " and AssignedSubdivision=@ParamSubDivCode "; }
            string Qry = "select GrievanceId,ApplicantName,ApplicantMobileNo,ApplicantEmail,QueryDescription from ApplicationGrievances where whetherReplied=@whetherReplied and to_char(QueryDate,'YYYYMMDD')::date = @QueryDate and DepartmentId=@ParamDeptCode" + WhetherCondition;
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@QueryDate", Utility.ConvertDateSequenceForDatabase(model.QueryDate, '/', true));
            cmd.Parameters.AddWithValue("@whetherReplied", CustomText.False.ToString());
            model.dataS = data.GetDataTable(cmd);
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            if (ModelState.IsValid)
            {
                for (int i = 0; i < model.dataS.Rows.Count; i++)
                {
                    if (!string.IsNullOrEmpty(frm["txtGrievanceId" + (i)]))
                    {
                        Qry = "Update dbo.ApplicationGrievances set whetherReplied=@whetherReplied,RepliedAnswer=@RepliedAnswer,RepliedBy=@RepliedBy,RepliedByIpAddress=@RepliedByIpAddress,RepliedDate=now() where GrievanceId=@GrievanceId";
                        NpgsqlCommand Cmd = new NpgsqlCommand(Qry.ToString());
                        Cmd.Parameters.AddWithValue("@GrievanceId", frm["hdnGrievanceId" + (i)].ToString());
                        Cmd.Parameters.AddWithValue("@whetherReplied", CustomText.True.ToString());
                        Cmd.Parameters.AddWithValue("@RepliedAnswer", frm["txtGrievanceId" + (i)].ToString());
                        Cmd.Parameters.AddWithValue("@RepliedBy", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@RepliedByIpAddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                }

                data.SaveData(cmdList);

                // send sms to applicant about status of thier GrievanceId
                for (int i = 0; i < model.dataS.Rows.Count; i++)
                {
                    if (!string.IsNullOrEmpty(frm["txtGrievanceId" + (i)]))
                    {
                        Dictionary<string, string> smsDic = new Dictionary<string, string>();
                        smsDic.Add("ParamRemarks", frm["hdnGrievanceId" + (i)].ToString());
                        smsDic.Add("ParamMobileNo", model.dataS.Rows[i]["ApplicantMobileNo"].ToString());
                        data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS046, smsDic));
                    }
                }

                return RedirectToAction("DateWiseGrievancesSummary");
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult AssignToSubDiv(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            string Qry = "select GrievanceId,ApplicantName,ApplicantMobileNo,ApplicantEmail,QueryDescription from ApplicationGrievances where whetherReplied=@whetherReplied and to_char(QueryDate,'YYYYMMDD')::date = @QueryDate and DepartmentId=@ParamDeptCode ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@QueryDate", Utility.ConvertDateSequenceForDatabase(model.QueryDate, '/', true));
            cmd.Parameters.AddWithValue("@whetherReplied", CustomText.False.ToString());
            model.dataS = data.GetDataTable(cmd);
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            if (ModelState.IsValid)
            {
                for (int i = 0; i < model.dataS.Rows.Count; i++)
                {
                    if (!string.IsNullOrEmpty(frm["SubDivCode" + (i)]))
                    {
                        Qry = "Update dbo.ApplicationGrievances set WhetherAssigned=@WhetherAssigned,AssignedSubdivision=@AssignedSubdivision,AssignedBy=@AssignedBy,AssignedDate=now() where GrievanceId=@GrievanceId";
                        NpgsqlCommand Cmd = new NpgsqlCommand(Qry.ToString());
                        Cmd.Parameters.AddWithValue("@GrievanceId", frm["hdnGrievanceId" + (i)].ToString());
                        Cmd.Parameters.AddWithValue("@WhetherAssigned", CustomText.True.ToString());
                        Cmd.Parameters.AddWithValue("@AssignedSubdivision", frm["SubDivCode" + (i)].ToString());
                        Cmd.Parameters.AddWithValue("@AssignedBy", Sessions.getEmployeeUser().UserId);
                        cmdList.Add(Cmd);
                    }
                }
                data.SaveData(cmdList);
                return RedirectToAction("DateWiseGrievancesSummary", "Admin");
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View("DateWiseGrievancesSummary", model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult SearchAuditTrail()
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SearchAuditTrail(AdminModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string Qry = "select UserId from dbo.usermaster where userid=@userid";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@userid", model.UserMaster.UserId);
                string WhetheruseridExist = data.SelectColumns(Cmd)[0];
                if (string.IsNullOrEmpty(WhetheruseridExist))
                {
                    ViewData["message"] = "Entered User-Id does not exist at e-District Delhi, Kindly check User-Id and try again.";
                    return View("message");
                }
                Qry = "select UM.UserName,UA.UserId,UA.LoginDateTime,UA.LogoutDatetime,UA.MacAddress,UA.IpAddress,UA.ActionValueId,ValueName from dbo.DepartmentLoginTrail UA inner join dbo.UserMaster UM on UA.UserId=UM.UserId inner join dbo.selectmastervaluedetails SMD on SMD.ValueId =UA.ActionValueId where UA.UserId=@UserId and to_char(UA.LoginDateTime,'YYYYMMDD')::date >= @FromDate and to_char(UA.LoginDateTime,'YYYYMMDD')::date <= @ToDate ";
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and UM.DistrictCode=@DistrictCode"; }
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@UserId", model.UserMaster.UserId);
                cmd.Parameters.AddWithValue("@FromDate", Utility.ConvertDateSequenceForDatabase(model.UserMaster.DateFrom, '/', true));
                cmd.Parameters.AddWithValue("@ToDate", Utility.ConvertDateSequenceForDatabase(model.UserMaster.DateTo, '/', true));
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { cmd.Parameters.AddWithValue("@DistrictCode", Sessions.getEmployeeUser().DistrictCode); }
                model.dataS = data.GetDataTable(cmd);
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }

        #region Insert Data From SLA TO ApplicationDetailsEpp Table
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult SaveSLAProcessFile()
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult SaveSLAProcessFile(AdminModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = string.Empty;
                NpgsqlCommand Cmd = null;

                if (model.SLAFile.ContentLength > 0)
                {
                    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                    StreamReader sr = new StreamReader(model.SLAFile.InputStream);
                    StringBuilder str = new StringBuilder();
                    int i = 0, countInsertRow = 0;
                    while (!sr.EndOfStream)
                    {
                        string line = sr.ReadLine();
                        string[] valueHeader;
                        string[] value = line.Split('|');
                        if (i == 0)
                        {
                            valueHeader = line.Split('|');
                            Qry = "SELECT column_name, ordinal_position FROM information_schema.columns WHERE table_schema='dbo' and table_name='applicationdetailsepp'";
                            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                            model.dataS = data.GetDataTable(cmd);
                            for (int j = 0; j < model.dataS.Rows.Count - 1; j++)
                            {
                                if (model.dataS.Rows[j]["column_name"].ToString().ToLower() != value[j].ToString().ToLower())
                                {
                                    ViewData["message"] = "Input File is Changed.<br />Please Create File Data Sequance idno|SnoOfApplication|ApplicantName|fname|Category|OS|DateOfApplication|SubDiv|Status|lng|StatusDate|DistrictCode|address|childname|attestingofficer|dobd|caste|dop|uploaddate|LastActionDateTime|JeevanApplNo|remarks|osname|stcen|DistCode|SubDivcode|ServiceCode|DistName|SubDivName|ServiceName|NSdivcode|Orgstatus|DeptName|RejectionReason|ProcessDate";
                                    return View("SaveSLAProcessFile");
                                }
                            }
                        }
                        else
                        {
                            if (value.Length > 0)
                            {
                                str.Append("," + value[0].ToString());
                                Qry = @"delete from dbo.ApplicationDetailsEpp where idno=@idno; insert into dbo.ApplicationDetailsEpp(idno,snoofapplication,applicantname,fname,category,os,dateofapplication,subdiv,status,lng,statusdate,districtcode,address,childname,attestingofficer,dobd,caste,dop,lastactiondatetime,remarks,osname,stcen,distcode,subdivcode,servicecode,distname,subdivname,servicename,nsdivcode,orgstatus,deptname,rejectionreason,processdate) values(@idno,@snoofapplication,@applicantname,@fname,@category,@os,@dateofapplication,@subdiv,@status,@lng,@statusdate,@districtcode,@address,@childname,@attestingofficer,@dobd,@caste,@dop,@lastactiondatetime,@remarks,@osname,@stcen,@distcode,@subdivcode,@servicecode,@distname,@subdivname,@servicename,@nsdivcode,@Org_status,@deptname,@rejectionreason,now())";
                                Cmd = new NpgsqlCommand(Qry);
                                Cmd.Parameters.AddWithValue("@idno", value[0].ToString());
                                Cmd.Parameters.AddWithValue("@snoofapplication", (value[1].ToString() == "" || value[1].ToString().ToUpper() == "NULL") ? null : value[1].ToString());
                                Cmd.Parameters.AddWithValue("@applicantname", value[2].ToString());
                                Cmd.Parameters.AddWithValue("@fname", value[3].ToString());
                                Cmd.Parameters.AddWithValue("@category", value[4].ToString());
                                Cmd.Parameters.AddWithValue("@os", value[5].ToString());
                                Cmd.Parameters.AddWithValue("@dateofapplication", value[6].ToString());
                                Cmd.Parameters.AddWithValue("@subdiv", value[7].ToString());
                                Cmd.Parameters.AddWithValue("@status", value[8].ToString());
                                Cmd.Parameters.AddWithValue("@lng", value[9].ToString());
                                Cmd.Parameters.AddWithValue("@statusdate", value[10].ToString());
                                Cmd.Parameters.AddWithValue("@districtcode", (value[11].ToString() == "" || value[11].ToString().ToUpper() == "NULL") ? null : value[11].ToString());
                                Cmd.Parameters.AddWithValue("@address", value[12].ToString());
                                Cmd.Parameters.AddWithValue("@childname", value[13].ToString());
                                Cmd.Parameters.AddWithValue("@attestingofficer", value[14].ToString());
                                Cmd.Parameters.AddWithValue("@dobd", value[15].ToString());
                                Cmd.Parameters.AddWithValue("@caste", value[16].ToString());
                                Cmd.Parameters.AddWithValue("@dop", value[17].ToString());
                                Cmd.Parameters.AddWithValue("@lastactiondatetime", value[18].ToString());
                                Cmd.Parameters.AddWithValue("@remarks", value[19].ToString());
                                Cmd.Parameters.AddWithValue("@osname", value[20].ToString());
                                Cmd.Parameters.AddWithValue("@stcen", value[21].ToString());
                                Cmd.Parameters.AddWithValue("@distcode", (value[22].ToString() == "" || value[22].ToString().ToUpper() == "NULL") ? null : value[22].ToString());
                                Cmd.Parameters.AddWithValue("@subdivcode", (value[23].ToString() == "" || value[23].ToString().ToUpper() == "NULL") ? null : value[23].ToString());
                                Cmd.Parameters.AddWithValue("@servicecode", (value[24].ToString() == "" || value[24].ToString().ToUpper() == "NULL") ? null : value[24].ToString());
                                Cmd.Parameters.AddWithValue("@distname", value[25].ToString());
                                Cmd.Parameters.AddWithValue("@subdivname", value[26].ToString());
                                Cmd.Parameters.AddWithValue("@servicename", value[27].ToString());
                                Cmd.Parameters.AddWithValue("@nsdivcode", (value[28].ToString() == "" || value[28].ToString().ToUpper() == "NULL") ? null : value[28].ToString());
                                Cmd.Parameters.AddWithValue("@Org_status", value[29].ToString());
                                Cmd.Parameters.AddWithValue("@rejectionreason", value[31].ToString());
                                Cmd.Parameters.AddWithValue("@deptname", "REVENUE DEPARTMENT");
                                cmdList.Add(Cmd);
                            }
                        }
                        i++;
                        countInsertRow++;
                    }
                    //save all recrods in temp table
                    data.SaveData(cmdList);

                    Qry = "SELECT Count(idno) as TotalRows from applicationdetailsepp";
                    NpgsqlCommand Cmd1 = new NpgsqlCommand(Qry);
                    model.dataSC = data.GetDataTable(Cmd1);

                    ViewData["message"] = "File has been successfully uploaded, Total Rows Inserted : " + countInsertRow + " Total Count in Table : " + model.dataSC.Rows[0]["TotalRows"].ToString();
                    return View("Message");
                }
            }
            return View(model);
        }

        #endregion Insert Data From SLA TO ApplicationDetailsEpp Table
        
        #region Insert Data From SLA TO ApplicationDetailsMarriageEpp Table
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult SaveSLAProcessMarriageFile()
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult SaveSLAProcessMarriageFile(AdminModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = string.Empty;
                NpgsqlCommand Cmd = null;

                if (model.SLAFile.ContentLength > 0)
                {
                    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                    StreamReader sr = new StreamReader(model.SLAFile.InputStream);
                    StringBuilder str = new StringBuilder();
                    int i = 0, countInsertRow = 0;
                    while (!sr.EndOfStream)
                    {
                        string line = sr.ReadLine();
                        string[] valueHeader;
                        string[] value = line.Split('|');
                        if (i == 0)
                        {
                            valueHeader = line.Split('|');
                            Qry = "SELECT column_name, ordinal_position FROM information_schema.columns WHERE table_schema='dbo' and table_name='applicationdetailsmarriageepp'";
                            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                            model.dataS = data.GetDataTable(cmd);
                            for (int j = 0; j < model.dataS.Rows.Count - 2; j++)
                            {
                                if (model.dataS.Rows[j]["column_name"].ToString().ToLower() != value[j].ToString().ToLower())
                                {
                                    ViewData["message"] = "Input File is Changed.<br />Please Create File Data Sequance rectno|dateofapplication|subdivision|husbandname|wifename|dobhusband|dobwife|presentaddresshusband|presentaddresswife|permanentaddresshusband|permanentaddresswife|fathernamehusband|fathernamewife|category|marriageofficer|dateofregistration|whetherissued|subdivisionwife|belongtosubdivision|ctno1|ctno2|userid|lastactiondatetime|ipno|actualissuedatetime|dateofprint|marriagesubdiv|distcode|dateofmarriage|distname";
                                    return View("SaveSLAProcessMarriageFile");
                                }
                            }

                        }
                        else
                        {
                            if (value.Length > 0)
                            {
                                str.Append("," + value[0].ToString());
                                Qry = @"delete from dbo.ApplicationDetailsMarriageEpp where rectno=@rectno and distcode=@distcode; insert into dbo.ApplicationDetailsMarriageEpp(rectno,dateofapplication,subdivision,husbandname,wifename,dobhusband,dobwife,presentaddresshusband,presentaddresswife,permanentaddresshusband,permanentaddresswife,fathernamehusband,fathernamewife,category,marriageofficer,dateofregistration,whetherissued,subdivisionwife,belongtosubdivision,ctno1,ctno2,userid,lastactiondatetime,ipno,actualissuedatetime,dateofprint,marriagesubdiv,distcode,dateofmarriage,distname) values(@rectno,@dateofapplication,@subdivision,@husbandname,@wifename,@dobhusband,@dobwife,@presentaddresshusband,@presentaddresswife,@permanentaddresshusband,@permanentaddresswife,@fathernamehusband,@fathernamewife,@category,@marriageofficer,@dateofregistration,@whetherissued,@subdivisionwife,@belongtosubdivision,@ctno1,@ctno2,@userid,@lastactiondatetime,@ipno,@actualissuedatetime,@dateofprint,@marriagesubdiv,@distcode,@dateofmarriage,@distname)";
                                Cmd = new NpgsqlCommand(Qry);
                                Cmd.Parameters.AddWithValue("@rectno", value[0].ToString());
                                Cmd.Parameters.AddWithValue("@dateofapplication", value[1].ToString());
                                Cmd.Parameters.AddWithValue("@subdivision", value[2].ToString());
                                Cmd.Parameters.AddWithValue("@husbandname", value[3].ToString());
                                Cmd.Parameters.AddWithValue("@wifename", value[4].ToString());
                                Cmd.Parameters.AddWithValue("@dobhusband", value[5].ToString());
                                Cmd.Parameters.AddWithValue("@dobwife", value[6].ToString());
                                Cmd.Parameters.AddWithValue("@presentaddresshusband", value[7].ToString());
                                Cmd.Parameters.AddWithValue("@presentaddresswife", value[8].ToString());
                                Cmd.Parameters.AddWithValue("@permanentaddresshusband", value[9].ToString());
                                Cmd.Parameters.AddWithValue("@permanentaddresswife", value[10].ToString());
                                Cmd.Parameters.AddWithValue("@fathernamehusband", value[11].ToString());
                                Cmd.Parameters.AddWithValue("@fathernamewife", value[12].ToString());
                                Cmd.Parameters.AddWithValue("@category", value[13].ToString());
                                Cmd.Parameters.AddWithValue("@marriageofficer", (value[14].ToString() == "" || value[14].ToString().ToUpper() == "NULL") ? null : value[14].ToString());
                                Cmd.Parameters.AddWithValue("@dateofregistration", value[15].ToString());
                                Cmd.Parameters.AddWithValue("@whetherissued", value[16].ToString());
                                Cmd.Parameters.AddWithValue("@subdivisionwife", value[17].ToString());
                                Cmd.Parameters.AddWithValue("@belongtosubdivision", (value[18].ToString() == "" || value[18].ToString().ToUpper() == "NULL") ? null : value[18].ToString());
                                Cmd.Parameters.AddWithValue("@ctno1", (value[19].ToString() == "" || value[19].ToString().ToUpper() == "NULL") ? null : value[19].ToString());
                                Cmd.Parameters.AddWithValue("@ctno2", (value[20].ToString() == "" || value[20].ToString().ToUpper() == "NULL") ? null : value[20].ToString());
                                Cmd.Parameters.AddWithValue("@userid", (value[21].ToString() == "" || value[21].ToString().ToUpper() == "NULL") ? null : value[21].ToString());
                                Cmd.Parameters.AddWithValue("@lastactiondatetime", value[22].ToString());
                                Cmd.Parameters.AddWithValue("@ipno", (value[23].ToString() == "" || value[23].ToString().ToUpper() == "NULL") ? null : value[23].ToString());
                                Cmd.Parameters.AddWithValue("@actualissuedatetime", value[24].ToString());
                                Cmd.Parameters.AddWithValue("@dateofprint", value[25].ToString());
                                Cmd.Parameters.AddWithValue("@marriagesubdiv", (value[26].ToString() == "" || value[26].ToString().ToUpper() == "NULL") ? null : value[26].ToString());
                                Cmd.Parameters.AddWithValue("@distcode", value[27].ToString());
                                Cmd.Parameters.AddWithValue("@dateofmarriage", value[28].ToString());
                                Cmd.Parameters.AddWithValue("@distname", value[29].ToString());
                                Cmd.Parameters.AddWithValue("@deptname", "REVENUE DEPARTMENT");
                                cmdList.Add(Cmd);

                            }
                        }
                        i++;
                        countInsertRow++;
                    }
                    //save all recrods in temp table
                    data.SaveData(cmdList);

                    Qry = "SELECT Count(rectno) as TotalRows from ApplicationDetailsMarriageEpp";
                    NpgsqlCommand Cmd1 = new NpgsqlCommand(Qry);
                    model.dataSC = data.GetDataTable(Cmd1);

                    ViewData["message"] = "File has been successfully uploaded, Total Rows Inserted : " + countInsertRow + " Total Count in Table : " + model.dataSC.Rows[0]["TotalRows"].ToString();
                    return View("Message");
                }
            }
            return View(model);
        }
        #endregion Insert Data From SLA TO ApplicationDetailsEpp Table

        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult SendSMS(string MobileNo)
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SendSMS(AdminModels model)
        {
            if (ModelState.IsValid)
            {
                model.flag = string.Empty;

                if (model.MobileNo.Length > 10 && model.MobileNo.Trim().Substring(0, 15) == "ACTIVATE SCRIPT")
                {
                    string[] arrScript = model.MobileNo.Trim().Split(':');
                    if (arrScript.Length > 0)
                    {
                        if (!string.IsNullOrEmpty(arrScript[1]))
                        {
                            GetData data = new GetData();
                            string Qry = arrScript[1].Trim();
                            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                            DataTable dt = data.GetDataTable(Cmd);
                            if (dt.Rows.Count > 0)
                            {
                                for (int i = 0; i < dt.Rows.Count; i++)
                                {
                                    dt.Rows[i][0] = dt.Rows[i][0].ToString().Trim(); //sanitize
                                    if (Regex.IsMatch(dt.Rows[i][0].ToString(), @"(\d+){10,10}"))
                                    {
                                        bool WhetherSend = Utility.IsSmsSent(dt.Rows[i][0].ToString(), model.Message);
                                        if (WhetherSend)
                                        {
                                            Utility.InsertPushSmsDetails(model.Message, dt.Rows[i][0].ToString(), WhetherSend);
                                        }
                                        else { model.flag += dt.Rows[i][0].ToString() + ", "; }
                                    }
                                    else { model.flag += dt.Rows[i][0].ToString() + ", "; }
                                }
                            }
                            if (!string.IsNullOrEmpty(model.flag)) { model.flag = model.flag.Trim().TrimEnd(','); } else { ViewBag.Message = "Message sent successfully"; }
                        }
                    }
                }
                else
                {
                    string[] arrMobileNo = model.MobileNo.Trim().Split(',');
                    for (int i = 0; i < arrMobileNo.Length; i++)
                    {
                        arrMobileNo[i] = arrMobileNo[i].Trim();

                        if (Regex.IsMatch(arrMobileNo[i], @"(\d+){10,10}")) {
                            bool WhetherSend = Utility.IsSmsSent(arrMobileNo[i], model.Message);
                            if (WhetherSend) { Utility.InsertPushSmsDetails(model.Message, arrMobileNo[i], WhetherSend); } else { model.flag += arrMobileNo[i] + ", "; }
                        } else { 
                            model.flag += arrMobileNo[i] + ", "; 
                        }
                    }
                    if (!string.IsNullOrEmpty(model.flag)) { model.flag = model.flag.Trim().TrimEnd(','); } else { ViewBag.Message = "Message sent successfully"; }
                }
            }
            return View(model);
        }

        [EncryptedActionParameter]
        public ActionResult AddProcess(int? RequestId)
        {
            AdminModels model = new AdminModels();
            string Qry = string.Empty;
            NpgsqlCommand Cmd = new NpgsqlCommand();
            model.CRRequestDetails = new CRRequestDetails();
            if (RequestId == null)
            {
                Qry = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId and s1.valueid<>@ValueId order by s1.valuename";

            }
            else
            {
                Qry = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId and s1.valueid=@ValueId order by s1.valuename";
                model.CRRequestDetails.RequestId = RequestId.ToString();
            }
            Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.ProcessOption);
            Cmd.Parameters.AddWithValue("@ValueId", (int)ValueId.ChangeRequest);
            List<SelectValueMaster> ProcessTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
            model.ProcessTypeList = new SelectList(ProcessTypeList, "SelectValueId", "SelectValueName");
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult AddProcess(AdminModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string RequestId = model.CRRequestDetails.RequestId;

                List<CMDInfoList> cmdList = new List<CMDInfoList>();
                CMDInfoList CmdInfo = new CMDInfoList();

                HttpPostedFile file = System.Web.HttpContext.Current.Request.Files["ScannedFile"];
                byte[] fileData = Utility.CompareFileCapturePhotoData(null, file);
                string ContentType = file.ContentType;

                string Qry = "insert into dbo.processhistorydetails(processvalueid,subject,concernedperson,descreption,documentdata,contenttype,performeddate,ConcernedDept,userid,ipaddress,actiondatetime) values(@processvalueid,@subject,@concernedperson,@descreption,@documentdata,@contenttype,@performeddate,@ConcernedDept,@userid,@ipaddress,now()) ; SELECT currval(pg_get_serial_sequence('dbo.processhistorydetails','detailsid'))";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@processvalueid", model.ProcessId);
                Cmd.Parameters.AddWithValue("@subject", model.Subject);
                Cmd.Parameters.AddWithValue("@concernedperson", model.ConcernedPerson);
                Cmd.Parameters.AddWithValue("@descreption", model.Description);
                Cmd.Parameters.AddWithValue("@documentdata", fileData);
                Cmd.Parameters.AddWithValue("@contenttype", ContentType);
                Cmd.Parameters.AddWithValue("@performeddate", Utility.GetDateYYYYMMDD(model.PerformedDate, '/', "0/1/2"));
                Cmd.Parameters.AddWithValue("@ConcernedDept", model.DeptCode);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                CmdInfo = new CMDInfoList();
                CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = null; CmdInfo.Returns = true;
                cmdList.Add(CmdInfo);

                if (RequestId != null)
                {
                    Qry = "update CRRequestDetails set ProcessId=@Parameter0 where RequestId=@RequestId";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@RequestId", RequestId);
                    CmdInfo = new CMDInfoList();
                    CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = new int[] { 0 }; CmdInfo.Returns = false;
                    cmdList.Add(CmdInfo);
                }

                data.SaveTransactionalDataCustom(cmdList);

                ViewData["message"] = "Your Request has been upload successfully";
                return View("message");
            }

            string qry = string.Empty;
            NpgsqlCommand cmd = new NpgsqlCommand();
            if (model.CRRequestDetails.RequestId == null)
            {
                qry = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId and s1.valueid<>@ValueId order by s1.valuename";

            }
            else
            {
                qry = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId and s1.valueid=@ValueId order by s1.valuename";
            }
            cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(qry));
            cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.ProcessOption);
            cmd.Parameters.AddWithValue("@ValueId", (int)ValueId.ChangeRequest);
            List<SelectValueMaster> ProcessTypeList = SelectValueMaster.List<SelectValueMaster>(cmd);
            model.ProcessTypeList = new SelectList(ProcessTypeList, "SelectValueId", "SelectValueName");

            return View("AddProcess", model);
        }
        public ActionResult ViewProcess()
        {
            AdminModels model = new AdminModels();

            string Qry = string.Empty;
            NpgsqlCommand cmd = new NpgsqlCommand();
            Qry = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
            cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.ProcessOption);
            List<SelectValueMaster> ProcessTypeList = SelectValueMaster.List<SelectValueMaster>(cmd);
            model.ProcessTypeList = new SelectList(ProcessTypeList, "SelectValueId", "SelectValueName");

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult ViewProcess(AdminModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string Qry = "select detailsid,processvalueid,s1.valuename,subject,concernedperson,descreption,to_char(performeddate,'DD/MM/YYYY') as performdate,case when documentdata is null then false else true end as fileexist,DM.deptname from processhistorydetails PM left outer join dbo.deptmaster DM on PM.concerneddept=DM.deptcode left outer join selectmastervaluedetails s1 on s1.valueid=PM.processvalueid";
                if (!string.IsNullOrEmpty(model.ProcessId)) { Qry += " where processvalueid=@processvalueid "; }
                Qry += " order by performeddate desc";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                if (!string.IsNullOrEmpty(model.ProcessId)) { Cmd.Parameters.AddWithValue("@processvalueid", model.ProcessId); }
                model.dataS = data.GetDataTable(Cmd);

                Qry = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.ProcessOption);
                List<SelectValueMaster> ProcessTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                model.ProcessTypeList = new SelectList(ProcessTypeList, "SelectValueId", "SelectValueName");

                return View("ViewProcess", model);
            }

            return View("ViewProcess", model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult ViewAttachment(int Val)
        {
            GetData data = new GetData();
            Byte[] byteArray;
            string ContentType = string.Empty;
            string Qry = "select documentdata,contenttype from processhistorydetails where detailsid=@detailsid ";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@detailsid", Val);
            DataTable AttachedData = data.GetDataTable(Cmd);
            if (AttachedData.Rows.Count > 0)
            {
                try
                {
                    byteArray = (Byte[])AttachedData.Rows[0]["documentdata"];
                    ContentType = AttachedData.Rows[0]["contenttype"].ToString();
                }
                catch
                {
                    byteArray = Utility.ImageToByteArrayFromFilePath(Server.MapPath(ImageList.NoImage));
                    ContentType = "image/jpeg";
                }
            }
            else
            {
                byteArray = Utility.ImageToByteArrayFromFilePath(Server.MapPath(ImageList.NoImage));
                ContentType = "image/jpeg";
            }
            return File(byteArray, ContentType);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult RequestedLocality()
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            string Qry = "select LocalityName,Landmark,pincode,to_char(actiondatetime,'DD/MM/YYYY') as actiondatetime from dbo.newlocalitydetails";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            model.dataS = data.GetDataTable(Cmd);
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult SearchForLogoutUserDetails()
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult SearchForLogoutUserDetails(AdminModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();

                string Qry = "select userid from useronlinedetails where userid=@userid";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@userid", model.UserMaster.UserId);
                model.dataS = data.GetDataTable(cmd);
                if (model.dataS.Rows.Count > 0)
                {
                    string IsUserIdExist = Utility.SelectColumnsValue("useronlinedetails", "userid", "userid", model.UserMaster.UserId)[0];
                    if (string.IsNullOrEmpty(IsUserIdExist)) { Utility.InsertUserId(model.UserMaster.UserId); }

                    Qry = "update useronlinedetails set maxloginattempt=@maxloginattempt,whetherlogout=@whetherlogout where userid=@userid";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@userid", model.UserMaster.UserId);
                    cmd.Parameters.AddWithValue("@maxloginattempt", (int)CustomValue.No);
                    cmd.Parameters.AddWithValue("@whetherlogout", CustomText.True.ToString());
                    data.UpdateData(cmd);

                    ViewData["message"] = "Userid has been Logout successfully";
                }
                else
                {
                    ViewData["message"] = "User has been already Logged-out or does not exist under e-District Delhi.";
                }

                PreserveModelState(Constant._ModelStateParent, model, false, true);
                return View("message");
            }
            return View("SearchForLogoutUserDetails", model);
        }

        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult SendWarnSMS()
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SendWarnSMS(AdminModels model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    if (model.SMSTypeId == ((int)ValueId.IncompleteRegistration).ToString())
                    {
                        GetData data = new GetData();
                        string Qry = "select tempregistrationid,applicantmobileno,((date_part('day',(now()-RegistrationDate::date))) >30) as RegistrationDate from web.registrationmastertemp where ((date_part('day',(now()-RegistrationDate::date))) >30)=TRUE ";
                        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                        DataTable dt = data.GetDataTable(Cmd);
                        if (dt.Rows.Count > 0)
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                if (dt.Rows[i]["RegistrationDate"].ToString() == CustomText.True.ToString())
                                {
                                    Qry = "update web.registrationmastertemp set whetherdeactiveinformed=TRUE,ActionPerformedBy=@ActionPerformedBy where tempregistrationid=@tempregistrationid";
                                    Cmd = new NpgsqlCommand(Qry);
                                    Cmd.Parameters.AddWithValue("@tempregistrationid", dt.Rows[i]["tempregistrationid"].ToString());
                                    Cmd.Parameters.AddWithValue("@ActionPerformedBy", Sessions.getEmployeeUser().UserId);
                                    data.UpdateData(Cmd);

                                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                    smsDic.Add("ParamMobileNo", dt.Rows[i]["applicantmobileno"].ToString());
                                    data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS016, smsDic));
                                }
                            }
                            ViewData["message"] = "Warning SMS has been send";
                            return View("message");
                        }
                        else
                        {
                            ViewBag.DisplayMessage = "There is no Profile to send SMS";
                            return View(model);
                        }
                    }
                    else if (model.SMSTypeId == ((int)ValueId.IncompleteApplication).ToString())
                    {
                        GetData data = new GetData();
                        string Qry = "select applicantmobileno,ApplicationId,((date_part('day',(now()-ApplicationDate::date)))>30) as ApplicationDate from web.applicationdetails where applicationno is null and ApplicationStatusId in(@WEBPEN,@PENPHO,@PENREV) and  ((date_part('day',(now()-ApplicationDate::date))) >30)=TRUE limit 10;";
                        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@WEBPEN", (int)Status.WEBPENC);
                        Cmd.Parameters.AddWithValue("@PENPHO", (int)Status.SCOM029);
                        Cmd.Parameters.AddWithValue("@PENREV", (int)Status.SCOM033);
                        DataTable dt = data.GetDataTable(Cmd);
                        if (dt.Rows.Count > 0)
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                if (dt.Rows[i]["ApplicationDate"].ToString() == CustomText.True.ToString())
                                {
                                    Qry = "update web.applicationdetails set whetherdeactiveinformed=true where ApplicationId=@ApplicationId";
                                    Cmd = new NpgsqlCommand(Qry);
                                    Cmd.Parameters.AddWithValue("@ApplicationId", dt.Rows[i]["ApplicationId"].ToString());
                                    data.UpdateData(Cmd);

                                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                    smsDic.Add("ParamMobileNo", dt.Rows[i]["applicantmobileno"].ToString());
                                    data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS017, smsDic));
                                }

                            }
                            ViewData["message"] = "Warning SMS has been send";
                            return View("message");
                        }
                        else
                        {
                            ViewBag.DisplayMessage = "There is no Application to send SMS";
                            return View(model);
                        }
                    }
                    else if (model.SMSTypeId == ((int)ValueId.SendSmsPendingDocSeen).ToString())
                    {
                        GetData data = new GetData();
                        List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                        string Qry = "select ApplicantMobileNo,ApplicationNo from ApplicationDetails AD Inner join StatusMaster SM on AD.ApplicationSTatusId=SM.StatusId  where AD.servicecode not in (select servicecode from servicemaster where deptcode in(@Dept009,@Dept010)) and ApplicationSourceId=@ApplicationSourceId and WhetherDocumentSeen=@WhetherDocumentSeen and applicationstatusId in (3,5,7,21,42,41)  and receivedpermission=@ReceivedperMission and  ApplicationDate >= (select lastupdatedate from lastupdatemaster where mastervalueid=@MasterValueId) and SM.whetheractive=@whetheractive limit 1000";
                        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@Dept009", (int)Department.Dept009);
                        Cmd.Parameters.AddWithValue("@Dept010", (int)Department.Dept010);
                        Cmd.Parameters.AddWithValue("@ApplicationSourceId", (int)ApplicationSource.Online);
                        Cmd.Parameters.AddWithValue("@WhetherDocumentSeen", CustomText.False.ToString());
                        Cmd.Parameters.AddWithValue("@whetheractive", CustomText.True.ToString());
                        Cmd.Parameters.AddWithValue("@MasterValueId", (int)ValueId.SendSmsPendingDocSeen);
                        Cmd.Parameters.AddWithValue("@ReceivedperMission", (int)Permission.CITZ);
                        DataTable dt = data.GetDataTable(Cmd);
                        if (dt.Rows.Count > 0)
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                smsDic.Add("ParamApplicationNo", dt.Rows[i]["ApplicationNo"].ToString());
                                smsDic.Add("ParamMobileNo", dt.Rows[i]["ApplicantMobileNo"].ToString());
                                cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS015, smsDic));
                            }
                            Qry = "Delete from lastupdatemaster where MasterValueId=@MasterValueId";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@MasterValueId", (int)ValueId.SendSmsPendingDocSeen);
                            cmdList.Add(Cmd);

                            Qry = "INSERT INTO  lastupdatemaster( MasterValueId,lastupdatedate,tablename, whetheractive) values(@MasterValueId,now(),'pushsmsdetais',@WhetherActive)";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@MasterValueId", (int)ValueId.SendSmsPendingDocSeen);
                            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
                            cmdList.Add(Cmd);

                            data.SaveData(cmdList);
                            ViewData["message"] = "Pending For Document Seen SMS has been send";
                            return View("message");
                        }
                        else
                        {
                            ViewBag.DisplayMessage = "There is no Application to send SMS";
                            return View(model);
                        }

                    }
                    else if (model.SMSTypeId == ((int)ValueId.InternalSMS).ToString())
                    {
                        GetData data = new GetData();
                        List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                        // Notification of new partition of Citizen Supporting Documents tables
                        string RemoteQry = string.Format("select partitionid,case when emailsentdate is null then 1 when ((date_part(''day'',(now()-emailsentdate::date))) >5) then 0 else 1 end as whethersendrequired,case when emailsentdate is null then 1 else 0 end as isupdaterequired,schemaname,tablename,servername,dbname from dbo.tablepartitionmaster where whetherlast={0}", CustomText.TRUE.ToString());
                        StringBuilder RemoteScript = new StringBuilder("select * from dblink('");
                        RemoteScript.Append(ForeignServer._ForeignServer02);
                        RemoteScript.Append("'::text, '");
                        RemoteScript.Append(RemoteQry);
                        RemoteScript.Append("'::text)  as tablepartition(partitionid int,whethersendrequired int,isupdaterequired int,schemaname text,tablename text,servername text,dbname text)");//changes2806
                        NpgsqlCommand Cmd = new NpgsqlCommand(RemoteScript.ToString());
                        DataTable dt = data.GetDataTable(Cmd);
                        if (dt.Rows.Count > 0)
                        {
                            if (dt.Rows[0]["whethersendrequired"].ToString() == ((int)CountList.Type001).ToString())
                            {
                                string qrygetmobile = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                                NpgsqlCommand Cmdmobile = new NpgsqlCommand(qrygetmobile);
                                Cmdmobile.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SendSms);
                                DataTable dtmobile = data.GetDataTable(Cmdmobile);
                                for (int i = 0; i < dtmobile.Rows.Count; i++)
                                {
                                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                    smsDic.Add("ParamSchemaName", dt.Rows[0]["schemaname"].ToString());
                                    smsDic.Add("ParamTableName", dt.Rows[0]["tablename"].ToString());
                                    smsDic.Add("ParamServerName", dt.Rows[0]["servername"].ToString());
                                    smsDic.Add("ParamDbName", dt.Rows[0]["dbname"].ToString());
                                    smsDic.Add("ParamMobileNo", dtmobile.Rows[i]["SelectValueName"].ToString());
                                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS024, smsDic));
                                }

                                string qrygetemail = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                                NpgsqlCommand Cmdemail = new NpgsqlCommand(qrygetemail);
                                Cmdemail.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SendEmail);
                                DataTable dtemail = data.GetDataTable(Cmdemail);
                                for (int i = 0; i < dtemail.Rows.Count; i++)
                                {
                                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                    smsDic.Add("ParamEmail", dtemail.Rows[i]["SelectValueName"].ToString());
                                    smsDic.Add("ParamSchemaName", dt.Rows[0]["schemaname"].ToString());
                                    smsDic.Add("ParamTableName", dt.Rows[0]["tablename"].ToString());
                                    smsDic.Add("ParamServerName", dt.Rows[0]["servername"].ToString());
                                    smsDic.Add("ParamDbName", dt.Rows[0]["dbname"].ToString());
                                    smsDic.Add("ParamServerId", ((int)CountList.Type001).ToString());
                                    cmdList.Add(Utility.ApplicationProcessEmail((int)CountList.Type002, smsDic));
                                }

                                if (dt.Rows[0]["isupdaterequired"].ToString() == ((int)CountList.Type001).ToString())
                                {
                                    RemoteQry = string.Format("update tablepartitionmaster set emailsentdate=now(),lastupdatedate=now() where partitionid={0};", dt.Rows[0][0].ToString());
                                    RemoteScript = new StringBuilder("select dblink_exec('");
                                    RemoteScript.Append(ForeignServer._ForeignServer02);
                                    RemoteScript.Append("'::text, '");
                                    RemoteScript.Append(RemoteQry);
                                    RemoteScript.Append("'::text);");
                                    RemoteScript.Append("select 1;");
                                    Cmd = new NpgsqlCommand(RemoteScript.ToString());
                                    cmdList.Add(Cmd);
                                }

                                data.SaveData(cmdList);
                            }
                            else
                            {
                                ViewBag.DisplayMessage = "No new partition created for last 5 days.";
                                return View(model);
                            }
                        }
                        else
                        {
                            ViewBag.DisplayMessage = "Something gone wrong, please contact to Administrator.";
                            return View(model);
                        }


                        // Notification of new partition of Digitally Signed Certificates tables
                        RemoteQry = string.Format("select partitionid,case when emailsentdate is null then 1 when ((date_part(''day'',(now()-emailsentdate::date))) >5) then 0 else 1 end as whethersendrequired,case when emailsentdate is null then 1 else 0 end as isupdaterequired,schemaname,tablename,servername,dbname from dsgn.tablepartitionmaster where whetherlast={0}", CustomText.TRUE.ToString());//changes2806
                        RemoteScript = new StringBuilder("select * from dblink('");
                        RemoteScript.Append(ForeignServer._ForeignServer01);
                        RemoteScript.Append("'::text, '");
                        RemoteScript.Append(RemoteQry);
                        RemoteScript.Append("'::text)  as tablepartition(partitionid int,whethersendrequired int,isupdaterequired int,schemaname text,tablename text,servername text,dbname text)");
                        Cmd = new NpgsqlCommand(RemoteScript.ToString());
                        dt = data.GetDataTable(Cmd);
                        if (dt.Rows.Count > 0)
                        {
                            if (dt.Rows[0]["whethersendrequired"].ToString() == ((int)CountList.Type001).ToString())
                            {
                                string qrygetmobile = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                                NpgsqlCommand Cmdmobile = new NpgsqlCommand(qrygetmobile);
                                Cmdmobile.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SendSms);
                                DataTable dtmobile = data.GetDataTable(Cmdmobile);
                                for (int i = 0; i < dtmobile.Rows.Count; i++)
                                {
                                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                    smsDic.Add("ParamMobileNo", dtmobile.Rows[i]["SelectValueName"].ToString());
                                    smsDic.Add("ParamSchemaName", dt.Rows[0]["schemaname"].ToString());
                                    smsDic.Add("ParamTableName", dt.Rows[0]["tablename"].ToString());
                                    smsDic.Add("ParamServerName", dt.Rows[0]["servername"].ToString());
                                    smsDic.Add("ParamDbName", dt.Rows[0]["dbname"].ToString());
                                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS024, smsDic));
                                }

                                string qrygetemail = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                                NpgsqlCommand Cmdemail = new NpgsqlCommand(qrygetemail);
                                Cmdemail.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SendEmail);
                                DataTable dtemail = data.GetDataTable(Cmdemail);
                                for (int i = 0; i < dtemail.Rows.Count; i++)
                                {
                                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                    smsDic.Add("ParamEmail", dtemail.Rows[i]["SelectValueName"].ToString());
                                    smsDic.Add("ParamSchemaName", dt.Rows[0]["schemaname"].ToString());
                                    smsDic.Add("ParamTableName", dt.Rows[0]["tablename"].ToString());
                                    smsDic.Add("ParamServerName", dt.Rows[0]["servername"].ToString());
                                    smsDic.Add("ParamDbName", dt.Rows[0]["dbname"].ToString());
                                    smsDic.Add("ParamServerId", ((int)CountList.Type001).ToString());
                                    cmdList.Add(Utility.ApplicationProcessEmail((int)CountList.Type002, smsDic));
                                }

                                if (dt.Rows[0]["isupdaterequired"].ToString() == ((int)CountList.Type001).ToString())
                                {
                                    RemoteQry = string.Format("update dsgn.tablepartitionmaster set emailsentdate=now(),lastupdatedate=now() where partitionid={0};", dt.Rows[0][0].ToString());
                                    RemoteScript = new StringBuilder("select dblink_exec('");
                                    RemoteScript.Append(ForeignServer._ForeignServer01);
                                    RemoteScript.Append("'::text, '");
                                    RemoteScript.Append(RemoteQry);
                                    RemoteScript.Append("'::text);");
                                    RemoteScript.Append("select 1;");
                                    Cmd = new NpgsqlCommand(RemoteScript.ToString());
                                    cmdList.Add(Cmd);
                                }

                                data.SaveData(cmdList);
                            }
                            else
                            {
                                ViewBag.DisplayMessage = "No new partition created for last 5 days.";
                                return View(model);
                            }
                        }

                        // Notification of new partition of Minor/Small Enclosure tables
                        RemoteQry = string.Format("select partitionid,case when emailsentdate is null then 1 when ((date_part(''day'',(now()-emailsentdate::date))) >5) then 0 else 1 end as whethersendrequired,case when emailsentdate is null then 1 else 0 end as isupdaterequired,schemaname,tablename,servername,dbname from dsgn.tablepartitionmaster where whetherlast={0}", CustomText.TRUE.ToString());
                        RemoteScript = new StringBuilder("select * from dblink('");
                        RemoteScript.Append(ForeignServer._ForeignServer03);
                        RemoteScript.Append("'::text, '");
                        RemoteScript.Append(RemoteQry);
                        RemoteScript.Append("'::text)  as tablepartition(partitionid int,whethersendrequired int,isupdaterequired int,schemaname text,tablename text,servername text,dbname text)");
                        Cmd = new NpgsqlCommand(RemoteScript.ToString());
                        dt = data.GetDataTable(Cmd);
                        if (dt.Rows.Count > 0)
                        {
                            if (dt.Rows[0]["whethersendrequired"].ToString() == ((int)CountList.Type001).ToString())
                            {
                                string qrygetmobile = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                                NpgsqlCommand Cmdmobile = new NpgsqlCommand(qrygetmobile);
                                Cmdmobile.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SendSms);
                                DataTable dtmobile = data.GetDataTable(Cmdmobile);
                                for (int i = 0; i < dtmobile.Rows.Count; i++)
                                {
                                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                    smsDic.Add("ParamMobileNo", dtmobile.Rows[i]["SelectValueName"].ToString());
                                    smsDic.Add("ParamSchemaName", dt.Rows[0]["schemaname"].ToString());
                                    smsDic.Add("ParamTableName", dt.Rows[0]["tablename"].ToString());
                                    smsDic.Add("ParamServerName", dt.Rows[0]["servername"].ToString());
                                    smsDic.Add("ParamDbName", dt.Rows[0]["dbname"].ToString());
                                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS024, smsDic));
                                }

                                string qrygetemail = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                                NpgsqlCommand Cmdemail = new NpgsqlCommand(qrygetemail);
                                Cmdemail.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SendEmail);
                                DataTable dtemail = data.GetDataTable(Cmdemail);
                                for (int i = 0; i < dtemail.Rows.Count; i++)
                                {
                                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                    smsDic.Add("ParamEmail", dtemail.Rows[i]["SelectValueName"].ToString());
                                    smsDic.Add("ParamSchemaName", dt.Rows[0]["schemaname"].ToString());
                                    smsDic.Add("ParamTableName", dt.Rows[0]["tablename"].ToString());
                                    smsDic.Add("ParamServerName", dt.Rows[0]["servername"].ToString());
                                    smsDic.Add("ParamDbName", dt.Rows[0]["dbname"].ToString());
                                    smsDic.Add("ParamServerId", ((int)CountList.Type001).ToString());
                                    cmdList.Add(Utility.ApplicationProcessEmail((int)CountList.Type002, smsDic));
                                }

                                if (dt.Rows[0]["isupdaterequired"].ToString() == ((int)CountList.Type001).ToString())
                                {
                                    RemoteQry = string.Format("update dsgn.tablepartitionmaster set emailsentdate=now(),lastupdatedate=now() where partitionid={0};", dt.Rows[0][0].ToString());
                                    RemoteScript = new StringBuilder("select dblink_exec('");
                                    RemoteScript.Append(ForeignServer._ForeignServer03);
                                    RemoteScript.Append("'::text, '");
                                    RemoteScript.Append(RemoteQry);
                                    RemoteScript.Append("'::text);");
                                    RemoteScript.Append("select 1;");
                                    Cmd = new NpgsqlCommand(RemoteScript.ToString());
                                    cmdList.Add(Cmd);
                                }

                                data.SaveData(cmdList);
                            }
                            else
                            {
                                ViewBag.DisplayMessage = "No new partition created for last 5 days.";
                                return View(model);
                            }
                        }

                        // Notification of new partition of Photograph tables
                        RemoteQry = string.Format("select partitionid,case when emailsentdate is null then 1 when ((date_part(''day'',(now()-emailsentdate::date))) >5) then 0 else 1 end as whethersendrequired,case when emailsentdate is null then 1 else 0 end as isupdaterequired,schemaname,tablename,servername,dbname from dsgn.tablepartitionmaster where whetherlast={0}", CustomText.TRUE.ToString());
                        RemoteScript = new StringBuilder("select * from dblink('");
                        RemoteScript.Append(ForeignServer._ForeignServer04);
                        RemoteScript.Append("'::text, '");
                        RemoteScript.Append(RemoteQry);
                        RemoteScript.Append("'::text)  as tablepartition(partitionid int,whethersendrequired int,isupdaterequired int,schemaname text,tablename text,servername text,dbname text)");
                        Cmd = new NpgsqlCommand(RemoteScript.ToString());
                        dt = data.GetDataTable(Cmd);
                        if (dt.Rows.Count > 0)
                        {
                            if (dt.Rows[0]["whethersendrequired"].ToString() == ((int)CountList.Type001).ToString())
                            {
                                string qrygetmobile = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                                NpgsqlCommand Cmdmobile = new NpgsqlCommand(qrygetmobile);
                                Cmdmobile.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SendSms);
                                DataTable dtmobile = data.GetDataTable(Cmdmobile);
                                for (int i = 0; i < dtmobile.Rows.Count; i++)
                                {
                                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                    smsDic.Add("ParamMobileNo", dtmobile.Rows[i]["SelectValueName"].ToString());
                                    smsDic.Add("ParamSchemaName", dt.Rows[0]["schemaname"].ToString());
                                    smsDic.Add("ParamTableName", dt.Rows[0]["tablename"].ToString());
                                    smsDic.Add("ParamServerName", dt.Rows[0]["servername"].ToString());
                                    smsDic.Add("ParamDbName", dt.Rows[0]["dbname"].ToString());
                                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS024, smsDic));
                                }

                                string qrygetemail = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                                NpgsqlCommand Cmdemail = new NpgsqlCommand(qrygetemail);
                                Cmdemail.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SendEmail);
                                DataTable dtemail = data.GetDataTable(Cmdemail);
                                for (int i = 0; i < dtemail.Rows.Count; i++)
                                {
                                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                    smsDic.Add("ParamEmail", dtemail.Rows[i]["SelectValueName"].ToString());
                                    smsDic.Add("ParamSchemaName", dt.Rows[0]["schemaname"].ToString());
                                    smsDic.Add("ParamTableName", dt.Rows[0]["tablename"].ToString());
                                    smsDic.Add("ParamServerName", dt.Rows[0]["servername"].ToString());
                                    smsDic.Add("ParamDbName", dt.Rows[0]["dbname"].ToString());
                                    smsDic.Add("ParamServerId", ((int)CountList.Type001).ToString());
                                    cmdList.Add(Utility.ApplicationProcessEmail((int)CountList.Type002, smsDic));
                                }

                                if (dt.Rows[0]["isupdaterequired"].ToString() == ((int)CountList.Type001).ToString())
                                {
                                    RemoteQry = string.Format("update dsgn.tablepartitionmaster set emailsentdate=now(),lastupdatedate=now() where partitionid={0};", dt.Rows[0][0].ToString());
                                    RemoteScript = new StringBuilder("select dblink_exec('");
                                    RemoteScript.Append(ForeignServer._ForeignServer04);
                                    RemoteScript.Append("'::text, '");
                                    RemoteScript.Append(RemoteQry);
                                    RemoteScript.Append("'::text);");
                                    RemoteScript.Append("select 1;");
                                    Cmd = new NpgsqlCommand(RemoteScript.ToString());
                                    cmdList.Add(Cmd);
                                }

                                data.SaveData(cmdList);
                            }
                            else
                            {
                                ViewBag.DisplayMessage = "No new partition created for last 5 days.";
                                return View(model);
                            }
                        }

                        // Notification of new partition of Digitally Signed Data of Major/Large Documents tables
                        RemoteQry = string.Format("select partitionid,case when emailsentdate is null then 1 when ((date_part(''day'',(now()-emailsentdate::date))) >5) then 0 else 1 end as whethersendrequired,case when emailsentdate is null then 1 else 0 end as isupdaterequired,schemaname,tablename,servername,dbname from dsgn.tablepartitionmaster where whetherlast={0}", CustomText.TRUE.ToString());
                        RemoteScript = new StringBuilder("select * from dblink('");
                        RemoteScript.Append(ForeignServer._ForeignServer05);
                        RemoteScript.Append("'::text, '");
                        RemoteScript.Append(RemoteQry);
                        RemoteScript.Append("'::text)  as tablepartition(partitionid int,whethersendrequired int,isupdaterequired int,schemaname text,tablename text,servername text,dbname text)");
                        Cmd = new NpgsqlCommand(RemoteScript.ToString());
                        dt = data.GetDataTable(Cmd);
                        if (dt.Rows.Count > 0)
                        {
                            if (dt.Rows[0]["whethersendrequired"].ToString() == ((int)CountList.Type001).ToString())
                            {
                                string qrygetmobile = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                                NpgsqlCommand Cmdmobile = new NpgsqlCommand(qrygetmobile);
                                Cmdmobile.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SendSms);
                                DataTable dtmobile = data.GetDataTable(Cmdmobile);
                                for (int i = 0; i < dtmobile.Rows.Count; i++)
                                {
                                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                    smsDic.Add("ParamMobileNo", dtmobile.Rows[i]["SelectValueName"].ToString());
                                    smsDic.Add("ParamSchemaName", dt.Rows[0]["schemaname"].ToString());
                                    smsDic.Add("ParamTableName", dt.Rows[0]["tablename"].ToString());
                                    smsDic.Add("ParamServerName", dt.Rows[0]["servername"].ToString());
                                    smsDic.Add("ParamDbName", dt.Rows[0]["dbname"].ToString());
                                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS024, smsDic));
                                }

                                string qrygetemail = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                                NpgsqlCommand Cmdemail = new NpgsqlCommand(qrygetemail);
                                Cmdemail.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SendEmail);
                                DataTable dtemail = data.GetDataTable(Cmdemail);
                                for (int i = 0; i < dtemail.Rows.Count; i++)
                                {
                                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                    smsDic.Add("ParamEmail", dtemail.Rows[i]["SelectValueName"].ToString());
                                    smsDic.Add("ParamSchemaName", dt.Rows[0]["schemaname"].ToString());
                                    smsDic.Add("ParamTableName", dt.Rows[0]["tablename"].ToString());
                                    smsDic.Add("ParamServerName", dt.Rows[0]["servername"].ToString());
                                    smsDic.Add("ParamDbName", dt.Rows[0]["dbname"].ToString());
                                    smsDic.Add("ParamServerId", ((int)CountList.Type001).ToString());
                                    cmdList.Add(Utility.ApplicationProcessEmail((int)CountList.Type002, smsDic));
                                }

                                if (dt.Rows[0]["isupdaterequired"].ToString() == ((int)CountList.Type001).ToString())
                                {
                                    RemoteQry = string.Format("update dsgn.tablepartitionmaster set emailsentdate=now(),lastupdatedate=now() where partitionid={0};", dt.Rows[0][0].ToString());
                                    RemoteScript = new StringBuilder("select dblink_exec('");
                                    RemoteScript.Append(ForeignServer._ForeignServer05);
                                    RemoteScript.Append("'::text, '");
                                    RemoteScript.Append(RemoteQry);
                                    RemoteScript.Append("'::text);");
                                    RemoteScript.Append("select 1;");
                                    Cmd = new NpgsqlCommand(RemoteScript.ToString());
                                    cmdList.Add(Cmd);
                                }

                                data.SaveData(cmdList);
                            }
                            else
                            {
                                ViewBag.DisplayMessage = "No new partition created for last 5 days.";
                                return View(model);
                            }
                        }

                        // Notification of new partition of Major/Large Enclosure tables
                        RemoteQry = string.Format("select partitionid,case when emailsentdate is null then 1 when ((date_part(''day'',(now()-emailsentdate::date))) >5) then 0 else 1 end as whethersendrequired,case when emailsentdate is null then 1 else 0 end as isupdaterequired,schemaname,tablename,servername,dbname from dsgn.tablepartitionmaster where whetherlast={0}", CustomText.TRUE.ToString());
                        RemoteScript = new StringBuilder("select * from dblink('");
                        RemoteScript.Append(ForeignServer._ForeignServer06);
                        RemoteScript.Append("'::text, '");
                        RemoteScript.Append(RemoteQry);
                        RemoteScript.Append("'::text)  as tablepartition(partitionid int,whethersendrequired int,isupdaterequired int,schemaname text,tablename text,servername text,dbname text)");
                        Cmd = new NpgsqlCommand(RemoteScript.ToString());
                        dt = data.GetDataTable(Cmd);
                        if (dt.Rows.Count > 0)
                        {
                            if (dt.Rows[0]["whethersendrequired"].ToString() == ((int)CountList.Type001).ToString())
                            {
                                string qrygetmobile = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                                NpgsqlCommand Cmdmobile = new NpgsqlCommand(qrygetmobile);
                                Cmdmobile.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SendSms);
                                DataTable dtmobile = data.GetDataTable(Cmdmobile);
                                for (int i = 0; i < dtmobile.Rows.Count; i++)
                                {
                                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                    smsDic.Add("ParamMobileNo", dtmobile.Rows[i]["SelectValueName"].ToString());
                                    smsDic.Add("ParamSchemaName", dt.Rows[0]["schemaname"].ToString());
                                    smsDic.Add("ParamTableName", dt.Rows[0]["tablename"].ToString());
                                    smsDic.Add("ParamServerName", dt.Rows[0]["servername"].ToString());
                                    smsDic.Add("ParamDbName", dt.Rows[0]["dbname"].ToString());
                                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS024, smsDic));
                                }

                                string qrygetemail = "select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                                NpgsqlCommand Cmdemail = new NpgsqlCommand(qrygetemail);
                                Cmdemail.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SendEmail);
                                DataTable dtemail = data.GetDataTable(Cmdemail);
                                for (int i = 0; i < dtemail.Rows.Count; i++)
                                {
                                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                    smsDic.Add("ParamEmail", dtemail.Rows[i]["SelectValueName"].ToString());
                                    smsDic.Add("ParamSchemaName", dt.Rows[0]["schemaname"].ToString());
                                    smsDic.Add("ParamTableName", dt.Rows[0]["tablename"].ToString());
                                    smsDic.Add("ParamServerName", dt.Rows[0]["servername"].ToString());
                                    smsDic.Add("ParamDbName", dt.Rows[0]["dbname"].ToString());
                                    smsDic.Add("ParamServerId", ((int)CountList.Type001).ToString());
                                    cmdList.Add(Utility.ApplicationProcessEmail((int)CountList.Type002, smsDic));
                                }

                                if (dt.Rows[0]["isupdaterequired"].ToString() == ((int)CountList.Type001).ToString())
                                {
                                    RemoteQry = string.Format("update dsgn.tablepartitionmaster set emailsentdate=now(),lastupdatedate=now() where partitionid={0};", dt.Rows[0][0].ToString());
                                    RemoteScript = new StringBuilder("select dblink_exec('");
                                    RemoteScript.Append(ForeignServer._ForeignServer06);
                                    RemoteScript.Append("'::text, '");
                                    RemoteScript.Append(RemoteQry);
                                    RemoteScript.Append("'::text);");
                                    RemoteScript.Append("select 1;");
                                    Cmd = new NpgsqlCommand(RemoteScript.ToString());
                                    cmdList.Add(Cmd);
                                }

                                data.SaveData(cmdList);
                                ViewData["message"] = "Internal SMS has been send";
                                return View("message");
                            }
                            else
                            {
                                ViewBag.DisplayMessage = "No new partition created for last 5 days.";
                                return View(model);
                            }
                        }
                        else
                        {
                            ViewBag.DisplayMessage = "Something gone wrong, please contact to Administrator.";
                            return View(model);
                        }                       
                    }
                }
                catch
                {
                    ViewBag.DisplayMessage = "Internal Server Error";
                    return View(model);
                }

            }
            ViewBag.DisplayMessage = "There is no Profile to send SMS";
            return View(model);
        }

        #region Department Dashboard News
        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult AddUpdateDashboardMessage(Int32? Id)
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.message = (string)TempData[Constant._ActionMessage]; }
            AdminModels model = new AdminModels();
            model.DashboardMessageMaster = new DashboardMessageMaster();
            GetData data = new GetData();
            string Qry = "select DBMB.id,DepartmentId,DeptName as DepartmentName,PermissionId,PName as PermissionName, InformationTitle,InformationDescription,to_char(AddDate,'DD/MM/YYYY') as AddInfoDate,DBMB.WhetherActive from dbo.dashboardmessagemaster DBMB inner join DeptMaster DM on DM.DeptCode=DBMB.DepartmentId left outer join PermissionMaster PM on PM.Pcode=DBMB.PermissionId::text order by adddate desc";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            model.dta = data.GetDataTable(Cmd);
            if (Id == null) { return View(model); }

            Qry = "select DBMB.id,DepartmentId,PermissionId,InformationTitle,InformationDescription,to_char(AddDate,'DD/MM/YYYY') as AddDate,DBMB.WhetherActive from dbo.dashboardmessagemaster DBMB where DBMB.Id=@Id";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@Id", Id);
            model.DashboardMessageMaster = DashboardMessageMaster.Get<DashboardMessageMaster>(new DashboardMessageMaster(), Cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult AddUpdateDashboardMessage(AdminModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = string.Empty;
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                if (string.IsNullOrEmpty(model.DashboardMessageMaster.Id))
                {
                    Qry = "insert into DashboardMessageMaster(DepartmentId,PermissionId,InformationTitle,InformationDescription,AddDate,WhetherActive,UserId,Ipaddress,LastactionDate) values (@DepartmentId,@PermissionId, @InformationTitle,@InformationDescription,@AddDate,@WhetherActive,@UserId,@Ipaddress,now())";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@DepartmentId", model.DashboardMessageMaster.DepartmentId);
                    Cmd.Parameters.AddWithValue("@PermissionId", model.DashboardMessageMaster.PermissionId);
                    Cmd.Parameters.AddWithValue("@InformationTitle", model.DashboardMessageMaster.InformationTitle);
                    Cmd.Parameters.AddWithValue("@InformationDescription", model.DashboardMessageMaster.InformationDescription);
                    Cmd.Parameters.AddWithValue("@AddDate", Utility.GetDateYYYYMMDD(model.DashboardMessageMaster.AddDate, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@WhetherActive", model.DashboardMessageMaster.WhetherActive);
                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                    PreserveModelState(Constant._ActionMessage, "Message Added successfully. ", false, true);
                }
                else
                {
                    Qry = "update DashboardMessageMaster set DepartmentId=@DepartmentId,PermissionId=@PermissionId, InformationTitle=@InformationTitle,InformationDescription=@InformationDescription,AddDate=@AddDate,WhetherActive=@WhetherActive,UserId=@UserId,Ipaddress=@Ipaddress,LastactionDate=now() where Id=@Id";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@Id", model.DashboardMessageMaster.Id);
                    Cmd.Parameters.AddWithValue("@DepartmentId", model.DashboardMessageMaster.DepartmentId);
                    Cmd.Parameters.AddWithValue("@PermissionId", model.DashboardMessageMaster.PermissionId);
                    Cmd.Parameters.AddWithValue("@InformationTitle", model.DashboardMessageMaster.InformationTitle);
                    Cmd.Parameters.AddWithValue("@InformationDescription", model.DashboardMessageMaster.InformationDescription);
                    Cmd.Parameters.AddWithValue("@AddDate", Utility.GetDateYYYYMMDD(model.DashboardMessageMaster.AddDate, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@WhetherActive", model.DashboardMessageMaster.WhetherActive);
                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                    PreserveModelState(Constant._ActionMessage, "Message Updated successfully. ", false, true);
                }
                data.SaveData(cmdList);

                //Qry = "select DBMB.id,DepartmentId,DeptName as DepartmentName,PermissionId,PName as PermissionName, InformationTitle,InformationDescription,to_char(AddDate,'DD/MM/YYYY') as AddDate,DBMB.WhetherActive from dbo.dashboardmessagemaster DBMB inner join DeptMaster DM on DM.DeptCode=DBMB.DepartmentId left outer join PermissionMaster PM on PM.Pcode=DBMB.PermissionId::text order by adddate desc";
                //NpgsqlCommand Cmd1 = new NpgsqlCommand(Qry);
                //model.dta = data.GetDataTable(Cmd1);
                //return View(model);

                return RedirectToAction("AddUpdateDashboardMessage", "Admin");
            }
            return View(model);
        }
        #endregion

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult CitizenApplicationDetails()
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult CitizenApplicationDetails(ReportModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string Qry = "select ApplicationId from web.ApplicationDetails where ApplicationId=@ApplicationId";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@ApplicationId", model.ApplicantDetails.ApplicationId);
                string WhetherExist = data.SelectColumns(cmd)[0];
                if (string.IsNullOrEmpty(WhetherExist))
                {

                    ViewData["message"] = "Application Id does not Exist";
                    return View("message");

                }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppId" }, new ArrayList() { model.ApplicantDetails.ApplicationId });
                return RedirectToAction("ApplicationPreview", "Receiving", new { q = QueryString });
            }
            return View("SearchApplicationwithTempId", model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult ProcessIntegrationModule()
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ProcessIntegrationModule(AdminModels model, FormCollection frm)
        {
            try
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                NpgsqlCommand cmd = null;
                string Qry = string.Empty;
                int count = 0;
                if (ModelState.IsValid)
                {
                    if (Convert.ToInt32(model.OperationId) == (int)ValueId.RASDataInsert)
                    {
                        Qry = "insert into  ApplicationAdditionalDetails (applicationno,whetherraspost,whetherdigipost) select a.applicationno,FALSE,FALSE from applicationdetails a left outer join applicationadditionaldetails b on b.applicationno=a.applicationno where b.applicationno is null";
                        cmd = new NpgsqlCommand(Qry);
                        data.UpdateData(cmd);

                        Qry = "select AD.ApplicationNo from ApplicationDetails AD inner join ApplicationAdditionalDetails AAD on AAD.ApplicationNo=AD.ApplicationNo  where AAD.WhetherRasPost=@WhetherRasPost and AD.ApplicationStatusId =@ApplicationStatusId limit 10000";
                        cmd = new NpgsqlCommand(Qry);
                        cmd.Parameters.AddWithValue("@WhetherRasPost", CustomText.False.ToString());
                        cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                        model.dta = data.GetDataTable(cmd);

                        if (model.dta.Rows.Count > 0)
                        {
                            for (int i = 0; i < model.dta.Rows.Count; i++)
                            {
                                bool returnresult = Utility.PostRasData(Convert.ToInt64(model.dta.Rows[i]["ApplicationNo"].ToString()));
                                if (returnresult == true)
                                {
                                    Qry = "update ApplicationAdditionalDetails set WhetherRasPost=@WhetherRasPost,raspostdate=now() where ApplicationNo=@ApplicationNo";
                                    cmd = new NpgsqlCommand(Qry);
                                    cmd.Parameters.AddWithValue("@WhetherRasPost", CustomText.True.ToString());
                                    cmd.Parameters.AddWithValue("@ApplicationNo", model.dta.Rows[i]["ApplicationNo"].ToString());
                                    data.UpdateData(cmd);

                                    count++;
                                }
                            }
                        }

                        if (count == 0) {
                            ViewData["message"] = "(0) record has been transfered at RAS Server.";
                        } else {
                            ViewData["message"] = "(" + count + ") record(s) has been transfered at RAS Server.";
                        }
                        return View("Message");
                    }
                    else if (Convert.ToInt32(model.OperationId) == (int)ValueId.DIGILockerDataInsert)
                    {
                        Qry = "insert into  ApplicationAdditionalDetails (applicationno,whetherraspost,whetherdigipost) select a.applicationno,FALSE,FALSE from applicationdetails a left outer join applicationadditionaldetails b on b.applicationno=a.applicationno where b.applicationno is null";
                        cmd = new NpgsqlCommand(Qry);
                        data.UpdateData(cmd);

                        Qry = "select a.ApplicationNo from ApplicationDetails a inner join applicationadditionaldetails b on b.applicationno=a.applicationno where b.WhetherDigiPost=@WhetherDigiPost and a.documentid=@documentid and a.ApplicationStatusId=@ApplicationStatusId and a.servicecode in (select servicecode from servicemaster where digiservicecode in ('CTCER','DMCER','INCER','OBCER')) limit 1000";
                        cmd = new NpgsqlCommand(Qry);
                        cmd.Parameters.AddWithValue("@WhetherDigiPost", CustomText.FALSE.ToString());
                        cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                        cmd.Parameters.AddWithValue("@documentid", (int)DocumentId.AadhaarCard);
                        model.dta = data.GetDataTable(cmd);

                        for (int i = 0; i < model.dta.Rows.Count; i++)
                        {
                            bool returnresult = Utility.PostDigiLockerData(Convert.ToInt64(model.dta.Rows[i]["ApplicationNo"].ToString()));
                            if (returnresult == true)
                            {
                                Qry = "update applicationadditionaldetails set whetherdigipost=@whetherdigipost,digipostdate=now() where applicationno=@applicationno";
                                cmd = new NpgsqlCommand(Qry);
                                cmd.Parameters.AddWithValue("@whetherdigipost", CustomText.TRUE.ToString());
                                cmd.Parameters.AddWithValue("@applicationno", model.dta.Rows[i]["ApplicationNo"].ToString());
                                data.UpdateData(cmd);

                                count++;
                            }
                        }

                        if (count == 0) {
                            ViewData["message"] = "(0) record has been transfered at DigiLocker Server.";
                        } else {
                            ViewData["message"] = "(" + count + ") record(s) has been transfered at DigiLocker Server.";
                        }
                        return View("Message");
                    }
                    else if (Convert.ToInt32(model.OperationId) == (int)ValueId.SLADataInsert)
                    {
                        return RedirectToAction("ProcessSLAData");
                    }
                    else if (Convert.ToInt32(model.OperationId) == (int)ValueId.MinorProfileUpdate)
                    {
                        Qry = "select RegistrationId from web.registrationmaster where parentregistrationid is not null and ((to_char(now(),'YYYYMMDD')::date-to_char(applicantdob,'YYYYMMDD')::date)/ 365) >= 18 limit 300";
                        cmd = new NpgsqlCommand(Qry);
                        DataTable dt = data.GetDataTable(cmd);
                        if (dt.Rows.Count > 0)
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                string SimplePassword = Utility.GetRandomString(8, 3);
                                string HashPassword = Utility.GenerateSHA512(SimplePassword).ToString().ToLower();

                                Qry = "Update web.RegistrationMaster set parentrelationid=ParentRegistrationId,ParentRegistrationId=NULL,applicantpassword=@applicantpassword,maxloginattempt=@maxloginattempt,whetherpasswordchange=@whetherpasswordchange,Applicantipaddress=@Applicantipaddress,lastactionperformed=now(),ActionPerformedBy=@ActionPerformedBy where RegistrationId=@RegistrationId";
                                cmd = new NpgsqlCommand(Qry);
                                cmd.Parameters.AddWithValue("@RegistrationId", dt.Rows[i]["RegistrationId"]);
                                cmd.Parameters.AddWithValue("@applicantpassword", HashPassword);
                                cmd.Parameters.AddWithValue("@maxloginattempt", (int)CustomValue.No);
                                cmd.Parameters.AddWithValue("@whetherpasswordchange", CustomText.False.ToString());
                                cmd.Parameters.AddWithValue("@ActionPerformedBy", Sessions.getEmployeeUser().UserId);
                                cmd.Parameters.AddWithValue("@Applicantipaddress", Utility.GetIP4Address());
                                cmdList.Add(cmd);

                                Qry = "update web.applicationdetails set receiveduser=registrationid where registrationid=@registrationid and receivedpermission=@receivedpermission and applicationno is null and registrationid::text<>receiveduser";
                                cmd = new NpgsqlCommand(Qry);
                                cmd.Parameters.AddWithValue("@registrationid", dt.Rows[i]["RegistrationId"]);
                                cmd.Parameters.AddWithValue("@receivedpermission", (int)Permission.CITZ);
                                cmdList.Add(cmd);
                                
                                Qry = "select ApplicantMobileNo from web.RegistrationMaster where RegistrationId=@RegistrationId";
                                cmd = new NpgsqlCommand(Qry);
                                cmd.Parameters.AddWithValue("@RegistrationId", dt.Rows[i]["RegistrationId"]);
                                string UserContactNo = data.SelectColumns(cmd)[0];

                                Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                smsDic.Add("ParamMobileNo", UserContactNo);
                                smsDic.Add("ParamRegistrationId", dt.Rows[i]["RegistrationId"].ToString());
                                smsDic.Add("ParamPassword", SimplePassword);
                                cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS001, smsDic));
                            }
                            int updateCount = data.SaveData(cmdList);
                            updateCount = updateCount / 2;
                            ViewData["message"] = "[" + updateCount.ToString() + "] records updated.";
                        }
                        else { ViewData["message"] = "No such records found, [0] records updated."; }
                        return View("Message");
                    }
                }
                return RedirectToAction("ProcessIntegrationModule", "Admin");
            }
            catch
            {
                return RedirectToAction("Index", "Error");
            }
        }

        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult ProcessSLAData()
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ProcessSLAData(AdminModels model)
        {
            try
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                NpgsqlCommand cmd = null;
                string Qry = string.Empty;
                if (ModelState.IsValid)
                {
                    Boolean WhetherServiceSuccess = false;
                    string msg = string.Empty, LastMsg = string.Empty, LastDate = string.Empty, LastDateSave = string.Empty;
                    int RecordCount = 0;
                    try
                    {
                        Qry = "select to_char(LastActionDate, 'yyyy-MM-dd HH24:MM:SS') as LastActionDate,to_char(LastActionDate+ INTERVAL '5 day', 'yyyy-MM-dd HH24:MM:SS')   as nextdate,STM.ServiceCode from SlaTransactionMaster STM inner join ServiceMaster SM on SM.ServiceCode=STM.ServiceCode and Deptcode=@Deptcode order by LastActionDate desc";
                        cmd = new NpgsqlCommand(Qry);
                        cmd.Parameters.AddWithValue("@Deptcode", model.DeptCode);
                        model.dta = data.GetDataTable(cmd);

                        if (model.dta != null && model.dta.Rows.Count > 0)
                        {
                            for (int k = 0; k < model.dta.Rows.Count; k++)
                            {
                                Qry = "select ((count(applicationno)/1000) + 1) as mycount from ApplicationDetails AD inner join servicemaster SM on SM.ServiceCode=AD.ServiceCode and SM.DeptCode=@Deptcode inner join StatusMaster SMM on SMM.StatusId=AD.ApplicationStatusId  where to_char(AD.LastActionDate, 'yyyy-MM-dd HH24:MM:SS') between  @LastActionDate  and @nextLastActionDate  and slaServiceCode is not null and SlaSubServiceCode is not null and AD.ServiceCode=@ServiceCode";
                                cmd = new NpgsqlCommand(Qry);
                                cmd.Parameters.AddWithValue("@Deptcode", model.DeptCode);
                                cmd.Parameters.AddWithValue("@ServiceCode", model.dta.Rows[k]["ServiceCode"].ToString());
                                cmd.Parameters.AddWithValue("@nextLastActionDate", model.dta.Rows[k]["nextdate"].ToString());
                                cmd.Parameters.AddWithValue("@LastActionDate", model.dta.Rows[k]["LastActionDate"].ToString());
                                model.dtb = data.GetDataTable(cmd);

                                LastDate = string.Empty;
                                for (int j = 0; j < Convert.ToInt32(model.dtb.Rows[0]["mycount"].ToString()); j++)
                                {
                                    Qry = @"Select to_char(AD.LastActionDate, 'yyyy-MM-dd HH24:MM:SS') as ""LastActionDate"", Applicationno as ""Applicationno"",ApplicantName as ""ApplicantName"",LEFT(dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode),400) as ""ApplicantAddress"",to_char(ApplicationDate,'YYYYMMDD') as ""DateofApplication"",case when ApplicationStatusId in (1,6,14,16) then to_char(AD.LastActionDate,'YYYYMMDD') else to_char(now(),'YYYYMMDD') end as ""Dateofissue"",ApplicantMobileNo as ""ContactNo"",sladeptcode as ""DeptCode"",SLADistrictCode::text as ""Subdeptcode"",SLASubDivCode::text as ""SubDivcode"",slaservicecode::text as ""servicecode"",SlaStatus::text as ""status"", null as ""lng"", null::text as ""OS"",null::text as ""remarks"",null::text as ""DateOfIssueOfDeficiencyMemo"",null::text as ""DateOfReplyOfDeficiencyMemo"",SlaSubServiceCode::text as ""subservicecode"",SlaSubStatus::text as  ""substatus"", null::text as ""SlaOutDate"",null::text as ""SlaInDate"" from applicationdetails AD inner join servicemaster SM on SM.ServiceCode=AD.ServiceCode and SM.DeptCode=@Deptcode inner join StatusMaster SMM on SMM.StatusId=AD.ApplicationStatusId inner join districtmaster DM on DM.DistrictCOde=AD.ApplicationDistrictCode inner join SubDivMaster SDM on SDM.SubDivCode=AD.ApplicationSubDivCode where to_char(AD.LastActionDate, 'yyyy-MM-dd HH24:MM:SS') between  @LastActionDate  and @nextLastActionDate and slaServiceCode is not null and SlaSubServiceCode is not null and AD.ServiceCode=@ServiceCode order by LastActionDate limit 1000";
                                    cmd = new NpgsqlCommand(Qry);
                                    cmd.Parameters.AddWithValue("@Deptcode", model.DeptCode);
                                    cmd.Parameters.AddWithValue("@ServiceCode", model.dta.Rows[k]["ServiceCode"].ToString());
                                    cmd.Parameters.AddWithValue("@nextLastActionDate", model.dta.Rows[k]["nextdate"].ToString());
                                    if (!string.IsNullOrEmpty(LastDate)) { cmd.Parameters.AddWithValue("@LastActionDate", LastDate); } else { cmd.Parameters.AddWithValue("@LastActionDate", model.dta.Rows[k]["LastActionDate"].ToString()); }
                                    model.dataS = data.GetDataTable(cmd);

                                    Qry = "select max(LastActionDate) as LastActionDate from (select  to_char(AD.LastActionDate, 'yyyy-MM-dd HH24:MM:SS') as LastActionDate from ApplicationDetails AD inner join servicemaster SM on SM.ServiceCode=AD.ServiceCode and SM.DeptCode=@Deptcode inner join StatusMaster SMM on SMM.StatusId=AD.ApplicationStatusId  where to_char(AD.LastActionDate, 'yyyy-MM-dd HH24:MM:SS') between  @LastActionDate  and @nextLastActionDate and slaServiceCode is not null and SlaSubServiceCode is not null and AD.ServiceCode=@ServiceCode order by LastActionDate  limit 1000) a";
                                    cmd = new NpgsqlCommand(Qry);
                                    cmd.Parameters.AddWithValue("@Deptcode", model.DeptCode);
                                    cmd.Parameters.AddWithValue("@ServiceCode", model.dta.Rows[k]["ServiceCode"].ToString());
                                    cmd.Parameters.AddWithValue("@nextLastActionDate", model.dta.Rows[k]["nextdate"].ToString());
                                    if (!string.IsNullOrEmpty(LastDate)) { cmd.Parameters.AddWithValue("@LastActionDate", LastDate); } else { cmd.Parameters.AddWithValue("@LastActionDate", model.dta.Rows[k]["LastActionDate"].ToString()); }
                                    model.dataSC = data.GetDataTable(cmd);

                                    if (model.dataS.Rows.Count > 0)
                                    {
                                        //string sBaseUrl = "http://10.128.24.7/eslaWebAPI/postdata.svc/AddRecord"; //Local URL
                                        string sBaseUrl = "http://10.248.118.36/eslaWebAPI/postdata.svc/AddRecord"; //Production URL

                                        SLADetails sladata = new SLADetails();
                                        sladata.data = model.dataS;
                                        if (model.DeptCode == ((int)Department.Dept001).ToString())
                                        {
                                            sladata.username = "esla"; //For Revenue                                        
                                            sladata.password = RijndaelSimple.AESEncryptData("Sla@1234", "!23esla@domainname.com");
                                        }
                                        else if (model.DeptCode == ((int)Department.Dept002).ToString())
                                        {
                                            sladata.username = "SWWebsevice"; //For Social Welfare                                        
                                            sladata.password = RijndaelSimple.AESEncryptData("Web@1234", "!23esla@domainname.com");
                                        }
                                        else if (model.DeptCode == ((int)Department.Dept003).ToString())
                                        {
                                            sladata.username = "fsedist"; //For NFS                                        
                                            sladata.password = RijndaelSimple.AESEncryptData("Edist@123", "!23esla@domainname.com");
                                        }
                                        else if (model.DeptCode == ((int)Department.Dept007).ToString())
                                        {
                                            sladata.username = "labourwebserv"; //For Labour                                        
                                            sladata.password = RijndaelSimple.AESEncryptData("!slA#2017", "!23esla@domainname.com");
                                        }
                                        else if (model.DeptCode == ((int)Department.Dept010).ToString())
                                        {
                                            sladata.username = "scstwebservice"; //For Sc/St Welfare                                        
                                            sladata.password = RijndaelSimple.AESEncryptData("Web@1234", "!23esla@domainname.com");
                                        }
                                        else
                                        {
                                            ViewData["message"] = "The Provision is Not Allowed for Selected Department";
                                            return View("message");
                                        }

                                        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(sBaseUrl);
                                        request.Timeout = 500000;
                                        request.Method = "POST";
                                        request.MaximumResponseHeadersLength = 2147483647;
                                        request.ContentType = "application/json";

                                        using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                                        {
                                            string JasonString = JsonConvert.SerializeObject(sladata);
                                            streamWriter.Write(JasonString);
                                            streamWriter.Flush();
                                            streamWriter.Close();
                                        }

                                        using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                                        {
                                            StreamReader reader = new StreamReader(response.GetResponseStream());
                                            string ResponseString = reader.ReadToEnd();
                                            model.SLAUtility = Utility.GetSLADetails(ResponseString);
                                        }

                                        if (Convert.ToInt16(model.SLAUtility.SLAID) == (int)CountList.Type111)
                                        {
                                            WhetherServiceSuccess = true;
                                            LastDate = model.dataSC.Rows[0]["LastActionDate"].ToString();
                                            if (model.dataS.Rows.Count < 1000)
                                            {
                                                LastDateSave = model.dta.Rows[k]["nextdate"].ToString();

                                                string CheckDate = DateTime.Now.ToString("yyyyMMdd");
                                                DateTime LastActionDate = Convert.ToDateTime(LastDateSave);
                                                string LastAction = LastActionDate.ToString("yyyyMMdd");
                                                if (Convert.ToInt64(LastAction) > Convert.ToInt64(CheckDate))
                                                {
                                                    LastDateSave = model.dataSC.Rows[0]["LastActionDate"].ToString();
                                                }
                                            }
                                            else
                                            {
                                                LastDateSave = model.dataSC.Rows[0]["LastActionDate"].ToString();
                                            }
                                            RecordCount += model.dataS.Rows.Count;
                                            //LastDateSave = model.dataSC.Rows[j]["LastActionDate"].ToString();

                                            // temp process for update transaction master
                                            Qry = " Update SlaTransactionMaster set LastActionDate=@LastActionDate,ActionUserId=@ActionUserId,ActionIpadress=@ActionIpadress,ActionDateTime=now() where ServiceCode=@ServiceCode";
                                            cmd = new NpgsqlCommand(Qry);
                                            cmd.Parameters.AddWithValue("@ServiceCode", model.dta.Rows[k]["ServiceCode"].ToString());
                                            cmd.Parameters.AddWithValue("@ActionUserId", Sessions.getEmployeeUser().UserId);
                                            cmd.Parameters.AddWithValue("@ActionIpadress", Utility.GetIP4Address());
                                            cmd.Parameters.AddWithValue("@LastActionDate", LastDateSave);
                                            cmdList.Add(cmd);

                                            Qry = " Insert Into SlaTransactionDetails(TotalRecrodsPushed,WhetherServiceSuccess,ReturnMessage,ActionUserId,ActionIpadress,ActionDateTime) values(@TotalRecrodsPushed,@WhetherServiceSuccess,@ReturnMessage,@ActionUserId,@ActionIpadress,now())";
                                            cmd = new NpgsqlCommand(Qry);
                                            cmd.Parameters.AddWithValue("@TotalRecrodsPushed", RecordCount);
                                            cmd.Parameters.AddWithValue("@WhetherServiceSuccess", WhetherServiceSuccess);
                                            cmd.Parameters.AddWithValue("@ReturnMessage", model.SLAUtility.SLAID);
                                            cmd.Parameters.AddWithValue("@ActionUserId", Sessions.getEmployeeUser().UserId);
                                            cmd.Parameters.AddWithValue("@ActionIpadress", Utility.GetIP4Address());
                                            cmdList.Add(cmd);

                                            data.SaveData(cmdList);
                                        }
                                        else
                                        {
                                            ViewData["message"] = model.SLAUtility.Message;
                                            return View("message");
                                        }
                                    }
                                    else
                                    {
                                        string CheckDate = DateTime.Now.ToString("yyyyMMdd");
                                        DateTime LastActionDate = Convert.ToDateTime(model.dta.Rows[k]["nextdate"].ToString());
                                        string LastAction = LastActionDate.ToString("yyyyMMdd");
                                        if (Convert.ToInt64(LastAction) < Convert.ToInt64(CheckDate))
                                        {
                                            Qry = " Update SlaTransactionMaster set LastActionDate=@LastActionDate,ActionUserId=@ActionUserId,ActionIpadress=@ActionIpadress,ActionDateTime=now() where ServiceCode=@ServiceCode";
                                            cmd = new NpgsqlCommand(Qry);
                                            cmd.Parameters.AddWithValue("@ServiceCode", model.dta.Rows[k]["ServiceCode"].ToString());
                                            cmd.Parameters.AddWithValue("@ActionUserId", Sessions.getEmployeeUser().UserId);
                                            cmd.Parameters.AddWithValue("@ActionIpadress", Utility.GetIP4Address());
                                            cmd.Parameters.AddWithValue("@LastActionDate", model.dta.Rows[k]["nextdate"].ToString());
                                            cmdList.Add(cmd);
                                            data.SaveData(cmdList);
                                        }
                                    }

                                }
                            }
                            ViewData["message"] = "SLA Processed Sucessfully.";
                            return View("message");
                        }
                        else
                        {
                            ViewData["message"] = "No SLA Data Available for this department.";
                            return View("message");
                        }


                    }
                    catch (Exception ex)
                    {
                        msg = ex.Message;
                        ViewData["message"] = "Some Exception Occured!!!";
                        return View("message");

                    }
                }
                return RedirectToAction("ProcessSLAData", "Admin");
            }
            catch
            {
                return RedirectToAction("Index", "Error");
            }
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult QueryBrowsing()
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult QueryBrowsing(AdminModels model)
        {
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            NpgsqlCommand cmd = null;
            string Qry = string.Empty;
            if (ModelState.IsValid)
            {
                model.QueryInput = model.QueryInput.Trim().ToLower();
                if (!model.QueryInput.Contains("delete") && !model.QueryInput.Contains("drop") && !model.QueryInput.Contains("insert") && !model.QueryInput.Contains("update") && !model.QueryInput.Contains("create") && !model.QueryInput.Contains("truncate"))
                {
                    try
                    {
                        cmd = new NpgsqlCommand(model.QueryInput);
                        model.dataS = data.GetDataTable(cmd);
                    }
                    catch (Exception e)
                    {
                        model.dataS = new DataTable();
                        model.dataS.Columns.Add("Message", typeof(string));
                        model.dataS.Rows.Add("Error Occured: " + e.ToString());
                    }
                }
                else { ViewBag.DisplayMessage = "String has forbidden characters"; return View(model); }
            }
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult UpdateBankMapping()
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult UpdateBankMapping(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                data = new GetData();
                string Qry = "Select  micrcode from Bankmappingmaster where micrcode = @micrcode";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ifsccode", model.IFSCCode);
                Cmd.Parameters.AddWithValue("@micrcode", model.MICRCode);
                model.data = data.GetDataTable(Cmd);

                if (model.data != null)
                {
                    if (model.data.Rows.Count > 0)
                    {
                        ViewData["message"] = "The mapping of given MICR/IFSC already Exist.Kindly check details and try again.";
                        return View("message");
                    }
                }

                Qry = "Select  ifsccode,micrcode from Bankmappingmaster where ifsccode = @ifsccode";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ifsccode", model.IFSCCode);
                model.dataS = data.GetDataTable(Cmd);

                if (model.dataS != null)
                {
                    if (model.dataS.Rows.Count > 0)
                    {
                        if (!string.IsNullOrEmpty(model.dataS.Rows[0]["micrcode"].ToString()))
                        {
                            ViewData["message"] = "The mapping of given MICR/IFSC already Exist.Kindly check details and try again.";
                            return View("message");
                        }
                        else
                        {
                            Qry = "update Bankmappingmaster set  Micrcode = @Micrcode Where IfscCode = @ifsccode";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ifsccode", model.IFSCCode);
                            Cmd.Parameters.AddWithValue("@Micrcode", model.MICRCode);
                            model.dataS = data.GetDataTable(Cmd);
                            ViewData["message"] = "Update in Bank Mapping.";
                            return View("message");
                        }
                    }

                    else
                    {

                        Qry = "insert into Bankmappingmaster (ifsccode,micrcode,branchaddress,bankcode,actiondatetime,userid,ipaddress)values (@ifsccode,@Micrcode,@branchaddress,@bankcode,now(),@userid,@ipaddress)";   //update
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ifsccode", model.IFSCCode);
                        Cmd.Parameters.AddWithValue("@Micrcode", model.MICRCode);
                        Cmd.Parameters.AddWithValue("@branchaddress", model.BankBranchAddress);
                        Cmd.Parameters.AddWithValue("@bankcode", model.BankCode);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        model.dataS = data.GetDataTable(Cmd);
                        ViewData["message"] = "The  given Bank mapping  details saved sucessfully.";
                        return View("message");
                    }
                }
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }

        #region Module for setting up the API permission from Admin
        [Authorize(Roles = "118")]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult CreateApiClientUser()
        {
            if (Sessions.getEmployeeUser().DeptCode != ((int)Department.Dept001).ToString()) { 
                ViewData["message"] = "You are not authorized to access this module. Kindly contact to your Administrator or Nodal Department"; 
                return View("message"); 
            }

            AdminModels model = new AdminModels();
            return View(model);
        }
        [Authorize(Roles = "118")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult CreateApiClientUser(AdminModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                string Qry = "select clientid from apiclientmaster where LOWER(clientid)=@clientid";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@clientid", model.ApiClientMaster.ClientId.ToString().ToLower());
                model.data = data.GetDataTable(Cmd);
                if (model.data.Rows.Count > 0)
                {
                    ViewBag.DisplayMessage = "Client Id  Already Exist!!";
                    PreserveModelState(Constant._ModelStateParent, null, true, false);
                    return View((CommonModels)TempData[Constant._ModelStateParent]);
                }

                string clientSecret = Utility.GetRandomString(12, 4);
                string encdecKey = Utility.GetRandomString(25, 4);

                Qry = "insert into  apiclientmaster(clientid,clientsecret,clientname,nodalofficername,nodalofficermobno,whetheractive,validupto,actionuserid,actionipaddress,actiondatetime,keyvalidupto,encdeckey) values (@clientid,@clientsecret,@clientname,@nodalofficername,@nodalofficermobno,@whetheractive,@validupto,@actionuserid,@actionipaddress,now(),@keyvalidupto,@encdeckey)";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@clientid", model.ApiClientMaster.ClientId);
                Cmd.Parameters.AddWithValue("@clientsecret", clientSecret);
                Cmd.Parameters.AddWithValue("@clientname", model.ApiClientMaster.ClientName);
                Cmd.Parameters.AddWithValue("@nodalofficername", model.ApiClientMaster.NodalOfficerName);
                Cmd.Parameters.AddWithValue("@nodalofficermobno", model.ApiClientMaster.NodalOfficerMobNo);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@validupto", System.DateTime.Now.AddMonths(2));
                Cmd.Parameters.AddWithValue("@keyvalidupto", System.DateTime.Now.AddMonths(2));
                Cmd.Parameters.AddWithValue("@encdeckey", encdecKey);
                Cmd.Parameters.AddWithValue("@actionuserid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                int insertedRows = data.SaveData(cmdList);

                //Qry = "select clientid,to_char(keyvalidupto,'dd/mm/yyyy') keyvalidupto,encdeckey,clientsecret from apiclientmaster where clientId=@clientid";
                //Cmd = new NpgsqlCommand(Qry);
                //Cmd.Parameters.AddWithValue("@clientid", model.ApiClientMaster.ClientId);
                //string[] saveddata = data.SelectColumns(Cmd);
                //TempData["ClientId"] = saveddata[0].ToString();
                //TempData["validupto"] = saveddata[1].ToString();
                //TempData["encdeckey"] = saveddata[2].ToString();
                //TempData["clientsecret"] = saveddata[3].ToString();

                if (insertedRows > 0)
                {
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamSmsText", "Client Id : " + model.ApiClientMaster.ClientId + ", Client Secret : " + clientSecret + " and Key : " + encdecKey);
                    smsDic.Add("ParamMobileNo", model.ApiClientMaster.NodalOfficerMobNo);
                    data.UpdateData(Utility.ApplicationProcessSms((int)SmsSendType.SMS019, smsDic));
                }
                else { return RedirectToAction("BadRequest","Error"); }

                ViewData["message"] = "Client has been successfully created and credential has been sent on Provided Nodal Officer's mobile No.";
                return View("message"); 
            }
            return View(model);
        }
        #endregion

        #region Unlock user modification flag of SC/ST welfare department
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult SearchForAllowUpdateUserDetails()
        {
            AdminModels model = new AdminModels();
            model.UserMaster = new UserMaster();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SearchForAllowUpdateUserDetails(AdminModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string Qry = "select UserId,UserName,Designation,to_char(DateofBirth,'DD/MM/YYYY') as DateofBirth,PresentAddress,PermanentAddress from usermaster where userid=@UserId";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@UserId", model.UserMaster.UserId);
                model.data = data.GetDataTable(Cmd);
                return View(model);
            }
            return View("SearchForAllowUpdateUserDetails", model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult AllowUpdateUserDetails(AdminModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Qry = string.Empty;

                Qry = "Update UserMaster set whetherdetailapprove=@WhetherFALSE,whetherdetailupdate=@WhetherFALSE Where UserId=@UserId";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@UserId", model.UserMaster.UserId);
                Cmd.Parameters.AddWithValue("@WhetherFALSE", CustomText.FALSE.ToString());
                cmdList.Add(Cmd);


                Qry = "Update usercreationenclosuredetails set contenttype=null,documentdata=null,userphotodata=null Where UserId=@UserId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@UserId", model.UserMaster.UserId);
                cmdList.Add(Cmd);
                data.SaveData(cmdList);

                ViewData["message"] = "User Allowed For Update User Details Successfully!!!";
                return View("message");
            }

            return View("SearchForAllowUpdateUserDetails", model);
        }
        #endregion

        #region Change zone in school/college/institute
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult ChangeSchoolZone()
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            model.ApplicationDetailsPrematsSC = new ApplicationDetailsPrematsSC();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult ChangeSchoolZone(AdminModels model)
        {
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            if (ModelState.IsValid)
            {
                string Qry = "select ApplicationNo  from dgen.prematapplicationprocess where SchoolId=@SchoolId ";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@SchoolId", model.ApplicationDetailsPrematsSC.SchoolId);
                model.data = data.GetDataTable(Cmd);
                if (model.data != null)
                {
                    if (model.data.Rows.Count > 0)
                    {
                        for (int i = 0; i < model.data.Rows.Count; i++)
                        {
                            cmdList.Add(Utility.InsertDepartmentAuditTrail(model.data.Rows[i]["ApplicationNo"].ToString(), (int)ApplicationHistoryMessage.MSG059, null, (int)ApplicationSource.Window, null));
                        }
                    }
                }

                Qry = "update dgen.prematschoolmaster set district=@district,subdivision=@subdivision where SchoolId=@SchoolId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@SchoolId", model.ApplicationDetailsPrematsSC.SchoolId);
                Cmd.Parameters.AddWithValue("@district", model.DistrictId);
                Cmd.Parameters.AddWithValue("@subdivision", model.ZoneId);
                cmdList.Add(Cmd);
                data.SaveData(cmdList);


                ViewData["message"] = "District and Zone Changed Sucessfully!";
                return View("message");
            }

            return View("ChangeSchoolZone", model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult SearchSCSTAppSchool()
        {
            AdminModels model = new AdminModels();
            model.ApplicationDetailsPrematsSC = new ApplicationDetailsPrematsSC();

            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ChangeSCSTSchool(AdminModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string Qry = "select PAP.SchoolId,AD.ServiceCode,AD.ApplicationNo,SchoolName,SchoolAddress,SchoolAffiliationId,District,DistrictName,SubDivision,ZoneName,PAP.SchoolTypeId,SMVDD.ValueName as SchoolType,PSM.DepartmentId,SMVD.ValueName as Department from dbo.ApplicationDetails AD inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo inner join dgen.PrematSchoolMaster PSM on PSM.SchoolId=PAP.SchoolId inner join SelectMasterValueDetails SMVD on SMVD.ValueId=PSM.DepartmentId inner join SelectMasterValueDetails SMVDD on SMVDD.ValueId=PSM.SchoolTypeId inner join dgen.PrematDistrictMaster PDM on PDM.DistrictId=PSM.District left outer join dgen.PrematZoneMaster PZM on PZM.ZoneId=PSM.SubDivision Where AD.ApplicationNo=@ApplicationNo and ApplicationStatusId=@ApplicationStatusId and PAP.AcademicSession=@AcademicSession ";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetailsPrematsSC.ApplicationNo);
                cmd.Parameters.AddWithValue("@AcademicSession", model.ApplicationDetailsPrematsSC.AcademicSession);
                cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.OBSPEND);
                model.data = data.GetDataTable(cmd);
                if (model.data.Rows.Count > 0)
                {
                    model.ServiceCode = model.data.Rows[0]["ServiceCode"].ToString();
                    Qry = "select PSM.SchoolId as SelectValueId,SchoolName||','||SchoolAddress as SelectValueName from dgen.prematschoolmaster PSM limit 0";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    List<SelectValueMaster> SchoolTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                    model.SchoolList = new SelectList(SchoolTypeList, "SelectValueId", "SelectValueName");

                    return View(model);
                }
                else
                {
                    ViewBag.DisplayMessage = "Provided Application No. and academic session either incorrect or not authroize to transfer to another school.";
                    PreserveModelState(Constant._ModelStateParent, null, true, false);
                    return View("SearchSCSTAppSchool", (AdminModels)TempData[Constant._ModelStateParent]);
                }
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("SearchSCSTAppSchool", (AdminModels)TempData[Constant._ModelStateParent]);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ChangeSCSTSchoolPost(AdminModels model)
        {
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            if (ModelState.IsValid)
            {
                string Qry = string.Empty;
                if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.PrematricScholarshipSC) { Qry = "update dgen.applicationdetailsprematssc "; }
                if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.PrematricScholarshipOBC) { Qry = "update dgen.applicationdetailsprematobc "; }
                if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.PostmatricScholarshipOBC) { Qry = "update dgen.applicationdetailspostmatobc "; }
                if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.FinancialAssistanceStationery) { Qry = "update dgen.applicationdetailsfinancialassistance "; }
                if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.MeritscholarshipSchool) { Qry = "update dgen.applicationdetailsmeritscholarshipschool "; }
                if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.MeritscholarshipProfessional) { Qry = "update dgen.applicationdetailsmeritprofessional "; }
                if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.DrbrAmbedkarToppers) { Qry = "update dgen.applicationdetailsbrambedkar "; }

                if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.PostmatricSC) { Qry = "update dgen.applicationdetailspostmatscssd "; }
                if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.PrematricSC) { Qry = "update dgen.applicationdetailsprematscssd "; }

                Qry += " set SchoolTypeId=@SchoolTypeId,DepartmentId=@DepartmentId, SchoolId=@SchoolId where ApplicationNo=@ApplicationNo";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@SchoolId", model.ApplicationDetailsPrematsSC.SchoolId);
                Cmd.Parameters.AddWithValue("@SchoolTypeId", model.ApplicationDetailsPrematsSC.SchoolTypeId);
                Cmd.Parameters.AddWithValue("@DepartmentId", model.ApplicationDetailsPrematsSC.DepartmentId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetailsPrematsSC.ApplicationNo);
                cmdList.Add(Cmd);

                Qry = " Update dgen.prematapplicationprocess set SchoolTypeId=@SchoolTypeId,DepartmentId=@DepartmentId, SchoolId=@SchoolId where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@SchoolId", model.ApplicationDetailsPrematsSC.SchoolId);
                Cmd.Parameters.AddWithValue("@SchoolTypeId", model.ApplicationDetailsPrematsSC.SchoolTypeId);
                Cmd.Parameters.AddWithValue("@DepartmentId", model.ApplicationDetailsPrematsSC.DepartmentId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetailsPrematsSC.ApplicationNo);
                cmdList.Add(Cmd);

                cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetailsPrematsSC.ApplicationNo, (int)ApplicationHistoryMessage.MSG054, null, (int)ApplicationSource.Window, null));
                data.SaveData(cmdList);


                ViewData["message"] = "School/College/Institution Changed Sucessfully!";
                return View("message");
            }

            return View("ChangeSCSTSchool", model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult UnlockSchoolVerification()
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            model.ApplicationDetailsPrematsSC = new ApplicationDetailsPrematsSC();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult UnlockSchoolVerification(AdminModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                string Qry = "select distinct AD.ApplicationNo from ApplicationDetails AD inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo where SchoolId=@SchoolId and ApplicationStatusId not in (@ApplicationStatusId,@ApplicationStatusId1) and DepartmentId=@DepartmentId and AD.serviceCode=@serviceCode and PAP.AcademicSession=@AcademicSession ";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@SchoolId", model.ApplicationDetailsPrematsSC.SchoolId);
                Cmd.Parameters.AddWithValue("@serviceCode", model.ServiceCode);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.OBSPEND);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId1", (int)Status.TEHSPEN);
                Cmd.Parameters.AddWithValue("@DepartmentId", (int)CountList.Type000);
                Cmd.Parameters.AddWithValue("@AcademicSession", model.ApplicationDetailsPrematsSC.AcademicSession);
                model.ApplicationNo = data.SelectColumns(Cmd)[0];
                if (!string.IsNullOrEmpty(model.ApplicationNo))
                {
                    ViewData["message"] = "Approving Department has approved the application for this service,You are not allowed to Unlock The Data!";
                    return View("message");
                }

                Qry = "select SchoolId,whetherrevertback from dbyt.prematverifiedapplication Where SchoolId=@SchoolId and ServiceCode=@serviceCode and DepartmentId=@DepartmentId and AcademicSession=@AcademicSession";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@SchoolId", model.ApplicationDetailsPrematsSC.SchoolId);
                Cmd.Parameters.AddWithValue("@serviceCode", model.ServiceCode);
                Cmd.Parameters.AddWithValue("@AcademicSession", model.ApplicationDetailsPrematsSC.AcademicSession);
                Cmd.Parameters.AddWithValue("@DepartmentId", (int)CountList.Type000);
                string[] Value = data.SelectColumns(Cmd);
                if (Value != null)
                {
                    if (string.IsNullOrEmpty(Value[0]))
                    {
                        ViewData["message"] = "There Is No File Found To Unloack!";
                        return View("message");
                    }
                    if (Value[1].ToString().ToUpper() == CustomText.TRUE.ToString())
                    {
                        ViewData["message"] = "Approving Department has Send Some Application for Re-Verification for this service,You are not allowed to Unlock The Data!";
                        return View("message");
                    }
                }


                Qry = "select letterId from dbyt.prematverifiedapplication where SchoolId=@SchoolId and ServiceCode=@ServiceCode and WhetherFileUploaded=@WhetherFileUploaded and AcademicSession=@AcademicSession and DepartmentId=@DepartmentId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@SchoolId", model.ApplicationDetailsPrematsSC.SchoolId);
                Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                Cmd.Parameters.AddWithValue("@WhetherFileUploaded", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@DepartmentId", (int)CountList.Type000);
                Cmd.Parameters.AddWithValue("@AcademicSession", model.ApplicationDetailsPrematsSC.AcademicSession);
                string letterId = data.SelectColumns(Cmd)[0];

                Qry = "Delete from dbyt.prematverifiedapplication where SchoolId=@SchoolId and ServiceCode=@serviceCode and AcademicSession=@AcademicSession and DepartmentId=@DepartmentId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@SchoolId", model.ApplicationDetailsPrematsSC.SchoolId);
                Cmd.Parameters.AddWithValue("@serviceCode", model.ServiceCode);
                Cmd.Parameters.AddWithValue("@AcademicSession", model.ApplicationDetailsPrematsSC.AcademicSession);
                Cmd.Parameters.AddWithValue("@DepartmentId", (int)CountList.Type000);
                cmdList.Add(Cmd);

                Qry = "update dbyt.prematverifiedapplication set VerificationLetterId=null where letterId=@letterId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@letterId", letterId);
                cmdList.Add(Cmd);

                data.UpdateData(Cmd);


                ViewData["message"] = "Data Unlock Successfully!";
                return View("message");
            }

            return View("UnlockSchoolVerification", model);
        }
        #endregion

        #region Juridiction (District/Locality) change in application
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult SearchApplocalitychange()
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ChangeApplocality(AdminModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                //Change07122017
                string Qry = "select ServiceCode FROM dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ServiceCode in (select servicecode from servicemaster where deptcode=@ParamDeptCode and districttransferallowed=@districttransferallowed) and ApplicationStatusId=@DEALOLR";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                //Cmd.Parameters.AddWithValue("@OldAge", (int)ServiceList.OldAge);
                //Cmd.Parameters.AddWithValue("@DFBScheme", (int)ServiceList.DFBScheme);
                //Cmd.Parameters.AddWithValue("@Handicapped", (int)ServiceList.Handicapped);
                Cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
                Cmd.Parameters.AddWithValue("@DistrictTransferAllowed", CustomText.True.ToString());
                model.ServiceCode = data.SelectColumns(Cmd)[0];

                if (string.IsNullOrEmpty(model.ServiceCode))
                {
                    ViewBag.DisplayMessage = "Application No is either incorrect or application is not eligible for tranfer to another jurisdiction.";
                    return View("SearchApplocalitychange");
                }


                model.DeptCode = Utility.GetDeptCode(model.ServiceCode);
                model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationNo, DB.LS.ToString());

                if (model.DeptCode == ((int)Department.Dept002).ToString())
                {
                    if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.Handicapped)
                    {
                        model.ApplicationHandicappedDetails = Utility.GetHandicappedDetails(model.ApplicationNo, DB.LS.ToString());
                    }
                    else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.OldAge)
                    {
                        model.ApplicationDetailsOldAge = Utility.GetOldAgeDetails(model.ApplicationNo, DB.LS.ToString());
                    }
                    else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.DFBScheme)
                    {
                        model.ApplicationDetailsDFBScheme = Utility.GetDFBSchemeDetails(model.ApplicationNo, DB.LS.ToString());
                    }
                }
                else if (model.DeptCode == ((int)Department.Dept007).ToString())
                {
                    if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.Contractors)
                    {
                        model.ApplicationDetailsContractor = Utility.GetContractorDetails(model.ApplicationNo, DB.LS.ToString());
                    }
                    else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.BOCW)
                    {
                        model.ApplicationDetailsBOCWAct = Utility.GetBOCWActDetails(model.ApplicationNo, DB.LS.ToString());
                    }
                    else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.InstallationOfLift)
                    {
                        model.ApplicationDetailsInstallationOfLift = Utility.GetInstallationOfLiftDetails(model.ApplicationNo, DB.LS.ToString());
                    }
                    else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.GrantOfPassengerLift)
                    {
                        model.ApplicationDetailsGrantOfPassengerLift = Utility.GetGrantOfPassengerLiftDetails(model.ApplicationNo, DB.LS.ToString());
                    }
                    else if (Convert.ToInt16(model.ServiceCode) == (int)ServiceList.ContractLabour)
                    {
                        model.ApplicationDetailsCLAct = Utility.GetCLActDetails(model.ApplicationNo, DB.LS.ToString());
                    }
                }

                model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", string.Empty, string.Empty, model.ApplicationNo, DB.LS.ToString(), CustomText.N.ToString());
                model.dataS = Utility.GetPhotoDetails(string.Empty, string.Empty, string.Empty, string.Empty, model.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
                PreserveModelState(Constant._ModelStateParent, model, false, true);
                return View(model);
            }
            return View("SearchApplocalitychange", model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ChangeApplocalityPost(AdminModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Qry = string.Empty;
                NpgsqlCommand Cmd = new NpgsqlCommand();
                //check capping limit for old age scheme after modification
                if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.OldAge)
                {
                    bool CheckReturn = Utility.CheckOldAgeCapLimit(model.ApplicantLocalityId);
                    if (CheckReturn == false)
                    {
                        ViewData["message"] = "The Capping Limit is Full in this Constituency.You are Not allowed to Change Locality!!!";
                        return View("message");
                    }
                }
                //Change07122017
                if (model.DeptCode == ((int)Department.Dept002).ToString())
                {
                    Qry = " update dbo.applicationdetails set ApplicantLocalityId=@ApplicantLocalityId,ApplicantDistrictcode=@ApplicantDistrictcode,ApplicantSubDivcode=@ApplicantSubDivcode,ApplicationDistrictcode=@ApplicationDistrictcode, ApplicationSubDivcode=@ApplicationSubDivcode where ApplicationNo=@ApplicationNo;";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@ApplicantLocalityId", model.ApplicantLocalityId);
                    Cmd.Parameters.AddWithValue("@ApplicantDistrictcode", model.DistrictId);
                    Cmd.Parameters.AddWithValue("@ApplicantSubDivcode", model.ZoneId);
                    Cmd.Parameters.AddWithValue("@ApplicationDistrictcode", model.DistrictId);
                    Cmd.Parameters.AddWithValue("@ApplicationSubDivcode", model.ZoneId);
                    cmdList.Add(Cmd);
                }
                else if (model.DeptCode == ((int)Department.Dept007).ToString())
                {
                    Qry = " update dbo.applicationdetails set ApplicationDistrictcode=@ApplicationDistrictcode, ApplicationSubDivcode=@ApplicationSubDivcode where ApplicationNo=@ApplicationNo;";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@ApplicationDistrictcode", model.DistrictId);
                    Cmd.Parameters.AddWithValue("@ApplicationSubDivcode", model.ZoneId);
                    cmdList.Add(Cmd);
                }

                //Qry = " update web.applicationdetails set ApplicantLocalityId=@ApplicantLocalityId,ApplicantDistrictcode=@ApplicantDistrictcode,ApplicantSubDivcode=@ApplicantSubDivcode,ApplicationDistrictcode=@ApplicationDistrictcode, ApplicationSubDivcode=@ApplicationSubDivcode where ApplicationNo=@ApplicationNo;";
                //Cmd = new NpgsqlCommand(Qry);
                //Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                //Cmd.Parameters.AddWithValue("@ApplicantLocalityId", model.ApplicantLocalityId);
                //Cmd.Parameters.AddWithValue("@ApplicantDistrictcode", model.DistrictId);
                //Cmd.Parameters.AddWithValue("@ApplicantSubDivcode", model.ZoneId);
                //Cmd.Parameters.AddWithValue("@ApplicationDistrictcode", model.DistrictId);
                //Cmd.Parameters.AddWithValue("@ApplicationSubDivcode", model.ZoneId);
                //cmdList.Add(Cmd);

                if (model.DeptCode == ((int)Department.Dept002).ToString())
                {
                    if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.OldAge) { Qry = " update dgen.applicationdetailsoldage set constituencyid=@constituencyid where ApplicationNo=@ApplicationNo;"; }
                    if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.Handicapped) { Qry = " update dgen.applicationdetailsHandicapped set constituencyid=@constituencyid where ApplicationNo=@ApplicationNo;"; }
                    if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.DFBScheme) { Qry = " update dgen.applicationdetailsdfbscheme set mlaconstituencyid=@constituencyid where ApplicationNo=@ApplicationNo;"; }
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@constituencyid", model.ConstituencyID);
                    cmdList.Add(Cmd);
                }
                else if (model.DeptCode == ((int)Department.Dept007).ToString())
                {
                    if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.Contractors) { Qry = " update dgen.ApplicationDetailsContractor set AppLocalityId=@AppLocalityId where ApplicationNo=@ApplicationNo"; }
                    if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.BOCW) { Qry = " update dgen.ApplicationDetailsBOCWAct set AppLocalityid=@AppLocalityid where ApplicationNo=@ApplicationNo"; }
                    if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.InstallationOfLift) { Qry = " update dgen.ApplicationDetailsInstallationOfLift set AppLocalityid=@AppLocalityid where ApplicationNo=@ApplicationNo"; }
                    if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.GrantOfPassengerLift) { Qry = " update dgen.ApplicationDetailsGrantOfPassengerLift set AppLocalityid=@AppLocalityid where ApplicationNo=@ApplicationNo"; }
                    if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.ContractLabour) { Qry = " update dgen.ApplicationDetailsCLAct set AppLocalityid=@AppLocalityid where ApplicationNo=@ApplicationNo"; }
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@AppLocalityId", model.ApplicantLocalityId);
                    cmdList.Add(Cmd);
                }

                //string ApplicationId = Utility.SelectColumnsValue("web.applicationdetails", "ApplicationId", "ApplicationNo", model.ApplicationNo)[0];
                //if (!string.IsNullOrEmpty(ApplicationId))
                //{
                //    if (model.DeptCode == ((int)Department.Dept002).ToString())
                //    {
                //        if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.OldAge) { Qry = "update wgen.applicationdetailsoldage set constituencyid=@constituencyid where ApplicationId=@ApplicationId;"; }
                //        if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.Handicapped) { Qry = " update wgen.applicationdetailsHandicapped set constituencyid=@constituencyid where ApplicationId=@ApplicationId;"; }
                //        if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.DFBScheme) { Qry = " update wgen.applicationdetailsdfbscheme set mlaconstituencyid=@constituencyid where ApplicationId=@ApplicationId;"; }
                //        Cmd = new NpgsqlCommand(Qry);
                //        Cmd.Parameters.AddWithValue("@ApplicationId", ApplicationId);
                //        Cmd.Parameters.AddWithValue("@constituencyid", model.ConstituencyID);
                //        cmdList.Add(Cmd);
                //    }
                //    else if (model.DeptCode == ((int)Department.Dept007).ToString())
                //    {
                //        if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.Contractors) { Qry = " update wgen.ApplicationDetailsContractor set AppLocalityId=@AppLocalityId where ApplicationId=@ApplicationId"; }
                //        if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.BOCW) { Qry = " update wgen.ApplicationDetailsBOCWAct set AppLocalityid=@AppLocalityid where ApplicationId=@ApplicationId"; }
                //        if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.InstallationOfLift) { Qry = " update wgen.ApplicationDetailsInstallationOfLift set AppLocalityid=@AppLocalityid where ApplicationId=@ApplicationId"; }
                //        if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.GrantOfPassengerLift) { Qry = " update wgen.ApplicationDetailsGrantOfPassengerLift set AppLocalityid=@AppLocalityid where ApplicationId=@ApplicationId"; }
                //        if (Convert.ToInt32(model.ServiceCode) == (int)ServiceList.ContractLabour) { Qry = " update wgen.ApplicationDetailsCLAct set AppLocalityid=@AppLocalityid where ApplicationId=@ApplicationId"; }
                //        Cmd = new NpgsqlCommand(Qry);
                //        Cmd.Parameters.AddWithValue("@ApplicationId", ApplicationId);
                //        Cmd.Parameters.AddWithValue("@AppLocalityId", model.LocalityId);
                //        cmdList.Add(Cmd); 
                //    } 
                //}

                //insert in audit trail
                cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG050, null, (int)ApplicationSource.Window, null));

                data.SaveData(cmdList);

                ViewData["message"] = "The District/Locality in application [" + model.ApplicationNo + "] has been changed successfully!";
                return View("message");
            }

            return View("ChangeApplocality", model);
        }
        #endregion

        #region Higher Education
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult UniversityEntry()
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            model.HeUniversityMaster = new HeUniversityMaster();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult UniversityEntry(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                data = new GetData();
                string Qry = "Select  universityid, universityname from heuniversitymaster where upper(universityname) = @universityname and servicecode=@servicecode";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@universityname", model.HeUniversityMaster.UniversityName.ToUpper().Trim());
                Cmd.Parameters.AddWithValue("@servicecode", model.ServiceCode);
                model.data = data.GetDataTable(Cmd);

                if (model.data != null)
                {
                    if (model.data.Rows.Count > 0)
                    {
                        ViewData["message"] = "University name already Exist.Kindly check try again.";
                        return View("message");
                    }
                    else
                    {

                        Qry = "insert into heuniversitymaster (universityname, whetheractive, servicecode,universityaddress,universityemail,universitycontactno,actiondatetime,userid,ipaddress)values (@universityname,@whetheractive,@servicecode,@universityaddress,@universityemail,@universitycontactno,now(),@userid,@ipaddress)";   //update
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@universityname", model.HeUniversityMaster.UniversityName);
                        Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@servicecode", model.ServiceCode);
                        Cmd.Parameters.AddWithValue("@universityaddress", model.HeUniversityMaster.UniversityAddress);
                        Cmd.Parameters.AddWithValue("@universityemail", model.HeUniversityMaster.UniversityEmail);
                        Cmd.Parameters.AddWithValue("@universitycontactno", model.HeUniversityMaster.UniversityContactNo);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                        data.SaveData(cmdList);
                        ViewData["message"] = "The  given University  details saved sucessfully.";
                        return View("message");
                    }
                }


            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult CourseEntry()
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            model.HeCourseMaster = new HeCourseMaster();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult CourseEntry(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                data = new GetData();
                string Qry = "Select  coursename from hecoursemaster where upper(coursename) = @coursename and servicecode=@servicecode";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@coursename", model.HeCourseMaster.CourseName.ToUpper().Trim());
                Cmd.Parameters.AddWithValue("@servicecode", model.ServiceCode);
                model.data = data.GetDataTable(Cmd);

                if (model.data != null)
                {
                    if (model.data.Rows.Count > 0)
                    {
                        ViewData["message"] = "Course name already Exist.Kindly check try again.";
                        return View("message");
                    }
                    else
                    {
                        Qry = "insert into hecoursemaster (coursename, whetheractive, servicecode,CoursePeriod,actiondatetime,userid,ipaddress)values (@coursename,@whetheractive,@servicecode,@CoursePeriod,now(),@userid,@ipaddress)";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@coursename", model.HeCourseMaster.CourseName);
                        Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@servicecode", model.ServiceCode);
                        Cmd.Parameters.AddWithValue("@CoursePeriod", model.HeCourseMaster.CoursePeriod);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                        data.SaveData(cmdList);
                        ViewData["message"] = "The  given Course details saved sucessfully.";
                        return View("message");
                    }
                }


            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult InstitutionEntry()
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            model.HeInstitutionMaster = new HeInstitutionMaster();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult InstitutionEntry(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                data = new GetData();
                string Qry = "Select  instituitonname from heinstitutionmaster where upper(instituitonname) = @instituitonname and universityid=@universityid";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@instituitonname", model.HeInstitutionMaster.InstituitonName.ToUpper().Trim());
                Cmd.Parameters.AddWithValue("@universityid", model.HeInstitutionMaster.UniversityId);
                model.data = data.GetDataTable(Cmd);

                if (model.data != null)
                {
                    if (model.data.Rows.Count > 0)
                    {
                        ViewData["message"] = "Institute name already Exist.Kindly check try again.";
                        return View("message");
                    }
                    else
                    {

                        Qry = "insert into heinstitutionmaster (instituitonname, institutionaddress, affiliationcode, universityid, whetheractive, userid, ipaddress, courseeligibility, actiondatetime, institutionemail, institutioncontact, nodalofficer)values (@instituitonname, @institutionaddress, @affiliationcode, @universityid, @whetheractive, @userid, @ipaddress, @courseeligibility,now(), @institutionemail, @institutioncontact, @nodalofficer)";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@instituitonname", model.HeInstitutionMaster.InstituitonName);
                        Cmd.Parameters.AddWithValue("@institutionaddress", model.HeInstitutionMaster.InstitutionAddress);
                        Cmd.Parameters.AddWithValue("@affiliationcode", model.HeInstitutionMaster.AffiliationCode);
                        Cmd.Parameters.AddWithValue("@universityid", model.HeInstitutionMaster.UniversityId);
                        Cmd.Parameters.AddWithValue("@institutionemail", model.HeInstitutionMaster.InstitutionEmail);
                        Cmd.Parameters.AddWithValue("@institutioncontact", model.HeInstitutionMaster.InstitutionContact);
                        Cmd.Parameters.AddWithValue("@nodalofficer", model.HeInstitutionMaster.NodalOfficer);
                        Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        if (model.ServiceCode == ((int)ServiceList.HigherEducationSKGS).ToString()) { Cmd.Parameters.AddWithValue("@courseeligibility", model.HeInstitutionMaster.CourseEligibility); }
                        else { Cmd.Parameters.AddWithValue("@courseeligibility", (int)CountList.Type000); }

                        cmdList.Add(Cmd);
                        data.SaveData(cmdList);
                        ViewData["message"] = "The  given Institution details saved sucessfully.";
                        return View("message");
                    }
                }
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult SchoolEntryForLoan()
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SchoolEntryForLoan(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                data = new GetData();

                string Qry = "Select  SchoolName from heschoolmaster where upper(SchoolName)=@SchoolName and schoolcategoryid=@SchoolCategoryId";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@SchoolName", model.SchoolName.ToUpper().Trim());
                Cmd.Parameters.AddWithValue("@SchoolCategoryId", model.SchoolCategoryId);
                model.data = data.GetDataTable(Cmd);

                if (model.data != null)
                {
                    if (model.data.Rows.Count > 0)
                    {
                        ViewData["message"] = "School Name already Exist.Kindly check try again.";
                        return View("message");
                    }
                    else
                    {
                        Qry = "insert into heschoolmaster (SchoolName, schoolcategoryid, whetheractive, userid, ipaddress)values (@SchoolName,@schoolcategoryid, @whetheractive, @userid, @ipaddress)";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@SchoolName", model.SchoolName.ToUpper().Trim());
                        Cmd.Parameters.AddWithValue("@schoolcategoryid", model.SchoolCategoryId);
                        Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                        data.SaveData(cmdList);
                        ViewData["message"] = "The  given School Name details saved sucessfully.";
                        return View("message");
                    }
                }
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        #endregion

        #region Change Request
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult CRRequestEntry()
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult CRRequestEntry(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                data = new GetData();
                byte[] fileData = null;
                if (model.CRRequestDetails.WhetherFlowAttached.ToUpper() == CustomText.TRUE.ToString())
                {
                    HttpPostedFile file = System.Web.HttpContext.Current.Request.Files["FlowData"];
                    fileData = Utility.CompareFileCapturePhotoData(null, file);
                    string ContentType = file.ContentType;
                    if (fileData == null)
                    {
                        ViewBag.DisplayMessage = "Upload Document is Required";
                        PreserveModelState(Constant._ModelStateParent, model, false, true);
                        return View(model);
                    }
                    if (file.ContentLength > (int)LengthList.EncContent)
                    {
                        ViewBag.DisplayMessage = "Document has invalid size. (Max Limit: 100KB)";
                        PreserveModelState(Constant._ModelStateParent, model, false, true);
                        return View(model);
                    }
                    if (ContentType.ToLower() != "application/pdf")
                    {
                        ViewBag.DisplayMessage = "Only PDF Document Is Uploaded";
                        PreserveModelState(Constant._ModelStateParent, model, false, true);
                        return View(model);
                    }
                }
                else { fileData = null; }
                
                if (model.CRRequestDetails.ServiceCode == null) { model.CRRequestDetails.ServiceCode = Convert.ToString((int)CountList.Type000); }

                string Qry = @"insert into dbo.CRRequestDetails(ProjectId,ProjectUrl,DepartmentId,ServiceCode,Nodalofficer,ChangeTitle,ChangeDetails,WhetherFlowAttached,FlowDetails,FlowData,WhetherNodalApproved,RequestedDate,userid,ipaddress,actiondatetime) values(@ProjectId,@ProjectUrl,@DepartmentId,@ServiceCode,@Nodalofficer,@ChangeTitle,@ChangeDetails,@WhetherFlowAttached,@FlowDetails,@FlowData,@WhetherNodalApproved,@RequestedDate,@userid,@ipaddress,now())";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ProjectId", model.CRRequestDetails.ProjectId);
                Cmd.Parameters.AddWithValue("@ProjectUrl", model.CRRequestDetails.ProjectUrl);
                Cmd.Parameters.AddWithValue("@DepartmentId", model.CRRequestDetails.DepartmentId);
                Cmd.Parameters.AddWithValue("@ServiceCode", model.CRRequestDetails.ServiceCode);
                Cmd.Parameters.AddWithValue("@Nodalofficer", model.CRRequestDetails.Nodalofficer);
                Cmd.Parameters.AddWithValue("@ChangeTitle", model.CRRequestDetails.ChangeTitle);
                Cmd.Parameters.AddWithValue("@ChangeDetails", model.CRRequestDetails.ChangeDetails);
                Cmd.Parameters.AddWithValue("@WhetherFlowAttached", model.CRRequestDetails.WhetherFlowAttached);
                Cmd.Parameters.AddWithValue("@FlowDetails", model.CRRequestDetails.FlowDetails);
                Cmd.Parameters.AddWithValue("@FlowData", fileData);
                Cmd.Parameters.AddWithValue("@WhetherNodalApproved", model.CRRequestDetails.WhetherNodalApproved);
                Cmd.Parameters.AddWithValue("@RequestedDate", Utility.GetDateYYYYMMDD(model.CRRequestDetails.RequestedDate, '/', "0/1/2"));
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                data.SaveData(cmdList);
                ViewData["message"] = "CR Saved successfully";
                return View("message");
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult ViewPendingCRForm(int Typeid)
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            model.flag = Typeid.ToString();
            string whethercondition = string.Empty;
            if (Typeid == (int)CountList.Type001) { whethercondition += " and WhetherComplete=@WhetherComplete"; }
            if (Typeid == (int)CountList.Type002) { whethercondition += " and WhetherComplete=@WhetherComplete1 and WhetherUATDone=@WhetherUATDone"; }
            if (Typeid == (int)CountList.Type003) { whethercondition += " and WhetherComplete=@WhetherComplete1 and WhetherUATDone=@WhetherUATDone1 and WhetherReleased=@WhetherReleased"; }
            if (Typeid == (int)CountList.Type004) { whethercondition += " and WhetherComplete=@WhetherComplete1 and WhetherUATDone=@WhetherUATDone1 and WhetherReleased=@WhetherReleased1 and WhetherSigned=@WhetherSigned"; }
            string Qry = "select RequestId,ValueName as ProjectName,DeptName as  DepartmentName,CRD.ServiceCode,case when CRD.ServiceCode=0 then 'General' else ServiceName end as ServiceName,ChangeTitle,to_char(RequestedDate,'DD/MM/YYYY') as RequestedDate from  CRRequestDetails CRD inner join SelectMasterValueDetails SMVD on SMVD.ValueId=CRD.ProjectId inner join DeptMaster DM on DM.DeptCode=CRD.DepartmentId left outer join ServiceMaster SM on SM.ServiceCode =CRD.ServiceCode where 1=1 " + whethercondition + " order by RequestId ";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            if (Typeid == (int)CountList.Type001) { cmd.Parameters.AddWithValue("@WhetherComplete", CustomText.False.ToString()); }
            if (Typeid == (int)CountList.Type002) { cmd.Parameters.AddWithValue("@WhetherComplete1", CustomText.True.ToString()); cmd.Parameters.AddWithValue("@WhetherUATDone", CustomText.False.ToString()); }
            if (Typeid == (int)CountList.Type003) { cmd.Parameters.AddWithValue("@WhetherComplete1", CustomText.True.ToString()); cmd.Parameters.AddWithValue("@WhetherUATDone1", CustomText.True.ToString()); cmd.Parameters.AddWithValue("@WhetherReleased", CustomText.False.ToString()); }
            if (Typeid == (int)CountList.Type004) { cmd.Parameters.AddWithValue("@WhetherComplete1", CustomText.True.ToString()); cmd.Parameters.AddWithValue("@WhetherUATDone1", CustomText.True.ToString()); cmd.Parameters.AddWithValue("@WhetherReleased1", CustomText.True.ToString()); cmd.Parameters.AddWithValue("@WhetherSigned", CustomText.False.ToString()); }

            model.dataS = data.GetDataTable(cmd);

            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult CRActionCompletion(int RequestId)
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            model.CRRequestDetails = new CRRequestDetails();
            model.CRRequestDetails.RequestId = RequestId.ToString();
            string Qry = "select RequestId,ValueName as ProjectName,ProjectUrl,DeptName as  DepartmentName,CRD.ServiceCode,case when CRD.ServiceCode=0 then 'General' else ServiceName end as ServiceName,NodalOfficer,ChangeTitle,ChangeDetails,WhetherFlowAttached,FlowDetails,WhetherNodalApproved, to_char(RequestedDate,'DD/MM/YYYY') as RequestedDate from  CRRequestDetails CRD inner join SelectMasterValueDetails SMVD on SMVD.ValueId=CRD.ProjectId inner join DeptMaster DM on DM.DeptCode=CRD.DepartmentId left outer join ServiceMaster SM on SM.ServiceCode =CRD.ServiceCode where RequestId=@RequestId and WhetherComplete=@WhetherComplete order by RequestId ";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@RequestId", RequestId);
            cmd.Parameters.AddWithValue("@WhetherComplete", CustomText.False.ToString());
            model.dataS = data.GetDataTable(cmd);

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult CRActionCompletion(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                data = new GetData();
                string Qry = @"Update dbo.CRRequestDetails set CompletionDate=@CompletionDate,Remarks=@Remarks,WhetherComplete=@WhetherComplete, CompletionBy=@CompletionBy,Completionipaddress=@Completionipaddress, completionactiondatetime=now() where RequestId=@RequestId";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RequestId", model.CRRequestDetails.RequestId);
                Cmd.Parameters.AddWithValue("@CompletionDate", Utility.GetDateYYYYMMDD(model.CRRequestDetails.CompletionDate, '/', "0/1/2"));
                Cmd.Parameters.AddWithValue("@WhetherComplete", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@Remarks", model.CRRequestDetails.Remarks);
                Cmd.Parameters.AddWithValue("@CompletionBy", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@Completionipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                data.SaveData(cmdList);
                ViewData["message"] = "Action Performed Successfully";
                return View("message");
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult CRActionUAT(int RequestId)
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            model.CRRequestDetails = new CRRequestDetails();
            model.CRRequestDetails.RequestId = RequestId.ToString();
            string Qry = "select RequestId,ValueName as ProjectName,ProjectUrl,DeptName as  DepartmentName,CRD.ServiceCode,case when CRD.ServiceCode=0 then 'General' else ServiceName end as ServiceName,NodalOfficer,ChangeTitle,ChangeDetails,WhetherFlowAttached,FlowDetails,WhetherNodalApproved, to_char(RequestedDate,'DD/MM/YYYY') as RequestedDate,to_char(CompletionDate,'DD/MM/YYYY') as CompletionDate,Remarks from  CRRequestDetails CRD inner join SelectMasterValueDetails SMVD on SMVD.ValueId=CRD.ProjectId inner join DeptMaster DM on DM.DeptCode=CRD.DepartmentId left outer join ServiceMaster SM on SM.ServiceCode =CRD.ServiceCode where RequestId=@RequestId and whethercomplete=@whethercomplete and WhetherUATDone=@WhetherUATDone order by RequestId  ";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@RequestId", RequestId);
            cmd.Parameters.AddWithValue("@whethercomplete", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@WhetherUATDone", CustomText.False.ToString());
            model.dataS = data.GetDataTable(cmd);

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult CRActionUAT(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                data = new GetData();
                string Qry = @"Update dbo.CRRequestDetails set UatDate=@UatDate,WhetherUATDone=@WhetherUATDone,OfficerName=@OfficerName,OfficerDesignation=@OfficerDesignation,WhetherDetailsChecked=@WhetherDetailsChecked,WhetherResultWorking=@WhetherResultWorking,WhetherDeploymentReady=@WhetherDeploymentReady,UatRemarks=@UatRemarks, UATBy=@UATBy,UATipaddress=@UATipaddress, uatactiondatetime=now() where RequestId=@RequestId";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RequestId", model.CRRequestDetails.RequestId);
                Cmd.Parameters.AddWithValue("@WhetherUATDone", CustomText.True.ToString());
                Cmd.Parameters.AddWithValue("@UatDate", Utility.GetDateYYYYMMDD(model.CRRequestDetails.UatDate, '/', "0/1/2"));
                Cmd.Parameters.AddWithValue("@OfficerName", model.CRRequestDetails.OfficerName);
                Cmd.Parameters.AddWithValue("@OfficerDesignation", model.CRRequestDetails.OfficerDesignation);
                Cmd.Parameters.AddWithValue("@WhetherDetailsChecked", model.CRRequestDetails.WhetherDetailsChecked);
                Cmd.Parameters.AddWithValue("@WhetherResultWorking", model.CRRequestDetails.WhetherResultWorking);
                Cmd.Parameters.AddWithValue("@WhetherDeploymentReady", model.CRRequestDetails.WhetherDeploymentReady);
                Cmd.Parameters.AddWithValue("@UatRemarks", model.CRRequestDetails.UatRemarks);
                //Cmd.Parameters.AddWithValue("@ReleaseDate", Utility.GetDateYYYYMMDD(model.CRRequestDetails.ReleaseDate, '/', "0/1/2"));
                Cmd.Parameters.AddWithValue("@UATBy", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@UATipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                data.SaveData(cmdList);
                ViewData["message"] = "Action Performed successfully";
                return View("message");
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult CRActionRelease(int RequestId)
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            model.CRRequestDetails = new CRRequestDetails();
            model.CRRequestDetails.RequestId = RequestId.ToString();
            string Qry = "select RequestId,ValueName as ProjectName,ProjectUrl,DeptName as  DepartmentName,CRD.ServiceCode,case when CRD.ServiceCode=0 then 'General' else ServiceName end as ServiceName,NodalOfficer,ChangeTitle,ChangeDetails,WhetherFlowAttached,FlowDetails,WhetherNodalApproved, to_char(RequestedDate,'DD/MM/YYYY') as RequestedDate,to_char(CompletionDate,'DD/MM/YYYY') as CompletionDate,Remarks,to_char(uatdate,'DD/MM/YYYY') as UATDate,OfficerName,OfficerDesignation,WhetherDetailsChecked,WhetherResultWorking,WhetherDeploymentReady,UATRemarks  from  CRRequestDetails CRD inner join SelectMasterValueDetails SMVD on SMVD.ValueId=CRD.ProjectId inner join DeptMaster DM on DM.DeptCode=CRD.DepartmentId left outer join ServiceMaster SM on SM.ServiceCode =CRD.ServiceCode where RequestId=@RequestId and whethercomplete=@whethercomplete and whetheruatdone=@WhetherUATDone and WhetherReleased=@WhetherReleased order by RequestId  ";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@RequestId", RequestId);
            cmd.Parameters.AddWithValue("@whethercomplete", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@WhetherUATDone", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@WhetherReleased", CustomText.False.ToString());
            model.dataS = data.GetDataTable(cmd);

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult CRActionRelease(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                data = new GetData();
                string Qry = @"Update dbo.CRRequestDetails set ReleaseDate=@ReleaseDate,WhetherReleased=@WhetherReleased,ReleasedBy=@ReleasedBy,Releasedipaddress=@Releasedipaddress, releasedactiondatetime=now() where RequestId=@RequestId";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RequestId", model.CRRequestDetails.RequestId);
                Cmd.Parameters.AddWithValue("@WhetherReleased", CustomText.True.ToString());
                Cmd.Parameters.AddWithValue("@ReleaseDate", Utility.GetDateYYYYMMDD(model.CRRequestDetails.ReleaseDate, '/', "0/1/2"));
                Cmd.Parameters.AddWithValue("@ReleasedBy", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@Releasedipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                data.SaveData(cmdList);
                ViewData["message"] = "Action Performed successfully";
                return View("message");
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult CRUploadFile(int RequestId)
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            model.CRRequestDetails = new CRRequestDetails();
            model.CRRequestDetails.RequestId = RequestId.ToString();
            string Qry = "select RequestId,ValueName as ProjectName,ProjectUrl,DeptName as  DepartmentName,CRD.ServiceCode,case when CRD.ServiceCode=0 then 'General' else ServiceName end as ServiceName,NodalOfficer,ChangeTitle,ChangeDetails,WhetherFlowAttached,FlowDetails,WhetherNodalApproved, to_char(RequestedDate,'DD/MM/YYYY') as RequestedDate,to_char(CompletionDate,'DD/MM/YYYY') as CompletionDate,Remarks,to_char(uatdate,'DD/MM/YYYY') as UATDate,OfficerName,OfficerDesignation,WhetherDetailsChecked,WhetherResultWorking,WhetherDeploymentReady,UATRemarks  from  CRRequestDetails CRD inner join SelectMasterValueDetails SMVD on SMVD.ValueId=CRD.ProjectId inner join DeptMaster DM on DM.DeptCode=CRD.DepartmentId left outer join ServiceMaster SM on SM.ServiceCode =CRD.ServiceCode where RequestId=@RequestId and whethercomplete=@whethercomplete and whetheruatdone=@WhetherUATDone and WhetherReleased=@WhetherReleased and WhetherSigned=@WhetherSigned order by RequestId  ";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@RequestId", RequestId);
            cmd.Parameters.AddWithValue("@whethercomplete", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@WhetherUATDone", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@WhetherReleased", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@WhetherSigned", CustomText.False.ToString());
            model.dataS = data.GetDataTable(cmd);

            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult CRUploadFile(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                data = new GetData();
                byte[] fileData = null;
                HttpPostedFile file = System.Web.HttpContext.Current.Request.Files["SignedData"];
                fileData = Utility.CompareFileCapturePhotoData(null, file);
                string ContentType = file.ContentType;
                if (fileData == null)
                {
                    ViewBag.DisplayMessage = "Upload Document is Required";
                    PreserveModelState(Constant._ModelStateParent, null, true, false);
                    return View(model);
                }
                if (ContentType.ToLower() != "application/pdf")
                {
                    ViewBag.DisplayMessage = "Only PDF Document Is Uploaded";
                    PreserveModelState(Constant._ModelStateParent, null, true, false);
                    return View(model);
                }

                string Qry = @"Update dbo.CRRequestDetails set SignedData=@SignedData,WhetherSigned=@WhetherSigned where RequestId=@RequestId";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RequestId", model.CRRequestDetails.RequestId);
                Cmd.Parameters.AddWithValue("@WhetherSigned", CustomText.True.ToString());
                Cmd.Parameters.AddWithValue("@SignedData", fileData);
                cmdList.Add(Cmd);

                data.SaveData(cmdList);
                ViewData["message"] = "Action Performed successfully";
                return View("message");
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult ViewCRDetails()
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            string Qry = "select RequestId,case when CD.servicecode=0 then'General'else SM.ServiceName end as ServiceName,Changetitle,ChangeDetails,to_char(CompletionDate,'DD/MM/YYYY')as CompletionDate,to_char(ReleaseDate,'DD/MM/YYYY')as ReleaseDate from dbo.crrequestdetails CD left outer join dbo.servicemaster SM on CD.servicecode=SM.servicecode order by RequestId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            model.dataS = data.GetDataTable(Cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult ViewCRAttachment(int Val)
        {
            GetData data = new GetData();
            Byte[] byteArray;
            string ContentType = string.Empty;
            string Qry = "select signeddata from crrequestdetails where RequestId=@RequestId ";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@RequestId", Val);
            DataTable AttachedData = data.GetDataTable(Cmd);
            if (AttachedData.Rows.Count > 0)
            {
                try
                {
                    byteArray = (Byte[])AttachedData.Rows[0]["signeddata"];
                    ContentType = "application/pdf";
                }
                catch
                {
                    byteArray = Utility.ImageToByteArrayFromFilePath(Server.MapPath(ImageList.NoImage));
                    ContentType = "image/jpeg";
                }
            }
            else
            {
                byteArray = Utility.ImageToByteArrayFromFilePath(Server.MapPath(ImageList.NoImage));
                ContentType = "image/jpeg";
            }
            return File(byteArray, ContentType);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult ViewChangeRequestDetails(int Val)
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            string Qry = "select RequestId,SMVD.valuename as ProjectName,Projecturl,DM.DeptName,case when CD.servicecode=0 then'General'else SM.ServiceName end as ServiceName,NodalOfficer,Changetitle,ChangeDetails, case when WhetherFlowAttached=true then 'Yes' else 'No' end as WhetherFlowAttached,FlowData,case when whethernodalapproved=true then'Yes' else 'No' end as whethernodalapproved,to_char(RequestedDate,'DD/MM/YYYY')as RequestedDate,case when whethercomplete=true then'Yes' else 'No' end as whethercomplete,to_char(CompletionDate,'DD/MM/YYYY')as CompletionDate,CompletionBy,case when whetheruatdone=true then'Yes' else 'No' end as whetheruatdone,to_char(UatDate,'DD/MM/YYYY')as UatDate,OfficerName,UatRemarks,OfficerDesignation,case when whetherdetailschecked=true then'Yes' else 'No' end as whetherdetailschecked,case when whetherResultWorking=true then'Yes' else 'No' end as whetherResultWorking,case when WhetherDeploymentReady=true then'Yes' else 'No' end as WhetherDeploymentReady,case when whetherreleased=true then'Yes' else 'No' end as whetherreleased,to_char(ReleaseDate,'DD/MM/YYYY')as ReleaseDate,case when Whethersigned=true then'Yes' else 'No' end as Whethersigned from dbo.crrequestdetails CD inner join SelectMasterValueDetails SMVD on SMVD.ValueId=CD.ProjectId inner join DeptMaster DM on DM.DeptCode=CD.DepartmentId left outer join dbo.servicemaster SM on CD.servicecode=SM.servicecode where RequestId=@RequestId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@RequestId", Val);
            model.dataS = data.GetDataTable(Cmd);
            return View(model);
        }
        #endregion

        #region Menu Management
        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult MenuManagement()
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult MenuManagement(AdminModels model)
        {
            if (ModelState.IsValid)
            {
                if (model.MenuMaster.RType == ((int)CountList.Type003).ToString())
                {
                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "RType", "DeptCode", "Permission" }, new ArrayList() { model.MenuMaster.RType, model.MenuMaster.Deptcode, model.MenuMaster.Permission });
                    return RedirectToAction("ProcessMenuOption", "Admin", new { q = QueryString });
                }
                GetData data = new GetData(); string Qry = string.Empty;
                model.dta = Utility.GetMenu(Convert.ToInt32(model.MenuMaster.Permission), Convert.ToInt32(model.MenuMaster.Deptcode), true, null);
                model.MenuMaster.PermissionName = Utility.SelectColumnsValue("permissionmaster", "pname", "pcode", model.MenuMaster.Permission)[0];
                model.MenuMaster.DeptName = Utility.SelectColumnsValue("deptmaster", "deptname", "deptcode", model.MenuMaster.Deptcode)[0];
                return View(model);
            }
            return View(model);
        }

        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult ProcessMenuOption(int RType, int? MenuId, int? DeptCode, int? Permission)
        {
            //0- Permission,1- DeptCode,2- MenuId,3- Head,4- WhetherLink,5- GroupId,6- DisplayOrder,7- WhetherActive,8- WhetherParameter,
            //9- Whether Peers Exist,10- Get All Related,11- All Peers, 12- First Parent,13- Next Node
            AdminModels model = new AdminModels();
            model.MenuMaster = new MenuMaster();
            model.MenuMaster.RType = RType.ToString();
            GetData data = new GetData();
            string Qry = string.Empty;
            NpgsqlCommand Cmd = null;
            if (DeptCode != null && Permission != null) { model.MenuMaster.Deptcode = DeptCode.ToString(); model.MenuMaster.Permission = Permission.ToString(); }
            else if (MenuId != null) { string[] DP = Utility.SelectColumnsValue("menumaster", "DeptCode,Permission", "menuid", MenuId.ToString()); model.MenuMaster.Deptcode = DP[0]; model.MenuMaster.Permission = DP[1]; }


            if (RType == (int)CountList.Type003)//edit
            {
                if (MenuId != null)
                {
                    string[] Val = Utility.GetNodeInfo(Convert.ToInt32(MenuId));
                    model.dta = Utility.GetMenu(null, null, true, Val[10] + "," + Val[3]);
                    model.MenuMaster.arrNode = Val;
                }
                else { }
            }
            else if (RType == (int)CountList.Type001)//add
            {
                string[] Val = Utility.GetNodeInfo(Convert.ToInt32(MenuId));
                model.dta = Utility.GetMenu(null, null, true, Val[12] + "," + Val[11]);
                model.MenuMaster.arrNode = Val;
                model.MenuMaster.MenuId = Val[2]; model.MenuMaster.GroupId = Val[5];
                model.MenuMaster.TargetMenuName = Utility.SelectColumnsValue("menumaster", "menutext", "menuid", model.MenuMaster.MenuId)[0];
                Qry = "select MenuId,MenuText from menumaster where MenuId in (" + Val[12] + "," + Val[11] + ") order by MenuId";
                Cmd = new NpgsqlCommand(Qry);
                model.MenuMaster.PeersList = new SelectList(MenuMaster.List<MenuMaster>(Cmd), "MenuId", "Menutext");
            }
            else if (RType == (int)CountList.Type002)//deactivate
            {
                string[] Val = Utility.GetNodeInfo(Convert.ToInt32(MenuId));
                model.dta = Utility.GetMenu(null, null, true, Val[10] + "," + Val[3]);
                model.MenuMaster.arrNode = Val;
                model.MenuMaster.MenuId = Val[2]; model.MenuMaster.GroupId = Val[5];
                model.MenuMaster.TargetMenuName = Utility.SelectColumnsValue("menumaster", "menutext", "menuid", model.MenuMaster.MenuId)[0];
                model.MenuMaster.NoteMessage = string.Empty; model.MenuMaster.Flag = false;
                if (Val[4].ToUpper() == CustomText.FALSE.ToString()) { model.MenuMaster.NoteMessage = "<span style=\"color:#D64541\">Note:</span> This MenuItem has a sub-menu, deactivating it will also deactivate all the linked sub menus as well.<br />"; }
                if (Val[9].ToUpper() == CustomText.FALSE.ToString() && Val[5] != ((int)CountList.Type000).ToString())
                {
                    string[] GV = Utility.SelectColumnsValue("menumaster", "Menutext,Menuaction,Menucontroller", "MenuId", Val[12]);
                    model.MenuMaster.Menutext = GV[0]; model.MenuMaster.Menuaction = GV[1]; model.MenuMaster.Menucontroller = GV[2];
                    model.MenuMaster.Flag = true; model.MenuMaster.NoteMessage += "<span style=\"color:#D64541\">Note:</span> This MenuItem is the last menu option of its parent, to deactivate it please provide link details as the parent will now have to become a link again.<br />";
                }
                model.MenuMaster.NoteMessage += "<span style=\"color:#D64541\">Note:</span> After deactivation you may not see it in the list, use the seperate module for re-activation.";
            }
            else if (RType == (int)CountList.Type004)//order
            {
                string[] Val = Utility.GetNodeInfo(Convert.ToInt32(MenuId));
                model.dta = Utility.GetMenu(null, null, true, Val[12] + "," + Val[11]);
                model.MenuMaster.arrNode = Val;
                model.MenuMaster.MenuId = Val[2]; model.MenuMaster.GroupId = Val[5];
                model.MenuMaster.NoteMessage = string.Empty; model.MenuMaster.Flag = false;
                if (Val[9].ToUpper() == CustomText.FALSE.ToString()) { model.MenuMaster.Flag = true; model.MenuMaster.NoteMessage = "<span style=\"color:#D64541\">Note:</span> This MenuItem has no peers or other items to shift places.<br />"; }
                else
                {
                    model.MenuMaster.TargetMenuName = Utility.SelectColumnsValue("menumaster", "menutext", "menuid", model.MenuMaster.MenuId)[0];
                    Qry = "select MenuId,MenuText from menumaster where MenuId in (" + Val[12] + "," + Val[11] + ") order by MenuId";
                    Cmd = new NpgsqlCommand(Qry);
                    model.MenuMaster.PeersList = new SelectList(MenuMaster.List<MenuMaster>(Cmd), "MenuId", "Menutext");
                }
            }
            else if (RType == (int)CountList.Type005)//update
            {
                model.MenuMaster.MenuId = MenuId.ToString();
                model.MenuMaster.arrNode = Utility.GetNodeInfo(Convert.ToInt32(model.MenuMaster.MenuId));
                string[] GetV = Utility.SelectColumnsValue("menumaster", "menutext,menuaction,menucontroller", "menuid", model.MenuMaster.MenuId);
                model.MenuMaster.Menutext = GetV[0]; model.MenuMaster.Menuaction = GetV[1]; model.MenuMaster.Menucontroller = GetV[2];
                if (model.MenuMaster.arrNode[8].ToUpper() == CustomText.TRUE.ToString())
                {
                    GetV = Utility.SelectColumnsValue("parametermaster", "paramname,paramvalue", "menuid", model.MenuMaster.MenuId);
                    model.MenuMaster.ParameterName = GetV[0]; model.MenuMaster.ParameterValue = GetV[1]; model.MenuMaster.Parameter = CustomText.TRUE.ToString();
                }
                else { model.MenuMaster.Parameter = CustomText.FALSE.ToString(); }
            }
            else
            {
                model.dta = Utility.GetMenu(Convert.ToInt32(Permission), Convert.ToInt32(DeptCode), true, null);
                model.MenuMaster.PermissionName = Utility.SelectColumnsValue("permissionmaster", "pname", "pcode", model.MenuMaster.Permission.ToString())[0];
                model.MenuMaster.DeptName = Utility.SelectColumnsValue("deptmaster", "deptname", "deptcode", model.MenuMaster.Deptcode.ToString())[0];
                return View("MenuManagement", model);
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult ProcessMenuOption(AdminModels model)
        {
            //0- Permission,1- DeptCode,2- MenuId,3- Head,4- WhetherLink,5- GroupId,6- DisplayOrder,7- WhetherActive,8- WhetherParameter,
            //9- Whether Peers Exist,10- Get All Related,11- All Peers, 12- First Parent,13- Next Node
            GetData data = new GetData();
            string Qry = string.Empty;
            NpgsqlCommand Cmd = null;
            if (model.MenuMaster.RType == ((int)CountList.Type001).ToString())//add
            {
                string PivotId = string.Empty;
                if (model.MenuMaster.AddAsSubMenu)
                {
                    PivotId = model.MenuMaster.MenuId;
                }
                else
                {
                    PivotId = model.MenuMaster.Head;
                }

                if (!string.IsNullOrEmpty(model.MenuMaster.MenuId))
                {
                    ViewBag.message = Utility.InsertNode(model.MenuMaster.Menutext, model.MenuMaster.Menuaction, model.MenuMaster.Menucontroller, PivotId, model.MenuMaster.AddAsSubMenu, null);
                    string[] Val = Utility.GetNodeInfo(Convert.ToInt32(model.MenuMaster.MenuId));
                    model.dta = Utility.GetMenu(Convert.ToInt32(model.MenuMaster.Permission), Convert.ToInt32(model.MenuMaster.Deptcode), true, Val[12] + "," + Val[11]);
                    model.MenuMaster.arrNode = Val;
                    model.MenuMaster.MenuId = Val[2]; model.MenuMaster.GroupId = Val[5];
                    model.MenuMaster.TargetMenuName = Utility.SelectColumnsValue("menumaster", "menutext", "menuid", model.MenuMaster.MenuId)[0];
                    Qry = "select MenuId,MenuText from menumaster where MenuId in (" + Val[12] + "," + Val[11] + ") order by MenuId";
                    Cmd = new NpgsqlCommand(Qry);
                    model.MenuMaster.PeersList = new SelectList(MenuMaster.List<MenuMaster>(Cmd), "MenuId", "Menutext");
                }
                else
                {
                    ViewBag.message = Utility.InsertNode(model.MenuMaster.Menutext, model.MenuMaster.Menuaction, model.MenuMaster.Menucontroller, PivotId, model.MenuMaster.AddAsSubMenu, model.MenuMaster.Deptcode + "|" + model.MenuMaster.Permission);
                    model.dta = Utility.GetMenu(Convert.ToInt32(model.MenuMaster.Permission), Convert.ToInt32(model.MenuMaster.Deptcode), true, null);
                    model.MenuMaster.PermissionName = Utility.SelectColumnsValue("permissionmaster", "pname", "pcode", model.MenuMaster.Permission.ToString())[0];
                    model.MenuMaster.DeptName = Utility.SelectColumnsValue("deptmaster", "deptname", "deptcode", model.MenuMaster.Deptcode.ToString())[0];
                    return View("MenuManagement", model);
                }
            }
            else if (model.MenuMaster.RType == ((int)CountList.Type002).ToString())//deactivate
            {
                string[] Val = Utility.GetNodeInfo(Convert.ToInt32(model.MenuMaster.MenuId));
                ViewBag.message = Utility.DeactivateNode(model.MenuMaster.Menutext, model.MenuMaster.Menuaction, model.MenuMaster.Menucontroller, model.MenuMaster.MenuId, model.MenuMaster.Flag);
                model.dta = Utility.GetMenu(Convert.ToInt32(Val[0]), Convert.ToInt32(Val[1]), true, null);
                model.MenuMaster.PermissionName = Utility.SelectColumnsValue("permissionmaster", "pname", "pcode", Val[0].ToString())[0];
                model.MenuMaster.DeptName = Utility.SelectColumnsValue("deptmaster", "deptname", "deptcode", Val[1].ToString())[0];
                return View("MenuManagement", model);
            }
            else if (model.MenuMaster.RType == ((int)CountList.Type004).ToString())//order
            {
                string[] Val = Utility.GetNodeInfo(Convert.ToInt32(model.MenuMaster.MenuId));
                ViewBag.message = Utility.UpdateNodeOrder(model.MenuMaster.MenuId, model.MenuMaster.Head);
                model.dta = Utility.GetMenu(null, null, true, Val[12] + "," + Val[11]);
                model.MenuMaster.arrNode = Val;
                model.MenuMaster.MenuId = Val[2]; model.MenuMaster.GroupId = Val[5];
                model.MenuMaster.NoteMessage = string.Empty; model.MenuMaster.Flag = false;
                if (Val[9].ToUpper() == CustomText.FALSE.ToString()) { model.MenuMaster.Flag = true; model.MenuMaster.NoteMessage = "<span style=\"color:#D64541\">Note:</span> This MenuItem has no peers or other items to shift places.<br />"; }
                else
                {
                    model.MenuMaster.TargetMenuName = Utility.SelectColumnsValue("menumaster", "menutext", "menuid", model.MenuMaster.MenuId)[0];
                    Qry = "select MenuId,MenuText from menumaster where MenuId in (" + Val[12] + "," + Val[11] + ") order by MenuId";
                    Cmd = new NpgsqlCommand(Qry);
                    model.MenuMaster.PeersList = new SelectList(MenuMaster.List<MenuMaster>(Cmd), "MenuId", "Menutext");
                }
            }
            else if (model.MenuMaster.RType == ((int)CountList.Type005).ToString())//update
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                Qry = "update menumaster set Menutext=@Menutext,Menuaction=@Menuaction,Menucontroller=@Menucontroller,actiondatetime=now() where MenuId=@MenuId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@MenuId", model.MenuMaster.MenuId);
                Cmd.Parameters.AddWithValue("@Menutext", model.MenuMaster.Menutext);
                Cmd.Parameters.AddWithValue("@Menuaction", model.MenuMaster.Menuaction);
                Cmd.Parameters.AddWithValue("@Menucontroller", model.MenuMaster.Menucontroller);
                cmdList.Add(Cmd);
                if (model.MenuMaster.AddParameter)
                {
                    cmdList.AddRange(Utility.InsertNodeParameter(model.MenuMaster.MenuId, model.MenuMaster.ParameterName, model.MenuMaster.ParameterValue, model.MenuMaster.RemoveParameter));
                }
                data.SaveData(cmdList);
                model.MenuMaster.RType = ((int)CountList.Type003).ToString();
                model.MenuMaster.arrNode = Utility.GetNodeInfo(Convert.ToInt32(model.MenuMaster.MenuId));
                model.dta = Utility.GetMenu(null, null, true, model.MenuMaster.arrNode[10] + "," + model.MenuMaster.arrNode[3]);
                ViewBag.message = "Menu Item updated successfully";
            }
            else
            {

            }
            return View(model);
        }

        //[EncryptedActionParameter]
        //[AcceptVerbs(HttpVerbs.Get)]
        //public ActionResult ProcessMenuOptions(int RType, int? MenuId, int? DeptCode, int? Permission)
        //{
        //    AdminModels model = new AdminModels();
        //    model.MenuMaster = new MenuMaster();
        //    GetData data = new GetData();
        //    string Qry = string.Empty;
        //    NpgsqlCommand Cmd = null;

        //    model.MenuMaster.RType = RType.ToString();
        //    if (MenuId == null)
        //    {
        //        if (DeptCode != null && Permission != null)
        //        {
        //            model.MenuMaster.Deptcode = DeptCode.ToString();
        //            model.MenuMaster.Permission = Permission.ToString();
        //            model.MenuMaster.PermissionName = Utility.SelectColumnsValue("permissionmaster", "pname", "pcode", model.MenuMaster.Permission)[0];
        //            model.MenuMaster.DeptName = Utility.SelectColumnsValue("deptmaster", "deptname", "deptcode", model.MenuMaster.Deptcode)[0];
        //        }

        //    }
        //    else
        //    {
        //        model.MenuMaster.Deptcode = Utility.SelectColumnsValue("MenuMaster", "DeptCode", "MenuId", MenuId.ToString())[0];
        //        model.MenuMaster.Permission = Utility.SelectColumnsValue("MenuMaster", "Permission", "MenuId", MenuId.ToString())[0];
        //        model.MenuMaster.PermissionName = Utility.SelectColumnsValue("permissionmaster", "pname", "pcode", model.MenuMaster.Permission)[0];
        //        model.MenuMaster.DeptName = Utility.SelectColumnsValue("deptmaster", "deptname", "deptcode", model.MenuMaster.Deptcode)[0];
        //    }

        //    if (RType == (int)CountList.Type001 || RType == (int)CountList.Type002)
        //    {
        //        Qry = "update MenuMaster set WhetherActive=@WhetherActive,actiondatetime=now(),UserId=@UserId,IpAddress=@IpAddress where MenuId=@MenuId";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@WhetherActive", RType == (int)CountList.Type001 ? CustomText.False.ToString() : RType == (int)CountList.Type002 ? CustomText.True.ToString() : CustomText.False.ToString());
        //        Cmd.Parameters.AddWithValue("@MenuId", MenuId);
        //        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
        //        Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
        //        data.UpdateData(Cmd);

        //        Qry = "select * from MenuMaster where DeptCode=@Deptcode and Permission=@Permission order by DisplayOrder,SubDisplayOrder";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@Deptcode", model.MenuMaster.Deptcode);
        //        Cmd.Parameters.AddWithValue("@Permission", model.MenuMaster.Permission);
        //        model.dta = data.GetDataTable(Cmd);
        //        return View("MenuManagement", model);
        //    }
        //    else if (RType == (int)CountList.Type003)
        //    {
        //        if (MenuId == null)
        //        {
        //            Qry = "select * from MenuMaster  where  DeptCode=@Deptcode and Permission=@Permission and Parent=0 and WhetherActive=@WhetherActive order by DisplayOrder,SubDisplayOrder";
        //            Cmd = new NpgsqlCommand(Qry);
        //            Cmd.Parameters.AddWithValue("@Deptcode", model.MenuMaster.Deptcode);
        //            Cmd.Parameters.AddWithValue("@Permission", model.MenuMaster.Permission);
        //            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
        //            model.dta = data.GetDataTable(Cmd);
        //            model.MenuMaster.MCounter = ((int)CountList.Type001).ToString();
        //        }
        //        else
        //        {
        //            Qry = "select * from MenuMaster  where (MenuId=@MenuId or Parent=@MenuId) and WhetherActive=@WhetherActive order by DisplayOrder,SubDisplayOrder";
        //            Cmd = new NpgsqlCommand(Qry);
        //            Cmd.Parameters.AddWithValue("@MenuId", MenuId);
        //            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
        //            model.dta = data.GetDataTable(Cmd);
        //            model.MenuMaster.MCounter = (model.dta.Rows.Count).ToString();
        //            model.MenuMaster.MenuId = MenuId.ToString();
        //        }
        //    }
        //    else
        //    {
        //        return RedirectToAction("BadRequest", "Error");
        //    }
        //    return View(model);
        //}
        //[AcceptVerbs(HttpVerbs.Post)]
        //[ValidateOnlyIncomingValues]
        //[ValidateAntiForgeryToken]
        //public ActionResult ProcessMenuOptions(AdminModels model, FormCollection frm)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        string Qry = string.Empty, RecvdId = string.Empty;
        //        CMDInfoList CmdInfo = new CMDInfoList();
        //        NpgsqlCommand Cmd = null;
        //        GetData data = new GetData();
        //        List<CMDInfoList> cmdList = new List<CMDInfoList>();

        //        int varCount = Convert.ToInt16(model.MenuMaster.MCounter);
        //        if (!string.IsNullOrEmpty(model.MenuMaster.MenuId))
        //        {
        //            model.MenuMaster.Parent = model.MenuMaster.MenuId;
        //            model.MenuMaster.Deptcode = Utility.SelectColumnsValue("MenuMaster", "DeptCode", "MenuId", model.MenuMaster.MenuId.ToString())[0];
        //            model.MenuMaster.Permission = Utility.SelectColumnsValue("MenuMaster", "Permission", "MenuId", model.MenuMaster.MenuId.ToString())[0];
        //            model.MenuMaster.PermissionName = Utility.SelectColumnsValue("permissionmaster", "pname", "pcode", model.MenuMaster.Permission)[0];
        //            model.MenuMaster.DeptName = Utility.SelectColumnsValue("deptmaster", "deptname", "deptcode", model.MenuMaster.Deptcode)[0];
        //        }
        //        else { model.MenuMaster.Parent = ((int)CountList.Type000).ToString(); }

        //        int GroupId = 0, flag = 1, SubDisplayOrder = 0, setSubDisplayOrder = 0;
        //        string DisplayOrder = string.Empty, Whethersubheading = string.Empty, WhetherLastOption = CustomText.False.ToString();
        //        string setWhethersubheading = string.Empty, Param = string.Empty, setWhetherLastOption = CustomText.False.ToString();
        //        for (int i = 1; i <= varCount; i++)
        //        {
        //            if ((frm["MenuText" + i] != null))
        //            {
        //                if (frm["MenuId" + i] != null)
        //                {
        //                    if (frm["Menuaction" + i] == null)
        //                    {
        //                        Param = "Parameter=@Parameter,";
        //                    }
        //                    else { Param = string.Empty; }
        //                    Qry = "update MenuMaster set Menutext=@Menutext,Menuaction=@Menuaction,Menucontroller=@Menucontroller,Whethersubheading=@Whethersubheading," + Param + "UserId=@UserId,Ipaddress=@Ipaddress,Actiondatetime=now() where MenuId=@MenuId";
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    Cmd.Parameters.AddWithValue("@MenuId", frm["MenuId" + i].ToString());
        //                    Cmd.Parameters.AddWithValue("@Menutext", frm["Menutext" + i].ToString());
        //                    Cmd.Parameters.AddWithValue("@Menuaction", frm["Menuaction" + i] == null ? null : frm["Menuaction" + i].ToString());
        //                    Cmd.Parameters.AddWithValue("@Menucontroller", frm["Menucontroller" + i] == null ? null : frm["Menucontroller" + i].ToString());
        //                    if (frm["Menuaction" + i] == null)
        //                    {
        //                        Cmd.Parameters.AddWithValue("@Whethersubheading", CustomText.True.ToString());
        //                        Cmd.Parameters.AddWithValue("@Parameter", CustomText.False.ToString());
        //                    }
        //                    else { Cmd.Parameters.AddWithValue("@Whethersubheading", CustomText.False.ToString()); }
        //                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
        //                    Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
        //                    CmdInfo = new CMDInfoList();
        //                    CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
        //                    cmdList.Add(CmdInfo);
        //                    if (frm["Menuaction" + i] == null)
        //                    {
        //                        Qry = "select PId from ParameterMaster where MenuId=@MenuId";
        //                        Cmd = new NpgsqlCommand(Qry);
        //                        Cmd.Parameters.AddWithValue("@MenuId", frm["MenuId" + i].ToString());
        //                        if (!string.IsNullOrEmpty((data.SelectColumns(Cmd)[0])))
        //                        {
        //                            Qry = "delete from ParameterMaster where MenuId=@MenuId";
        //                            Cmd = new NpgsqlCommand(Qry);
        //                            Cmd.Parameters.AddWithValue("@MenuId", frm["MenuId" + i].ToString());
        //                            CmdInfo = new CMDInfoList();
        //                            CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
        //                            cmdList.Add(CmdInfo);
        //                        }
        //                    }
        //                }
        //                else
        //                {
        //                    string str = " SELECT currval(pg_get_serial_sequence('menumaster','menuid'))";
        //                    string Parent = "@Parent";
        //                    int Endtagcount = 0;
        //                    if (model.MenuMaster.Parent == ((int)CountList.Type000).ToString())
        //                    {
        //                        if (flag == 1)
        //                        {
        //                            SubDisplayOrder = 1; DisplayOrder = Utility.SelectColumnsValue("menumaster", "max(displayorder)+1", "1", "1")[0]; GroupId = 1;

        //                            Qry = "update menumaster set WhetherLastOption=@WhetherLastOption where Deptcode=@Deptcode and Permission=@Permission and Parent=0";
        //                            Cmd = new NpgsqlCommand(Qry);
        //                            Cmd.Parameters.AddWithValue("@WhetherLastOption", CustomText.False.ToString());
        //                            Cmd.Parameters.AddWithValue("@Deptcode", model.MenuMaster.Deptcode);
        //                            Cmd.Parameters.AddWithValue("@Permission", model.MenuMaster.Permission);
        //                            CmdInfo = new CMDInfoList();
        //                            CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
        //                            cmdList.Add(CmdInfo);
        //                        }
        //                        else { str = string.Empty; Parent = "@Parameter1"; GroupId = 2; SubDisplayOrder++; }
        //                        if (i == varCount) { if (varCount > 1) { Endtagcount = 1; } WhetherLastOption = CustomText.True.ToString(); }
        //                    }
        //                    else
        //                    {
        //                        if (flag == 1)
        //                        {
        //                            string[] GetV = Utility.SelectColumnsValue("MenuMaster", "Parent,DisplayOrder,GroupId,WhetherLastOption,Whethersubheading,SubDisplayOrder", "MenuId", model.MenuMaster.MenuId);
        //                            //int RootParent = Convert.ToInt32(GetV[0]);
        //                            DisplayOrder = GetV[1];
        //                            GroupId = Convert.ToInt32(GetV[2]) + 1;
        //                            setWhetherLastOption = GetV[3];
        //                            setWhethersubheading = GetV[4];
        //                            SubDisplayOrder = Convert.ToInt32(GetV[5]);
        //                            setSubDisplayOrder = Convert.ToInt32(GetV[5]);
        //                        }

        //                        string LastChildofSelected = string.Empty, LastChild = string.Empty;
        //                        int tempSubDisplayOrder = 0;
        //                        if (setWhetherLastOption == CustomText.False.ToString())
        //                        {
        //                            if (setWhethersubheading == CustomText.True.ToString())
        //                            {
        //                                if (flag == 1)
        //                                {
        //                                    string[] LC = Utility.GetLastChilds(model.MenuMaster.MenuId);
        //                                    LastChild = LC[0]; LastChildofSelected = LC[1]; tempSubDisplayOrder = Convert.ToInt32(LC[2]);

        //                                    Qry = "update menumaster set WhetherLastOption=@WhetherLastOption where MenuId=@LastChildofSelected";
        //                                    Cmd = new NpgsqlCommand(Qry);
        //                                    Cmd.Parameters.AddWithValue("@WhetherLastOption", CustomText.False.ToString());
        //                                    Cmd.Parameters.AddWithValue("@LastChildofSelected", LastChildofSelected);
        //                                    CmdInfo = new CMDInfoList();
        //                                    CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
        //                                    cmdList.Add(CmdInfo);

        //                                    Qry = "update menumaster set endtagcount=(select endtagcount-1 from menumaster where MenuId=@LastChild) where MenuId=@LastChild";
        //                                    Cmd = new NpgsqlCommand(Qry);
        //                                    Cmd.Parameters.AddWithValue("@LastChild", LastChild);
        //                                    CmdInfo = new CMDInfoList();
        //                                    CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
        //                                    cmdList.Add(CmdInfo);
        //                                }
        //                                if (i == varCount) { Endtagcount = 1; WhetherLastOption = CustomText.True.ToString(); }
        //                                else { Endtagcount = 0; WhetherLastOption = CustomText.False.ToString(); }
        //                            }
        //                            else
        //                            {
        //                                if (i == varCount) { Endtagcount = 1; WhetherLastOption = CustomText.True.ToString(); }
        //                                else { Endtagcount = 0; WhetherLastOption = CustomText.False.ToString(); }
        //                            }
        //                        }
        //                        else
        //                        {
        //                            if (setWhethersubheading == CustomText.True.ToString())
        //                            {
        //                                if (flag == 1)
        //                                {
        //                                    string[] LC = Utility.GetLastChilds(model.MenuMaster.MenuId);
        //                                    LastChild = LC[0]; LastChildofSelected = LC[1]; tempSubDisplayOrder = Convert.ToInt32(LC[2]);

        //                                    Qry = "update menumaster set WhetherLastOption=@WhetherLastOption where MenuId=@LastChildofSelected";
        //                                    Cmd = new NpgsqlCommand(Qry);
        //                                    Cmd.Parameters.AddWithValue("@WhetherLastOption", CustomText.False.ToString());
        //                                    Cmd.Parameters.AddWithValue("@LastChildofSelected", LastChildofSelected);
        //                                    CmdInfo = new CMDInfoList();
        //                                    CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
        //                                    cmdList.Add(CmdInfo);

        //                                    Qry = "update menumaster set endtagcount=((select groupid from menumaster where MenuId=@LastChild)-(select groupid from menumaster where MenuId=@LastChildofSelected)) where MenuId=@LastChild";
        //                                    Cmd = new NpgsqlCommand(Qry);
        //                                    Cmd.Parameters.AddWithValue("@LastChild", LastChild);
        //                                    Cmd.Parameters.AddWithValue("@LastChildofSelected", LastChildofSelected);
        //                                    CmdInfo = new CMDInfoList();
        //                                    CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
        //                                    cmdList.Add(CmdInfo);
        //                                }
        //                                if (i == varCount) { Endtagcount = Utility.GetEndTagCount(model.MenuMaster.MenuId, DisplayOrder, setSubDisplayOrder); WhetherLastOption = CustomText.True.ToString(); }
        //                                else { Endtagcount = 0; WhetherLastOption = CustomText.False.ToString(); }
        //                            }
        //                            else
        //                            {
        //                                if (flag == 1)
        //                                {
        //                                    Qry = "update menumaster set endtagcount=0 where MenuId=@MenuId";
        //                                    Cmd = new NpgsqlCommand(Qry);
        //                                    Cmd.Parameters.AddWithValue("@MenuId", model.MenuMaster.MenuId);
        //                                    CmdInfo = new CMDInfoList();
        //                                    CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
        //                                    cmdList.Add(CmdInfo);
        //                                }
        //                                if (i == varCount)
        //                                {
        //                                    Endtagcount = Utility.GetEndTagCount(model.MenuMaster.MenuId, DisplayOrder, setSubDisplayOrder);
        //                                    WhetherLastOption = CustomText.True.ToString();
        //                                }
        //                                else { Endtagcount = 0; WhetherLastOption = CustomText.False.ToString(); }
        //                            }
        //                        }
        //                        if (flag == 1)
        //                        {
        //                            int InsertCount = 0;
        //                            int MaxSubDisplayOrder = Convert.ToInt32(Utility.SelectColumnsValue("MenuMaster", "MAX(SubDisplayOrder)", "DisplayOrder", DisplayOrder)[0]);
        //                            for (int s = 1; s <= varCount; s++)
        //                            {
        //                                if (frm["MenuId" + s] == null)
        //                                { InsertCount++; }
        //                            }
        //                            if (setWhethersubheading == CustomText.True.ToString())
        //                            {
        //                                if (tempSubDisplayOrder > SubDisplayOrder) { SubDisplayOrder = tempSubDisplayOrder; }
        //                            }
        //                            if (MaxSubDisplayOrder > SubDisplayOrder)
        //                            {
        //                                for (int k = MaxSubDisplayOrder; k > SubDisplayOrder; k--)
        //                                {
        //                                    Qry = "update menumaster set SubDisplayOrder=SubDisplayOrder+@InsertCount where DisplayOrder=@DisplayOrder and SubDisplayOrder=@MaxSubDisplayOrder";
        //                                    Cmd = new NpgsqlCommand(Qry);
        //                                    Cmd.Parameters.AddWithValue("@DisplayOrder", DisplayOrder);
        //                                    Cmd.Parameters.AddWithValue("@MaxSubDisplayOrder", MaxSubDisplayOrder);
        //                                    Cmd.Parameters.AddWithValue("@InsertCount", InsertCount);
        //                                    CmdInfo = new CMDInfoList();
        //                                    CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
        //                                    cmdList.Add(CmdInfo);
        //                                    MaxSubDisplayOrder--;
        //                                }
        //                                SubDisplayOrder++;
        //                            }
        //                            else { SubDisplayOrder = MaxSubDisplayOrder + 1; }
        //                        }
        //                        else { SubDisplayOrder++; }
        //                        //if (RootParent != 0){int ParentCheck = 9999;
        //                        //    while (true)
        //                        //    { ParentCheck = Convert.ToInt32(Utility.SelectColumnsValue("MenuMaster", "Parent", "MenuId", RootParent.ToString())[0]);
        //                        //    if (ParentCheck == 0) { Root = RootParent; break; } else { RootParent = ParentCheck; }
        //                        //    }}else { Root = RootParent; }
        //                    }
        //                    flag++;
        //                    Qry = "insert into MenuMaster(Menutext,Menuaction,Menucontroller,Parent,Deptcode,Permission,Parameter,Whetherservicespecific,Displayorder,SubDisplayOrder,Whethersubheading,Endtagcount,Whetheractive,AddDate,GroupId,WhetherLastOption,UserId,Ipaddress,Actiondatetime) values (@Menutext,@Menuaction,@Menucontroller," + Parent + ",@Deptcode,@Permission,@Parameter,@Whetherservicespecific,@Displayorder,@SubDisplayOrder,@Whethersubheading,@Endtagcount,@Whetheractive,now(),@GroupId,@WhetherLastOption,@userid,@ipaddress,now()); " + str;
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    Cmd.Parameters.AddWithValue("@Menutext", frm["Menutext" + i].ToString());
        //                    Cmd.Parameters.AddWithValue("@Menuaction", frm["Menuaction" + i] == null ? null : frm["Menuaction" + i].ToString());
        //                    Cmd.Parameters.AddWithValue("@Menucontroller", frm["Menucontroller" + i] == null ? null : frm["Menucontroller" + i].ToString());
        //                    Cmd.Parameters.AddWithValue("@Parent", model.MenuMaster.Parent);
        //                    Cmd.Parameters.AddWithValue("@GroupId", GroupId);
        //                    Cmd.Parameters.AddWithValue("@Deptcode", model.MenuMaster.Deptcode);
        //                    Cmd.Parameters.AddWithValue("@Permission", model.MenuMaster.Permission);
        //                    Cmd.Parameters.AddWithValue("@Parameter", CustomText.False.ToString());
        //                    Cmd.Parameters.AddWithValue("@Whetherservicespecific", CustomText.False.ToString());
        //                    Cmd.Parameters.AddWithValue("@Displayorder", DisplayOrder);
        //                    Cmd.Parameters.AddWithValue("@SubDisplayOrder", SubDisplayOrder);
        //                    if (model.MenuMaster.Parent == ((int)CountList.Type000).ToString() && varCount > 1 && i == 1)
        //                    {
        //                        Cmd.Parameters.AddWithValue("@Whethersubheading", CustomText.True.ToString());
        //                    }
        //                    else { Cmd.Parameters.AddWithValue("@Whethersubheading", CustomText.False.ToString()); }
        //                    Cmd.Parameters.AddWithValue("@Endtagcount", Endtagcount);
        //                    Cmd.Parameters.AddWithValue("@Whetheractive", CustomText.True.ToString());
        //                    Cmd.Parameters.AddWithValue("@WhetherLastOption", WhetherLastOption);
        //                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
        //                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
        //                    if (model.MenuMaster.Parent == ((int)CountList.Type000).ToString())
        //                    {
        //                        if (i == 1)
        //                        {
        //                            CmdInfo = new CMDInfoList();
        //                            CmdInfo.Cmd = Cmd; CmdInfo.Returns = true; CmdInfo.ParamenterIndex = null;
        //                            cmdList.Add(CmdInfo);
        //                        }
        //                        else
        //                        {
        //                            CmdInfo = new CMDInfoList();
        //                            CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = new int[] { 1 };
        //                            cmdList.Add(CmdInfo);
        //                        }
        //                    }
        //                    else
        //                    {
        //                        CmdInfo = new CMDInfoList();
        //                        CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
        //                        cmdList.Add(CmdInfo);
        //                    }
        //                }
        //            }
        //        }
        //        data.SaveTransactionalDataCustom(cmdList);
        //        Qry = "select * from MenuMaster where DeptCode=@Deptcode and Permission=@Permission order by DisplayOrder,SubDisplayOrder";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@Deptcode", model.MenuMaster.Deptcode);
        //        Cmd.Parameters.AddWithValue("@Permission", model.MenuMaster.Permission);
        //        model.dta = data.GetDataTable(Cmd);
        //        ViewBag.message = "Added!";
        //        return View("MenuManagement", model);
        //    }
        //    return View(model);
        //}
        //[EncryptedActionParameter]
        //[AcceptVerbs(HttpVerbs.Get)]
        //public ActionResult ChangeMenuOrder(int DeptCode, int Permission)
        //{
        //    AdminModels model = new AdminModels();
        //    model.MenuMaster = new MenuMaster();
        //    model.MenuMaster.Deptcode = DeptCode.ToString();
        //    model.MenuMaster.Permission = Permission.ToString();
        //    GetData data = new GetData(); string Qry = string.Empty;
        //    Qry = "select *,'Parent'||Parent as ddlname from MenuMaster where DeptCode=@Deptcode and Permission=@Permission and WhetherActive=@WhetherActive order by DisplayOrder,SubDisplayOrder";
        //    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
        //    Cmd.Parameters.AddWithValue("@Deptcode", DeptCode);
        //    Cmd.Parameters.AddWithValue("@Permission", Permission);
        //    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
        //    model.dta = data.GetDataTable(Cmd);
        //    model.MenuMaster.PermissionName = Utility.SelectColumnsValue("permissionmaster", "pname", "pcode", Permission.ToString())[0];
        //    model.MenuMaster.DeptName = Utility.SelectColumnsValue("deptmaster", "deptname", "deptcode", DeptCode.ToString())[0];

        //    Qry = "select distinct Parent from MenuMaster where DeptCode=@Deptcode and Permission=@Permission and WhetherActive=@WhetherActive order by 1";
        //    Cmd = new NpgsqlCommand(Qry);
        //    Cmd.Parameters.AddWithValue("@Deptcode", DeptCode);
        //    Cmd.Parameters.AddWithValue("@Permission", Permission);
        //    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
        //    DataTable dt = data.GetDataTable(Cmd);
        //    if (dt.Rows.Count > 0)
        //    {
        //        for (int i = 0; i < dt.Rows.Count; i++)
        //        {
        //            Qry = "select MenuId,MenuText from MenuMaster where Parent=@Parent and DeptCode=@Deptcode and Permission=@Permission and WhetherActive=@WhetherActive order by 2";
        //            Cmd = new NpgsqlCommand(Qry);
        //            Cmd.Parameters.AddWithValue("@Parent", dt.Rows[i]["Parent"]);
        //            Cmd.Parameters.AddWithValue("@Deptcode", DeptCode);
        //            Cmd.Parameters.AddWithValue("@Permission", Permission);
        //            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
        //            DataTable dt2 = data.GetDataTable(Cmd);
        //            List<SelectListItem> varDropDownList = new List<SelectListItem>();
        //            foreach (DataRow Row in dt2.Rows)
        //            {
        //                varDropDownList.Add(new SelectListItem { Text = Row["MenuText"].ToString(), Value = Row["MenuId"].ToString() });
        //            }
        //            ViewData["Parent" + dt.Rows[i]["Parent"].ToString()] = new SelectList(varDropDownList, "Value", "Text"); ;
        //        }
        //    }
        //    return View(model);
        //}
        //[AcceptVerbs(HttpVerbs.Post)]
        //[ValidateOnlyIncomingValues]
        //[ValidateAntiForgeryToken]
        //public ActionResult ChangeMenuOrder(AdminModels model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        GetData data = new GetData(); string Qry = string.Empty; NpgsqlCommand Cmd = null;
        //        if (string.IsNullOrEmpty(model.MenuMaster.MenuId)) { return RedirectToAction("BadRequest", "Error"); }
        //        List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
        //        if (model.MenuMaster.RType == ((int)CountList.Type003).ToString())//Down
        //        {
        //            int DownSubDisplayOrder = 0;
        //            string CheckNextWL = string.Empty, NextMenuId = string.Empty;
        //            Qry = "select MenuId,DisplayOrder,SubDisplayOrder,WhetherLastOption from MenuMaster where Parent=@Parent and DeptCode=@Deptcode and Permission=@Permission and WhetherActive=@WhetherActive order by DisplayOrder,SubDisplayOrder";
        //            Cmd = new NpgsqlCommand(Qry);
        //            Cmd.Parameters.AddWithValue("@Parent", Convert.ToInt32(Utility.SelectColumnsValue("MenuMaster", "Parent", "MenuId", model.MenuMaster.MenuId)[0]));
        //            Cmd.Parameters.AddWithValue("@Deptcode", model.MenuMaster.Deptcode);
        //            Cmd.Parameters.AddWithValue("@Permission", model.MenuMaster.Permission);
        //            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
        //            DataTable dtpre = data.GetDataTable(Cmd);
        //            for (int l = 0; l < dtpre.Rows.Count; l++)
        //            {
        //                if (dtpre.Rows[l]["MenuId"].ToString() == model.MenuMaster.MenuId)
        //                {
        //                    DownSubDisplayOrder = Convert.ToInt32(dtpre.Rows[l + 1]["SubDisplayOrder"]);
        //                    CheckNextWL = dtpre.Rows[l + 1]["WhetherLastOption"].ToString();
        //                    NextMenuId = dtpre.Rows[l + 1]["MenuId"].ToString();
        //                }
        //            }
        //            model.MenuMaster.MenuId = NextMenuId;
        //        }
        //        string[] GetValues = Utility.SelectColumnsValue("MenuMaster", "Parent,GroupId,DisplayOrder,SubDisplayOrder,WhetherLastOption,WhetherSubHeading", "MenuId", model.MenuMaster.MenuId);
        //        int setParent = Convert.ToInt32(GetValues[0]); int setGroupId = Convert.ToInt32(GetValues[1]);
        //        int setDisplayOrder = Convert.ToInt32(GetValues[2]); int setSubDisplayOrder = Convert.ToInt32(GetValues[3]);
        //        string setWhetherLastOption = GetValues[4]; string setWhetherSubHeading = GetValues[5];
        //        int MaxSubDisplayOrder = Convert.ToInt32(Utility.SelectColumnsValue("MenuMaster", "MAX(SubDisplayOrder)", "DisplayOrder", setDisplayOrder.ToString())[0]);
        //        Qry = "select max(DisplayOrder),min(DisplayOrder) from MenuMaster  where DeptCode=@Deptcode and Permission=@Permission and WhetherActive=@WhetherActive";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
        //        Cmd.Parameters.AddWithValue("@Deptcode", model.MenuMaster.Deptcode);
        //        Cmd.Parameters.AddWithValue("@Permission", model.MenuMaster.Permission);
        //        string[] GetV = data.SelectColumns(Cmd);
        //        int MaxDisplayOrder = Convert.ToInt32(GetV[0]);
        //        int MinDisplayOrder = Convert.ToInt32(GetV[1]);

        //        Qry = "select MenuId,DisplayOrder,SubDisplayOrder,WhetherLastOption from MenuMaster where Parent=@Parent and DeptCode=@Deptcode and Permission=@Permission and WhetherActive=@WhetherActive order by DisplayOrder,SubDisplayOrder";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@Parent", setParent);
        //        Cmd.Parameters.AddWithValue("@Deptcode", model.MenuMaster.Deptcode);
        //        Cmd.Parameters.AddWithValue("@Permission", model.MenuMaster.Permission);
        //        Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
        //        DataTable dt = data.GetDataTable(Cmd);
        //        int TopDisplayOrder = Convert.ToInt32(dt.Rows[0]["DisplayOrder"]);
        //        int TopSubDisplayOrder = Convert.ToInt32(dt.Rows[0]["SubDisplayOrder"]);
        //        int BottomDisplayOrder = Convert.ToInt32(dt.Rows[dt.Rows.Count - 1]["DisplayOrder"]);
        //        int BottomSubDisplayOrder = Convert.ToInt32(dt.Rows[dt.Rows.Count - 1]["SubDisplayOrder"]);

        //        if (model.MenuMaster.RType == ((int)CountList.Type001).ToString())//Top
        //        {
        //            #region Move to Top
        //            if (setWhetherLastOption.ToUpper() == CustomText.TRUE.ToString())
        //            {
        //                Qry = "update MenuMaster set WhetherLastOption=@WhetherLastOption where MenuId=@MenuId";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@WhetherLastOption", CustomText.False.ToString());
        //                Cmd.Parameters.AddWithValue("@MenuId", model.MenuMaster.MenuId);
        //                cmdList.Add(Cmd);

        //                string[] LC = Utility.GetLastChilds(model.MenuMaster.MenuId);
        //                int CGroupId = Convert.ToInt32(Utility.SelectColumnsValue("MenuMaster", "GroupId", "MenuId", LC[0])[0]);
        //                int NewEndTagCountPostSwap = CGroupId - setGroupId;

        //                Qry = "update MenuMaster set EndTagCount=@EndTagCount where MenuId=@MenuId";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@EndTagCount", NewEndTagCountPostSwap);
        //                Cmd.Parameters.AddWithValue("@MenuId", LC[0]);
        //                cmdList.Add(Cmd);

        //            }
        //            if (setParent == (int)CountList.Type000)
        //            {
        //                Qry = "update MenuMaster set DisplayOrder=@tempDisplayOrder where DisplayOrder=@TopDisplayOrder";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@tempDisplayOrder", 999);
        //                Cmd.Parameters.AddWithValue("@TopDisplayOrder", TopDisplayOrder);
        //                cmdList.Add(Cmd);

        //                Qry = "update MenuMaster set DisplayOrder=@TopDisplayOrder where DisplayOrder=@setDisplayOrder";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@TopDisplayOrder", TopDisplayOrder);
        //                Cmd.Parameters.AddWithValue("@setDisplayOrder", setDisplayOrder);
        //                cmdList.Add(Cmd);

        //                for (int i = 0; i < (setDisplayOrder - TopDisplayOrder); i++)
        //                {
        //                    string qq = string.Empty;
        //                    if (i == (setDisplayOrder - TopDisplayOrder) - 1) { qq = "DisplayOrder=@DisplayOrder"; } else { qq = "DisplayOrder=DisplayOrder+1"; }
        //                    Qry = "update MenuMaster set " + qq + " where DisplayOrder=@NextDisplayOrder";
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    if (i == (setDisplayOrder - TopDisplayOrder) - 1)
        //                    {
        //                        Cmd.Parameters.AddWithValue("@DisplayOrder", TopDisplayOrder + 1);
        //                        Cmd.Parameters.AddWithValue("@NextDisplayOrder", 999);
        //                    }
        //                    else
        //                    {
        //                        Cmd.Parameters.AddWithValue("@NextDisplayOrder", setDisplayOrder - (i + 1));
        //                    }
        //                    cmdList.Add(Cmd);
        //                }
        //                Qry = "update menumaster set WhetherLastOption=@WhetherLastOption where MenuId=(select MenuId from MenuMaster where DisplayOrder=@MaxDisplayOrder and WhetherActive=@WhetherActive and Parent=0)";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@MaxDisplayOrder", MaxDisplayOrder);
        //                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
        //                Cmd.Parameters.AddWithValue("@WhetherLastOption", CustomText.True.ToString());

        //                cmdList.Add(Cmd);
        //            }
        //            else //Parent not 0
        //            {
        //                int NewLSubDisplayOrder = 0, LCSubDisplayOrder = 0, LCGroupId = 0;
        //                if (setWhetherLastOption.ToUpper() == CustomText.TRUE.ToString())
        //                {
        //                    Qry = "select MenuId,SubDisplayOrder from MenuMaster where Parent=@setParent and WhetherLastOption=@WhetherLastOption and WhetherActive=@WhetherActive order by DisplayOrder,SubDisplayOrder";
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    Cmd.Parameters.AddWithValue("@setParent", setParent);
        //                    Cmd.Parameters.AddWithValue("@WhetherLastOption", CustomText.False.ToString());
        //                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
        //                    DataTable tdt = data.GetDataTable(Cmd);
        //                    int NewLMenuId = Convert.ToInt32(tdt.Rows[tdt.Rows.Count - 1]["MenuId"]);
        //                    NewLSubDisplayOrder = Convert.ToInt32(tdt.Rows[tdt.Rows.Count - 1]["SubDisplayOrder"]);
        //                }

        //                int BlockSize = 1;
        //                if (setWhetherSubHeading.ToUpper() == CustomText.TRUE.ToString())
        //                {
        //                    string[] LC = Utility.GetLastChilds(model.MenuMaster.MenuId);
        //                    string[] GV = Utility.SelectColumnsValue("MenuMaster", "SubDisplayOrder,GroupId", "MenuId", LC[0]);
        //                    LCSubDisplayOrder = Convert.ToInt32(GV[0]); LCGroupId = Convert.ToInt32(GV[1]);
        //                    BlockSize = LCSubDisplayOrder - setSubDisplayOrder + 1;
        //                }
        //                else { LCSubDisplayOrder = setSubDisplayOrder; LCGroupId = setGroupId; }

        //                for (int l = 0; l < BlockSize; l++)
        //                {
        //                    Qry = "update MenuMaster set SubDisplayOrder=@tempSubDisplayOrder where SubDisplayOrder=@setSubDisplayOrder and DisplayOrder=@DisplayOrder";
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                    Cmd.Parameters.AddWithValue("@tempSubDisplayOrder", 999 + l);
        //                    Cmd.Parameters.AddWithValue("@setSubDisplayOrder", setSubDisplayOrder + l);
        //                    cmdList.Add(Cmd);
        //                }

        //                for (int l = 0; l < (setSubDisplayOrder - TopSubDisplayOrder); l++)
        //                {
        //                    string qlast = string.Empty; string qendtagcount = string.Empty;
        //                    int NewEndTagCount = 0;
        //                    if (setWhetherLastOption.ToUpper() == CustomText.TRUE.ToString())
        //                    {
        //                        if ((setSubDisplayOrder - (l + 1)) == NewLSubDisplayOrder) { qlast = ",WhetherLastOption=@WhetherLastOption "; }
        //                        if (l == 0)
        //                        {
        //                            if (MaxSubDisplayOrder == LCSubDisplayOrder)
        //                            {
        //                                NewEndTagCount = LCGroupId - 1;
        //                                qendtagcount = ",EndTagCount=@EndTagCount ";
        //                            }
        //                            else
        //                            {
        //                                Qry = "select GroupId from menumaster where GroupId<@GroupId and DisplayOrder=@DisplayOrder and SubDisplayOrder>@SubDisplayOrder  and Whetheractive=@Whetheractive order by DisplayOrder,SubDisplayOrder limit 1 ";
        //                                Cmd = new NpgsqlCommand(Qry);
        //                                Cmd.Parameters.AddWithValue("@GroupId", setGroupId);
        //                                Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                                Cmd.Parameters.AddWithValue("@SubDisplayOrder", LCSubDisplayOrder);
        //                                Cmd.Parameters.AddWithValue("@Whetheractive", CustomText.True.ToString());
        //                                int NextGroupId = Convert.ToInt32(data.SelectColumns(Cmd)[0]);

        //                                Qry = "select GroupId from menumaster where DisplayOrder=@DisplayOrder and SubDisplayOrder=@SubDisplayOrder and Whetheractive=@Whetheractive";
        //                                Cmd = new NpgsqlCommand(Qry);
        //                                Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                                Cmd.Parameters.AddWithValue("@SubDisplayOrder", setSubDisplayOrder - 1);
        //                                Cmd.Parameters.AddWithValue("@Whetheractive", CustomText.True.ToString());
        //                                int CGroupId = Convert.ToInt32(data.SelectColumns(Cmd)[0]);

        //                                NewEndTagCount = CGroupId - NextGroupId;
        //                                qendtagcount = ",EndTagCount=@EndTagCount ";
        //                            }
        //                        }
        //                    }
        //                    Qry = "update MenuMaster set SubDisplayOrder=SubDisplayOrder+@BlockSize " + qlast + qendtagcount + " where SubDisplayOrder=@NextSubDisplayOrder and DisplayOrder=@DisplayOrder";
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                    Cmd.Parameters.AddWithValue("@BlockSize", BlockSize);
        //                    Cmd.Parameters.AddWithValue("@NextSubDisplayOrder", setSubDisplayOrder - (l + 1));
        //                    if (!string.IsNullOrEmpty(qendtagcount)) { Cmd.Parameters.AddWithValue("@EndTagCount", NewEndTagCount); }
        //                    if (!string.IsNullOrEmpty(qlast)) { Cmd.Parameters.AddWithValue("@WhetherLastOption", CustomText.TRUE.ToString()); }
        //                    cmdList.Add(Cmd);
        //                }

        //                for (int l = 0; l < BlockSize; l++)
        //                {
        //                    Qry = "update MenuMaster set SubDisplayOrder=@TopSubDisplayOrder where SubDisplayOrder=@tempSubDisplayOrder and DisplayOrder=@DisplayOrder";
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                    Cmd.Parameters.AddWithValue("@TopSubDisplayOrder", TopSubDisplayOrder + l);
        //                    Cmd.Parameters.AddWithValue("@tempSubDisplayOrder", 999 + l);
        //                    cmdList.Add(Cmd);
        //                }
        //            }
        //            #endregion Move to Top
        //        }
        //        if (model.MenuMaster.RType == ((int)CountList.Type002).ToString())//Up
        //        {
        //            #region Move Up
        //            int UpDisplayOrder = setDisplayOrder - 1;
        //            int UpSubDisplayOrder = 0;
        //            for (int l = 0; l < dt.Rows.Count; l++)
        //            {
        //                if (dt.Rows[l]["MenuId"].ToString() == model.MenuMaster.MenuId)
        //                { UpSubDisplayOrder = Convert.ToInt32(dt.Rows[l - 1]["SubDisplayOrder"]); }
        //            }

        //            if (setWhetherLastOption.ToUpper() == CustomText.TRUE.ToString())
        //            {
        //                Qry = "update MenuMaster set WhetherLastOption=@WhetherLastOption where MenuId=@MenuId";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@WhetherLastOption", CustomText.False.ToString());
        //                Cmd.Parameters.AddWithValue("@MenuId", model.MenuMaster.MenuId);
        //                cmdList.Add(Cmd);

        //                string[] LC = Utility.GetLastChilds(model.MenuMaster.MenuId);
        //                int CGroupId = Convert.ToInt32(Utility.SelectColumnsValue("MenuMaster", "GroupId", "MenuId", LC[0])[0]);
        //                int NewEndTagCountPostSwap = CGroupId - setGroupId;

        //                Qry = "update MenuMaster set EndTagCount=@EndTagCount where MenuId=@MenuId";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@EndTagCount", NewEndTagCountPostSwap);
        //                Cmd.Parameters.AddWithValue("@MenuId", LC[0]);
        //                cmdList.Add(Cmd);

        //            }
        //            if (setParent == (int)CountList.Type000)
        //            {
        //                Qry = "update MenuMaster set DisplayOrder=@tempDisplayOrder where DisplayOrder=@UpDisplayOrder";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@tempDisplayOrder", 999);
        //                Cmd.Parameters.AddWithValue("@UpDisplayOrder", UpDisplayOrder);
        //                cmdList.Add(Cmd);

        //                Qry = "update MenuMaster set DisplayOrder=@UpDisplayOrder where DisplayOrder=@setDisplayOrder";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@UpDisplayOrder", UpDisplayOrder);
        //                Cmd.Parameters.AddWithValue("@setDisplayOrder", setDisplayOrder);
        //                cmdList.Add(Cmd);

        //                Qry = "update MenuMaster set DisplayOrder=@setDisplayOrder  where DisplayOrder=@tempDisplayOrder";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@setDisplayOrder", setDisplayOrder);
        //                Cmd.Parameters.AddWithValue("@tempDisplayOrder", 999);
        //                cmdList.Add(Cmd);

        //                Qry = "update menumaster set WhetherLastOption=@WhetherLastOption where MenuId=(select MenuId from MenuMaster where DisplayOrder=@MaxDisplayOrder and WhetherActive=@WhetherActive and Parent=0)";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@MaxDisplayOrder", MaxDisplayOrder);
        //                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
        //                Cmd.Parameters.AddWithValue("@WhetherLastOption", CustomText.True.ToString());
        //                cmdList.Add(Cmd);
        //            }
        //            else //Parent not 0
        //            {
        //                int LCSubDisplayOrder = 0, LCGroupId = 0;

        //                int BlockSize = 1;
        //                if (setWhetherSubHeading.ToUpper() == CustomText.TRUE.ToString())
        //                {
        //                    string[] LC = Utility.GetLastChilds(model.MenuMaster.MenuId);
        //                    string[] GV = Utility.SelectColumnsValue("MenuMaster", "SubDisplayOrder,GroupId", "MenuId", LC[0]);
        //                    LCSubDisplayOrder = Convert.ToInt32(GV[0]); LCGroupId = Convert.ToInt32(GV[1]);
        //                    BlockSize = LCSubDisplayOrder - setSubDisplayOrder + 1;
        //                }
        //                else { LCSubDisplayOrder = setSubDisplayOrder; LCGroupId = setGroupId; }

        //                for (int l = 0; l < BlockSize; l++)
        //                {
        //                    Qry = "update MenuMaster set SubDisplayOrder=@tempSubDisplayOrder where SubDisplayOrder=@setSubDisplayOrder and DisplayOrder=@DisplayOrder";
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                    Cmd.Parameters.AddWithValue("@tempSubDisplayOrder", 999 + l);
        //                    Cmd.Parameters.AddWithValue("@setSubDisplayOrder", setSubDisplayOrder + l);
        //                    cmdList.Add(Cmd);
        //                }

        //                for (int l = 0; l < (setSubDisplayOrder - UpSubDisplayOrder); l++)
        //                {
        //                    string qlast = string.Empty; string qendtagcount = string.Empty;
        //                    int NewEndTagCount = 0;
        //                    if (setWhetherLastOption.ToUpper() == CustomText.TRUE.ToString())
        //                    {
        //                        if ((setSubDisplayOrder - (l + 1)) == UpSubDisplayOrder) { qlast = ",WhetherLastOption=@WhetherLastOption "; }
        //                        if (l == 0)
        //                        {
        //                            if (MaxSubDisplayOrder == LCSubDisplayOrder)
        //                            {
        //                                NewEndTagCount = LCGroupId - 1;
        //                            }
        //                            else
        //                            {
        //                                Qry = "select GroupId from menumaster where GroupId<@GroupId and DisplayOrder=@DisplayOrder and SubDisplayOrder>@SubDisplayOrder  and Whetheractive=@Whetheractive order by DisplayOrder,SubDisplayOrder limit 1 ";
        //                                Cmd = new NpgsqlCommand(Qry);
        //                                Cmd.Parameters.AddWithValue("@GroupId", setGroupId);
        //                                Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                                Cmd.Parameters.AddWithValue("@SubDisplayOrder", LCSubDisplayOrder);
        //                                Cmd.Parameters.AddWithValue("@Whetheractive", CustomText.True.ToString());
        //                                int NextGroupId = Convert.ToInt32(data.SelectColumns(Cmd)[0]);

        //                                Qry = "select GroupId from menumaster where DisplayOrder=@DisplayOrder and SubDisplayOrder=@SubDisplayOrder and Whetheractive=@Whetheractive";
        //                                Cmd = new NpgsqlCommand(Qry);
        //                                Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                                Cmd.Parameters.AddWithValue("@SubDisplayOrder", setSubDisplayOrder - 1);
        //                                Cmd.Parameters.AddWithValue("@Whetheractive", CustomText.True.ToString());
        //                                int CGroupId = Convert.ToInt32(data.SelectColumns(Cmd)[0]);

        //                                NewEndTagCount = CGroupId - NextGroupId;
        //                                qendtagcount = ",EndTagCount=@EndTagCount ";
        //                            }
        //                        }
        //                    }
        //                    Qry = "update MenuMaster set SubDisplayOrder=SubDisplayOrder+@BlockSize " + qlast + qendtagcount + " where SubDisplayOrder=@NextSubDisplayOrder and DisplayOrder=@DisplayOrder";
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                    Cmd.Parameters.AddWithValue("@BlockSize", BlockSize);
        //                    Cmd.Parameters.AddWithValue("@NextSubDisplayOrder", setSubDisplayOrder - (l + 1));
        //                    if (!string.IsNullOrEmpty(qendtagcount)) { Cmd.Parameters.AddWithValue("@EndTagCount", NewEndTagCount); }
        //                    if (!string.IsNullOrEmpty(qlast)) { Cmd.Parameters.AddWithValue("@WhetherLastOption", CustomText.TRUE.ToString()); }
        //                    cmdList.Add(Cmd);
        //                }

        //                for (int l = 0; l < BlockSize; l++)
        //                {
        //                    Qry = "update MenuMaster set SubDisplayOrder=@UpSubDisplayOrder where SubDisplayOrder=@tempSubDisplayOrder and DisplayOrder=@DisplayOrder";
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                    Cmd.Parameters.AddWithValue("@UpSubDisplayOrder", UpSubDisplayOrder + l);
        //                    Cmd.Parameters.AddWithValue("@tempSubDisplayOrder", 999 + l);
        //                    cmdList.Add(Cmd);
        //                }
        //            }
        //            #endregion Move Up
        //        }
        //        if (model.MenuMaster.RType == ((int)CountList.Type003).ToString())//Down
        //        {
        //            #region Move Down
        //            int UpDisplayOrder = setDisplayOrder - 1;
        //            int UpSubDisplayOrder = 0;
        //            for (int l = 0; l < dt.Rows.Count; l++)
        //            {
        //                if (dt.Rows[l]["MenuId"].ToString() == model.MenuMaster.MenuId)
        //                { UpSubDisplayOrder = Convert.ToInt32(dt.Rows[l - 1]["SubDisplayOrder"]); }
        //            }

        //            if (setWhetherLastOption.ToUpper() == CustomText.TRUE.ToString())
        //            {
        //                Qry = "update MenuMaster set WhetherLastOption=@WhetherLastOption where MenuId=@MenuId";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@WhetherLastOption", CustomText.False.ToString());
        //                Cmd.Parameters.AddWithValue("@MenuId", model.MenuMaster.MenuId);
        //                cmdList.Add(Cmd);

        //                string[] LC = Utility.GetLastChilds(model.MenuMaster.MenuId);
        //                int CGroupId = Convert.ToInt32(Utility.SelectColumnsValue("MenuMaster", "GroupId", "MenuId", LC[0])[0]);
        //                int NewEndTagCountPostSwap = CGroupId - setGroupId;

        //                Qry = "update MenuMaster set EndTagCount=@EndTagCount where MenuId=@MenuId";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@EndTagCount", NewEndTagCountPostSwap);
        //                Cmd.Parameters.AddWithValue("@MenuId", LC[0]);
        //                cmdList.Add(Cmd);

        //            }
        //            if (setParent == (int)CountList.Type000)
        //            {
        //                Qry = "update MenuMaster set DisplayOrder=@tempDisplayOrder where DisplayOrder=@UpDisplayOrder";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@tempDisplayOrder", 999);
        //                Cmd.Parameters.AddWithValue("@UpDisplayOrder", UpDisplayOrder);
        //                cmdList.Add(Cmd);

        //                Qry = "update MenuMaster set DisplayOrder=@UpDisplayOrder where DisplayOrder=@setDisplayOrder";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@UpDisplayOrder", UpDisplayOrder);
        //                Cmd.Parameters.AddWithValue("@setDisplayOrder", setDisplayOrder);
        //                cmdList.Add(Cmd);

        //                Qry = "update MenuMaster set DisplayOrder=@setDisplayOrder  where DisplayOrder=@tempDisplayOrder";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@setDisplayOrder", setDisplayOrder);
        //                Cmd.Parameters.AddWithValue("@tempDisplayOrder", 999);
        //                cmdList.Add(Cmd);

        //                Qry = "update menumaster set WhetherLastOption=@WhetherLastOption where MenuId=(select MenuId from MenuMaster where DisplayOrder=@MaxDisplayOrder and WhetherActive=@WhetherActive and Parent=0)";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@MaxDisplayOrder", MaxDisplayOrder);
        //                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
        //                Cmd.Parameters.AddWithValue("@WhetherLastOption", CustomText.True.ToString());
        //                cmdList.Add(Cmd);
        //            }
        //            else //Parent not 0
        //            {
        //                int LCSubDisplayOrder = 0, LCGroupId = 0;

        //                int BlockSize = 1;
        //                if (setWhetherSubHeading.ToUpper() == CustomText.TRUE.ToString())
        //                {
        //                    string[] LC = Utility.GetLastChilds(model.MenuMaster.MenuId);
        //                    string[] GV = Utility.SelectColumnsValue("MenuMaster", "SubDisplayOrder,GroupId", "MenuId", LC[0]);
        //                    LCSubDisplayOrder = Convert.ToInt32(GV[0]); LCGroupId = Convert.ToInt32(GV[1]);
        //                    BlockSize = LCSubDisplayOrder - setSubDisplayOrder + 1;
        //                }
        //                else { LCSubDisplayOrder = setSubDisplayOrder; LCGroupId = setGroupId; }

        //                for (int l = 0; l < BlockSize; l++)
        //                {
        //                    Qry = "update MenuMaster set SubDisplayOrder=@tempSubDisplayOrder where SubDisplayOrder=@setSubDisplayOrder and DisplayOrder=@DisplayOrder";
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                    Cmd.Parameters.AddWithValue("@tempSubDisplayOrder", 999 + l);
        //                    Cmd.Parameters.AddWithValue("@setSubDisplayOrder", setSubDisplayOrder + l);
        //                    cmdList.Add(Cmd);
        //                }

        //                for (int l = 0; l < (setSubDisplayOrder - UpSubDisplayOrder); l++)
        //                {
        //                    string qlast = string.Empty; string qendtagcount = string.Empty;
        //                    int NewEndTagCount = 0;
        //                    if (setWhetherLastOption.ToUpper() == CustomText.TRUE.ToString())
        //                    {
        //                        if ((setSubDisplayOrder - (l + 1)) == UpSubDisplayOrder) { qlast = ",WhetherLastOption=@WhetherLastOption "; }
        //                        if (l == 0)
        //                        {
        //                            if (MaxSubDisplayOrder == LCSubDisplayOrder)
        //                            {
        //                                NewEndTagCount = LCGroupId - 1;
        //                            }
        //                            else
        //                            {
        //                                Qry = "select GroupId from menumaster where GroupId<@GroupId and DisplayOrder=@DisplayOrder and SubDisplayOrder>@SubDisplayOrder  and Whetheractive=@Whetheractive order by DisplayOrder,SubDisplayOrder limit 1 ";
        //                                Cmd = new NpgsqlCommand(Qry);
        //                                Cmd.Parameters.AddWithValue("@GroupId", setGroupId);
        //                                Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                                Cmd.Parameters.AddWithValue("@SubDisplayOrder", LCSubDisplayOrder);
        //                                Cmd.Parameters.AddWithValue("@Whetheractive", CustomText.True.ToString());
        //                                int NextGroupId = Convert.ToInt32(data.SelectColumns(Cmd)[0]);

        //                                Qry = "select GroupId from menumaster where DisplayOrder=@DisplayOrder and SubDisplayOrder=@SubDisplayOrder and Whetheractive=@Whetheractive";
        //                                Cmd = new NpgsqlCommand(Qry);
        //                                Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                                Cmd.Parameters.AddWithValue("@SubDisplayOrder", setSubDisplayOrder - 1);
        //                                Cmd.Parameters.AddWithValue("@Whetheractive", CustomText.True.ToString());
        //                                int CGroupId = Convert.ToInt32(data.SelectColumns(Cmd)[0]);

        //                                NewEndTagCount = CGroupId - NextGroupId;
        //                                qendtagcount = ",EndTagCount=@EndTagCount ";
        //                            }
        //                        }
        //                    }
        //                    Qry = "update MenuMaster set SubDisplayOrder=SubDisplayOrder+@BlockSize " + qlast + qendtagcount + " where SubDisplayOrder=@NextSubDisplayOrder and DisplayOrder=@DisplayOrder";
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                    Cmd.Parameters.AddWithValue("@BlockSize", BlockSize);
        //                    Cmd.Parameters.AddWithValue("@NextSubDisplayOrder", setSubDisplayOrder - (l + 1));
        //                    if (!string.IsNullOrEmpty(qendtagcount)) { Cmd.Parameters.AddWithValue("@EndTagCount", NewEndTagCount); }
        //                    if (!string.IsNullOrEmpty(qlast)) { Cmd.Parameters.AddWithValue("@WhetherLastOption", CustomText.TRUE.ToString()); }
        //                    cmdList.Add(Cmd);
        //                }

        //                for (int l = 0; l < BlockSize; l++)
        //                {
        //                    Qry = "update MenuMaster set SubDisplayOrder=@UpSubDisplayOrder where SubDisplayOrder=@tempSubDisplayOrder and DisplayOrder=@DisplayOrder";
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                    Cmd.Parameters.AddWithValue("@UpSubDisplayOrder", UpSubDisplayOrder + l);
        //                    Cmd.Parameters.AddWithValue("@tempSubDisplayOrder", 999 + l);
        //                    cmdList.Add(Cmd);
        //                }
        //            }
        //            #endregion Move Down
        //        }
        //        if (model.MenuMaster.RType == ((int)CountList.Type004).ToString())//Bottom
        //        {
        //            #region Move to Bottom

        //            Qry = "update MenuMaster set WhetherLastOption=@WhetherLastOption where Parent=@Parent and DeptCode=@Deptcode and Permission=@Permission  and WhetherActive=@WhetherActive";
        //            Cmd = new NpgsqlCommand(Qry);
        //            Cmd.Parameters.AddWithValue("@WhetherLastOption", CustomText.False.ToString());
        //            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
        //            Cmd.Parameters.AddWithValue("@Deptcode", model.MenuMaster.Deptcode);
        //            Cmd.Parameters.AddWithValue("@Permission", model.MenuMaster.Permission);
        //            Cmd.Parameters.AddWithValue("@Parent", setParent);
        //            cmdList.Add(Cmd);

        //            if (setParent == (int)CountList.Type000)
        //            {
        //                Qry = "update MenuMaster set DisplayOrder=@tempDisplayOrder where DisplayOrder=@BottomDisplayOrder";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@tempDisplayOrder", 999);
        //                Cmd.Parameters.AddWithValue("@BottomDisplayOrder", BottomDisplayOrder);
        //                cmdList.Add(Cmd);

        //                Qry = "update MenuMaster set DisplayOrder=@BottomDisplayOrder where DisplayOrder=@setDisplayOrder";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@BottomDisplayOrder", BottomDisplayOrder);
        //                Cmd.Parameters.AddWithValue("@setDisplayOrder", setDisplayOrder);
        //                cmdList.Add(Cmd);

        //                for (int i = 0; i < (BottomDisplayOrder - setDisplayOrder); i++)
        //                {
        //                    string qq = string.Empty;
        //                    if (i == (BottomDisplayOrder - setDisplayOrder) - 1) { qq = "DisplayOrder=@DisplayOrder"; } else { qq = "DisplayOrder=DisplayOrder-1"; }
        //                    Qry = "update MenuMaster set " + qq + " where DisplayOrder=@NextDisplayOrder";
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    if (i == (BottomDisplayOrder - setDisplayOrder) - 1)
        //                    {
        //                        Cmd.Parameters.AddWithValue("@DisplayOrder", BottomDisplayOrder - 1);
        //                        Cmd.Parameters.AddWithValue("@NextDisplayOrder", 999);
        //                    }
        //                    else
        //                    {
        //                        Cmd.Parameters.AddWithValue("@NextDisplayOrder", setDisplayOrder + (i + 1));
        //                    }
        //                    cmdList.Add(Cmd);
        //                }
        //                Qry = "update menumaster set WhetherLastOption=@WhetherLastOption where MenuId=(select MenuId from MenuMaster where DisplayOrder=@MaxDisplayOrder and WhetherActive=@WhetherActive and Parent=0)";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@MaxDisplayOrder", MaxDisplayOrder);
        //                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.True.ToString());
        //                Cmd.Parameters.AddWithValue("@WhetherLastOption", CustomText.True.ToString());

        //                cmdList.Add(Cmd);
        //            }
        //            else //Parent not 0
        //            {
        //                int LCSubDisplayOrder = 0, LCGroupId = 0;

        //                int BlockSize = 1;
        //                if (setWhetherSubHeading.ToUpper() == CustomText.TRUE.ToString())
        //                {
        //                    string[] LC = Utility.GetLastChilds(model.MenuMaster.MenuId);
        //                    string[] GV = Utility.SelectColumnsValue("MenuMaster", "SubDisplayOrder,GroupId", "MenuId", LC[0]);
        //                    LCSubDisplayOrder = Convert.ToInt32(GV[0]); LCGroupId = Convert.ToInt32(GV[1]);
        //                    BlockSize = LCSubDisplayOrder - setSubDisplayOrder + 1;
        //                }
        //                else { LCSubDisplayOrder = setSubDisplayOrder; LCGroupId = setGroupId; }

        //                for (int l = 0; l < BlockSize; l++)
        //                {
        //                    Qry = "update MenuMaster set SubDisplayOrder=@tempSubDisplayOrder where SubDisplayOrder=@setSubDisplayOrder and DisplayOrder=@DisplayOrder";
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                    Cmd.Parameters.AddWithValue("@tempSubDisplayOrder", 999 + l);
        //                    Cmd.Parameters.AddWithValue("@setSubDisplayOrder", setSubDisplayOrder + l);
        //                    cmdList.Add(Cmd);
        //                }

        //                bool WhetherBottomLast = false;
        //                Qry = "select MenuId from MenuMaster where SubDisplayOrder=@SubDisplayOrder and DisplayOrder=@DisplayOrder";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                Cmd.Parameters.AddWithValue("@SubDisplayOrder", BottomSubDisplayOrder);
        //                string[] LCofBottom = Utility.GetLastChilds(data.SelectColumns(Cmd)[0]);
        //                string[] GVBottom = Utility.SelectColumnsValue("MenuMaster", "SubDisplayOrder,GroupId", "MenuId", LCofBottom[0]);
        //                int LCBottomSubDisplayOrder = Convert.ToInt32(GVBottom[0]); 
        //                int LCBottomGroupId = Convert.ToInt32(GVBottom[1]);
        //                if (LCBottomSubDisplayOrder == 0) { LCBottomSubDisplayOrder = BottomSubDisplayOrder; }
        //                if (LCBottomGroupId == 0) { LCBottomGroupId = setGroupId; }

        //                for (int l = 0; l < (LCBottomSubDisplayOrder - LCSubDisplayOrder); l++)
        //                {
        //                    string qlast = string.Empty; string qendtagcount = string.Empty;
        //                    int NewEndTagCount = 0;
        //                    if ((setSubDisplayOrder + BlockSize) + l == MaxSubDisplayOrder) { WhetherBottomLast = true; }
        //                    if ((setSubDisplayOrder + BlockSize) + l == BottomSubDisplayOrder) { qlast = ",WhetherLastOption=@WhetherLastOption "; }
        //                    if (l == (LCBottomSubDisplayOrder - LCSubDisplayOrder) - 1)
        //                    {
        //                        NewEndTagCount = LCBottomGroupId - setGroupId;
        //                        qendtagcount = ",EndTagCount=@EndTagCount ";
        //                    }

        //                    Qry = "update MenuMaster set SubDisplayOrder=SubDisplayOrder-@BlockSize " + qlast + qendtagcount + " where SubDisplayOrder=@NextSubDisplayOrder and DisplayOrder=@DisplayOrder";
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                    Cmd.Parameters.AddWithValue("@BlockSize", BlockSize);
        //                    Cmd.Parameters.AddWithValue("@NextSubDisplayOrder", (setSubDisplayOrder + BlockSize) + l);
        //                    if (!string.IsNullOrEmpty(qendtagcount)) { Cmd.Parameters.AddWithValue("@EndTagCount", NewEndTagCount); }
        //                    if (!string.IsNullOrEmpty(qlast)) { Cmd.Parameters.AddWithValue("@WhetherLastOption", CustomText.False.ToString()); }
        //                    cmdList.Add(Cmd);
        //                }

        //                for (int l = 0; l < BlockSize; l++)
        //                {
        //                    string qlast = string.Empty; string qendtagcount = string.Empty;
        //                    int NewEndTagCount = 0;

        //                    if (l == 0) { qlast = ",WhetherLastOption=@WhetherLastOption "; }
        //                    if (l == BlockSize - 1)
        //                    {
        //                        if (WhetherBottomLast)
        //                        {
        //                            NewEndTagCount = LCGroupId - 1;
        //                            qendtagcount = ",EndTagCount=@EndTagCount ";
        //                        }
        //                        else
        //                        {
        //                            qlast = ",WhetherLastOption=@WhetherLastOption ";

        //                            Qry = "select GroupId from menumaster where GroupId<@GroupId and DisplayOrder=@DisplayOrder and SubDisplayOrder>@SubDisplayOrder  and Whetheractive=@Whetheractive order by DisplayOrder,SubDisplayOrder limit 1 ";
        //                            Cmd = new NpgsqlCommand(Qry);
        //                            Cmd.Parameters.AddWithValue("@GroupId", setGroupId);
        //                            Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                            Cmd.Parameters.AddWithValue("@SubDisplayOrder", BottomSubDisplayOrder);
        //                            Cmd.Parameters.AddWithValue("@Whetheractive", CustomText.True.ToString());
        //                            int NextGroupId = Convert.ToInt32(data.SelectColumns(Cmd)[0]);

        //                            NewEndTagCount = LCGroupId - NextGroupId;
        //                            qendtagcount = ",EndTagCount=@EndTagCount ";
        //                        }
        //                    }

        //                    Qry = "update MenuMaster set SubDisplayOrder=@BottomSubDisplayOrder " + qlast + qendtagcount + " where SubDisplayOrder=@tempSubDisplayOrder and DisplayOrder=@DisplayOrder";
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    Cmd.Parameters.AddWithValue("@DisplayOrder", setDisplayOrder);
        //                    Cmd.Parameters.AddWithValue("@BottomSubDisplayOrder", (LCBottomSubDisplayOrder - (BlockSize - 1)) + l);
        //                    Cmd.Parameters.AddWithValue("@tempSubDisplayOrder", 999 + l);
        //                    if (!string.IsNullOrEmpty(qendtagcount)) { Cmd.Parameters.AddWithValue("@EndTagCount", NewEndTagCount); }
        //                    if (!string.IsNullOrEmpty(qlast)) { Cmd.Parameters.AddWithValue("@WhetherLastOption", CustomText.True.ToString()); }
        //                    cmdList.Add(Cmd);
        //                }
        //            }
        //            #endregion Move to Bottom
        //        }
        //        data.SaveData(cmdList);
        //        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DeptCode", "Permission" }, new ArrayList() { model.MenuMaster.Deptcode, model.MenuMaster.Permission });
        //        return RedirectToAction("ChangeMenuOrder", "Admin", new { q = QueryString });
        //    }
        //    return View(model);
        //}
        #endregion

        #region Document Management

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult DocumentManagement()
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult DocumentManagement(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            string Qry = string.Empty;
            NpgsqlCommand Cmd = new NpgsqlCommand();
            List<CMDInfoList> cmdList = new List<CMDInfoList>();
            CMDInfoList CmdInfo = new CMDInfoList();

            if (model.ReqTypeId == ((int)CountList.Type002).ToString())
            {
                ArrayList Values = new ArrayList();
                Qry = "select DocumentTypeName from DocumenttypeMaster where DocumentTypeName=@DocumentTypeName and WhetherActive=@WhetherActive limit 1";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@DocumentTypeName", model.DocumentMaster.DocumentName);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                string check = data.SelectColumns(Cmd)[0];
                if (!string.IsNullOrEmpty(check)) { return View(model); }

                Qry = "select 'Doc'||DocumentId as DocControlId from documentmaster where WhetherActive=@WhetherActive order by DocumentName";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                DataTable dta = data.GetDataTable(Cmd);
                for (int i = 0; i < dta.Rows.Count; i++)
                {
                    if (frm[dta.Rows[i]["DocControlId"].ToString()] != null)
                    {
                        Values.Add(frm[dta.Rows[i]["DocControlId"].ToString()]);
                    }
                }

                if (Values == null && string.IsNullOrEmpty(model.AddDoc)) { return View(model); }

                Qry = "insert into dbo.documenttypemaster(DocumentTypeName,WhetherActive,userid,ipaddress,actiondatetime) values(@DocumentTypeName,@WhetherActive,@userid,@ipaddress,now()); SELECT currval(pg_get_serial_sequence('dbo.documenttypemaster','documenttypeid'))";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@DocumentTypeName", model.DocumentMaster.DocumentName);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                CmdInfo = new CMDInfoList();
                CmdInfo.Cmd = Cmd; CmdInfo.Returns = true; CmdInfo.ParamenterIndex = null;
                cmdList.Add(CmdInfo);

                if (!string.IsNullOrEmpty(model.AddDoc))
                {
                    Qry = "select Documentname from DocumentMaster where Documentname=@Documentname and WhetherActive=@WhetherActive limit 1";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@Documentname", model.AddDoc);
                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                    check = data.SelectColumns(Cmd)[0];
                    if (!string.IsNullOrEmpty(check)) { return View(model); }

                    Qry = "insert into dbo.documentmaster(DocumentName,WhetherActive,userid,ipaddress,actiondatetime) values(@DocumentName,@WhetherActive,@userid,@ipaddress,now()); SELECT currval(pg_get_serial_sequence('dbo.documentmaster','documentid'))";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@DocumentName", model.AddDoc);
                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    CmdInfo = new CMDInfoList();
                    CmdInfo.Cmd = Cmd; CmdInfo.Returns = true; CmdInfo.ParamenterIndex = null;
                    cmdList.Add(CmdInfo);

                    Qry = "insert into dbo.documenttotypemaster(documenttypeid,documentid,WhetherActive,userid,ipaddress,actiondatetime) values(@Parameter0,@Parameter1,@WhetherActive,@userid,@ipaddress,now()) ";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    CmdInfo = new CMDInfoList();
                    CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = new int[] { 0, 1 };
                    cmdList.Add(CmdInfo);
                }
                if (Values != null)
                {
                    for (int i = 0; i < Values.Count; i++)
                    {
                        Qry = "insert into dbo.documenttotypemaster(documenttypeid,documentid,WhetherActive,userid,ipaddress,actiondatetime) values(@Parameter0,@documentid,@WhetherActive,@userid,@ipaddress,now()) ";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@documentid", (Values[i]).ToString());
                        Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        CmdInfo = new CMDInfoList();
                        CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = new int[] { 0 };
                        cmdList.Add(CmdInfo);
                    }
                }
                data.SaveTransactionalDataCustom(cmdList);
            }

            if (model.ReqTypeId == ((int)CountList.Type001).ToString())
            {
                Qry = "select DocumentId,DocumentName,WhetherActive,'Doc'||DocumentId as DocControlId from documentmaster where WhetherActive=@WhetherActive order by DocumentName";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                model.dta = data.GetDataTable(Cmd);
            }

            Qry = "select @DType as DType,documenttypeid as DocumentId,DocumentTypeName as DocumentName,WhetherActive from dbo.DocumentTypeMaster where lower(DocumentTypeName) like '%" + model.DocumentMaster.DocumentName.ToLower() + "%'";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DType", (int)CountList.Type001);
            model.dataS = data.GetDataTable(Cmd);

            Qry = "select @DType as DType,DocumentId, DocumentName,WhetherActive from dbo.DocumentMaster where lower(DocumentName) like '%" + model.DocumentMaster.DocumentName.ToLower() + "%'";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DType", (int)CountList.Type002);
            model.dtb = data.GetDataTable(Cmd);
            model.dataS.Merge(model.dtb);

            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult ViewDocumentDetails(Int32 DId, int Type)
        {
            AdminModels model = new AdminModels();
            GetData data = new GetData();
            string Qry = string.Empty;
            NpgsqlCommand Cmd = new NpgsqlCommand();
            string str = string.Empty;
            if (Type == (int)CountList.Type001) { str = " DT.documenttypeid=@DId"; }
            if (Type == (int)CountList.Type002) { str = " DM.documentid=@DId"; }
            Qry = "select @Dtype as DType,DT.documenttypeid,DT.documenttypename,DM.documentid,DM.documentname from documenttypemaster DT inner join documenttotypemaster DD on DD.documenttypeid=DT.documenttypeid inner join documentmaster DM on DM.documentid=DD.documentid where " + str;
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DId", DId);
            Cmd.Parameters.AddWithValue("@DType", Type);
            model.dataS = data.GetDataTable(Cmd);
            if (Type == (int)CountList.Type001)
            {
                Qry = "select SM.servicename,case when SD.whethermandatory=true and SD.whetheroptional=false then '1' else(case when SD.whethermandatory=true and SD.whetheroptional=true then '2' else (case when SD.whethermandatory=false and SD.whetheroptional=false then '3' else '0' end)end)end as optiontype from servicetodocumentmaster SD inner join servicemaster SM on SM.servicecode=SD.servicecode where SD.WhetherActive=@WhetherActive and SD.documenttypeid=@DId order by SM.servicename";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@DId", DId);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                model.dta = data.GetDataTable(Cmd);
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult UpdateDocumentStatus(Int32 Id, int Type, string Sts, Int32? SCode)
        {
            AdminModels model = new AdminModels();
            GetData data = new GetData();
            string Qry = string.Empty;
            NpgsqlCommand Cmd = new NpgsqlCommand();

            if (Type == (int)CountList.Type001)
            {
                Qry = "update DocumentTypeMaster set WhetherActive=@WhetherActive where DocumentTypeId=@DId";
            }
            else if (Type == (int)CountList.Type002)
            {
                Qry = "update DocumentMaster set WhetherActive=@WhetherActive where DocumentId=@DId";
            }
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DId", Id);
            Cmd.Parameters.AddWithValue("@WhetherActive", Sts.ToString().ToUpper());
            data.UpdateData(Cmd);

            return View("DocumentManagement", model);

        }

        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult MapDocument(Int32 DId, int MType)
        {
            AdminModels model = new AdminModels();
            model.DocumentMaster = new DocumentMaster();
            model.DocumentMaster.DocumentID = DId.ToString();
            GetData data = new GetData();
            string Qry = string.Empty;
            NpgsqlCommand Cmd = new NpgsqlCommand();
            string str = string.Empty;
            string DName = Utility.SelectColumnsValue("DocumentTypeMaster", "DocumentTypeName", "DocumentTypeId", DId.ToString())[0];
            if (MType == (int)CountList.Type001)
            {
                Qry = "select @DName as DName,@MType as MType,'chkb'||a.documentid as DocControlId,case when b.documenttypeid is not null then '1' else '0' end as whetherselected,a.documentid,a.documentname from documentmaster a left outer join (select * from (select DT.documenttypeid,DT.documenttypename,DM.documentid,DM.documentname from documenttypemaster DT inner join documenttotypemaster DD on DD.documenttypeid=DT.documenttypeid inner join documentmaster DM on DM.documentid=DD.documentid where DT.documenttypeid=@DId and DT.WhetherActive=@WhetherActive) rs) b on b.documentid=a.documentid order by a.documentname";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@DName", DName);
                Cmd.Parameters.AddWithValue("@DId", DId);
                Cmd.Parameters.AddWithValue("@MType", MType);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                model.dataS = data.GetDataTable(Cmd);
            }
            else if (MType == (int)CountList.Type002)
            {
                Qry = "select @DName as DName,@MType as MType,'chkb'||a.servicecode as SerControlId,'rb'||a.servicecode as TControlId,case when b.documenttypeid is not null then '1' else '0' end as whetherselected,case when b.whethermandatory=true and b.whetheroptional=false then '1' else(case when b.whethermandatory=true and b.whetheroptional=true then '2' else (case when b.whethermandatory=false and b.whetheroptional=false then '3' else '0' end)end)end as optiontype,a.servicecode,a.servicename,b.documenttypeid from servicemaster a left outer join(select SM.servicecode,SM.servicename,SD.documenttypeid,SD.whethermandatory,SD,whetheroptional from servicetodocumentmaster SD inner join servicemaster SM on SM.servicecode=SD.servicecode where SD.WhetherActive=@WhetherActive and SD.documenttypeid=@DId order by SM.servicename) b on b.servicecode=a.servicecode order by a.servicename";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@DName", DName);
                Cmd.Parameters.AddWithValue("@DId", DId);
                Cmd.Parameters.AddWithValue("@MType", MType);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                model.dataS = data.GetDataTable(Cmd);
            }

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult MapDocument(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            string Qry = string.Empty;
            NpgsqlCommand Cmd = new NpgsqlCommand();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

            if (model.ReqTypeId == ((int)CountList.Type001).ToString())
            {
                ArrayList Values = new ArrayList();
                Qry = "select 'chkb'||DocumentId as DocControlId from documentmaster where WhetherActive=@WhetherActive order by DocumentName";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                DataTable dta = data.GetDataTable(Cmd);
                for (int i = 0; i < dta.Rows.Count; i++)
                {
                    if (frm[dta.Rows[i]["DocControlId"].ToString()] != null)
                    {
                        Values.Add(frm[dta.Rows[i]["DocControlId"].ToString()]);
                    }
                }
                if (Values == null) { return View(model); }
                else
                {
                    Qry = "delete from dbo.documenttotypemaster where DocumentTypeId=@DocumentTypeId";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@DocumentTypeId", model.DocumentMaster.DocumentID);
                    cmdList.Add(Cmd);

                    for (int i = 0; i < Values.Count; i++)
                    {
                        Qry = "insert into dbo.documenttotypemaster(DocumentTypeId,DocumentId,WhetherActive,userid,ipaddress,actiondatetime) values(@DocumentTypeId,@DocumentId,@WhetherActive,@userid,@ipaddress,now()) ";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@DocumentTypeId", model.DocumentMaster.DocumentID);
                        Cmd.Parameters.AddWithValue("@DocumentId", (Values[i]).ToString());
                        Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                }
                data.SaveData(cmdList);
            }
            else if (model.ReqTypeId == ((int)CountList.Type002).ToString())
            {
                ArrayList Values = new ArrayList();
                ArrayList Values2 = new ArrayList();
                Qry = "select 'chkb'||ServiceCode as SerControlId,'rb'||ServiceCode as TControlId from ServiceMaster where WhetherActive=@WhetherActive order by ServiceName";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                DataTable dta = data.GetDataTable(Cmd);
                for (int i = 0; i < dta.Rows.Count; i++)
                {
                    if (frm[dta.Rows[i]["SerControlId"].ToString()] != null)
                    {
                        Values.Add(frm[dta.Rows[i]["SerControlId"].ToString()]);
                    }
                }
                for (int i = 0; i < dta.Rows.Count; i++)
                {
                    if (frm[dta.Rows[i]["TControlId"].ToString()] != null)
                    {
                        Values2.Add(frm[dta.Rows[i]["TControlId"].ToString()]);
                    }
                }
                if (Values == null) { return View(model); }
                else
                {
                    Qry = "delete from dbo.servicetodocumentmaster where DocumentTypeId=@DocumentTypeId";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@DocumentTypeId", model.DocumentMaster.DocumentID);
                    cmdList.Add(Cmd);

                    for (int i = 0; i < Values.Count; i++)
                    {
                        Qry = "insert into dbo.servicetodocumentmaster(DocumentTypeId,ServiceCode,WhetherMandatory,WhetherOptional,WhetherActive,userid,ipaddress,actiondatetime) values(@DocumentTypeId,@ServiceCode,@WhetherMandatory,@WhetherOptional,@WhetherActive,@userid,@ipaddress,now()) ";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@DocumentTypeId", model.DocumentMaster.DocumentID);
                        Cmd.Parameters.AddWithValue("@ServiceCode", (Values[i]).ToString());
                        if (Values2[i].ToString() == ((int)CountList.Type001).ToString())
                        {
                            Cmd.Parameters.AddWithValue("@WhetherMandatory", CustomText.True.ToString());
                            Cmd.Parameters.AddWithValue("@WhetherOptional", CustomText.False.ToString());
                        }
                        else if (Values2[i].ToString() == ((int)CountList.Type002).ToString())
                        {
                            Cmd.Parameters.AddWithValue("@WhetherMandatory", CustomText.True.ToString());
                            Cmd.Parameters.AddWithValue("@WhetherOptional", CustomText.True.ToString());
                        }
                        else if (Values2[i].ToString() == ((int)CountList.Type003).ToString())
                        {
                            Cmd.Parameters.AddWithValue("@WhetherMandatory", CustomText.False.ToString());
                            Cmd.Parameters.AddWithValue("@WhetherOptional", CustomText.False.ToString());
                        }
                        else
                        {
                            Cmd.Parameters.AddWithValue("@WhetherMandatory", CustomText.True.ToString());
                            Cmd.Parameters.AddWithValue("@WhetherOptional", CustomText.False.ToString());
                        }
                        Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                    }
                }
                data.SaveData(cmdList);
            }
            model.ReqTypeId = null;
            ViewBag.DisplayMessage = "Linking/Unlinking completed successfully";
            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "DId", "Type" }, new ArrayList() { model.DocumentMaster.DocumentID, ((int)CountList.Type001).ToString() });
            return RedirectToAction("ViewDocumentDetails", "Admin", new { q = QueryString });
        }
        #endregion Document Management

        #region Validation management
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult ApplicationValidationManagement(int? sid, int? lvlid)
        {
            GetData data = new GetData();
            AdminModels model = new AdminModels();
            if (sid == null || lvlid == null) { return View(model); }

            model.ServiceCode = sid.ToString();
            model.LevelId = lvlid.ToString();
            model.ServiceName = Utility.SelectColumnsValue("Servicemaster", "servicename", "servicecode", model.ServiceCode)[0];
            model.LevelName = Utility.SelectColumnsValue("selectmastervaluedetails", "valuename", "valueid", model.LevelId)[0];

            string Qry = "select * from servicevalidationcheckmaster where servicecode=@sid and levelid=@lvlid and whetheractive=true";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@sid", model.ServiceCode);
            Cmd.Parameters.AddWithValue("@lvlid", model.LevelId);
            DataTable dt = data.GetDataTable(Cmd);
            DataSet ds = Utility.GetValidationTables(dt);

            if (ds.Tables.Contains("dtValidation")) { model.data = ds.Tables["dtValidation"]; }
            if (ds.Tables.Contains("dtAuthentication")) { model.dataS = ds.Tables["dtAuthentication"]; }
            if (ds.Tables.Contains("dtSigning")) { model.dataSC = ds.Tables["dtSigning"]; }
            if (ds.Tables.Contains("dtStatus")) { model.dataSCC = ds.Tables["dtStatus"]; }

            if (TempData[Constant._ActionMessage] != null) { ViewBag.message = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ApplicationValidationManagement(AdminModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid", "lvlid" }, new ArrayList() { model.ServiceCode, model.LevelId });
                return RedirectToAction("ApplicationValidationManagement", "Admin", new { q = QueryString });
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SaveApplicationValidation(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            DataSet ds = new DataSet();
            string Qry = string.Empty, QueryString = string.Empty;
            NpgsqlCommand Cmd = new NpgsqlCommand();
            List<NpgsqlCommand> cmdList1 = new List<NpgsqlCommand>();
            ArrayList Values = new ArrayList();

            Qry = "select * from servicevalidationcheckmaster where servicecode=@sid and levelid=@lvlid and whetheractive=true";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@sid", model.ServiceCode);
            Cmd.Parameters.AddWithValue("@lvlid", model.LevelId);
            DataTable dt = data.GetDataTable(Cmd);

            ds = Utility.GetValidationTables(dt);
            int vdone = 0, adone = 0, sdone = 0, tdone = 0;
            for (int s = 0; s < ds.Tables.Count; s++)
            {
                string ControlPrefix = "cb", ColumnId = string.Empty, ControlName = string.Empty, tblName = string.Empty;
                if (ds.Tables.Contains("dtValidation") && vdone == 0) { ColumnId = "ValidationId"; tblName = "dtValidation"; vdone = 1; }
                else if (ds.Tables.Contains("dtAuthentication") && adone == 0) { ColumnId = "authenticationtypeid"; tblName = "dtAuthentication"; adone = 1; }
                else if (ds.Tables.Contains("dtSigning") && sdone == 0) { ColumnId = "signingtypeid"; tblName = "dtSigning"; sdone = 1; }
                else if (ds.Tables.Contains("dtStatus") && tdone == 0) { ControlPrefix = "scb"; ColumnId = "statusid"; tblName = "dtStatus"; tdone = 1; }

                for (int i = 0; i < ds.Tables[tblName].Rows.Count; i++)
                {
                    ControlName = ControlPrefix + ds.Tables[tblName].Rows[i][ColumnId];

                    if (frm[ControlName] != null)
                    {
                        Values.Add(tblName + "|" + frm[ControlName]);
                    }
                    if (Values == null)
                    {
                        PreserveModelState(Constant._ActionMessage, "Please select atleast one validation.", false, true);
                        QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid", "lvlid" }, new ArrayList() { model.ServiceCode, model.LevelId });
                        return RedirectToAction("ApplicationValidationManagement", "Admin", new { q = QueryString });
                    }
                }
            }
            string updValidation = string.Empty, updAuthentication = string.Empty, updSigning = string.Empty, updStatus = string.Empty;
            for (int i = 0; i < Values.Count; i++)
            {
                string[] tempArr = Values[i].ToString().Split('|');
                if (tempArr[0] == "dtValidation") { updValidation += tempArr[1] + ","; }
                else if (tempArr[0] == "dtAuthentication") { updAuthentication += tempArr[1] + ","; }
                else if (tempArr[0] == "dtSigning") { updSigning += tempArr[1] + ","; }
                else if (tempArr[0] == "dtStatus") { updStatus += tempArr[1] + ","; }
            }

            Qry = "select ServiceCode from servicevalidationcheckmaster where ServiceCode=@ServiceCode and LevelId=@LevelId";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
            Cmd.Parameters.AddWithValue("@LevelId", model.LevelId);
            if (string.IsNullOrEmpty(data.SelectColumns(Cmd)[0]))
            {
                Qry = "insert into servicevalidationcheckmaster (ServiceCode,LevelId,ValidationCheck,AuthenticationType,SigningType,Status) values(@ServiceCode,@LevelId,@ValidationCheck,@AuthenticationType,@SigningType,@Status)";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                Cmd.Parameters.AddWithValue("@LevelId", model.LevelId);
                Cmd.Parameters.AddWithValue("@ValidationCheck", updValidation.TrimEnd(','));
                Cmd.Parameters.AddWithValue("@AuthenticationType", updAuthentication.TrimEnd(','));
                Cmd.Parameters.AddWithValue("@SigningType", updSigning.TrimEnd(','));
                Cmd.Parameters.AddWithValue("@Status", updStatus.TrimEnd(','));
                data.UpdateData(Cmd);
                PreserveModelState(Constant._ActionMessage, "Service validations successfully inserted!", false, true);
            }
            else
            {

                Qry = "update servicevalidationcheckmaster set ValidationCheck=@ValidationCheck,AuthenticationType=@AuthenticationType,SigningType=@SigningType,Status=@Status where ServiceCode=@ServiceCode and LevelId=@LevelId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                Cmd.Parameters.AddWithValue("@LevelId", model.LevelId);
                Cmd.Parameters.AddWithValue("@ValidationCheck", updValidation.TrimEnd(','));
                Cmd.Parameters.AddWithValue("@AuthenticationType", updAuthentication.TrimEnd(','));
                Cmd.Parameters.AddWithValue("@SigningType", updSigning.TrimEnd(','));
                Cmd.Parameters.AddWithValue("@Status", updStatus.TrimEnd(','));
                data.UpdateData(Cmd);
                PreserveModelState(Constant._ActionMessage, "Service validations successfully updated!", false, true);
            }
            QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid", "lvlid" }, new ArrayList() { model.ServiceCode, model.LevelId });
            return RedirectToAction("ApplicationValidationManagement", "Admin", new { q = QueryString });
        }
        #endregion

        #region Verify UID
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult VerifyUID()
        {
            AdminModels model = new AdminModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult VerifyUID(AdminModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                int DocStatusId = 0;

                string Qry = "select DocumentId,dbo.udf_general_decrypt(DocumentNo) as DocumentNo,ApplicantName,ApplicantGender, to_char(ApplicantDob,'yyyy-mm-dd') as ApplicantDob from web.registrationmaster where documentId in(@AdocumentId,@VdocumentId) and documentstatusid in(@AuidstatusId,@VuidstatusId) limit 1000";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@AdocumentId", ((int)DocumentId.AadhaarCard));
                cmd.Parameters.AddWithValue("@VdocumentId", ((int)DocumentId.VoterID));
                cmd.Parameters.AddWithValue("@AuidstatusId", ((int)WebServiceResponse.VerificationPending));
                cmd.Parameters.AddWithValue("@VuidstatusId", ((int)WebServiceResponse.ExceptionOccurred));
                model.dataS = data.GetDataTable(cmd);

                if (model.dataS.Rows.Count > 0)
                {
                    for (int i = 0; i < model.dataS.Rows.Count; i++)
                    {
                        if (!string.IsNullOrEmpty(model.dataS.Rows[i]["ApplicantName"].ToString()) && !string.IsNullOrEmpty(model.dataS.Rows[i]["ApplicantGender"].ToString()) && !string.IsNullOrEmpty(model.dataS.Rows[i]["ApplicantDob"].ToString()) && !string.IsNullOrEmpty(model.dataS.Rows[i]["DocumentNo"].ToString()))
                        {
                            DocStatusId = Utility.VerifyRegistrationDocument(model.dataS.Rows[i]["ApplicantName"].ToString().ToUpper(), model.dataS.Rows[i]["ApplicantGender"].ToString().ToUpper(), model.dataS.Rows[i]["ApplicantDob"].ToString(), model.dataS.Rows[i]["DocumentNo"].ToString(), Convert.ToInt32(model.dataS.Rows[i]["DocumentId"].ToString()));

                            //Qry = @"update web.registrationmaster set documentstatusid=@documentstatusid,Applicantipaddress=@Applicantipaddress,LastactionPerformed=now(),ActionPerformedBy=@ActionPerformedBy where dbo.udf_general_decrypt(DocumentNo)=@DocumentNo and documentId=@documentId";
                            Qry = @"update web.registrationmaster set documentstatusid=@documentstatusid,Applicantipaddress=@Applicantipaddress,LastactionPerformed=now(),ActionPerformedBy=@ActionPerformedBy where DocumentNo=@DocumentNo and documentId=@documentId";
                            cmd = new NpgsqlCommand(Qry);
                            cmd.Parameters.AddWithValue("@DocumentNo", Utility.GetByteFromDocumentNo(model.dataS.Rows[i]["DocumentNo"].ToString().ToUpper()));
                            cmd.Parameters.AddWithValue("@documentId", model.dataS.Rows[i]["DocumentId"].ToString());
                            cmd.Parameters.AddWithValue("@documentstatusid", DocStatusId);
                            cmd.Parameters.AddWithValue("@Applicantipaddress", Utility.GetIP4Address());
                            cmd.Parameters.AddWithValue("@ActionPerformedBy", Sessions.getEmployeeUser().UserId);
                            data.UpdateData(cmd);
                        }
                        else
                        {
                            ViewBag.DisplayMessage = "ApplicantName or ApplicantGender or ApplicantDob or Applicant Document No not Exist";
                            return View("VerifyUID");
                        }
                    }

                }
                else
                {
                    ViewBag.DisplayMessage = "No Registration Is Pending For Verification.";
                    return View("VerifyUID");
                }
            }
            ViewBag.DisplayMessage = "UID Verification Done for 1000 records.";
            return View("VerifyUID");
        }
        #endregion Verify UID

        #region global method current contoller
        public void PreserveModelState(string Key, object obj, bool IsKeep, bool IsRemove)
        {
            if (IsRemove == true) { TempData.Remove(Key); }
            if (obj != null) { TempData[Key] = obj; }
            if (IsKeep == true) { TempData.Keep(Key); }
        }
        #endregion global method current contoller

    }
}
