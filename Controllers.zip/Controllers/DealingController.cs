﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.Mvc;
using Edistrict.Models;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.DataService;
using Edistrict.Models.Entities;
using Edistrict.Models.CustomClass;
using System.Web;
using System.Web.UI;
using Npgsql;
using System.Collections;

namespace Edistrict.Controllers
{
    [Authorize(Roles = "102,122,130")]
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class DealingController : Controller
    {
        #region action methods for scruitney of application
        //[AcceptVerbs(HttpVerbs.Get)]
        //public ActionResult AvaiableServicesAtDealing()
        //{
        //    if (Sessions.getEmployeeUser().Permission != ((int)Permission.DEAL).ToString() && Sessions.getEmployeeUser().Permission != ((int)Permission.P122).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

        //    DealingModels model = new DealingModels();
        //    model.data = Utility.GetServiceDetails(true, true, true, false, true, true, true, false, null);
        //    return View(model);
        //}
        [EncryptedActionParameter]
        [Authorize(Roles = "102,122")]
        public ActionResult PendingApplicationSummary(int sid)
        {
            GetData data = new GetData();
            //string WhetherCondition = string.Empty;
            DealingModels model = new DealingModels();

            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000)
            //{
            //    WhetherCondition = " and AD.OfficeCode in (@ParamAuthorizationId) and AD.AcceptedBy in (@AcceptedBy)";
            //}
            //else
            //{
            //    WhetherCondition = " and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.OfficeCode=@OfficeCode and AD.AcceptedBy in (@AcceptedBy)";
            //}

            string addScript = Utility.GetScriptForAuthorizationProcess();

            //string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and ApplicationSourceId=@ApplicationSourceId then 1 end),0) as PendingatCSC,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as PendingatOnline  from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) " + WhetherCondition + " group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and ApplicationSourceId=@ApplicationSourceId then 1 end),0) as PendingatCSC,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and ApplicationSourceId=@ApplicationSourceId1 then 1 end),0) as PendingatOnline  from dbo.ApplicationDetails AD left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.AcceptedBy in (@AcceptedBy) and AD.ServiceCode in (@ParamServiceCode) " + addScript + " group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@ApplicationSourceId", (int)ApplicationSource.Window);
            cmd.Parameters.AddWithValue("@ApplicationSourceId1", (int)ApplicationSource.Online);
            //cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            model.data = data.GetDataTable(cmd);

            ViewData[KeyName._Key01] = sid;
            return View(model);
        }
        [EncryptedActionParameter]
        [Authorize(Roles = "102,122")]
        public ActionResult SerachAppForAction(int sid)
        {
            //if (Sessions.getEmployeeUser().Permission != ((int)Permission.DEAL).ToString() && Sessions.getEmployeeUser().Permission != ((int)Permission.P122).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

            GetData data = new GetData();
            DealingModels model = new DealingModels();
            model.StatusId = sid.ToString();
            string Qry = "select StatusName from dbo.StatusMaster where StatusId=@StatusId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@StatusId", model.StatusId);
            ViewBag.ListTitle = data.SelectColumns(Cmd)[0];
           
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [EncryptedActionParameter]
        [Authorize(Roles = "102,122")]
        public ActionResult PendingApplicationList(int subDiv, int service, int status, int? SourceId)
        {
            GetData data = new GetData();
            DealingModels model = new DealingModels();

            //string QryStr = string.Empty;
            //if (SourceId != null) { QryStr += " and ApplicationSourceId=@ApplicationSourceId"; }
            //string WhetherCondition = string.Empty;
            //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition = " and AD.OfficeCode = @OfficeCode "; }
            //else { WhetherCondition = " and AD.applicationsubdivcode=@applicationsubdivcode and AD.OfficeCode=@OfficeCode"; }

            string addScript = Utility.GetScriptForAuthorizationProcess();
            if (SourceId != null) { addScript += " and AD.ApplicationSourceId=@ApplicationSourceId"; }

            //string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,AD.ApplicantDob,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate from dbo.ApplicationDetails AD inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode where AD.ServiceCode=@ServiceCode " + WhetherCondition + " and AD.ApplicationStatusId=@ApplicationStatusId " + QryStr + " order by AD.applicationdate";
            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,AD.ApplicantDob,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate from dbo.ApplicationDetails AD inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode where AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId and AD.AcceptedBy in (@AcceptedBy) " + addScript + " order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", status);
            cmd.Parameters.AddWithValue("@applicationsubdivcode", subDiv);
            cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            if (SourceId != null) { cmd.Parameters.AddWithValue("@ApplicationSourceId", SourceId); }
            //cmd.Parameters.AddWithValue("@OfficeCode", Sessions.getEmployeeUser().AuthorizationId);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult PendingApplicationDetails(DealingModels model)
        {
            if (ModelState.IsValid)
            {
                model.StatusId = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ApplicationStatusId", "ApplicationNo", model.ApplicationNo.ToString())[0];
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo", "StsId" }, new ArrayList() { model.ApplicationNo, model.StatusId });
                return RedirectToAction("PendingApplicationDetails", "Dealing", new { q = QueryString });
            }
            return View("SerachAppForAction", model);
        }
        [EncryptedActionParameter]
        public ActionResult PendingApplicationDetails(Int64 AppNo, int StsId)
        {
            GetData data = new GetData();
            DealingModels model=new DealingModels();
            model.ApplicationNo = AppNo.ToString();
            model.StatusId = StsId.ToString();
            model.WhetherScStwelfateAllowed = false;
            string QueryString = string.Empty, WhetherCondition = string.Empty;

            Dictionary<string, string> ValidateData = new Dictionary<string, string>();
            ValidateData.Add("ApplicationNo", model.ApplicationNo);

            string DisplayMessage = Utility.WhetherAccessAllowed(ValidateData, new int[] { (int)ValueId.AuthCrendential, (int)ValueId.AuthOtp, (int)ValueId.AuthDigital, (int)ValueId.AutheKYC }, null, new int[] { (int)Status.SCOM036, (int)Status.DEALOLR, (int)Status.NOTIACT }, false, true, true);
            if (!string.IsNullOrEmpty(DisplayMessage))
            {
                PreserveModelState(Constant._ActionMessage, DisplayMessage, false, true);
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.StatusId });
                return RedirectToAction("SerachAppForAction", new { q = QueryString });
            }


            //string addScript = " and ApplicationSubdivCode in (@ParamSubDivCode)"; 
            //string[] Values = Utility.GetServiceCode(Convert.ToInt64(model.ApplicationNo));
            //if (Values[1] != ((int)Department.Dept010).ToString())
            //{
            //    if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { addScript = " and OfficeCode in (@ParamAuthorizationId)"; }

            //    //if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000 && Convert.ToInt32(Sessions.getEmployeeUser().DeptCode) == (int)Department.Dept001)
            //    //{
            //    //    WhetherCondition = " and OfficeCode in (@ParamAuthorizationId) ";
            //    //}
            //    //else
            //    //{
            //    //    WhetherCondition = " and ApplicationSubdivCode in (@ParamSubDivCode) and OfficeCode=@OfficeCode";
            //    //}
            //}

            string addScript = Utility.GetScriptForAuthorizationProcess();
            int deptCode = Convert.ToInt32(Sessions.getEmployeeUser().DeptCode);

            //string Qry = "select ServiceCode,ApplicationStatusId,ApplicationNo FROM dbo.ApplicationDetails where ApplicationNo=@ApplicationNo " + WhetherCondition + " and ServiceCode in (@ParamServiceCode)";
            string Qry = "select AD.ServiceCode,AD.ApplicationStatusId,AD.ApplicationNo FROM dbo.ApplicationDetails AD inner join servicemaster SM on SM.ServiceCode=AD.ServiceCode where AD.ApplicationNo=@ApplicationNo and SM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) " + addScript;
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            //Cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            string[] Val = data.SelectColumns(Cmd);
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ServiceCode = Val[0];
            model.ApplicationDetails.ApplicationStatusId = Val[1];
            model.ApplicationDetails.ApplicationNo = Val[2];
            if (string.IsNullOrEmpty(model.ApplicationDetails.ApplicationNo)) 
            { 
                PreserveModelState(Constant._ActionMessage, "Application Not Found or Not Available in you account, Kindly Check Your Application No.", false, true);
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.StatusId });
                return RedirectToAction("SerachAppForAction", new { q = QueryString }); 
            }

            if (model.StatusId == ((int)Status.DEALOLR).ToString() || model.StatusId == ((int)Status.NOTIACT).ToString())
            {
                model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());

                if (deptCode != (int)Department.Dept010)
                {
                    Qry = "select UM.UID,UM.UserName from UserMaster UM inner join UserToSubDivMaster SDM on SDM.Uid=UM.Uid where UM.DistrictCode=@DistrictCode and SDM.SubDivCode in (@ParamSubDivCode) and UM.Permission=@Permission";
                    Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    Cmd.Parameters.AddWithValue("@DistrictCode", Sessions.getEmployeeUser().DistrictCode);
                    Cmd.Parameters.AddWithValue("@Permission", Convert.ToString((int)Permission.VERF));
                    model.VerifierMaster = new SelectList(UserMaster.List<UserMaster>(Cmd), "UID", "UserName");
                }

                Qry = "select left(RV.SelectValueName,1) SelectValueId,RV.SelectValueName from dbo.SelectTypeToValueMaster TV inner join  SelectTypeMaster RT on RT.SelectTypeId=TV.SelectTypeId inner join SelectValueMaster RV on RV.SelectValueId=TV.SelectValueId where TV.SelectTypeId=@SelectTypeId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@SelectTypeId", (int)SelectControl.YesNo);
                model.VerificationSelectList = new SelectList(SelectValueMaster.List<SelectValueMaster>(Cmd), "SelectValueId", "SelectValueName");

                model.IsAlreadyVerified = Utility.SelectColumnsValue("dbo.VerifierApplicationDetails", "ApplicationNo", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];

                if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Domicile)
                {
                    model.ApplicationDetailsDomicile = Utility.GetDomicileDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Handicapped)
                {
                    model.ApplicationHandicappedDetails = Utility.GetHandicappedDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.OldAge)
                {
                    model.ApplicationDetailsOldAge = Utility.GetOldAgeDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Widow)
                {
                    model.ApplicationWidowDetails = Utility.GetWidowDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Nationality)
                {
                    model.ApplicationDetailsNationality = Utility.GetNationalityDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Marriage)
                {
                    model.ApplicationMarriageDetails = Utility.GetMarriageDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                    model.MarriageWitnessDetails = Utility.GetMarriageWitnessDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Solemnization)
                {
                    model.ApplicationMarriageDetails = Utility.GetMarriageSolemnizationDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                    model.MarriageWitnessDetails = Utility.GetMarriageWitnessDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                    if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.NOTIACT).ToString())
                    {
                        Cmd = new NpgsqlCommand("select DATE_PART('day',SolemnizationDate - now()::date) as Difference,to_char(SolemnizationDate,'DD/MM/YYYY') as SolemnizationDate from dgen.ApplicationMarriageSolemnizationDetails where ApplicationNo=@ApplicationNo");
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        string[] GetValues = data.SelectColumns(Cmd);
                        int SDate = Convert.ToInt32(GetValues[0]);
                        if (SDate <= 0) { model.ApplicationDetails.WhetherSolemnizationDatePassed = true; }
                        else { model.ApplicationDetails.WhetherSolemnizationDatePassed = false; model.ApplicationDetails.SolemnizationDate = GetValues[1]; }
                    }
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Solvency)
                {
                    model.ApplicationDetailsSolvency = Utility.GetSolvencyDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Disability)
                {
                    model.ApplicationDetailsDisability = Utility.GetDisabilityDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Birth)
                {
                    model.ApplicationDetailsBirth = Utility.GetBirthDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Death)
                {
                    model.ApplicationDetailsDeath = Utility.GetDeathDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Income)
                {
                    model.ApplicationDetailsIncome = Utility.GetIncomeDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.SCST)
                {
                    model.ApplicationDetailsSCST = Utility.GetSCSTDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.ApplicationLetterDetailsModel = Utility.GetApplicationLetterDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                    if ((model.ApplicationDetailsSCST.StateId != ((int)State.Delhi).ToString()) && (model.ApplicationDetailsSCST.WhetherRelationSCST.ToLower() == "true")) { model.WhetherVerificationLetterRequired = true; }

                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.ST)
                {
                    model.ApplicationDetailsST = Utility.GetSTDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.ApplicationLetterDetailsModel = Utility.GetApplicationLetterDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                    if ((model.ApplicationDetailsST.StateId != ((int)State.Delhi).ToString()) && (model.ApplicationDetailsST.WhetherRelationST.ToLower() == "true")) { model.WhetherVerificationLetterRequired = true; }
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.NT)
                {
                    model.ApplicationDetailsNT = Utility.GetNTDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.ApplicationLetterDetailsModel = Utility.GetApplicationLetterDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                    if ((model.ApplicationDetailsNT.StateId != ((int)State.Delhi).ToString()) && (model.ApplicationDetailsNT.WhetherRelationNT.ToLower() == "true")) { model.WhetherVerificationLetterRequired = true; }
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.OBC)
                {
                    bool WhetherOld = false;
                    string ApplicationDate = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ApplicationDate", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0];
                    if (Convert.ToDateTime(ApplicationDate) < Convert.ToDateTime(Constant._OBCDate)) { WhetherOld = true; }
                    model.ApplicationDetailsOBC = Utility.GetOBCDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.ApplicationDetailsOBC.WhetherOld = WhetherOld;
                    model.ApplicationDetailsOBC.OBCIncomeDetails = Utility.GetOBCIncomeDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                    model.ApplicationLetterDetailsModel = Utility.GetApplicationLetterDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                    if ((model.ApplicationDetailsOBC.StateId != ((int)State.Delhi).ToString()) && (model.ApplicationDetailsOBC.WhetherRelationObc.ToLower() == "true")) { model.WhetherVerificationLetterRequired = true; }
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Surviving)
                {
                    model.ApplicationDetailsSurviving = Utility.GetSurvivingDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.LalDora)
                {
                    model.ApplicationDetailsLalDora = Utility.GetLalDoraDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.LalDoraWitnessDetails = Utility.GetWitnessDetailsLalDora(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.CDVolunteer)
                {
                    model.ApplicationDetailsCDV = Utility.GetCDVDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.ApplicationDetailsCDV.Flag = Utility.SelectColumnsValue("dgen.ApplicationDetailsCDV", "WhetherPccComplete", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];
                    if (string.IsNullOrEmpty(model.ApplicationDetailsCDV.Flag))
                    {
                        model.ApplicationDetailsCDV.Flag = "True";
                    }
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.NOC)
                {
                    model.ApplicationDetailsNOC = Utility.GetNOCDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Migration)
                {
                    model.ApplicationDetailsMigration = Utility.GetMigrationDetails(model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.BOCW)
                {
                    model.ApplicationDetailsBOCWAct = Utility.GetBOCWActDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.ContractLabour)
                {
                    model.ApplicationDetailsCLAct = Utility.GetCLActDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Contractors)
                {
                    model.ApplicationDetailsContractor = Utility.GetContractorDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.RenewalOfContractor)
                {
                    model.ApplicationDetailsRenewalContractor = Utility.GetRenewalContractorDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Ladli)
                {
                    model.ApplicationDetailsLadli = Utility.GetLadliDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.DFBScheme)
                {
                    model.ApplicationDetailsDFBScheme = Utility.GetDFBSchemeDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Recovery)
                {
                    model.ApplicationDetailsRecovery = Utility.GetRecoveryDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.SocietyRegistration)
                {
                    model.ApplicationDetailsSociety = Utility.GetApplicationDetailsSociety(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.FirmRegistration)
                {
                    model.ApplicationDetailsFirm = Utility.GetApplicationDetailsFirm(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MeritscholarshipProfessional)
                {
                    model.ApplicationDetailsMeritProfessional = Utility.GetMeritscholarshipProfessionalDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.ApplicationDetailsMeritProfessional.ScStFeeDetails = new List<ScStFeeDetails>();
                    Qry = @"select a.servicecode,a.feetypeby,b.valuename,coalesce(c.feeamount,0) as feeamount from prematservicetofeehead a inner join selectmastervaluedetails b on b.valueid=a.feetypeby 
                            left outer join dgen.scstfeedetails c on c.feetypeby=a.feetypeby and c.feeinitiateby=@feeinitiateby and c.applicationno=@ApplicationNo where ServiceCode=@ServiceCode";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.MeritscholarshipProfessional);
                    Cmd.Parameters.AddWithValue("@feeinitiateby", (int)ValueId.Department);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
                    DataTable Dt1 = data.GetDataTable(Cmd);
                    for (int i = 0; i < Dt1.Rows.Count; i++)
                    {
                        model.ApplicationDetailsMeritProfessional.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
                    }
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PostmatricScholarshipOBC)
                {
                    model.ApplicationDetailsPostmatOBC = Utility.GetPostmatOBCDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.ApplicationDetailsPostmatOBC.ScStFeeDetails = new List<ScStFeeDetails>();
                    DataTable Dt1 = Utility.GetSCSTScholorship(model.ApplicantDetails.ApplicationNo, null, null);
                    for (int i = 0; i < Dt1.Rows.Count; i++)
                    {
                        model.WhetherScStwelfateAllowed = true;
                        model.ApplicationDetailsPostmatOBC.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
                    }


//                    model.ApplicationDetailsPostmatOBC = Utility.GetPostmatOBCDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
//                    model.ApplicationDetailsPostmatOBC.ScStFeeDetails = new List<ScStFeeDetails>();
//                    Qry = @"select a.servicecode,a.feetypeby,b.valuename,coalesce(c.feeamount,0) as feeamount from prematservicetofeehead a inner join selectmastervaluedetails b on b.valueid=a.feetypeby 
//                            left outer join dgen.scstfeedetails c on c.feetypeby=a.feetypeby and c.feeinitiateby=@feeinitiateby and c.applicationno=@ApplicationNo where ServiceCode=@ServiceCode";
//                    Cmd = new NpgsqlCommand(Qry);
//                    Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.PostmatricScholarshipOBC);
//                    Cmd.Parameters.AddWithValue("@feeinitiateby", (int)ValueId.Department);
//                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
//                    DataTable Dt1 = data.GetDataTable(Cmd);
//                    for (int i = 0; i < Dt1.Rows.Count; i++)
//                    {
//                        model.ApplicationDetailsPostmatOBC.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
//                    }
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PostmatricSC)
                {
                    model.ApplicationDetailsPostmatSCssd = Utility.GetPostmatSCSSDDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.ApplicationDetailsPostmatSCssd.ScStFeeDetails = new List<ScStFeeDetails>();
                    DataTable Dt1 = Utility.GetSCSTScholorship(model.ApplicantDetails.ApplicationNo, null, null);
                    for (int i = 0; i < Dt1.Rows.Count; i++)
                    {
                        model.WhetherScStwelfateAllowed = true;
                        model.ApplicationDetailsPostmatSCssd.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
                    }
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.CertifiedCopyFromSR)
                {
                    model.ApplicationDetailsSRCopy = Utility.GetCertifiedCopyFromSR(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.InstallationOfLift)
                {
                    model.ApplicationDetailsInstallationOfLift = Utility.GetInstallationOfLiftDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.GrantOfPassengerLift)
                {
                    model.ApplicationDetailsGrantOfPassengerLift = Utility.GetGrantOfPassengerLiftDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.RenewalOfPassengerLift)
                {
                    model.ApplicationDetailsRenewalOfPassengerLift = Utility.GetRenewalOfPassengerLiftDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.CEA1)
                {
                    model.ApplicationDetailsCEA1 = Utility.GetApplicationDetailsCEA1(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.CEA2)
                {
                    model.ApplicationDetailsCEA2 = Utility.GetApplicationDetailsCEA2(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.CEA3)
                {
                    model.ApplicationDetailsCEA3 = Utility.GetApplicationDetailsCEA3(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.ECLicence)
                {
                    model.ApplicationDetailsEC = Utility.GetApplicationDetailsEC(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.CompCertificate)
                {
                    model.ApplicationDetailsCompCertificate = Utility.GetApplicationDetailsCompCertificate(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.ConstructionWorker)
                {
                    model.ApplicationDetailsConsWorker = Utility.GetConsWorkerDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());

                    Qry = "select username,to_char(actiondate,'DD/MM/YYYY HH:MM:SS') as actiondate,ipaddress from departmentaudittrail dat inner join usermaster um on dat.actionby=um.userid where applicationno=@applicationno and actionmessageid=@actionmessageid";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@actionmessageid", (int)CountList.Type008);
                    model.datac = data.GetDataTable(Cmd);
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.RenewalConsWorker)
                {
                    model.RenewalConsWorker = Utility.GetRenewalConsWorkerDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.DeathBenefits)
                {
                    model.ApplicationDetailsDeathBenefits = Utility.GetDeathBenefitsActDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsDeathBenefits.WorkerRegNo);
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.FuneralBenefit)
                {
                    model.ApplicationDetailsFuneralBenefit = Utility.GetFuneralBenefitActDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsFuneralBenefit.WorkerRegNo);
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.FamilyPension)
                {
                    model.ApplicationDetailsFamilyPension = Utility.GetFamilyPensionActDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsFamilyPension.WorkerRegNo);
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MarriageAssistance)
                {
                    model.ApplicationDetailsMarriageAssistance = Utility.GetMarriageAssistanceActDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());

                    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsMarriageAssistance.WorkerRegNo);
                    string applicationid = Utility.SelectColumnsValue("web.applicationdetails", "applicationid", "applicationno", model.ApplicationDetailsMarriageAssistance.ApplicationNo)[0];
                    model.ApplicationDetailsMarriageAssistance.Durationofmembership = Utility.RegisteredWorkerMembershipDuration(model.ApplicationDetailsMarriageAssistance.WorkerRegNo, applicationid);
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.EduScholarship)
                {
                    model.ApplicationDetailsEduScholarship = Utility.GetEduScholarshipActDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsEduScholarship.WorkerRegNo);
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MedicalAssistance)
                {
                    model.ApplicationDetailsMedicalAssistance = Utility.GetMedicalAssistanceActDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsMedicalAssistance.WorkerRegNo);
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.HBA)
                {
                    model.ApplicationDetailsHBA = Utility.GetHBAActDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsHBA.WorkerRegNo);
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.DisabilityPension)
                {
                    model.ApplicationDetailsDisabilityPension = Utility.GetDisabilityPensionActDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsDisabilityPension.WorkerRegNo);
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Pension)
                {
                    model.ApplicationDetailsPension = Utility.GetPensionActDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsPension.WorkerRegNo);
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MaternityBenefit)
                {
                    model.ApplicationDetailsMaternityBenefit = Utility.GetMaternityBenefitActDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsMaternityBenefit.WorkerRegNo);
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.GrantofWork)
                {
                    model.ApplicationDetailsGrantofWork = Utility.GetGrantofWorkActDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsGrantofWork.WorkerRegNo);
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.InstrumentLoan)
                {
                    model.ApplicationDetailsInstrumentLoan = Utility.GetInstrumentLoanActDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.dtRegisteredWorkerDetails = Utility.GetRegisteredWorkerDetails(model.ApplicationDetailsInstrumentLoan.WorkerRegNo);
                }
                else
                {
                    return RedirectToAction("BadRequest", "Error");
                }


                if (model.WhetherVerificationLetterRequired == true)
                {
                    model.WhetherVerificationLetterRequired = Utility.CheckVerificationLetter(model.ApplicantDetails.ApplicationNo);
                    Qry = "select 0 as LetterDetailsId,AV.ApplicationNo,AV.TypeValueId, SV.ValueName,to_char(AV.GenerateDate,'DD/MM/YYYY') as GenerateDate,AV.Generateby,AV.WhetherVerificationUpload,AV.UploaddocumentData,to_char(AV.UploadDate,'DD/MM/YYYY') as UploadDate,AV.Uploadby from dbo.ApplicationVerificationLetterDetails AV inner join dbo.SelectMasterValueDetails SV on SV.ValueId=AV.TypeValueId where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
                    model.dtVerificationLetter = data.GetDataTable(Cmd);
                }

                model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", string.Empty, string.Empty, model.ApplicationDetails.ApplicationNo, DB.LS.ToString(), CustomText.N.ToString());
                ViewData[KeyName._Key01] = Utility.GetPhotoDetails(string.Empty, string.Empty, string.Empty, string.Empty, model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
                model.datab = Utility.GetPaymentDetails(model.ApplicationDetails.ApplicationNo);
                model.data1 = Utility.GetMobileSahayakDetailsData(model.ApplicationDetails.ApplicationNo);

                PreserveModelState(Constant._ModelStateParent, model, false, true);
                return View(model);
            }
            PreserveModelState(Constant._ActionMessage, "Entered Application Not Pending at this Level.", false, true);
            QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.StatusId });
            return RedirectToAction("SerachAppForAction", new { q = QueryString });
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SavePendingApplicationDetails(DealingModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                NpgsqlCommand Cmd = new NpgsqlCommand();
                Int64 FillAmount = 0, DisburseAmount = 0;
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Qry = string.Empty, ApplicationStatusId = string.Empty;

                Dictionary<string, string> ValidateData = new Dictionary<string, string>();
                ValidateData.Add("ApplicationNo", model.ApplicationNo);
                string DisplayMessage = Utility.WhetherAccessAllowed(ValidateData, new int[] { (int)ValueId.AuthCrendential, (int)ValueId.AuthOtp, (int)ValueId.AuthDigital, (int)ValueId.AutheKYC }, null, new int[] { (int)Status.DEALOLR }, false, true, true);
                if (!string.IsNullOrEmpty(DisplayMessage))
                {
                    ViewBag.DisplayMessage = DisplayMessage;
                    PreserveModelState(Constant._ModelStateParent, null, true, false);
                    return View("PendingApplicationDetails", (DealingModels)TempData[Constant._ModelStateParent]);
                }

                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.VERSENT).ToString())
                {
                    model.IsAlreadyVerified = Utility.SelectColumnsValue("dbo.VerifierApplicationDetails", "ApplicationNo", "ApplicationNo", model.ApplicationNo.ToString())[0];
                    if (string.IsNullOrEmpty(model.IsAlreadyVerified))
                    {
                        string Uid = Utility.SelectColumnsValue("dbo.UserMaster", "Uid", "UserId", Sessions.getEmployeeUser().UserId.ToString())[0];
                        
                        //entry of last status
                        Utility.SaveOldStatusBeforeVerification(model.ApplicationNo, CustomText.TRUE.ToString());

                        Qry = "update dbo.VerifierApplicationDetails set WhetherLastVerification=@WhetherLastVerification where ApplicationNo=@ApplicationNo and exists (select ApplicationNo from dbo.VerifierApplicationDetails where ApplicationNo=@ApplicationNo)";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@WhetherLastVerification", CustomText.FALSE.ToString());
                        cmdList.Add(Cmd);

                        Qry = "insert into dbo.VerifierApplicationDetails (ApplicationNo,SentBy,SentTo,SentDate,WhetherVerified,WhetherLastVerification,LastStatusId) values(@ApplicationNo,@SentBy,@SentTo,now(),@WhetherVerified,@WhetherLastVerification,@LastStatusId)";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@LastStatusId", (int)Status.DEALOLR);
                        Cmd.Parameters.AddWithValue("@SentBy", Uid);
                        Cmd.Parameters.AddWithValue("@SentTo", model.VerifierCode);
                        Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.FALSE.ToString());
                        Cmd.Parameters.AddWithValue("@WhetherLastVerification", CustomText.TRUE.ToString());
                        cmdList.Add(Cmd);

                        cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG013, null, (int)ApplicationSource.Window, null));

                        //send sms to applicant and insert record in table
                        Dictionary<string, string> smsDic = new Dictionary<string, string>();
                        smsDic.Add("ParamApplicationNo", model.ApplicationNo);
                        cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS004, smsDic));

                        //send email to applicant and insert record in table
                        Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                        EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                        EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS004).ToString());
                        EmailDic.Add("ParamApplicationNo", model.ApplicationNo);
                        NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                        if (EmailCmd != null) { cmdList.Add(EmailCmd); }

                        ApplicationStatusId = model.ApplicationDetails.ApplicationStatusId;
                    }
                }
                else
                {
                    if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.CDVolunteer).ToString())
                    {
                        if ((model.ApplicationDetailsCDV.WhetherPccUploaded.ToUpper() == CustomText.TRUE.ToString() && model.ApplicationDetailsCDV.WhetherPccOk.ToUpper() == CustomText.TRUE.ToString() && string.IsNullOrEmpty(model.ApplicationDetailsCDV.WhetherPccAttached)) || (model.ApplicationDetailsCDV.WhetherPccUploaded.ToUpper() == CustomText.FALSE.ToString() && string.IsNullOrEmpty(model.ApplicationDetailsCDV.WhetherPccOk) && model.ApplicationDetailsCDV.WhetherPccAttached.ToUpper() == CustomText.TRUE.ToString()) || (model.ApplicationDetailsCDV.WhetherPccUploaded.ToUpper() == CustomText.TRUE.ToString() && model.ApplicationDetailsCDV.WhetherPccOk.ToUpper() == CustomText.FALSE.ToString() && model.ApplicationDetailsCDV.WhetherPccAttached.ToUpper() == CustomText.TRUE.ToString()))
                        {
                            Qry = "Update dgen.ApplicationDetailsCDV set WhetherPccComplete=@WhetherPccComplete where ApplicationNo=@ApplicationNo ";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@WhetherPccComplete", CustomText.TRUE.ToString());
                            cmdList.Add(Cmd);

                            Qry = "Update dgen.CDVPoliceVerificationMaster set WhetherActive=@WhetherActive where ApplicationNo=@ApplicationNo and WhetherActive=@WhetherActive1";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.FALSE.ToString());
                            Cmd.Parameters.AddWithValue("@WhetherActive1", CustomText.TRUE.ToString());
                            cmdList.Add(Cmd);

                            //process for attach a scanned document
                            HttpPostedFile file = System.Web.HttpContext.Current.Request.Files["DocumentData"];
                            byte[] fileData = Utility.CompareFileCapturePhotoData(null, file);
                            string ContentType = file.ContentType;  
                            if (fileData == null)
                            {
                                ViewBag.DisplayMessage = "Upload Document is Required";
                                PreserveModelState(Constant._ModelStateParent, null, true, false);
                                return View("PendingApplicationDetails", (DealingModels)TempData[Constant._ModelStateParent]);
                            }
                            if (file.ContentLength > (int)LengthList.EncContent)
                            {
                                ViewBag.DisplayMessage = "Document has invalid size. (Max Limit: 100KB)";
                                PreserveModelState(Constant._ModelStateParent, null, true, false);
                                return View("PendingApplicationDetails", (DealingModels)TempData[Constant._ModelStateParent]);
                            }
                            if (ContentType.ToLower() != "application/pdf")
                            {
                                ViewBag.DisplayMessage = "Only PDF Document Is Uploaded";
                                PreserveModelState(Constant._ModelStateParent, null, true, false);
                                return View("PendingApplicationDetails", (DealingModels)TempData[Constant._ModelStateParent]);
                            }
                            Qry = "insert into dgen.CDVPoliceVerificationMaster (ApplicationNo,PccCompleteId,PccCompleteDetails,VerificationNo,PoliceVerificationDate,DocumentData,ContentType,WhetherActive,UserId,ipaddress,actiondatetime) values (@ApplicationNo,@PccCompleteId,@PccCompleteDetails,@VerificationNo,@PoliceVerificationDate,@DocumentData,@ContentType,@WhetherActive,@UserId,@ipaddress,now())";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@PccCompleteId", model.ApplicationDetailsCDV.PccCompleteIdDeal);
                            Cmd.Parameters.AddWithValue("@PccCompleteDetails", model.ApplicationDetailsCDV.PccCompleteDetailsDeal);
                            Cmd.Parameters.AddWithValue("@VerificationNo", model.ApplicationDetailsCDV.VerificationNoDeal);
                            Cmd.Parameters.AddWithValue("@PoliceVerificationDate", Utility.GetDateYYYYMMDD(model.ApplicationDetailsCDV.PoliceVerificationDateDeal, '/', "0/1/2"));
                            Cmd.Parameters.AddWithValue("@DocumentData", fileData);
                            Cmd.Parameters.AddWithValue("@ContentType", ContentType);
                            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                            Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);
                            //End Process for attach a scanned document
                        }
                    }
                    else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.MeritscholarshipProfessional).ToString())
                    {
                        string DisAmount = string.Empty;
                        string whetherCon = string.Empty;
                        if (model.ApplicationDetailsMeritProfessional.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                        {
                            // fee check commented on requested on department on 13/07/2017
                            foreach (ScStFeeDetails Head in model.ApplicationDetailsMeritProfessional.ScStFeeDetails)
                            {
                                DisAmount = Head.FeeAmount;
                            }
                            DataTable dtcheck = Utility.GetSCSTScholorship(model.ApplicationNo, null, model.ApplicationDetailsMeritProfessional.GroupId);
                            if (Convert.ToInt32(dtcheck.Rows[0]["FeeAmount"].ToString()) < Convert.ToInt32(DisAmount))
                            {
                                ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                                PreserveModelState(Constant._ModelStateParent, null, true, false);
                                return View("PendingApplicationDetails", (DealingModels)TempData[Constant._ModelStateParent]);
                            }


                            Qry = "Delete from dgen.ScStFeeDetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                            cmdList.Add(Cmd);

                            foreach (ScStFeeDetails Head in model.ApplicationDetailsMeritProfessional.ScStFeeDetails)
                            {
                                Qry = "insert into dgen.ScStFeeDetails(ApplicationNo,FeeinitiateBy,FeeTypeBy,FeeAmount,UserId,IpAddress,LastActionDate) values (@ApplicationNo,@FeeinitiateBy,@FeeTypeBy,@FeeAmount,@UserId,@IpAddress,now())";
                                Cmd = new NpgsqlCommand(Qry);
                                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                                Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                                Cmd.Parameters.AddWithValue("@FeeTypeBy", Head.FeeTypeId);
                                Cmd.Parameters.AddWithValue("@FeeAmount", Head.FeeAmount);
                                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                                cmdList.Add(Cmd);
                            }
                        }

                        if (model.ApplicationDetailsMeritProfessional.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                        {
                            whetherCon = ",GroupId=@GroupId";
                        }

                        Qry = "update dgen.applicationdetailsmeritprofessional set WhetherVerified=@WhetherVerified,WhetherSchoolRecomended=@WhetherSchoolRecomended" + whetherCon + ",SchollRemarks=@SchollRemarks,SchollRemarksBy=@SchollRemarksBy,SchollRemarksIpAddress=@SchollRemarksIpAddress,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", model.ApplicationDetailsMeritProfessional.WhetherSchoolRecomended);
                        Cmd.Parameters.AddWithValue("@GroupId", model.ApplicationDetailsMeritProfessional.GroupId);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@SchollRemarks", model.ApplicationDetailsMeritProfessional.SchollRemarks);
                        Cmd.Parameters.AddWithValue("@SchollRemarksBy", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.True.ToString());
                        Cmd.Parameters.AddWithValue("@SchollRemarksIpAddress", Utility.GetIP4Address());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        Qry = "update dgen.prematapplicationprocess set ProcessStatusId=@ProcessStatusId,whetherrecommended=@whetherrecommended, WhetherRevertBack=@WhetherRevertBack, VerificationDate=now(),VerificationBy=@VerificationBy,VerificationIpAddress=@VerificationIpAddress where ApplicationNo=@ApplicationNo;";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@whetherrecommended", model.ApplicationDetailsMeritProfessional.WhetherSchoolRecomended);
                        Cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.Verified);
                        Cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.False.ToString());
                        Cmd.Parameters.AddWithValue("@ServiceCode", model.ApplicationDetails.ServiceCode);
                        Cmd.Parameters.AddWithValue("@VerificationBy", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@VerificationIpAddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        model.ApplicationDARemarks = model.ApplicationDetailsMeritProfessional.SchollRemarks;

                        // commented on 07/12/2017
                        //bool ReturnValue = Utility.CheckAppAlreadyVerified(model.ApplicationNo);
                        //if (ReturnValue == true)
                        //{
                        //    Qry = "update dgen.prematapplicationprocess set WhetherRevertBack=@WhetherRevertBack, VerificationDate=now(),VerificationBy=@VerificationBy,VerificationIpAddress=@VerificationIpAddress where ApplicationNo=@ApplicationNo;";
                        //}
                        //else
                        //{
                        //    Qry = "insert into dgen.prematapplicationprocess(ApplicationNo,ServiceCode,VerificationDate,VerificationBy,VerificationIpAddress) values(@ApplicationNo,@ServiceCode,now(),@VerificationBy,@VerificationIpAddress);";
                        //}
                        //Cmd = new NpgsqlCommand(Qry);
                        //Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        //Cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.False.ToString());
                        //Cmd.Parameters.AddWithValue("@ServiceCode", model.ApplicationDetails.ServiceCode);
                        //Cmd.Parameters.AddWithValue("@VerificationBy", Sessions.getEmployeeUser().UserId);
                        //Cmd.Parameters.AddWithValue("@VerificationIpAddress", Utility.GetIP4Address());
                        //cmdList.Add(Cmd);
                    }
                    else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.PostmatricScholarshipOBC).ToString())
                    {
                        //string DisAmount = string.Empty;
                        string whetherCon = string.Empty;
                        Int64 GetScholarshipAmount = 0, Nonrefundablefee = 0;
                        if (model.ApplicationDetailsPostmatOBC.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                        {
                            //// coide for check fee from database ----commented on 13/04/2017 from department
                            //foreach (ScStFeeDetails Head in model.ApplicationDetailsPostmatOBC.ScStFeeDetails)
                            //{
                            //    DisAmount = Head.FeeAmount;
                            //}
                            //DataTable dtcheck = Utility.GetSCSTScholorship(model.ApplicationNo, null, model.ApplicationDetailsPostmatOBC.GroupId);
                            //if (Convert.ToInt32(dtcheck.Rows[0]["FeeAmount"].ToString()) < Convert.ToInt32(DisAmount))
                            //{
                            //    ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                            //    PreserveModelState(Constant._ModelStateParent, null, true, false);
                            //    return View("PendingApplicationDetails", (DealingModels)TempData[Constant._ModelStateParent]);
                            //}

                            // Fee amount check on the baiss of Hostler/Dayscholer
                            string WhetherHostler = Utility.SelectColumnsValue("dgen.applicationdetailspostmatobc", "WhetherHostler", "ApplicationNo", model.ApplicationNo)[0];
                            foreach (ScStFeeDetails Head in model.ApplicationDetailsPostmatOBC.ScStFeeDetails)
                            {
                                DisburseAmount = DisburseAmount + Convert.ToInt64(Head.FeeAmount);
                            }

                            if (WhetherHostler.ToUpper() == CustomText.TRUE.ToString() && DisburseAmount > 30000)
                            {
                                ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                                PreserveModelState(Constant._ModelStateParent, null, true, false);
                                return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                            }
                            if (WhetherHostler.ToUpper() == CustomText.FALSE.ToString() && DisburseAmount > 25000)
                            {
                                ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                                PreserveModelState(Constant._ModelStateParent, null, true, false);
                                return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                            }
                            //if (WhetherHostler.ToUpper() == CustomText.TRUE.ToString() && Convert.ToInt32(DisAmount) > 30000)
                            //{
                            //    ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                            //    PreserveModelState(Constant._ModelStateParent, null, true, false);
                            //    return View("PendingApplicationDetails", (DealingModels)TempData[Constant._ModelStateParent]);
                            //}
                            //if (WhetherHostler.ToUpper() == CustomText.FALSE.ToString() && Convert.ToInt32(DisAmount) > 25000)
                            //{
                            //    ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                            //    PreserveModelState(Constant._ModelStateParent, null, true, false);
                            //    return View("PendingApplicationDetails", (DealingModels)TempData[Constant._ModelStateParent]);
                            //}

                            Qry = "Select FeeAmount from dgen.ScStFeeDetails Where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Applicant);
                            DataTable dt = data.GetDataTable(Cmd);
                            if (dt != null)
                            {
                                for (int i = 0; i < dt.Rows.Count; i++)
                                {
                                    FillAmount = FillAmount + Convert.ToInt64(dt.Rows[i]["FeeAmount"].ToString());
                                }
                            }

                            model.datab = Utility.GetSCSTScholorship(model.ApplicationNo, null, model.ApplicationDetailsPostmatOBC.GroupId);
                            if (model.datab != null)
                            {
                                for (int i = 0; i < model.datab.Rows.Count; i++)
                                {
                                    GetScholarshipAmount = GetScholarshipAmount + Convert.ToInt64(model.datab.Rows[i]["FeeAmount"].ToString());
                                    FillAmount = FillAmount + Convert.ToInt64(model.datab.Rows[i]["FeeAmount"].ToString());
                                }
                            }

                            Nonrefundablefee = DisburseAmount - GetScholarshipAmount;
                            if (Nonrefundablefee > 20000)
                            {
                                ViewBag.DisplayMessage = "The Non Refundable Course Fee is Not Allowed More Than 20000 !!!";
                                PreserveModelState(Constant._ModelStateParent, null, true, false);
                                return View("PendingApplicationDetails", (DealingModels)TempData[Constant._ModelStateParent]);
                            }

                            Dictionary<string, string> Data = new Dictionary<string, string>();
                            Data.Add("DisAmount", DisburseAmount.ToString());
                            Data.Add("FillAmount", FillAmount.ToString());
                            bool chececkresult = Utility.CheckEligibilitySCSTService(Data, model.ApplicationDetails.ServiceCode, (int)CountList.Type001);
                            if (chececkresult == false)
                            {
                                ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                                PreserveModelState(Constant._ModelStateParent, null, true, false);
                                return View("PendingApplicationDetails", (DealingModels)TempData[Constant._ModelStateParent]);
                            }

                            Qry = "Delete from dgen.ScStFeeDetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                            cmdList.Add(Cmd);

                            foreach (ScStFeeDetails Head in model.ApplicationDetailsPostmatOBC.ScStFeeDetails)
                            {
                                Qry = "insert into dgen.ScStFeeDetails(ApplicationNo,FeeinitiateBy,FeeTypeBy,FeeAmount,UserId,IpAddress,LastActionDate) values (@ApplicationNo,@FeeinitiateBy,@FeeTypeBy,@FeeAmount,@UserId,@IpAddress,now())";
                                Cmd = new NpgsqlCommand(Qry);
                                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                                Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                                Cmd.Parameters.AddWithValue("@FeeTypeBy", Head.FeeTypeId);
                                Cmd.Parameters.AddWithValue("@FeeAmount", Head.FeeAmount);
                                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                                cmdList.Add(Cmd);
                            }
                        }

                        if (model.ApplicationDetailsPostmatOBC.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                        {
                            whetherCon = ",GroupId=@GroupId";
                        }

                        Qry = "update dgen.applicationdetailspostmatobc set WhetherVerified=@WhetherVerified,WhetherSchoolRecomended=@WhetherSchoolRecomended" + whetherCon + ",SchollRemarks=@SchollRemarks,SchollRemarksBy=@SchollRemarksBy,SchollRemarksIpAddress=@SchollRemarksIpAddress,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", model.ApplicationDetailsPostmatOBC.WhetherSchoolRecomended);
                        Cmd.Parameters.AddWithValue("@GroupId", model.ApplicationDetailsPostmatOBC.GroupId);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@SchollRemarks", model.ApplicationDetailsPostmatOBC.SchollRemarks);
                        Cmd.Parameters.AddWithValue("@SchollRemarksBy", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.True.ToString());
                        Cmd.Parameters.AddWithValue("@SchollRemarksIpAddress", Utility.GetIP4Address());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        Qry = "update dgen.prematapplicationprocess set ProcessStatusId=@ProcessStatusId,whetherrecommended=@whetherrecommended, WhetherRevertBack=@WhetherRevertBack, VerificationDate=now(),VerificationBy=@VerificationBy,VerificationIpAddress=@VerificationIpAddress where ApplicationNo=@ApplicationNo;";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@whetherrecommended", model.ApplicationDetailsPostmatOBC.WhetherSchoolRecomended);
                        Cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.Verified);
                        Cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.False.ToString());
                        Cmd.Parameters.AddWithValue("@ServiceCode", model.ApplicationDetails.ServiceCode);
                        Cmd.Parameters.AddWithValue("@VerificationBy", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@VerificationIpAddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        model.ApplicationDARemarks = model.ApplicationDetailsPostmatOBC.SchollRemarks;                                                 
                    }
                    else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.PostmatricSC).ToString())
                    {
                        string DisAmount = string.Empty;
                        string whetherCon = string.Empty;
                        if (model.ApplicationDetailsPostmatSCssd.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                        {
                            Qry = "Select FeeAmount from dgen.ScStFeeDetails Where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Applicant);
                            DataTable dt = data.GetDataTable(Cmd);
                            if (dt != null)
                            {
                                for (int i = 0; i < dt.Rows.Count; i++)
                                {
                                    FillAmount = FillAmount + Convert.ToInt64(dt.Rows[i]["FeeAmount"].ToString());
                                }
                            }
                            foreach (ScStFeeDetails Head in model.ApplicationDetailsPostmatSCssd.ScStFeeDetails)
                            {
                                DisburseAmount = DisburseAmount + Convert.ToInt64(Head.FeeAmount);
                            }
                            model.data = Utility.GetSCSTScholorship(model.ApplicationNo, null, model.ApplicationDetailsPostmatSCssd.GroupId);
                            if (model.data != null)
                            {
                                for (int i = 0; i < model.data.Rows.Count; i++)
                                {
                                    FillAmount = FillAmount + Convert.ToInt64(model.data.Rows[i]["FeeAmount"].ToString());
                                }
                            }
                            Dictionary<string, string> Data = new Dictionary<string, string>();
                            Data.Add("DisAmount", DisburseAmount.ToString());
                            Data.Add("FillAmount", FillAmount.ToString());
                            bool chececkresult = Utility.CheckEligibilitySCSTService(Data, model.ApplicationDetails.ServiceCode, (int)CountList.Type001);
                            if (chececkresult == false)
                            {
                                ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                                PreserveModelState(Constant._ModelStateParent, null, true, false);
                                return View("PendingApplicationDetails", (DealingModels)TempData[Constant._ModelStateParent]);
                            }


                            Qry = "Delete from dgen.ScStFeeDetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                            cmdList.Add(Cmd);

                            foreach (ScStFeeDetails Head in model.ApplicationDetailsPostmatSCssd.ScStFeeDetails)
                            {
                                Qry = "insert into dgen.ScStFeeDetails(ApplicationNo,FeeinitiateBy,FeeTypeBy,FeeAmount,UserId,IpAddress,LastActionDate) values (@ApplicationNo,@FeeinitiateBy,@FeeTypeBy,@FeeAmount,@UserId,@IpAddress,now())";
                                Cmd = new NpgsqlCommand(Qry);
                                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                                Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                                Cmd.Parameters.AddWithValue("@FeeTypeBy", Head.FeeTypeId);
                                Cmd.Parameters.AddWithValue("@FeeAmount", Head.FeeAmount);
                                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                                cmdList.Add(Cmd);
                            }
                        }

                        if (model.ApplicationDetailsPostmatSCssd.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                        {
                            whetherCon = ",GroupId=@GroupId";
                        }

                        Qry = "update dgen.ApplicationDetailsPostmatSCssd set WhetherVerified=@WhetherVerified,WhetherSchoolRecomended=@WhetherSchoolRecomended" + whetherCon + ",SchollRemarks=@SchollRemarks,SchollRemarksBy=@SchollRemarksBy,SchollRemarksIpAddress=@SchollRemarksIpAddress,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", model.ApplicationDetailsPostmatSCssd.WhetherSchoolRecomended);
                        Cmd.Parameters.AddWithValue("@GroupId", model.ApplicationDetailsPostmatSCssd.GroupId);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@SchollRemarks", model.ApplicationDetailsPostmatSCssd.SchollRemarks);
                        Cmd.Parameters.AddWithValue("@SchollRemarksBy", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.True.ToString());
                        Cmd.Parameters.AddWithValue("@SchollRemarksIpAddress", Utility.GetIP4Address());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        Qry = "update dgen.prematapplicationprocess set ProcessStatusId=@ProcessStatusId,whetherrecommended=@whetherrecommended, WhetherRevertBack=@WhetherRevertBack, VerificationDate=now(),VerificationBy=@VerificationBy,VerificationIpAddress=@VerificationIpAddress where ApplicationNo=@ApplicationNo;";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@whetherrecommended", model.ApplicationDetailsPostmatSCssd.WhetherSchoolRecomended);
                        Cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.Verified);
                        Cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.False.ToString());
                        Cmd.Parameters.AddWithValue("@ServiceCode", model.ApplicationDetails.ServiceCode);
                        Cmd.Parameters.AddWithValue("@VerificationBy", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@VerificationIpAddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        model.ApplicationDARemarks = model.ApplicationDetailsPostmatSCssd.SchollRemarks;
                    }

                    //insert in application audit trail
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG006, model.ApplicationDARemarks, (int)ApplicationSource.Window, null));

                    ApplicationStatusId = ((int)Status.TEHSPEN).ToString();
                }

                if (!Utility.CheckCurrentStatusBeforeUpdate(model.ApplicationNo, Convert.ToInt32(ApplicationStatusId), (int)CountList.Type001))
                {
                    ViewData["message"] = "Application is not pending at this level anymore!";
                    return View("message");
                }

                int ActionType = (int)CountList.Type001;
                if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Recovery).ToString())
                {
                    string Amount = Utility.SelectColumnsValue("dgen.applicationdetailsrecovery", "amount", "applicationno", model.ApplicationNo)[0];
                    if (Convert.ToInt32(Amount) > 500000) { ActionType = (int)CountList.Type002; }
                }

                Qry = "update dbo.ApplicationDetails set AcceptedBy=@AcceptedBy,ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDARemarks);
                Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationNo, Convert.ToInt32(ApplicationStatusId), ActionType, DB.LS.ToString()));
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDARemarks);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                data.SaveData(cmdList);

                ViewData["message"] = "Application [" + model.ApplicationNo + "] has been sent to competent authority for approval.";
                return View("message");
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PendingApplicationDetails", (DealingModels)TempData[Constant._ModelStateParent]);
        }
        [EncryptedActionParameter]
        public ActionResult EditApplicantDetails(Int64 AppNo)
        {
            GetData data = new GetData();
            DealingModels model = new DealingModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();

            string Qry = "select ServiceCode FROM dbo.ApplicationDetails where ApplicationNo=@ApplicationNo";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            model.ApplicationDetails.ServiceCode = data.SelectColumns(Cmd)[0];

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Marriage).ToString() || model.ApplicationDetails.ServiceCode == ((int)ServiceList.Solemnization).ToString())
            {
                string str = string.Empty, MarriageActId = string.Empty;
                if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Marriage).ToString()) { MarriageActId = Utility.SelectColumnsValue("dgen.applicationmarriagedetails", "MarriageActId", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0]; }
                if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Solemnization).ToString()) { MarriageActId = Utility.SelectColumnsValue("dgen.applicationmarriagesolemnizationdetails", "MarriageActId", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0]; }
                if (MarriageActId == ((int)MarriageAct.Special).ToString() || MarriageActId == ((int)MarriageAct.Special13).ToString() || MarriageActId == ((int)MarriageAct.Special16).ToString())
                {
                    str = " IR.RelatedId in (@WitnessI,@WitnessII,@WitnessIII)  order by 1 ASC";
                }
                else
                {
                    str = " IR.RelatedId in (@WitnessI,@WitnessII)  order by 1 ASC";
                }

                Qry = "select distinct ROW_NUMBER() OVER (ORDER BY MW.WitnessId asc) AS RowNumber,MW.WitnessId,MW.ApplicationNo,MW.WitnessName,MW.WitnessFatherName,MW.witnesshousenumber,MW.witnessstreetnumber,MW.witnesscountryid,MW.WitnessIdentityTypeId,witnesssublocality,witnesslocalityid,witnesssubdivcode,witnessdistrictcode,witnessstateid,witnesscountryid,witnesspincode,dbo.udf_general_decrypt(MW.WitnessIdentificationNo) as WitnessIdentificationNo,LocalityName as witnessLocalityName,SubDivDescription as witnessSubDivDescription,DistrictName as witnessDistrictName,StateName as witnessstatename,CountryName as witnessCountryName,IR.RelatedId from InformationRelatedMaster IR left outer join dgen.MarriageWitnessMaster MW on MW.witnesstypeid=IR.RelatedId and  MW.ApplicationNo=@ApplicationNo left outer Join Subdivmaster SDm on SDM.subdivcode=MW.witnesssubdivcode left outer join LocalityMaster LM on LM.Localityid=MW.witnesslocalityid left outer join localitytosubdivmaster LS on LS.localityid=LM.localityid and LS.subdivcode=SDM.subdivcode left outer join statemaster SM on SM.stateid=MW.WitnessStateId left outer join districtmaster DM on DM.districtcode=MW.witnessdistrictcode left outer join CountryMaster CM on  CM.countryId=MW.witnesscountryid where " + str;
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@WitnessI", (int)RelatedTo.WitnessI);
                Cmd.Parameters.AddWithValue("@WitnessII", (int)RelatedTo.WitnessII);
                if (MarriageActId == ((int)MarriageAct.Special).ToString() || MarriageActId == ((int)MarriageAct.Special13).ToString() || MarriageActId == ((int)MarriageAct.Special16).ToString())
                {
                    Cmd.Parameters.AddWithValue("@WitnessIII", (int)RelatedTo.WitnessIII);
                }
                model.MarriageWitnessMaster = MarriageWitnessMaster.List<MarriageWitnessMaster>(Cmd);
            }
            else
            {
                return RedirectToAction("BadRequest", "Error");
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SaveApplicantDetails(DealingModels model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    if (Convert.ToInt32(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Marriage || Convert.ToInt32(model.ApplicationDetails.ServiceCode) == (int)ServiceList.Solemnization)
                    {
                        GetData data = new GetData();
                        model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                        model.data = Utility.GetEnclosureDetails(string.Empty, string.Empty, ControllerList.Dealing.ToString(), "EditApplicantEnclosure", model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.Y.ToString());

                        for (int i = 0; i < model.MarriageWitnessMaster.Count; i++)
                        {
                            string Qry = @"update dgen.MarriageWitnessMaster set WitnessName=@WitnessName, WitnessFatherName=@WitnessFatherName,WitnessIdentificationNo=dbo.udf_general_encrypt(@WitnessIdentificationNo),WitnessIdentityTypeId=@WitnessIdentityTypeId,witnesshousenumber=@witnesshousenumber,witnessstreetnumber=@witnessstreetnumber,witnesssublocality=@witnesssublocality,witnesslocalityid=@witnesslocalityid,witnesssubdivcode=@witnesssubdivcode,witnessdistrictcode=@witnessdistrictcode, witnessstateid=@witnessstateid,witnesscountryid=@witnesscountryid,witnesspincode=@witnesspincode,witnesstypeid=@witnesstypeid where WitnessId=@WitnessId;";
                            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@WitnessId", model.MarriageWitnessMaster[i].WitnessId);
                            Cmd.Parameters.AddWithValue("@WitnessName", model.MarriageWitnessMaster[i].WitnessName);
                            Cmd.Parameters.AddWithValue("@WitnessFatherName", model.MarriageWitnessMaster[i].WitnessFatherName);
                            Cmd.Parameters.AddWithValue("@WitnessIdentificationNo", model.MarriageWitnessMaster[i].WitnessIdentificationNo);
                            Cmd.Parameters.AddWithValue("@WitnessIdentityTypeId", model.MarriageWitnessMaster[i].WitnessIdentityTypeId);
                            Cmd.Parameters.AddWithValue("@witnesshousenumber", model.MarriageWitnessMaster[i].witnesshousenumber);
                            Cmd.Parameters.AddWithValue("@witnessstreetnumber", model.MarriageWitnessMaster[i].witnessstreetnumber);
                            Cmd.Parameters.AddWithValue("@witnesssublocality", model.MarriageWitnessMaster[i].witnesssublocality);
                            Cmd.Parameters.AddWithValue("@witnesslocalityid", model.MarriageWitnessMaster[i].witnesslocalityid);
                            Cmd.Parameters.AddWithValue("@witnesssubdivcode", model.MarriageWitnessMaster[i].witnesssubdivcode);
                            Cmd.Parameters.AddWithValue("@witnessdistrictcode", model.MarriageWitnessMaster[i].witnessdistrictcode);
                            Cmd.Parameters.AddWithValue("@witnessstateid", model.MarriageWitnessMaster[i].witnessstateid);
                            Cmd.Parameters.AddWithValue("@witnesscountryid", model.MarriageWitnessMaster[i].witnesscountryid);
                            Cmd.Parameters.AddWithValue("@witnesspincode", model.MarriageWitnessMaster[i].witnesspincode);
                            Cmd.Parameters.AddWithValue("@witnesstypeid", model.MarriageWitnessMaster[i].RelatedId);
                            data.UpdateData(Cmd);
                        }
                        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                        return RedirectToAction("EditApplicantPhoto", new { q = QueryString });
                    }
                    else
                    {
                        return RedirectToAction("BadRequest", "Error");
                    }
                }
                catch
                {
                    return RedirectToAction("Index", "Error");
                }
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("EditApplicantDetails", (DealingModels)TempData[Constant._ModelStateParent]);
        }
        [EncryptedActionParameter]
        public ActionResult EditApplicantPhoto(Int64 AppNo)
        {
            GetData data = new GetData();
            DealingModels model = new DealingModels();
            model.ApplicationDetails = new ApplicationDetails();
            if (TempData[Constant._UniqueId] != null)
            {
                model.ApplicationDetails.ApplicationNo = TempData[Constant._UniqueId].ToString();
            }
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();
            string[] GetValues = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ApplicationStatusId,ServiceCode", "ApplicationNo", model.ApplicationDetails.ApplicationNo);
            model.ApplicationDetails.ApplicationStatusId = GetValues[0];
            model.ApplicationDetails.ServiceCode = GetValues[1];

            string MarriageActId = string.Empty;
            if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Marriage).ToString())
            { MarriageActId = Utility.SelectColumnsValue("dgen.applicationmarriagedetails", "MarriageActId", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0]; }
            else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Solemnization).ToString())
            { MarriageActId = Utility.SelectColumnsValue("dgen.applicationmarriagesolemnizationdetails", "MarriageActId", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0]; }

            string Qry = "select AD.ApplicationNo,IR.RelatedId,IR.RelatedTo,case when AP.refphotoid is not null then 1 else 0 end as WhetherUploaded,AP.PhotoId,AP.refphotoid,AP.WhetherRecaptured from dbo.InformationRelatedMaster IR  left outer join dbo.ServiceToPhotoRelatedMaster SP on IR.RelatedId=SP.RequiredRelatedId inner  join dbo.ApplicationDetails AD on AD.ApplicationRelatedId=SP.ServiceRelatedId and AD.ServiceCode=SP.ServiceCode and AD.ApplicationNo=@ApplicationNo left outer join dbo.ApplicationPhotoMaster AP on AP.ApplicationNo=AD.ApplicationNo and AP.RelatedId=IR.RelatedId where";
            if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Solemnization).ToString())
            {
                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.NOTIACT).ToString())
                {
                    if (MarriageActId == ((int)MarriageAct.Special).ToString() || MarriageActId == ((int)MarriageAct.Special13).ToString() || MarriageActId == ((int)MarriageAct.Special16).ToString())
                    {
                        Qry += " IR.RelatedId in (@Husband,@Wife,@WitnessI,@WitnessII,@WitnessIII)  order by 1 ASC";
                    }
                    else
                    {
                        Qry += " IR.RelatedId in (@Husband,@Wife,@WitnessI,@WitnessII)  order by 1 ASC";
                    }
                }
                else { Qry += " IR.RelatedId in (@Husband,@Wife)"; }
            }
            if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Marriage).ToString())
            {
                if (MarriageActId == ((int)MarriageAct.Special).ToString())
                {
                    Qry += " IR.RelatedId in (@Husband,@Wife,@WitnessI,@WitnessII,@WitnessIII)  order by 1 ASC";
                }
                else
                {
                    Qry += " IR.RelatedId in (@Husband,@Wife,@WitnessI,@WitnessII)  order by 1 ASC";
                }
            }
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Marriage).ToString())
            {
                Cmd.Parameters.AddWithValue("@Husband", (int)RelatedTo.Husband);
                Cmd.Parameters.AddWithValue("@Wife", (int)RelatedTo.Wife);
                Cmd.Parameters.AddWithValue("@WitnessI", (int)RelatedTo.WitnessI);
                Cmd.Parameters.AddWithValue("@WitnessII", (int)RelatedTo.WitnessII);
                if (MarriageActId == ((int)MarriageAct.Special).ToString())
                {
                    Cmd.Parameters.AddWithValue("@WitnessIII", (int)RelatedTo.WitnessIII);
                }
            }
            if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Solemnization).ToString())
            {
                if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.NOTIACT).ToString())
                {
                    if (MarriageActId == ((int)MarriageAct.Special).ToString() || MarriageActId == ((int)MarriageAct.Special13).ToString() || MarriageActId == ((int)MarriageAct.Special16).ToString())
                    {
                        Cmd.Parameters.AddWithValue("@Husband", (int)RelatedTo.Husband);
                        Cmd.Parameters.AddWithValue("@Wife", (int)RelatedTo.Wife);
                        Cmd.Parameters.AddWithValue("@WitnessI", (int)RelatedTo.WitnessI);
                        Cmd.Parameters.AddWithValue("@WitnessII", (int)RelatedTo.WitnessII);
                        Cmd.Parameters.AddWithValue("@WitnessIII", (int)RelatedTo.WitnessIII);
                    }
                    else
                    {
                        Cmd.Parameters.AddWithValue("@Husband", (int)RelatedTo.Husband);
                        Cmd.Parameters.AddWithValue("@Wife", (int)RelatedTo.Wife);
                        Cmd.Parameters.AddWithValue("@WitnessI", (int)RelatedTo.WitnessI);
                        Cmd.Parameters.AddWithValue("@WitnessII", (int)RelatedTo.WitnessII);
                    }
                }
                else
                {
                    Cmd.Parameters.AddWithValue("@Husband", (int)RelatedTo.Husband);
                    Cmd.Parameters.AddWithValue("@Wife", (int)RelatedTo.Wife);
                }

            }
            model.data = data.GetDataTable(Cmd);            

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
            PreserveModelState(Constant._ModelStateParent, model, true, false);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult UploadApplicationPhoto(Int64 AppNo, int Rid)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                DealingModels model = new DealingModels();
                model.ApplicationPhotoMaster = new ApplicationPhotoMaster();
                model.ApplicationDetails = new ApplicationDetails();
                model.ApplicationDetails.ApplicationNo = AppNo.ToString();
                model.ApplicationPhotoMaster.RelatedId = Rid.ToString();
                model.ApplicationDetails.ServiceCode = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0];

                string Qry = "select IR.RelatedTo,case when AP.refphotoid is null then 0 else 1 end as WhetherPhoto,AP.refphotoid from dbo.InformationRelatedMaster IR left outer join dbo.ApplicationPhotoMaster AP on AP.RelatedId=IR.RelatedId and AP.ApplicationNo=@ApplicationNo where IR.RelatedId=@RelatedId";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@RelatedId", model.ApplicationPhotoMaster.RelatedId);
                model.data = data.GetDataTable(Cmd);

                model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());
                PreserveModelState(Constant._ModelStateParent, model, false, true);
                return View(model);
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("EditApplicantPhoto", (DealingModels)TempData[Constant._ModelStateParent]);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult UploadApplicationPhotoPost(DealingModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                byte[] byteArray = Utility.CompareFileCapturePhotoData(model.PhotoData, System.Web.HttpContext.Current.Request.Files["ApplicantPhoto"]);
                string ContentType = System.Web.HttpContext.Current.Request.Files["ApplicantPhoto"].ContentType;

                cmdList.Add(Utility.InsertPhotographdetails(CustomText.TRUE.ToString(), ContentType, byteArray));

                string Qry = "update dbo.ApplicationPhotoMaster set RefPhotoId=@LastInsertedId,WhetherRecaptured=@WhetherRecaptured,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo and RelatedId=@RelatedId and exists(select ApplicationNo from dbo.ApplicationPhotoMaster where ApplicationNo=@ApplicationNo and RelatedId=@RelatedId)";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@RelatedId", model.ApplicationPhotoMaster.RelatedId);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@WhetherRecaptured", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "insert into dbo.ApplicationPhotoMaster(ApplicationNo,RelatedId,WhetherActive,WhetherRecaptured,RefPhotoId,userid,ipaddress,lastactiondate) select @ApplicationNo,@RelatedId,@WhetherActive,@WhetherRecaptured,@LastInsertedId,@userid,@ipaddress,now() where not exists(select ApplicationNo from dbo.ApplicationPhotoMaster where ApplicationNo=@ApplicationNo and RelatedId=@RelatedId)";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                Cmd.Parameters.AddWithValue("@RelatedId", model.ApplicationPhotoMaster.RelatedId);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@WhetherRecaptured", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                data.SaveTransactionalData(cmdList);


                //fill again to display Applcant Photo
                string[] GetValues = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ServiceCode,ApplicationStatusId", "ApplicationNo", model.ApplicationDetails.ApplicationNo);
                model.ApplicationDetails.ServiceCode = GetValues[0];
                model.ApplicationDetails.ApplicationStatusId = GetValues[1];

                string MarriageActId = string.Empty;
                if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Marriage).ToString())
                { MarriageActId = Utility.SelectColumnsValue("dgen.applicationmarriagedetails", "MarriageActId", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0]; }
                else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Solemnization).ToString())
                { MarriageActId = Utility.SelectColumnsValue("dgen.applicationmarriagesolemnizationdetails", "MarriageActId", "ApplicationNo", model.ApplicationDetails.ApplicationNo.ToString())[0]; }

                Qry = "select AD.ApplicationNo,IR.RelatedId,IR.RelatedTo,case when AP.refphotoid is not null then 1 else 0 end as WhetherUploaded,AP.PhotoId,AP.refphotoid,AP.WhetherRecaptured from dbo.InformationRelatedMaster IR  left outer join dbo.ServiceToPhotoRelatedMaster SP on IR.RelatedId=SP.RequiredRelatedId inner  join dbo.ApplicationDetails AD on AD.ApplicationRelatedId=SP.ServiceRelatedId and AD.ServiceCode=SP.ServiceCode and AD.ApplicationNo=@ApplicationNo left outer join dbo.ApplicationPhotoMaster AP on AP.ApplicationNo=AD.ApplicationNo and AP.RelatedId=IR.RelatedId where";
                if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Solemnization).ToString())
                {
                    if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.NOTIACT).ToString())
                    {
                        if (MarriageActId == ((int)MarriageAct.Special).ToString() || MarriageActId == ((int)MarriageAct.Special13).ToString() || MarriageActId == ((int)MarriageAct.Special16).ToString())
                        {
                            Qry += " IR.RelatedId in (@Husband,@Wife,@WitnessI,@WitnessII,@WitnessIII)  order by 1 ASC";
                        }
                        else
                        {
                            Qry += " IR.RelatedId in (@Husband,@Wife,@WitnessI,@WitnessII)  order by 1 ASC";
                        }
                    }
                    else { Qry += " IR.RelatedId in (@Husband,@Wife)"; }
                }
                if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Marriage).ToString())
                {
                    if (MarriageActId == ((int)MarriageAct.Special).ToString())
                    {
                        Qry += " IR.RelatedId in (@Husband,@Wife,@WitnessI,@WitnessII,@WitnessIII)  order by 1 ASC";
                    }
                    else
                    {
                        Qry += " IR.RelatedId in (@Husband,@Wife,@WitnessI,@WitnessII)  order by 1 ASC";
                    }
                }
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Marriage).ToString())
                {
                    Cmd.Parameters.AddWithValue("@Husband", (int)RelatedTo.Husband);
                    Cmd.Parameters.AddWithValue("@Wife", (int)RelatedTo.Wife);
                    Cmd.Parameters.AddWithValue("@WitnessI", (int)RelatedTo.WitnessI);
                    Cmd.Parameters.AddWithValue("@WitnessII", (int)RelatedTo.WitnessII);
                    if (MarriageActId == ((int)MarriageAct.Special).ToString())
                    {
                        Cmd.Parameters.AddWithValue("@WitnessIII", (int)RelatedTo.WitnessIII);
                    }
                }
                if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Solemnization).ToString())
                {
                    if (model.ApplicationDetails.ApplicationStatusId == ((int)Status.NOTIACT).ToString())
                    {
                        if (MarriageActId == ((int)MarriageAct.Special).ToString() || MarriageActId == ((int)MarriageAct.Special13).ToString() || MarriageActId == ((int)MarriageAct.Special16).ToString())
                        {
                            Cmd.Parameters.AddWithValue("@Husband", (int)RelatedTo.Husband);
                            Cmd.Parameters.AddWithValue("@Wife", (int)RelatedTo.Wife);
                            Cmd.Parameters.AddWithValue("@WitnessI", (int)RelatedTo.WitnessI);
                            Cmd.Parameters.AddWithValue("@WitnessII", (int)RelatedTo.WitnessII);
                            Cmd.Parameters.AddWithValue("@WitnessIII", (int)RelatedTo.WitnessIII);
                        }
                        else
                        {
                            Cmd.Parameters.AddWithValue("@Husband", (int)RelatedTo.Husband);
                            Cmd.Parameters.AddWithValue("@Wife", (int)RelatedTo.Wife);
                            Cmd.Parameters.AddWithValue("@WitnessI", (int)RelatedTo.WitnessI);
                            Cmd.Parameters.AddWithValue("@WitnessII", (int)RelatedTo.WitnessII);
                        }
                    }
                    else
                    {
                        Cmd.Parameters.AddWithValue("@Husband", (int)RelatedTo.Husband);
                        Cmd.Parameters.AddWithValue("@Wife", (int)RelatedTo.Wife);
                    }

                }
                model.data = data.GetDataTable(Cmd);
                model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString());

                ViewBag.DisplayMessage = "Photo has been upload successfully.!!!";
                PreserveModelState(Constant._ModelStateParent, null, false, true);
                return View("EditApplicantPhoto", model);
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("UploadApplicationPhoto", (DealingModels)TempData[Constant._ModelStateParent]);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult EditApplicantPhotoPost(DealingModels model, FormCollection form)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    GetData data = new GetData();
                    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                    if (!Utility.CheckCurrentStatusBeforeUpdate(model.ApplicationDetails.ApplicationNo, (int)Status.TEHSPEN, (int)CountList.Type001))
                    {
                        ViewData["message"] = "Application is not pending at this level anymore!";
                        return View("message");
                    }

                    
                    model.ApplicationDetails.ServiceCode = Utility.GetServiceCode(Convert.ToInt64(model.ApplicationDetails.ApplicationNo))[0];

                    string Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,applicationremarks=@applicationremarks,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSPEN);
                    Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationDetails.ApplicationNo, (int)Status.TEHSPEN, (int)CountList.Type001, DB.LS.ToString()));
                    Cmd.Parameters.AddWithValue("@applicationremarks", model.ApplicationDARemarks);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSPEN);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDARemarks);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);


                    string DealingRecommandDate = string.Empty, SolemnizationDate = string.Empty;
                    if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Marriage).ToString())
                    {
                        DealingRecommandDate = Utility.SelectColumnsValue("dgen.applicationmarriagedetails", "dealingrecommanddate", "ApplicationNo", model.ApplicationDetails.ApplicationNo)[0];
                    }
                    if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Solemnization).ToString())
                    {
                        string[] value = Utility.SelectColumnsValue("dgen.applicationmarriagesolemnizationdetails", "SolemnizationDate,dealingrecommanddate", "ApplicationNo", model.ApplicationDetails.ApplicationNo);
                        SolemnizationDate = value[0];
                        DealingRecommandDate = value[1];

                    }
                    if (string.IsNullOrEmpty(DealingRecommandDate))
                    {
                        if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Marriage).ToString())
                        {

                            Qry = "update dgen.applicationmarriagedetails set DealingRecommandDate=now(),userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);
                        }
                        if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.Solemnization).ToString())
                        {
                            if (!string.IsNullOrEmpty(SolemnizationDate))
                            {
                                Qry = "update dgen.applicationmarriagesolemnizationdetails set DealingRecommandDate=now(),userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                                Cmd = new NpgsqlCommand(Qry);
                                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                cmdList.Add(Cmd);
                            }
                        }
                    }


                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG036, null, (int)ApplicationSource.Window, null));

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG006, model.ApplicationDARemarks, (int)ApplicationSource.Window, null));
                    
                    data.SaveData(cmdList);
                    ViewData["message"] = "Application [Application No: " + model.ApplicationDetails.ApplicationNo + "] has been sent to competent authority for approval.";
                    return View("message");
                }
                catch
                {
                    return RedirectToAction("Index", "Error");
                }
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("EditApplicantPhoto", (DealingModels)TempData[Constant._ModelStateParent]);
        }
        [EncryptedActionParameter]
        public ActionResult SolemnizationApplicationSearch()
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.DEAL).ToString()) { return RedirectToAction("UnauthorizedRequest"); }
            return View();
        }
        [EncryptedActionParameter]
        public ActionResult SolemnizationApplicationList()
        {
            GetData data = new GetData();
            DealingModels model = new DealingModels();

            string addScript = Utility.GetScriptForAuthorizationProcess();
            //string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,AD.ApplicantDob,AD.ApplicationStatusId from dbo.ApplicationDetails AD where AD.ServiceCode=@ServiceCode and AD.applicationsubdivcode in (@ParamSubDivCode) and AD.ApplicationStatusId=@ApplicationStatusId order by AD.applicationdate";
            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,AD.ApplicantDob,AD.ApplicationStatusId from dbo.ApplicationDetails AD inner join servicemaster SM  on SM.ServiceCode=AD.ServiceCode where AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId and SM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) " + addScript + " order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.Solemnization);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.NOTIACT);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult SendForVerification()
        {
            return View();
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SendForVerification(DealingModels model)
        {
            if (ModelState.IsValid)
            {
                model.StatusId = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ApplicationStatusId", "ApplicationNo", model.ApplicationNo.ToString())[0];
                model.IsAlreadyVerified = Utility.SelectColumnsValue("dbo.VerifierApplicationDetails", "ApplicationNo", "ApplicationNo", model.ApplicationNo.ToString())[0];
                if (string.IsNullOrEmpty(model.IsAlreadyVerified) && model.StatusId == ((int)Status.DEALOLR).ToString())
                {
                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo", "StsId" }, new ArrayList() { model.ApplicationNo, model.StatusId });
                    return RedirectToAction("PendingApplicationDetails", "Dealing", new { q = QueryString });
                }
                ViewBag.DisplayMessage = "Application not pending at this level or already send for verification!";
                return View();
            }
            return View();
        }        
        #endregion

        #region action methods for NOC
        [EncryptedActionParameter]
        public ActionResult NOCAcquisitionEntry(string strVRKIReq)
        {
            GetData data = new GetData();
            string Qry = string.Empty; NpgsqlCommand Cmd = null;
            DealingModels model = new DealingModels();
            model.NOCAcquisitionDetails = new NOCAcquisitionDetails();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            if (string.IsNullOrEmpty(strVRKIReq)) { return View(model); }
            string[] arr = strVRKIReq.Split('|');
            model.NOCAcquisitionDetails.VillageId = arr[0];
            model.NOCAcquisitionDetails.RectangleNo = arr[1];
            model.NOCAcquisitionDetails.KhasraNo = arr[2];
            model.NOCAcquisitionDetails.AcquisitionId = arr[3];
            model.NOCAcquisitionDetails.RType = arr[4];
            model.NOCAcquisitionDetails.AcquisitionTypeId = arr[5];
            model.NOCAcquisitionDetails.AcquisitionNo = arr[6];
            model.NOCAcquisitionDetails.AcquisitionDate = arr[7];
            if (!string.IsNullOrEmpty(model.NOCAcquisitionDetails.AcquisitionId))
            {
                Qry = "select AcquisitionId,AQ.VillageId,VM.VillageName,RectangleNo,KhasraNo,Bigha,Biswa,Biswansi,Min,AcquisitiontypeId,acquisitionno,SV1.valuename as Acquisitiontype,to_char(Acquisitiondate,'DD/MM/YYYY') as Acquisitiondate,to_char(Acquisitionapprovaldate,'DD/MM/YYYY') as Acquisitionapprovaldate,Acquisitionremarks from dgen.nocacquisitionmaster AQ inner join VillageMaster VM on VM.VillageId=AQ.VillageId inner join selectmastervaluedetails SV1 on SV1.valueid=AQ.AcquisitiontypeId where AcquisitionId=@AcquisitionId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@AcquisitionId", model.NOCAcquisitionDetails.AcquisitionId);
                model.NOCAcquisitionDetails = NOCAcquisitionDetails.Get<NOCAcquisitionDetails>(new NOCAcquisitionDetails(), Cmd);
                model.NOCAcquisitionDetails.RType = arr[4];
            }
            else
            {
                Qry = "select AcquisitionId,VM.villagename,khasrano,rectangleno,Bigha,Biswa,Biswansi,Min,acquisitionno,SV1.valuename as Acquisitiontype,to_char(Acquisitiondate,'DD/MM/YYYY') as Acquisitiondate,to_char(Acquisitionapprovaldate,'DD/MM/YYYY') as Acquisitionapprovaldate,Acquisitionremarks,AQ.whetheractive from dgen.nocacquisitionmaster AQ inner join villagemaster VM on VM.villageid=AQ.VillageId inner join selectmastervaluedetails SV1 on SV1.valueid=AQ.AcquisitiontypeId  where AQ.VillageId=@VillageId and AQ.RectangleNo=@RectangleNo and AQ.KhasraNo=@KhasraNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@VillageId", model.NOCAcquisitionDetails.VillageId);
                Cmd.Parameters.AddWithValue("@RectangleNo", model.NOCAcquisitionDetails.RectangleNo);
                Cmd.Parameters.AddWithValue("@KhasraNo", model.NOCAcquisitionDetails.KhasraNo);
                model.data = data.GetDataTable(Cmd);
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult NOCAcquisitionEntry(DealingModels model)
        {
            if (ModelState.IsValid)
            {

                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Qry = string.Empty, QueryString = string.Empty; NpgsqlCommand Cmd = null;
                if (model.NOCAcquisitionDetails.RType == ((int)CountList.Type001).ToString())
                {
                    if (string.IsNullOrEmpty(model.NOCAcquisitionDetails.AcquisitionTypeId) || string.IsNullOrEmpty(model.NOCAcquisitionDetails.AcquisitionNo) || string.IsNullOrEmpty(model.NOCAcquisitionDetails.AcquisitionDate))
                    {
                        QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "strVRKIReq" }, new ArrayList() { model.NOCAcquisitionDetails.VillageId + "|" + model.NOCAcquisitionDetails.RectangleNo + "|" + model.NOCAcquisitionDetails.KhasraNo + "|" + model.NOCAcquisitionDetails.AcquisitionId + "|" + model.NOCAcquisitionDetails.RType + "|" + model.NOCAcquisitionDetails.AcquisitionTypeId + "|" + model.NOCAcquisitionDetails.AcquisitionNo + "|" + model.NOCAcquisitionDetails.AcquisitionDate });
                        return RedirectToAction("NOCAcquisitionEntry", "Dealing", new { q = QueryString });
                    }
                    if (string.IsNullOrEmpty(model.NOCAcquisitionDetails.AcquisitionId)) { Qry = "insert into dgen.nocAcquisitionmaster (VillageId,RectangleNo,KhasraNo,Bigha,Biswa,Biswansi,Min,AcquisitionNo,AcquisitiontypeId,Acquisitiondate,Acquisitionremarks,UserId,Ipaddress,Lastactiondate)values(@VillageId,@RectangleNo,@KhasraNo,@Bigha,@Biswa,@Biswansi,@Min,@AcquisitionNo,@AcquisitiontypeId,@Acquisitiondate,@Acquisitionremarks,@UserId,@Ipaddress,now())"; }
                    else { Qry = "update dgen.nocAcquisitionmaster set VillageId=@VillageId,RectangleNo=@RectangleNo,KhasraNo=@KhasraNo,Bigha=@Bigha,Biswa=@Biswa,Biswansi=@Biswansi,Min=@Min,AcquisitionNo=@AcquisitionNo,AcquisitiontypeId=@AcquisitiontypeId,Acquisitiondate=@Acquisitiondate,Acquisitionremarks=@Acquisitionremarks,UserId=@UserId,Ipaddress=@Ipaddress,LastActionDate=now() where AcquisitionId=@AcquisitionId"; }
                }
                else if (model.NOCAcquisitionDetails.RType == ((int)CountList.Type002).ToString())
                {
                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "strVRKIReq" }, new ArrayList() { model.NOCAcquisitionDetails.VillageId + "|" + model.NOCAcquisitionDetails.RectangleNo + "|" + model.NOCAcquisitionDetails.KhasraNo + "|" + model.NOCAcquisitionDetails.AcquisitionId + "|" + model.NOCAcquisitionDetails.RType + "|" + model.NOCAcquisitionDetails.AcquisitionTypeId + "|" + model.NOCAcquisitionDetails.AcquisitionNo + "|" + model.NOCAcquisitionDetails.AcquisitionDate });
                    return RedirectToAction("NOCAcquisitionEntry", "Dealing", new { q = QueryString });
                }
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@AcquisitionId", model.NOCAcquisitionDetails.AcquisitionId);
                Cmd.Parameters.AddWithValue("@VillageId", model.NOCAcquisitionDetails.VillageId);
                Cmd.Parameters.AddWithValue("@KhasraNo", model.NOCAcquisitionDetails.KhasraNo);
                Cmd.Parameters.AddWithValue("@RectangleNo", model.NOCAcquisitionDetails.RectangleNo);
                Cmd.Parameters.AddWithValue("@AcquisitionTypeId", model.NOCAcquisitionDetails.AcquisitionTypeId);
                Cmd.Parameters.AddWithValue("@AcquisitionNo", model.NOCAcquisitionDetails.AcquisitionNo);
                Cmd.Parameters.AddWithValue("@Bigha", string.IsNullOrEmpty(model.NOCAcquisitionDetails.Bigha) ? ((int)CountList.Type000).ToString() : model.NOCAcquisitionDetails.Bigha);
                Cmd.Parameters.AddWithValue("@Biswa", string.IsNullOrEmpty(model.NOCAcquisitionDetails.Biswa) ? ((int)CountList.Type000).ToString() : model.NOCAcquisitionDetails.Biswa);
                Cmd.Parameters.AddWithValue("@Biswansi", string.IsNullOrEmpty(model.NOCAcquisitionDetails.Biswansi) ? ((int)CountList.Type000).ToString() : model.NOCAcquisitionDetails.Biswansi);
                Cmd.Parameters.AddWithValue("@Min", model.NOCAcquisitionDetails.Min);
                Cmd.Parameters.AddWithValue("@Acquisitiondate", Utility.GetDateYYYYMMDD(model.NOCAcquisitionDetails.AcquisitionDate, '/', "0/1/2"));
                Cmd.Parameters.AddWithValue("@Acquisitionremarks", model.NOCAcquisitionDetails.AcquisitionRemarks);
                Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);
                data.SaveData(cmdList);
                if (string.IsNullOrEmpty(model.NOCAcquisitionDetails.AcquisitionId))
                { PreserveModelState(Constant._ActionMessage, "Acquisition Added!", false, true); }
                else
                {
                    PreserveModelState(Constant._ActionMessage, "Acquisition Updated!", false, true);
                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "strVRKIReq" }, new ArrayList() { model.NOCAcquisitionDetails.VillageId + "|" + model.NOCAcquisitionDetails.RectangleNo + "|" + model.NOCAcquisitionDetails.KhasraNo + "||" + ((int)CountList.Type002).ToString() + "|" + model.NOCAcquisitionDetails.AcquisitionTypeId + "|" + model.NOCAcquisitionDetails.AcquisitionNo + "|" + model.NOCAcquisitionDetails.AcquisitionDate });
                    return RedirectToAction("NOCAcquisitionEntry", "Dealing", new { q = QueryString });
                }

                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "strVRKIReq" }, new ArrayList() { model.NOCAcquisitionDetails.VillageId + "|" + model.NOCAcquisitionDetails.RectangleNo + "|" + model.NOCAcquisitionDetails.KhasraNo + "|" + model.NOCAcquisitionDetails.AcquisitionId + "|" + model.NOCAcquisitionDetails.RType + "|" + model.NOCAcquisitionDetails.AcquisitionTypeId + "|" + model.NOCAcquisitionDetails.AcquisitionNo + "|" + model.NOCAcquisitionDetails.AcquisitionDate });
                return RedirectToAction("NOCAcquisitionEntry", "Dealing", new { q = QueryString });



            }
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult NOCViolationEntry(string strVRKIReq)
        {
            GetData data = new GetData();
            string Qry = string.Empty; NpgsqlCommand Cmd = null;
            DealingModels model = new DealingModels();
            model.NOCViolationDetails = new NOCViolationDetails();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            if (string.IsNullOrEmpty(strVRKIReq)) { return View(model); }
            string[] arr = strVRKIReq.Split('|');
            model.NOCViolationDetails.VillageId = arr[0];
            model.NOCViolationDetails.RectangleNo = arr[1];
            model.NOCViolationDetails.KhasraNo = arr[2];
            model.NOCViolationDetails.ViolationId = arr[3];
            model.NOCViolationDetails.RType = arr[4];

            model.NOCViolationDetails.LandId = arr[5];
            model.NOCViolationDetails.SectionId = arr[6];
            model.NOCViolationDetails.VDate = arr[7];


            if (!string.IsNullOrEmpty(model.NOCViolationDetails.ViolationId))
            {
                Qry = "select WhetherDeViolate,ViolationId,villageid,localityid,khasrano,rectangleno,Violationactid,landid,sectionid,to_char(vdate,'DD/MM/YYYY') as vdate,remarks,whetheractive from dgen.nocviolationmaster where violationid=@violationid";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ViolationId", model.NOCViolationDetails.ViolationId);
                model.NOCViolationDetails = NOCViolationDetails.Get<NOCViolationDetails>(new NOCViolationDetails(), Cmd);
                model.NOCViolationDetails.RType = arr[4];
            }
            else
            {
                Qry = "select V.WhetherDeViolate,V.ViolationId,VM.villagename,LM.localityname,V.khasrano,V.rectangleno,SV1.valuename as act,SV2.valuename as land,SV3.valuename as section,to_char(V.vdate,'DD/MM/YYYY') as vdate,v.remarks,v.whetheractive from dgen.nocviolationmaster V inner join villagemaster VM on VM.villageid=V.VillageId left outer join localitymaster LM on LM.localityId=V.localityId inner join selectmastervaluedetails SV1 on SV1.valueid=V.violationactid inner join selectmastervaluedetails SV2 on SV2.valueid=V.landid inner join selectmastervaluedetails SV3 on SV3.valueid=V.sectionid   where V.VillageId=@VillageId and V.RectangleNo=@RectangleNo and V.KhasraNo=@KhasraNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@VillageId", model.NOCViolationDetails.VillageId);
                Cmd.Parameters.AddWithValue("@RectangleNo", model.NOCViolationDetails.RectangleNo);
                Cmd.Parameters.AddWithValue("@KhasraNo", model.NOCViolationDetails.KhasraNo);
                model.data = data.GetDataTable(Cmd);
            }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult NOCViolationEntry(DealingModels model)
        {
            if (ModelState.IsValid)
            {

                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Qry = string.Empty, QueryString = string.Empty; NpgsqlCommand Cmd = null;
                if (model.NOCViolationDetails.RType == ((int)CountList.Type001).ToString())
                {
                    if (string.IsNullOrEmpty(model.NOCViolationDetails.ViolationactId) || string.IsNullOrEmpty(model.NOCViolationDetails.LandId) || string.IsNullOrEmpty(model.NOCViolationDetails.SectionId))
                    {
                        QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "strVRKIReq" }, new ArrayList() { model.NOCViolationDetails.VillageId + "|" + model.NOCViolationDetails.RectangleNo + "|" + model.NOCViolationDetails.KhasraNo + "|" + model.NOCViolationDetails.ViolationId + "|" + model.NOCViolationDetails.RType + "|" + model.NOCViolationDetails.LandId + "|" + model.NOCViolationDetails.SectionId + "|" + model.NOCViolationDetails.VDate });
                        return RedirectToAction("NOCViolationEntry", "Dealing", new { q = QueryString });
                    }
                    if (string.IsNullOrEmpty(model.NOCViolationDetails.ViolationId)) { Qry = "insert into dgen.nocviolationmaster (VillageId,KhasraNo,RectangleNo,ViolationActId,LandId,SectionId,VDate,Remarks,UserId,Ipaddress,LastActionDate)values(@VillageId,@KhasraNo,@RectangleNo,@ViolationActId,@LandId,@SectionId,@VDate,@Remarks,@UserId,@Ipaddress,now())"; }
                    else { Qry = "update dgen.nocviolationmaster set VillageId=@VillageId,KhasraNo=@KhasraNo,RectangleNo=@RectangleNo,ViolationActId=@ViolationActId,LandId=@LandId,SectionId=@SectionId,VDate=@VDate,Remarks=@Remarks,UserId=@UserId,Ipaddress=@Ipaddress,LastActionDate=now() where ViolationId=@ViolationId"; }
                }
                else if (model.NOCViolationDetails.RType == ((int)CountList.Type002).ToString())
                {
                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "strVRKIReq" }, new ArrayList() { model.NOCViolationDetails.VillageId + "|" + model.NOCViolationDetails.RectangleNo + "|" + model.NOCViolationDetails.KhasraNo + "|" + model.NOCViolationDetails.ViolationId + "|" + model.NOCViolationDetails.RType + "|" + model.NOCViolationDetails.LandId + "|" + model.NOCViolationDetails.SectionId + "|" + model.NOCViolationDetails.VDate });
                    return RedirectToAction("NOCViolationEntry", "Dealing", new { q = QueryString });
                }
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ViolationId", model.NOCViolationDetails.ViolationId);
                Cmd.Parameters.AddWithValue("@VillageId", model.NOCViolationDetails.VillageId);
                Cmd.Parameters.AddWithValue("@KhasraNo", model.NOCViolationDetails.KhasraNo);
                Cmd.Parameters.AddWithValue("@RectangleNo", model.NOCViolationDetails.RectangleNo);
                Cmd.Parameters.AddWithValue("@ViolationActId", model.NOCViolationDetails.ViolationactId);
                Cmd.Parameters.AddWithValue("@LandId", model.NOCViolationDetails.LandId);
                Cmd.Parameters.AddWithValue("@SectionId", model.NOCViolationDetails.SectionId);
                Cmd.Parameters.AddWithValue("@VDate", Utility.GetDateYYYYMMDD(model.NOCViolationDetails.VDate, '/', "0/1/2"));
                Cmd.Parameters.AddWithValue("@Remarks", model.NOCViolationDetails.Remarks);
                Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);
                data.SaveData(cmdList);
                if (string.IsNullOrEmpty(model.NOCViolationDetails.ViolationId))
                { PreserveModelState(Constant._ActionMessage, "Violation Added!", false, true); }
                else { PreserveModelState(Constant._ActionMessage, "Violation Updated!", false, true); }

                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "strVRKIReq" }, new ArrayList() { model.NOCViolationDetails.VillageId + "|" + model.NOCViolationDetails.RectangleNo + "|" + model.NOCViolationDetails.KhasraNo + "|" + model.NOCViolationDetails.ViolationId + "|" + model.NOCViolationDetails.RType + "|" + model.NOCViolationDetails.LandId + "|" + model.NOCViolationDetails.SectionId + "|" + model.NOCViolationDetails.VDate });
                return RedirectToAction("NOCViolationEntry", "Dealing", new { q = QueryString });



            }
            return View(model);
        }
        #endregion

        #region action methods for SC/ST

        [EncryptedActionParameter]
        public ActionResult PendingAppServiceWiseSCSTSummary(int sid)
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.DEAL).ToString()) { return RedirectToAction("UnauthorizedRequest"); }
            GetData data = new GetData();
            DealingModels model = new DealingModels();
            string WhetherCondition = string.Empty;
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { WhetherCondition = " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and whetherschoolrecomended=@WhetherSchoolRecomended then 1 end),0) as Recomended,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and whetherschoolrecomended=@WhetherSchoolRecomended1 then 1 end),0) as NotRecomended  from dbo.ApplicationDetails AD  inner join dgen.applicationdetailsprematssc ADSC on AD.ApplicationNo=ADSC.ApplicationNo left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode " + WhetherCondition + " and AD.ServiceCode in (@ParamServiceCode) and ADSC.SchoolId is not Null group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended1", CustomText.False.ToString());
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult PendingAppSchoolWiseSCSTSummary(int SubDiv, int ServiceCode)
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.DEAL).ToString()) { return RedirectToAction("UnauthorizedRequest"); }
            GetData data = new GetData();
            DealingModels model = new DealingModels();
            string Qry = "select ADSC.SchoolID,SchoolName,SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and whetherschoolrecomended=@WhetherSchoolRecomended then 1 end),0) as Recomended,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId  and whetherschoolrecomended=@WhetherSchoolRecomended1 then 1 end),0) as NotRecomended  from dbo.ApplicationDetails AD  inner join dgen.applicationdetailsprematssc ADSC on AD.ApplicationNo=ADSC.ApplicationNo inner join dgen.prematschoolmaster PSM on PSM.SchoolId=ADSC.SchoolId left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.applicationsubdivcode in (@SubDivCode) and AD.ServiceCode in (@ServiceCode) group by ADSC.SchoolID,SchoolName,AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@WhetherSchoolRecomended1", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@SubDivCode", SubDiv);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }

        [EncryptedActionParameter]
        public ActionResult PendingApplicationSCSTSummary(int sid, int? AcademicSession = 0)
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.DEAL).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

            GetData data = new GetData();
            NpgsqlCommand cmd = new NpgsqlCommand();
            DealingModels model = new DealingModels();
            string Qry = string.Empty, cond = string.Empty;
            // please uncomment this code after reslve the issue
            //if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); } 

            // please comment this code after reslve the issue
            // temp code for set back year session (remove after soltuion)
            if (AcademicSession < 1) { AcademicSession = DateTime.Now.Year - 1; } 
            
            if (AcademicSession == (int)CountList.Type000)
            {
                ////----------------------Temp comment for 2017-18 session, un-comment when you wants to process for 2017-18
                //Qry = "select s1.valuename from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                //cmd = new NpgsqlCommand(Qry);
                //cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SCSTWelfareAcadmicSession);
                //AcademicSession = Convert.ToInt32(data.SelectColumns(cmd)[0]);
                //AcademicSession = 2016;
            }

            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { cond += " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { cond += " and ADSC.DepartmentId in (@Code) "; }
            if (AcademicSession != (int)CountList.Type000) { cond += " and PAP.AcademicSession=@AcademicSession "; }

            Qry = "select SC.ServiceName,SC.ServiceCode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId then 1 end),0) as Pending,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ADSC.whetherreceiptuploaded=True then 1 end),0) as UploadLetter,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and ADSC.whetherreceiptuploaded=False then 1 end),0) as NotUploadLetter from dbo.ApplicationDetails AD  inner join (select ApplicationNo,whetherreceiptuploaded from  dgen.applicationdetailsmeritprofessional union all select ApplicationNo,whetherreceiptuploaded from dgen.applicationdetailspostmatobc union all select ApplicationNo,whetherreceiptuploaded from  dgen.ApplicationDetailsPostmatSCssd )  ADSC on AD.ApplicationNo=ADSC.ApplicationNo inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo = AD.ApplicationNo left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode " + cond + " and AD.ServiceCode in (@ParamServiceCode) and PAP.SchoolId is Null group by SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@Code", Sessions.getEmployeeUser().AuthorizationId);
            //cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            if (AcademicSession != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession); }
            model.data = data.GetDataTable(cmd);

            model.StatusId = sid.ToString();
            model.AcademicSession = AcademicSession.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingApplicationSCSTSummary(DealingModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid", "AcademicSession" }, new ArrayList() { Convert.ToInt32(model.StatusId), AcademicSession });
                return RedirectToAction("PendingApplicationSCSTSummary", "Dealing", new { q = QueryString });
            }
            return View("PendingApplicationSCSTSummary", model);
        }
        [EncryptedActionParameter]
        public ActionResult PendingApplicationSCSTList(int ServiceCode, int SchoolId, int Type, int AcademicSession)
        {
            GetData data = new GetData();
            DealingModels model = new DealingModels();
            string Qry = string.Empty;
            string WhetherCondition = string.Empty;
            if (Type == (int)CountList.Type000) { WhetherCondition = " and whetherschoolrecomended=true "; }
            else if (Type == (int)CountList.Type001) { WhetherCondition = " and whetherschoolrecomended=false "; }
            else if (Type == (int)CountList.Type003) { WhetherCondition = " and ADSC.whetherreceiptuploaded=True"; }
            else if (Type == (int)CountList.Type004) { WhetherCondition = " and ADSC.whetherreceiptuploaded=false"; }

            if (SchoolId == (int)CountList.Type000) { WhetherCondition += " and PAP.schoolid is null "; }
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { WhetherCondition += " and ADSC.DepartmentId=@Code "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { WhetherCondition += " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }

            if (SchoolId == (int)CountList.Type000) { Qry = @"select 'Out of Delhi' as SchoolName,"; } else { Qry = @"select SchoolName,"; }
            Qry += @"AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,AD.ApplicantDob,AD.ApplicationStatusId,whetherreceiptuploaded from dbo.ApplicationDetails AD inner join (select ApplicationNo,whetherreceiptuploaded from  dgen.applicationdetailsmeritprofessional union all select ApplicationNo,whetherreceiptuploaded from  dgen.applicationdetailspostmatobc union all select ApplicationNo,whetherreceiptuploaded from  dgen.ApplicationDetailsPostmatSCssd)  ADSC on AD.ApplicationNo=ADSC.ApplicationNo inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode where AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId and PAP.AcademicSession=@AcademicSession " + WhetherCondition + " order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@Code", Sessions.getEmployeeUser().AuthorizationId);
            cmd.Parameters.AddWithValue("@SchoolId", SchoolId);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.DEALOLR);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);

            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        #endregion

        #region action methods for Recovery
        [EncryptedActionParameter]
        public ActionResult RecoveryofDues(Int64 AppNo)
        {
            DealingModels model = new DealingModels();
            model.ApplicationNo = AppNo.ToString();

            Dictionary<string, string> ValidateData = new Dictionary<string, string>();
            ValidateData.Add("ApplicationNo", model.ApplicationNo);

            string DisplayMessage = Utility.WhetherAccessAllowed(ValidateData, new int[] { (int)ValueId.AuthCrendential, (int)ValueId.AuthOtp }, null, null, false, false, false);
            if (!string.IsNullOrEmpty(DisplayMessage))
            {
                ViewData["message"] = DisplayMessage;
                return View("message");
            }

            model.ApplicantDetails = Utility.GetApplicantDetails(AppNo.ToString(), DB.LS.ToString());
            model.ApplicationDetailsRecovery = Utility.GetRecoveryDetails(AppNo.ToString(), DB.LS.ToString());
            model.TotalAmount = Utility.SelectColumnsValue("dgen.applicationdetailsrecovery", "Amount", "ApplicationNo", AppNo.ToString())[0];
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult RecoveryofDues(DealingModels model)
        {
            if (ModelState.IsValid)
            {
                if (string.IsNullOrEmpty(model.RecAmount))
                {
                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationNo });
                    return RedirectToAction("RecoveryofDues", "Dealing", new { q = QueryString });
                }
                else
                {
                    string BalanceAmount = string.Empty, WhetherComplete = CustomText.False.ToString();
                    model.TotalAmount = Utility.SelectColumnsValue("dgen.applicationdetailsrecovery", "Amount", "ApplicationNo", model.ApplicationNo.ToString())[0];
                    if (Convert.ToInt64(model.RecAmount) > Convert.ToInt64(model.TotalAmount))
                    {
                        ViewBag.DisplayMessage = "Amount entered cannot be greater than total amount to be recovered";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View("RecoveryofDues", (DealingModels)TempData[Constant._ModelStateParent]);
                    }
                    else if (Convert.ToInt64(model.RecAmount) <= (int)CountList.Type000)
                    {
                        ViewBag.DisplayMessage = "Amount entered is not valid";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View("RecoveryofDues", (DealingModels)TempData[Constant._ModelStateParent]);
                    }
                    else
                    {
                        string TotalRec = Utility.SelectColumnsValue("dgen.recoveryduesdetails", "case when sum(AmountRecovered) is null then 0 else sum(AmountRecovered) end", "ApplicationNo", model.ApplicationNo.ToString())[0];
                        if ((Convert.ToInt64(TotalRec) + Convert.ToInt64(model.RecAmount)) > Convert.ToInt64(model.TotalAmount))
                        {
                            ViewBag.DisplayMessage = "Amount entered will exceed total amount to be recovered";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("RecoveryofDues", (DealingModels)TempData[Constant._ModelStateParent]);
                        }
                        else
                        {
                            BalanceAmount = (Convert.ToInt64(model.TotalAmount) - (Convert.ToInt64(TotalRec) + Convert.ToInt64(model.RecAmount))).ToString();
                            if (BalanceAmount == ((int)CountList.Type000).ToString())
                            { PreserveModelState(Constant._ActionMessage, "Total Amount Recovered.", false, true); WhetherComplete = CustomText.True.ToString(); }
                        }
                    }
                    GetData data = new GetData();
                    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                    NpgsqlCommand updCmd = new NpgsqlCommand("insert into dgen.recoveryduesdetails(ApplicationNo,AmountRecovered,BalanceAmount,whethercomplete,userid,ipaddress,lastactiondate) values (@ApplicationNo,@AmountRecovered,@BalanceAmount,@whethercomplete,@userid,@ipaddress,now()) ");
                    updCmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    updCmd.Parameters.AddWithValue("@AmountRecovered", model.RecAmount);
                    updCmd.Parameters.AddWithValue("@BalanceAmount", BalanceAmount);
                    updCmd.Parameters.AddWithValue("@whethercomplete", WhetherComplete);
                    updCmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    updCmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(updCmd);
                    data.SaveData(cmdList);
                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationNo });
                    return RedirectToAction("RecoveryofDues", "Dealing", new { q = QueryString });
                }
            }
            return View();
        }
        #endregion

        #region Physical Verification document module
        [HttpGet]
        public ActionResult SearchAppForEncVerification()
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            DealingModels model = new DealingModels();
            return View(model);
        }
        [HttpPost]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult SearchAppForEncVerification(DealingModels model)
        {
            string sts = string.Empty;
            GetData data = new GetData();
            string WhetherCondition = string.Empty;

            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DeptCode)) { WhetherCondition = " and applicationdistrictcode in (@ParamDistCode) "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { WhetherCondition = " and applicationsubdivcode in (@ParamSubDivCode) "; }
            string Qry = "select ApplicationStatusId from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and WhetherDocumentSeen=@WhetherDocumentSeen and ServiceCode in (@ParamServiceCode) " + WhetherCondition;
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            //cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            cmd.Parameters.AddWithValue("@WhetherDocumentSeen", CustomText.False.ToString());
            model.StatusId = data.SelectColumns(cmd)[0];

            if (string.IsNullOrEmpty(model.StatusId))
            {
                ViewBag.DisplayMessage = "This Application is Not Pending For Document Verification!";
                return View(model);
            }

            Dictionary<string, string> ValidateData = new Dictionary<string, string>();
            ValidateData.Add("ApplicationNo", model.ApplicationNo);

            string DisplayMessage = Utility.WhetherAccessAllowed(ValidateData, new int[] { (int)ValueId.AuthCrendential, (int)ValueId.AuthOtp, (int)ValueId.AuthDigital, (int)ValueId.AutheKYC }, null, null, false, true, true);
            if (!string.IsNullOrEmpty(DisplayMessage))
            {
                ViewBag.DisplayMessage = DisplayMessage;
                return View(model);
            }


            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo", "TypeId" }, new ArrayList() { model.ApplicationNo, (int)CountList.Type000 });
            return RedirectToAction("EnclosureverificationDetail", "Dealing", new { q = QueryString });
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult EnclosureverificationDetail(Int64 AppNo)
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            GetData data = new GetData();
            string whethercon = string.Empty;
            DealingModels model = new DealingModels();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            model.ApplicationNo = AppNo.ToString();
            string Qry = "select AED.enclosureid from applicationenclosuredetails  AED left Outer Join applicationenclosureverificationdetails AEVD on AEVD.enclosureid=AED.enclosureid where AED.applicationno=@ApplicationNo  and AEVD.enclosureid is null and Documentid is not null ";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            model.data = data.GetDataTable(Cmd);
            if (model.data != null && model.data.Rows.Count > 0)
            {
                for (int i = 0; i < model.data.Rows.Count; i++)
                {
                    Qry = "insert into applicationenclosureverificationdetails(applicationno,enclosureid,userid,ipaddress,actiondatetime) values(@applicationno,@enclosureid,@userid,@ipaddress,now());";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@applicationno", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@enclosureid", model.data.Rows[i]["enclosureid"]);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                }
                data.SaveData(cmdList);
            }
            model.data1 = Utility.GetEncDetailsForVerification(model.ApplicationNo, ((int)CountList.Type000).ToString());

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult EnclosureverificationDetail(DealingModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Qry = "select EnclosureId from applicationenclosureverificationdetails where ApplicationNo=@ApplicationNo and whetherverified=@whetherverified ";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@whetherverified", CustomText.FALSE.ToString());
                string EnclosureId = data.SelectColumns(Cmd)[0];
                if (!string.IsNullOrEmpty(EnclosureId))
                {
                    ViewData["message"] = "Some Enclosure are Pending For Verification!!!.";
                    return View("message");
                }

                Qry = "update dbo.ApplicationDetails set WhetherDocumentSeen=@WhetherDocumentSeen,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDARemarks);
                Cmd.Parameters.AddWithValue("@WhetherDocumentSeen", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                //insert in audit trail
                cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo.ToString(), (int)ApplicationHistoryMessage.MSG032, model.ApplicationDARemarks.ToString(), (int)ApplicationSource.Window, null));

                data.SaveData(cmdList);

                ViewBag.Message = "Documents has been successfully check and verified.";
                return View("SearchAppForEncVerification");
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View((DealingModels)TempData[Constant._ModelStateParent]);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult Enclosureverification(Int64 AppNo, int EnclosureId)
        {
            GetData data = new GetData();
            DealingModels model = new DealingModels();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            model.ApplicationNo = AppNo.ToString();
            model.EnclosureId = EnclosureId.ToString();
            string Qry = "select AED.DepartmentId,AED.EnclosureId,AED.ApplicationNo,AED.DocumentDetails,IRM.RelatedTo,AED.DocumentTypeId,DTM.DocumentTypeName,AED.DocumentId,case when AED.DocumentDetails is not null then DM.DocumentName || ' (' || AED.DocumentDetails || ')' else DM.DocumentName end as DocumentName,dbo.udf_general_decrypt(AED.DocumentNo) as DocumentNo,AED.WhetherActive,AD.ApplicationStatusId from dbo.ApplicationEnclosureDetails AED inner join applicationenclosureverificationdetails AEVD on AEVD.enclosureid=AED.enclosureid inner join dbo.ApplicationDetails AD on AD.ApplicationNo=AED.ApplicationNo inner join dbo.DocumentTypeMaster DTM on DTM.DocumentTypeID=AED.DocumentTypeId inner join dbo.InformationRelatedMaster IRM on IRM.RelatedId=AED.RelatedId left outer join dbo.DocumentMaster DM on DM.DocumentID=AED.DocumentId  where AED.ApplicationNo=@ApplicationNo  and AEVD.enclosureid=@EnclosureId order by IRM.RelatedTo,DTM.DocumentTypeName,DM.DocumentName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
            Cmd.Parameters.AddWithValue("@EnclosureId", EnclosureId);
            model.data = data.GetDataTable(Cmd);

            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult Enclosureverification(DealingModels model, FormCollection frm)
        {
            GetData data = new GetData();
            string QueryString = string.Empty;
            if (ModelState.IsValid)
            {
                string Qry = "Update ApplicationEnclosureVerificationDetails set verificationtypeid=@verificationtypeid ,verificationdate=@verificationdate,whetherverified=@whetherverified,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where enclosureid=@enclosureid  ";
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@enclosureid", model.EnclosureId);
                cmd.Parameters.AddWithValue("@verificationtypeid", model.EnclosureVerificationMaster.VerificationTypeId);
                cmd.Parameters.AddWithValue("@verificationdate", Utility.GetDateYYYYMMDD(model.EnclosureVerificationMaster.VerificationDate, '/', "0/1/2"));
                cmd.Parameters.AddWithValue("@whetherverified", CustomText.TRUE.ToString());
                cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                data.UpdateData(cmd);

                PreserveModelState(Constant._ActionMessage, "Verification Entred Successful!!! ", false, true);
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { Convert.ToInt64(model.ApplicationNo) });
                return RedirectToAction("EnclosureverificationDetail", new { q = QueryString });
            }

            PreserveModelState(Constant._ActionMessage, "Please Enter All Details!!! ", false, true);
            QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo", "EnclosureId" }, new ArrayList() { Convert.ToInt64(model.ApplicationNo), Convert.ToInt32(model.EnclosureId) });
            return RedirectToAction("Enclosureverification", new { q = QueryString });

        }
        #endregion

        //ExcludeTirthYatra Code is Not Used in Current FLow Block the Code and Exclude View when flow is Final
        #region Tirth Yatra Service
        [EncryptedActionParameter]
        public ActionResult PendingYatraAppSummary(int sid)
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.P130).ToString()) { return RedirectToAction("UnauthorizedRequest"); }
            GetData data = new GetData();
            DealingModels model = new DealingModels();
            string Qry = "select SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName ,count(AD.ApplicationNo) as total, coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId then 1 end),0) as Pending,coalesce(sum(case when ApplicationStatusId not in (@ApplicationStatusId) then 1 end),0) as DoneSecrutiny  from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid inner join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and ADTY.constituencyid=@ParamAuthorizationId and AD.ServiceCode in (@ParamServiceCode) group by SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName order by SMVD.ValueName,constituencyName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            model.data = data.GetDataTable(cmd);
            model.StatusId = sid.ToString();
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult PendingYatraApplicationList(int RouteId, int ConstituencyId, int StatusId)
        {
            GetData data = new GetData();
            DealingModels model = new DealingModels();
            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,AD.ApplicantDob,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo  inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid where AD.ServiceCode=@ServiceCode  and AD.ApplicationStatusId=@ApplicationStatusId and ADTY.ConstituencyId=@ConstituencyId and ADTY.RouteId=@RouteId  order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.TirthYatraYojna);
            cmd.Parameters.AddWithValue("@RouteId", RouteId);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", StatusId);
            cmd.Parameters.AddWithValue("@ConstituencyId", ConstituencyId);
            model.data = data.GetDataTable(cmd);
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult PendingYatraApplicationDetails(DealingModels model)
        {
            if (ModelState.IsValid)
            {
                model.StatusId = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ApplicationStatusId", "ApplicationNo", model.ApplicationNo.ToString())[0];
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo", "StatusId" }, new ArrayList() { model.ApplicationNo, model.StatusId });
                return RedirectToAction("PendingYatraApplicationDetails", "Dealing", new { q = QueryString });
            }
            return View("SerachYatraAppForAction", model);
        }
        [EncryptedActionParameter]
        public ActionResult PendingYatraApplicationDetails(Int64 AppNo, int StatusId)
        {
            GetData data = new GetData();
            DealingModels model = new DealingModels();
            model.ApplicationNo = AppNo.ToString();
            model.StatusId = StatusId.ToString();
            string QueryString = string.Empty, WhetherCondition = string.Empty;


            //Dictionary<string, string> ValidateData = new Dictionary<string, string>();
            //ValidateData.Add("ApplicationNo", model.ApplicationNo);

            //string DisplayMessage = Utility.WhetherAccessAllowed(ValidateData, new int[] { (int)ValueId.AuthCrendential, (int)ValueId.AuthOtp, (int)ValueId.AuthDigital, (int)ValueId.AutheKYC }, null, new int[] { (int)Status.SCOM036, (int)Status.DEALOLR, (int)Status.NOTIACT }, false, true, true);
            //if (!string.IsNullOrEmpty(DisplayMessage))
            //{
            //    PreserveModelState(Constant._ActionMessage, DisplayMessage, false, true);
            //    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.StatusId });
            //    return RedirectToAction("PendingYatraAppSummary", new { q = QueryString });
            //}
            string[] Values = Utility.GetServiceCode(Convert.ToInt64(model.ApplicationNo));
            string Qry = "select ServiceCode,ApplicationStatusId,ApplicationNo FROM dbo.ApplicationDetails where ApplicationNo=@ApplicationNo  and ServiceCode in (@ParamServiceCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            //Cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            string[] Val = data.SelectColumns(Cmd);
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ServiceCode = Val[0];
            model.ApplicationDetails.ApplicationStatusId = Val[1];
            model.ApplicationDetails.ApplicationNo = Val[2];
            if (string.IsNullOrEmpty(model.ApplicationDetails.ApplicationNo))
            {
                PreserveModelState(Constant._ActionMessage, "Application Not Found or Not Available in you account, Kindly Check Your Application No.", false, true);
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.StatusId });
                return RedirectToAction("PendingYatraAppSummary", new { q = QueryString });
            }

            if (model.StatusId == ((int)Status.DEALOLR).ToString())
            {
                model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.TirthYatraYojna)
                {
                    model.ApplicationDetailsTirthYatraYojana = Utility.GetTirthYatraYojnaDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                }
                else
                {
                    return RedirectToAction("UnauthorizedRequest", "Error");
                }

                model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", string.Empty, string.Empty, model.ApplicationDetails.ApplicationNo, DB.LS.ToString(), CustomText.N.ToString());
                model.datab = Utility.GetPhotoDetails(string.Empty, string.Empty, string.Empty, string.Empty, model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
                PreserveModelState(Constant._ModelStateParent, model, false, true);
                return View(model);
            }
            PreserveModelState(Constant._ActionMessage, "Entered Application Not Pending at this Level.", false, true);
            QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.StatusId });
            return RedirectToAction("PendingYatraAppSummary", new { q = QueryString });
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SavePendingYatraApplicationDetails(DealingModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Qry = string.Empty, ApplicationStatusId = string.Empty;

                Dictionary<string, string> ValidateData = new Dictionary<string, string>();
                ValidateData.Add("ApplicationNo", model.ApplicationNo);

                string DisplayMessage = Utility.WhetherAccessAllowed(ValidateData, new int[] { (int)ValueId.AuthCrendential, (int)ValueId.AuthOtp }, null, new int[] { (int)Status.DEALOLR }, false, false, true);
                if (!string.IsNullOrEmpty(DisplayMessage))
                {
                    ViewBag.DisplayMessage = DisplayMessage;
                    PreserveModelState(Constant._ModelStateParent, null, true, false);
                    return View("PendingYatraApplicationDetails", (DealingModels)TempData[Constant._ModelStateParent]);
                }

                Qry = "Update dgen.applicationdetailstirthyatrayojana set VerifyBy=@VerifyBy,VerifyIpAddress=@VerifyIpAddress,VerifyDate=now(),VerifyByRemarks=@VerifyByRemarks where ApplicationNo=@ApplicationNo ";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@VerifyByRemarks", model.ApplicationDARemarks);
                Cmd.Parameters.AddWithValue("@VerifyBy", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@VerifyIpAddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSPEN);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDARemarks);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSPEN);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDARemarks);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                //insert in application audit trail
                cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG006, model.ApplicationDARemarks, (int)ApplicationSource.Window, null));
                data.SaveData(cmdList);

                ViewData["message"] = "Application [" + model.ApplicationNo + "] has been sent to competent authority for approval.";
                return View("message");
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PendingYatraApplicationDetails", (DealingModels)TempData[Constant._ModelStateParent]);
        }

        #endregion

        #region global method current contoller
        //method for preserve model state
        public void PreserveModelState(string Key, object obj, bool IsKeep, bool IsRemove)
        {
            if (IsRemove == true) { TempData.Remove(Key); }
            if (obj != null) { TempData[Key] = obj; }
            if (IsKeep == true) { TempData.Keep(Key); }
        }
        #endregion global method current contoller
    }
}
