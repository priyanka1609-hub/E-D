﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Edistrict.Models;
using Edistrict.Models.DataService;
using System.IO;
using Npgsql;
using Edistrict.Models.ApplicationService;
using System.Web.UI;
using Edistrict.Models.Entities;
using com.toml.dp.util;
using System.Data;
using Edistrict.Models.CustomAttribute;
using System.Collections;
using Edistrict.Models.CustomClass;

namespace Edistrict.Controllers
{
    [Authorize]
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class EpayController : Controller
    {
        #region SBIePay Payment Gateway Module
        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult PaymentReferral(int PayId)
        {
            try
            {
                if (!Request.IsSecureConnection)
                {
                    Response.Redirect("https://" + Request.ServerVariables["HTTP_HOST"] + Request.RawUrl);
                }

                GetData data = new GetData();
                EpayModels model = new EpayModels();
                string AppTableName = string.Empty, AppColumnName = string.Empty, AppValueName = string.Empty;

                string Qry = "select applicationid,applicationno,paymentorderno,paymentcustomerid,otherdetails,(select sum(paymentamount) from applicationpaymentdescription where paymentid=@paymentid) as PaymentAmount from applicationpaymentrequest where paymentid=@paymentid";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@paymentid", PayId);
                model.ApplicationPaymentRequest = ApplicationPaymentRequest.Get<ApplicationPaymentRequest>(new ApplicationPaymentRequest(), Cmd);

                if (!string.IsNullOrEmpty(model.ApplicationPaymentRequest.ApplicationId)) { AppTableName = "web.applicationdetails"; AppColumnName = "applicationid"; AppValueName=model.ApplicationPaymentRequest.ApplicationId; } else if (!string.IsNullOrEmpty(model.ApplicationPaymentRequest.ApplicationNo)) { AppTableName = "dbo.applicationdetails"; AppColumnName = "applicationno"; AppValueName = model.ApplicationPaymentRequest.ApplicationNo; }
                model.ServiceCode = Utility.SelectColumnsValue(AppTableName, "servicecode", AppColumnName, AppValueName)[0];
                model.PaymentGatewayParameter = Utility.GetSbiEpayParameterValue(model.ServiceCode);

                model.ReferralValue = Utility.EncryptSbiEpayRequest(model.ApplicationPaymentRequest, model.PaymentGatewayParameter);
                model.ReferralUrl = model.PaymentGatewayParameter.PushPostUrl;
                model.MerchantId = model.PaymentGatewayParameter.MerchantId;

                PreserveModelState(KeyName._Key01, model.ServiceCode, false, true);
                return View(model);
            }
            catch
            {
                ViewData["Message"] = "Your transaction has been failed, please try again later.";
                return View("Message");
            }
        }
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult PaymentResponse(string encData)
        {
            GetData data = new GetData();
            EpayModels model = new EpayModels();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            List<CMDInfoList> CmdInfoList = new List<CMDInfoList>();

            try
            {
                if (TempData[KeyName._Key01] == null) { return RedirectToAction("BadRequest", "Error"); }
                model.ServiceCode = TempData[KeyName._Key01].ToString();

                model.PaymentGatewayParameter = Utility.GetSbiEpayParameterValue(model.ServiceCode);
                model.ApplicationPaymentResponse = Utility.DecryptSbiEpayResponse(encData, model.PaymentGatewayParameter);

                if (model.ApplicationPaymentResponse == null)
                {
                    ViewData["Message"] = "Your transaction has been failed, please try again later after 10 minute.";
                    return View("Message");
                }

                if (string.IsNullOrEmpty(model.ApplicationPaymentResponse.MerchantOrderNo))
                {
                    ViewData["Message"] = "Your transaction has been failed, please try again later after 10 minute.";
                    return View("Message");
                }
                if (model.ApplicationPaymentResponse.PaymentStatus.ToString() == CustomText.NA.ToString())
                {
                    model.ApplicationPaymentResponse.PaymentStatus = ((int)CountList.Type000).ToString();
                }
                if (model.ApplicationPaymentResponse.PaymentAmount.ToString() == CustomText.NA.ToString())
                {
                    model.ApplicationPaymentResponse.PaymentAmount = ((int)CountList.Type000).ToString();
                }

                string Qry = "select a.paymentid,a.applicationid,b.servicecode from applicationpaymentrequest a inner join web.applicationdetails b on b.applicationid=a.applicationid where a.paymentorderno=@paymentorderno";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@paymentorderno", model.ApplicationPaymentResponse.MerchantOrderNo);
                DataTable objData = data.GetDataTable(Cmd);
                model.ApplicationPaymentResponse.PaymentId = objData.Rows[0]["paymentid"].ToString();
                model.ApplicationId = objData.Rows[0]["applicationid"].ToString();
                model.ServiceCode = objData.Rows[0]["servicecode"].ToString();

                Qry = "insert into applicationpaymentresponsegateway(paymentid,responsedata,actiondate,actionuserid,actionipaddress) values(@paymentid,@encData,now(),@actionuserid,@actionipaddress)";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@paymentid", model.ApplicationPaymentResponse.PaymentId);
                Cmd.Parameters.AddWithValue("@encData", encData);
                Cmd.Parameters.AddWithValue("@actionuserid", Utility.GetCurrentUserId());
                Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "insert into applicationpaymentresponse (paymentid,merchantorderno,gatewayreferenceid,paymentstatusid,paymentstatus,paymentamount,paymentcurrency,paymentmode,otherdetails,transactionreason,bankcode,bankreferenceno,transactiondate,transactioncountry,transactioncin,actiondate,actionuserid,actionipaddress) values (@paymentid,@merchantorderno,@gatewayreferenceid,@paymentstatusid,@paymentstatus,@paymentamount,@paymentcurrency,@paymentmode,@otherdetails,@transactionreason,@bankcode,@bankreferenceno,@transactiondate,@transactioncountry,@transactioncin,now(),@actionuserid,@actionipaddress)";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@paymentid", model.ApplicationPaymentResponse.PaymentId);
                Cmd.Parameters.AddWithValue("@merchantorderno", model.ApplicationPaymentResponse.MerchantOrderNo);
                Cmd.Parameters.AddWithValue("@gatewayreferenceid", model.ApplicationPaymentResponse.GatewayReferenceId);
                Cmd.Parameters.AddWithValue("@paymentstatusid", model.ApplicationPaymentResponse.PaymentStatusId);
                Cmd.Parameters.AddWithValue("@paymentstatus", model.ApplicationPaymentResponse.PaymentStatus);
                Cmd.Parameters.AddWithValue("@paymentamount", model.ApplicationPaymentResponse.PaymentAmount);
                Cmd.Parameters.AddWithValue("@paymentcurrency", model.ApplicationPaymentResponse.PaymentCurrency);
                Cmd.Parameters.AddWithValue("@paymentmode", model.ApplicationPaymentResponse.PaymentMode);
                Cmd.Parameters.AddWithValue("@otherdetails", model.ApplicationPaymentResponse.OtherDetails);
                Cmd.Parameters.AddWithValue("@transactionreason", model.ApplicationPaymentResponse.TransactionReason);
                Cmd.Parameters.AddWithValue("@bankcode", model.ApplicationPaymentResponse.BankCode);
                Cmd.Parameters.AddWithValue("@bankreferenceno", model.ApplicationPaymentResponse.BankReferenceNo);
                Cmd.Parameters.AddWithValue("@transactiondate", model.ApplicationPaymentResponse.TransactionDate);
                Cmd.Parameters.AddWithValue("@transactioncountry", model.ApplicationPaymentResponse.TransactionCountry);
                Cmd.Parameters.AddWithValue("@transactioncin", model.ApplicationPaymentResponse.TransactionCin);
                Cmd.Parameters.AddWithValue("@actionuserid", Utility.GetCurrentUserId());
                Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "update applicationpaymentrequest set paymentstatusid=@paymentstatusid,paymentdate=now(),actionuserid=@actionuserid,actionipaddress=@actionipaddress where paymentid=@paymentid;";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@paymentid", model.ApplicationPaymentResponse.PaymentId);
                Cmd.Parameters.AddWithValue("@paymentstatusid", model.ApplicationPaymentResponse.PaymentStatusId);
                Cmd.Parameters.AddWithValue("@actionuserid", Utility.GetCurrentUserId());
                Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);
                
                model.StatusId = ((int)Status.SCOM030).ToString();
                if (model.ApplicationPaymentResponse.PaymentStatusId == ((int)ValueId.SbiEpaySuccess).ToString())
                {
                    model.StatusId = ((int)Status.SCOM004).ToString();
                    model.ActionMethod = "SubmitFinalAppication";
                    model.ControllerName = ControllerList.Receiving.ToString();
                    
                    //if (model.ServiceCode == ((int)ServiceList.Marriage).ToString() || model.ServiceCode == ((int)ServiceList.Solemnization).ToString())
                    //{
                    //    model.StatusId = ((int)Status.SCOM031).ToString();
                    //    model.ActionMethod = "ApplicationAppointmentMaster";
                    //}

                    if (model.ServiceCode == ((int)ServiceList.Marriage).ToString() || model.ServiceCode == ((int)ServiceList.Solemnization).ToString())
                    {
                        List<NpgsqlCommand> cmdList2 = Utility.LockAppointment(model.ServiceCode, model.ApplicationId, null, null);
                        Utility.MergeCmdListCmdInfo(cmdList2, ref cmdList, ref CmdInfoList);
                    }
                }

                Qry = "update web.applicationdetails set applicationstatusid=@applicationstatusid,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where applicationid=@applicationid";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@applicationid", model.ApplicationId);
                Cmd.Parameters.AddWithValue("@applicationstatusid", model.StatusId);
                Cmd.Parameters.AddWithValue("@userid", Utility.GetCurrentUserId());
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                data.SaveData(cmdList);
                return View(model);
            }
            catch
            {
                ViewData["Message"] = "Your transaction has been failed, please try again later.";
                return View("Message");
            }
        }

        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult PaymentVerificationReferral(int AppId)
        {
            try
            {
                if (!Request.IsSecureConnection)
                {
                    Response.Redirect("https://" + Request.ServerVariables["HTTP_HOST"] + Request.RawUrl);
                }

                GetData data = new GetData();
                EpayModels model = new EpayModels();
                model.ApplicationId = AppId.ToString();
                string AppTableName = string.Empty, AppColumnName = string.Empty, AppValueName = string.Empty;

                string Qry = "select a.applicationid,a.applicationno,b.gatewayreferenceid,a.paymentorderno as merchantorderno from applicationpaymentrequest a left outer join applicationpaymentresponse b on b.paymentid=a.paymentid where a.applicationid=@applicationid  order by a.paymentid desc limit 1";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@applicationid", model.ApplicationId);
                model.ApplicationPaymentResponse = ApplicationPaymentResponse.Get<ApplicationPaymentResponse>(new ApplicationPaymentResponse(), Cmd);

                if (!string.IsNullOrEmpty(model.ApplicationPaymentResponse.ApplicationId)) { AppTableName = "web.applicationdetails"; AppColumnName = "applicationid"; AppValueName = model.ApplicationPaymentResponse.ApplicationId; } else if (!string.IsNullOrEmpty(model.ApplicationPaymentResponse.ApplicationNo)) { AppTableName = "dbo.applicationdetails"; AppColumnName = "applicationno"; AppValueName = model.ApplicationPaymentResponse.ApplicationNo; }
                model.ServiceCode = Utility.SelectColumnsValue(AppTableName, "servicecode", AppColumnName, AppValueName)[0];
                model.PaymentGatewayParameter = Utility.GetSbiEpayParameterValue(model.ServiceCode);

                model.ReferralValue = Utility.EncryptSbiEpayVerificationRequest(model.ApplicationPaymentResponse, model.PaymentGatewayParameter);
                model.ReferralUrl = model.PaymentGatewayParameter.VerifyPostUrl;
                model.MerchantId = model.PaymentGatewayParameter.MerchantId;

                PreserveModelState(KeyName._Key01, model.ServiceCode, false, true);
                PreserveModelState(KeyName._Key02, model.ApplicationPaymentResponse.MerchantOrderNo, false, true);

                return View(model);
            }
            catch
            {
                ViewData["Message"] = "Your transaction has been failed, please try again later.";
                return View("Message");
            }
        }
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult PaymentVerificationResponse(string encStatusData)
        {
            GetData data = new GetData();
            EpayModels model = new EpayModels();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

            try
            {
                if (TempData[KeyName._Key01] == null) { return RedirectToAction("BadRequest", "Error"); }
                model.ServiceCode = TempData[KeyName._Key01].ToString();
                model.IsResponse = true;

                model.PaymentGatewayParameter = Utility.GetSbiEpayParameterValue(model.ServiceCode);
                model.ApplicationPaymentResponse = Utility.DecryptSbiEpayVerificationResponse(encStatusData, model.PaymentGatewayParameter);

                if (model.ApplicationPaymentResponse == null)
                {
                    ViewData["Message"] = "The payment gateway response does not verified, please try again later.";
                    return View("Message");
                }

                // in case if MerchantOrderNo contain the NA string
                if (model.ApplicationPaymentResponse.MerchantOrderNo.ToUpper() == CustomText.NA.ToString())
                {
                    if (TempData[KeyName._Key02] == null) {
                        ViewData["Message"] = "The payment gateway response does not verified, please try again later.";
                        return View("Message");
                    } else {
                        model.IsResponse = false;
                        model.ApplicationPaymentResponse.PaymentStatus = CustomText.FAIL.ToString();
                        model.ApplicationPaymentResponse.PaymentStatusId = ((int)ValueId.SbiEpayCancel).ToString();
                        model.ApplicationPaymentResponse.MerchantOrderNo = TempData[KeyName._Key02].ToString(); 
                    }
                }
                // in case if payment status contain the NA string
                if (model.ApplicationPaymentResponse.PaymentStatus.ToString()==CustomText.NA.ToString())
                {
                    model.ApplicationPaymentResponse.PaymentStatus = ((int)CountList.Type000).ToString();
                }
                // in case if Payment Amount contain the NA string
                if (model.ApplicationPaymentResponse.PaymentAmount.ToString() == CustomText.NA.ToString())
                {
                    model.ApplicationPaymentResponse.PaymentAmount = ((int)CountList.Type000).ToString();
                }

                string Qry = "select a.paymentid,a.applicationid,b.servicecode from applicationpaymentrequest a inner join web.applicationdetails b on b.applicationid=a.applicationid where a.paymentorderno=@paymentorderno";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@paymentorderno", model.ApplicationPaymentResponse.MerchantOrderNo);
                DataTable objData = data.GetDataTable(Cmd);
                model.ApplicationPaymentResponse.PaymentId = objData.Rows[0]["paymentid"].ToString();
                model.ApplicationId = objData.Rows[0]["applicationid"].ToString();
                model.ServiceCode = objData.Rows[0]["servicecode"].ToString();

                if (model.IsResponse)
                {
                    Qry = "insert into applicationpaymentresponsegateway(paymentid,responsedata,actiondate,actionuserid,actionipaddress) values(@paymentid,@encData,now(),@actionuserid,@actionipaddress)";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@paymentid", model.ApplicationPaymentResponse.PaymentId);
                    Cmd.Parameters.AddWithValue("@encData", encStatusData);
                    Cmd.Parameters.AddWithValue("@actionuserid", Utility.GetCurrentUserId());
                    Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    Qry = "insert into applicationpaymentresponse (paymentid,merchantorderno,gatewayreferenceid,paymentstatusid,paymentstatus,paymentamount,paymentcurrency,paymentmode,otherdetails,transactionreason,bankcode,bankreferenceno,transactiondate,transactioncountry,transactioncin,actiondate,actionuserid,actionipaddress) values (@paymentid,@merchantorderno,@gatewayreferenceid,@paymentstatusid,@paymentstatus,@paymentamount,@paymentcurrency,@paymentmode,@otherdetails,@transactionreason,@bankcode,@bankreferenceno,@transactiondate,@transactioncountry,@transactioncin,now(),@actionuserid,@actionipaddress)";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@paymentid", model.ApplicationPaymentResponse.PaymentId);
                    Cmd.Parameters.AddWithValue("@merchantorderno", model.ApplicationPaymentResponse.MerchantOrderNo);
                    Cmd.Parameters.AddWithValue("@gatewayreferenceid", model.ApplicationPaymentResponse.GatewayReferenceId);
                    Cmd.Parameters.AddWithValue("@paymentstatusid", model.ApplicationPaymentResponse.PaymentStatusId);
                    Cmd.Parameters.AddWithValue("@paymentstatus", model.ApplicationPaymentResponse.PaymentStatus);
                    Cmd.Parameters.AddWithValue("@paymentamount", model.ApplicationPaymentResponse.PaymentAmount);
                    Cmd.Parameters.AddWithValue("@paymentcurrency", model.ApplicationPaymentResponse.PaymentCurrency);
                    Cmd.Parameters.AddWithValue("@paymentmode", model.ApplicationPaymentResponse.PaymentMode);
                    Cmd.Parameters.AddWithValue("@otherdetails", model.ApplicationPaymentResponse.OtherDetails);
                    Cmd.Parameters.AddWithValue("@transactionreason", model.ApplicationPaymentResponse.TransactionReason);
                    Cmd.Parameters.AddWithValue("@bankcode", model.ApplicationPaymentResponse.BankCode);
                    Cmd.Parameters.AddWithValue("@bankreferenceno", model.ApplicationPaymentResponse.BankReferenceNo);
                    Cmd.Parameters.AddWithValue("@transactiondate", model.ApplicationPaymentResponse.TransactionDate);
                    Cmd.Parameters.AddWithValue("@transactioncountry", model.ApplicationPaymentResponse.TransactionCountry);
                    Cmd.Parameters.AddWithValue("@transactioncin", model.ApplicationPaymentResponse.TransactionCin);
                    Cmd.Parameters.AddWithValue("@actionuserid", Utility.GetCurrentUserId());
                    Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                }

                Qry = "update applicationpaymentrequest set paymentstatusid=@paymentstatusid,paymentdate=now(),actionuserid=@actionuserid,actionipaddress=@actionipaddress where paymentid=@paymentid;";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@paymentid", model.ApplicationPaymentResponse.PaymentId);
                Cmd.Parameters.AddWithValue("@paymentstatusid", model.ApplicationPaymentResponse.PaymentStatusId);
                Cmd.Parameters.AddWithValue("@actionuserid", Utility.GetCurrentUserId());
                Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                model.StatusId = ((int)Status.SCOM030).ToString();
                if (model.ApplicationPaymentResponse.PaymentStatusId == ((int)ValueId.SbiEpaySuccess).ToString())
                {
                    model.StatusId = ((int)Status.SCOM004).ToString();
                    model.ActionMethod = "SubmitFinalAppication";
                    model.ControllerName = ControllerList.Receiving.ToString();

                    //if (model.ServiceCode == ((int)ServiceList.Marriage).ToString() || model.ServiceCode == ((int)ServiceList.Solemnization).ToString())
                    //{
                    //    model.ActionMethod = "ApplicationAppointmentMaster";
                    //    model.StatusId = ((int)Status.SCOM031).ToString();
                    //}

                    if (model.ServiceCode == ((int)ServiceList.Marriage).ToString() || model.ServiceCode == ((int)ServiceList.Solemnization).ToString())
                    {
                        Utility.LockAppointment(model.ServiceCode, model.ApplicationId, null, null);
                    }
                }

                Qry = "update web.applicationdetails set applicationstatusid=@applicationstatusid,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where applicationid=@applicationid";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@applicationid", model.ApplicationId);
                Cmd.Parameters.AddWithValue("@applicationstatusid", model.StatusId);
                Cmd.Parameters.AddWithValue("@userid", Utility.GetCurrentUserId());
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                data.SaveData(cmdList);
            }
            catch
            {
                ViewData["Message"] = "Your transaction has been failed, please try again later.";
                return View("Message");
            }
            return View(model);
        }

        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult PaymentVerificationQueryReferral(int AppId)
        {
            try
            {
                if (!Request.IsSecureConnection)
                {
                    Response.Redirect("https://" + Request.ServerVariables["HTTP_HOST"] + Request.RawUrl);
                }

                GetData data = new GetData();
                EpayModels model = new EpayModels();
                model.ApplicationId = AppId.ToString();
                string AppTableName = string.Empty, AppColumnName = string.Empty, AppValueName = string.Empty;

                string Qry = "select a.applicationid,a.applicationno,b.gatewayreferenceid,a.paymentorderno as merchantorderno from applicationpaymentrequest a left outer join applicationpaymentresponse b on b.paymentid=a.paymentid where a.applicationid=@applicationid  order by a.paymentid desc limit 1";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@applicationid", model.ApplicationId);
                model.ApplicationPaymentResponse = ApplicationPaymentResponse.Get<ApplicationPaymentResponse>(new ApplicationPaymentResponse(), Cmd);

                if (!string.IsNullOrEmpty(model.ApplicationPaymentResponse.ApplicationId)) { AppTableName = "web.applicationdetails"; AppColumnName = "applicationid"; AppValueName = model.ApplicationPaymentResponse.ApplicationId; } else if (!string.IsNullOrEmpty(model.ApplicationPaymentResponse.ApplicationNo)) { AppTableName = "dbo.applicationdetails"; AppColumnName = "applicationno"; AppValueName = model.ApplicationPaymentResponse.ApplicationNo; }
                model.ServiceCode = Utility.SelectColumnsValue(AppTableName, "servicecode", AppColumnName, AppValueName)[0];
                model.PaymentGatewayParameter = Utility.GetSbiEpayParameterValue(model.ServiceCode);

                model.ReferralValue = Utility.EncryptSbiEpayQueryRequest(model.ApplicationPaymentResponse, model.PaymentGatewayParameter);
                model.ReferralUrl = model.PaymentGatewayParameter.VerifyPostUrl;
                model.MerchantId = model.PaymentGatewayParameter.MerchantId;

                PreserveModelState(KeyName._Key01, model.ServiceCode, false, true);
                PreserveModelState(KeyName._Key02, model.ApplicationPaymentResponse.MerchantOrderNo, false, true);

                return View(model);
            }
            catch
            {
                ViewData["Message"] = "Your transaction has been failed, please try again later.";
                return View("Message");
            }
        }
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult PaymentVerificationQueryResponse(string encStatusData)
        {
            GetData data = new GetData();
            EpayModels model = new EpayModels();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

            try
            {
                if (TempData[KeyName._Key01] == null) { return RedirectToAction("BadRequest", "Error"); }
                model.ServiceCode = TempData[KeyName._Key01].ToString();
                model.IsResponse = true;

                model.PaymentGatewayParameter = Utility.GetSbiEpayParameterValue(model.ServiceCode);
                model.ApplicationPaymentResponse = Utility.DecryptSbiEpayVerificationResponse(encStatusData, model.PaymentGatewayParameter);

                if (model.ApplicationPaymentResponse == null)
                {
                    ViewData["Message"] = "The payment gateway response dpes not verified, please try again later.";
                    return View("Message");
                }

                if (model.ApplicationPaymentResponse.MerchantOrderNo.ToUpper() == CustomText.NA.ToString())
                {
                    if (TempData[KeyName._Key02] == null)
                    {
                        ViewData["Message"] = "The payment gateway response does not verified, please try again later.";
                        return View("Message");
                    }
                    else
                    {
                        model.IsResponse = false;
                        model.ApplicationPaymentResponse.PaymentStatus = CustomText.FAIL.ToString();
                        model.ApplicationPaymentResponse.PaymentStatusId = ((int)ValueId.SbiEpayCancel).ToString();
                        model.ApplicationPaymentResponse.MerchantOrderNo = TempData[KeyName._Key02].ToString();
                    }
                }

                string Qry = "select a.paymentid,a.applicationid,b.servicecode from applicationpaymentrequest a inner join web.applicationdetails b on b.applicationid=a.applicationid where a.paymentorderno=@paymentorderno";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@paymentorderno", model.ApplicationPaymentResponse.MerchantOrderNo);
                DataTable objData = data.GetDataTable(Cmd);
                model.ApplicationPaymentResponse.PaymentId = objData.Rows[0]["paymentid"].ToString();
                model.ApplicationId = objData.Rows[0]["applicationid"].ToString();
                model.ServiceCode = objData.Rows[0]["servicecode"].ToString();

                return View(model);
            }
            catch
            {
                ViewData["Message"] = "Your transaction has been failed, please try again later.";
                return View("Message");
            }
            
        }        
        #endregion


        #region global method current contoller
        public void PreserveModelState(string Key, object obj, bool IsKeep, bool IsRemove)
        {
            if (IsRemove == true) { TempData.Remove(Key); }
            if (obj != null) { TempData[Key] = obj; }
            if (IsKeep == true) { TempData.Keep(Key); }
        }

        #endregion


        #region Billdesk Payment Gateway Module
        //public ActionResult PaymentReferral(string type)
        //{
        //    EpayModels model = new EpayModels();
        //    Random rand = new Random((int)DateTime.Now.Ticks);
        //    string UniqueId = rand.Next(1000000000, 1999999999).ToString();

        //    String Data = String.Empty, Commonkey = String.Empty, HashValue = String.Empty;

        //    if (type == "t")
        //    {
        //        Data = "XNSDLEDTRS|" + UniqueId + "|NA|2.00|XXX|NA|NA|INR|DIRECT|R|xnsdledtrs|NA|NA|F|" + UniqueId + "|9073|1.00|1.00|NA|NA|NA|http://164.100.78.88/Epay/PaymentResponse";
        //        Commonkey = "TXX9vFumIsT65g";
        //        HashValue = Utility.GetHMACSHA256(Data, Commonkey);
        //    }
        //    else
        //    {
        //        Data = "XNSDLEDIST|" + UniqueId + "|NA|2.00|NA|NA|NA|INR|NA|R|xnsdledist|NA|NA|F|" + UniqueId + "|9054|2.00|0.00|NA|NA|NA|http://164.100.78.88/Epay/PaymentResponse";
        //        Commonkey = "5SifGlzT2xaU";
        //        HashValue = Utility.GetHMACSHA256(Data, Commonkey);
        //    }

        //    model.ReferralValue = Data + "|" + HashValue.ToUpper();
        //    ViewBag.UniqueId = UniqueId;
        //    ViewBag.Type = type;
        //    return View(model);
        //}
        //[AcceptVerbs(HttpVerbs.Post)]
        //public ActionResult PaymentResponse(EpayModels model)
        //{
        //    model.PaymentResponseDetails = Utility.GetPaymentResponse(model.msg);
        //    return View(model);
        //}
        //[AcceptVerbs(HttpVerbs.Post)]
        //[ValidateInput(false)]
        //public ActionResult CinQueryResponse()
        //{
        //    string XmlResponse = string.Empty;
        //    try
        //    {
        //        string XmlString = string.Empty;
        //        string Commonkey = "8dJD5CeMrPLx";

        //        if (Request.InputStream != null)
        //        {
        //            StreamReader RequestStream = new StreamReader(Request.InputStream);
        //            string RequestString = RequestStream.ReadToEnd();
        //            XmlString = HttpUtility.UrlDecode(RequestString);
        //        }
        //        string TempResponse = Utility.GetSeperatedStringFromXML(XmlString, "CINQueryRequest");

        //        int position = TempResponse.LastIndexOf('|');
        //        string RawStringWithOutCheckSum = TempResponse.Substring(0, position);
        //        string GetChecksumFromRequest = TempResponse.Substring(position + 1, TempResponse.Length - position - 1);
        //        string GenerateChecksumFromRequest = Utility.GetHMACSHA256(RawStringWithOutCheckSum, Commonkey);

        //        if (!GetChecksumFromRequest.ToUpper().Equals(GenerateChecksumFromRequest.ToUpper()))
        //        {
        //            XmlResponse = @"<?xml version='1.0' encoding='UTF-8'?><CINQueryResposne><ResponseCode>1001</ResponseCode></CINQueryResposne>";
        //        }
        //        else
        //        {
        //            string[] arrResponse = TempResponse.Split('|');
        //            if (arrResponse[0] == "0700" && arrResponse[1] == "XNSDLEDTRS")
        //            {
        //                string CurrentDate = DateTime.Now.ToString("yyyyMMddHHmmss");

        //                string XmlResponseForChecksum = @"<?xml version='1.0' encoding='UTF-8'?><CINQueryResposne><RequestType>0710</RequestType><MerchantID>" + arrResponse[1] + @"</MerchantID><TxnReferenceNo>" + arrResponse[4] + @"</TxnReferenceNo><CINGenerate>YES</CINGenerate><CurrentDateTime>" + CurrentDate + @"</CurrentDateTime></CINQueryResposne>";
        //                string Checksum = Utility.GetHMACSHA256(Utility.GetSeperatedStringFromXML(XmlResponseForChecksum, "CINQueryResposne"), Commonkey);
        //                XmlResponse = @"<?xml version='1.0' encoding='UTF-8'?><CINQueryResposne><RequestType>0710</RequestType><MerchantID>" + arrResponse[1] + @"</MerchantID><TxnReferenceNo>" + arrResponse[4] + @"</TxnReferenceNo><CINGenerate>YES</CINGenerate><CurrentDateTime>" + CurrentDate + @"</CurrentDateTime><Checksum>" + Checksum.ToUpper() + @"</Checksum></CINQueryResposne>";
        //            }
        //            else
        //            {
        //                XmlResponse = @"<?xml version='1.0' encoding='UTF-8'?><CINQueryResposne><ResponseCode>1002</ResponseCode></CINQueryResposne>";
        //            }
        //        }
        //        return this.Content(XmlResponse, "text/xml");
        //    }
        //    catch
        //    {
        //        XmlResponse = @"<?xml version='1.0' encoding='UTF-8'?><CINQueryResposne><ResponseCode>1003</ResponseCode></CINQueryResposne>";
        //        return this.Content(XmlResponse, "text/xml");
        //    }
        //}
        #endregion
    }
}
