﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Edistrict.Models.DataService;
using System.Data.SqlClient;
using Edistrict.Models;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.Entities;
using System.Web.UI;
using Npgsql;
using System.Collections;
using ReportManagement;
using Edistrict.Models.CustomClass;
using System.Data;

namespace Edistrict.Controllers
{
    [Authorize(Roles = "103")]
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class TehsildarController : Controller
    {
        #region Pull application from verifier
        [EncryptedActionParameter]
        public ActionResult UnderVerification(int? service)
        {
            GetData data = new GetData();
            TehsildarModels model = new TehsildarModels();
            string q = string.Empty, Qry = string.Empty;
            if (!string.IsNullOrEmpty(service.ToString())) { q = " and AD.ServiceCode=@ServiceCode"; } else { q = " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept007).ToString() || Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept016).ToString())
            {
                Qry = "select UM.Username,AD.ApplicationNo,SM.ServiceCode,AD.ApplicantName,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,AD.ApplicantDob,AD.ApplicationStatusId,AD.ApplicationDate,SM.ServiceName,ST.StatusName,DM.DistrictName,SDM.SubDivDescription,date_part('day',(now()-AD.LastActionDate)) as PendingDays FROM dbo.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.SubDivMaster SDM on SDM.SubDivCode=AD.ApplicantSubDivCode inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicantDistrictCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId left outer join dgen.lbrliftinspectionmaster VA on VA.ApplicationNo=AD.ApplicationNo and VA.WhetherActive=@WhetherActive left outer join UserMaster UM on VA.InspectedBy=UM.uid where DM.deptcode=@ParamDeptCode and AD.ApplicationStatusId in (@VERSENT,@INSPEND) and AD.ApplicationSubDivCode in (@ParamSubDivCode)" + q;
            }
            else
            {
                Qry = "select UM.Username,AD.ApplicationNo,SM.ServiceCode,AD.ApplicantName,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,AD.ApplicantDob,AD.ApplicationStatusId,AD.ApplicationDate,SM.ServiceName,ST.StatusName,DM.DistrictName,SDM.SubDivDescription,date_part('day',(now()-AD.LastActionDate)) as PendingDays FROM dbo.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.SubDivMaster SDM on SDM.SubDivCode=AD.ApplicantSubDivCode inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicantDistrictCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId left outer join VerifierApplicationDetails VA on VA.ApplicationNo=AD.ApplicationNo left outer join UserMaster UM on VA.SentTo=UM.uid where DM.deptcode=@ParamDeptCode and AD.ApplicationStatusId in (@VERSENT,@VERLGAZ,@VERLOTHS) and AD.ApplicationSubDivCode in (@ParamSubDivCode)" + q;
            }
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            if (!string.IsNullOrEmpty(service.ToString())) { Cmd.Parameters.AddWithValue("@ServiceCode", service); }
            Cmd.Parameters.AddWithValue("@VERLGAZ", (int)Status.VERLGAZ);
            Cmd.Parameters.AddWithValue("@VERLOTHS", (int)Status.VERLOTHS);
            Cmd.Parameters.AddWithValue("@VERSENT", (int)Status.VERSENT);
            Cmd.Parameters.AddWithValue("@INSPEND", (int)Status.INSPEND);
            Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
            model.data = data.GetDataTable(Cmd);
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PullApplicationFromVerifier(TehsildarModels model)
        {
            string Qry = string.Empty;
            GetData data = new GetData();
            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationNo, DB.LS.ToString());
            if (Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept007).ToString() || Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept016).ToString())
            {
                Qry = "select ApplicationNo from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ApplicationStatusId in (@VERSENT,@INSPEND)";
            }
            else
            {
                Qry = "select ApplicationNo from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ApplicationStatusId in (@VERLGAZ,@VERLOTHS,@VERSENT)";
            }
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            Cmd.Parameters.AddWithValue("@VERLGAZ", (int)Status.VERLGAZ);
            Cmd.Parameters.AddWithValue("@VERLOTHS", (int)Status.VERLOTHS);
            Cmd.Parameters.AddWithValue("@VERSENT", (int)Status.VERSENT);
            Cmd.Parameters.AddWithValue("@INSPEND", (int)Status.INSPEND);
            string ApplicationNo = data.SelectColumns(Cmd)[0];
            if (string.IsNullOrEmpty(ApplicationNo))
            {
                PreserveModelState(Constant._ActionMessage, "Application not avialable for pulling from verifier.!!!", false, true);
                return RedirectToAction("UnderVerification", "Tehsildar");
            }
            else
            {
                PreserveModelState(Constant._ModelStateParent, model, false, true);
                return View(model);
            }
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PullApplicationFromVerifierPost(TehsildarModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                if (!Utility.CheckCurrentStatusBeforeUpdate(model.ApplicationNo, (int)Status.TEHSPEN, (int)CountList.Type001))
                {
                    ViewData["message"] = "Application is not pending at this level anymore!";
                    return View("message");
                }
                string SCode = Utility.SelectColumnsValue("applicationdetails", "servicecode", "applicationno", model.ApplicationNo)[0];

                string Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,applicationremarks=@applicationremarks,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSPEN);
                Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationNo, (int)Status.TEHSPEN, (int)CountList.Type001, DB.LS.ToString()));
                Cmd.Parameters.AddWithValue("@applicationremarks", model.ApplicationRemarks);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSPEN);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationRemarks);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                if (SCode == ((int)ServiceList.InstallationOfLift).ToString() || SCode == ((int)ServiceList.GrantOfPassengerLift).ToString() || SCode == ((int)ServiceList.RenewalOfPassengerLift).ToString())
                {
                    Qry = "update dgen.lbrliftinspectionmaster set Remarks=@Remarks,whetherinspected=@whetherinspected,inspectedon=now(),userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo and whetheractive=@whetheractive;";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@whetherinspected", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@Remarks", "[APPLICATION PULLED BACK] " + model.ApplicationRemarks);
                    Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                }
                else
                {
                    Qry = "update dbo.applicationverificationletterdetails set totalverificationdays=(to_char(now(),'YYYYMMDD')::date-to_char(generatedate,'YYYYMMDD')::date),whetherapplicationpulled=@whetherapplicationpulled,pulleddate=now(),pulledby=@pulledby,pulledipaddress=@pulledipaddress where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@whetherapplicationpulled", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@pulledby", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@pulledipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                }

                cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG024, model.ApplicationRemarks, (int)ApplicationSource.Window, null));

                data.SaveData(cmdList);

                PreserveModelState(Constant._ActionMessage, "Application has been pulled from verification and pending fro decision.!!!", false, true);
                return RedirectToAction("UnderVerification");
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PullApplicationFromVerifier", (TehsildarModels)TempData[Constant._ModelStateParent]);
        }
        #endregion

        #region action methods for assign new verifier
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult AssigntoVerifier()
        {
            GetData data = new GetData();
            TehsildarModels model = new TehsildarModels();
            string Qry = "select AD.ApplicationNo,SM.ServiceCode,AD.ApplicantName,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,AD.ApplicantDob,AD.ApplicationStatusId,AD.ApplicationDate,SM.ServiceName,ST.StatusName,UM.Username as Sentby,UM1.Username as Sentto FROM dbo.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.SubDivMaster SDM on SDM.SubDivCode=AD.ApplicantSubDivCode inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicantDistrictCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.verifierapplicationdetails VA on VA.Applicationno=AD.Applicationno  inner join dbo.usermaster UM on UM.uid=VA.sentby inner join dbo.usermaster UM1 on UM1.uid=VA.sentto where AD.ApplicationStatusId=@VERSENT and DM.deptcode=@ParamDeptCode and AD.ApplicationSubDivCode in (@ParamSubDivCode) and AD.ServiceCode in (@ParamServiceCode) and VA.whetherverified=@whetherverified";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@VERSENT", (int)Status.VERSENT);
            Cmd.Parameters.AddWithValue("@whetherverified", CustomText.False.ToString());
            model.data = data.GetDataTable(Cmd);

            Qry = "select UM.UID,UM.UserName from UserMaster UM inner join UserToSubDivMaster SDM on SDM.Uid=UM.Uid where UM.DistrictCode=@DistrictCode and SDM.SubDivCode in (@ParamSubDivCode) and UM.Permission=@Permission";
            Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@DistrictCode", Sessions.getEmployeeUser().DistrictCode);
            Cmd.Parameters.AddWithValue("@Permission", Convert.ToString((int)Permission.VERF));
            model.VerifierMaster = new SelectList(UserMaster.List<UserMaster>(Cmd), "UID", "UserName");

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult AssigntoVerifierPost(TehsildarModels model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                ArrayList Values = new ArrayList();
                data = new GetData();
                string Qry = "Select ('chkbox' || cast(ApplicationNo as varchar)) as CheckboxValue from dbo.ApplicationDetails where ApplicationStatusid=@VERSENT and ApplicationSubDivCode in (@ParamSubDivCode) and ServiceCode in (@ParamServiceCode)";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@VERSENT", (int)Status.VERSENT);

                DataTable dta = data.GetDataTable(Cmd);
                for (int i = 0; i < dta.Rows.Count; i++)
                {
                    if (frm[dta.Rows[i]["CheckboxValue"].ToString()] != null)
                    {
                        Values.Add(frm[dta.Rows[i]["CheckboxValue"].ToString()]);
                    }
                    if (Values == null)
                    {
                        return View(model);
                    }
                }
                for (int i = 0; i < Values.Count; i++)
                {
                    string UID = string.Empty;
                    UID = Utility.SelectColumnsValue("dbo.usermaster", "uid", "userid", Sessions.getEmployeeUser().UserId)[0];

                    Qry = "update dbo.VerifierApplicationDetails set sentby=@sentby,sentto=@sentto,sentbyremarks=@sentbyremarks where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                    Cmd.Parameters.AddWithValue("@sentby", UID);
                    Cmd.Parameters.AddWithValue("@sentto", model.NewVerifierCode);
                    Cmd.Parameters.AddWithValue("@sentbyremarks", model.ApplicationRemarks);
                    cmdList.Add(Cmd);

                    cmdList.Add(Utility.InsertDepartmentAuditTrail((Values[i]).ToString(), (int)ApplicationHistoryMessage.MSG027, model.ApplicationRemarks, (int)ApplicationSource.Window, null));
                }

                data.SaveData(cmdList);
                PreserveModelState(Constant._ModelStateParent, null, false, true);
                ViewData["message"] = "Application has been assigned to new verifier.";
                return View("message");
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("AssigntoVerifier", (TehsildarModels)TempData[Constant._ModelStateParent]);
        }

        #endregion action methods for assign new verifier

        #region Labour Grievances Module
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult PendingFirmGrievances()
        {
            TehsildarModels model = new TehsildarModels();
            GetData data = new GetData();
            string Qry = "select SC.ServiceName,SC.ServiceCode,AD.subdivcode,coalesce(sum(case when StatusId=@Pending then 1 end),0) as Pending  from dgen.LBRGrievanceDetails AD left outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.subdivcode in (@ParamSubDivCode) and AD.ServiceCode in (@ParamServiceCode) group by AD.subdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@Pending", (int)LBRStatus.SendForApproval);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult PendingFirmGrievancesList(int ServiceCode, int StatusId)
        {
            TehsildarModels model = new TehsildarModels();
            GetData data = new GetData();
            string Qry = "select AD.ServiceCode,AD.GrievanceId,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,(houseno||' '||LM.LocalityName||' '||SD.subdivdescription||' '||DM.districtname) as ApplicantAddress,AD.ApplicantDob,AD.StatusId from dgen.LBRGrievanceDetails AD inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode inner join localitymaster LM on LM.localityId=AD.localityid inner join districtmaster DM on DM.districtcode=AD.districtcode inner join subdivmaster SD on SD.subdivcode=AD.subdivcode where AD.ServiceCode=@ServiceCode and AD.subdivcode in (@ParamSubDivCode) and AD.StatusId=@StatusId order by AD.actiondatetime";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@StatusId", StatusId);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult PendingGrievanceInspectionDetails(int GId, int StatusId)
        {
            TehsildarModels model = new TehsildarModels();
            GetData data = new GetData();
            model.LBRGrievanceDetails = new LBRGrievanceDetails();
            model.LBRGrievanceDetails = Utility.GetGrievanceDetails(GId);
            model.LBRGrievanceDetails.InspectionId = Utility.SelectColumnsValue("dgen.lbrinspectionmaster", "InspectionId", "GrievanceId", GId.ToString())[0];
            string Qry = "select ControlTypeId,WhetherCountRequired,WhetherPrimaryCount,ColumnName,ID.ColumnValue,SC.ServiceName from dgen.LBRinspectioncolumnmaster IC left outer join dgen.LBRInspectionDetails ID on ID.columnid=IC.columnid  and ID.InspectionId=@InspectionId inner join ServiceMaster SC on SC.ServiceCode=IC.ServiceCode where IC.ServiceCode=@ServiceCode order by ColumnOrder";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ServiceCode", model.LBRGrievanceDetails.ServiceCode);
            cmd.Parameters.AddWithValue("@InspectionId", model.LBRGrievanceDetails.InspectionId);
            model.LBRGrievanceDetails.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingGrievanceInspectionDetails(TehsildarModels model)
        {
            GetData data = new GetData();
            string Qry = string.Empty; NpgsqlCommand cmd = null;
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

            Qry = "update dgen.lbrinspectionmaster set observationremarks=@observationremarks,observationby=@observationby,observationdate=now() where InspectionId=@InspectionId";
            cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@InspectionId", model.LBRGrievanceDetails.InspectionId);
            cmd.Parameters.AddWithValue("@observationremarks", model.LBRGrievanceDetails.Observation);
            cmd.Parameters.AddWithValue("@observationby", Sessions.getEmployeeUser().UserId);
            cmdList.Add(cmd);

            Qry = "update dgen.LBRGrievanceDetails set StatusId=@StatusId where GrievanceId=@GrievanceId";
            cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@GrievanceId", model.LBRGrievanceDetails.GrievanceId);
            cmd.Parameters.AddWithValue("@StatusId", (int)LBRStatus.InProcess);
            cmdList.Add(cmd);

            data.SaveData(cmdList);

            return RedirectToAction("PendingFirmGrievances", "Tehsildar");
        }
        #endregion

        #region Land Status (NOC)
        [EncryptedActionParameter]
        public ActionResult NOCAcquisitionProcess(string strVRKIReq)
        {
            GetData data = new GetData();
            string Qry = string.Empty; NpgsqlCommand Cmd = null;
            TehsildarModels model = new TehsildarModels();
            model.NOCAcquisitionDetails = new NOCAcquisitionDetails();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            if (string.IsNullOrEmpty(strVRKIReq)) { return View(model); }
            string[] arr = strVRKIReq.Split('|');
            model.NOCAcquisitionDetails.VillageId = arr[0];
            model.NOCAcquisitionDetails.RectangleNo = arr[1];
            model.NOCAcquisitionDetails.KhasraNo = arr[2];
            model.NOCAcquisitionDetails.AcquisitionId = arr[3];
            model.NOCAcquisitionDetails.RType = arr[4];

            Qry = "select AcquisitionId,VM.villagename,khasrano,rectangleno,Bigha,Biswa,Biswansi,Min,acquisitionno,SV1.valuename as Acquisitiontype,to_char(Acquisitiondate,'DD/MM/YYYY') as Acquisitiondate,to_char(Acquisitionapprovaldate,'DD/MM/YYYY') as Acquisitionapprovaldate,Acquisitionremarks,AQ.whetheractive from dgen.nocacquisitionmaster AQ inner join villagemaster VM on VM.villageid=AQ.VillageId inner join selectmastervaluedetails SV1 on SV1.valueid=AQ.AcquisitiontypeId  where AQ.VillageId=@VillageId and AQ.RectangleNo=@RectangleNo and AQ.KhasraNo=@KhasraNo";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@VillageId", model.NOCAcquisitionDetails.VillageId);
            Cmd.Parameters.AddWithValue("@RectangleNo", model.NOCAcquisitionDetails.RectangleNo);
            Cmd.Parameters.AddWithValue("@KhasraNo", model.NOCAcquisitionDetails.KhasraNo);
            model.data = data.GetDataTable(Cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult NOCAcquisitionProcess(TehsildarModels model)
        {
            if (ModelState.IsValid)
            {

                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Qry = string.Empty, QueryString = string.Empty; NpgsqlCommand Cmd = null;
                if (string.IsNullOrEmpty(model.NOCAcquisitionDetails.RType))
                {
                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "strVRKIReq" }, new ArrayList() { model.NOCAcquisitionDetails.VillageId + "|" + model.NOCAcquisitionDetails.RectangleNo + "|" + model.NOCAcquisitionDetails.KhasraNo + "|" + model.NOCAcquisitionDetails.AcquisitionId + "|" + model.NOCAcquisitionDetails.RType });
                    return RedirectToAction("NOCAcquisitionProcess", "Tehsildar", new { q = QueryString });
                }
                else
                {
                    if (model.NOCAcquisitionDetails.RType == ((int)CountList.Type000).ToString())
                    {
                        Qry = "update dgen.nocAcquisitionmaster set WhetherActive=@WhetherActive,UserId=@UserId,Ipaddress=@Ipaddress,LastActionDate=now() where AcquisitionId=@AcquisitionId";
                    }
                    else if (model.NOCAcquisitionDetails.RType == ((int)CountList.Type001).ToString())
                    {
                        Qry = "update dgen.nocAcquisitionmaster set acquisitionapprovaldate=now(),WhetherActive=@WhetherActive,UserId=@UserId,Ipaddress=@Ipaddress,LastActionDate=now() where AcquisitionId=@AcquisitionId";
                    }
                }
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@AcquisitionId", model.NOCAcquisitionDetails.AcquisitionId);
                if (model.NOCAcquisitionDetails.RType == ((int)CountList.Type000).ToString())
                {
                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.FALSE.ToString());
                }
                else if (model.NOCAcquisitionDetails.RType == ((int)CountList.Type001).ToString())
                {
                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                }
                Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);
                data.SaveData(cmdList);

                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "strVRKIReq" }, new ArrayList() { model.NOCAcquisitionDetails.VillageId + "|" + model.NOCAcquisitionDetails.RectangleNo + "|" + model.NOCAcquisitionDetails.KhasraNo + "|" + model.NOCAcquisitionDetails.AcquisitionId + "|" + model.NOCAcquisitionDetails.RType });
                return RedirectToAction("NOCAcquisitionProcess", "Tehsildar", new { q = QueryString });
            }
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult NOCViolationProcess(string strVRKIReq)
        {
            GetData data = new GetData();
            string Qry = string.Empty; NpgsqlCommand Cmd = null;
            TehsildarModels model = new TehsildarModels();
            model.NOCViolationDetails = new NOCViolationDetails();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            if (string.IsNullOrEmpty(strVRKIReq)) { return View(model); }
            string[] arr = strVRKIReq.Split('|');
            model.NOCViolationDetails.VillageId = arr[0];
            model.NOCViolationDetails.RectangleNo = arr[1];
            model.NOCViolationDetails.KhasraNo = arr[2];
            model.NOCViolationDetails.ViolationId = arr[3];
            model.NOCViolationDetails.RType = arr[4];

            Qry = "select V.WhetherDeViolate,V.ViolationId,VM.villagename,LM.localityname,V.khasrano,V.rectangleno,SV1.valuename as act,SV2.valuename as land,SV3.valuename as section,to_char(V.vdate,'DD/MM/YYYY') as vdate,v.remarks,v.whetheractive from dgen.nocviolationmaster V inner join villagemaster VM on VM.villageid=V.VillageId left outer join localitymaster LM on LM.localityId=V.localityId inner join selectmastervaluedetails SV1 on SV1.valueid=V.violationactid inner join selectmastervaluedetails SV2 on SV2.valueid=V.landid inner join selectmastervaluedetails SV3 on SV3.valueid=V.sectionid   where V.VillageId=@VillageId and V.RectangleNo=@RectangleNo and V.KhasraNo=@KhasraNo";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@VillageId", model.NOCViolationDetails.VillageId);
            Cmd.Parameters.AddWithValue("@RectangleNo", model.NOCViolationDetails.RectangleNo);
            Cmd.Parameters.AddWithValue("@KhasraNo", model.NOCViolationDetails.KhasraNo);
            model.data = data.GetDataTable(Cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult NOCViolationProcess(TehsildarModels model)
        {
            if (ModelState.IsValid)
            {

                GetData data = new GetData();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Qry = string.Empty, QueryString = string.Empty; NpgsqlCommand Cmd = null;
                if (string.IsNullOrEmpty(model.NOCViolationDetails.RType))
                {
                    QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "strVRKIReq" }, new ArrayList() { model.NOCViolationDetails.VillageId + "|" + model.NOCViolationDetails.RectangleNo + "|" + model.NOCViolationDetails.KhasraNo + "|" + model.NOCViolationDetails.ViolationId + "|" + model.NOCViolationDetails.RType });
                    return RedirectToAction("NOCViolationProcess", "Tehsildar", new { q = QueryString });
                }
                else
                {
                    if (model.NOCViolationDetails.RType == ((int)CountList.Type000).ToString())
                    {
                        Qry = "update dgen.nocviolationmaster set WhetherActive=@WhetherActive,UserId=@UserId,Ipaddress=@Ipaddress,LastActionDate=now() where ViolationId=@ViolationId";
                    }
                    else if (model.NOCViolationDetails.RType == ((int)CountList.Type001).ToString())
                    {
                        Qry = "update dgen.nocviolationmaster set approvaldate=now(),WhetherActive=@WhetherActive,UserId=@UserId,Ipaddress=@Ipaddress,LastActionDate=now() where ViolationId=@ViolationId";
                    }
                    else if (model.NOCViolationDetails.RType == ((int)CountList.Type002).ToString())
                    {
                        Qry = "update dgen.nocviolationmaster set WhetherDeViolate=@WhetherDeViolate,UserId=@UserId,Ipaddress=@Ipaddress,LastActionDate=now() where ViolationId=@ViolationId";
                    }
                }
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ViolationId", model.NOCViolationDetails.ViolationId);
                if (model.NOCViolationDetails.RType == ((int)CountList.Type000).ToString())
                {
                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.FALSE.ToString());
                }
                else if (model.NOCViolationDetails.RType == ((int)CountList.Type001).ToString())
                {
                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                }
                else if (model.NOCViolationDetails.RType == ((int)CountList.Type002).ToString())
                {
                    Cmd.Parameters.AddWithValue("@WhetherDeViolate", CustomText.TRUE.ToString());
                }
                Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);
                data.SaveData(cmdList);

                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "strVRKIReq" }, new ArrayList() { model.NOCViolationDetails.VillageId + "|" + model.NOCViolationDetails.RectangleNo + "|" + model.NOCViolationDetails.KhasraNo + "|" + model.NOCViolationDetails.ViolationId + "|" + model.NOCViolationDetails.RType });
                return RedirectToAction("NOCViolationProcess", "Tehsildar", new { q = QueryString });
            }
            return View(model);
        }
        #endregion

        #region global method current contoller
        //method for preserve nodel state
        public void PreserveModelState(string Key, object obj, bool IsKeep, bool IsRemove)
        {
            if (IsRemove == true) { TempData.Remove(Key); }
            if (obj != null) { TempData[Key] = obj; }
            if (IsKeep == true) { TempData.Keep(Key); }
        }
        #endregion global method current contoller
    }
}
