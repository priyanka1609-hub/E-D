﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using Edistrict.Models;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.DataService;
using Edistrict.Models.Entities;
using Npgsql;
using System.Collections;
using System.Web.UI;
using Edistrict.Models.CustomClass;
using System.Web;
using System.Data;
using System.Web.Security;

namespace Edistrict.Controllers
{
    [Authorize]
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class ProcessController : Controller
    {
        #region CDV Training Session
        [Authorize(Roles = "112")]
        [EncryptedActionParameter]
        public ActionResult PendingForTrainingSummary()
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            string Qry = @"select AD.ApplicationDistrictCode,DistrictName,count(AD.ApplicationNo) TotalReceived,(select count(AADCDV.ApplicationNo) from dgen.ApplicationDetailsCDV AADCDV inner join ApplicationDetails AAD on AAD.ApplicationNo=AADCDV.ApplicationNo where AAD.ApplicationStatusId=@ApplicationStatusId and WhetherBasicTrainingComplete=false and  ApplicationDistrictCode=@ParamDistrictCode  and AADCDV.applicationno not in(select applicationno from dgen.CDVApplicantTrainingDetails where TrainingTypeId=@TrainingTypeId)) as TotalPendingAllocation,coalesce(sum(case when VenueId is not null and WhetherTrainingCompleted=False and TrainingTypeId=@TrainingTypeId then 1 end),0)as TrainingUnderProcess,coalesce(sum(case when WhetherBasicTrainingComplete=True then 1 end),0)as TrainingCompleted  from ApplicationDetails AD  right outer join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode  inner join dgen.ApplicationDetailsCDV ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo left outer join dgen.CDVApplicantTrainingDetails CDVTS on CDVTS.ApplicationNo=AD.ApplicationNo and TrainingTypeId=@TrainingTypeId  where DM.deptcode=@ParamDeptCode and ApplicationStatusId=@ApplicationStatusId";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            Qry += " group by DistrictName,AD.ApplicationDistrictCode";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TrainingTypeId", (int)ValueId.BasicTraining);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [Authorize(Roles = "112")]
        [EncryptedActionParameter]
        public ActionResult PendingForTrainingList(int Flag)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            model.CDVApplicantTrainingDetails = new CDVApplicantTrainingDetails();
            model.CDVApplicantTrainingDetails.TrainingTypeId = Convert.ToString((int)ValueId.BasicTraining);
            model.Flag = Convert.ToString(Flag);
            string whethercondition = string.Empty;

            if (Flag == 1)
            {
                whethercondition = whethercondition + " and ADCDV.applicationno not in(select applicationno from dgen.CDVApplicantTrainingDetails where TrainingTypeId=@TrainingTypeId) ";
            }
            if (Flag == 2)
            {
                whethercondition = whethercondition + " and ADCDV.applicationno in(select applicationno from dgen.CDVApplicantTrainingDetails where TrainingTypeId=@TrainingTypeId and WhetherTrainingCompleted=False)";
            }
            string Qry = "select ADCDV.ApplicationNo,EnrollmentNo,to_char(EnrollmentDate,'DD/MM/YYYY') as EnrollDate,ApplicantName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress,StatusName from ApplicationDetails AD inner join dgen.ApplicationDetailsCDV ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo Inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode Inner join dbo.StatusMaster SM on SM.StatusId=AD.ApplicationStatusId  where DM.deptcode=@ParamDeptCode and ApplicationStatusId=@ApplicationStatusId and whetherbasictrainingcomplete=@whetherbasictrainingcomplete" + whethercondition + "";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }

            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            Qry += " order by EnrollmentNo";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@TrainingTypeId", (int)ValueId.BasicTraining);
            if (Flag == 3)
            {
                cmd.Parameters.AddWithValue("@whetherbasictrainingcomplete", CustomText.TRUE.ToString());
            }
            else
            {
                cmd.Parameters.AddWithValue("@whetherbasictrainingcomplete", CustomText.False.ToString());
            }
            model.data = data.GetDataTable(cmd);

            return View(model);
        }
        [Authorize(Roles = "112")]
        [EncryptedActionParameter]
        public ActionResult MarkTrainingAllocation(int? Flag)
        {
            ProcessModels model = new ProcessModels();
            model.CDVApplicantTrainingDetails = new CDVApplicantTrainingDetails();
            try { if (!string.IsNullOrEmpty(Flag.ToString())) { model.Flag = Flag.ToString(); } }
            catch { model.Flag = null; }
            string Qry = "select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid";
            if (!string.IsNullOrEmpty(model.Flag))
            {
                Qry = Qry + " and  SMVTD.valueid=@valueid";
            }
            else
            {
                Qry = Qry + " and  SMVTD.valueid<>@valueid";
            }
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@valueid", (int)ValueId.BasicTraining);
            Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CDVTrainingType);
            List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
            model.CDVApplicantTrainingDetails.TrainingTypeList = new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");

            return View(model);
        }
        [Authorize(Roles = "112")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult TrainingAllocation(ProcessModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string Qry = "select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid and  SMVTD.valueid=@valueid";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@valueid", model.CDVApplicantTrainingDetails.TrainingTypeId);
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CDVTrainingType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                model.CDVApplicantTrainingDetails.TrainingTypeList = new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");

                Qry = @"Select ADCDV.ApplicationNo,EnrollmentNo,to_char(EnrollmentDate,'DD/MM/YYYY') as EnrollDate,ApplicantName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress  from  dgen.ApplicationDetailsCDV  ADCDV inner join ApplicationDetails AD on AD.ApplicationNo=ADCDV.ApplicationNo  Inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode where AD.ServiceCode in (@ParamServiceCode)  and ApplicationStatusId=@ApplicationStatusId and ADCDV.whetherbasictrainingcomplete=@whetherbasictrainingcomplete and DM.deptcode=@ParamDeptCode  ";
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
                if (model.Flag == "1")
                {
                    Qry += " and ADCDV.applicationno not in(select applicationno from dgen.CDVApplicantTrainingDetails where TrainingTypeId=@TrainingTypeId)";
                }
                Qry += " order by EnrollmentNo";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                if (model.Flag == "1")
                {
                    cmd.Parameters.AddWithValue("@whetherbasictrainingcomplete", CustomText.FALSE.ToString());
                }
                else
                {
                    cmd.Parameters.AddWithValue("@whetherbasictrainingcomplete", CustomText.TRUE.ToString());
                }
                cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@TrainingTypeId", (int)ValueId.BasicTraining);
                model.data = data.GetDataTable(cmd);
                if (model.CDVApplicantTrainingDetails.TrainingPeriodId.ToUpper() == CustomText.TRUE.ToString())
                {
                    DateTime date = Convert.ToDateTime(model.CDVApplicantTrainingDetails.TrainingFrom);
                    DateTime EndDate = date.AddDays(7);

                    string[] GetDetail = Utility.DateHolidayCheck(date.ToString("dd/MM/yyyy"));
                    if (GetDetail[0] == CustomText.FALSE.ToString()) { date = date.AddDays(Convert.ToInt16(GetDetail[1])); EndDate = EndDate.AddDays(Convert.ToInt16(GetDetail[1])); }

                    for (int i = 1; i <= Convert.ToInt32(model.CDVApplicantTrainingDetails.TrainingDuration); i++)
                    {
                        if (i == 1)
                        {
                            ViewData["TrainingDate" + i] = date.ToString("dd/MM/yyyy");
                        }
                        else
                        {
                            if (date <= EndDate)
                            {
                                DateTime Nextdate = date.AddDays(1);
                                GetDetail = Utility.DateHolidayCheck(Nextdate.ToString("dd/MM/yyyy"));
                                if (GetDetail[0] == CustomText.FALSE.ToString()) { ViewData["TrainingDate" + i] = Nextdate.AddDays(Convert.ToInt16(GetDetail[1])).ToString("dd/MM/yyyy"); if (Nextdate != EndDate) { EndDate = EndDate.AddDays(Convert.ToInt16(GetDetail[1])); } date = Nextdate.AddDays(Convert.ToInt16(GetDetail[1])); }
                                else { ViewData["TrainingDate" + i] = date.AddDays(1).ToString("dd/MM/yyyy"); date = date.AddDays(1); }
                            }
                        }
                    }
                }
                else
                {
                    DateTime date = DateTime.Now;
                    while (true) { if (date.ToString("dddd").ToUpper() == "SUNDAY") { break; } date = date.AddDays(1); }
                    while (true) { if (Utility.DateHolidayCheck(date.ToString("dd/MM/yyyy"))[0] == CustomText.TRUE.ToString()) { break; } date = date.AddDays(7); }
                    DateTime EndDate = date.AddDays(56);

                    for (int i = 1; i <= Convert.ToInt32(model.CDVApplicantTrainingDetails.TrainingDuration); i++)
                    {
                        if (i == 1)
                        {
                            ViewData["TrainingDate" + i] = date.ToString("dd/MM/yyyy");
                        }
                        else
                        {
                            if (date <= EndDate)
                            {
                                DateTime Nextdate = date.AddDays(7);
                                string[] GetDetail = Utility.DateHolidayCheck(Nextdate.ToString("dd/MM/yyyy"));
                                if (GetDetail[0] == CustomText.FALSE.ToString()) { ViewData["TrainingDate" + i] = Nextdate.AddDays(7).ToString("dd/MM/yyyy"); if (Nextdate != EndDate) { EndDate = EndDate.AddDays(7); } date = Nextdate.AddDays(7); }
                                else { ViewData["TrainingDate" + i] = date.AddDays(7).ToString("dd/MM/yyyy"); date = date.AddDays(7); }
                            }
                        }
                    }
                }
                return View(model);
            }

            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "Flag" }, new ArrayList() { model.Flag });
            return RedirectToAction("MarkTrainingAllocation", "Process", new { q = QueryString });

        }
        [Authorize(Roles = "112")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingAllocation(ProcessModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                ArrayList ValuesDate = new ArrayList();
                List<CMDInfoList> cmdList = new List<CMDInfoList>();
                CMDInfoList CmdInfo = new CMDInfoList();
                string TrainingStartDate = string.Empty, TrainingEndDate = string.Empty;
                string Message = string.Empty;
                string checkboxvalue = frm["chkboxData"];
                string[] Values = checkboxvalue.Split(',');
                int ParentIndex = 0, ChildIndex = 0;
                for (int i = 0; i <Values.Length; i++)
                {
                    string Qry = "insert into dgen.CDVApplicantTrainingDetails(ApplicationNo,TrainingTypeId,TrainingCourseId,VenueId,TrainingDuration,UserId,IpAddress,ActionDateTime) values(@ApplicationNo,@TrainingTypeId,@TrainingCourseId,@VenuId,@TrainingDuration,@UserId,@IpAddress,now()); SELECT currval(pg_get_serial_sequence('dgen.CDVApplicantTrainingDetails','trainingid'))";
                    NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                    cmd.Parameters.AddWithValue("@TrainingTypeId", model.CDVApplicantTrainingDetails.TrainingTypeId);
                    cmd.Parameters.AddWithValue("@TrainingCourseId", model.CDVApplicantTrainingDetails.TrainingCourseId);
                    cmd.Parameters.AddWithValue("@VenuId", model.CDVApplicantTrainingDetails.VenueId);
                    cmd.Parameters.AddWithValue("@TrainingDuration", model.CDVApplicantTrainingDetails.TrainingDuration);
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    CmdInfo = new CMDInfoList();
                    CmdInfo.Cmd = cmd; CmdInfo.ParamenterIndex = null; CmdInfo.Returns = true;
                    cmdList.Add(CmdInfo);
                    ParentIndex = ParentIndex + ChildIndex;

                    ChildIndex = 1;
                    for (int j = 1; j <= Convert.ToInt16(model.CDVApplicantTrainingDetails.TrainingDuration); j++)
                    {
                        if (frm["TrainingDate" + j] != null)
                        {
                            ViewData["TrainingDate" + j] = frm["TrainingDate" + j].ToString();

                            if (string.IsNullOrEmpty(frm["TrainingDate" + j].ToString()))
                            {
                                PreserveModelState(Constant._ModelStateParent, null, true, false);
                                return View((ProcessModels)TempData[Constant._ModelStateParent]);
                            }
                            Qry = "insert into dgen.CDVAttendanceDetails(TrainingId,TrainingDate,UserId,IpAddress,ActionDateTime) values(@Parameter" + ParentIndex + @",@TrainingDate,@UserId,@IpAddress,now())";
                            cmd = new NpgsqlCommand(Qry);
                            cmd.Parameters.AddWithValue("@TrainingDate", Utility.GetDateYYYYMMDD(frm["TrainingDate" + j].ToString(), '/', "0/1/2"));
                            cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                            cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                            CmdInfo = new CMDInfoList();
                            CmdInfo.Cmd = cmd; CmdInfo.ParamenterIndex = new int[] { ParentIndex }; CmdInfo.Returns = false;
                            cmdList.Add(CmdInfo);

                            ChildIndex++;
                        }
                    }
                }
                if (cmdList.Count > 0)
                {
                    data.SaveTransactionalDataCustom(cmdList);

                    string startdate = string.Empty, enddate = string.Empty, SendMessage = string.Empty; ;
                    for (int i = 0; i < Values.Length; i++)
                    {
                        string mobileno = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ApplicantmobileNo", "ApplicationNO", (Values[i]).ToString())[0];
                        string Qry = "select DistrictName,Venueaddress from venuemaster VM inner join DistrictMaster DM on DM.DistrictCode=VM.DistrictCode where Venueid=@Venueid";
                        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@Venueid", model.CDVApplicantTrainingDetails.VenueId);
                        string[] getValue = data.SelectColumns(Cmd);

                        for (int j = 1; j <= Convert.ToInt16(model.CDVApplicantTrainingDetails.TrainingDuration); j++)
                        {
                            if (j == 1) { startdate = ViewData["TrainingDate" + j].ToString(); }
                            enddate = ViewData["TrainingDate" + j].ToString();

                        }

                        SendMessage = "Regular Basic Training starts on " + startdate + " and ends on " + enddate + " at " + getValue[0] + "," + getValue[1];
                        bool WhetherSend = Utility.IsSmsSent(mobileno, SendMessage);
                        if (WhetherSend)
                        {
                            data.UpdateData((Utility.InsertPushSmsDetails(SendMessage, mobileno, WhetherSend)));
                        }
                    }

                    return RedirectToAction("PendingForTrainingSummary", "Process");
                }
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("TrainingAllocation", (ProcessModels)TempData[Constant._ModelStateParent]);
        }


        [Authorize(Roles = "112")]
        [EncryptedActionParameter]
        public ActionResult MissedTrainingList()
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            model.CDVApplicantTrainingDetails = new CDVApplicantTrainingDetails();
            string whethercondition = string.Empty;
            string Qry = "select ADCDV.ApplicationNo,EnrollmentNo,to_char(EnrollmentDate,'DD/MM/YYYY') as EnrollDate,ApplicantName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress,StatusName,(TrainingDays-coalesce(sum(case when whetherPresent=@whetherPresent1 then 1 end),0)) as TrainingMissed,TrainingTypeId,ValueName as TrainingType,CDVTS.TrainingId,CourseId from ApplicationDetails AD inner join dgen.ApplicationDetailsCDV ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo Inner join dgen.CDVApplicantTrainingDetails CDVTS on CDVTS.ApplicationNo=ADCDV.ApplicationNo Inner join dgen.CDVAttendanceDetails CDVAD on CDVAD.TrainingId=CDVTS.TrainingId Inner join CourseMaster CM on CM.CourseId=CDVTS.TrainingCourseId Inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode Inner join dbo.StatusMaster SM on SM.StatusId=AD.ApplicationStatusId Inner join dbo.selectmastervaluedetails SMVD on SMVD.ValueId=CDVTS.TrainingTypeId  where DM.deptcode=@ParamDeptCode and  ApplicationStatusId=@ApplicationStatusId and WhetherTrainingCompleted=False ";
            //string Qry = "select ADCDV.ApplicationNo,ApplicantName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress,StatusName,coalesce(sum(case when whetherPresent=@whetherPresent then 1 end),0) as TrainingMissed,TrainingTypeId,ValueName as TrainingType,CDVTS.TrainingId,CourseId from ApplicationDetails AD inner join dgen.ApplicationDetailsCDV ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo Inner join dgen.CDVApplicantTrainingDetails CDVTS on CDVTS.ApplicationNo=ADCDV.ApplicationNo  Inner join dgen.CDVAttendanceDetails CDVAD on CDVAD.TrainingId=CDVTS.TrainingId Inner join CourseMaster CM on CM.CourseId=CDVTS.TrainingCourseId  Inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode  Inner join dbo.StatusMaster SM on SM.StatusId=AD.ApplicationStatusId Inner join dbo.selectmastervaluedetails SMVD on SMVD.ValueId=CDVTS.TrainingTypeId  where DM.deptcode=@ParamDeptCode and   ApplicationStatusId=@ApplicationStatusId and WhetherTrainingCompleted=False ";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().ServiceCode)) { Qry += " and AD.ServiceCode in (@ParamServiceCode)"; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            Qry += " group by ADCDV.ApplicationNo,ApplicantName,ApplicationStatusId,ApplicantmobileNo,ApplicantDOB,HpermanentAddress,StatusName,TrainingTypeId,ValueName,CDVTS.TrainingId ,CourseId having coalesce(sum(case when whetherPresent=@whetherPresent1 or whetherPresent is null then 1 end),0)<TrainingDays and coalesce(sum(case when whetherPresent is null then 1 end),0)=0  order by EnrollmentNo,CDVTS.TrainingId desc";
            //Qry += " group by ADCDV.ApplicationNo,ApplicantName,ApplicationStatusId,ApplicantmobileNo,ApplicantDOB,HpermanentAddress,StatusName,TrainingTypeId,ValueName,CDVTS.TrainingId ,CourseId  having coalesce(sum(case when whetherPresent=@whetherPresent1 or whetherPresent is null then 1 end),0)<TrainingDays order by CDVTS.TrainingId  desc limit 1 ";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
            //cmd.Parameters.AddWithValue("@whetherPresent", ((int)ValueId.Absent).ToString());
            cmd.Parameters.AddWithValue("@whetherPresent1", ((int)ValueId.Present).ToString());
            model.data = data.GetDataTable(cmd);

            return View(model);
        }
        [Authorize(Roles = "112")]
        [EncryptedActionParameter]
        public ActionResult MarkReAllocateTraining()
        {
            ProcessModels model = new ProcessModels();
            model.CDVApplicantTrainingDetails = new CDVApplicantTrainingDetails();
            string Qry = "select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CDVTrainingType);
            List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
            model.CDVApplicantTrainingDetails.TrainingTypeList = new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");

            return View(model);
        }
        [Authorize(Roles = "112")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ReAllocateTraining(ProcessModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string Qry = "select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid and  SMVTD.valueid=@valueid";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@valueid", model.CDVApplicantTrainingDetails.TrainingTypeId);
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CDVTrainingType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                model.CDVApplicantTrainingDetails.TrainingTypeList = new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
                Qry = "select ADCDV.ApplicationNo,EnrollmentNo,to_char(EnrollmentDate,'DD/MM/YYYY') as EnrollDate,ApplicantName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress,StatusName,(TrainingDays-coalesce(sum(case when whetherPresent=@whetherPresent1 then 1 end),0)) as TrainingMissed,TrainingTypeId,ValueName as TrainingType,CDVTS.TrainingId,CourseId from ApplicationDetails AD inner join dgen.ApplicationDetailsCDV ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo Inner join dgen.CDVApplicantTrainingDetails CDVTS on CDVTS.ApplicationNo=ADCDV.ApplicationNo Inner join dgen.CDVAttendanceDetails CDVAD on CDVAD.TrainingId=CDVTS.TrainingId Inner join CourseMaster CM on CM.CourseId=CDVTS.TrainingCourseId Inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode Inner join dbo.StatusMaster SM on SM.StatusId=AD.ApplicationStatusId Inner join dbo.selectmastervaluedetails SMVD on SMVD.ValueId=CDVTS.TrainingTypeId  where TrainingTypeId=@TrainingTypeId and DM.deptcode=@ParamDeptCode and  ApplicationStatusId=@ApplicationStatusId and WhetherTrainingCompleted=False ";
                //Qry = "select ADCDV.ApplicationNo,ApplicantName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress,StatusName,(TrainingDays-coalesce(sum(case when whetherPresent=@whetherPresent1 then 1 end),0)) as TrainingMissed,TrainingTypeId,ValueName as TrainingType,CDVTS.TrainingId,CourseId  from ApplicationDetails AD inner join dgen.ApplicationDetailsCDV ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo Inner join dgen.CDVApplicantTrainingDetails CDVTS on CDVTS.ApplicationNo=ADCDV.ApplicationNo  Inner join dgen.CDVAttendanceDetails CDVAD on CDVAD.TrainingId=CDVTS.TrainingId Inner join CourseMaster CM on CM.CourseId=CDVTS.TrainingCourseId Inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode  Inner join dbo.StatusMaster SM on SM.StatusId=AD.ApplicationStatusId Inner join dbo.selectmastervaluedetails SMVD on SMVD.ValueId=CDVTS.TrainingTypeId  where TrainingTypeId=@TrainingTypeId and DM.deptcode=@ParamDeptCode and   ApplicationStatusId=@ApplicationStatusId and WhetherTrainingCompleted=False ";
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
                Qry += " group by ADCDV.ApplicationNo,ApplicantName,ApplicationStatusId,ApplicantmobileNo,ApplicantDOB,HpermanentAddress,StatusName,TrainingTypeId,ValueName,CDVTS.TrainingId ,CourseId having(TrainingDays-coalesce(sum(case when whetherPresent=@whetherPresent1 then 1 end),0))=@TrainingDuration and coalesce(sum(case when whetherPresent=@whetherPresent1 or whetherPresent is null then 1 end),0)<TrainingDays and coalesce(sum(case when whetherPresent is null then 1 end),0)=0  order by EnrollmentNo,CDVTS.TrainingId desc";
                //Qry += " group by ADCDV.ApplicationNo,ApplicantName,ApplicationStatusId,ApplicantmobileNo,ApplicantDOB,HpermanentAddress,StatusName,TrainingTypeId,ValueName,CDVTS.TrainingId,CourseId  having coalesce(sum(case when whetherPresent=@WhetherPresent then 1 end),0)=@TrainingDuration and coalesce(sum(case when whetherPresent=@WhetherPresent1 or whetherPresent is null then 1 end),0)<TrainingDays";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                //cmd.Parameters.AddWithValue("@WhetherPresent", ((int)ValueId.Absent).ToString());
                cmd.Parameters.AddWithValue("@WhetherPresent1", ((int)ValueId.Present).ToString());
                cmd.Parameters.AddWithValue("@TrainingTypeId", model.CDVApplicantTrainingDetails.TrainingTypeId);
                cmd.Parameters.AddWithValue("@TrainingDuration", model.CDVApplicantTrainingDetails.TrainingDuration);
                model.data = data.GetDataTable(cmd);
                return View(model);
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("ReAllocateTraining", (ProcessModels)TempData[Constant._ModelStateParent]);

        }
        [Authorize(Roles = "112")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingReAllocation(ProcessModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                ArrayList Values = new ArrayList();
                ArrayList ValuesTraining = new ArrayList();
                string Qry = "select ADCDV.ApplicationNo,('chkbox' || cast(ADCDV.ApplicationNo as varchar)) as CDVApplicationNo,EnrollmentNo,to_char(EnrollmentDate,'DD/MM/YYYY') as EnrollDate,ApplicantName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress,StatusName,(TrainingDays-coalesce(sum(case when whetherPresent=@whetherPresent1 then 1 end),0)) as TrainingMissed,TrainingTypeId,ValueName as TrainingType,CDVTS.TrainingId,CourseId from ApplicationDetails AD inner join dgen.ApplicationDetailsCDV ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo Inner join dgen.CDVApplicantTrainingDetails CDVTS on CDVTS.ApplicationNo=ADCDV.ApplicationNo Inner join dgen.CDVAttendanceDetails CDVAD on CDVAD.TrainingId=CDVTS.TrainingId Inner join CourseMaster CM on CM.CourseId=CDVTS.TrainingCourseId Inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode Inner join dbo.StatusMaster SM on SM.StatusId=AD.ApplicationStatusId Inner join dbo.selectmastervaluedetails SMVD on SMVD.ValueId=CDVTS.TrainingTypeId  where TrainingTypeId=@TrainingTypeId and DM.deptcode=@ParamDeptCode and  ApplicationStatusId=@ApplicationStatusId and WhetherTrainingCompleted=False ";
                //string Qry = "select ADCDV.ApplicationNo,('chkbox' || cast(ADCDV.ApplicationNo as varchar)) as CDVApplicationNo,ApplicantName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress,StatusName,coalesce(sum(case when whetherPresent=@WhetherPresent then 1 end),0) as TrainingMissed,TrainingTypeId,ValueName as TrainingType,CDVTS.TrainingId,CourseId  from ApplicationDetails AD inner join dgen.ApplicationDetailsCDV ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo Inner join dgen.CDVApplicantTrainingDetails CDVTS on CDVTS.ApplicationNo=ADCDV.ApplicationNo  Inner join dgen.CDVAttendanceDetails CDVAD on CDVAD.TrainingId=CDVTS.TrainingId  Inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode  Inner join dbo.StatusMaster SM on SM.StatusId=AD.ApplicationStatusId Inner join dbo.selectmastervaluedetails SMVD on SMVD.ValueId=CDVTS.TrainingTypeId Inner join CourseMaster CM on CM.CourseId=CDVTS.TrainingCourseId  where TrainingTypeId=@TrainingTypeId and DM.deptcode=@ParamDeptCode and   ApplicationStatusId=@ApplicationStatusId and WhetherTrainingCompleted=False ";
                //Qry = "Select ADCDV.ApplicationNo,('chkbox' || cast(ADCDV.ApplicationNo as varchar)) as CDVApplicationNo,ApplicantName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress  from  dgen.ApplicationDetailsCDV  ADCDV inner join ApplicationDetails AD on AD.ApplicationNo=ADCDV.ApplicationNo  Inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode Inner join dbo.StatusMaster SM on SM.StatusId=AD.ApplicationStatusId where ServiceCode=@ServiceCode and ApplicationStatusId=@ApplicationStatusId  and  DM.deptcode=@ParamDeptCode and ADCDV.applicationno in(select applicationno from dgen.CDVApplicantTrainingDetails where TrainingTypeId=@TrainingTypeId and WhetherTrainingCompleted=False and whetherlasttrainingcomplete=true)";
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
                Qry += " group by ADCDV.ApplicationNo,ApplicantName,ApplicationStatusId,ApplicantmobileNo,ApplicantDOB,HpermanentAddress,StatusName,TrainingTypeId,ValueName,CDVTS.TrainingId ,CourseId having(TrainingDays-coalesce(sum(case when whetherPresent=@whetherPresent1 then 1 end),0))=@TrainingDuration and coalesce(sum(case when whetherPresent=@whetherPresent1 or whetherPresent is null then 1 end),0)<TrainingDays and coalesce(sum(case when whetherPresent is null then 1 end),0)=0  order by EnrollmentNo,CDVTS.TrainingId desc";
                //Qry += " group by ADCDV.ApplicationNo,ApplicantName,ApplicationStatusId,ApplicantmobileNo,ApplicantDOB,HpermanentAddress,StatusName,TrainingTypeId,ValueName,CDVTS.TrainingId,CourseId  having coalesce(sum(case when whetherPresent=@WhetherPresent then 1 end),0)=@TrainingDuration and coalesce(sum(case when whetherPresent=@WhetherPresent1 or whetherPresent is null then 1 end),0)<TrainingDays";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.CDVolunteer);
                cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                //cmd.Parameters.AddWithValue("@WhetherPresent", ((int)ValueId.Absent).ToString());
                cmd.Parameters.AddWithValue("@WhetherPresent1", ((int)ValueId.Present).ToString());
                cmd.Parameters.AddWithValue("@TrainingTypeId", model.CDVApplicantTrainingDetails.TrainingTypeId);
                cmd.Parameters.AddWithValue("@TrainingDuration", model.CDVApplicantTrainingDetails.TrainingDuration);
                model.data = data.GetDataTable(cmd);
                for (int i = 0; i < model.data.Rows.Count; i++)
                {
                    if (frm[model.data.Rows[i]["CDVApplicationNo"].ToString()] != null)
                    {
                        Values.Add(frm[model.data.Rows[i]["CDVApplicationNo"].ToString()]);
                        ValuesTraining.Add(model.data.Rows[i]["TrainingId"].ToString());
                    }
                    if (Values == null)
                    {
                        return View(model);
                    }
                }


                for (int i = 0; i < Values.Count; i++)
                {
                    //Qry = "insert into dgen.CDVApplicantTrainingDetails(ApplicationNo,TrainingTypeId,TrainingCourseId,VenueId,TrainingDuration,UserId,IpAddress,ActionDateTime) values(@ApplicationNo,@TrainingTypeId,@TrainingCourseId,@VenuId,@TrainingDuration,@UserId,@IpAddress,now()); SELECT currval(pg_get_serial_sequence('dgen.CDVApplicantTrainingDetails','trainingid'))";
                    //cmd = new NpgsqlCommand(Qry);
                    //cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                    //cmd.Parameters.AddWithValue("@TrainingTypeId", model.CDVApplicantTrainingDetails.TrainingTypeId);
                    //cmd.Parameters.AddWithValue("@TrainingCourseId", model.CDVApplicantTrainingDetails.TrainingCourseId);
                    //cmd.Parameters.AddWithValue("@VenuId", model.CDVApplicantTrainingDetails.VenueId);
                    //cmd.Parameters.AddWithValue("@TrainingDuration", model.CDVApplicantTrainingDetails.TrainingDuration);
                    //cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    //cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    //cmdList.Add(cmd);

                    for (int j = 1; j <= Convert.ToInt16(model.CDVApplicantTrainingDetails.TrainingDuration); j++)
                    {
                        if (frm["TrainingDate" + j] != null)
                        {
                            ViewData["TrainingDate" + j] = frm["TrainingDate" + j].ToString();
                            if (string.IsNullOrEmpty(frm["TrainingDate" + j].ToString()))
                            {
                                PreserveModelState(Constant._ModelStateParent, null, true, false);
                                return View((ProcessModels)TempData[Constant._ModelStateParent]);
                            }
                            Qry = "insert into dgen.CDVAttendanceDetails(TrainingId,TrainingDate,UserId,IpAddress,ActionDateTime) values(@TrainingId,@TrainingDate,@UserId,@IpAddress,now())";
                            cmd = new NpgsqlCommand(Qry);
                            cmd.Parameters.AddWithValue("@TrainingId", (ValuesTraining[i]).ToString());
                            cmd.Parameters.AddWithValue("@TrainingDate", Utility.GetDateYYYYMMDD(frm["TrainingDate" + j].ToString(), '/', "0/1/2"));
                            cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                            cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                            cmdList.Add(cmd);
                        }

                    }

                }
                if (cmdList.Count > 0)
                {
                    data.SaveData(cmdList);
                    return RedirectToAction("PendingForTrainingSummary", "Process");
                }
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("ReAllocateTraining", (ProcessModels)TempData[Constant._ModelStateParent]);

        }


        [Authorize(Roles = "114")]
        public ActionResult AllocateDuty()
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            model.ApplicationDetailsCDV = new ApplicationDetailsCDV();
            model.CDVDutyDetails = new CDVDutyDetails();

            return View(model);
        }
        [Authorize(Roles = "114")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult AllocateDuty(ProcessModels model)
        {
            if (ModelState.IsValid)
            {

                //GetData data = new GetData();
                //string Qry = @"Select ADCDV.ApplicationNo,EnrollmentNo,to_char(EnrollmentDate,'DD/MM/YYYY') as EnrollDate,ApplicantName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress  from  dgen.ApplicationDetailsCDV  ADCDV inner join ApplicationDetails AD on AD.ApplicationNo=ADCDV.ApplicationNo  Inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode left outer join dgen.CDVTechnicalEducationDetail CDVTED on CDVTED.ApplicationNo=ADCDV.ApplicationNo ";
                //if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and TechnicalEducationId=@TechnicalEducationId "; }
                //Qry += " where AD.ServiceCode in (@ParamServiceCode)  and ApplicationStatusId=@ApplicationStatusId  and DM.deptcode=@ParamDeptCode and ADCDV.WhetherBasicTrainingComplete=@WhetherBasicTrainingComplete ";

                //if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
                //if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.EnrollmentNo)) { Qry += " and ADCDV.EnrollmentNo=@EnrollmentNo"; }
                //if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.SEqualificationId)) { Qry += " and ADCDV.EqualificationId=@EqualificationId"; }
                //if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.SBloodGroup)) { Qry += " and ADCDV.BloodGroup=@BloodGroup"; }
                //if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.SGender)) { Qry += " and AD.ApplicantGender=@ApplicantGender"; }
                //if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.SOccupationId)) { Qry += " and ADCDV.OccupationId=@OccupationId"; }
                //if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.STqualificationId)) { Qry += " and TechnicalEducationId=@TechnicalEducationId"; }
                //if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.Sheight)) { Qry += " and ADCDV.heightfeet >= @height and heightinch>0"; }
                //if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.SChest)) { Qry += " and ADCDV.chest >@SChest"; }
                //Qry += " order by EnrollmentNo";

                //NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                //cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                //cmd.Parameters.AddWithValue("@WhetherBasicTrainingComplete", CustomText.True.ToString());
                //cmd.Parameters.AddWithValue("@EnrollmentNo", model.ApplicationDetailsCDV.EnrollmentNo);
                //cmd.Parameters.AddWithValue("@EqualificationId", model.ApplicationDetailsCDV.SEqualificationId);
                //cmd.Parameters.AddWithValue("@TechnicalEducationId", model.ApplicationDetailsCDV.STqualificationId);
                //cmd.Parameters.AddWithValue("@BloodGroup", model.ApplicationDetailsCDV.SBloodGroup);
                //cmd.Parameters.AddWithValue("@ApplicantGender", model.ApplicationDetailsCDV.SGender);
                //cmd.Parameters.AddWithValue("@OccupationId", model.ApplicationDetailsCDV.SOccupationId);
                //cmd.Parameters.AddWithValue("@height", model.ApplicationDetailsCDV.Sheight);
                //cmd.Parameters.AddWithValue("@SChest", model.ApplicationDetailsCDV.SChest);
                //model.data = data.GetDataTable(cmd);

                GetData data = new GetData();
                string whereCondition = string.Empty;
                string Qry = @"select ADCDV.ApplicationNo,EnrollmentNo,to_char(EnrollmentDate,'DD/MM/YYYY') as EnrollDate,ApplicantName,ApplicantFatherName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress from ApplicationDetails AD inner join dgen.ApplicationDetailsCDV ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo inner join dgen.CDVInterviewDetails  CDVID on CDVID.ApplicationNo=ADCDV.ApplicationNo where InterviewDate=@InterviewDate and WhetherSelected=@WhetherSelected";
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and ApplicationDistrictCode in (@ParamDistrictCode)"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and ApplicationSubDivCode=@ParamSubDivCode"; }
                Qry += " and (case when dutyto is null then (case when dutyfrom is null then '2016-02-23' else dutyfrom end ) else dutyto end ) < now() order by enrollmentno";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@InterviewDate", Utility.ConvertDateSequenceForDatabase(model.ActionDate, '/', true));
                cmd.Parameters.AddWithValue("@WhetherSelected", CustomText.TRUE.ToString());
                model.data = data.GetDataTable(cmd);
                model.CDVDutyDetails = new CDVDutyDetails();
                return View(model);
            }
            return View(model);
        }
        [Authorize(Roles = "114")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult AllocateDutyType(ProcessModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Message = string.Empty;
                string checkboxvalue = frm["chkMyCHeck"];
                string[] Values = checkboxvalue.Split(',');
                for (int i = 0; i < Values.Length; i++)
                {
                    string Qry = "insert into dgen.CDVDutyDetails(ApplicationNo,OfficeName,OfficeAddress,DutyTypeId,DutyFrom,DutyTo,JobName,UserId,IpAddress,ActionDateTime) values(@ApplicationNo,@OfficeName,@OfficeAddress,@DutyTypeId,@DutyFrom,@DutyTo,@JobName,@UserId,@IpAddress,now())";
                    NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                    cmd.Parameters.AddWithValue("@OfficeName", model.CDVDutyDetails.OfficeName);
                    cmd.Parameters.AddWithValue("@OfficeAddress", model.CDVDutyDetails.OfficeAddress);
                    cmd.Parameters.AddWithValue("@DutyTypeId", model.CDVDutyDetails.DutyTypeId);
                    cmd.Parameters.AddWithValue("@DutyFrom", Utility.GetDateYYYYMMDD(model.CDVDutyDetails.DutyFrom, '/', "0/1/2"));
                    cmd.Parameters.AddWithValue("@DutyTo", Utility.GetDateYYYYMMDD(model.CDVDutyDetails.DutyTo, '/', "0/1/2"));
                    cmd.Parameters.AddWithValue("@JobName", model.CDVDutyDetails.JobName);
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(cmd);

                    Qry = "Update dgen.applicationdetailscdv set dutyfrom=@dutyfrom ,dutyto=@dutyto where ApplicationNo=@ApplicationNo  ";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                    cmd.Parameters.AddWithValue("@DutyFrom", Utility.GetDateYYYYMMDD(model.CDVDutyDetails.DutyFrom, '/', "0/1/2"));
                    cmd.Parameters.AddWithValue("@DutyTo", Utility.GetDateYYYYMMDD(model.CDVDutyDetails.DutyTo, '/', "0/1/2"));
                    cmdList.Add(cmd);
                }
                if (cmdList.Count > 0)
                {
                    data.SaveData(cmdList);
                    PreserveModelState(Constant._ActionMessage, "Allocate Duty Successful!!! ", false, true);
                    return RedirectToAction("AllocateDuty", "Process");
                }
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("AllocateDuty", (ProcessModels)TempData[Constant._ModelStateParent]);

        }
        [Authorize(Roles = "114")]
        public ActionResult AllocateInterview()
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            model.ApplicationDetailsCDV = new ApplicationDetailsCDV();
            model.CDVDutyDetails = new CDVDutyDetails();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "114")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult AllocateInterview(ProcessModels model)
        {
            if (ModelState.IsValid)
            {

                GetData data = new GetData();
                string Qry = @"Select distinct ADCDV.ApplicationNo,EnrollmentNo,to_char(EnrollmentDate,'DD/MM/YYYY') as EnrollDate,ApplicantName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress  from  dgen.ApplicationDetailsCDV  ADCDV inner join ApplicationDetails AD on AD.ApplicationNo=ADCDV.ApplicationNo  Inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode left outer join dgen.CDVTechnicalEducationDetail CDVTED on CDVTED.ApplicationNo=ADCDV.ApplicationNo ";
                Qry += " where AD.ServiceCode in (@ParamServiceCode)  and ApplicationStatusId=@ApplicationStatusId  and DM.deptcode=@ParamDeptCode and ADCDV.WhetherBasicTrainingComplete=@WhetherBasicTrainingComplete ";
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
                if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.SEqualificationId)) { Qry += " and ADCDV.EqualificationId=@EqualificationId"; }
                if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.SBloodGroup)) { Qry += " and ADCDV.BloodGroup=@BloodGroup"; }
                if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.SGender)) { Qry += " and AD.ApplicantGender=@ApplicantGender"; }
                if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.SOccupationId)) { Qry += " and ADCDV.OccupationId=@OccupationId"; }
                if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.STqualificationId)) { Qry += " and TechnicalEducationId=@TechnicalEducationId"; }
                if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.Sheight)) { Qry += " and ADCDV.heightfeet >= @height and heightinch>0"; }
                if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.SChest)) { Qry += " and ADCDV.chest >@SChest"; }
                Qry += " and (case when dutyto is null then (case when dutyfrom is null then '2016-02-23' else dutyfrom end ) else dutyto end ) < now() order by EnrollDate";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@WhetherBasicTrainingComplete", CustomText.True.ToString());
                cmd.Parameters.AddWithValue("@EqualificationId", model.ApplicationDetailsCDV.SEqualificationId);
                cmd.Parameters.AddWithValue("@TechnicalEducationId", model.ApplicationDetailsCDV.STqualificationId);
                cmd.Parameters.AddWithValue("@BloodGroup", model.ApplicationDetailsCDV.SBloodGroup);
                cmd.Parameters.AddWithValue("@ApplicantGender", model.ApplicationDetailsCDV.SGender);
                cmd.Parameters.AddWithValue("@OccupationId", model.ApplicationDetailsCDV.SOccupationId);
                cmd.Parameters.AddWithValue("@height", model.ApplicationDetailsCDV.Sheight);
                cmd.Parameters.AddWithValue("@SChest", model.ApplicationDetailsCDV.SChest);
                model.data = data.GetDataTable(cmd);
                model.CDVDutyDetails = new CDVDutyDetails();
                return View(model);
            }
            return View(model);
        }
        [Authorize(Roles = "114")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult AllocateInterviewType(ProcessModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Message = string.Empty;
                string checkboxvalue = frm["chkMyCHeck"];
                string[] Values = checkboxvalue.Split(',');
                for (int i = 0; i < Values.Length; i++)
                {
                    Message = "Interview for call-out duty is on " + model.CDVDutyDetails.DutyFrom + " " + model.CDVDutyDetails.InterviewTime + " " + model.CDVDutyDetails.InterviewTimePeriod + " Venu:" + model.CDVDutyDetails.InterviewVenue + "Interview Details: " + model.CDVDutyDetails.InterviewDescr;
                    bool WhetherSend = Utility.IsSmsSent(frm["hdnApplicantmobileNo" + (i)].ToString(), Message);

                    if (WhetherSend)
                    {
                        cmdList.Add(Utility.InsertPushSmsDetails(Message, frm["hdnApplicantmobileNo" + (i)].ToString(), WhetherSend));

                    }

                    string Qry = "insert into dgen.CDVInterviewDetails(ApplicationNo,InterviewDate,InterviewTime,InterviewVenue,InterviewDetails,UserId,IpAddress,ActionDateTime) values(@ApplicationNo,@InterviewDate,@InterviewTime,@InterviewVenue,@InterviewDetails,@UserId,@IpAddress,now())";
                    NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                    cmd.Parameters.AddWithValue("@InterviewDate", Utility.GetDateYYYYMMDD(model.CDVDutyDetails.DutyFrom, '/', "0/1/2"));
                    cmd.Parameters.AddWithValue("@InterviewVenue", model.CDVDutyDetails.InterviewVenue);
                    cmd.Parameters.AddWithValue("@InterviewTime", model.CDVDutyDetails.InterviewTime + " " + model.CDVDutyDetails.InterviewTimePeriod);
                    cmd.Parameters.AddWithValue("@InterviewDetails", model.CDVDutyDetails.InterviewDescr);
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(cmd);

                }
                if (cmdList.Count > 0)
                {
                    data.SaveData(cmdList);
                    PreserveModelState(Constant._ActionMessage, "Allocate Interview Successful!!! ", false, true);
                    return RedirectToAction("AllocateInterview", "Process");
                }
            }

            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("AllocateInterview", (ProcessModels)TempData[Constant._ModelStateParent]);

        }

        [HttpGet]
        public ActionResult CalledForInterviewReport()
        {
            GetData data = new GetData();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            ProcessModels model = new ProcessModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult CalledForInterviewReport(ProcessModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string whereCondition = string.Empty;
                string Qry = @"select ADCDV.ApplicationNo,EnrollmentNo,to_char(EnrollmentDate,'DD/MM/YYYY') as EnrollDate,ApplicantName,ApplicantFatherName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress from ApplicationDetails AD inner join dgen.ApplicationDetailsCDV ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo inner join dgen.CDVInterviewDetails  CDVID on CDVID.ApplicationNo=ADCDV.ApplicationNo where InterviewDate=@InterviewDate";
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and ApplicationDistrictCode in (@ParamDistrictCode)"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and ApplicationSubDivCode=@ParamSubDivCode"; }
                Qry += " order by enrollmentno";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@InterviewDate", Utility.ConvertDateSequenceForDatabase(model.ActionDate, '/', true));
                model.data = data.GetDataTable(cmd);
            }
            return View("CalledForInterviewReport", model);
        }
        [Authorize(Roles = "114")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult CalledForInterviewType(ProcessModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Message = string.Empty;
                string checkboxvalue = frm["chkMyCHeck"];
                string[] Values = checkboxvalue.Split(',');
                for (int i = 0; i < Values.Length; i++)
                {
                    string Qry = "update dgen.CDVInterviewDetails set WhetherSelected=@WhetherSelected where ApplicationNo=@ApplicationNo;";
                    NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                    cmd.Parameters.AddWithValue("@WhetherSelected", CustomText.TRUE.ToString());
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(cmd);

                }
                if (cmdList.Count > 0)
                {
                    data.SaveData(cmdList);
                    PreserveModelState(Constant._ActionMessage, "Updated Successful!!! ", false, true);
                    return RedirectToAction("CalledForInterviewReport", "Process");
                }
            }

            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("CalledForInterviewReport", (ProcessModels)TempData[Constant._ModelStateParent]);

        }

        [Authorize(Roles = "112")]
        [EncryptedActionParameter]
        public ActionResult MarkAttendance()
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            model.ApplicationDetailsCDV = new ApplicationDetailsCDV();
            model.CDVApplicantTrainingDetails = new CDVApplicantTrainingDetails();

            string Qry = "select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid ";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CDVTrainingType);
            List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
            model.CDVApplicantTrainingDetails.TrainingTypeList = new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");

            return View(model);
        }
        [Authorize(Roles = "112")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult MarkAttendance(ProcessModels model)
        {
            if (ModelState.IsValid)
            {

                GetData data = new GetData();
                string Qry = @"Select AttendanceId,ADCDV.ApplicationNo,EnrollmentNo,to_char(EnrollmentDate,'DD/MM/YYYY') as EnrollDate,ApplicantName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress,TrainingDuration,CDVTS.TrainingId from  dgen.ApplicationDetailsCDV  ADCDV inner join ApplicationDetails AD on AD.ApplicationNo=ADCDV.ApplicationNo  Inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode inner join dgen.CDVApplicantTrainingDetails  CDVTS on CDVTS.ApplicationNO=ADCDV.ApplicationNo inner join dgen.CDVAttendanceDetails  CDVAD on CDVAD.TrainingId=CDVTS.TrainingId  and WhetherPresent is null where AD.ServiceCode in (@ParamServiceCode)  and ApplicationStatusId=@ApplicationStatusId  and DM.deptcode=@ParamDeptCode and whethertrainingCompleted=@whethertrainingCompleted ";
                if (!string.IsNullOrEmpty(model.CDVApplicantTrainingDetails.TrainingTypeId)) { Qry += " and TrainingTypeId=@TrainingTypeId"; }
                if (!string.IsNullOrEmpty(model.CDVApplicantTrainingDetails.TrainingCourseId)) { Qry += " and TrainingCourseId=@TrainingCourseId"; }
                if (!string.IsNullOrEmpty(model.CDVDutyDetails.DutyFrom)) { Qry += " and to_char(TrainingDate,'YYYYMMDD')::date =@TrainingDate"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
                Qry += " order by EnrollmentDate";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@whethertrainingCompleted", CustomText.False.ToString());
                cmd.Parameters.AddWithValue("@TrainingTypeId", model.CDVApplicantTrainingDetails.TrainingTypeId);
                cmd.Parameters.AddWithValue("@TrainingCourseId", model.CDVApplicantTrainingDetails.TrainingCourseId);
                cmd.Parameters.AddWithValue("@TrainingDate", Utility.ConvertDateSequenceForDatabase(model.CDVDutyDetails.DutyFrom, '/', true));
                model.data = data.GetDataTable(cmd);


                Qry = "select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid and  SMVTD.valueid=@valueid";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@valueid", model.CDVApplicantTrainingDetails.TrainingTypeId);
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CDVTrainingType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                model.CDVApplicantTrainingDetails.TrainingTypeList = new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
                return View(model);
            }
            return View(model);
        }
        [Authorize(Roles = "112")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult MarkAttendanceType(ProcessModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                ArrayList Values = new ArrayList();
                ArrayList ValuesTraining = new ArrayList();
                ArrayList ValuesAppno = new ArrayList();
                string Qry = @"Select AttendanceId,EnrollmentNo,to_char(EnrollmentDate,'DD/MM/YYYY') as EnrollDate,CDVTS.TrainingTypeid,CDVAD.TrainingId,ADCDV.ApplicationNo,ApplicantName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress,TrainingDuration from  dgen.ApplicationDetailsCDV  ADCDV inner join ApplicationDetails AD on AD.ApplicationNo=ADCDV.ApplicationNo  Inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode inner join dgen.CDVApplicantTrainingDetails  CDVTS on CDVTS.ApplicationNO=ADCDV.ApplicationNo inner join dgen.CDVAttendanceDetails  CDVAD on CDVAD.TrainingId=CDVTS.TrainingId and WhetherPresent is null where AD.ServiceCode in (@ParamServiceCode)  and ApplicationStatusId=@ApplicationStatusId  and DM.deptcode=@ParamDeptCode and WhetherTrainingCompleted=@WhetherTrainingCompleted";
                if (!string.IsNullOrEmpty(model.CDVApplicantTrainingDetails.TrainingTypeId)) { Qry += " and TrainingTypeId=@TrainingTypeId"; }
                if (!string.IsNullOrEmpty(model.CDVApplicantTrainingDetails.TrainingCourseId)) { Qry += " and TrainingCourseId=@TrainingCourseId"; }
                if (!string.IsNullOrEmpty(model.CDVDutyDetails.DutyFrom)) { Qry += " and to_char(TrainingDate,'YYYYMMDD')::date =@TrainingDate"; }
                Qry += " order by EnrollmentDate";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@WhetherTrainingCompleted", CustomText.False.ToString());
                cmd.Parameters.AddWithValue("@TrainingTypeId", model.CDVApplicantTrainingDetails.TrainingTypeId);
                cmd.Parameters.AddWithValue("@TrainingCourseId", model.CDVApplicantTrainingDetails.TrainingCourseId);
                cmd.Parameters.AddWithValue("@TrainingDate", Utility.ConvertDateSequenceForDatabase(model.CDVDutyDetails.DutyFrom, '/', true));

                model.data = data.GetDataTable(cmd);
                string checkboxvalue = frm["chkattendance"];
                string[] chkAttendanceValue = checkboxvalue.Split(',');

                Qry = @"select TrainingDays from coursemaster  where ValueId=@TrainingTypeId and CourseId=@TrainingCourseId";
                cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@TrainingTypeId", model.CDVApplicantTrainingDetails.TrainingTypeId);
                cmd.Parameters.AddWithValue("@TrainingCourseId", model.CDVApplicantTrainingDetails.TrainingCourseId);
                model.data2 = data.GetDataTable(cmd);

                string Message = string.Empty;
                for (int i = 0; i < chkAttendanceValue.Length; i++)
                {
                    Qry = "select coalesce(sum(case when WhetherPresent =@WhetherPresent then 1 end),0) as Attend from dgen.cdvattendancedetails Where TrainingId=@TrainingId group by TrainingId";
                    cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    cmd.Parameters.AddWithValue("@TrainingId", frm["hdnTrainingId" + (i)].ToString());
                    cmd.Parameters.AddWithValue("@WhetherPresent", ((int)ValueId.Present).ToString());
                    model.data1 = data.GetDataTable(cmd);

                    Qry = "update dgen.CDVAttendanceDetails set WhetherPresent=@WhetherPresent,UserId=@UserId,IpAddress=@IpAddress,ActionDateTime=now() where AttendanceId=@AttendanceId";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@AttendanceId", (chkAttendanceValue[i]).ToString());
                    cmd.Parameters.AddWithValue("@WhetherPresent", model.CDVApplicantTrainingDetails.WhetherPresent);
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(cmd);

                    if (Convert.ToInt32(model.data2.Rows[0]["TrainingDays"].ToString()) == (Convert.ToInt32(model.data1.Rows[0]["Attend"].ToString()) + 1) && model.CDVApplicantTrainingDetails.WhetherPresent.ToString() == ((int)ValueId.Present).ToString())
                    {
                        Qry = "update dgen.CDVApplicantTrainingDetails set whethertrainingCompleted=@whethertrainingCompleted,UserId=@UserId,IpAddress=@IpAddress,ActionDateTime=now() where TrainingId=@TrainingId and ApplicationNo=@ApplicationNo";
                        cmd = new NpgsqlCommand(Qry);
                        cmd.Parameters.AddWithValue("@TrainingId", frm["hdnTrainingId" + (i)].ToString());
                        cmd.Parameters.AddWithValue("@ApplicationNo", frm["hdnApplicationNo" + (i)].ToString());
                        cmd.Parameters.AddWithValue("@whethertrainingCompleted", CustomText.TRUE.ToString());
                        cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                        cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                        cmdList.Add(cmd);
                    }
                    if (Convert.ToInt32(model.data2.Rows[0]["TrainingDays"].ToString()) == (Convert.ToInt32(model.data1.Rows[0]["Attend"].ToString()) + 1) && model.CDVApplicantTrainingDetails.WhetherPresent.ToString() == ((int)ValueId.Present).ToString() && Convert.ToInt32(model.data.Rows[i]["TrainingTypeid"].ToString()) == (int)ValueId.BasicTraining)
                    {
                        Qry = "update dgen.applicationdetailscdv set whetherbasictrainingComplete=@whetherbasictrainingComplete,UserId=@UserId,IpAddress=@IpAddress,ActionDateTime=now() where ApplicationNo=@ApplicationNo";
                        cmd = new NpgsqlCommand(Qry);
                        cmd.Parameters.AddWithValue("@ApplicationNo", frm["hdnApplicationNo" + (i)].ToString());
                        cmd.Parameters.AddWithValue("@whetherbasictrainingComplete", CustomText.TRUE.ToString());
                        cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                        cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                        cmdList.Add(cmd);
                    }
                    //}
                }
                if (cmdList.Count > 0)
                {
                    data.SaveData(cmdList);
                    return RedirectToAction("MarkAttendance", "Process");
                }
            }

            model.ApplicationDetailsCDV = new ApplicationDetailsCDV();
            string qry = "select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid and  SMVTD.valueid=@valueid";
            NpgsqlCommand Cmd = new NpgsqlCommand(qry);
            Cmd.Parameters.AddWithValue("@valueid", model.CDVApplicantTrainingDetails.TrainingTypeId);
            Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CDVTrainingType);
            List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
            model.CDVApplicantTrainingDetails.TrainingTypeList = new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");

            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("MarkAttendance", (ProcessModels)TempData[Constant._ModelStateParent]);

        }


        [Authorize(Roles = "112")]
        [EncryptedActionParameter]
        public ActionResult AllocatedApplications(int Pid)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            model.PoliceStationId = Convert.ToString(Pid);
            string Qry = @"Select ADCDV.ApplicationNo,ApplicantName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,to_char(StartDate,'DD/MM/YYY') as StartDate,TrainingDuration,CDVTS.VenueId,VenueName,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress  from dgen.CDVApplicantTrainingDetails CDVTS inner join  dgen.ApplicationDetailsCDV  ADCDV on CDVTS.ApplicationNo=ADCDV.ApplicationNo inner join ApplicationDetails AD on AD.ApplicationNo=ADCDV.ApplicationNo  Inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode Inner join dbo.VenueMaster VM on VM.VenueId=CDVTS.VenueId Inner join dbo.PsToLocalityMaster LM on LM.LocalityId=AD.ApplicantlocalityId where AD.ServiceCode in (@ParamServiceCode)  and ApplicationStatusId=@ApplicationStatusId and StartDate is not null and TrainingDuration is not null and dateofcompletion is null and DM.deptcode=@ParamDeptCode and PoliceStationId=@PoliceStationId";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@PoliceStationId", model.PoliceStationId);
            model.data = data.GetDataTable(cmd);
            model.CDVApplicantTrainingDetails = new CDVApplicantTrainingDetails();
            return View(model);

        }

        [Authorize(Roles = "112")]
        [EncryptedActionParameter]
        public ActionResult TrainingCompletedApplications(int Pid)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            model.PoliceStationId = Convert.ToString(Pid);
            string Qry = @"Select ADCDV.ApplicationNo,ApplicantName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,to_char(StartDate,'DD/MM/YYY') as StartDate,to_char(DateofCompletion,'DD/MM/YYY') as CompletionDate,TrainingDuration,CDVTS.VenueId,VenueName,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress  from dgen.CDVApplicantTrainingDetails CDVTS inner join  dgen.ApplicationDetailsCDV  ADCDV on CDVTS.ApplicationNo=ADCDV.ApplicationNo inner join ApplicationDetails AD on AD.ApplicationNo=ADCDV.ApplicationNo  Inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode Inner join dbo.VenueMaster VM on VM.VenueId=CDVTS.VenueId Inner join dbo.PsToLocalityMaster LM on LM.LocalityId=AD.ApplicantlocalityId where AD.ServiceCode in (@ParamServiceCode)  and ApplicationStatusId=@ApplicationStatusId and whetherTrainingCompleted=True and DM.deptcode=@ParamDeptCode and PoliceStationId=@PoliceStationId";
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@PoliceStationId", model.PoliceStationId);
            model.data = data.GetDataTable(cmd);
            model.CDVApplicantTrainingDetails = new CDVApplicantTrainingDetails();
            return View(model);
        }


        [Authorize(Roles = "112")]
        [EncryptedActionParameter]
        public ActionResult CDVAwardDetails()
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            string Qry = "select EnrollmentNo,AwardId,CD.ApplicationNo,AD.ApplicationId,AD.ApplicantName,AwardName,AwardDetails,to_char(AwardDate,'DD/MM/YYYY')as AwardDate,AwardGivenBy from wgen.cdvawarddetails CD inner join dbo.ApplicationDetails AD on AD.ApplicationNo=CD.ApplicationNo inner join dgen.ApplicationDetailsCDV  ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo where ApplicationStatusid=@ApplicationStatusid and WhetherApproved=@WhetherApproved";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationStatusid", (int)Status.ISSUCER);
            Cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.FALSE.ToString());
            model.data = data.GetDataTable(Cmd);
            return View(model);
        }
        [Authorize(Roles = "112")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult CDVAwardDetailsType(ProcessModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                ArrayList Values = new ArrayList();
                ArrayList ValuesAppno = new ArrayList();
                string Qry = @"select EnrollmentNo,AwardId,('chkbox' || cast(AwardId as varchar)) as CDVAwardId,CD.ApplicationNo,AD.ApplicationId,AD.ApplicantName,AwardName,AwardDetails,to_char(AwardDate,'DD/MM/YYYY')as AwardDate,AwardGivenBy from wgen.cdvawarddetails CD inner join dbo.ApplicationDetails AD on AD.ApplicationNo=CD.ApplicationNo inner join dgen.ApplicationDetailsCDV  ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo where ApplicationStatusid=@ApplicationStatusid and WhetherApproved=@WhetherApproved";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ApplicationStatusid", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.FALSE.ToString());
                model.data = data.GetDataTable(cmd);
                for (int i = 0; i < model.data.Rows.Count; i++)
                {
                    if (frm[model.data.Rows[i]["CDVAwardId"].ToString()] != null)
                    {
                        Values.Add(frm[model.data.Rows[i]["CDVAwardId"].ToString()]);
                        ValuesAppno.Add(model.data.Rows[i]["ApplicationNo"].ToString());
                    }
                    if (Values == null)
                    {
                        return View(model);
                    }
                }

                string Message = string.Empty;
                for (int i = 0; i < Values.Count; i++)
                {
                    Qry = "insert into dgen.cdvawarddetails (ApplicationNo,AwardName,AwardDetails,AwardGivenBy,AwardDate,UserId,IpAddress,ActionDateTime) select ApplicationNo,AwardName,AwardDetails,AwardGivenBy,AwardDate,@UserId as UserId,@IpAddress as IpAddress,now() as ActionDateTime from wgen.cdvawarddetails where AwardId=@AwardId and ApplicationNo=@ApplicationNo";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@AwardId", (Values[i]).ToString());
                    cmd.Parameters.AddWithValue("@ApplicationNo", (ValuesAppno[i]).ToString());
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(cmd);

                    Qry = "update wgen.cdvawarddetails set WhetherApproved=@WhetherApproved where AwardId=@AwardId and ApplicationNo=@ApplicationNo";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@AwardId", (Values[i]).ToString());
                    cmd.Parameters.AddWithValue("@ApplicationNo", (ValuesAppno[i]).ToString());
                    cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.TRUE.ToString());
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(cmd);
                }
                if (cmdList.Count > 0)
                {
                    data.SaveData(cmdList);
                    return RedirectToAction("CDVAwardDetails", "Process");
                }
            }
            return RedirectToAction("CDVAwardDetails", "Process");
        }
        [Authorize(Roles = "112")]
        [EncryptedActionParameter]
        public ActionResult CDVDutyDetails()
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            string Qry = "select EnrollmentNo,DutyId,CD.ApplicationNo,AD.ApplicantName,CD.OfficeName,CD.OfficeAddress,SMVD.ValueId,SMVD.ValueName as DutyName,(to_char(CD.DutyFrom,'DD/MM/YYYY')||'-'||to_char(CD.DutyTo,'DD/MM/YYYY'))as DutyPeriod,to_char(OrderDate,'DD/MM/YYYY')as OrderDate,JobName from wgen.cdvdutydetails CD inner join dbo.ApplicationDetails AD on AD.ApplicationNo=CD.ApplicationNo inner join dgen.ApplicationDetailsCDV  ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo left outer join selectmastervaluedetails SMVD on SMVD.valueid=CD.DutyTypeId  where ApplicationStatusid=@ApplicationStatusid and WhetherApproved=@WhetherApproved";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationStatusid", (int)Status.ISSUCER);
            Cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.FALSE.ToString());
            model.data = data.GetDataTable(Cmd);
            return View(model);
        }
        [Authorize(Roles = "112")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult CDVDutyDetailsType(ProcessModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                ArrayList Values = new ArrayList();
                ArrayList ValuesAppno = new ArrayList();
                string Qry = @"select EnrollmentNo,DutyId,('chkbox' || cast(DutyId as varchar)) as CDVDutyId,CD.ApplicationNo,AD.ApplicantName,CD.OfficeName,CD.OfficeAddress,SMVD.ValueId,SMVD.ValueName as DutyName,(to_char(CD.DutyFrom,'DD/MM/YYYY')||'-'||to_char(CD.DutyTo,'DD/MM/YYYY'))as DutyPeriod,to_char(OrderDate,'DD/MM/YYYY')as OrderDate,JobName from wgen.cdvdutydetails CD inner join dbo.ApplicationDetails AD on AD.ApplicationNo=CD.ApplicationNo inner join dgen.ApplicationDetailsCDV  ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo left outer join selectmastervaluedetails SMVD on SMVD.valueid=CD.DutyTypeId  where ApplicationStatusid=@ApplicationStatusid and WhetherApproved=@WhetherApproved";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ApplicationStatusid", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.FALSE.ToString());
                model.data = data.GetDataTable(cmd);
                for (int i = 0; i < model.data.Rows.Count; i++)
                {
                    if (frm[model.data.Rows[i]["CDVDutyId"].ToString()] != null)
                    {
                        Values.Add(frm[model.data.Rows[i]["CDVDutyId"].ToString()]);
                        ValuesAppno.Add(model.data.Rows[i]["ApplicationNo"].ToString());
                    }
                    if (Values == null)
                    {
                        return View(model);
                    }
                }

                string Message = string.Empty;
                for (int i = 0; i < Values.Count; i++)
                {
                    Qry = "insert into dgen.cdvdutydetails (ApplicationNo,OfficeName,OfficeAddress,DutyTypeId,DutyFrom,DutyTo,OrderDate,JobName,UserId,IpAddress,ActionDateTime) select ApplicationNo,OfficeName,OfficeAddress,DutyTypeId,DutyFrom,DutyTo,OrderDate,JobName,@UserId as UserId,@IpAddress as IpAddress,now() as ActionDateTime from wgen.cdvdutydetails where DutyId=@DutyId and ApplicationNo=@ApplicationNo";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@DutyId", (Values[i]).ToString());
                    cmd.Parameters.AddWithValue("@ApplicationNo", (ValuesAppno[i]).ToString());
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(cmd);

                    Qry = "update wgen.cdvdutydetails set WhetherApproved=@WhetherApproved where DutyId=@DutyId and ApplicationNo=@ApplicationNo";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@DutyId", (Values[i]).ToString());
                    cmd.Parameters.AddWithValue("@ApplicationNo", (ValuesAppno[i]).ToString());
                    cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.TRUE.ToString());
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(cmd);
                }
                if (cmdList.Count > 0)
                {
                    data.SaveData(cmdList);
                    return RedirectToAction("CDVDutyDetails", "Process");
                }
            }
            return RedirectToAction("CDVDutyDetails", "Process");
        }
        [Authorize(Roles = "112")]
        [EncryptedActionParameter]
        public ActionResult CDVTrainingDetails()
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            string Qry = "select EnrollmentNo,TrainingId,CD.ApplicationNo,AD.ApplicantName,SMVD.ValueId,SMVD.ValueName as TrainingTypeName,CM.CourseName,VM.VenueName,TrainingDuration,WhetherTrainingCompleted,TrainingObservation from wgen.CDVApplicantTrainingDetails CD inner join dbo.ApplicationDetails AD on AD.ApplicationNo=CD.ApplicationNo inner join dgen.ApplicationDetailsCDV  ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo left outer join selectmastervaluedetails SMVD on SMVD.valueid=CD.trainingtypeid inner join venuemaster VM on VM.VenueId=CD.VenueId inner join coursemaster CM on CM.CourseId=CD.trainingcourseid where ApplicationStatusid=@ApplicationStatusid and WhetherApproved=@WhetherApproved";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationStatusid", (int)Status.ISSUCER);
            Cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.FALSE.ToString());
            model.data = data.GetDataTable(Cmd);
            return View(model);
        }
        [Authorize(Roles = "112")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult CDVTrainingDetailsType(ProcessModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                ArrayList Values = new ArrayList();
                ArrayList ValuesAppno = new ArrayList();
                string Qry = @"select EnrollmentNo,TrainingId,('chkbox' || cast(TrainingId as varchar)) as CDVTrainingId,CD.ApplicationNo,AD.ApplicantName,SMVD.ValueId,SMVD.ValueName as TrainingTypeName,CM.CourseName,VM.VenueName,TrainingDuration,WhetherTrainingCompleted,TrainingObservation from wgen.CDVApplicantTrainingDetails CD inner join dbo.ApplicationDetails AD on AD.ApplicationNo=CD.ApplicationNo inner join dgen.ApplicationDetailsCDV  ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo left outer join selectmastervaluedetails SMVD on SMVD.valueid=CD.trainingtypeid inner join venuemaster VM on VM.VenueId=CD.VenueId inner join coursemaster CM on CM.CourseId=CD.trainingcourseid where ApplicationStatusid=@ApplicationStatusid and WhetherApproved=@WhetherApproved";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ApplicationStatusid", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.FALSE.ToString());
                model.data = data.GetDataTable(cmd);
                for (int i = 0; i < model.data.Rows.Count; i++)
                {
                    if (frm[model.data.Rows[i]["CDVTrainingId"].ToString()] != null)
                    {
                        Values.Add(frm[model.data.Rows[i]["CDVTrainingId"].ToString()]);
                        ValuesAppno.Add(model.data.Rows[i]["ApplicationNo"].ToString());
                    }
                    if (Values == null)
                    {
                        return View(model);
                    }
                }

                string Message = string.Empty;
                for (int i = 0; i < Values.Count; i++)
                {
                    Qry = "insert into dgen.CDVApplicantTrainingDetails (ApplicationNo,TrainingTypeId,TrainingCourseId,VenueId,TrainingDuration,WhetherTrainingCompleted,TrainingObservation,UserId,IpAddress,ActionDateTime) select ApplicationNo,TrainingTypeId,TrainingCourseId,VenueId,TrainingDuration,WhetherTrainingCompleted,TrainingObservation,@UserId as UserId,@IpAddress as IpAddress,now() as ActionDateTime from wgen.CDVApplicantTrainingDetails where TrainingId=@TrainingId and ApplicationNo=@ApplicationNo";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@TrainingId", (Values[i]).ToString());
                    cmd.Parameters.AddWithValue("@ApplicationNo", (ValuesAppno[i]).ToString());
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(cmd);

                    Qry = "update wgen.CDVApplicantTrainingDetails set WhetherApproved=@WhetherApproved where TrainingId=@TrainingId and ApplicationNo=@ApplicationNo";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@TrainingId", (Values[i]).ToString());
                    cmd.Parameters.AddWithValue("@ApplicationNo", (ValuesAppno[i]).ToString());
                    cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.TRUE.ToString());
                    cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(cmd);
                }
                if (cmdList.Count > 0)
                {
                    data.SaveData(cmdList);
                    return RedirectToAction("CDVTrainingDetails", "Process");
                }
            }
            return RedirectToAction("CDVTrainingDetails", "Process");
        }
        #endregion

        #region Tirth Yatra Service
        //[Authorize(Roles = "130,131")]
        //[EncryptedActionParameter]
        //public ActionResult PendingForDrawSummary(int sid, int? RouteId = 0, int? ConstituencyId = 0)
        //{
        //    GetData data = new GetData();
        //    ProcessModels model = new ProcessModels();

        //    string Qry = "select SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName,sum(case when ApplicationStatusId=@ApplicationStatusId and whetherindraw=@WhetherFALSE then 1 else 0 end) as Pending,sum(case when ApplicationStatusId=@ApplicationStatusId and whetherindraw=@WhetherFALSE then 1 else 0 end + (case when ApplicationStatusId=@ApplicationStatusId and whetherindraw=@WhetherFALSE and whetherappyingwithspouse=@WhetherTrue then 1 else 0 end) + (case when ApplicationStatusId=@ApplicationStatusId  and whetherindraw=@WhetherFALSE and optingforattendant=@WhetherTrue then 1 else 0 end)) as totalrecMember from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid inner join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) ";
        //    if (RouteId != (int)CountList.Type000) { Qry += " and ADTY.RouteId=@RouteId "; }
        //    if (ConstituencyId != (int)CountList.Type000) { Qry += " and ADTY.constituencyid=@ConstituencyId "; }
        //    Qry += " group by SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName order by SMVD.ValueName,constituencyName";
        //    NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
        //    cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
        //    cmd.Parameters.AddWithValue("@RouteId", RouteId);
        //    cmd.Parameters.AddWithValue("@ConstituencyId", ConstituencyId);
        //    cmd.Parameters.AddWithValue("@WhetherTrue", CustomText.TRUE.ToString());
        //    cmd.Parameters.AddWithValue("@WhetherFALSE", CustomText.FALSE.ToString());
        //    model.data = data.GetDataTable(cmd);
        //    model.StatusId = sid.ToString();
        //    if (RouteId != (int)CountList.Type000) { model.RouteId = RouteId.ToString(); }
        //    if (ConstituencyId != (int)CountList.Type000) { model.ConstituencyId = ConstituencyId.ToString(); }

        //    if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
        //    return View(model);
        //}
        //[Authorize(Roles = "130,131")]
        //[AcceptVerbs(HttpVerbs.Post)]
        //[ValidateAntiForgeryToken]
        //[ValidateOnlyIncomingValues]
        //public ActionResult PendingForDrawSummary(ProcessModels model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        int RouteId = 0, ConstituencyId = 0;
        //        if (!string.IsNullOrEmpty(model.RouteId)) { RouteId = Convert.ToInt32(model.RouteId); }
        //        if (!string.IsNullOrEmpty(model.ConstituencyId)) { ConstituencyId = Convert.ToInt32(model.ConstituencyId); }
        //        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid", "RouteId", "ConstituencyId" }, new ArrayList() { Convert.ToInt32(model.StatusId), RouteId, ConstituencyId });
        //        return RedirectToAction("PendingForDrawSummary", "Process", new { q = QueryString });
        //    }
        //    return View("PendingForDrawSummary", model);
        //}
        //[Authorize(Roles = "130,131")]
        //[EncryptedActionParameter]
        //public ActionResult PendingForDrawAppList(int RouteId, int ConstituencyId, int StatusId)
        //{
        //    GetData data = new GetData();
        //    ProcessModels model = new ProcessModels();
        //    string Qry = "select AD.ServiceCode,SCM.ServiceName,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName,sum(1 + (case when ApplicationStatusId=@ApplicationStatusId and whetherappyingwithspouse=true then 1 else 0 end) + (case when ApplicationStatusId=@ApplicationStatusId and optingforattendant=true then 1 else 0 end)) as totalrecMember,to_Char(AD.applicationdate,'DD/MM/YYY')as DateofApplication from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo  inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid inner join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId and ADTY.constituencyid=@ConstituencyId and ADTY.RouteId=@RouteId and whetherindraw=@WhetherFALSE group by AD.ServiceCode,SCM.ServiceName,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,SL.StatusName,AD.ApplicationStatusId,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName order by AD.applicationdate";
        //    NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
        //    cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.TirthYatraYojna);
        //    cmd.Parameters.AddWithValue("@RouteId", RouteId);
        //    cmd.Parameters.AddWithValue("@ApplicationStatusId", StatusId);
        //    cmd.Parameters.AddWithValue("@ConstituencyId", ConstituencyId);
        //    cmd.Parameters.AddWithValue("@WhetherTrue", CustomText.TRUE.ToString());
        //    cmd.Parameters.AddWithValue("@WhetherFALSE", CustomText.FALSE.ToString());
        //    model.data = data.GetDataTable(cmd);
        //    return View(model);
        //}
        //[Authorize(Roles = "130,131")]
        //[EncryptedActionParameter]
        //public ActionResult PendingForDrawAppDetails(Int64 AppNo)
        //{
        //    if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }

        //    GetData data = new GetData();
        //    ProcessModels model = new ProcessModels();
        //    model.ApplicationDetails = new ApplicationDetails();
        //    model.ApplicationDetails.ApplicationNo = AppNo.ToString();
        //    string[] Values = Utility.GetServiceCode(Convert.ToInt64(model.ApplicationDetails.ApplicationNo));

        //    string Qry = "select ServiceCode,ApplicationStatusId from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ServiceCode in (@ParamServiceCode)";
        //    NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
        //    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
        //    Cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
        //    Cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
        //    string[] GetValues = data.SelectColumns(Cmd);
        //    model.ApplicationDetails.ServiceCode = GetValues[0];
        //    model.ApplicationDetails.ApplicationStatusId = GetValues[1];

        //    model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
        //    model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
        //    model.data1 = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
        //    model.data3 = Utility.GetObjectionDetails(model.ApplicantDetails.ApplicationNo.ToString());
        //    model.data4 = Utility.GetApplicationAuditTrail(model.ApplicantDetails.ApplicationNo);

        //    if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.TirthYatraYojna)
        //    {
        //        model.ApplicationDetailsTirthYatraYojana = Utility.GetTirthYatraYojnaDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
        //    }
        //    else
        //    {
        //        return RedirectToAction("UnauthorizedRequest", "Error");
        //    }
        //    PreserveModelState(Constant._ModelStateParent, model, false, true);
        //    return View(model);
        //}
        //[Authorize(Roles = "130,131")]
        //[AcceptVerbs(HttpVerbs.Post)]
        //[ValidateAntiForgeryToken]
        //[ValidateOnlyIncomingValues]
        //public ActionResult PendingForDrawAppDetails(ProcessModels model, FormCollection frm)
        //{
        //    GetData data = new GetData();
        //    if (ModelState.IsValid)
        //    {
        //        List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
        //        NpgsqlCommand cmd = new NpgsqlCommand();
        //        string Qry = string.Empty;

        //        Qry = "Update dgen.applicationdetailstirthyatrayojana set WhetherInDraw=@WhetherInDraw,drawno=@drawno,priorityno=@priorityno,userid=@userid,IpAddress=@IpAddress,LastActionDate=now() where ApplicationNo=@ApplicationNo ";
        //        cmd = new NpgsqlCommand(Qry);
        //        cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
        //        cmd.Parameters.AddWithValue("@drawno", model.ApplicationDetailsTirthYatraYojana.DrawNo);
        //        cmd.Parameters.AddWithValue("@priorityno", model.ApplicationDetailsTirthYatraYojana.PriorityNo);
        //        cmd.Parameters.AddWithValue("@WhetherInDraw", CustomText.TRUE.ToString());
        //        cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
        //        cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
        //        cmdList.Add(cmd);

        //        Qry = "update web.ApplicationDetails set userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
        //        cmd = new NpgsqlCommand(Qry);
        //        cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
        //        cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
        //        cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
        //        cmdList.Add(cmd);

        //        Qry = "update dbo.ApplicationDetails set userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
        //        cmd = new NpgsqlCommand(Qry);
        //        cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
        //        cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
        //        cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
        //        cmdList.Add(cmd);

        //        cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG067, null, (int)ApplicationSource.Window, null));

        //        data.SaveData(cmdList);
        //        PreserveModelState(Constant._ActionMessage, "Selected application has been processed successfully.", false, true);
        //        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.ISSUCER).ToString() });
        //        return RedirectToAction("PendingForDrawSummary", new { q = QueryString });
        //    }
        //    PreserveModelState(Constant._ModelStateParent, null, true, false);
        //    return View("PendingForDrawSummary", (DecisionModels)TempData[Constant._ModelStateParent]);
        //}

        //ExcludeTirthYatra Code is Not Used in Current FLow Block the Code and Exclude View when flow is Final
        
        #region Exclude code of Tirth Yatra Yojna
        [Authorize(Roles = "132")]
        [EncryptedActionParameter]
        public ActionResult PendingYatraApprovedAppSummary(int sid, int? RouteId = 0, int? ConstituencyId = 0)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();

            string Qry = "select SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName,count(AD.ApplicationNo) as total,sum((case when ApplicationStatusId=@ApplicationStatusId then 1 else 0 end) + (case when whetherappyingwithspouse=true then 1 else 0 end) + (case when optingforattendant=true then 1 else 0 end)) as totalMember,sum(case when ApplicationStatusId=@ApplicationStatusId then 1 else 0 end) as Pending,sum(case when ApplicationStatusId=@ApplicationStatusId then 1 else 0 end + (case when ApplicationStatusId=@ApplicationStatusId and whetherappyingwithspouse=true then 1 else 0 end) + (case when ApplicationStatusId=@ApplicationStatusId  and optingforattendant=true then 1 else 0 end)) as totalrecMember from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid inner join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) ";
            if (RouteId != (int)CountList.Type000) { Qry += " and ADTY.RouteId=@RouteId "; }
            if (ConstituencyId != (int)CountList.Type000) { Qry += " and ADTY.constituencyid=@ConstituencyId "; }
            Qry += " group by SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName order by SMVD.ValueName,constituencyName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@RouteId", RouteId);
            cmd.Parameters.AddWithValue("@ConstituencyId", ConstituencyId);
            model.data = data.GetDataTable(cmd);
            model.StatusId = sid.ToString();
            if (RouteId != (int)CountList.Type000) { model.RouteId = RouteId.ToString(); }
            if (ConstituencyId != (int)CountList.Type000) { model.ConstituencyId = ConstituencyId.ToString(); }

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "132")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingYatraApprovedAppSummary(ProcessModels model)
        {
            if (ModelState.IsValid)
            {
                int RouteId = 0, ConstituencyId = 0;
                if (!string.IsNullOrEmpty(model.RouteId)) { RouteId = Convert.ToInt32(model.RouteId); }
                if (!string.IsNullOrEmpty(model.ConstituencyId)) { ConstituencyId = Convert.ToInt32(model.ConstituencyId); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid", "RouteId", "ConstituencyId" }, new ArrayList() { Convert.ToInt32(model.StatusId), RouteId, ConstituencyId });
                return RedirectToAction("PendingYatraApprovedAppSummary", "Process", new { q = QueryString });
            }
            return View("PendingYatraApprovedAppSummary", model);
        }
        [Authorize(Roles = "132")]
        [EncryptedActionParameter]
        public ActionResult PendingYatraApprovedAppList(int RouteId, int ConstituencyId, int StatusId)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            string Qry = "select AD.ServiceCode,SCM.ServiceName,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName,sum(1 + (case when ApplicationStatusId=@ApplicationStatusId and whetherappyingwithspouse=true then 1 else 0 end) + (case when ApplicationStatusId=@ApplicationStatusId and optingforattendant=true then 1 else 0 end)) as totalrecMember,to_Char(AD.applicationdate,'DD/MM/YYY')as DateofApplication from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo  inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid inner join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId and ADTY.constituencyid=@ConstituencyId and ADTY.RouteId=@RouteId group by AD.ServiceCode,SCM.ServiceName,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,SL.StatusName,AD.ApplicationStatusId,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.TirthYatraYojna);
            cmd.Parameters.AddWithValue("@RouteId", RouteId);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", StatusId);
            cmd.Parameters.AddWithValue("@ConstituencyId", ConstituencyId);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [Authorize(Roles = "132")]
        [EncryptedActionParameter]
        public ActionResult PendingYatraApprovedAppDetails(Int64 AppNo)
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }

            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();
            string[] Values = Utility.GetServiceCode(Convert.ToInt64(model.ApplicationDetails.ApplicationNo));

            string Qry = "select ServiceCode,ApplicationStatusId from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ServiceCode in (@ParamServiceCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //Cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            string[] GetValues = data.SelectColumns(Cmd);
            model.ApplicationDetails.ServiceCode = GetValues[0];
            model.ApplicationDetails.ApplicationStatusId = GetValues[1];

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data1 = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data3 = Utility.GetObjectionDetails(model.ApplicantDetails.ApplicationNo.ToString());
            model.data4 = Utility.GetApplicationAuditTrail(model.ApplicantDetails.ApplicationNo);

            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.TirthYatraYojna)
            {
                model.ApplicationDetailsTirthYatraYojana = Utility.GetTirthYatraYojnaDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            }
            else
            {
                return RedirectToAction("UnauthorizedRequest", "Error");
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [Authorize(Roles = "132")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingYatraApprovedAppDetails(ProcessModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                NpgsqlCommand cmd = new NpgsqlCommand();
                string Qry = string.Empty;
                string checkboxvalue = frm["MarkRecmd"];
                string[] MarkRecmdValue = checkboxvalue.Split(',');

                string Message = string.Empty;
                for (int i = 0; i < MarkRecmdValue.Length; i++)
                {
                    Dictionary<string, string> ValidateData = new Dictionary<string, string>();
                    ValidateData.Add("ApplicationNo", (MarkRecmdValue[i]).ToString());
                    string[] ValidationCheck = Utility.ApplicationValidation(ValidateData, (int)ValidationCheckLevels.DecisionProcessGeneralPost, false);
                    if (ValidationCheck[0] == ((int)CountList.Type001).ToString())
                    {
                        ViewData["message"] = ValidationCheck[1];
                        return View("message");
                    }
                    else if (ValidationCheck[0] == ((int)CountList.Type002).ToString())
                    {
                        ViewData["message"] = ValidationCheck[1];
                        return View("message");
                    }

                    Qry = "Update dgen.applicationdetailstirthyatrayojana set ApproveBy=@ApproveBy,ApproveIpAddress=@ApproveIpAddress,ApproveDate=now() where ApplicationNo=@ApplicationNo ";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@ApplicationNo", (MarkRecmdValue[i]).ToString());
                    cmd.Parameters.AddWithValue("@ApproveBy", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@ApproveIpAddress", Utility.GetIP4Address());
                    cmdList.Add(cmd);

                    Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                    cmd.Parameters.AddWithValue("@ApplicationNo", (MarkRecmdValue[i]).ToString());
                    cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                    cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(cmd);

                    Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
                    cmd.Parameters.AddWithValue("@ApplicationNo", (MarkRecmdValue[i]).ToString());
                    cmd.Parameters.AddWithValue("@ApplicationRemarks", model.ApplicationDetails.ApplicationRemarks);
                    cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(cmd);

                    cmdList.Add(Utility.InsertDepartmentAuditTrail((MarkRecmdValue[i]).ToString(), (int)ApplicationHistoryMessage.MSG005, null, (int)ApplicationSource.Window, null));
                }
                if (cmdList.Count > 0)
                {
                    data.SaveData(cmdList);
                    PreserveModelState(Constant._ActionMessage, "Selected application has been processed successfully.", false, true);
                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.TEHSREC).ToString() });
                    return RedirectToAction("PendingYatraApprovedAppSummary", new { q = QueryString });
                }
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PendingYatraApprovedAppDetails", (DecisionModels)TempData[Constant._ModelStateParent]);
        }
        #endregion


        [Authorize(Roles = "133")]
        [EncryptedActionParameter]
        public ActionResult PendingYatraDTDCAppSummary(int sid, int? RouteId = 0, int? ConstituencyId = 0)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();

            //string Qry = "select SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName,sum(case when ApplicationStatusId=@ApplicationStatusId and whetherindraw=@WhetherTRUE then 1 else 0 end) as Pending,sum(case when ApplicationStatusId=@ApplicationStatusId and whetherindraw=@WhetherTRUE then 1 else 0 end + (case when ApplicationStatusId=@ApplicationStatusId and whetherindraw=@WhetherTRUE and whetherappyingwithspouse=@WhetherTRUE then 1 else 0 end) + (case when ApplicationStatusId=@ApplicationStatusId  and whetherindraw=@WhetherTRUE and optingforattendant=@WhetherTRUE then 1 else 0 end)) as totalrecMember from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid inner join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) and WhetherAllocateTravel=@WhetherAllocateTravel";
            string Qry = "select SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName,sum(case when ApplicationStatusId=@ApplicationStatusId  then 1 else 0 end) as Pending,sum(case when ApplicationStatusId=@ApplicationStatusId then 1 else 0 end + (case when ApplicationStatusId=@ApplicationStatusId and whetherappyingwithspouse=@WhetherTRUE then 1 else 0 end) + (case when ApplicationStatusId=@ApplicationStatusId  and optingforattendant=@WhetherTRUE then 1 else 0 end)) as totalrecMember from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid inner join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) and WhetherAllocateTravel=@WhetherAllocateTravel";
            if (RouteId != (int)CountList.Type000) { Qry += " and ADTY.RouteId=@RouteId "; }
            if (ConstituencyId != (int)CountList.Type000) { Qry += " and ADTY.constituencyid=@ConstituencyId "; }
            Qry += " group by SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName order by SMVD.ValueName,constituencyName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@RouteId", RouteId);
            cmd.Parameters.AddWithValue("@ConstituencyId", ConstituencyId);
            cmd.Parameters.AddWithValue("@WhetherAllocateTravel", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@WhetherTRUE", CustomText.TRUE.ToString());
            model.data = data.GetDataTable(cmd);
            model.StatusId = sid.ToString();
            if (RouteId != (int)CountList.Type000) { model.RouteId = RouteId.ToString(); }
            if (ConstituencyId != (int)CountList.Type000) { model.ConstituencyId = ConstituencyId.ToString(); }
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "133")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingYatraDTDCAppSummary(ProcessModels model)
        {
            if (ModelState.IsValid)
            {
                int RouteId = 0, ConstituencyId = 0;
                if (!string.IsNullOrEmpty(model.RouteId)) { RouteId = Convert.ToInt32(model.RouteId); }
                if (!string.IsNullOrEmpty(model.ConstituencyId)) { ConstituencyId = Convert.ToInt32(model.ConstituencyId); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid", "RouteId", "ConstituencyId" }, new ArrayList() { Convert.ToInt32(model.StatusId), RouteId, ConstituencyId });
                return RedirectToAction("PendingYatraDTDCAppSummary", "Process", new { q = QueryString });
            }
            return View("PendingYatraDTDCAppSummary", model);
        }
        [Authorize(Roles = "133")]
        [EncryptedActionParameter]
        public ActionResult PendingYatraDTDCAppList(int RouteId, int ConstituencyId, int StatusId)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            model.ApplicationDetailsTirthYatraYojana = new ApplicationDetailsTirthYatraYojana();

            //string Qry = "select AD.ServiceCode,SCM.ServiceName,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName,DrawNo,priorityno,sum(case when ApplicationStatusId=@ApplicationStatusId then 1 else 0 end + (case when ApplicationStatusId=@ApplicationStatusId and whetherappyingwithspouse=@WhetherTRUE then 1 else 0 end) + (case when ApplicationStatusId=@ApplicationStatusId and optingforattendant=@WhetherTRUE then 1 else 0 end)) as totalrecMember from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo  inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid inner join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId and ADTY.constituencyid=@ConstituencyId and ADTY.RouteId=@RouteId and WhetherAllocateTravel=@WhetherAllocateTravel and whetherindraw=@WhetherTRUE group by AD.ServiceCode,SCM.ServiceName,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,SL.StatusName,AD.ApplicationStatusId,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName,priorityno,DrawNo order by priorityno,DrawNo";
            string Qry = "select AD.ServiceCode,SCM.ServiceName,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName,sum(case when ApplicationStatusId=@ApplicationStatusId then 1 else 0 end + (case when ApplicationStatusId=@ApplicationStatusId and whetherappyingwithspouse=@WhetherTRUE then 1 else 0 end) + (case when ApplicationStatusId=@ApplicationStatusId and optingforattendant=@WhetherTRUE then 1 else 0 end)) as totalrecMember from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo  inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid inner join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId where AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId=@ApplicationStatusId and ADTY.constituencyid=@ConstituencyId and ADTY.RouteId=@RouteId and WhetherAllocateTravel=@WhetherAllocateTravel group by AD.ServiceCode,SCM.ServiceName,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,SL.StatusName,AD.ApplicationStatusId,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName order by AD.ApplicationNo";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.TirthYatraYojna);
            cmd.Parameters.AddWithValue("@RouteId", RouteId);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", StatusId);
            cmd.Parameters.AddWithValue("@ConstituencyId", ConstituencyId);
            cmd.Parameters.AddWithValue("@WhetherAllocateTravel", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@WhetherTRUE", CustomText.TRUE.ToString());
            model.data = data.GetDataTable(cmd);
            model.RouteId = RouteId.ToString();
            model.ConstituencyId = ConstituencyId.ToString();
            model.StatusId = StatusId.ToString();

            return View(model);
        }
        [Authorize(Roles = "133")]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult PendingYatraDTDCAppDetails(Int64 AppNo)
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }

            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();
            string[] Values = Utility.GetServiceCode(Convert.ToInt64(model.ApplicationDetails.ApplicationNo));

            string Qry = "select ServiceCode,ApplicationStatusId from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ServiceCode in (@ParamServiceCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            Cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            //Cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            string[] GetValues = data.SelectColumns(Cmd);
            model.ApplicationDetails.ServiceCode = GetValues[0];
            model.ApplicationDetails.ApplicationStatusId = GetValues[1];

            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data1 = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data3 = Utility.GetObjectionDetails(model.ApplicantDetails.ApplicationNo.ToString());
            model.data4 = Utility.GetApplicationAuditTrail(model.ApplicantDetails.ApplicationNo);

            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.TirthYatraYojna)
            {
                model.ApplicationDetailsTirthYatraYojana = Utility.GetTirthYatraYojnaDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
            }
            else
            {
                return RedirectToAction("UnauthorizedRequest", "Error");
            }
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [Authorize(Roles = "133")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingYatraDTDCAppDetails(ProcessModels model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                string Qry = string.Empty;
                GetData data = new GetData();
                NpgsqlCommand cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                
                string checkboxvalue = frm["MarkRecmd"];
                string[] MarkRecmdValue = checkboxvalue.Split(',');

                if (string.IsNullOrEmpty(model.ApplicationDetailsTirthYatraYojana.TravelDate) && string.IsNullOrEmpty(model.ApplicationDetailsTirthYatraYojana.TravelTime) && string.IsNullOrEmpty(model.ApplicationDetailsTirthYatraYojana.BoardingFrom) && string.IsNullOrEmpty(model.ApplicationDetailsTirthYatraYojana.TourDetails))
                {
                    ViewData["message"] = "Please Fill All Details";
                    return View("message");
                }

                string Message = string.Empty;
                Qry = "insert into dgen.tirthtraveldetails(routeid,constituencyid,UserId,Ipaddress,actiondatetime) values (@routeid,@constituencyid,@UserId,@Ipaddress,now()); SELECT currval(pg_get_serial_sequence('dgen.tirthtraveldetails','travelid'))";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@routeid", model.RouteId);
                cmd.Parameters.AddWithValue("@constituencyid", model.ConstituencyId);
                cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                cmdList.Add(cmd);

                for (int i = 0; i < MarkRecmdValue.Length; i++)
                {

                    Dictionary<string, string> ValidateData = new Dictionary<string, string>();
                    ValidateData.Add("ApplicationNo", (MarkRecmdValue[i]).ToString());
                    string[] ValidationCheck = Utility.ApplicationValidation(ValidateData, (int)ValidationCheckLevels.DecisionProcessGeneralPost, false);
                    if (ValidationCheck[0] == ((int)CountList.Type001).ToString())
                    {
                        ViewData["message"] = ValidationCheck[1];
                        return View("message");
                    }
                    else if (ValidationCheck[0] == ((int)CountList.Type002).ToString())
                    {
                        ViewData["message"] = ValidationCheck[1];
                        return View("message");
                    }

                    //changes20180912
                    Qry = "Update dgen.applicationdetailstirthyatrayojana set travelid=@LastInsertedId, WhetherAllocateTravel=@WhetherAllocateTravel,BusDetails=@BusDetails,TravelDate=@TravelDate,TravelTime=@TravelTime,BoardingFrom=@BoardingFrom,TourDetails=@TourDetails,CoachNo=@CoachNo,SeatNo=@SeatNo,TravelByTypeId=@TravelByTypeId,AllocateBy=@AllocateBy,AllocateIpAddress=@AllocateIpAddress,AllocateDate=now() where ApplicationNo=@ApplicationNo ";//Changes20180801
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@ApplicationNo", (MarkRecmdValue[i]).ToString());
                    cmd.Parameters.AddWithValue("@AllocateBy", Sessions.getEmployeeUser().UserId);
                    cmd.Parameters.AddWithValue("@AllocateIpAddress", Utility.GetIP4Address());
                    cmd.Parameters.AddWithValue("@WhetherAllocateTravel", CustomText.True.ToString());
                    cmd.Parameters.AddWithValue("@TravelDate", Utility.GetDateYYYYMMDD(model.ApplicationDetailsTirthYatraYojana.TravelDate, '/', "0/1/2"));
                    cmd.Parameters.AddWithValue("@TravelTime", model.ApplicationDetailsTirthYatraYojana.TravelTime);
                    cmd.Parameters.AddWithValue("@BoardingFrom", model.ApplicationDetailsTirthYatraYojana.BoardingFrom);
                    cmd.Parameters.AddWithValue("@TourDetails", model.ApplicationDetailsTirthYatraYojana.TourDetails);
                    cmd.Parameters.AddWithValue("@BusDetails", model.ApplicationDetailsTirthYatraYojana.BusDetails);
                    cmd.Parameters.AddWithValue("@CoachNo", model.ApplicationDetailsTirthYatraYojana.CoachNo);
                    cmd.Parameters.AddWithValue("@SeatNo", model.ApplicationDetailsTirthYatraYojana.SeatNo);
                    cmd.Parameters.AddWithValue("@TravelByTypeId", model.ApplicationDetailsTirthYatraYojana.TravelByTypeId);
                    cmdList.Add(cmd);

                    // entry in application log
                    cmdList.Add(Utility.InsertDepartmentAuditTrail((MarkRecmdValue[i]).ToString(), (int)ApplicationHistoryMessage.MSG068, null, (int)ApplicationSource.Window, null));
                    data.SaveTransactionalData(cmdList);

                    //send sms to applicant and insert record in table
                    string ParamSmsText = string.Empty;
                    ParamSmsText = "Travel Date:" + model.ApplicationDetailsTirthYatraYojana.TravelDate;
                    if (model.ApplicationDetailsTirthYatraYojana.TravelByTypeId == ((int)ValueId.Train).ToString())
                    {
                        ParamSmsText += " Coach No:" + model.ApplicationDetailsTirthYatraYojana.CoachNo + "Seat No:" + model.ApplicationDetailsTirthYatraYojana.SeatNo;
                    }
                    else
                    {
                        ParamSmsText += " Bus No:" + model.ApplicationDetailsTirthYatraYojana.CoachNo + "Seat No:" + model.ApplicationDetailsTirthYatraYojana.SeatNo;
                    }
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", (MarkRecmdValue[i]).ToString());
                    smsDic.Add("ParamSmsText", ParamSmsText);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS047, smsDic));

                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS047).ToString());
                    EmailDic.Add("ParamApplicationNo", (MarkRecmdValue[i]).ToString());
                    EmailDic.Add("ParamSmsText", ParamSmsText);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }

                    data.SaveData(cmdList);
                }                

                PreserveModelState(Constant._ActionMessage, "Selected application has been processed successfully.", false, true);
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { ((int)Status.ISSUCER).ToString() });
                return RedirectToAction("PendingYatraDTDCAppSummary", new { q = QueryString });
            }
            string QueryString1 = Utility.CreateEncryptedQueyString(new ArrayList() { "RouteId", "ConstituencyId", "StatusId" }, new ArrayList() { Convert.ToInt32(model.RouteId), Convert.ToInt32(model.ConstituencyId), Convert.ToInt32(model.StatusId) });
            return RedirectToAction("PendingYatraDTDCAppList", "Process", new { q = QueryString1 });
        }
        [Authorize(Roles = "133")]
        [EncryptedActionParameter]
        public ActionResult PendingAllocatedYatraAppSummary(int sid, int? RouteId = 0, int? ConstituencyId = 0)
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.P133).ToString()) { return RedirectToAction("UnauthorizedRequest"); }
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            string Qry = "select SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId and whetherallocatetravel=@whetherallocatetravel then 1 end),0) as Pending from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid inner join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.ServiceCode in (@ParamServiceCode) and WhetherPresentInTrip=@WhetherPresentInTrip ";
            if (RouteId != (int)CountList.Type000) { Qry += " and ADTY.RouteId=@RouteId "; }
            if (ConstituencyId != (int)CountList.Type000) { Qry += " and ADTY.constituencyid=@ConstituencyId "; }
            Qry += " group by SC.ServiceName,SC.ServiceCode,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName order by SMVD.ValueName,constituencyName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@whetherallocatetravel", CustomText.TRUE.ToString());
            cmd.Parameters.AddWithValue("@WhetherPresentInTrip", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@RouteId", RouteId);
            cmd.Parameters.AddWithValue("@ConstituencyId", ConstituencyId);
            model.data = data.GetDataTable(cmd);
            model.StatusId = sid.ToString();
            if (RouteId != (int)CountList.Type000) { model.RouteId = RouteId.ToString(); }
            if (ConstituencyId != (int)CountList.Type000) { model.ConstituencyId = ConstituencyId.ToString(); }
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "133")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingAllocatedYatraAppSummary(ProcessModels model)
        {
            if (ModelState.IsValid)
            {
                int RouteId = 0, ConstituencyId = 0;
                if (!string.IsNullOrEmpty(model.RouteId)) { RouteId = Convert.ToInt32(model.RouteId); }
                if (!string.IsNullOrEmpty(model.ConstituencyId)) { ConstituencyId = Convert.ToInt32(model.ConstituencyId); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid", "RouteId", "ConstituencyId" }, new ArrayList() { Convert.ToInt32(model.StatusId), RouteId, ConstituencyId });
                return RedirectToAction("PendingAllocatedYatraAppSummary", "Process", new { q = QueryString });
            }
            return View("PendingAllocatedYatraAppSummary", model);
        }
        [Authorize(Roles = "133")]
        [EncryptedActionParameter]
        public ActionResult PendingAllocatedYatraApplicationList(int RouteId, int ConstituencyId, int StatusId)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,AD.ApplicantDob,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,SMVD.ValueName,SMVD.ValueId,ACM.constituencyid,constituencyName from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsTirthYatrayojana ADTY on ADTY.ApplicationNo=AD.ApplicationNo  inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode inner join SelectMasterValueDetails SMVD on SMVD.ValueId=ADTY.RouteId inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADTY.constituencyid where AD.ServiceCode=@ServiceCode  and AD.ApplicationStatusId=@ApplicationStatusId and ADTY.ConstituencyId=@ConstituencyId and ADTY.RouteId=@RouteId and WhetherPresentInTrip=@WhetherPresentInTrip and whetherallocatetravel=@whetherallocatetravel order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.TirthYatraYojna);
            cmd.Parameters.AddWithValue("@RouteId", RouteId);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", StatusId);
            cmd.Parameters.AddWithValue("@ConstituencyId", ConstituencyId);
            cmd.Parameters.AddWithValue("@whetherallocatetravel", CustomText.TRUE.ToString());
            cmd.Parameters.AddWithValue("@WhetherPresentInTrip", CustomText.False.ToString());
            model.data = data.GetDataTable(cmd);
            model.StatusId = StatusId.ToString();
            model.RouteId = RouteId.ToString();
            model.ConstituencyId = ConstituencyId.ToString();
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "133")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SaveAllocatedYatraApplicationDetails(ProcessModels model, FormCollection frm)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Qry = string.Empty, ApplicationStatusId = string.Empty;
                string checkboxvalue = frm["MarkVisited"];
                string[] MarkRecmdValue = checkboxvalue.Split(',');

                for (int i = 0; i < MarkRecmdValue.Length; i++)
                {
                    Qry = "Update dgen.applicationdetailstirthyatrayojana set WhetherPresentInTrip=@WhetherPresentInTrip,PresentMarkBy=@PresentMarkBy,PresentMarkIpAddress=@PresentMarkIpAddress,PresentMarkDate=now() where ApplicationNo=@ApplicationNo ";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", (MarkRecmdValue[i]).ToString());
                    Cmd.Parameters.AddWithValue("@PresentMarkBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@PresentMarkIpAddress", Utility.GetIP4Address());
                    Cmd.Parameters.AddWithValue("@WhetherPresentInTrip", CustomText.True.ToString());
                    cmdList.Add(Cmd);
                }

                data.SaveData(cmdList);

                ViewData["message"] = "Present Mark Sucessfully";
                return View("message");
            }
            PreserveModelState(Constant._ActionMessage, "Please Check the Details", false, true);
            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "RouteId", "ConstituencyId", "StatusId" }, new ArrayList() { Convert.ToInt32(model.RouteId), Convert.ToInt32(model.ConstituencyId), Convert.ToInt32(model.StatusId) });
            return RedirectToAction("PendingAllocatedYatraApplicationList", new { q = QueryString });
        }        
        #endregion

        #region Prematric Services
        [Authorize(Roles = "120")]
        [EncryptedActionParameter]
        public ActionResult AddCourseToSchool()
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            TempData[KeyName._Key06] = null;
            PreMatricModel model = new PreMatricModel();
            model.SchoolId = Sessions.getEmployeeUser().AuthorizationId;
            model.SchoolName = Utility.SelectColumnsValue("dgen.prematschoolmaster", "schoolname", "schoolid", model.SchoolId)[0];
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult AddCourseToSchool(PreMatricModel model)
        {
            GetData data = new GetData();
            PreMatricModel model1 = new PreMatricModel();
            string Qry = string.Empty; NpgsqlCommand Cmd = new NpgsqlCommand();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            if (TempData[KeyName._Key06] == null)
            {
                Qry = "select * from dgen.PreMatCourseMaster where lower(CourseName)=@CourseName and SchoolId=@SchoolId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@CourseName", model.CourseName.ToLower().Trim());
                Cmd.Parameters.AddWithValue("@SchoolId", model.SchoolId);
                DataTable dt = data.GetDataTable(Cmd);
                if (dt.Rows.Count > 0)
                {
                    PreserveModelState(Constant._ActionMessage, "Course with same name has already been added once. ", false, true);
                    return RedirectToAction("AddCourseToSchool", "Process");
                }

                Qry = "select * from dgen.PreMatCourseMaster where AffiliatedId=@AffiliatedId and SchoolId=@SchoolId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@AffiliatedId", model.AffiliatedId.ToLower().Trim());
                Cmd.Parameters.AddWithValue("@SchoolId", model.SchoolId);
                DataTable dt1 = data.GetDataTable(Cmd);
                if (dt1.Rows.Count == 0)
                {
                    TempData[KeyName._Key06] = model;
                    model1.AffiliatedId = model.AffiliatedId;
                    return View("AddCourseToSchool", model1);
                }
                else
                {
                    Qry = "insert into dgen.PreMatCourseMaster(CourseName,AffiliatedId,SchoolId,UniversityName,AffiliationFrom,AffiliationUpto,UserId,Ipaddress,LastactionDate) values (@CourseName,@AffiliatedId,@SchoolId,@UniversityName,@AffiliationFrom,@AffiliationUpto,@UserId,@Ipaddress,now())";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@CourseName", model.CourseName.Trim());
                    Cmd.Parameters.AddWithValue("@AffiliatedId", model.AffiliatedId.Trim());
                    Cmd.Parameters.AddWithValue("@SchoolId", model.SchoolId);
                    Cmd.Parameters.AddWithValue("@UniversityName", model.UniversityName);
                    Cmd.Parameters.AddWithValue("@AffiliationFrom", Utility.GetDateYYYYMMDD(model.AffiliationFrom, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@AffiliationUpto", Utility.GetDateYYYYMMDD(model.AffiliationUpto, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                    data.UpdateData(Cmd);
                }
            }
            else
            {

                PreMatricModel model2 = new PreMatricModel();
                model2 = (PreMatricModel)TempData[KeyName._Key06];

                Qry = "insert into dgen.PreMatCourseMaster(CourseName,AffiliatedId,SchoolId,UniversityName,AffiliationFrom,AffiliationUpto,UserId,Ipaddress,LastactionDate) values (@CourseName,@AffiliatedId,@SchoolId,@UniversityName,@AffiliationFrom,@AffiliationUpto,@UserId,@Ipaddress,now())";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@CourseName", model2.CourseName.Trim());
                Cmd.Parameters.AddWithValue("@AffiliatedId", model2.AffiliatedId.Trim());
                Cmd.Parameters.AddWithValue("@SchoolId", model2.SchoolId);
                Cmd.Parameters.AddWithValue("@UniversityName", model2.UniversityName);
                Cmd.Parameters.AddWithValue("@AffiliationFrom", Utility.GetDateYYYYMMDD(model2.AffiliationFrom, '/', "0/1/2"));
                Cmd.Parameters.AddWithValue("@AffiliationUpto", Utility.GetDateYYYYMMDD(model2.AffiliationUpto, '/', "0/1/2"));
                Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);


                HttpPostedFile file1 = System.Web.HttpContext.Current.Request.Files["AffDoc1"];
                byte[] fileData1 = Utility.CompareFileCapturePhotoData(null, file1);
                string contentType1 = file1.ContentType;

                HttpPostedFile file2 = System.Web.HttpContext.Current.Request.Files["AffDoc2"];
                byte[] fileData2 = Utility.CompareFileCapturePhotoData(null, file2);
                string contentType2 = file2.ContentType;

                if (fileData1 == null || fileData2 == null)
                {
                    ViewBag.DisplayMessage = "Please Upload Correct File";
                    TempData[KeyName._Key06] = model2;
                    model1.AffiliatedId = model2.AffiliatedId;
                    return View("AddCourseToSchool", model1);
                }

                Qry = "insert into dgen.PreMatCourseEnclosureDetails(AffiliatedId,SchoolId,EnclosureData,EnclosureContentType,FeeOrderData,FeeOrderContentType,UserId,Ipaddress,LastactionDate) values (@AffiliatedId,@SchoolId,@EnclosureData,@EnclosureContentType,@FeeOrderData,@FeeOrderContentType,@UserId,@Ipaddress,now())";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@EnclosureData", fileData1);
                Cmd.Parameters.AddWithValue("@EnclosureContentType", contentType1);
                Cmd.Parameters.AddWithValue("@FeeOrderData", fileData2);
                Cmd.Parameters.AddWithValue("@FeeOrderContentType", contentType2);
                Cmd.Parameters.AddWithValue("@AffiliatedId", model.AffiliatedId);
                Cmd.Parameters.AddWithValue("@SchoolId", model2.SchoolId);
                Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);
                data.SaveData(cmdList);
            }

            PreserveModelState(Constant._ActionMessage, "Course Added", false, true);
            return RedirectToAction("AddCourseToSchool", "Process");
        }
        [Authorize(Roles = "120")]
        [EncryptedActionParameter]
        public ActionResult PendingPreMatApplicationSummary(int sid, int? AcademicSession = 0)
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.P120).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
            string cond = string.Empty, Qry = string.Empty; // join = string.Empty 
            NpgsqlCommand cmd = new NpgsqlCommand();
            if (AcademicSession == (int)CountList.Type000)
            {
                //----------------------Temp comment for 2017-18 session, un-comment when you wants to process for 2017-18
                Qry = "select s1.valuename from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SCSTWelfareAcadmicSession);
                AcademicSession = Convert.ToInt32(data.SelectColumns(cmd)[0]);
                //AcademicSession = 2016;
            }

            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { cond += " and PAP.Schoolid=@Schoolid "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { cond += " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            if (AcademicSession != (int)CountList.Type000) { cond += " and PAP.AcademicSession=@AcademicSession "; }
            Qry = "select SC.ServiceName,SC.ServiceCode,count(AD.ApplicationNo) as TotalReceived,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId then 1 end),0) as Pending,coalesce(sum(case when ApplicationStatusId<>@ApplicationStatusId then 1 end),0) as Verified  from dbo.ApplicationDetails AD Inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo  left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode  where DM.deptcode=@ParamDeptCode  and AD.ServiceCode in (@ParamServiceCode)   " + cond + "  group by SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            if (AcademicSession != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession); }
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@Schoolid", Sessions.getEmployeeUser().AuthorizationId); }
            model.data = data.GetDataTable(cmd);
            model.StatusId = sid.ToString();
            model.AcademicSession = AcademicSession.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingPreMatApplicationSummary(ProcessModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid", "AcademicSession" }, new ArrayList() { Convert.ToInt32(model.StatusId), AcademicSession });
                return RedirectToAction("PendingPreMatApplicationSummary", "Process", new { q = QueryString });
            }
            return View("PendingPreMatApplicationSummary", model);
        }
        [Authorize(Roles = "120")]
        [EncryptedActionParameter]
        public ActionResult PendingPreMatReverifyAppSummary(int sid, int? AcademicSession = 0)
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.P120).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
            string join = string.Empty, cond = string.Empty, Qry = string.Empty;
            NpgsqlCommand cmd = new NpgsqlCommand();
            if (AcademicSession == (int)CountList.Type000)
            {
                //----------------------Temp comment for 2017-18 session, un-comment when you wants to process for 2017-18
                Qry = "select s1.valuename from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SCSTWelfareAcadmicSession);
                AcademicSession = Convert.ToInt32(data.SelectColumns(cmd)[0]);
                //AcademicSession = 2016;
            }

            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { cond += " and PAP.Schoolid=@Schoolid "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { cond += " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            if (AcademicSession != (int)CountList.Type000) { cond += " and PAP.AcademicSession=@AcademicSession "; }
            Qry = "select SC.ServiceName,SC.ServiceCode,coalesce(sum(case when ApplicationStatusId=@ApplicationStatusId then 1 end),0) as Pending from dbo.ApplicationDetails AD Inner join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo  left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode  where DM.deptcode=@ParamDeptCode  and AD.ServiceCode in (@ParamServiceCode) and WhetherRevertBack=@WhetherRevertBack " + cond + "  group by SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.TRUE.ToString());
            if (AcademicSession != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession); }
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@Schoolid", Sessions.getEmployeeUser().AuthorizationId); }
            model.data = data.GetDataTable(cmd);
            model.StatusId = sid.ToString();
            model.AcademicSession = AcademicSession.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingPreMatReverifyAppSummary(ProcessModels model)
        {
            if (ModelState.IsValid)
            {
                int AcademicSession = 0;
                if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid", "AcademicSession" }, new ArrayList() { Convert.ToInt32(model.StatusId), AcademicSession });
                return RedirectToAction("PendingPreMatReverifyAppSummary", "Process", new { q = QueryString });
            }
            return View("PendingPreMatReverifyAppSummary", model);
        }
        [Authorize(Roles = "120")]
        [EncryptedActionParameter]
        public ActionResult SearchAppForAction(int sid)
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.P120).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            model.StatusId = sid.ToString();

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "120")]
        [EncryptedActionParameter]
        public ActionResult PendingPreMatApplicationList(int service, int status, int AppType, int AcademicSession)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            string Whethercondition = string.Empty;
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { Whethercondition += " and PAP.Schoolid=@Schoolid "; }
            if (AppType == (int)CountList.Type001) { Whethercondition += " and whetherrevertback=true "; }
            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate , dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,AD.ApplicantDob,AD.ApplicationStatusId from dbo.ApplicationDetails AD inner  join dgen.prematapplicationprocess PAP on AD.ApplicationNo=PAP.ApplicationNo  inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode where AD.ServiceCode=@ServiceCode  and AD.ApplicationStatusId=@ApplicationStatusId  and PAP.AcademicSession=@AcademicSession " + Whethercondition + " order by AD.applicationdate ";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", status);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@Schoolid", Sessions.getEmployeeUser().AuthorizationId); }
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [Authorize(Roles = "120")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult PendingPreMatApplicationDetails(ProcessModels model)
        {
            if (ModelState.IsValid)
            {
                model.StatusId = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ApplicationStatusId", "ApplicationNo", model.ApplicationNo.ToString())[0];
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo", "StsId" }, new ArrayList() { model.ApplicationNo, model.StatusId });
                return RedirectToAction("PendingPreMatApplicationDetails", "Process", new { q = QueryString });
            }
            return View("SearchAppForAction", model);
        }
        [Authorize(Roles = "120")]
        [EncryptedActionParameter]
        public ActionResult PendingPreMatApplicationDetails(Int64 AppNo, int StsId)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            model.ApplicationNo = AppNo.ToString();
            model.StatusId = StsId.ToString();
            string QueryString = string.Empty, cond = string.Empty;
            model.WhetherScStwelfateAllowed = false;
            Dictionary<string, string> ValidateData = new Dictionary<string, string>();
            ValidateData.Add("ApplicationNo", model.ApplicationNo);

            string DisplayMessage = Utility.WhetherAccessAllowed(ValidateData, new int[] { (int)ValueId.AuthCrendential, (int)ValueId.AuthOtp }, null, new int[] { (int)Status.OBSPEND }, false, false, true);
            if (!string.IsNullOrEmpty(DisplayMessage))
            {
                PreserveModelState(Constant._ActionMessage, DisplayMessage, false, true);
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.StatusId });
                return RedirectToAction("SearchAppForAction", new { q = QueryString });
            }

            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { cond += " and ApplicationSubdivCode in (@ParamSubDivCode) "; }
            string Qry = "select ServiceCode,ApplicationStatusId,ApplicationNo FROM dbo.ApplicationDetails where ApplicationNo=@ApplicationNo " + cond + " and ServiceCode in (@ParamServiceCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            string[] Val = data.SelectColumns(Cmd);
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ServiceCode = Val[0];
            model.ApplicationDetails.ApplicationStatusId = Val[1];
            model.ApplicationDetails.ApplicationNo = Val[2];
            if (string.IsNullOrEmpty(model.ApplicationDetails.ApplicationNo))
            {
                PreserveModelState(Constant._ActionMessage, "Application Not Found or Not Available in you account, Kindly Check Your Application No.", false, true);
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.StatusId });
                return RedirectToAction("SearchAppForAction", new { q = QueryString });
            }

            model.WhetherDocVerified = Utility.CheckWhetherDocVerify(model.ApplicationNo, DB.LS.ToString());

            if (model.StatusId == ((int)Status.OBSPEND).ToString())
            {
                model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());

                Qry = "select ApplicantName,to_char(ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB, Case When ApplicantGender='M' Then 'Male' When ApplicantGender='F' Then 'Female' When ApplicantGender='T' Then 'Transgender' end as ApplicantGender from dgen.scstupdatedapplicationdetail where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
                model.data1 = data.GetDataTable(Cmd);

                if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PrematricScholarshipSC)
                {
                    model.ApplicationDetailsPrematsSC = Utility.GetPrematsSCDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.ApplicationDetailsPrematsSC.ScStFeeDetails = new List<ScStFeeDetails>();
                    Qry = @"select a.servicecode,a.feetypeby,b.valuename,coalesce(c.feeamount,0) as feeamount from prematservicetofeehead a inner join selectmastervaluedetails b on b.valueid=a.feetypeby 
                            left outer join dgen.scstfeedetails c on c.feetypeby=a.feetypeby and c.feeinitiateby=@feeinitiateby and c.applicationno=@ApplicationNo where ServiceCode=@ServiceCode and a.feetypeby not in (@feetypeby,@OtherCompulsoryFees) ";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.PrematricScholarshipSC);
                    Cmd.Parameters.AddWithValue("@feeinitiateby", (int)ValueId.Department);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@feetypeby", (int)ValueId.Issued);
                    Cmd.Parameters.AddWithValue("@OtherCompulsoryFees", (int)ValueId.OtherCompulsoryFees);
                    DataTable Dt1 = data.GetDataTable(Cmd);

                    for (int i = 0; i < Dt1.Rows.Count; i++)
                    {
                        model.WhetherScStwelfateAllowed = true;
                        model.ApplicationDetailsPrematsSC.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
                    }
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.FinancialAssistanceStationery)
                {
                    model.ApplicationDetailsFinancialAssistance = Utility.GetFinancialAssistanceDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.ApplicationDetailsFinancialAssistance.ScStFeeDetails = new List<ScStFeeDetails>();
                    DataTable Dt1 = Utility.GetSCSTScholorship(model.ApplicantDetails.ApplicationNo, null, null);
                    for (int i = 0; i < Dt1.Rows.Count; i++)
                    {
                        model.WhetherScStwelfateAllowed = true;
                        model.ApplicationDetailsFinancialAssistance.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
                    }
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MeritscholarshipSchool)
                {
                    model.ApplicationDetailsMeritscholarshipSchool = Utility.GetMeritscholarshipSchoolDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.ApplicationDetailsMeritscholarshipSchool.ScStFeeDetails = new List<ScStFeeDetails>();
                    DataTable Dt1 = Utility.GetSCSTScholorship(model.ApplicantDetails.ApplicationNo, null, null);
                    for (int i = 0; i < Dt1.Rows.Count; i++)
                    {
                        model.WhetherScStwelfateAllowed = true;
                        model.ApplicationDetailsMeritscholarshipSchool.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
                    }
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.DrbrAmbedkarToppers)
                {
                    model.ApplicationDetailsDrbrAmbedkarToppers = Utility.GetDrbrAmbedkarToppersDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.ApplicationDetailsDrbrAmbedkarToppers.ScStFeeDetails = new List<ScStFeeDetails>();
                    DataTable Dt1 = Utility.GetSCSTScholorship(model.ApplicantDetails.ApplicationNo, null, null);
                    for (int i = 0; i < Dt1.Rows.Count; i++)
                    {
                        model.WhetherScStwelfateAllowed = true;
                        model.ApplicationDetailsDrbrAmbedkarToppers.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
                    }
                }

                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.MeritscholarshipProfessional)
                {
                    model.ApplicationDetailsMeritProfessional = Utility.GetMeritscholarshipProfessionalDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.ApplicationDetailsMeritProfessional.ScStFeeDetails = new List<ScStFeeDetails>();
                    DataTable Dt1 = Utility.GetSCSTScholorship(model.ApplicantDetails.ApplicationNo, null, null);
                    for (int i = 0; i < Dt1.Rows.Count; i++)
                    {
                        model.WhetherScStwelfateAllowed = true;
                        model.ApplicationDetailsMeritProfessional.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
                    }
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PrematricScholarshipOBC)
                {
                    model.ApplicationDetailsPrematOBC = Utility.GetPrematsOBCDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.ApplicationDetailsPrematOBC.ScStFeeDetails = new List<ScStFeeDetails>();
                    DataTable Dt1 = Utility.GetSCSTScholorship(model.ApplicantDetails.ApplicationNo, null, null);

                    for (int i = 0; i < Dt1.Rows.Count; i++)
                    {
                        model.WhetherScStwelfateAllowed = true;
                        model.ApplicationDetailsPrematOBC.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
                    }
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PostmatricScholarshipOBC)
                {
                    model.ApplicationDetailsPostmatOBC = Utility.GetPostmatOBCDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.ApplicationDetailsPostmatOBC.ScStFeeDetails = new List<ScStFeeDetails>();
                    DataTable Dt1 = Utility.GetSCSTScholorship(model.ApplicantDetails.ApplicationNo, null, null);
                    for (int i = 0; i < Dt1.Rows.Count; i++)
                    {
                        model.WhetherScStwelfateAllowed = true;
                        model.ApplicationDetailsPostmatOBC.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
                    }
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PrematricSC)
                {
                    model.ApplicationDetailsPrematSCssd = Utility.GetPrematSCSSDDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.ApplicationDetailsPrematSCssd.ScStFeeDetails = new List<ScStFeeDetails>();
                    DataTable Dt1 = Utility.GetSCSTScholorship(model.ApplicantDetails.ApplicationNo, null, null);
                    for (int i = 0; i < Dt1.Rows.Count; i++)
                    {
                        model.WhetherScStwelfateAllowed = true;
                        model.ApplicationDetailsPrematSCssd.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
                    }
                }
                else if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PostmatricSC)
                {
                    model.ApplicationDetailsPostmatSCssd = Utility.GetPostmatSCSSDDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                    model.ApplicationDetailsPostmatSCssd.ScStFeeDetails = new List<ScStFeeDetails>();
                    DataTable Dt1 = Utility.GetSCSTScholorship(model.ApplicantDetails.ApplicationNo, null, null);
                    for (int i = 0; i < Dt1.Rows.Count; i++)
                    {
                        model.WhetherScStwelfateAllowed = true;
                        model.ApplicationDetailsPostmatSCssd.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
                    }
                }



                model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", string.Empty, string.Empty, model.ApplicationDetails.ApplicationNo, DB.LS.ToString(), CustomText.N.ToString());
                model.data2 = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
                model.data4 = Utility.GetApplicantAvailedService(model.ApplicantDetails.RegistrationId.ToString());

                PreserveModelState(Constant._ModelStateParent, model, false, true);
                return View(model);
            }
            PreserveModelState(Constant._ActionMessage, "Entered Application Not Pending at this Level.", false, true);
            QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.StatusId });
            return RedirectToAction("SearchAppForAction", new { q = QueryString });
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SavePendingPreMatApplicationDetails(ProcessModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Qry = string.Empty, ApplicationStatusId = string.Empty, DisAmount = string.Empty;

                Dictionary<string, string> ValidateData = new Dictionary<string, string>();
                ValidateData.Add("ApplicationNo", model.ApplicationNo);

                string DisplayMessage = Utility.WhetherAccessAllowed(ValidateData, new int[] { (int)ValueId.AuthCrendential, (int)ValueId.AuthOtp }, null, new int[] { (int)Status.OBSPEND }, false, false, true);
                if (!string.IsNullOrEmpty(DisplayMessage))
                {
                    ViewBag.DisplayMessage = DisplayMessage;
                    PreserveModelState(Constant._ModelStateParent, null, true, false);
                    return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                }

                Qry = "select Academicsession from dgen.prematapplicationprocess where ApplicationNo=@ApplicationNo and whetherrevertback=@whetherrevertback;";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@whetherrevertback", CustomText.False.ToString());
                string Academicsession = data.SelectColumns(Cmd)[0];
                if (!string.IsNullOrEmpty(Academicsession))
                {
                    Qry = "select SchoolId from dbyt.prematverifiedapplication where SchoolId=@SchoolId and ServiceCode=@ServiceCode and WhetherFileUploaded=@WhetherFileUploaded and Academicsession=@Academicsession and Academicsession<>@AcademicsessionNotIn ";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@SchoolId", Sessions.getEmployeeUser().AuthorizationId.ToString());
                    Cmd.Parameters.AddWithValue("@ServiceCode", model.ApplicationDetails.ServiceCode);
                    Cmd.Parameters.AddWithValue("@WhetherFileUploaded", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@Academicsession", Academicsession);
                    Cmd.Parameters.AddWithValue("@AcademicsessionNotIn", "2016");
                    string SchoolId = data.SelectColumns(Cmd)[0];
                    if (!string.IsNullOrEmpty(SchoolId))
                    {
                        ViewData["message"] = "You are Not Allowed To Verify The Application. Your Have Alerady Uploaded The Verified Applications!!!";
                        return View("message");
                    }
                }

                if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.PrematricScholarshipSC).ToString() || model.ApplicationDetails.ServiceCode == ((int)ServiceList.FinancialAssistanceStationery).ToString() || model.ApplicationDetails.ServiceCode == ((int)ServiceList.MeritscholarshipSchool).ToString() || model.ApplicationDetails.ServiceCode == ((int)ServiceList.DrbrAmbedkarToppers).ToString() || model.ApplicationDetails.ServiceCode == ((int)ServiceList.MeritscholarshipProfessional).ToString() || model.ApplicationDetails.ServiceCode == ((int)ServiceList.PostmatricScholarshipOBC).ToString() || model.ApplicationDetails.ServiceCode == ((int)ServiceList.PrematricScholarshipOBC).ToString() || model.ApplicationDetails.ServiceCode == ((int)ServiceList.PrematricSC).ToString() || model.ApplicationDetails.ServiceCode == ((int)ServiceList.PostmatricSC).ToString())
                {
                    ApplicationStatusId = ((int)Status.TEHSPEN).ToString();
                }
                if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.PrematricScholarshipSC).ToString())
                {
                    model.WhetherSchoolRecomended = model.ApplicationDetailsPrematsSC.WhetherSchoolRecomended;
                    if (model.ApplicationDetailsPrematsSC.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                    {
                        Int64 DisburseAmount = 0, FillAmount = 0;
                        Qry = "Select AnnualIncome from dgen.ApplicationDetailsPrematsSC Where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        string AnnualIncome = data.SelectColumns(Cmd)[0];

                        Qry = "Select FeeAmount from dgen.ScStFeeDetails Where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Applicant);
                        DataTable dt = data.GetDataTable(Cmd);
                        if (dt != null)
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                FillAmount = FillAmount + Convert.ToInt64(dt.Rows[i]["FeeAmount"].ToString());
                            }
                        }
                        foreach (ScStFeeDetails Head in model.ApplicationDetailsPrematsSC.ScStFeeDetails)
                        {
                            DisburseAmount = DisburseAmount + Convert.ToInt64(Head.FeeAmount);
                        }
                        Dictionary<string, string> Data = new Dictionary<string, string>();
                        Data.Add("AnnualIncome", AnnualIncome);
                        Data.Add("DisAmount", DisburseAmount.ToString());
                        Data.Add("FillAmount", FillAmount.ToString());
                        bool chececkresult = Utility.CheckEligibilitySCSTService(Data, model.ApplicationDetails.ServiceCode, (int)CountList.Type001);
                        if (chececkresult == false)
                        {
                            ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                        }

                        if (DisburseAmount == (int)CountList.Type000)
                        {
                            ViewBag.DisplayMessage = "Please Enter The Correct Amount. Zero Amount is not Allowed";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                        }

                        Qry = "Delete from dgen.ScStFeeDetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                        cmdList.Add(Cmd);

                        foreach (ScStFeeDetails Head in model.ApplicationDetailsPrematsSC.ScStFeeDetails)
                        {
                            Qry = "insert into dgen.ScStFeeDetails(ApplicationNo,FeeinitiateBy,FeeTypeBy,FeeAmount,UserId,IpAddress,LastActionDate) values (@ApplicationNo,@FeeinitiateBy,@FeeTypeBy,@FeeAmount,@UserId,@IpAddress,now())";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                            Cmd.Parameters.AddWithValue("@FeeTypeBy", Head.FeeTypeId);
                            Cmd.Parameters.AddWithValue("@FeeAmount", Head.FeeAmount);
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);
                        }
                    }
                    Qry = "update dgen.ApplicationDetailsPrematsSC set WhetherSchoolRecomended=@WhetherSchoolRecomended,WhetherVerified=@WhetherVerified,VerifiedDate=now(),SchollRemarks=@SchollRemarks,SchollRemarksBy=@SchollRemarksBy,SchollRemarksIpAddress=@SchollRemarksIpAddress,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", model.ApplicationDetailsPrematsSC.WhetherSchoolRecomended);
                    Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@SchollRemarks", model.ApplicationDetailsPrematsSC.SchollRemarks);
                    Cmd.Parameters.AddWithValue("@SchollRemarksBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@SchollRemarksIpAddress", Utility.GetIP4Address());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, model.ApplicationDetailsPrematsSC.SchollRemarks, (int)ApplicationSource.Window, null));
                }
                else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.FinancialAssistanceStationery).ToString())
                {
                    model.WhetherSchoolRecomended = model.ApplicationDetailsFinancialAssistance.WhetherSchoolRecomended;
                    if (model.ApplicationDetailsFinancialAssistance.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                    {
                        foreach (ScStFeeDetails Head in model.ApplicationDetailsFinancialAssistance.ScStFeeDetails)
                        {
                            DisAmount = Head.FeeAmount;
                        }
                        model.data1 = Utility.GetSCSTScholorship(model.ApplicationNo, null, null);
                        if (Convert.ToInt32(model.data1.Rows[0]["FeeAmount"].ToString()) < Convert.ToInt32(DisAmount))
                        {
                            ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                        }

                        Qry = "Delete from dgen.ScStFeeDetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                        cmdList.Add(Cmd);

                        foreach (ScStFeeDetails Head in model.ApplicationDetailsFinancialAssistance.ScStFeeDetails)
                        {
                            Qry = "insert into dgen.ScStFeeDetails(ApplicationNo,FeeinitiateBy,FeeTypeBy,FeeAmount,UserId,IpAddress,LastActionDate) values (@ApplicationNo,@FeeinitiateBy,@FeeTypeBy,@FeeAmount,@UserId,@IpAddress,now())";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                            Cmd.Parameters.AddWithValue("@FeeTypeBy", Head.FeeTypeId);
                            Cmd.Parameters.AddWithValue("@FeeAmount", Head.FeeAmount);
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);
                        }
                    }
                    Qry = "update dgen.ApplicationDetailsFinancialAssistance set WhetherSchoolRecomended=@WhetherSchoolRecomended,WhetherVerified=@WhetherVerified,VerifiedDate=now(),SchollRemarks=@SchollRemarks,SchollRemarksBy=@SchollRemarksBy,SchollRemarksIpAddress=@SchollRemarksIpAddress,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", model.ApplicationDetailsFinancialAssistance.WhetherSchoolRecomended);
                    Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@SchollRemarks", model.ApplicationDetailsFinancialAssistance.SchollRemarks);
                    Cmd.Parameters.AddWithValue("@SchollRemarksBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@SchollRemarksIpAddress", Utility.GetIP4Address());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, model.ApplicationDetailsFinancialAssistance.SchollRemarks, (int)ApplicationSource.Window, null));
                }
                else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.MeritscholarshipSchool).ToString())
                {
                    model.WhetherSchoolRecomended = model.ApplicationDetailsMeritscholarshipSchool.WhetherSchoolRecomended;
                    if (model.ApplicationDetailsMeritscholarshipSchool.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                    {
                        foreach (ScStFeeDetails Head in model.ApplicationDetailsMeritscholarshipSchool.ScStFeeDetails)
                        {
                            DisAmount = Head.FeeAmount;
                        }
                        model.data1 = Utility.GetSCSTScholorship(model.ApplicationNo, null, null);
                        if (Convert.ToInt32(model.data1.Rows[0]["FeeAmount"].ToString()) < Convert.ToInt32(DisAmount))
                        {
                            ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                        }

                        Qry = "Delete from dgen.ScStFeeDetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                        cmdList.Add(Cmd);

                        foreach (ScStFeeDetails Head in model.ApplicationDetailsMeritscholarshipSchool.ScStFeeDetails)
                        {
                            Qry = "insert into dgen.ScStFeeDetails(ApplicationNo,FeeinitiateBy,FeeTypeBy,FeeAmount,UserId,IpAddress,LastActionDate) values (@ApplicationNo,@FeeinitiateBy,@FeeTypeBy,@FeeAmount,@UserId,@IpAddress,now())";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                            Cmd.Parameters.AddWithValue("@FeeTypeBy", Head.FeeTypeId);
                            Cmd.Parameters.AddWithValue("@FeeAmount", Head.FeeAmount);
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);
                        }
                    }
                    Qry = "update dgen.applicationdetailsmeritscholarshipschool set WhetherSchoolRecomended=@WhetherSchoolRecomended,WhetherVerified=@WhetherVerified,VerifiedDate=now(),SchollRemarks=@SchollRemarks,SchollRemarksBy=@SchollRemarksBy,SchollRemarksIpAddress=@SchollRemarksIpAddress,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", model.ApplicationDetailsMeritscholarshipSchool.WhetherSchoolRecomended);
                    Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@SchollRemarks", model.ApplicationDetailsMeritscholarshipSchool.SchollRemarks);
                    Cmd.Parameters.AddWithValue("@SchollRemarksBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@SchollRemarksIpAddress", Utility.GetIP4Address());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, model.ApplicationDetailsMeritscholarshipSchool.SchollRemarks, (int)ApplicationSource.Window, null));
                }
                else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.DrbrAmbedkarToppers).ToString())
                {
                    model.WhetherSchoolRecomended = model.ApplicationDetailsDrbrAmbedkarToppers.WhetherSchoolRecomended;
                    if (model.ApplicationDetailsDrbrAmbedkarToppers.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                    {
                        foreach (ScStFeeDetails Head in model.ApplicationDetailsDrbrAmbedkarToppers.ScStFeeDetails)
                        {
                            DisAmount = Head.FeeAmount;
                        }
                        model.data1 = Utility.GetSCSTScholorship(model.ApplicationNo, null, null);
                        if (Convert.ToInt32(model.data1.Rows[0]["FeeAmount"].ToString()) < Convert.ToInt32(DisAmount))
                        {
                            ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                        }

                        Qry = "Delete from dgen.ScStFeeDetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                        cmdList.Add(Cmd);
                        foreach (ScStFeeDetails Head in model.ApplicationDetailsDrbrAmbedkarToppers.ScStFeeDetails)
                        {
                            Qry = "insert into dgen.ScStFeeDetails(ApplicationNo,FeeinitiateBy,FeeTypeBy,FeeAmount,UserId,IpAddress,LastActionDate) values (@ApplicationNo,@FeeinitiateBy,@FeeTypeBy,@FeeAmount,@UserId,@IpAddress,now())";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                            Cmd.Parameters.AddWithValue("@FeeTypeBy", Head.FeeTypeId);
                            Cmd.Parameters.AddWithValue("@FeeAmount", Head.FeeAmount);
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);
                        }

                    }
                    Qry = "update dgen.applicationdetailsbrambedkar set WhetherSchoolRecomended=@WhetherSchoolRecomended,WhetherVerified=@WhetherVerified,VerifiedDate=now(),SchollRemarks=@SchollRemarks,SchollRemarksBy=@SchollRemarksBy,SchollRemarksIpAddress=@SchollRemarksIpAddress,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", model.ApplicationDetailsDrbrAmbedkarToppers.WhetherSchoolRecomended);
                    Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@SchollRemarks", model.ApplicationDetailsDrbrAmbedkarToppers.SchollRemarks);
                    Cmd.Parameters.AddWithValue("@SchollRemarksBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@SchollRemarksIpAddress", Utility.GetIP4Address());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, model.ApplicationDetailsDrbrAmbedkarToppers.SchollRemarks, (int)ApplicationSource.Window, null));
                }
                else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.MeritscholarshipProfessional).ToString())
                {
                    string whetherCon = string.Empty;
                    model.WhetherSchoolRecomended = model.ApplicationDetailsMeritProfessional.WhetherSchoolRecomended;
                    if (model.ApplicationDetailsMeritProfessional.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                    {

                        // coide for check fee from database ----commented on 11/07/2017 requested from department
                        foreach (ScStFeeDetails Head in model.ApplicationDetailsMeritProfessional.ScStFeeDetails)
                        {
                            DisAmount = Head.FeeAmount;
                        }
                        model.data1 = Utility.GetSCSTScholorship(model.ApplicationNo, null, model.ApplicationDetailsMeritProfessional.GroupId);
                        if (Convert.ToInt32(model.data1.Rows[0]["FeeAmount"].ToString()) < Convert.ToInt32(DisAmount))
                        {
                            ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                        }

                        Qry = "Delete from dgen.ScStFeeDetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                        cmdList.Add(Cmd);

                        foreach (ScStFeeDetails Head in model.ApplicationDetailsMeritProfessional.ScStFeeDetails)
                        {
                            Qry = "insert into dgen.ScStFeeDetails(ApplicationNo,FeeinitiateBy,FeeTypeBy,FeeAmount,UserId,IpAddress,LastActionDate) values (@ApplicationNo,@FeeinitiateBy,@FeeTypeBy,@FeeAmount,@UserId,@IpAddress,now())";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                            Cmd.Parameters.AddWithValue("@FeeTypeBy", Head.FeeTypeId);
                            Cmd.Parameters.AddWithValue("@FeeAmount", Head.FeeAmount);
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);
                        }
                    }
                    if (model.ApplicationDetailsMeritProfessional.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                    {
                        whetherCon = ",GroupId=@GroupId";
                    }
                    Qry = "update dgen.applicationdetailsmeritprofessional set WhetherSchoolRecomended=@WhetherSchoolRecomended" + whetherCon + ",WhetherVerified=@WhetherVerified,VerifiedDate=now(),SchollRemarks=@SchollRemarks,SchollRemarksBy=@SchollRemarksBy,SchollRemarksIpAddress=@SchollRemarksIpAddress,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", model.ApplicationDetailsMeritProfessional.WhetherSchoolRecomended);
                    Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@GroupId", model.ApplicationDetailsMeritProfessional.GroupId);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@SchollRemarks", model.ApplicationDetailsMeritProfessional.SchollRemarks);
                    Cmd.Parameters.AddWithValue("@SchollRemarksBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@SchollRemarksIpAddress", Utility.GetIP4Address());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, model.ApplicationDetailsMeritProfessional.SchollRemarks, (int)ApplicationSource.Window, null));
                }
                else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.PrematricScholarshipOBC).ToString())
                {
                    model.WhetherSchoolRecomended = model.ApplicationDetailsPrematOBC.WhetherSchoolRecomended;
                    if (model.ApplicationDetailsPrematOBC.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                    {
                        foreach (ScStFeeDetails Head in model.ApplicationDetailsPrematOBC.ScStFeeDetails)
                        {
                            DisAmount = Head.FeeAmount;
                        }
                        model.data1 = Utility.GetSCSTScholorship(model.ApplicationNo, null, null);
                        if (Convert.ToInt32(model.data1.Rows[0]["FeeAmount"].ToString()) < Convert.ToInt32(DisAmount))
                        {
                            ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                        }


                        Qry = "Delete from dgen.ScStFeeDetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                        cmdList.Add(Cmd);

                        foreach (ScStFeeDetails Head in model.ApplicationDetailsPrematOBC.ScStFeeDetails)
                        {
                            Qry = "insert into dgen.ScStFeeDetails(ApplicationNo,FeeinitiateBy,FeeTypeBy,FeeAmount,UserId,IpAddress,LastActionDate) values (@ApplicationNo,@FeeinitiateBy,@FeeTypeBy,@FeeAmount,@UserId,@IpAddress,now())";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                            Cmd.Parameters.AddWithValue("@FeeTypeBy", Head.FeeTypeId);
                            Cmd.Parameters.AddWithValue("@FeeAmount", Head.FeeAmount);
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);
                        }
                    }
                    Qry = "update dgen.ApplicationDetailsPrematOBC set WhetherSchoolRecomended=@WhetherSchoolRecomended,WhetherVerified=@WhetherVerified,VerifiedDate=now(),SchollRemarks=@SchollRemarks,SchollRemarksBy=@SchollRemarksBy,SchollRemarksIpAddress=@SchollRemarksIpAddress,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", model.ApplicationDetailsPrematOBC.WhetherSchoolRecomended);
                    Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@SchollRemarks", model.ApplicationDetailsPrematOBC.SchollRemarks);
                    Cmd.Parameters.AddWithValue("@SchollRemarksBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@SchollRemarksIpAddress", Utility.GetIP4Address());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, model.ApplicationDetailsPrematOBC.SchollRemarks, (int)ApplicationSource.Window, null));
                }
                else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.PostmatricScholarshipOBC).ToString())
                {
                    Int64 FillAmount = 0, DisburseAmount = 0, GetScholarshipAmount = 0, Nonrefundablefee = 0;
                    string whetherCon = string.Empty;
                    model.WhetherSchoolRecomended = model.ApplicationDetailsPostmatOBC.WhetherSchoolRecomended;
                    if (model.ApplicationDetailsPostmatOBC.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                    {
                        //// coide for check fee from database ----commented on 13/04/2017 from department
                        //foreach (ScStFeeDetails Head in model.ApplicationDetailsPostmatOBC.ScStFeeDetails)
                        //{
                        //    DisAmount = Head.FeeAmount;
                        //}
                        //model.data1 = Utility.GetSCSTScholorship(model.ApplicationNo, null, model.ApplicationDetailsPostmatOBC.GroupId);
                        //if (Convert.ToInt32(model.data1.Rows[0]["FeeAmount"].ToString()) < Convert.ToInt32(DisAmount))
                        //{
                        //    ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                        //    PreserveModelState(Constant._ModelStateParent, null, true, false);
                        //    return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                        //} 
                        string WhetherHostler = Utility.SelectColumnsValue("dgen.applicationdetailspostmatobc", "WhetherHostler", "ApplicationNo", model.ApplicationNo)[0];
                        foreach (ScStFeeDetails Head in model.ApplicationDetailsPostmatOBC.ScStFeeDetails)
                        {
                            DisburseAmount = DisburseAmount + Convert.ToInt64(Head.FeeAmount);
                        }
                        if (WhetherHostler.ToUpper() == CustomText.TRUE.ToString() && DisburseAmount > 30000)
                        {
                            ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                        }
                        if (WhetherHostler.ToUpper() == CustomText.FALSE.ToString() && DisburseAmount > 25000)
                        {
                            ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                        }


                        Qry = "Select FeeAmount from dgen.ScStFeeDetails Where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Applicant);
                        DataTable dt = data.GetDataTable(Cmd);
                        if (dt != null)
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                FillAmount = FillAmount + Convert.ToInt64(dt.Rows[i]["FeeAmount"].ToString());
                            }
                        }

                        model.data1 = Utility.GetSCSTScholorship(model.ApplicationNo, null, model.ApplicationDetailsPostmatOBC.GroupId);
                        if (model.data1 != null)
                        {
                            for (int i = 0; i < model.data1.Rows.Count; i++)
                            {
                                GetScholarshipAmount = GetScholarshipAmount + Convert.ToInt64(model.data1.Rows[i]["FeeAmount"].ToString());
                                FillAmount = FillAmount + Convert.ToInt64(model.data1.Rows[i]["FeeAmount"].ToString());

                            }
                        }
                        Nonrefundablefee = DisburseAmount - GetScholarshipAmount;
                        if (Nonrefundablefee > 20000)
                        {
                            ViewBag.DisplayMessage = "The Non Refundable Course Fee is Not Allowed More Than 20000 !!!";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                        }

                        Dictionary<string, string> Data = new Dictionary<string, string>();
                        Data.Add("DisAmount", DisburseAmount.ToString());
                        Data.Add("FillAmount", FillAmount.ToString());
                        bool chececkresult = Utility.CheckEligibilitySCSTService(Data, model.ApplicationDetails.ServiceCode, (int)CountList.Type001);
                        if (chececkresult == false)
                        {
                            ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                        }

                        Qry = "Delete from dgen.ScStFeeDetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                        cmdList.Add(Cmd);

                        foreach (ScStFeeDetails Head in model.ApplicationDetailsPostmatOBC.ScStFeeDetails)
                        {
                            Qry = "insert into dgen.ScStFeeDetails(ApplicationNo,FeeinitiateBy,FeeTypeBy,FeeAmount,UserId,IpAddress,LastActionDate) values (@ApplicationNo,@FeeinitiateBy,@FeeTypeBy,@FeeAmount,@UserId,@IpAddress,now())";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                            Cmd.Parameters.AddWithValue("@FeeTypeBy", Head.FeeTypeId);
                            Cmd.Parameters.AddWithValue("@FeeAmount", Head.FeeAmount);
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);
                        }
                    }
                    if (model.ApplicationDetailsPostmatOBC.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                    {
                        whetherCon = ",GroupId=@GroupId";
                    }
                    Qry = "update dgen.applicationdetailspostmatobc set WhetherSchoolRecomended=@WhetherSchoolRecomended" + whetherCon + ",WhetherVerified=@WhetherVerified,VerifiedDate=now(),SchollRemarks=@SchollRemarks,SchollRemarksBy=@SchollRemarksBy,SchollRemarksIpAddress=@SchollRemarksIpAddress,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", model.ApplicationDetailsPostmatOBC.WhetherSchoolRecomended);
                    Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@GroupId", model.ApplicationDetailsPostmatOBC.GroupId);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@SchollRemarks", model.ApplicationDetailsPostmatOBC.SchollRemarks);
                    Cmd.Parameters.AddWithValue("@SchollRemarksBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@SchollRemarksIpAddress", Utility.GetIP4Address());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, model.ApplicationDetailsPostmatOBC.SchollRemarks, (int)ApplicationSource.Window, null));
                    
                }
                else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.PrematricSC).ToString())
                {
                    model.WhetherSchoolRecomended = model.ApplicationDetailsPrematSCssd.WhetherSchoolRecomended;
                    if (model.ApplicationDetailsPrematSCssd.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                    {
                        foreach (ScStFeeDetails Head in model.ApplicationDetailsPrematSCssd.ScStFeeDetails)
                        {
                            DisAmount = Head.FeeAmount;
                        }
                        model.data1 = Utility.GetSCSTScholorship(model.ApplicationNo, null, null);
                        if (Convert.ToInt32(model.data1.Rows[0]["FeeAmount"].ToString()) < Convert.ToInt32(DisAmount))
                        {
                            ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                        }


                        Qry = "Delete from dgen.ScStFeeDetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                        cmdList.Add(Cmd);

                        foreach (ScStFeeDetails Head in model.ApplicationDetailsPrematSCssd.ScStFeeDetails)
                        {
                            Qry = "insert into dgen.ScStFeeDetails(ApplicationNo,FeeinitiateBy,FeeTypeBy,FeeAmount,UserId,IpAddress,LastActionDate) values (@ApplicationNo,@FeeinitiateBy,@FeeTypeBy,@FeeAmount,@UserId,@IpAddress,now())";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                            Cmd.Parameters.AddWithValue("@FeeTypeBy", Head.FeeTypeId);
                            Cmd.Parameters.AddWithValue("@FeeAmount", Head.FeeAmount);
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);
                        }
                    }
                    Qry = "update dgen.ApplicationDetailsPrematSCssd set WhetherSchoolRecomended=@WhetherSchoolRecomended,WhetherVerified=@WhetherVerified,VerifiedDate=now(),SchollRemarks=@SchollRemarks,SchollRemarksBy=@SchollRemarksBy,SchollRemarksIpAddress=@SchollRemarksIpAddress,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", model.ApplicationDetailsPrematSCssd.WhetherSchoolRecomended);
                    Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@SchollRemarks", model.ApplicationDetailsPrematSCssd.SchollRemarks);
                    Cmd.Parameters.AddWithValue("@SchollRemarksBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@SchollRemarksIpAddress", Utility.GetIP4Address());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, model.ApplicationDetailsPrematSCssd.SchollRemarks, (int)ApplicationSource.Window, null));
                }
                else if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.PostmatricSC).ToString())
                {
                    Int64 FillAmount = 0, DisburseAmount = 0;
                    string whetherCon = string.Empty;
                    model.WhetherSchoolRecomended = model.ApplicationDetailsPostmatSCssd.WhetherSchoolRecomended;
                    if (model.ApplicationDetailsPostmatSCssd.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                    {
                        //// coide for check fee from database ----commented on 13/04/2017 from department
                        //foreach (ScStFeeDetails Head in model.ApplicationDetailsPostmatOBC.ScStFeeDetails)
                        //{
                        //    DisAmount = Head.FeeAmount;
                        //}
                        //model.data1 = Utility.GetSCSTScholorship(model.ApplicationNo, null, model.ApplicationDetailsPostmatOBC.GroupId);
                        //if (Convert.ToInt32(model.data1.Rows[0]["FeeAmount"].ToString()) < Convert.ToInt32(DisAmount))
                        //{
                        //    ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                        //    PreserveModelState(Constant._ModelStateParent, null, true, false);
                        //    return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                        //}

                        Qry = "Select FeeAmount from dgen.ScStFeeDetails Where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Applicant);
                        DataTable dt = data.GetDataTable(Cmd);
                        if (dt != null)
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                FillAmount = FillAmount + Convert.ToInt64(dt.Rows[i]["FeeAmount"].ToString());
                            }
                        }
                        foreach (ScStFeeDetails Head in model.ApplicationDetailsPostmatSCssd.ScStFeeDetails)
                        {
                            DisburseAmount = DisburseAmount + Convert.ToInt64(Head.FeeAmount);
                        }
                        model.data1 = Utility.GetSCSTScholorship(model.ApplicationNo, null, model.ApplicationDetailsPostmatSCssd.GroupId);
                        if (model.data1 != null)
                        {
                            for (int i = 0; i < model.data1.Rows.Count; i++)
                            {
                                FillAmount = FillAmount + Convert.ToInt64(model.data1.Rows[i]["FeeAmount"].ToString());
                            }
                        }
                        Dictionary<string, string> Data = new Dictionary<string, string>();
                        Data.Add("DisAmount", DisburseAmount.ToString());
                        Data.Add("FillAmount", FillAmount.ToString());
                        bool chececkresult = Utility.CheckEligibilitySCSTService(Data, model.ApplicationDetails.ServiceCode, (int)CountList.Type001);
                        if (chececkresult == false)
                        {
                            ViewBag.DisplayMessage = "The Amount Is Not Correct ";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                        }


                        Qry = "Delete from dgen.ScStFeeDetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                        cmdList.Add(Cmd);

                        foreach (ScStFeeDetails Head in model.ApplicationDetailsPostmatSCssd.ScStFeeDetails)
                        {
                            Qry = "insert into dgen.ScStFeeDetails(ApplicationNo,FeeinitiateBy,FeeTypeBy,FeeAmount,UserId,IpAddress,LastActionDate) values (@ApplicationNo,@FeeinitiateBy,@FeeTypeBy,@FeeAmount,@UserId,@IpAddress,now())";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                            Cmd.Parameters.AddWithValue("@FeeTypeBy", Head.FeeTypeId);
                            Cmd.Parameters.AddWithValue("@FeeAmount", Head.FeeAmount);
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);
                        }
                    }
                    if (model.ApplicationDetailsPostmatSCssd.WhetherSchoolRecomended.ToUpper() == CustomText.TRUE.ToString())
                    {
                        whetherCon = ",GroupId=@GroupId";
                    }
                    Qry = "update dgen.ApplicationDetailsPostmatSCssd set WhetherSchoolRecomended=@WhetherSchoolRecomended" + whetherCon + ",WhetherVerified=@WhetherVerified,VerifiedDate=now(),SchollRemarks=@SchollRemarks,SchollRemarksBy=@SchollRemarksBy,SchollRemarksIpAddress=@SchollRemarksIpAddress,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@WhetherSchoolRecomended", model.ApplicationDetailsPostmatSCssd.WhetherSchoolRecomended);
                    Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.True.ToString());
                    Cmd.Parameters.AddWithValue("@GroupId", model.ApplicationDetailsPostmatSCssd.GroupId);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@SchollRemarks", model.ApplicationDetailsPostmatSCssd.SchollRemarks);
                    Cmd.Parameters.AddWithValue("@SchollRemarksBy", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@SchollRemarksIpAddress", Utility.GetIP4Address());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, model.ApplicationDetailsPostmatSCssd.SchollRemarks, (int)ApplicationSource.Window, null));
                }

                Qry = "update dgen.prematapplicationprocess set ProcessStatusId=@ProcessStatusId,whetherrecommended=@whetherrecommended, WhetherRevertBack=@WhetherRevertBack, VerificationDate=now(),VerificationBy=@VerificationBy,VerificationIpAddress=@VerificationIpAddress where ApplicationNo=@ApplicationNo;";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@whetherrecommended", model.WhetherSchoolRecomended);
                Cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.Verified);
                Cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.False.ToString());
                Cmd.Parameters.AddWithValue("@ServiceCode", model.ApplicationDetails.ServiceCode);
                Cmd.Parameters.AddWithValue("@VerificationBy", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@VerificationIpAddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.SchollRemarks);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", ApplicationStatusId);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.SchollRemarks);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                Dictionary<string, string> smsDic = new Dictionary<string, string>();
                smsDic.Add("ParamApplicationNo", model.ApplicationNo);
                cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS031, smsDic));

                //send email to applicant and insert record in table
                Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS031).ToString());
                EmailDic.Add("ParamApplicationNo", model.ApplicationNo);
                NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                if (EmailCmd != null) { cmdList.Add(EmailCmd); }

                data.SaveData(cmdList);

                ViewData["message"] = "Application [" + model.ApplicationNo + "] has been processed successfully.";
                return View("message");
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PendingPreMatApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
        }
        [Authorize(Roles = "120")]
        [EncryptedActionParameter]
        public ActionResult AttachCourseAffiliation()
        {
            GetData data = new GetData();
            PreMatricModel model = new PreMatricModel();
            model.SchoolId = Sessions.getEmployeeUser().AuthorizationId;
            model.SchoolName = Utility.SelectColumnsValue("dgen.prematschoolmaster", "schoolname", "schoolid", model.SchoolId)[0];
            string Qry = "select a.courseid,a.coursename,a.affiliatedid,b.acount,a.UniversityName,to_char(AffiliationFrom,'DD/MM/YYYY') as AffiliationFrom,to_char(AffiliationUpto,'DD/MM/YYYY') as AffiliationUpto,a.schoolid,a.whetherapproved,a.whetheractive,case when c.enclosureid is not null then c.enclosureid else 0 end as whetherdoc from dgen.prematcoursemaster a inner join (select affiliatedid,count(*) as acount from dgen.prematcoursemaster  where schoolid=@SchoolId group by affiliatedid) b on b.affiliatedid=a.affiliatedid left outer join dgen.prematcourseenclosuredetails c on c.affiliatedid=a.affiliatedid where a.schoolid=@SchoolId group by a.courseid,a.affiliatedid,b.acount,c.enclosureid,a.coursename,a.schoolid order by a.affiliatedid,a.coursename ";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@SchoolId", model.SchoolId);
            model.data = data.GetDataTable(Cmd);
            model.AffiliatedId = string.Empty;
            return View(model);
        }
        [Authorize(Roles = "118")]
        [EncryptedActionParameter]
        public ActionResult AddSchoolForPreMatScholarship()
        {
            PreMatricModel model = new PreMatricModel();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult AddSchoolForPreMatScholarship(PreMatricModel model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string Qry = string.Empty; NpgsqlCommand Cmd = new NpgsqlCommand();
                List<CMDInfoList> cmdList = new List<CMDInfoList>();
                CMDInfoList CmdInfo = new CMDInfoList();

                Qry = "select * from dgen.PreMatSchoolMaster where lower(SchoolName)=@SchoolName and District=@District and SubDivision=@SubDivision";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@SchoolName", model.SchoolName.ToLower().Trim());
                Cmd.Parameters.AddWithValue("@District", model.District);
                Cmd.Parameters.AddWithValue("@SubDivision", model.SubDivision);
                DataTable dt = data.GetDataTable(Cmd);
                if (dt.Rows.Count > 0)
                {
                    ViewBag.DisplayMessage = "School with same name has already been added once.";
                    return View(model);
                }

                Qry = "insert into dgen.PreMatSchoolMaster(SchoolName,Schooladdress,District,Subdivision,PinCode,SchoolAffiliationId,State,MobileNo,EmailId,NodalOfficer,UserId,Ipaddress,LastActionDate) values (@SchoolName,@Schooladdress,@District,@Subdivision,@PinCode,@SchoolAffiliationId,@SchoolState,@MobileNo,@EmailId,@NodalOfficer,@UserId,@Ipaddress,now()); SELECT currval(pg_get_serial_sequence('dgen.PreMatSchoolMaster','schoolid'))";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@SchoolName", model.SchoolName.Trim());
                Cmd.Parameters.AddWithValue("@Schooladdress", model.SchoolAddress.Trim());
                Cmd.Parameters.AddWithValue("@District", model.District);
                Cmd.Parameters.AddWithValue("@Subdivision", model.SubDivision);
                Cmd.Parameters.AddWithValue("@PinCode", model.PinCode);
                Cmd.Parameters.AddWithValue("@SchoolState", model.SchoolState);
                Cmd.Parameters.AddWithValue("@SchoolAffiliationId", model.SchoolAffiliationId);
                Cmd.Parameters.AddWithValue("@MobileNo", model.MobileNo);
                Cmd.Parameters.AddWithValue("@EmailId", model.EmailId);
                Cmd.Parameters.AddWithValue("@NodalOfficer", model.NodalOfficer);
                Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                CmdInfo = new CMDInfoList();
                CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = null; CmdInfo.Returns = true;
                cmdList.Add(CmdInfo);


                string SimplePassword = Utility.GetRandomString(8, 3);
                string HashPassword = Utility.GenerateSHA512(SimplePassword).ToString().ToLower();

                Qry = "insert into dbo.usermaster(UserId,UserName,password,districtcode,permission,designation,contactno,dateofbirth,permanentaddress,presentaddress,dateofjoining,createdate,deptcode,whetherpasswordchange,lastpassowrdchange,Gender,authorizationid,AuthenticationTypeId,SigningTypeId,actionuserid,actionipaddress,actiondatetime) values(@UserId||@Parameter0,@UserName,@password,@districtcode,@permission,@designation,@contactno,now(),@permanentaddress,@presentaddress,now(),now(),now(),@deptcode,@whetherpasswordchange,now(),@Gender,@Parameter0,@AuthenticationTypeId,@SigningTypeId,@actionuserid,@actionipaddress,now()); SELECT currval(pg_get_serial_sequence('dbo.usermaster','uid'))";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@userid", "SCH");
                Cmd.Parameters.AddWithValue("@UserName", model.SchoolName.Trim());
                Cmd.Parameters.AddWithValue("@password", HashPassword);
                Cmd.Parameters.AddWithValue("@districtcode", model.District);
                Cmd.Parameters.AddWithValue("@permission", (int)Permission.P120);
                Cmd.Parameters.AddWithValue("@designation", "Nodal Officer");
                Cmd.Parameters.AddWithValue("@contactno", model.MobileNo);
                Cmd.Parameters.AddWithValue("@permanentaddress", model.SchoolAddress.Trim());
                Cmd.Parameters.AddWithValue("@presentaddress", model.SchoolAddress.Trim());
                Cmd.Parameters.AddWithValue("@Gender", Gender.M.ToString());
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept010);
                Cmd.Parameters.AddWithValue("@whetherpasswordchange", CustomText.FALSE.ToString());
                Cmd.Parameters.AddWithValue("@AuthenticationTypeId", (int)ValueId.AuthCrendential);
                Cmd.Parameters.AddWithValue("@SigningTypeId", (int)ValueId.SignNoSign);
                Cmd.Parameters.AddWithValue("@actionuserid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@actionipaddress", Utility.GetIP4Address());
                CmdInfo = new CMDInfoList();
                CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = new int[] { 0 }; CmdInfo.Returns = true;
                cmdList.Add(CmdInfo);

                Qry = "select Servicecode from servicemaster where deptcode =@deptcode and whetheractive=@whetheractive";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept010);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                DataTable dta = data.GetDataTable(Cmd);

                for (int i = 0; i < dta.Rows.Count; i++)
                {
                    Qry = "insert into dbo.usertoservicemaster(uid,servicecode,userid,ipaddress,actiondatetime) values(@Parameter1,@servicecode,@userid,@ipaddress,now()) ";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@servicecode", dta.Rows[i]["Servicecode"].ToString());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    CmdInfo = new CMDInfoList();
                    CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = new int[] { 1 }; CmdInfo.Returns = false;
                    cmdList.Add(CmdInfo);
                }
                Qry = "insert into dbo.usertosubdivmaster(uid,subdivcode,userid,ipaddress,actiondatetime) values(@Parameter1,@subdivcode,@userid,@ipaddress,now()) ";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@subdivcode", model.SubDivision);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                CmdInfo = new CMDInfoList();
                CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = new int[] { 1 }; CmdInfo.Returns = false;
                cmdList.Add(CmdInfo);

                data.SaveTransactionalDataCustom(cmdList);

                ViewData["message"] = "School/College/Institute successfully";
                return View("message");
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("AddSchoolForPreMatScholarship", (PreMatricModel)TempData[Constant._ModelStateParent]);
        }
        [Authorize(Roles = "118")]
        [EncryptedActionParameter]
        public ActionResult SchoolListForApproval()
        {
            GetData data = new GetData();
            PreMatricModel model = new PreMatricModel();
            string Qry = "select * from dgen.PreMatSchoolMaster order by SchoolName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            model.data = data.GetDataTable(Cmd);
            return View(model);
        }
        [Authorize(Roles = "118")]
        [EncryptedActionParameter]
        public ActionResult PendingCourseListForApproval()
        {
            GetData data = new GetData();
            PreMatricModel model = new PreMatricModel();
            string Qry = "select PCM.SchoolId,SchoolName, courseid,coursename,PCM.affiliatedid,UniversityName,to_char(AffiliationFrom,'DD/MM/YYYY') as AffiliationFrom,to_char(AffiliationUpto,'DD/MM/YYYY') as AffiliationUpto,Whetherapproved,PCM.Whetheractive,case when c.enclosureid is not null then c.enclosureid else 0 end as whetherdoc from dgen.PreMatCourseMaster  PCM inner join dgen.prematschoolmaster PSM on PSM.SchoolId=PCM.Schoolid left outer join dgen.prematcourseenclosuredetails c on c.affiliatedid=PCM.affiliatedid  where WhetherApproved=@WhetherApproved order by SchoolName,CourseName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.FALSE.ToString());
            model.data = data.GetDataTable(Cmd);
            return View(model);
        }
        [Authorize(Roles = "118")]
        [EncryptedActionParameter]
        public ActionResult ApprovedCourseList()
        {
            GetData data = new GetData();
            PreMatricModel model = new PreMatricModel();
            string Qry = "select PCM.SchoolId,SchoolName, courseid,coursename,PCM.affiliatedid,UniversityName,to_char(AffiliationFrom,'DD/MM/YYYY') as AffiliationFrom,to_char(AffiliationUpto,'DD/MM/YYYY') as AffiliationUpto,Whetherapproved,PCM.Whetheractive,case when c.enclosureid is not null then c.enclosureid else 0 end as whetherdoc from dgen.PreMatCourseMaster  PCM inner join dgen.prematschoolmaster PSM on PSM.SchoolId=PCM.Schoolid left outer join dgen.prematcourseenclosuredetails c on c.affiliatedid=PCM.affiliatedid  where WhetherApproved=@WhetherApproved order by SchoolName,CourseName";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.TRUE.ToString());
            model.data = data.GetDataTable(Cmd);
            return View(model);
        }
        [Authorize(Roles = "118")]
        [EncryptedActionParameter]
        public ActionResult CourseApproval(Int32 CId, Int32 SId)
        {
            GetData data = new GetData();
            PreMatricModel model = new PreMatricModel();
            string Qry = "update dgen.PreMatCourseMaster set WhetherApproved=@WhetherApproved where CourseId=@CourseId";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@WhetherApproved", CustomText.TRUE.ToString());
            Cmd.Parameters.AddWithValue("@CourseId", CId);
            data.UpdateData(Cmd);
            //string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "SId" }, new ArrayList() { SId .ToString() });
            //return RedirectToAction("CourseListForApproval", "Process", new { q = QueryString });
            return RedirectToAction("PendingCourseListForApproval", "Process");
        }
        [EncryptedActionParameter]
        public ActionResult ServiceWiseChangeDepartment()
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            string WhetherCondition = string.Empty;
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { WhetherCondition = " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { WhetherCondition = " and AD.applicationdistrictCode in (@ParamDistrictCode) "; }
            string Qry = "select SC.ServiceName,SC.ServiceCode,AD.applicationsubdivcode,count(AD.ApplicationNo) as TotalApp from dbo.ApplicationDetails AD  inner join dgen.applicationdetailsprematssc ADSC on AD.ApplicationNo=ADSC.ApplicationNo left outer join dbo.DistrictMaster DM on AD.applicationdistrictcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.applicationsubdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode " + WhetherCondition + " and AD.ServiceCode in (@ParamServiceCode) and ADSC.SchoolId is Null and AD.ApplicationStatusId Not in (@ApplicationStatusId,@ApplicationStatusId1) group by AD.applicationsubdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ApplicationStatusId1", (int)Status.ISSUCER);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult ServiceWiseChangeDepartmentList(int ServiceCode)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            string Qry = string.Empty;
            string WhetherCondition = string.Empty;
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { WhetherCondition += " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { WhetherCondition = " and AD.applicationdistrictCode in (@ParamDistrictCode) "; }

            Qry += @"select 'Out of Delhi' as SchoolName,AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,AD.ApplicantDob,AD.ApplicationStatusId from dbo.ApplicationDetails AD inner join dgen.applicationdetailsprematssc ADSC on AD.ApplicationNo=ADSC.ApplicationNo inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode where AD.ServiceCode=@ServiceCode and AD.ApplicationStatusId Not in (@ApplicationStatusId,@ApplicationStatusId1)  and ADSC.schoolid is null order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@ApplicationStatusId1", (int)Status.ISSUCER);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult ChangePrematApplicationDetails(Int64 AppNo)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            model.ApplicationNo = AppNo.ToString();
            string QueryString = string.Empty;
            string WhetherCondition = string.Empty;
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { WhetherCondition = " and applicationsubdivcode in (@ParamSubDivCode) "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { WhetherCondition = " and applicationdistrictCode in (@ParamDistrictCode) "; }
            string Qry = "select ServiceCode,ApplicationStatusId,ApplicationNo FROM dbo.ApplicationDetails where ApplicationNo=@ApplicationNo " + WhetherCondition + " and ServiceCode in (@ParamServiceCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            string[] Val = data.SelectColumns(Cmd);
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ServiceCode = Val[0];
            model.ApplicationDetails.ApplicationStatusId = Val[1];
            model.ApplicationDetails.ApplicationNo = Val[2];
            if (string.IsNullOrEmpty(model.ApplicationDetails.ApplicationNo))
            {
                PreserveModelState(Constant._ActionMessage, "Application Not Found or Not Available in you account, Kindly Check Your Application No.", false, true);
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.StatusId });
                return RedirectToAction("SearchAppForAction", new { q = QueryString });
            }
            model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());



            if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PrematricScholarshipSC)
            {
                model.ApplicationDetailsPrematsSC = Utility.GetPrematsSCDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                model.ApplicationDetailsPrematsSC.ScStFeeDetails = new List<ScStFeeDetails>();
                Qry = @"select a.servicecode,a.feetypeby,b.valuename,coalesce(c.feeamount,0) as feeamount from prematservicetofeehead a inner join selectmastervaluedetails b on b.valueid=a.feetypeby 
                            left outer join dgen.scstfeedetails c on c.feetypeby=a.feetypeby and c.feeinitiateby=@feeinitiateby and c.applicationno=@ApplicationNo where ServiceCode=@ServiceCode";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.PrematricScholarshipSC);
                Cmd.Parameters.AddWithValue("@feeinitiateby", (int)ValueId.Department);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
                DataTable Dt1 = data.GetDataTable(Cmd);

                for (int i = 0; i < Dt1.Rows.Count; i++)
                {
                    model.ApplicationDetailsPrematsSC.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
                }
            }

            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", string.Empty, string.Empty, model.ApplicationDetails.ApplicationNo, DB.LS.ToString(), CustomText.N.ToString());

            ViewData[KeyName._Key01] = Utility.GetPhotoDetails(string.Empty, string.Empty, string.Empty, string.Empty, model.ApplicationDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ChangePrematApplicationDetails(ProcessModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Qry = string.Empty, ApplicationStatusId = string.Empty;


                if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.PrematricScholarshipSC)
                {
                    Qry = "update dgen.ApplicationDetailsPrematsSC set DepartmentId=@DepartmentId,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@DepartmentId", model.ApplicationDetailsPrematsSC.DepartmentId);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                }

                data.SaveData(cmdList);

                ViewData["message"] = "Application [" + model.ApplicationNo + "] has been processed successfully.";
                return View("message");
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("ChangePrematApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
        }
        [EncryptedActionParameter]
        public ActionResult ApplyPrematRelatedService(Int64 AppNo, int ServiceCode)
        {
            ProcessModels model = new ProcessModels();
            GetData data = new GetData();
            TempData[Constant._FinalSubmitActionId] = null;
            model.ApplicationNo = AppNo.ToString();
            model.ServiceCode = ServiceCode.ToString();
            string Qry = "select ServiceName from ServiceMaster where ServiceCode=@ServiceCode";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
            model.data1 = data.GetDataTable(Cmd);
            model.data = Utility.CheckPrematRelatedService(AppNo.ToString(), ServiceCode.ToString());
            if (model.data != null)
            {
                if (model.data.Rows.Count > 0) { return View(model); }
            }
            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo", "IsPrint" }, new ArrayList() { AppNo.ToString(), "0" });
            return RedirectToAction("RevenueApplicationReciept", "Print", new { q = QueryString }); 

        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult ApplyPrematRelatedService(ProcessModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string Qry = string.Empty, RegistrationId = string.Empty;
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                if (Convert.ToInt32(model.ServiceCode) != (int)ServiceList.PrematricScholarshipSC)
                {
                    RegistrationId = Utility.SelectColumnsValue("dbo.applicationdetails", "RegistrationId", "ApplicationNo", model.ApplicationNo)[0];
                    Qry = "select Applicationno from dbo.applicationdetails where RegistrationId=@RegistrationId and ServiceCode=@ServiceCode";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@RegistrationId", RegistrationId);
                    Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.PrematricScholarshipSC);
                    DataTable dt1 = data.GetDataTable(Cmd);
                    model.ApplicationNo = dt1.Rows[0]["Applicationno"].ToString();
                }

                model.ApplicationDetails = new ApplicationDetails();
                Qry = "select ApplicationNo,ServiceCode,ApplicationRelatedId,ApplicantName,ApplicantGender,RegistrationId,ApplicantFatherName,ApplicantMotherName,ApplicantHusbandName,ApplicantMobileNo,ApplicantHousenumber,ApplicantStreetnumber,ApplicantSublocality,stateid,countryid,ApplicantPinCode,to_char(ApplicantDob,'DD/MM/YYYY') as ApplicantDob,ApplicantLocalityId,ApplicantSubdivCode,ApplicantDistrictCode,ApplicantNationality,applicationsubdivcode,applicationdistrictcode,ApplicantPermanentAddress,WhetherSameAddress,officecode,dbo.udf_general_decrypt(DocumentNo) as DocumentNo,DocumentId FROM dbo.ApplicationDetails where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.ApplicationDetails = ApplicationDetails.Get<ApplicationDetails>(new ApplicationDetails(), Cmd);

                //check duplciate mobile no at application
                string ReturnMsg = Utility.CheckDuplicateAppMobileNo(model.ApplicationDetails.ApplicantMobileNo, null);
                if (!string.IsNullOrEmpty(ReturnMsg))
                {
                    ViewData["message"] = ReturnMsg;
                    return View("message");
                }

                Qry = "select PhotoId,RefPhotoId,RelatedId,WhetherActive from dbo.ApplicationPhotoMaster where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                DataTable dtPhoto = data.GetDataTable(Cmd);

                //select data from citizen ApplicationEnclosureDetails
                Qry = "select ServiceCode,DocumentTypeId,DocumentId,dbo.udf_general_decrypt(DocumentNo) as DocumentNo,DocumentData,ContentType,DepartmentId,OtherDepartment,RelatedId,WhetherVerified,WhetherActive,WhetherMandatory,ReferenceEnclosureId from dbo.ApplicationEnclosureDetails where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                DataTable dtEnclosure = data.GetDataTable(Cmd);

                Qry = "insert into web.ApplicationDetails(RegistrationID,ServiceCode,ApplicationRelatedId,ApplicantName,ApplicantGender,ApplicantFatherName,ApplicantMotherName,ApplicantHusbandName,ApplicantMobileNo,applicanthousenumber,applicantstreetnumber,applicantsublocality,stateid,countryid,ApplicantPinCode,ApplicantDob,ApplicantLocalityId,applicantsubdivcode,ApplicantDistrictCode,ApplicantNationality,ApplicationStatusId,applicationsubdivcode,applicationdistrictcode,ApplicationDate,ApplicantPermanentAddress,WhetherSameAddress,DocumentNo,DocumentId,receiveduser,receivedpermission,userid,ipaddress,actiondatetime) values(@RegistrationID,@ServiceCode,@ApplicationRelatedId,@ApplicantName,@ApplicantGender,@ApplicantFatherName,@ApplicantMotherName,@ApplicantHusbandName,@ApplicantMobileNo,@applicanthouseno,@applicantstreetno,@applicantsublocality,@stateid,@countryid,@ApplicantPinCode,@ApplicantDob,@ApplicantLocalityId,@ApplicantSubDivCode,@ApplicantDistrictCode,@ApplicantNationality,@ApplicationStatusId,@applicationsubdivcode,@applicationdistrictcode,now(),@ApplicantPermanentAddress,@WhetherSameAddress,dbo.udf_general_encrypt(@DocumentNo),@DocumentId,@receiveduser,@receivedpermission,@userid,@ipaddress,now()); SELECT currval(pg_get_serial_sequence('web.ApplicationDetails','applicationid'))";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RegistrationID", model.ApplicationDetails.RegistrationId);
                if (frm["rad"] != null)
                {
                    if (Convert.ToInt32(frm["rad"].ToString()) == (int)ServiceList.FinancialAssistanceStationery) { Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.FinancialAssistanceStationery); }
                    if (Convert.ToInt32(frm["rad"].ToString()) == (int)ServiceList.MeritscholarshipSchool) { Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.MeritscholarshipSchool); }
                }
                Cmd.Parameters.AddWithValue("@ApplicationRelatedId", model.ApplicationDetails.ApplicationRelatedId);
                Cmd.Parameters.AddWithValue("@DocumentNo", model.ApplicationDetails.DocumentNo);
                Cmd.Parameters.AddWithValue("@DocumentId", model.ApplicationDetails.DocumentId);
                Cmd.Parameters.AddWithValue("@ApplicantName", model.ApplicationDetails.ApplicantName.ToUpper());
                Cmd.Parameters.AddWithValue("@ApplicantGender", model.ApplicationDetails.ApplicantGender.ToUpper());
                Cmd.Parameters.AddWithValue("@ApplicantFatherName", model.ApplicationDetails.ApplicantFatherName.ToUpper());
                Cmd.Parameters.AddWithValue("@ApplicantMotherName", model.ApplicationDetails.ApplicantMotherName.ToUpper());
                Cmd.Parameters.AddWithValue("@ApplicantHusbandName", model.ApplicationDetails.ApplicantHusbandName);
                Cmd.Parameters.AddWithValue("@ApplicantMobileNo", model.ApplicationDetails.ApplicantMobileNo);
                Cmd.Parameters.AddWithValue("@applicanthouseno", model.ApplicationDetails.ApplicantHouseNumber);
                Cmd.Parameters.AddWithValue("@applicantstreetno", model.ApplicationDetails.ApplicantStreetNumber);
                Cmd.Parameters.AddWithValue("@applicantsublocality", model.ApplicationDetails.ApplicantSubLocality);
                Cmd.Parameters.AddWithValue("@stateid", model.ApplicationDetails.StateId);
                Cmd.Parameters.AddWithValue("@countryid", model.ApplicationDetails.CountryId);
                Cmd.Parameters.AddWithValue("@ApplicantPinCode", model.ApplicationDetails.ApplicantPinCode);
                Cmd.Parameters.AddWithValue("@ApplicantDob", Utility.GetDateYYYYMMDD(model.ApplicationDetails.ApplicantDob, '/', "0/1/2"));
                Cmd.Parameters.AddWithValue("@ApplicantLocalityId", model.ApplicationDetails.ApplicantLocalityId);
                Cmd.Parameters.AddWithValue("@ApplicantSubDivCode", model.ApplicationDetails.ApplicantSubDivCode);
                Cmd.Parameters.AddWithValue("@ApplicantDistrictCode", model.ApplicationDetails.ApplicantDistrictCode);
                Cmd.Parameters.AddWithValue("@ApplicantNationality", model.ApplicationDetails.ApplicantNationality);
                Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.SCOM032);
                Cmd.Parameters.AddWithValue("@applicationsubdivcode", model.ApplicationDetails.ApplicationSubDivCode);
                Cmd.Parameters.AddWithValue("@applicationdistrictcode", model.ApplicationDetails.ApplicationDistrictCode);
                Cmd.Parameters.AddWithValue("@WhetherSameAddress", model.ApplicationDetails.WhetherSameAddress);
                Cmd.Parameters.AddWithValue("@ApplicantPermanentAddress", model.ApplicationDetails.ApplicantPermanentAddress);
                Cmd.Parameters.AddWithValue("@receiveduser", Sessions.getCurrentUser().RegistrationId);
                Cmd.Parameters.AddWithValue("@receivedpermission", (int)Permission.CITZ);
                Cmd.Parameters.AddWithValue("@userid", Sessions.getCurrentUser().RegistrationId);
                Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                cmdList.Add(Cmd);

                //insert data in into ApplicationPhotoMaster
                for (int i = 0; i < dtPhoto.Rows.Count; i++)
                {
                    Qry = "insert into web.ApplicationPhotoMaster(ApplicationId,refphotoid,RelatedId,WhetherActive,userid,ipaddress,actiondatetime) values(@LastInsertedId,@refphotoid,@RelatedId,@WhetherActive,@userid,@ipaddress,now())";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@refphotoid", dtPhoto.Rows[i]["refphotoid"]);
                    Cmd.Parameters.AddWithValue("@RelatedId", dtPhoto.Rows[i]["RelatedId"]);
                    Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getCurrentUser().RegistrationId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                }

                //insert data in into ApplicationEnclosureDetails
                for (int i = 0; i < dtEnclosure.Rows.Count; i++)
                {
                    Qry = "insert into web.ApplicationEnclosureDetails(ApplicationId,ServiceCode,DocumentTypeId,DocumentId,DocumentNo,DocumentData,DepartmentId,OtherDepartment,ContentType,RelatedId,WhetherVerified,WhetherActive,WhetherMandatory,ReferenceEnclosureId,userid,ipaddress,actiondatetime) values(@LastInsertedId,@ServiceCode,@DocumentTypeId,@DocumentId,dbo.udf_general_encrypt(@DocumentNo),@DocumentData,@DepartmentId,@OtherDepartment,@ContentType,@RelatedId,@WhetherVerified,@WhetherActive,@WhetherMandatory,@ReferenceEnclosureId,@userid,@ipaddress,now())";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ServiceCode", dtEnclosure.Rows[i]["ServiceCode"].ToString());
                    Cmd.Parameters.AddWithValue("@DocumentTypeId", dtEnclosure.Rows[i]["DocumentTypeId"].ToString());
                    Cmd.Parameters.AddWithValue("@DocumentId", (string.IsNullOrEmpty(dtEnclosure.Rows[i]["DocumentId"].ToString())) ? null : dtEnclosure.Rows[i]["DocumentId"].ToString());
                    Cmd.Parameters.AddWithValue("@DocumentNo", (string.IsNullOrEmpty(dtEnclosure.Rows[i]["DocumentNo"].ToString())) ? null : dtEnclosure.Rows[i]["DocumentNo"].ToString());
                    Cmd.Parameters.AddWithValue("@DocumentData", dtEnclosure.Rows[i]["DocumentData"] == DBNull.Value ? null : (byte[])dtEnclosure.Rows[i]["DocumentData"]);
                    Cmd.Parameters.AddWithValue("@ContentType", (string.IsNullOrEmpty(dtEnclosure.Rows[i]["ContentType"].ToString())) ? null : dtEnclosure.Rows[i]["ContentType"].ToString());
                    Cmd.Parameters.AddWithValue("@DepartmentId", (string.IsNullOrEmpty(dtEnclosure.Rows[i]["DepartmentId"].ToString())) ? null : dtEnclosure.Rows[i]["DepartmentId"].ToString());
                    Cmd.Parameters.AddWithValue("@OtherDepartment", (string.IsNullOrEmpty(dtEnclosure.Rows[i]["OtherDepartment"].ToString())) ? null : dtEnclosure.Rows[i]["OtherDepartment"].ToString());
                    Cmd.Parameters.AddWithValue("@RelatedId", dtEnclosure.Rows[i]["RelatedId"]);
                    Cmd.Parameters.AddWithValue("@WhetherVerified", dtEnclosure.Rows[i]["WhetherVerified"].ToString());
                    Cmd.Parameters.AddWithValue("@WhetherActive", dtEnclosure.Rows[i]["WhetherActive"].ToString());
                    Cmd.Parameters.AddWithValue("@WhetherMandatory", dtEnclosure.Rows[i]["WhetherMandatory"].ToString());
                    Cmd.Parameters.AddWithValue("@ReferenceEnclosureId", dtEnclosure.Rows[i]["ReferenceEnclosureId"]);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getCurrentUser().RegistrationId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);
                }

                if (frm["rad"] != null)
                {
                    model.ApplicationDetailsPrematsSC = new ApplicationDetailsPrematsSC();
                    Qry = "select * from dgen.ApplicationDetailsPrematsSC where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
                    model.ApplicationDetailsPrematsSC = ApplicationDetailsPrematsSC.Get<ApplicationDetailsPrematsSC>(new ApplicationDetailsPrematsSC(), Cmd);

                    if (Convert.ToInt32(frm["rad"].ToString()) == (int)ServiceList.FinancialAssistanceStationery)
                    {
                        Dictionary<string, string> Data = new Dictionary<string, string>();
                        Data.Add("AnnualIncome", model.ApplicationDetailsPrematsSC.AnnualIncome);
                        if (model.ApplicationDetailsPrematsSC.PresentClass == ((int)ValueId.IstClass).ToString()) { model.ApplicationDetailsPrematsSC.AttendancePercentage = "80"; }
                        Data.Add("AttendancePercentage", model.ApplicationDetailsPrematsSC.AttendancePercentage);

                        bool chececkresult = Utility.CheckEligibilitySCSTService(Data, ((int)ServiceList.FinancialAssistanceStationery).ToString(), (int)CountList.Type000);
                        if (chececkresult == false)
                        {
                            ViewData["message"] = "The Details You Enter Not Eligible For this Service, Please Check The Eligibility Criteria";
                            return View("message");

                        }
                    }

                    if (Convert.ToInt32(frm["rad"].ToString()) == (int)ServiceList.MeritscholarshipSchool)
                    {
                        Dictionary<string, string> Data = new Dictionary<string, string>();
                        Data.Add("ClassId", model.ApplicationDetailsPrematsSC.PresentClass);
                        Data.Add("AnnualIncome", model.ApplicationDetailsPrematsSC.AnnualIncome);
                        Data.Add("CategoryId", model.ApplicationDetailsPrematsSC.CategoryId);

                        if (model.ApplicationDetailsPrematsSC.MarksPercentage == ((int)ValueId.IstClass).ToString()) { model.ApplicationDetailsPrematsSC.MarksPercentage = "80"; }
                        Data.Add("MarksPercentage", model.ApplicationDetailsPrematsSC.MarksPercentage);

                        bool chececkresult = Utility.CheckEligibilitySCSTService(Data, ((int)ServiceList.MeritscholarshipSchool).ToString(), (int)CountList.Type000);
                        if (chececkresult == false)
                        {
                            ViewData["message"] = "The Details You Enter Not Eligible For this Service, Please Check The Eligibility Criteria";
                            return View("message");
                        }
                    }

                    if (Convert.ToInt32(frm["rad"].ToString()) == (int)ServiceList.FinancialAssistanceStationery) { Qry = "insert into wgen.ApplicationDetailsFinancialAssistance(ApplicationId,AcademicSession,Annualincome,NameAsPerSchool,Applyingfor,WhetherpanNo,PanNo,CategoryId,SchoolTypeId,DepartmentId,SchoolId,Presentclass,Previousclass,Yearclasspassed,Attendancepercentage,AccountholderName,AccountNo,Bankcode,Ifsccode,Micrcode,WhetherIssuedFromDelhi,CasteCerNo,CasteCerIssueDate,DomicileCerNo,DomicileCerIssueDate,WhetherCasteVerified,Declarationid,UserId,IpAddress,LastActionDate) values (@LastInsertedId,@AcademicSession,@Annualincome,@NameAsPerSchool,@Applyingfor,@WhetherpanNo,@PanNo,@CategoryId,@SchoolTypeId,@DepartmentId,@SchoolId,@Presentclass,@Previousclass,@Yearclasspassed,@Attendancepercentage,@AccountholderName,@AccountNo,@Bankcode,@Ifsccode,@Micrcode,@WhetherIssuedFromDelhi,@CasteCerNo,@CasteCerIssueDate,@DomicileCerNo,@DomicileCerIssueDate,@WhetherCasteVerified,@Declarationid,@UserId,@IpAddress,now())"; }
                    if (Convert.ToInt32(frm["rad"].ToString()) == (int)ServiceList.MeritscholarshipSchool) { Qry = "insert into wgen.ApplicationDetailsmeritScholarshipSchool(ApplicationId,AcademicSession,Annualincome,NameAsPerSchool,Applyingfor,WhetherpanNo,PanNo,CategoryId,SchoolTypeId,DepartmentId,SchoolId,Presentclass,Previousclass,Yearclasspassed,MarksPercentage,Attendancepercentage,AccountholderName,AccountNo,Bankcode,Ifsccode,Micrcode,WhetherIssuedFromDelhi,CasteCerNo,CasteCerIssueDate,DomicileCerNo,DomicileCerIssueDate,WhetherCasteVerified,Declarationid,UserId,IpAddress,LastActionDate) values (@LastInsertedId,@AcademicSession,@Annualincome,@NameAsPerSchool,@Applyingfor,@WhetherpanNo,@PanNo,@CategoryId,@SchoolTypeId,@DepartmentId,@SchoolId,@Presentclass,@Previousclass,@Yearclasspassed,@MarksPercentage,@Attendancepercentage,@AccountholderName,@AccountNo,@Bankcode,@Ifsccode,@Micrcode,@WhetherIssuedFromDelhi,@CasteCerNo,@CasteCerIssueDate,@DomicileCerNo,@DomicileCerIssueDate,@WhetherCasteVerified,@Declarationid,@UserId,@IpAddress,now())"; }
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@Applyingfor", model.ApplicationDetailsPrematsSC.ApplyingFor);
                    Cmd.Parameters.AddWithValue("@AcademicSession", model.ApplicationDetailsPrematsSC.AcademicSession);
                    Cmd.Parameters.AddWithValue("@NameAsPerSchool", model.ApplicationDetailsPrematsSC.NameAsPerSchool);
                    Cmd.Parameters.AddWithValue("@Annualincome", model.ApplicationDetailsPrematsSC.AnnualIncome);
                    Cmd.Parameters.AddWithValue("@WhetherpanNo", model.ApplicationDetailsPrematsSC.WhetherPANNo);
                    Cmd.Parameters.AddWithValue("@PanNo", model.ApplicationDetailsPrematsSC.PANNo);
                    Cmd.Parameters.AddWithValue("@CategoryId", model.ApplicationDetailsPrematsSC.CategoryId);
                    Cmd.Parameters.AddWithValue("@SchoolId", model.ApplicationDetailsPrematsSC.SchoolId);
                    Cmd.Parameters.AddWithValue("@SchoolTypeId", model.ApplicationDetailsPrematsSC.SchoolTypeId);
                    Cmd.Parameters.AddWithValue("@DepartmentId", model.ApplicationDetailsPrematsSC.DepartmentId);
                    Cmd.Parameters.AddWithValue("@Presentclass", model.ApplicationDetailsPrematsSC.PresentClass);
                    Cmd.Parameters.AddWithValue("@Previousclass", model.ApplicationDetailsPrematsSC.PreviousClass);
                    Cmd.Parameters.AddWithValue("@Yearclasspassed", model.ApplicationDetailsPrematsSC.YearClassPassed);
                    Cmd.Parameters.AddWithValue("@MarksPercentage", model.ApplicationDetailsPrematsSC.MarksPercentage);
                    Cmd.Parameters.AddWithValue("@Attendancepercentage", model.ApplicationDetailsPrematsSC.AttendancePercentage);
                    Cmd.Parameters.AddWithValue("@AccountholderName", model.ApplicationDetailsPrematsSC.AccountHolderName);
                    Cmd.Parameters.AddWithValue("@AccountNo", model.ApplicationDetailsPrematsSC.AccountNo);
                    Cmd.Parameters.AddWithValue("@Bankcode", model.ApplicationDetailsPrematsSC.BankCode);
                    Cmd.Parameters.AddWithValue("@Ifsccode", model.ApplicationDetailsPrematsSC.IFSCCode);
                    Cmd.Parameters.AddWithValue("@Micrcode", model.ApplicationDetailsPrematsSC.MICRCode);
                    Cmd.Parameters.AddWithValue("@WhetherIssuedFromDelhi", model.ApplicationDetailsPrematsSC.WhetherIssuedFromDelhi);
                    Cmd.Parameters.AddWithValue("@WhetherCasteVerified", model.ApplicationDetailsPrematsSC.WhetherCasteVerified);
                    Cmd.Parameters.AddWithValue("@CasteCerNo", model.ApplicationDetailsPrematsSC.CasteCerNo);
                    Cmd.Parameters.AddWithValue("@CasteCerIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationDetailsPrematsSC.CasteCerIssueDate, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@DomicileCerNo", model.ApplicationDetailsPrematsSC.DomicileCerNo);
                    Cmd.Parameters.AddWithValue("@DomicileCerIssueDate", Utility.GetDateYYYYMMDD(model.ApplicationDetailsPrematsSC.DomicileCerIssueDate, '/', "0/1/2"));
                    Cmd.Parameters.AddWithValue("@Declarationid", (int)ValueId.Declaration);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getCurrentUser().RegistrationId);
                    Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                }

                model.ApplicationDetails.ApplicationId = Convert.ToInt32(data.SaveTransactionalData(cmdList)[1]);

                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppId" }, new ArrayList() { model.ApplicationDetails.ApplicationId });
                return RedirectToAction("SubmitFinalAppication", "Receiving", new { q = QueryString });

            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View((ProcessModels)TempData[Constant._ModelStateParent]);
        }
        public ActionResult PendingForSanctionProcessSummary(int? AcademicSession = 0)
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.P110).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            model.ApplicationDetailsPrematsSC = new ApplicationDetailsPrematsSC();
            string join = string.Empty, cond = string.Empty;

            if (!string.IsNullOrEmpty(model.AcademicSession)) { AcademicSession = Convert.ToInt32(model.AcademicSession); }
            string Qry = string.Empty;
            NpgsqlCommand cmd = new NpgsqlCommand();
            if (AcademicSession == (int)CountList.Type000)
            {
                ////----------------------Temp comment for 2017-18 session, un-comment when you wants to process for 2017-18
                //Qry = "select s1.valuename from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename";
                //cmd = new NpgsqlCommand(Qry);
                //cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SCSTWelfareAcadmicSession);
                //AcademicSession = Convert.ToInt32(data.SelectColumns(cmd)[0]);

                AcademicSession = 2016;
            }

            Qry = "select AD.ServiceCode,ServiceName,sum(case when ApplicationStatusId=@ApplicationStatusId and ProcessstatusId<>@Verified then 1 else 0 end) as Approved,sum(case when ApplicationStatusId=@ApplicationStatusId and ProcessstatusId=@PFMSValidateComplete then 1 else 0 end) as ValidatePFMS,sum(case when ApplicationStatusId=@ApplicationStatusId and ProcessstatusId=@PFMSFileGenerated  then 1 else 0 end) as PendingResponse,sum(case when ApplicationStatusId=@ApplicationStatusId and ProcessstatusId=@Approved  then 1 else 0 end) as PendingForValidate,sum(case when ApplicationStatusId=@ApplicationStatusId and ProcessstatusId in (@SanctionIssued,@SanctionProcessed)  then 1 else 0 end) as SanctionProcessed from applicationdetails AD inner join dgen.PrematApplicationProcess  PAP on PAP.ApplicationNo=AD.ApplicationNo inner join (select applicationno,sum(feeamount) as feeamount from dgen.scstfeedetails where FeeinitiateBy=@FeeinitiateBy group by applicationno)  SCSTFD on SCSTFD.applicationNo=AD.ApplicationNo inner join ServiceMaster Sm on SM.ServiceCode=AD.ServiceCode left outer join dgen.prematschoolmaster PSM on PSM.SchoolId = PAP.SchoolId left outer join SelectMasterValueDetails SMVD on SMVD.ValueId=PAP.ProcessstatusId left outer join dgen.prematdistrictmaster PDM on PDM.DistrictId = PSM.District left outer join dgen.prematzonemaster PZM on PZM.ZoneId = PSM.SubDivision  where AD.ServiceCode in (@ParamServiceCode) ";
            if (AcademicSession != (int)CountList.Type000) { Qry += " and PAP.AcademicSession=@Academicsession "; }
            Qry += " group by ServiceName,AD.ServiceCode order by ServiceName";
            cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@Verified", (int)ValueId.Verified);
            cmd.Parameters.AddWithValue("@Approved", (int)ValueId.Approved);
            cmd.Parameters.AddWithValue("@PFMSFileGenerated", (int)ValueId.PFMSFileGenerated);
            cmd.Parameters.AddWithValue("@PFMSValidateComplete", (int)ValueId.PFMSValidateComplete);
            cmd.Parameters.AddWithValue("@SanctionProcessed", (int)ValueId.SanctionProcessed);
            cmd.Parameters.AddWithValue("@SanctionIssued", (int)ValueId.SanctionIssued);
            cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
            if (AcademicSession != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@Academicsession", AcademicSession); }
            model.data = data.GetDataTable(cmd);
            model.SCSTDepartmentId = ((int)CountList.Type000).ToString();
            model.SCSTDistrictId = ((int)CountList.Type000).ToString();
            model.SCSTZoneId = ((int)CountList.Type000).ToString();
            model.SchoolId = ((int)CountList.Type000).ToString();
            model.CategoryId = ((int)CountList.Type000).ToString();
            model.AcademicSession = AcademicSession.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingForSanctionProcessSummary(ProcessModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                string cond = string.Empty;

                string Qry = "select AD.ServiceCode,ServiceName,sum(case when ApplicationStatusId=@ApplicationStatusId and ProcessstatusId<>@Verified then 1 else 0 end) as Approved,sum(case when ApplicationStatusId=@ApplicationStatusId and ProcessstatusId=@PFMSValidateComplete then 1 else 0 end) as ValidatePFMS,sum(case when ApplicationStatusId=@ApplicationStatusId and ProcessstatusId=@PFMSFileGenerated  then 1 else 0 end) as PendingResponse,sum(case when ApplicationStatusId=@ApplicationStatusId and ProcessstatusId=@Approved  then 1 else 0 end) as PendingForValidate,sum(case when ApplicationStatusId=@ApplicationStatusId and ProcessstatusId in (@SanctionIssued,@SanctionProcessed)  then 1 else 0 end) as SanctionProcessed from applicationdetails AD inner join dgen.PrematApplicationProcess  PAP on PAP.ApplicationNo=AD.ApplicationNo inner join ServiceMaster Sm on SM.ServiceCode=AD.ServiceCode inner join (select applicationno,sum(feeamount) as feeamount from dgen.scstfeedetails where FeeinitiateBy=@FeeinitiateBy group by applicationno)  SCSTFD on SCSTFD.applicationNo=AD.ApplicationNo left outer join dgen.prematschoolmaster PSM on PSM.SchoolId = PAP.SchoolId left outer join SelectMasterValueDetails SMVD on SMVD.ValueId=PAP.ProcessstatusId left outer join dgen.prematdistrictmaster PDM on PDM.DistrictId = PSM.District left outer join dgen.prematzonemaster PZM on PZM.ZoneId = PSM.SubDivision  where AD.ServiceCode in (@ParamServiceCode) ";
                if (!string.IsNullOrEmpty(model.SCSTDepartmentId)) { Qry += " and PAP.DepartmentId = @SCSTDepartmentId "; }
                if (!string.IsNullOrEmpty(model.SCSTDistrictId)) { Qry += " and PSM.District = @SCSTDistrictId "; }
                if (!string.IsNullOrEmpty(model.SCSTZoneId)) { Qry += " and PSM.SubDivision = @SCSTZoneId "; }
                if (!string.IsNullOrEmpty(model.SchoolId)) { Qry += " and PAP.SchoolId = @SchoolId "; }
                if (!string.IsNullOrEmpty(model.CategoryId)) { Qry += " and PAP.CategoryId = @CategoryId "; }
                if (!string.IsNullOrEmpty(model.AcademicSession)) { Qry += " and PAP.AcademicSession=@Academicsession "; }
                Qry += " group by ServiceName,AD.ServiceCode ";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
                cmd.Parameters.AddWithValue("@Verified", (int)ValueId.Verified);
                cmd.Parameters.AddWithValue("@Approved", (int)ValueId.Approved);
                cmd.Parameters.AddWithValue("@PFMSFileGenerated", (int)ValueId.PFMSFileGenerated);
                cmd.Parameters.AddWithValue("@PFMSValidateComplete", (int)ValueId.PFMSValidateComplete);
                cmd.Parameters.AddWithValue("@SanctionProcessed", (int)ValueId.SanctionProcessed);
                cmd.Parameters.AddWithValue("@SanctionIssued", (int)ValueId.SanctionIssued);
                cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                cmd.Parameters.AddWithValue("@SCSTDepartmentId", model.SCSTDepartmentId);
                cmd.Parameters.AddWithValue("@SCSTDistrictId", model.SCSTDistrictId);
                cmd.Parameters.AddWithValue("@SCSTZoneId", model.SCSTZoneId);
                cmd.Parameters.AddWithValue("@SchoolId", model.SchoolId);
                cmd.Parameters.AddWithValue("@CategoryId", model.CategoryId);
                cmd.Parameters.AddWithValue("@Academicsession", model.AcademicSession);
                model.data = data.GetDataTable(cmd);

                if (string.IsNullOrEmpty(model.SCSTDepartmentId)) { model.SCSTDepartmentId = ((int)CountList.Type000).ToString(); }
                if (string.IsNullOrEmpty(model.SCSTDistrictId)) { model.SCSTDistrictId = ((int)CountList.Type000).ToString(); }
                if (string.IsNullOrEmpty(model.SCSTZoneId)) { model.SCSTZoneId = ((int)CountList.Type000).ToString(); }
                if (string.IsNullOrEmpty(model.SchoolId)) { model.SchoolId = ((int)CountList.Type000).ToString(); }
                if (string.IsNullOrEmpty(model.CategoryId)) { model.CategoryId = ((int)CountList.Type000).ToString(); }
                if (string.IsNullOrEmpty(model.AcademicSession)) { model.AcademicSession = ((int)CountList.Type000).ToString(); }
            }
            return View("PendingForSanctionProcessSummary", model);
        }
        [Authorize(Roles = "110")]
        [EncryptedActionParameter]
        public ActionResult PendingForSanctionProcessList(int ServiceCode, int Type, int? DepartmentId = 0, int? DistrictId = 0, int? ZoneId = 0, int? SchoolId = 0, int? CategoryId = 0, int? AcademicSession = 0)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            string Whethercondition = string.Empty;
            model.ActionType = Type.ToString();

            string Qry = @"select  AD.ApplicationNo,ApplicantName,to_char(ApplicantDob,'DD/MM/YYYY') as ApplicantDob,ApplicantGender,AD.ServiceCode,ServiceName,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,case when SchoolName is null then 'Out of Delhi' else SchoolName end as SchoolName, PAP.DepartmentId,SMVD1.ValueName as Department,to_char(AD.ApplicantDob,'DD/MM/YYYY') as DOB,AD.ApplicationStatusId,coalesce(sum(Feeamount),0) as Recomended,to_char(AD.ApprovedDate,'DD/MM/YYYY') as ApprovedDate,SMVD.ValueName as Category  from applicationdetails AD inner join dgen.PrematApplicationProcess  PAP on PAP.ApplicationNo=AD.ApplicationNo inner join dgen.scstfeedetails  SCSTFD on SCSTFD.applicationNo=AD.ApplicationNo inner join ServiceMaster Sm on SM.ServiceCode=AD.ServiceCode inner join SelectMasterValueDetails SMVD on SMVD.ValueId = PAP.CategoryId inner join SelectMasterValueDetails SMVD1 on SMVD1.ValueId = PAP.DepartmentId left outer join dgen.prematschoolmaster PSM on PSM.SchoolId = PAP.SchoolId left outer join SelectMasterValueDetails SMVVD on SMVVD.ValueId=PAP.ProcessstatusId left outer join dgen.prematdistrictmaster PDM on PDM.DistrictId = PSM.District   left outer join dgen.prematzonemaster PZM on PZM.ZoneId = PSM.SubDivision where AD.ServiceCode in (@ServiceCode) and ApplicationStatusId=@ApplicationStatusId and FeeinitiateBy=@FeeinitiateBy ";
            if (DepartmentId != (int)CountList.Type000) { Qry += "and PAP.DepartmentId = @DepartmentId "; }
            if (DistrictId != (int)CountList.Type000) { Qry += " and PSM.District = @DistrictId "; }
            if (ZoneId != (int)CountList.Type000) { Qry += " and PSM.SubDivision = @ZoneId "; }
            if (SchoolId != (int)CountList.Type000) { Qry += " and PAP.SchoolId = @SchoolId"; }
            if (CategoryId != (int)CountList.Type000) { Qry += " and PAP.CategoryId = @CategoryId"; }
            if (AcademicSession != (int)CountList.Type000) { Qry += " and PAP.AcademicSession = @AcademicSession"; }

            if (Type == (int)CountList.Type000) { Qry += " and ProcessstatusId=@PFMSValidateComplete "; }
            if (Type == (int)CountList.Type001) { Qry += " and ProcessstatusId=@PFMSFileGenerated "; }
            if (Type == (int)CountList.Type002) { Qry += " and ProcessstatusId=@Approved "; }

            Qry += " group by  AD.ApplicationNo,ApplicantName, ApplicantDob,ApplicantGender,AD.ServiceCode,ServiceName,ApplicationDate,SchoolName, PAP.DepartmentId,SMVD1.ValueName,AD.ApplicantDob,AD.ApplicationStatusId,SMVD.ValueName";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@DepartmentId", DepartmentId);
            cmd.Parameters.AddWithValue("@DistrictId", DistrictId);
            cmd.Parameters.AddWithValue("@ZoneId", ZoneId);
            cmd.Parameters.AddWithValue("@SchoolId", SchoolId);
            cmd.Parameters.AddWithValue("@CategoryId", CategoryId);
            cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
            cmd.Parameters.AddWithValue("@Approved", (int)ValueId.Approved);
            cmd.Parameters.AddWithValue("@PFMSFileGenerated", (int)ValueId.PFMSFileGenerated);
            cmd.Parameters.AddWithValue("@PFMSValidateComplete", (int)ValueId.PFMSValidateComplete);
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            model.data = data.GetDataTable(cmd);

            model.SCSTDepartmentId = DepartmentId.ToString();
            model.SCSTDistrictId = DistrictId.ToString();
            model.SCSTZoneId = ZoneId.ToString();
            model.SchoolId = SchoolId.ToString();
            model.CategoryId = CategoryId.ToString();
            model.AcademicSession = AcademicSession.ToString();
            return View(model);
        }
        [Authorize(Roles = "110")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SaveSanctionProcess(ProcessModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string Qry = string.Empty, checkResult = string.Empty, SchoolId = string.Empty, DepartmentId = string.Empty, ApplicationStatusId = string.Empty;
                bool VerificationLetterUpload = true, ApprovalLetterUpload = true;
                string[] value = null;
                NpgsqlCommand cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string TrainingStartDate = string.Empty, TrainingEndDate = string.Empty;
                string checkboxvalue = frm["chkboxData"];
                string[] Values = checkboxvalue.Split(',');
                for (int i = 0; i < Values.Length; i++)
                {
                    model.ServiceCode = Utility.GetServiceCode(Convert.ToInt64(Values[i]))[0];
                    if (model.ActionType == ((int)CountList.Type000).ToString())
                    {

                        Qry = "select ApplicationNo from dgen.prematapplicationprocess where ApplicationNo=@ApplicationNo and whethervletteruploaded=@whethervletteruploaded";
                        cmd = new NpgsqlCommand(Qry);
                        cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                        cmd.Parameters.AddWithValue("@whethervletteruploaded", CustomText.FALSE.ToString());
                        string WhetherVLetterSkip = data.SelectColumns(cmd)[0];
                        if (!string.IsNullOrEmpty(WhetherVLetterSkip))
                        {
                            //Qry = "select ApplicationNo from dgen.prematapplicationprocess where ApplicationNo=@ApplicationNo and VerificationLetterId is null";
                            //cmd = new NpgsqlCommand(Qry);
                            //cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                            //checkResult = data.SelectColumns(cmd)[0];
                            //if (!string.IsNullOrEmpty(checkResult))
                            //{
                            VerificationLetterUpload = false;
                            ViewData["message"] = "The Verification Letter of Some Application's are not Uploaded by the Concerned School/College/Institue. However Sanction Authority can allow the Application For Further process without uploading of Verificatoin letter.";
                            //}
                        }
                        Qry = "select ApplicationNo from dgen.prematapplicationprocess where ApplicationNo=@ApplicationNo and whetheraletteruploaded=@whetheraletteruploaded";
                        cmd = new NpgsqlCommand(Qry);
                        cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                        cmd.Parameters.AddWithValue("@whetheraletteruploaded", CustomText.FALSE.ToString());
                        string WhetherALetterSkip = data.SelectColumns(cmd)[0];
                        if (!string.IsNullOrEmpty(WhetherALetterSkip))
                        {
                            //Qry = "select ApplicationNo from dgen.prematapplicationprocess where ApplicationNo=@ApplicationNo and ApprovalSignedLetterId is null";
                            //cmd = new NpgsqlCommand(Qry);
                            //cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                            //checkResult = data.SelectColumns(cmd)[0];
                            //if (!string.IsNullOrEmpty(checkResult))
                            //{
                            ApprovalLetterUpload = false;
                            ViewData["message"] = "The Approval Letter of Some Application's are not Uploaded by the Concerned Department/Zone. However Sanction Authority can allow the Application For Further process without  uploading of Approval letter.";
                            //}
                        }

                        Qry = "update dgen.prematapplicationprocess set ProcessStatusId= @ProcessStatusId,sanctionprocessremarks= @sanctionprocessremarks,sanctionprocessdate=now(),sanctionprocessby= @sanctionprocessby,sanctionprocessipaddress= @sanctionprocessipaddress where ApplicationNo = @ApplicationNo";
                        cmd = new NpgsqlCommand(Qry);
                        cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                        cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.SanctionProcessed);
                        cmd.Parameters.AddWithValue("@sanctionprocessremarks", model.SchollRemarks);
                        cmd.Parameters.AddWithValue("@sanctionprocessby", Sessions.getEmployeeUser().UserId);
                        cmd.Parameters.AddWithValue("@sanctionprocessipaddress", Utility.GetIP4Address());
                        cmdList.Add(cmd);
                    }
                    else if (model.ActionType == ((int)CountList.Type001).ToString())
                    {
                        if (model.Flag == ((int)CountList.Type001).ToString())
                        {
                            ApplicationStatusId = ((int)Status.OBSPEND).ToString();
                            if (model.ServiceCode == ((int)ServiceList.PrematricScholarshipSC).ToString())
                            {
                                value = Utility.SelectColumnsValue("dgen.applicationdetailsprematssc", "SchoolId,DepartmentId", "ApplicationNo", (Values[i]).ToString());
                                if (value != null)
                                {
                                    SchoolId = value[0].ToString();
                                    DepartmentId = value[1].ToString();
                                }
                                Qry = "update dgen.applicationdetailsprematssc set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                                cmd = new NpgsqlCommand(Qry);
                                cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                                cmd.Parameters.AddWithValue("@Observation", model.SchollRemarks);
                                cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                                cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                cmdList.Add(cmd);
                            }
                            else if (model.ServiceCode == ((int)ServiceList.FinancialAssistanceStationery).ToString())
                            {
                                value = Utility.SelectColumnsValue("dgen.applicationdetailsfinancialassistance", "SchoolId,DepartmentId", "ApplicationNo", (Values[i]).ToString());
                                if (value != null)
                                {
                                    SchoolId = value[0].ToString();
                                    DepartmentId = value[1].ToString();
                                }
                                Qry = "update dgen.applicationdetailsfinancialassistance set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                                cmd = new NpgsqlCommand(Qry);
                                cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                                cmd.Parameters.AddWithValue("@Observation", model.SchollRemarks);
                                cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                                cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                cmdList.Add(cmd);
                            }
                            else if (model.ServiceCode == ((int)ServiceList.MeritscholarshipSchool).ToString())
                            {
                                value = Utility.SelectColumnsValue("dgen.applicationdetailsmeritscholarshipschool", "SchoolId,DepartmentId", "ApplicationNo", (Values[i]).ToString());
                                if (value != null)
                                {
                                    SchoolId = value[0].ToString();
                                    DepartmentId = value[1].ToString();
                                }
                                Qry = "update dgen.applicationdetailsmeritscholarshipschool set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                                cmd = new NpgsqlCommand(Qry);
                                cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                                cmd.Parameters.AddWithValue("@Observation", model.SchollRemarks);
                                cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                                cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                cmdList.Add(cmd);
                            }
                            else if (model.ServiceCode == ((int)ServiceList.DrbrAmbedkarToppers).ToString())
                            {
                                value = Utility.SelectColumnsValue("dgen.applicationdetailsbrambedkar", "SchoolId,DepartmentId", "ApplicationNo", (Values[i]).ToString());
                                if (value != null)
                                {
                                    SchoolId = value[0].ToString();
                                    DepartmentId = value[1].ToString();
                                }
                                Qry = "update dgen.applicationdetailsbrambedkar set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                                cmd = new NpgsqlCommand(Qry);
                                cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                                cmd.Parameters.AddWithValue("@Observation", model.SchollRemarks);
                                cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                                cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                cmdList.Add(cmd);
                            }
                            else if (model.ServiceCode == ((int)ServiceList.MeritscholarshipProfessional).ToString())
                            {
                                value = Utility.SelectColumnsValue("dgen.applicationdetailsmeritprofessional", "SchoolId,DepartmentId", "ApplicationNo", (Values[i]).ToString());
                                if (value != null)
                                {
                                    SchoolId = value[0].ToString();
                                    DepartmentId = value[1].ToString();
                                }
                                if (string.IsNullOrEmpty(SchoolId))
                                {
                                    ApplicationStatusId = ((int)Status.DEALOLR).ToString();
                                }

                                Qry = "update dgen.applicationdetailsmeritprofessional set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                                cmd = new NpgsqlCommand(Qry);
                                cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                                cmd.Parameters.AddWithValue("@Observation", model.SchollRemarks);
                                cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                                cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                cmdList.Add(cmd);
                            }
                            else if (model.ServiceCode == ((int)ServiceList.PrematricScholarshipOBC).ToString())
                            {
                                value = Utility.SelectColumnsValue("dgen.applicationdetailsprematobc", "SchoolId,DepartmentId", "ApplicationNo", (Values[i]).ToString());
                                if (value != null)
                                {
                                    SchoolId = value[0].ToString();
                                    DepartmentId = value[1].ToString();
                                }
                                Qry = "update dgen.applicationdetailsprematobc set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                                cmd = new NpgsqlCommand(Qry);
                                cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                                cmd.Parameters.AddWithValue("@Observation", model.SchollRemarks);
                                cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                                cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                cmdList.Add(cmd);
                            }
                            else if (model.ServiceCode == ((int)ServiceList.PostmatricScholarshipOBC).ToString())
                            {
                                value = Utility.SelectColumnsValue("dgen.applicationdetailspostmatobc", "SchoolId,DepartmentId", "ApplicationNo", (Values[i]).ToString());
                                if (value != null)
                                {
                                    SchoolId = value[0].ToString();
                                    DepartmentId = value[1].ToString();
                                }
                                if (string.IsNullOrEmpty(SchoolId))
                                {
                                    ApplicationStatusId = ((int)Status.DEALOLR).ToString();
                                }

                                Qry = "update dgen.applicationdetailspostmatobc set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                                cmd = new NpgsqlCommand(Qry);
                                cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                                cmd.Parameters.AddWithValue("@Observation", model.SchollRemarks);
                                cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                                cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                cmdList.Add(cmd);
                            }
                            else if (model.ServiceCode == ((int)ServiceList.PrematricSC).ToString())
                            {
                                value = Utility.SelectColumnsValue("dgen.applicationdetailsprematscssd", "SchoolId,DepartmentId", "ApplicationNo", (Values[i]).ToString());
                                if (value != null)
                                {
                                    SchoolId = value[0].ToString();
                                    DepartmentId = value[1].ToString();
                                }
                                Qry = "update dgen.applicationdetailsprematscssd set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                                cmd = new NpgsqlCommand(Qry);
                                cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                                cmd.Parameters.AddWithValue("@Observation", model.SchollRemarks);
                                cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                                cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                cmdList.Add(cmd);
                            }
                            else if (model.ServiceCode == ((int)ServiceList.PostmatricSC).ToString())
                            {
                                value = Utility.SelectColumnsValue("dgen.applicationdetailspostmatscssd", "SchoolId,DepartmentId", "ApplicationNo", (Values[i]).ToString());
                                if (value != null)
                                {
                                    SchoolId = value[0].ToString();
                                    DepartmentId = value[1].ToString();
                                }
                                if (string.IsNullOrEmpty(SchoolId))
                                {
                                    ApplicationStatusId = ((int)Status.DEALOLR).ToString();
                                }

                                Qry = "update dgen.applicationdetailspostmatscssd set Observation=@Observation,WhetherVerified=@WhetherVerified,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                                cmd = new NpgsqlCommand(Qry);
                                cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                                cmd.Parameters.AddWithValue("@Observation", model.SchollRemarks);
                                cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.False.ToString());
                                cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                                cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                                cmdList.Add(cmd);
                            }


                            if (!string.IsNullOrEmpty(SchoolId))
                            {
                                Qry = "select letterId from dbyt.prematverifiedapplication where SchoolId=@SchoolId and ServiceCode=@ServiceCode and WhetherFileUploaded=@WhetherFileUploaded and AcademicSession=@AcademicSession and DepartmentId=@DepartmentId";
                                cmd = new NpgsqlCommand(Qry);
                                cmd.Parameters.AddWithValue("@SchoolId", SchoolId);
                                cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                                cmd.Parameters.AddWithValue("@WhetherFileUploaded", CustomText.TRUE.ToString());
                                cmd.Parameters.AddWithValue("@DepartmentId", DepartmentId);
                                cmd.Parameters.AddWithValue("@AcademicSession", model.AcademicSession);
                                string letterId = data.SelectColumns(cmd)[0];
                                if (!string.IsNullOrEmpty(letterId))
                                {
                                    Qry = "update dbyt.prematverifiedapplication set WhetherRevertBack=@WhetherRevertBack where letterId=@letterId";
                                    cmd = new NpgsqlCommand(Qry);
                                    cmd.Parameters.AddWithValue("@letterId", letterId);
                                    cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.True.ToString());
                                    cmdList.Add(cmd);
                                }
                            }

                            Qry = "update dgen.prematapplicationprocess set WhetherRevertBack=@WhetherRevertBack,ProcessStatusId=@PendingVerification,whethervletteruploaded=@whethervletteruploaded,whetheraletteruploaded=@whetheraletteruploaded where ApplicationNo=@ApplicationNo";
                            cmd = new NpgsqlCommand(Qry);
                            cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                            cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.True.ToString());
                            cmd.Parameters.AddWithValue("@PendingVerification", (int)ValueId.PendingVerification);
                            cmd.Parameters.AddWithValue("@whethervletteruploaded", CustomText.False.ToString());
                            cmd.Parameters.AddWithValue("@whetheraletteruploaded", CustomText.False.ToString());
                            cmdList.Add(cmd);

                            Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                            cmd = new NpgsqlCommand(Qry);
                            cmd.Parameters.AddWithValue("@ApplicationStatusId", ApplicationStatusId);
                            cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                            cmd.Parameters.AddWithValue("@ApplicationRemarks", model.SchollRemarks);
                            cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                            cmdList.Add(cmd);

                            Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                            cmd = new NpgsqlCommand(Qry);
                            cmd.Parameters.AddWithValue("@ApplicationStatusId", ApplicationStatusId);
                            cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                            cmd.Parameters.AddWithValue("@ApplicationRemarks", model.SchollRemarks);
                            cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                            cmdList.Add(cmd);
                            cmdList.Add(Utility.InsertDepartmentAuditTrail((Values[i]).ToString(), (int)ApplicationHistoryMessage.MSG051, model.SchollRemarks, (int)ApplicationSource.Window, null));
                        }
                    }
                    else if (model.ActionType == ((int)CountList.Type002).ToString())
                    {
                        Qry = "update dgen.prematapplicationprocess set ProcessStatusId= @ProcessStatusId,filegeneratedate=now(),filegenerateby= @filegenerateby,filegenerateipaddress= @filegenerateipaddress where ApplicationNo = @ApplicationNo";
                        cmd = new NpgsqlCommand(Qry);
                        cmd.Parameters.AddWithValue("@ApplicationNo", (Values[i]).ToString());
                        cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.PFMSFileGenerated);
                        cmd.Parameters.AddWithValue("@filegenerateby", Sessions.getEmployeeUser().UserId);
                        cmd.Parameters.AddWithValue("@filegenerateipaddress", Utility.GetIP4Address());
                        cmdList.Add(cmd);
                    }
                }

                if (cmdList.Count > 0)
                {
                    if (VerificationLetterUpload == false || ApprovalLetterUpload == false)
                    {
                        return View("message");
                    }
                    data.SaveData(cmdList);
                    if (model.ActionType == ((int)CountList.Type001).ToString())
                    {
                        if (model.Flag == ((int)CountList.Type001).ToString())
                        {
                            cmdList.Clear();
                            for (int i = 0; i < Values.Length; i++)
                            {
                                //send sms to applicant and insert record in table
                                Dictionary<string, string> smsDic = new Dictionary<string, string>();
                                smsDic.Add("ParamApplicationNo", (Values[i]).ToString());
                                cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS030, smsDic));

                                Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                                EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                                EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS030).ToString());
                                EmailDic.Add("ParamApplicationNo", (Values[i]).ToString());
                                NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                                if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                            }
                            data.SaveData(cmdList);
                            ViewData["message"] = "Selected Application Revert Back Sucessfully!";
                            return View("message");
                        }
                    }
                }
                if (model.ActionType == ((int)CountList.Type000).ToString())
                {
                    ViewData["message"] = "Sanction Processed Successfully";
                }
                else if (model.ActionType == ((int)CountList.Type001).ToString())
                {
                    return RedirectToAction("ScstCheckPfmsResponse");
                }
                else if (model.ActionType == ((int)CountList.Type002).ToString())
                {
                    //Qry = @"select case when SUD.ApplicantName is null then AD.ApplicantName else SUD.ApplicantName end as ""Full Name in English"",null as ""Full Name in Recognized Official Language"",case when SUD.ApplicantGender is null then AD.ApplicantGender else SUD.ApplicantGender end as Gender,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ""Address line 1"",case when PAP.SchoolId is null then 'Out Of Delhi' else PSM.SchoolName end as ""Address Line 2"",ApplicantMobileNo as ""Address Line 3"",DM.DistrictName as District,STM.StateName as State,'India' as Country, BM.BankName as ""Bank Name"",IFSCCode,AccountNo as ""Account Number"",dbo.udf_general_decrypt(AED.DocumentNo) as ""Aadhaar Number"" ,ApplicantPinCode as Pincode,AD.ApplicationNo as ""Scheme Specific ID"",null as ""Center Share Payment Amount"",coalesce(sum(Feeamount),0) as ""State Share Payment Amount"" from applicationdetails AD inner join dgen.PrematApplicationProcess  PAP on PAP.ApplicationNo=AD.ApplicationNo  inner join (select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailsfinancialassistance union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailsprematssc union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailsmeritscholarshipschool union all select ApplicationNo,AccountNo,Ifsccode,bankcode from  dgen.applicationdetailsbrambedkar union all select ApplicationNo,AccountNo,Ifsccode,bankcode from  dgen.applicationdetailsmeritprofessional union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailsprematobc union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailspostmatobc union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailsprematscssd union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailspostmatscssd  ) SCD on AD.ApplicationNo=SCD.ApplicationNo  inner join applicationenclosuredetails AED on AED.ApplicationNo=AD.ApplicationNo inner join dgen.scstfeedetails  SCSTFD on SCSTFD.applicationNo=AD.ApplicationNo inner join ServiceMaster Sm on SM.ServiceCode=AD.ServiceCode inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join StateMaster STM on STM.StateId=AD.StateId inner join BankMaster BM on BM.BankCode=SCD.BankCode inner join SelectMasterValueDetails SMVVD on SMVVD.ValueId=PAP.ProcessstatusId left outer join dgen.prematschoolmaster PSM on PSM.SchoolId = PAP.SchoolId  left outer  join dgen.prematdistrictmaster PDM on PDM.DistrictId = PSM.District left outer join SelectMasterValueDetails SMVD1 on SMVD1.ValueId = PAP.DepartmentId  left outer join dgen.scstupdatedapplicationdetail SUD on SUD.ApplicationNo=AD.ApplicationNo left outer join dgen.prematzonemaster PZM on PZM.ZoneId = PSM.SubDivision where AD.ServiceCode in (@ServiceCode) and ApplicationStatusId =@ApplicationStatusId and FeeinitiateBy=@FeeinitiateBy  and ProcessstatusId=@PFMSFileGenerated and AD.ApplicationNo in (" + checkboxvalue + ") and AED.DocumentId=@DocumentId ";
                    Qry = @"select case when SUD.ApplicantName is null then AD.ApplicantName else SUD.ApplicantName end as ""Full Name in English"",null as ""Full Name in Recognized Official Language"",case when SUD.ApplicantGender is null then AD.ApplicantGender else SUD.ApplicantGender end as Gender,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ""Address line 1"",case when PAP.SchoolId is null then 'Out Of Delhi' else PSM.SchoolName end as ""Address Line 2"",ApplicantMobileNo as ""Address Line 3"",DM.DistrictName as District,STM.StateName as State,'India' as Country, BM.BankName as ""Bank Name"",IFSCCode,AccountNo as ""Account Number"",dbo.udf_general_decrypt(AED.DocumentNo) as ""Aadhaar Number"", ApplicantPinCode as Pincode,AD.ApplicationNo as ""Scheme Specific ID"",null as ""Center Share Payment Amount"",coalesce(sum(Feeamount),0) as ""State Share Payment Amount"" from applicationdetails AD inner join dgen.PrematApplicationProcess  PAP on PAP.ApplicationNo=AD.ApplicationNo  inner join (select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailsfinancialassistance union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailsprematssc union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailsmeritscholarshipschool union all select ApplicationNo,AccountNo,Ifsccode,bankcode from  dgen.applicationdetailsbrambedkar union all select ApplicationNo,AccountNo,Ifsccode,bankcode from  dgen.applicationdetailsmeritprofessional union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailsprematobc union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailspostmatobc union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailsprematscssd union all select ApplicationNo,AccountNo,Ifsccode,bankcode from dgen.applicationdetailspostmatscssd  ) SCD on AD.ApplicationNo=SCD.ApplicationNo  inner join applicationenclosuredetails AED on AED.ApplicationNo=AD.ApplicationNo inner join dgen.scstfeedetails  SCSTFD on SCSTFD.applicationNo=AD.ApplicationNo inner join ServiceMaster Sm on SM.ServiceCode=AD.ServiceCode inner join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join StateMaster STM on STM.StateId=AD.StateId inner join BankMaster BM on BM.BankCode=SCD.BankCode inner join SelectMasterValueDetails SMVVD on SMVVD.ValueId=PAP.ProcessstatusId left outer join dgen.prematschoolmaster PSM on PSM.SchoolId = PAP.SchoolId  left outer  join dgen.prematdistrictmaster PDM on PDM.DistrictId = PSM.District left outer join SelectMasterValueDetails SMVD1 on SMVD1.ValueId = PAP.DepartmentId  left outer join dgen.scstupdatedapplicationdetail SUD on SUD.ApplicationNo=AD.ApplicationNo left outer join dgen.prematzonemaster PZM on PZM.ZoneId = PSM.SubDivision where AD.ServiceCode in (@ServiceCode) and ApplicationStatusId =@ApplicationStatusId and FeeinitiateBy=@FeeinitiateBy  and ProcessstatusId=@PFMSFileGenerated and AD.ApplicationNo in (" + checkboxvalue + ") and AED.DocumentId=@DocumentId";
                    if (model.SCSTDepartmentId != ((int)CountList.Type000).ToString()) { Qry += " and PAP.DepartmentId = @DepartmentId "; }
                    if (model.SCSTDistrictId != ((int)CountList.Type000).ToString()) { Qry += " and PSM.District = @DistrictId "; }
                    if (model.SCSTZoneId != ((int)CountList.Type000).ToString()) { Qry += " and PSM.SubDivision = @ZoneId "; }
                    if (model.SchoolId != ((int)CountList.Type000).ToString()) { Qry += " and PAP.SchoolId = @SchoolId"; }
                    if (model.AcademicSession != ((int)CountList.Type000).ToString()) { Qry += " and PAP.AcademicSession = @AcademicSession"; }
                    Qry += " and AD.ApplicationNo not in (select applicationno from applicationdetailstempcheck where detailstypeid=@detailstypeid)"; // to skip the duplicate records from temp table
                    Qry += " group by  SUD.ApplicantName,AD.ApplicantName,SUD.ApplicantGender,AD.ApplicantGender,BM.BankName,Ifsccode,AccountNo,AED.DocumentNo,ApplicantPinCode,AD.ApplicationNo,ServiceName,AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,DM.DistrictName,STM.StateName,PAP.SchoolId,PSM.SchoolName";
                    cmd = new NpgsqlCommand(Qry);
                    cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceCode);
                    cmd.Parameters.AddWithValue("@DocumentId", (int)DocumentId.AadhaarCardCopy);
                    cmd.Parameters.AddWithValue("@DepartmentId", model.SCSTDepartmentId);
                    cmd.Parameters.AddWithValue("@DistrictId", model.SCSTDistrictId);
                    cmd.Parameters.AddWithValue("@ZoneId", model.SCSTZoneId);
                    cmd.Parameters.AddWithValue("@SchoolId", model.SchoolId);
                    cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                    cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
                    cmd.Parameters.AddWithValue("@PFMSFileGenerated", (int)ValueId.PFMSFileGenerated);
                    cmd.Parameters.AddWithValue("@AcademicSession", model.AcademicSession);
                    cmd.Parameters.AddWithValue("@detailstypeid", (int)AppTempCheck.Value0858);
                    model.data = data.GetDataTable(cmd);
                    
                    CSVFileFormat csvfile = new CSVFileFormat(model.data, "SanctionFile.csv");
                    csvfile.ExecuteResult(this.ControllerContext);

                    ViewData["message"] = "File Generated Successfully";
                }
                return View("message");
            }
            return RedirectToAction("PendingForSanctionProcessList");
        }
        public ActionResult ScstCheckPfmsResponse()
        {
            ProcessModels model = new ProcessModels();
            Utility.DeleteBulkFile();
            return View(model);
        }
        [HttpPost]
        [ValidateOnlyIncomingValues]
        public ActionResult ScstCheckPfmsResponse(ProcessModels model)
        {
            if (ModelState.IsValid)
            {
                string[] ValidCol = new string[] { "S.No.", "CPSMS Beneficiary Code", "Scheme Specific Id", "Beneficiary Name", "Beneficiary Regional Name", "Category", "Beneficiary Name as per Bank", "Father/Husband Name", "Bank Name", "Aadhaar Number", "Account Number", "IFSC Code", "State", "District", "Address Line 1", "Address Line2", "Address Line3", "Purpose", "Centre Share Payment Amount", "State Share Payment Amount", "Total Amount", "Payment From Date", "Payment To Date" };
                Session["FilePath"] = Utility.UploadFile(model.uploadFile);
                try
                {
                    if (Session["FilePath"].ToString() == null) { ViewData["message"] = "Invalid file or Location, Please try again later."; return View("message"); }
                    string[] getFirstRow = Utility.getFirstRow(Session["FilePath"].ToString());

                    bool validColumn = Utility.CheckValidHeader(Session["FilePath"].ToString(), ValidCol);
                    if (validColumn == false) { ViewData["message"] = "Invalid Column Name, Please check the file and try again."; return View("message"); }

                    string TempTab = "pay_" + Sessions.getEmployeeUser().UserId + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss");
                    string TempTabCol = "(\"S.No.\" character varying(10) NOT NULL,\"CPSMS Beneficiary Code\" character varying(50) NOT NULL,\"Scheme Specific Id\" character varying(14) NOT NULL,\"Beneficiary Name\" character varying(100) NOT NULL,\"Beneficiary Regional Name\" character varying(100),category character varying(50),\"Beneficiary Name as per Bank\" character varying(100),\"Father/Husband Name\" character varying(100), \"Bank Name\" character varying(100),\"Aadhaar Number\" character varying(12) NOT NULL,\"Account Number\" character varying(25),\"IFSC Code\" character varying(15),state character varying(100) NOT NULL,district character varying(25),\"Address Line 1\" character varying(300),\"Address Line2\" character varying(300),\"Address Line3\" character varying(300),\"Purpose\" character varying(100) NOT NULL,\"Centre Share Payment Amount\" bigint,\"State Share Payment Amount\" bigint,\"Total Amount\" bigint,\"Payment From Date\" character varying(15),\"Payment To Date\" character varying(15))";
                    string joinQuery = @"select case when b.ApplicationNo is null then 0 else 1 end as IsFind,""S.No."",""CPSMS Beneficiary Code"", ""Scheme Specific Id"", ""Beneficiary Name"", ""Beneficiary Regional Name"", category, ""Beneficiary Name as per Bank"", ""Father/Husband Name"", ""Bank Name"", ""Aadhaar Number"", ""Account Number"", ""IFSC Code"", state, district, ""Address Line 1"",""Address Line2"", ""Address Line3"", ""Purpose"",""Centre Share Payment Amount"",""State Share Payment Amount"",""Total Amount"",""Payment From Date"",""Payment To Date"" from " + TempTab + @" a left outer join dgen.prematapplicationprocess  b on b.ApplicationNo=a.""Scheme Specific Id""::bigint and b.processstatusid=733 order by 1 desc";
                    model.data = Utility.FillTempTable(Session["FilePath"].ToString(), ValidCol, ',', TempTab, TempTabCol, joinQuery, null);
                    if (model.data == null) { ViewData["message"] = "The CSV File is Trying to upload is in wrong Format. Kindly Check the data and try again"; return View("message"); }
                    return View(model);
                }
                catch
                {
                    Utility.DeleteServerFile(Session["FilePath"].ToString());
                    ViewData["message"] = "File upload error, Please try again later.";
                    return View("message");
                }
            }
            return View(model);
        }
        [HttpPost]
        [ValidateOnlyIncomingValues]
        public ActionResult ScstFreezePfmsResponse(ProcessModels model)
        {
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            string[] ValidCol = new string[] { "S.No.", "CPSMS Beneficiary Code", "Scheme Specific Id", "Beneficiary Name", "Beneficiary Regional Name", "Category", "Beneficiary Name as per Bank", "Father/Husband Name", "Bank Name", "Aadhaar Number", "Account Number", "IFSC Code", "State", "District", "Address Line 1", "Address Line2", "Address Line3", "Purpose", "Centre Share Payment Amount", "State Share Payment Amount", "Total Amount", "Payment From Date", "Payment To Date" };
            try
            {
                if (Session["FilePath"].ToString() == null) { ViewData["message"] = "Invalid file or Location, Please try again later."; return View("message"); }
                string[] getFirstRow = Utility.getFirstRow(Session["FilePath"].ToString());

                bool validColumn = Utility.CheckValidHeader(Session["FilePath"].ToString(), ValidCol);
                if (validColumn == false) { ViewData["message"] = "Invalid Column Name, Please check the file and try again."; return View("message"); }

                string TempTab = "pay_" + Sessions.getEmployeeUser().UserId + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss");
                string TempTabCol = "(\"S.No.\" character varying(10) NOT NULL,\"CPSMS Beneficiary Code\" character varying(50) NOT NULL,\"Scheme Specific Id\" character varying(14) NOT NULL,\"Beneficiary Name\" character varying(100) NOT NULL,\"Beneficiary Regional Name\" character varying(100),category character varying(50),\"Beneficiary Name as per Bank\" character varying(100),\"Father/Husband Name\" character varying(100), \"Bank Name\" character varying(100),\"Aadhaar Number\" character varying(12) NOT NULL,\"Account Number\" character varying(25),\"IFSC Code\" character varying(15),state character varying(100) NOT NULL,district character varying(25),\"Address Line 1\" character varying(300),\"Address Line2\" character varying(300),\"Address Line3\" character varying(300),\"Purpose\" character varying(100) NOT NULL,\"Centre Share Payment Amount\" bigint,\"State Share Payment Amount\" bigint,\"Total Amount\" bigint,\"Payment From Date\" character varying(15),\"Payment To Date\" character varying(15))";

                string UpdQry = @"update dgen.prematapplicationprocess set processstatusid=734,fileuploadipaddress='" + Utility.GetIP4Address() + "',fileuploaddate=now(),fileuploadby='" + Sessions.getEmployeeUser().UserId + @"',beneficiarycode=a.""CPSMS Beneficiary Code"" from " + TempTab + @" a where a.""Scheme Specific Id""::bigint = dgen.prematapplicationprocess.ApplicationNo and dgen.prematapplicationprocess.processstatusid = 733";

                model.data = Utility.FillTempTable(Session["FilePath"].ToString(), ValidCol, ',', TempTab, TempTabCol, null, UpdQry);
                if (model.data == null) { ViewData["message"] = "The CSV File is Trying to upload is in wrong Format. Kindly Check the data and try again."; return View("message"); }

                Utility.DeleteServerFile(Session["FilePath"].ToString());
                ViewData["message"] = "The PFMS mapping of [" + model.Flag + "] record(s) out of total [" + model.data.Rows.Count + "]  record(s) has been completed successfully under e-District Delhi.";
                return View("message");

            }
            catch
            {
                Utility.DeleteServerFile(Session["FilePath"].ToString());
                ViewData["message"] = "File upload error, Please try again later.";
                return View("message");
            }
        }
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult AllowSCSTSantionProcess()
        {
            ProcessModels model = new ProcessModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult AllowSCSTSantionProcess(ProcessModels model)
        {
            ViewData["message"] = "This Facility is not Avaliable";
            return View("message");

            //GetData data = new GetData();
            //if (ModelState.IsValid)
            //{

            //    string Qry = "select PSM.SchoolId,SchoolName,SchoolAddress,SchoolAffiliationId,SchoolTypeId,SMVD.ValueName as SchoolType,DepartmentId,SMVD1.ValueName as Department,SubDivision,ZoneName from dgen.prematschoolmaster PSM inner join SelectmasterValueDetails SMVD on SMVD.ValueId=PSM.SchoolTypeId inner join SelectmasterValueDetails SMVD1 on SMVD1.ValueId=PSM.DepartmentId left outer join dgen.PrematZoneMaster PZM on PZM.ZoneId=PSM.SubDivision where PSM.WhetherActive=@WhetherActive  and DepartmentId=@DepartmentId and SchoolTypeId=@SchoolTypeId  order by SchoolName";
            //    NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            //    cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
            //    cmd.Parameters.AddWithValue("@ServiceCode", model.ApplicationDetailsPrematsSC.ServiceCode);
            //    cmd.Parameters.AddWithValue("@SchoolTypeId", model.ApplicationDetailsPrematsSC.SchoolTypeId);
            //    cmd.Parameters.AddWithValue("@DepartmentId", model.ApplicationDetailsPrematsSC.DepartmentId);
            //    model.data = data.GetDataTable(cmd);
            //}
            //return View(model);

        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SaveAllowSCSTSantionProcess(CommonModels model, FormCollection frm)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                string Qry = string.Empty, SchoolId = string.Empty;
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string[] VerifyValues = null;
                string[] ApproveValues = null; ;
                string checkVerifyvalue = frm["chkVerifyCHeck"];
                if (!string.IsNullOrEmpty(checkVerifyvalue))
                {
                    VerifyValues = checkVerifyvalue.Split(',');
                }
                string checkApproveyvalue = frm["chkApproveCHeck"];
                if (!string.IsNullOrEmpty(checkApproveyvalue))
                {
                    ApproveValues = checkApproveyvalue.Split(',');
                }

                if (!string.IsNullOrEmpty(checkVerifyvalue))
                {
                    for (int i = 0; i < VerifyValues.Length; i++)
                    {
                        Qry = "select AD.ApplicationNo from ApplicationDetails AD inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo inner join (select SchoolId,ApplicationNo,DepartmentId from dgen.applicationdetailsfinancialassistance union all select SchoolId,ApplicationNo,DepartmentId from dgen.applicationdetailsprematssc union all select SchoolId,ApplicationNo,DepartmentId from dgen.applicationdetailsmeritscholarshipschool union all select SchoolId,ApplicationNo,DepartmentId from  dgen.applicationdetailsbrambedkar union all select SchoolId,ApplicationNo,DepartmentId from  dgen.applicationdetailsmeritprofessional union all select SchoolId,ApplicationNo,DepartmentId from dgen.applicationdetailsprematobc union all select SchoolId,ApplicationNo,DepartmentId from dgen.applicationdetailspostmatobc ) SCD on AD.ApplicationNo=SCD.ApplicationNo inner join ServiceMaster Sm on SM.ServiceCode=AD.ServiceCode  inner join dgen.prematschoolmaster PSM on PSM.SchoolId = SCD.SchoolId where SCD.SchoolId=@SchoolId and AD.ServiceCode=@ServiceCode";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@SchoolId", VerifyValues[i]);
                        Cmd.Parameters.AddWithValue("@ServiceCode", model.ApplicationDetailsPrematsSC.ServiceCode);
                        model.data1 = data.GetDataTable(Cmd);

                        if (model.data1 != null)
                        {
                            if (model.data1.Rows.Count > 0)
                            {
                                for (int j = 0; j < model.data1.Rows.Count; j++)
                                {
                                    Qry = "update dgen.prematapplicationprocess set whethervletteruploaded=@whethervletteruploaded,vletterskipdate=now(),vletterskipby=@vletterskipby,vletterskipipaddress=@vletterskipipaddress where ApplicationNo=@ApplicationNo and whethervletteruploaded=@whethervletteruploaded1";
                                    Cmd = new NpgsqlCommand(Qry);
                                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.data1.Rows[j]["ApplicationNo"].ToString());
                                    Cmd.Parameters.AddWithValue("@whethervletteruploaded", CustomText.TRUE.ToString());
                                    Cmd.Parameters.AddWithValue("@whethervletteruploaded1", CustomText.False.ToString());
                                    Cmd.Parameters.AddWithValue("@vletterskipby", Utility.GetIP4Address());
                                    Cmd.Parameters.AddWithValue("@vletterskipipaddress", Sessions.getEmployeeUser().UserId);
                                    cmdList.Add(Cmd);
                                }
                            }
                        }

                    }
                }
                if (!string.IsNullOrEmpty(checkApproveyvalue))
                {
                    for (int i = 0; i < ApproveValues.Length; i++)
                    {
                        Qry = "select AD.ApplicationNo from ApplicationDetails AD inner join dgen.prematapplicationprocess PAP on PAP.ApplicationNo=AD.ApplicationNo inner join (select SchoolId,ApplicationNo,DepartmentId from dgen.applicationdetailsfinancialassistance union all select SchoolId,ApplicationNo,DepartmentId from dgen.applicationdetailsprematssc union all select SchoolId,ApplicationNo,DepartmentId from dgen.applicationdetailsmeritscholarshipschool union all select SchoolId,ApplicationNo,DepartmentId from  dgen.applicationdetailsbrambedkar union all select SchoolId,ApplicationNo,DepartmentId from  dgen.applicationdetailsmeritprofessional union all select SchoolId,ApplicationNo,DepartmentId from dgen.applicationdetailsprematobc union all select SchoolId,ApplicationNo,DepartmentId from dgen.applicationdetailspostmatobc ) SCD on AD.ApplicationNo=SCD.ApplicationNo inner join ServiceMaster Sm on SM.ServiceCode=AD.ServiceCode  inner join dgen.prematschoolmaster PSM on PSM.SchoolId = SCD.SchoolId where SCD.SchoolId=@SchoolId and AD.ServiceCode=@ServiceCode";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@SchoolId", ApproveValues[i]);
                        Cmd.Parameters.AddWithValue("@ServiceCode", model.ApplicationDetailsPrematsSC.ServiceCode);
                        model.data1 = data.GetDataTable(Cmd);

                        if (model.data1 != null)
                        {
                            if (model.data1.Rows.Count > 0)
                            {
                                for (int j = 0; j < model.data1.Rows.Count; j++)
                                {
                                    Qry = "update dgen.prematapplicationprocess set whetheraletteruploaded=@whetheraletteruploaded,aletterskipdate=now(),aletterskipby=@aletterskipby,aletterskipipaddress=@aletterskipipaddress where ApplicationNo=@ApplicationNo and whetheraletteruploaded=@whetheraletteruploaded1";
                                    Cmd = new NpgsqlCommand(Qry);
                                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.data1.Rows[j]["ApplicationNo"].ToString());
                                    Cmd.Parameters.AddWithValue("@whetheraletteruploaded", CustomText.TRUE.ToString());
                                    Cmd.Parameters.AddWithValue("@whetheraletteruploaded1", CustomText.False.ToString());
                                    Cmd.Parameters.AddWithValue("@aletterskipby", Utility.GetIP4Address());
                                    Cmd.Parameters.AddWithValue("@aletterskipipaddress", Sessions.getEmployeeUser().UserId);
                                    cmdList.Add(Cmd);
                                }
                            }
                        }
                    }
                }
                data.SaveData(cmdList);
                ViewData["message"] = "Application Sanction Process Allowed Without Letter Sucessfully!";
                return View("message");
            }
            return View("AllowSCSTSantionProcess", model);
        }
        [Authorize(Roles = "111")]
        [EncryptedActionParameter]
        public ActionResult SCSTSanctionPrintSummary()
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.P111).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            //model.ApplicationDetailsPrematsSC = new ApplicationDetailsPrematsSC();
            //string join = string.Empty, cond = string.Empty;

            string Qry = "select SPD.signedrefid,SPD.SanctionId,to_char(SPD.lastactiondate,'DD/MM/YYYY') as SanctionDate,SPD.SanctionAmount,count(ApplicationNo) as TotalApplication from  sanctionpaymentdetails  as SPD inner join sanctionapplicationdetails SAD on  SAD.SanctionId=SPD.SanctionId group by SPD.SanctionId order by SPD.SanctionId";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [Authorize(Roles = "111")]
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult SCSTPrintSanction(int SanctionId)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            string Qry = string.Empty, checkResult = string.Empty;
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            NpgsqlCommand cmd = new NpgsqlCommand();

            Qry = @"select beneficiarycode as ""CPSMS Beneficiary Code"",AD.applicationNo as ""Scheme Specific Id"", case when SUD.ApplicantName is null then  AD.ApplicantName else SUD.ApplicantName end as ""Beneficiary Name"",ServiceName as Purpose, null as ""Centre Share Payment Amount"",coalesce(sum(Feeamount),0) as ""State Share Payment Amount"",'01/04/2016' as ""Payment From Date"",'31/03/2017' as ""Payment To Date"" from applicationdetails AD inner join dgen.PrematApplicationProcess  PAP on PAP.ApplicationNo=AD.ApplicationNo inner join sanctionpaymentdetails  as SPD on SPD.SanctionId=PAP.SanctionId inner join sanctionapplicationdetails SAD on  SAD.SanctionId=SPD.SanctionId and SAD.ApplicationNo=PAP.ApplicationNo inner join dgen.scstfeedetails  SCSTFD on SCSTFD.applicationNo=AD.ApplicationNo inner join ServiceMaster Sm on SM.ServiceCode=AD.ServiceCode inner join SelectMasterValueDetails SMVVD on SMVVD.ValueId=PAP.ProcessstatusId left outer join dgen.scstupdatedapplicationdetail SUD on SUD.ApplicationNo=AD.ApplicationNo where ApplicationStatusId=@ApplicationStatusId and FeeinitiateBy=@FeeinitiateBy and ProcessstatusId=@SanctionIssued and SAD.SanctionId=@SanctionId group by  beneficiarycode, SUD.ApplicantName,AD.ApplicantName,AD.ApplicationNo,ServiceName";
            cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@SanctionId", SanctionId);
            cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@SanctionIssued", (int)ValueId.SanctionIssued);
            model.data = data.GetDataTable(cmd);
            CSVFileFormat csvfile = new CSVFileFormat(model.data, "PrintSanctionFile.csv");
            csvfile.ExecuteResult(this.ControllerContext);

            ViewData["message"] = "Print Sanction Successfully";
            return View("message");

        }

        [Authorize(Roles = "120")]
        [EncryptedActionParameter]
        public ActionResult UpdatePrematSchoolDetails(int? TypeId = 0)
        {
            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            PreMatricModel model = new PreMatricModel();
            string query = "SELECT psm.schoolid,psm.schoolname,psm.schoolcode,psm.schooladdress,psm.subdivision,psm.pincode,psm.schoolaffiliationid as AffiliatedId,psm.state,psm.whetheractive,psm.mobileno,   psm.emailid,psm.nodalofficer,psm.schooltypeid,psm.whetherdataupdate,pzm.zonename as subdivcode,pdm.districtname as district,SMVD.valuename as departmentid FROM  dgen.prematschoolmaster psm inner join dgen.prematdistrictmaster pdm on psm.district = pdm.districtid inner join dbo.selectmastervaluedetails SMVD on  psm.departmentid = SMVD.valueid left outer join dgen.prematzonemaster pzm on pzm.zoneid = psm.subdivision where PSM.schoolid=@schoolid;";
            NpgsqlCommand Cmd = new NpgsqlCommand(query);
            Cmd.Parameters.AddWithValue("@schoolid", Sessions.getEmployeeUser().AuthorizationId);
            model = PreMatricModel.Get<PreMatricModel>(new PreMatricModel(), Cmd);
            model.TypeId = TypeId.ToString();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult UpdatePrematSchoolDetails(PreMatricModel model)
        {
            GetData data = new GetData();
            PreMatricModel model1 = new PreMatricModel();
            string Qry = string.Empty; NpgsqlCommand Cmd = new NpgsqlCommand();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            if (ModelState.IsValid)
            {
                Qry = "UPDATE dgen.prematschoolmaster set schoolcode=@schoolcode,schooladdress=@schooladdress,pincode=@pincode,schoolaffiliationid=@schoolaffiliationid,mobileno=@mobileno,emailid=@emailid,nodalofficer=@nodalofficer,whetherdataupdate=@whetherdataupdate,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() WHERE schoolid=@schoolid;";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@schoolcode", model.SchoolId);
                Cmd.Parameters.AddWithValue("@schooladdress", model.SchoolAddress);
                Cmd.Parameters.AddWithValue("@pincode", model.PinCode);
                Cmd.Parameters.AddWithValue("@schoolaffiliationid", model.AffiliatedId);
                Cmd.Parameters.AddWithValue("@mobileno", model.MobileNo);
                Cmd.Parameters.AddWithValue("@emailid", model.EmailId);
                Cmd.Parameters.AddWithValue("@whetherdataupdate", true);
                Cmd.Parameters.AddWithValue("@nodalofficer", model.NodalOfficer);
                Cmd.Parameters.AddWithValue("@nodalofficer", model.NodalOfficer);
                Cmd.Parameters.AddWithValue("@schoolid", model.SchoolId);
                Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
                data.UpdateData(Cmd);
                ViewData["message"] = "School Details Updated Successfully";
                return View("message");
            }
            return View(model);
        }
        #endregion

        #region Higher Education
        [Authorize(Roles = "120")]
        [EncryptedActionParameter]
        public ActionResult PendingHeMCMApplicationSummary(int sid)
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.P120).ToString()) { return RedirectToAction("UnauthorizedRequest"); }
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            string join = string.Empty, cond = string.Empty;
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { cond += " and institutionid=@InstitutionId "; }
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { cond += " and AD.applicationsubdivcode in (@ParamSubDivCode) "; }

            string Qry = "select SM.ServiceName,SM.ServiceCode,count(AD.ApplicationNo) as TotalReceived,coalesce(sum(case when ApplicationStatusId in (@ApplicationStatusId) and WhetherRevertBack=@WhetherRevertBack then 1 end),0) as Pending,coalesce(sum(case when ApplicationStatusId in (@ApplicationStatusId) and WhetherRevertBack=@WhetherRevertBack1 then 1 end),0) as PendingReverted,coalesce(sum(case when ApplicationStatusId in (@CSCEDT) then 1 end),0) as PendingEdit,coalesce(sum(case when ApplicationStatusId not in (@ApplicationStatusId,@CSCEDT) then 1 end),0) as Verified  from dbo.ApplicationDetails AD Inner join dbo.ServiceMaster SM on AD.ServiceCode=SM.ServiceCode inner join dgen.heapplicationprocess HAP on HAP.ApplicationNo=AD.ApplicationNo where SM.deptcode=@ParamDeptCode  and AD.ServiceCode in (@ParamServiceCode) and HAP.Academicsession=(select ValueName::integer from SelectMasterValueDetails where ValueId=@AcademicSession)  " + cond + "  group by SM.ServiceName,SM.ServiceCode order by SM.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@WhetherRevertBack1", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@CSCEDT", (int)Status.CSCEDT);
            cmd.Parameters.AddWithValue("@AcademicSession", (int)ValueId.HigherEduCurAcadmicSession);
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@InstitutionId", Sessions.getEmployeeUser().AuthorizationId); }
            model.data = data.GetDataTable(cmd);

            Qry = "select SMVD.valuename as AcademicSession,(SMVD.valuename ||'-'||SMVD.valuename::integer + 1) as AcademicSessionType from  selectmastervaluedetails SMVD inner join selectmastervaluetodetails SMVTD  on SMVTD.valueid=SMVD.valueid where mastervalueid=@mastervalueid";
            cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HigherEduAcadmicSession);
            model.data1 = data.GetDataTable(cmd);
            if (model.data1 != null && model.data1.Rows.Count > 0)
            {
                model.AcademicSession = model.data1.Rows[0]["AcademicSession"].ToString();
                model.AcademicSessionType = model.data1.Rows[0]["AcademicSessionType"].ToString();
            }

            model.StatusId = sid.ToString();
            return View(model);
        }
        [Authorize(Roles = "120")]
        [EncryptedActionParameter]
        public ActionResult SearchHeMCMAppForAction(int sid)
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.P120).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            model.StatusId = sid.ToString();

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [Authorize(Roles = "120")]
        [EncryptedActionParameter]
        public ActionResult PendingHeMCMApplicationList(int service, int status, int AppType, int AcademicSession, string AcademicSessionType)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            string Whethercondition = string.Empty;
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { Whethercondition += " and institutionid=@InstitutionId "; }
            if (AppType == (int)CountList.Type000) { Whethercondition += " and whetherrevertback=@WhetherRevertBack "; }
            if (AppType == (int)CountList.Type001) { Whethercondition += " and whetherrevertback=@WhetherRevertBack1 "; }
            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate , dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicationsubdivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,AD.ApplicantDob,AD.ApplicationStatusId from dbo.ApplicationDetails AD inner join dgen.heapplicationprocess HAP on HAP.ApplicationNo=AD.ApplicationNo inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode where AD.ServiceCode=@ServiceCode  and AD.ApplicationStatusId=@ApplicationStatusId and HAP.AcademicSession=@AcademicSession  " + Whethercondition + " order by AD.applicationdate ";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ServiceCode", service);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", status);
            cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.False.ToString());
            cmd.Parameters.AddWithValue("@WhetherRevertBack1", CustomText.True.ToString());
            cmd.Parameters.AddWithValue("@AcademicSession", AcademicSession);
            if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { cmd.Parameters.AddWithValue("@InstitutionId", Sessions.getEmployeeUser().AuthorizationId); }
            model.data = data.GetDataTable(cmd);

            model.AcademicSessionType = AcademicSessionType;
            return View(model);
        }


        [Authorize(Roles = "120")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult PendingHeMCMApplicationDetails(ProcessModels model)
        {
            if (ModelState.IsValid)
            {
                model.StatusId = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ApplicationStatusId", "ApplicationNo", model.ApplicationNo.ToString())[0];
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo", "StsId" }, new ArrayList() { model.ApplicationNo, model.StatusId });
                return RedirectToAction("PendingHeMCMApplicationDetails", "Process", new { q = QueryString });
            }
            return View("SearchAppForAction", model);
        }
        [Authorize(Roles = "120")]
        [EncryptedActionParameter]
        public ActionResult PendingHeMCMApplicationDetails(Int64 AppNo, int StsId)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            model.ApplicationNo = AppNo.ToString();
            model.StatusId = StsId.ToString();
            string QueryString = string.Empty, cond = string.Empty;
            model.WhetherScStwelfateAllowed = false;
            Dictionary<string, string> ValidateData = new Dictionary<string, string>();
            ValidateData.Add("ApplicationNo", model.ApplicationNo);

            string DisplayMessage = Utility.WhetherAccessAllowed(ValidateData, new int[] { (int)ValueId.AuthCrendential, (int)ValueId.AuthOtp }, null, new int[] { (int)Status.OBSPEND }, false, false, true);
            if (!string.IsNullOrEmpty(DisplayMessage))
            {
                PreserveModelState(Constant._ActionMessage, DisplayMessage, false, true);
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.StatusId });
                return RedirectToAction("SearchHeMCMAppForAction", new { q = QueryString });
            }

            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { cond += " and ApplicationSubdivCode in (@ParamSubDivCode) "; }
            string Qry = "select ServiceCode,ApplicationStatusId,ApplicationNo FROM dbo.ApplicationDetails where ApplicationNo=@ApplicationNo " + cond + " and ServiceCode in (@ParamServiceCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            string[] Val = data.SelectColumns(Cmd);
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ServiceCode = Val[0];
            model.ApplicationDetails.ApplicationStatusId = Val[1];
            model.ApplicationDetails.ApplicationNo = Val[2];
            if (string.IsNullOrEmpty(model.ApplicationDetails.ApplicationNo))
            {
                PreserveModelState(Constant._ActionMessage, "Application Not Found or Not Available in you account, Kindly Check Your Application No.", false, true);
                QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.StatusId });
                return RedirectToAction("SearchHeMCMAppForAction", new { q = QueryString });
            }

            //model.WhetherDocVerified = true;
            model.WhetherDocVerified = Utility.CheckWhetherDocVerify(model.ApplicationNo, DB.LS.ToString());

            if (model.StatusId == ((int)Status.OBSPEND).ToString())
            {
                model.ApplicantDetails = Utility.GetApplicantDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());
                if (Convert.ToInt16(model.ApplicationDetails.ServiceCode) == (int)ServiceList.HeFinancialAssistance)
                {
                    model.HeMCMFinancialAssistance = Utility.GetHeMCMFinancialAssistanceDetails(model.ApplicationDetails.ApplicationNo, DB.LS.ToString());

                    model.HeMCMFinancialAssistance.TutionFee = Utility.GetHeScholorship(model.ApplicationDetails.ApplicationNo);
                    if (!string.IsNullOrEmpty(model.HeMCMFinancialAssistance.TutionFee))
                    {
                        model.WhetherScStwelfateAllowed = true;
                    }

                    //model.ApplicationDetailsPrematsSC.ScStFeeDetails = new List<ScStFeeDetails>();
                    //Qry = @"select a.servicecode,a.feetypeby,b.valuename,coalesce(c.feeamount,0) as feeamount from prematservicetofeehead a inner join selectmastervaluedetails b on b.valueid=a.feetypeby 
                    //        left outer join dgen.scstfeedetails c on c.feetypeby=a.feetypeby and c.feeinitiateby=@feeinitiateby and c.applicationno=@ApplicationNo where ServiceCode=@ServiceCode";
                    //Cmd = new NpgsqlCommand(Qry);
                    //Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.PrematricScholarshipSC);
                    //Cmd.Parameters.AddWithValue("@feeinitiateby", (int)ValueId.Department);
                    //Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
                    //DataTable Dt1 = data.GetDataTable(Cmd);

                    //for (int i = 0; i < Dt1.Rows.Count; i++)
                    //{
                    //    model.WhetherScStwelfateAllowed = true;//Changes20170614
                    //    model.ApplicationDetailsPrematsSC.ScStFeeDetails.Add(new ScStFeeDetails() { Sno = (i + 1).ToString(), FeeTypeId = Dt1.Rows[i]["feetypeby"].ToString(), FeeTypeName = Dt1.Rows[i]["valuename"].ToString(), FeeAmount = Dt1.Rows[i]["feeamount"].ToString() });
                    //}
                }

                Qry = "select Feeamount from dgen.hefeedetails where ApplicationNo=@ApplicationNo and FeeInitiateBy=@FeeInitiateBy";
                Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@FeeInitiateBy", (int)ValueId.Applicant);
                model.data4 = data.GetDataTable(Cmd);

                Qry = "select Processstatusid,WhetherRecommended,WhetherRevertBack,RevertBackRemarks,Instituteremarks from dgen.heapplicationprocess where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.data3 = data.GetDataTable(Cmd);

                model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", string.Empty, string.Empty, model.ApplicationDetails.ApplicationNo, DB.LS.ToString(), CustomText.N.ToString());
                model.data2 = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
                model.data1 = Utility.GetApplicantAvailedService(model.ApplicantDetails.RegistrationId.ToString());

                PreserveModelState(Constant._ModelStateParent, model, false, true);
                return View(model);
            }
            PreserveModelState(Constant._ActionMessage, "Entered Application Not Pending at this Level.", false, true);
            QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "sid" }, new ArrayList() { model.StatusId });
            return RedirectToAction("SearchHeMCMAppForAction", new { q = QueryString });
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SavePendingHeMCMApplicationDetails(ProcessModels model)
        {
            if (ModelState.IsValid)
            {
                GetData data = new GetData();
                NpgsqlCommand Cmd = new NpgsqlCommand();
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                string Qry = string.Empty, ApplicationStatusId = string.Empty, DisAmount = string.Empty;

                Dictionary<string, string> ValidateData = new Dictionary<string, string>();
                ValidateData.Add("ApplicationNo", model.ApplicationNo);

                string DisplayMessage = Utility.WhetherAccessAllowed(ValidateData, new int[] { (int)ValueId.AuthCrendential, (int)ValueId.AuthOtp }, null, new int[] { (int)Status.OBSPEND }, false, false, true);
                if (!string.IsNullOrEmpty(DisplayMessage))
                {
                    ViewBag.DisplayMessage = DisplayMessage;
                    PreserveModelState(Constant._ModelStateParent, null, true, false);
                    return View("PendingHeMCMApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
                }

                if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.HeFinancialAssistance).ToString())
                {
                    string resultrtn = Utility.CheckMCMCourseFee(model.ApplicationNo.ToString(), ((int)CountList.Type002).ToString());
                    if (!string.IsNullOrEmpty(resultrtn))
                    {
                        ViewData["message"] = resultrtn;
                        return View("message");
                    }
                }

                ApplicationStatusId = ((int)Status.TEHSPEN).ToString();
                if (model.HeMCMFinancialAssistance.WhetherSchoolRecomended.ToUpper() == CustomText.Y.ToString() || model.HeMCMFinancialAssistance.WhetherSchoolRecomended.ToUpper() == CustomText.N.ToString())
                {
                    if (model.ApplicationDetails.ServiceCode == ((int)ServiceList.HeFinancialAssistance).ToString())
                    {
                        if (model.HeMCMFinancialAssistance.WhetherSchoolRecomended.ToUpper() == CustomText.Y.ToString())
                        {
                            Qry = "Delete from dgen.hefeedetails where ApplicationNo=@ApplicationNo and FeeinitiateBy=@FeeinitiateBy";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                            cmdList.Add(Cmd);

                            Qry = "insert into dgen.hefeedetails(ApplicationNo,FeeinitiateBy,FeeTypeBy,FeeAmount,UserId,IpAddress,LastActionDate) values (@ApplicationNo,@FeeinitiateBy,@FeeTypeBy,@FeeAmount,@UserId,@IpAddress,now())";
                            Cmd = new NpgsqlCommand(Qry);
                            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                            Cmd.Parameters.AddWithValue("@FeeinitiateBy", (int)ValueId.Department);
                            Cmd.Parameters.AddWithValue("@FeeTypeBy", (int)ValueId.TuitionFees);
                            Cmd.Parameters.AddWithValue("@FeeAmount", model.HeMCMFinancialAssistance.TutionFee);
                            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                            Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                            cmdList.Add(Cmd);
                        }
                        Qry = "update dgen.heapplicationprocess set WhetherRecommended=@WhetherRecommended,Instituteremarks=@InstituteRemarks,ProcessStatusId=@ProcessStatusId,WhetherRevertBack=@WhetherRevertBack,VerificationDate=now(),VerificationBy=@VerificationBy,VerificationIpAddress=@VerificationIpAddress  where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@WhetherRecommended", model.HeMCMFinancialAssistance.WhetherSchoolRecomended);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@ProcessStatusId", (int)ValueId.Verified);
                        Cmd.Parameters.AddWithValue("@WhetherRevertBack", CustomText.False.ToString());
                        Cmd.Parameters.AddWithValue("@InstituteRemarks", model.SchollRemarks);
                        Cmd.Parameters.AddWithValue("@VerificationBy", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@VerificationIpAddress", Utility.GetIP4Address());
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);
                        cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG041, model.SchollRemarks, (int)ApplicationSource.Window, null));
                    }


                    Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationStatusId", ApplicationStatusId);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.SchollRemarks);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,ApplicationRemarks=@ApplicationRemarks,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationStatusId", ApplicationStatusId);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@ApplicationRemarks", model.SchollRemarks);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    cmdList.Add(Cmd);

                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationNo);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS031, smsDic));

                    //send email to applicant and insert record in table
                    Dictionary<string, string> EmailDic = new Dictionary<string, string>();
                    EmailDic.Add("ParamServerId", ((int)CountList.Type002).ToString());
                    EmailDic.Add("ParamSendType", ((int)SmsSendType.SMS031).ToString());
                    EmailDic.Add("ParamApplicationNo", model.ApplicationNo);
                    NpgsqlCommand EmailCmd = Utility.ApplicationProcessEmail((int)CountList.Type003, EmailDic);
                    if (EmailCmd != null) { cmdList.Add(EmailCmd); }
                }
                else
                {
                    Dictionary<string, string> smsDic = new Dictionary<string, string>();
                    smsDic.Add("ParamApplicationNo", model.ApplicationNo);
                    smsDic.Add("ParamRemarks", model.SchollRemarks);
                    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS037, smsDic));
                }
                data.SaveData(cmdList);

                ViewData["message"] = "Application [" + model.ApplicationNo + "] has been processed successfully.";
                return View("message");
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("PendingHeMCMApplicationDetails", (ProcessModels)TempData[Constant._ModelStateParent]);
        }
        #endregion

        #region Social Welfare
        [EncryptedActionParameter]
        public ActionResult SWDistwiseSanctionSummary()
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.TEHS).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            string join = string.Empty, cond = string.Empty;
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { cond = " and AD.ApplicationsubdivCode=@ParamSubDivCode "; }
            string Qry = "select SDM.SubDivCode,Subdivdescription,ApplicationDistrictCode,DistrictName,count(distinct SPD.SanctionId)  as TotalSanction  from  sanctionpaymentdetails  as SPD inner join sanctionapplicationdetails SAD on  SAD.SanctionId=SPD.SanctionId inner join ApplicationDetails AD on  AD.ApplicationNo=SAD.ApplicationNo inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode right outer join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode right outer join SubDivMaster SDM on SDM.SubDivCode=AD.ApplicationSubDivCode where ApplicationStatusId=@ApplicationStatusId and SM.Deptcode=@ParamDeptCode " + cond + " group by SDM.SubDivCode,Subdivdescription,ApplicationDistrictCode,DistrictName order by Subdivdescription";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult SWServicewiseSanctionSummary(int SubDivCode, int DistCode)
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.TEHS).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            string join = string.Empty, cond = string.Empty;
            if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { cond = " and AD.ApplicationsubdivCode=@ParamSubDivCode "; }
            string Qry = "select AD.ApplicationsubdivCode,AD.ApplicationDistrictCode,AD.ServiceCode,ServiceName,count(distinct SPD.SanctionId) as TotalSanction from  sanctionpaymentdetails  as SPD inner join sanctionapplicationdetails SAD on  SAD.SanctionId=SPD.SanctionId inner join ApplicationDetails AD on  AD.ApplicationNo=SAD.ApplicationNo inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode right outer join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode right outer join SubDivMaster SDM on SDM.SubDivCode=AD.ApplicationSubDivCode where ApplicationStatusId=@ApplicationStatusId and SM.Deptcode=@ParamDeptCode and AD.ApplicationsubdivCode=@SubDivCode and AD.ApplicationDistrictCode=@DistCode group by AD.ServiceCode,ServiceName,AD.ApplicationsubdivCode,AD.ApplicationDistrictCode order by ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@SubDivCode", SubDivCode);
            cmd.Parameters.AddWithValue("@DistCode", DistCode);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult SWSanctionList(int SubDivCode, int DistCode, int ServiceCode)
        {
            if (Sessions.getEmployeeUser().Permission != ((int)Permission.TEHS).ToString()) { return RedirectToAction("UnauthorizedRequest"); }

            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            //string join = string.Empty, cond = string.Empty;
            //if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { cond = " and AD.ApplicationsubdivCode=@ParamSubDivCode "; }

            string Qry = "select SPD.signedrefid,ReferenceCode,Subdivdescription,DistrictName,ServiceName, SPD.SanctionId,to_char(SPD.lastactiondate,'DD/MM/YYYY') as SanctionDate,count(AD.ApplicationNo) as TotalApplication  from  sanctionpaymentdetails  as SPD inner join sanctionapplicationdetails SAD on  SAD.SanctionId=SPD.SanctionId inner join ApplicationDetails AD on  AD.ApplicationNo=SAD.ApplicationNo inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode right outer join DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode right outer join SubDivMaster SDM on SDM.SubDivCode=AD.ApplicationSubDivCode where ApplicationStatusId=@ApplicationStatusId and SM.Deptcode=@ParamDeptCode and AD.ApplicationsubdivCode=@SubDivCode and AD.ServiceCode=@ServiceCode  and AD.ApplicationDistrictCode=@DistCode group by ReferenceCode,SPD.SanctionId,Subdivdescription,DistrictName,ServiceName order by ReferenceCode";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER);
            cmd.Parameters.AddWithValue("@SubDivCode", SubDivCode);
            cmd.Parameters.AddWithValue("@DistCode", DistCode);
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult SWDDownloadCsvFormat()
        {
            ProcessModels model = new ProcessModels();
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult SWDDownloadCsvFormat(ProcessModels model)
        {
            GetData data = new GetData();
            if (ModelState.IsValid)
            {
                //string Qry = @"select AD.ApplicationNo as ""Application No"",ApplicantName as ""Applicant Name"",ApplicantMotherName as ""Mother Name"",ApplicantFatherName as ""Father Name"",ApplicantHusbandName as ""Spouse Name"",case when ApplicantGender='M' then 'Male' when ApplicantGender='F' then 'Female' end as ""Gender"",to_char(ApplicantDob,'DD/MM/YYYY') as ""Date Of Birth"",null as ""Age"",dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ""Address"",LocalityName as ""Locality"",ConstituencyName as ""Constituency"",DistrictName as ""District"",applicantpincode as ""Pincode"",ApplicantMobileNo as ""Mobile Number"",null as ""Caste"",";
                string Qry = @"select case when AD.DocumentId=@DocumentId then dbo.udf_general_decrypt(AD.DocumentNo) when RDM.DocumentId=@DocumentId then dbo.udf_general_decrypt(RDM.DocumentNo) end as ""Aadhaar No"" ,AD.ApplicationNo as ""Application No"",ApplicantName as ""Applicant Name"",ApplicantMotherName as ""Mother Name"",ApplicantFatherName as ""Father Name"",ApplicantHusbandName as ""Spouse Name"",case when ApplicantGender='M' then 'Male' when ApplicantGender='F' then 'Female' end as ""Gender"",to_char(ApplicantDob,'DD/MM/YYYY') as ""Date Of Birth"",null as ""Age"",dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ""Address"",LocalityName as ""Locality"",ConstituencyName as ""Constituency"",DistrictName as ""District"",applicantpincode as ""Pincode"",ApplicantMobileNo as ""Mobile Number"",null as ""Caste"",";
                if (model.ServiceId == ((int)ServiceList.DFBScheme).ToString()) { Qry += @"bankaccno as ""Account Number"","; }
                else { Qry += @"AccountNo as  ""Account Number"","; }
                Qry += @"BankName as ""Bank Name"",branchaddress as ""Bank Branch Address"",micrcode as ""MICR Code"",";
                if (model.ServiceId == ((int)ServiceList.DFBScheme).ToString()) { Qry += @"null as ""IFSC Code"",ReligionName as ""Caste Category"","; }
                else { Qry += @"ifsccode as ""IFSC Code"",categoryName as ""Caste Category"","; }
                if (model.ServiceId == ((int)ServiceList.Handicapped).ToString()) { Qry += @" disabilitytypeName as ""Type of Disability"", "; }

                //Qry += @" StatusName as ""Status"",to_char(ApplicationDate,'DD/MM/YYYY') as ""Application Date"",case when AD.ApplicationStatusId=@Issued then to_char(AD.lastactiondate,'DD/MM/YYYY') else NULL end as ""Sign Date""  from applicationdetails AD inner join LocalityMaster LM on LM.LocalityId=AD.ApplicantLocalityId inner join DistrictMaster DM on DM.DistrictCode=AD.applicantdistrictcode inner join StatusMaster SM on SM.StatusId=AD.ApplicationStatusId  ";
                Qry += @" StatusName as ""Status"",case when ApplicationStatusId in (@CANCEL,@TEHSREJ,@TEHSOBJ) then ApplicationRemarks else null end as ""Remarks"",to_char(ApplicationDate,'DD/MM/YYYY') as ""Application Date"",case when AD.ApplicationStatusId=@Issued then to_char(AD.lastactiondate,'DD/MM/YYYY') else NULL end as ""Sign Date""  from applicationdetails AD inner join LocalityMaster LM on LM.LocalityId=AD.ApplicantLocalityId inner join DistrictMaster DM on DM.DistrictCode=AD.applicantdistrictcode inner join StatusMaster SM on SM.StatusId=AD.ApplicationStatusId  ";
                if (model.ServiceId == ((int)ServiceList.OldAge).ToString()) { Qry += " left outer join dgen.applicationdetailsoldage  ADS on ADS.ApplicationNo=AD.ApplicationNo "; }
                if (model.ServiceId == ((int)ServiceList.Handicapped).ToString()) { Qry += " left outer join dgen.applicationdetailshandicapped  ADS on ADS.ApplicationNo=AD.ApplicationNo left outer join disabilitytypemaster DTM on DTM.disabilitytypeid=ADS.disabilitytypeid "; }
                if (model.ServiceId == ((int)ServiceList.DFBScheme).ToString()) { Qry += " left outer join dgen.applicationdetailsdfbscheme  ADS on ADS.ApplicationNo=AD.ApplicationNo"; }

                if (model.ServiceId == ((int)ServiceList.DFBScheme).ToString()) { Qry += " left outer join assemblyconstituencymaster ACM on ACM.ConstituencyId=ADS.MLAConstituencyId left outer join religionmaster CM on CM.ReligionId=ADS.Religion left outer join BankMaster BBM on BBM.BankCode=ADS.BankCode"; }
                else { Qry += " left outer join assemblyconstituencymaster ACM on ACM.ConstituencyId=ADS.ConstituencyId left outer join dbo.ApplicantBankDetails ABD on ABD.ApplicationNo=AD.ApplicationNo left outer join categorymaster CM on CM.categoryid=ADS.categoryid left outer join BankMaster BBM on BBM.BankCode=ABD.BankCode"; }
                Qry += "  left outer join registrationtodocumentmaster RDM on RDM.RegistrationId=AD.RegistrationId  and RDM.DocumentId=@DocumentId where AD.ServiceCode=@ServiceCode and ApplicationStatusId=@ApplicationStatusId";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@DocumentId", (int)CountList.Type001);
                cmd.Parameters.AddWithValue("@ServiceCode", model.ServiceId);
                cmd.Parameters.AddWithValue("@Issued", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@ApplicationStatusId", model.StatusId);
                cmd.Parameters.AddWithValue("@CANCEL", (int)Status.CANCEL);
                cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
                cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
                model.data = data.GetDataTable(cmd);


                if (model.data.Rows.Count > 0)
                {
                    var grid = new System.Web.UI.WebControls.GridView();
                    grid.DataSource = model.data;
                    grid.DataBind();
                    Response.Clear();
                    Response.AddHeader("content-disposition", "attachment; filename=StatusWiseApplication.xls");
                    Response.Charset = "";
                    Response.ContentType = "application/vnd.xls";
                    System.IO.StringWriter stringWrite = new System.IO.StringWriter();
                    System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
                    grid.RenderControl(htmlWrite);
                    string style = @"<style> td { mso-number-format:\@; } </style>";
                    Response.Write(style);

                    Response.Write(stringWrite.ToString());
                    Response.End();

                    ViewData["message"] = "File Downloaded Successfully";
                    return View("message");
                }
                else
                {
                    ViewData["message"] = "No Record Found";
                    return View("message");
                }
            }
            return View(model);

        }
        #endregion

        #region BIOMETRIC Process
        [Authorize(Roles = "117")]
        [EncryptedActionParameter]
        [ValidateOnlyIncomingValues]
        public ActionResult BioApplicationEntryForm(Int64 AppNo)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();
            return View(model);
        }
        [Authorize(Roles = "117")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult BioApplicationEntryForm(ProcessModels model)
        {
            if (ModelState.IsValid)
            {

                GetData data = new GetData();
                bool rtrn = Utility.UpdateBioApplicantDetails(model.ApplicationDetails.ApplicationNo, model.ApplicationDetails.BioApplicantAadhaarNo, model.ApplicationDetails.ApplicantName, model.ApplicationDetails.ApplicantDob, model.ApplicationDetails.ApplicantGender);
                if (rtrn == true)
                {
                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationDetails.ApplicationNo });
                    return RedirectToAction("BioApplicationVerifyForm", "Process", new { q = QueryString });
                }
                return View(model);
            }
            return View(model);
        }
        [Authorize(Roles = "117")]
        [EncryptedActionParameter]
        [ValidateOnlyIncomingValues]
        public ActionResult BioApplicationVerifyForm(Int64 AppNo)
        {
            GetData data = new GetData();
            ProcessModels model = new ProcessModels();
            model.ApplicationDetails = new ApplicationDetails();
            model.ApplicationDetails.ApplicationNo = AppNo.ToString();
            string qry = "select ApplicationNo,ReferenceId,dbo.udf_general_decrypt(UID) as UID,ApplicantUIDName,case when ApplicantUidGender='M' Then 'Male' when ApplicantUidGender='F' Then 'Female' end as ApplicantUidGender,to_char(ApplicantUidDob,'DD/MM/YYYY') as ApplicantUidDob from BioApplicationDetails where ApplicationNo=@ApplicationNo";
            NpgsqlCommand cmd = new NpgsqlCommand(qry);
            cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationDetails.ApplicationNo);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [Authorize(Roles = "117")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateOnlyIncomingValues]
        [ValidateAntiForgeryToken]
        public ActionResult BioApplicationVerifyForm(ProcessModels model)
        {
            if (ModelState.IsValid)
            {

                GetData data = new GetData();
                string Qry = @"Select ADCDV.ApplicationNo,EnrollmentNo,to_char(EnrollmentDate,'DD/MM/YYYY') as EnrollDate,ApplicantName,ApplicationStatusId,ApplicantmobileNo,to_char(ApplicantDOB,'DD/MM/YYY') as ApplicantDOB,dbo.displaycompleteaddressfromid(AD.Applicanthousenumber,AD.Applicantstreetnumber,AD.Applicantsublocality,AD.Applicantlocalityid,AD.ApplicationSubDivCode,AD.Applicationdistrictcode,AD.stateid,AD.countryid,AD.Applicantpincode) as HPermanentAddress  from  dgen.ApplicationDetailsCDV  ADCDV inner join ApplicationDetails AD on AD.ApplicationNo=ADCDV.ApplicationNo  Inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.Applicationdistrictcode left outer join dgen.CDVTechnicalEducationDetail CDVTED on CDVTED.ApplicationNo=ADCDV.ApplicationNo ";
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and TechnicalEducationId=@TechnicalEducationId "; }
                Qry += " where AD.ServiceCode in (@ParamServiceCode)  and ApplicationStatusId=@ApplicationStatusId  and DM.deptcode=@ParamDeptCode and ADCDV.WhetherBasicTrainingComplete=@WhetherBasicTrainingComplete ";
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DM.DistrictCode=@ParamDistrictCode"; }
                if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.SEqualificationId)) { Qry += " and ADCDV.EqualificationId=@EqualificationId"; }
                if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.SBloodGroup)) { Qry += " and ADCDV.BloodGroup=@BloodGroup"; }
                //if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.SCDVSubDivCode)) { Qry += " and ADCDV.CDVSubDivCode=@CDVSubDivCode"; }
                if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.SGender)) { Qry += " and AD.ApplicantGender=@ApplicantGender"; }
                if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.SOccupationId)) { Qry += " and ADCDV.OccupationId=@OccupationId"; }
                if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.STqualificationId)) { Qry += " and TechnicalEducationId=@TechnicalEducationId"; }
                if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.Sheight)) { Qry += " and ADCDV.heightfeet >= @height and heightinch>0"; }
                if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.SChest)) { Qry += " and ADCDV.chest >@SChest"; }
                //if (!string.IsNullOrEmpty(model.ApplicationDetailsCDV.SSubDivCode)) { Qry += " and AD.ApplicationSubDivCode=@SSubDivCode"; }
                Qry += " order by EnrollDate";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.TEHSREC);
                cmd.Parameters.AddWithValue("@WhetherBasicTrainingComplete", CustomText.True.ToString());
                cmd.Parameters.AddWithValue("@EqualificationId", model.ApplicationDetailsCDV.SEqualificationId);
                cmd.Parameters.AddWithValue("@TechnicalEducationId", model.ApplicationDetailsCDV.STqualificationId);
                cmd.Parameters.AddWithValue("@BloodGroup", model.ApplicationDetailsCDV.SBloodGroup);
                cmd.Parameters.AddWithValue("@ApplicantGender", model.ApplicationDetailsCDV.SGender);
                cmd.Parameters.AddWithValue("@OccupationId", model.ApplicationDetailsCDV.SOccupationId);
                cmd.Parameters.AddWithValue("@height", model.ApplicationDetailsCDV.Sheight);
                cmd.Parameters.AddWithValue("@SChest", model.ApplicationDetailsCDV.SChest);
                //cmd.Parameters.AddWithValue("@SSubDivCode", model.ApplicationDetailsCDV.SSubDivCode);
                model.data = data.GetDataTable(cmd);


                //Qry = "select CDVSubDivCode,CDVSubDivName from CDVSubDivMaster where WhetherActive=@WhetherActive";
                //NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                //Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                //List<CDVSubDivMaster> ServiceTypeMasterList = CDVSubDivMaster.List<CDVSubDivMaster>(Cmd);
                //model.ApplicationDetailsCDV.CDVSubDivList = new SelectList(ServiceTypeMasterList, "CDVSubDivCode", "CDVSubDivName");
                model.CDVDutyDetails = new CDVDutyDetails();
                return View(model);
            }
            return View(model);
        }
        #endregion

        #region global method current contoller
        //method for preserve model state
        public void PreserveModelState(string Key, object obj, bool IsKeep, bool IsRemove)
        {
            if (IsRemove == true) { TempData.Remove(Key); }
            if (obj != null) { TempData[Key] = obj; }
            if (IsKeep == true) { TempData.Keep(Key); }
        }
        #endregion global method current contoller
    }
}
