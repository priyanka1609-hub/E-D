﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.ApplicationService;
using Edistrict.Models;
using System.Web.UI;
using Npgsql;
using System.Data;
using System.Collections;
using Edistrict.Models.Entities;
using Edistrict.Models.CustomClass;
using System.Web.Security;

namespace Edistrict.Controllers
{
    [Authorize(Roles = "104,123")]
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class SdmController : Controller
    {
        #region action methods for re-assign/modify the solemnization date
        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult ReAssignSolemnizationDate(Int64? AppNo)
        {
            if (AppNo == null) { return View(); }

            GetData data = new GetData();
            SdmModels model = new SdmModels();
            model.ApplicationNo = AppNo.ToString();

            Dictionary<string, string> ValidateData = new Dictionary<string, string>();
            ValidateData.Add("ApplicationNo", model.ApplicationNo);
            string DisplayMessage = Utility.WhetherAccessAllowed(ValidateData, new int[] { (int)ValueId.AuthDigital, (int)ValueId.AutheKYC }, new int[] { (int)ValueId.SignDigital, (int)ValueId.SignEsign }, new int[] { (int)Status.TEHSPEN, (int)Status.NOTIACT }, false, true, true);
            if (!string.IsNullOrEmpty(DisplayMessage))
            {
                ViewData["message"] = DisplayMessage;
                return View("message");
            }

            string Qry = "select ApplicationStatusId,ServiceCode from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ApplicationSubDivCode in (@ParamSubDivCode) and ServiceCode in(@ParamServiceCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            string StatusCheck = data.SelectColumns(Cmd)[0];
            string ServiceCode = data.SelectColumns(Cmd)[1];
            if (ServiceCode == ((int)ServiceList.Solemnization).ToString())
            {
                if (StatusCheck == ((int)Status.NOTIACT).ToString() || StatusCheck == ((int)Status.TEHSPEN).ToString())
                {
                    Qry = "select to_char(SolemnizationDate,'DD/MM/YYYY') as SolemnizationDate,ApplicationNo from dgen.applicationmarriagesolemnizationdetails where ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    model.SolemnizationDate = data.SelectColumns(Cmd)[0];

                    if (!string.IsNullOrEmpty(model.SolemnizationDate))
                    {
                        Qry = "select ApplicationNo from dgen.SolemnizationLetterDetails where ApplicationNo=@ApplicationNo and TypeValueId in (@TypeValueId1,@TypeValueId2)";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@TypeValueId1", (int)LetterTypeValueId.SolemnizationVerificationLetter);
                        Cmd.Parameters.AddWithValue("@TypeValueId2", (int)LetterTypeValueId.SolemnizationNotice);
                        model.data = data.GetDataTable(Cmd);
                        if (model.data.Rows.Count > 0)
                        {
                            ViewBag.DisplayMessage = "Note:\\n You have already generated the verification letter and notice to with assigned date of Solemnization.\\n However you can take print of generated letter and notice or you can generate a new letter and notice after re-assigned the new date of Solemnization.";
                        }
                        model.OldSolemnizationDate = model.SolemnizationDate;
                        model.SolemnizationDate = null;
                        return View(model);
                    }
                    else
                    {
                        ViewBag.DisplayMessage = "Could not re-assign solemnization date before approval!";
                    }

                }
                else
                {
                    ViewBag.DisplayMessage = "Could not re-assign solemnization date at this level!";
                }
            }
            else
            {
                ViewBag.DisplayMessage = "The application is not belongs to solemnization of Marriage.";
            }
            return View();
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult ReAssignSolemnizationDate(SdmModels model)
        {
            if (ModelState.IsValid)
            {
                if (string.IsNullOrEmpty(model.SolemnizationDate))
                {
                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationNo });
                    return RedirectToAction("ReAssignSolemnizationDate", "SDM", new { q = QueryString });
                }
                else
                {
                    GetData data = new GetData();
                    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                    string Qry = "select AD.applicationno from applicationdetails AD inner join dgen.applicationmarriagesolemnizationdetails AMSD on AMSD.ApplicationNo=AD.ApplicationNo where AD.applicationno=@ApplicationNo and applicationsubdivcode in (@ParamSubDivCode) and ServiceCode in(@ParamServiceCode) and @SolemnizationDate >= (noticegeneratedate::date + interval '30' day)";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@SolemnizationDate", Utility.GetDateYYYYMMDD(model.SolemnizationDate, '/', "0/1/2"));
                    string AppNo = data.SelectColumns(Cmd)[0];
                    if (!string.IsNullOrEmpty(AppNo))
                    {
                        Qry = "update dgen.applicationmarriagesolemnizationdetails set SolemnizationDate=@SolemnizationDate,UserId=@UserId,IpAddress=@IpAddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@SolemnizationDate", Utility.GetDateYYYYMMDD(model.SolemnizationDate, '/', "0/1/2"));
                        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
                        cmdList.Add(Cmd);

                        //insert in department audit trail                    
                        cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo.ToString(), (int)ApplicationHistoryMessage.MSG031, null, (int)ApplicationSource.Window, null));

                        data.SaveData(cmdList);

                        ViewBag.DisplayMessage = "Solemnization Date Re-assigned successfully!";
                    }
                    else
                    {
                        ViewBag.DisplayMessage = "You are not authorized to change solemnization date Or You have choosed wrong solemnization date!";
                    }
                }
            }
            return View();
        }

        //[EncryptedActionParameter]
        //[AcceptVerbs(HttpVerbs.Get)]
        //public ActionResult ModifySolemnizationDate(Int64? AppNo)
        //{
        //    if (AppNo == null) { return View(); }
        //    GetData data = new GetData();
        //    SdmModels model = new SdmModels();
        //    model.ApplicationNo = AppNo.ToString();

        //    Dictionary<string, string> ValidateData = new Dictionary<string, string>();
        //    ValidateData.Add("ApplicationNo", model.ApplicationNo);

        //    string DisplayMessage = Utility.WhetherAccessAllowed(ValidateData, new int[] { (int)ValueId.AuthDigital, (int)ValueId.AutheKYC }, new int[] { (int)ValueId.SignDigital, (int)ValueId.SignEsign }, new int[] { (int)Status.TEHSPEN, (int)Status.NOTIACT }, false, true, true);
        //    if (!string.IsNullOrEmpty(DisplayMessage))
        //    {
        //        ViewData["message"] = DisplayMessage;
        //        return View("message");
        //    }

        //    string Qry = "select ApplicationStatusId,ServiceCode from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ApplicationSubDivCode in (@ParamSubDivCode) and ServiceCode in(@ParamServiceCode) and applicationno=@ApplicationNo"; //90740000000549
        //    NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
        //    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
        //    string[] strArray = data.SelectColumns(Cmd);
        //    string StatusCheck = strArray[0];
        //    string ServiceCode = strArray[1];
        //    if (ServiceCode == ((int)ServiceList.Solemnization).ToString())
        //    {
        //        if (StatusCheck == ((int)Status.NOTIACT).ToString())
        //        {
        //            Qry = "select to_char(SolemnizationDate,'DD/MM/YYYY') as SolemnizationDate,ApplicationNo from dgen.applicationmarriagesolemnizationdetails where ApplicationNo=@ApplicationNo";
        //            Cmd = new NpgsqlCommand(Qry);
        //            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
        //            model.SolemnizationDate = data.SelectColumns(Cmd)[0];

        //            if (!string.IsNullOrEmpty(model.SolemnizationDate))
        //            {
        //                Qry = "select ApplicationNo from dgen.SolemnizationLetterDetails where ApplicationNo=@ApplicationNo and TypeValueId in (@TypeValueId1,@TypeValueId2)";
        //                Cmd = new NpgsqlCommand(Qry);
        //                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
        //                Cmd.Parameters.AddWithValue("@TypeValueId1", (int)LetterTypeValueId.SolemnizationVerificationLetter);
        //                Cmd.Parameters.AddWithValue("@TypeValueId2", (int)LetterTypeValueId.SolemnizationNotice);
        //                model.data = data.GetDataTable(Cmd);
        //                if (model.data.Rows.Count > 0)
        //                {
        //                    ViewBag.DisplayMessage = "Note:\\n You have already generated the verification letter and notice to with assigned date of Solemnization.\\n However you can take print of generated letter and notice or you can generate a new letter and notice after re-assigned the new date of Solemnization.";
        //                }
        //                model.OldSolemnizationDate = model.SolemnizationDate;
        //                model.SolemnizationDate = null;
        //                return View(model);
        //            }
        //            else
        //            {
        //                ViewBag.DisplayMessage = "Could not Modify solemnization date before approval!";
        //            }

        //        }
        //        else
        //        {
        //            ViewBag.DisplayMessage = "Could not Modify solemnization date at this level!";
        //        }
        //    }
        //    else
        //    {
        //        ViewBag.DisplayMessage = "Could not Modify solemnization date at this level!";
        //    }
        //    return View();
        //}
        //[AcceptVerbs(HttpVerbs.Post)]
        //[ValidateAntiForgeryToken]
        //[ValidateOnlyIncomingValues]
        //public ActionResult ModifySolemnizationDate(SdmModels model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        if (string.IsNullOrEmpty(model.SolemnizationDate))
        //        {
        //            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationNo });
        //            return RedirectToAction("ModifySolemnizationDate", "SDM", new { q = QueryString });
        //        }
        //        else
        //        {
        //            GetData data = new GetData();
        //            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

        //            string Qry = "select applicationno from applicationdetails where applicationno=@ApplicationNo and applicationsubdivcode in (@ParamSubDivCode) and ServiceCode in(@ParamServiceCode) and @SolemnizationDate >= (applicationdate::date + interval '30' day)";
        //            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
        //            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
        //            Cmd.Parameters.AddWithValue("@SolemnizationDate", Utility.GetDateYYYYMMDD(model.SolemnizationDate, '/', "0/1/2"));
        //            string AppNo = data.SelectColumns(Cmd)[0];
        //            if (!string.IsNullOrEmpty(AppNo))
        //            {
        //                Qry = "select AppointmentDate from dbo.AppointmentMaster where ServiceCode=@ServiceCode and SubDivCode in (@ParamSubDivCode) and AppointmentDate=@SolemnizationDate limit 1";
        //                Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
        //                Cmd.Parameters.AddWithValue("@SolemnizationDate", Utility.GetDateYYYYMMDD(model.SolemnizationDate, '/', "0/1/2"));
        //                Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.Solemnization);
        //                AppNo = data.SelectColumns(Cmd)[0];
        //                if (!string.IsNullOrEmpty(AppNo))
        //                {
        //                    Qry = "update dgen.applicationmarriagesolemnizationdetails set UserId=@UserId,IpAddress=@IpAddress,SolemnizationDate=@SolemnizationDate where ApplicationNo=@ApplicationNo";
        //                    Cmd = new NpgsqlCommand(Qry);
        //                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
        //                    Cmd.Parameters.AddWithValue("@SolemnizationDate", Utility.GetDateYYYYMMDD(model.SolemnizationDate, '/', "0/1/2"));
        //                    Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
        //                    Cmd.Parameters.AddWithValue("@IpAddress", Utility.GetIP4Address());
        //                    cmdList.Add(Cmd);

        //                    //insert in department audit trail                    
        //                    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo.ToString(), (int)ApplicationHistoryMessage.MSG031, null, (int)ApplicationSource.Window, null));
        //                    data.SaveData(cmdList);
        //                    ViewBag.DisplayMessage = "Solemnization Date modify successfully!";
        //                }
        //                else
        //                {
        //                    ViewBag.DisplayMessage = "You have choosed wrong solemnization date!";
        //                }
        //            }
        //            else
        //            {
        //                ViewBag.DisplayMessage = "You are not authorized to modify the solemnization date!";
        //            }
        //        }
        //    }
        //    return View();
        //}
        #endregion

        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult PendingLBRRecoveryApplicationList(int sid)
        {
            string value = string.Empty;

            GetData data = new GetData();
            SdmModels model = new SdmModels();
            string WhetherCondition = string.Empty;

            string Qry = "select AD.ServiceCode,AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,SL.StatusName,AD.ApplicationStatusId  from applicationdetails  AD inner join localitytosubdivmaster a on a.localityid=AD.applicantlocalityid inner join subdivmaster b on b.subdivcode=a.subdivcode inner join districtmaster c on c.districtcode=b.districtcode inner join dbo.StatusMaster SL on AD.ApplicationStatusId=SL.StatusId  where c.deptcode=@DeptCode and c.stateid=@StateId and a.subdivcode in (@ParamSubDivCode) and AD.servicecode in (@ParamServiceCode) and AD.servicecode=@ServiceCode and AD.AcceptedBy in (@AcceptedBy) and AD.ApplicationStatusId=@ApplicationStatusId  and AD.OfficeCode=@OfficeCode   order by AD.applicationdate";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.LbrRecovery);
            cmd.Parameters.AddWithValue("@ApplicationStatusId", sid);
            cmd.Parameters.AddWithValue("@AcceptedBy", Sessions.getEmployeeUser().Permission);
            cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
            cmd.Parameters.AddWithValue("@DeptCode", Sessions.getEmployeeUser().DeptCode);
            cmd.Parameters.AddWithValue("@StateId", (int)State.Delhi);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult PendingLBRRecoveryApplication(Int64 AppNo)
        {
            GetData data = new GetData();
            SdmModels model = new SdmModels();

            model.ApplicantDetails = Utility.GetApplicantDetails(AppNo.ToString(), DB.LS.ToString());
            model.data = Utility.GetEnclosureDetails(ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", ControllerList.Receiving.ToString(), "DpApplicationEnclosureDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.data1 = Utility.GetPhotoDetails(ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", ControllerList.Receiving.ToString(), "DpApplicationPhotoDetails", model.ApplicantDetails.ApplicationNo.ToString(), DB.LS.ToString(), CustomText.N.ToString());
            model.ApplicationDetailsLBRRecovery = Utility.GetLBRRecoveryDetails(model.ApplicantDetails.ApplicationNo, DB.LS.ToString());

            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingLBRRecoveryApplication(SdmModels model)
        {
            GetData data = new GetData();
            int SigningTypeId = Convert.ToInt32(Utility.SelectColumnsValue("dbo.usermaster", "signingtypeid", "UserId", Sessions.getEmployeeUser().UserId)[0]);
            if (SigningTypeId != (int)ValueId.SignDigital)
            {
                ViewBag.DisplayMessage = "You need to be digitally signed in to take action on this application.";
                PreserveModelState(Constant._ModelStateParent, null, true, false);
                return View("PendingLBRRecoveryApplication", (SdmModels)TempData[Constant._ModelStateParent]);
            }

            List<CMDInfoList> cmdList = new List<CMDInfoList>();
            CMDInfoList CmdInfo = new CMDInfoList();
            CMDInfoList tempCmdInfo = new CMDInfoList();

            string Qry = "select AD.ApplicationId,AD.ApplicationNo,SM.ServiceName as ServiceCode,AD.ApplicantName,IR.RelatedTo as ApplicantType,AD.ApplicantGender,AD.RegistrationId,RM.DocumentId,dbo.udf_general_decrypt(RM.DocumentNo) as DocumentNo,DocM.DocumentName,AD.ApplicantFatherName,AD.ApplicantMotherName,AD.ApplicantHusbandName,AD.ApplicantMobileNo,AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode,to_char(AD.ApplicantDob,'DD/MM/YYYY') as ApplicantDob,AD.ApplicantNationality,AD.ApplicantLocalityId,AD.IpAddress,to_char(now(),'DD/MM/YYYY') as ApplicationDate,ST.StatusId,AD.WhetherDocumentSeen,AD.ApplicantPermanentAddress,AD.WhetherSameAddress FROM dbo.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.SubDivMaster SDM on SDM.SubDivCode=AD.ApplicantSubDivCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.InformationRelatedMaster IR on IR.RelatedId=AD.ApplicationRelatedId inner join web.RegistrationMaster RM on RM.RegistrationId=AD.RegistrationId inner join dbo.DocumentMaster DocM on DocM.DocumentId=RM.DocumentId where AD.ApplicationNo=@ApplicationNo";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
            model.ApplicantDetails = ApplicantDetails.Get<ApplicantDetails>(new ApplicantDetails(), Cmd);

            Qry = "select x.subdivcode,x.districtcode from subdivmaster x inner join(select subdivcode from localitytosubdivmaster where localityid=@localityid and subdivcode in (select subdivcode from subdivmaster where districtcode in (select districtcode from districtmaster where deptcode=@deptcode and stateid=@stateid))) y on x.subdivcode=y.subdivcode";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@localityid", Utility.SelectColumnsValue("dgen.ApplicationDetailsLBRRecovery", "EstLocalityId", "ApplicationNo", model.ApplicantDetails.ApplicationNo)[0]);
            Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
            Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
            string[] revSD = data.SelectColumns(Cmd);

            string CaseNo = Utility.SelectColumnsValue("dgen.ApplicationDetailsLBRRecovery", "CaseNo", "ApplicationNo", model.ApplicantDetails.ApplicationNo)[0];

            Qry = "select (cast(@ServiceCode as varchar) || case when length(MaxAppNo)=1 then ('000000000' || MaxAppNo) when length(MaxAppNo)=2 then ('00000000' || MaxAppNo) when length(MaxAppNo)=3 then ('0000000'|| MaxAppNo) when length(MaxAppNo)=4 then ('000000' || MaxAppNo) when length(MaxAppNo)=5 then ('00000' || MaxAppNo) when length(MaxAppNo)=6 then ('0000' || MaxAppNo) when length(MaxAppNo)=7 then ('000' || MaxAppNo) when length(MaxAppNo)=8 then ('00' || MaxAppNo) when length(MaxAppNo)=9 then ('0' || MaxAppNo) else MaxAppNo end) as ApplicationNo from (select  CAST(CAST(right(coalesce(MAX(ApplicationNo)::varchar,0::varchar),10) as Bigint)+1 as varchar) as MaxAppNo FROM dbo.ApplicationDetails where ServiceCode=@ServiceCode) RS";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.Recovery);
            CmdInfo = new CMDInfoList();
            CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = null; CmdInfo.Returns = true;
            cmdList.Add(CmdInfo);

            string AccessCode = Utility.GetRandomString(5, 1);
            string SimplePassword = Utility.GetRandomString(8, 3);
            string HashPassword = Utility.GenerateSHA512(SimplePassword).ToString().ToLower();
            Qry = "insert into web.RegistrationMaster(DocumentNo,DocumentId,ApplicantName,ApplicantGender,ApplicantFatherName,ApplicantMotherName,ApplicantSpouseName,ApplicantDOB,ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,applicantstateid,applicantcountryid,ApplicantDistrictCode,applicantsubdivcode,ApplicantPinCode,ApplicantLocalityId,ApplicantMobileNo,ApplicantPassword,ApplicantAccessCode,RegistrationDate,RegistrationSourceId,ApplicantIpAddress,LastActionPerformed,documentstatusid,ApplicantPermanentAddress,WhetherSameAddress,ActionPerformedBy) values(dbo.udf_general_encrypt(@DocumentNo),@DocumentId,@ApplicantName,@ApplicantGender,@ApplicantFatherName,@ApplicantMotherName,@ApplicantSpouseName,@ApplicantDOB,@ApplicantHouseNumber,@ApplicantStreetNumber,@ApplicantSubLocality,@applicantstateid,@applicantcountryid,@ApplicantDistrictCode,@ApplicantSubDivCode,@ApplicantPinCode,@ApplicantLocalityId,@ApplicantMobileNo,@ApplicantPassword,@ApplicantAccessCode,now(),@RegistrationSourceId,@ApplicantIpAddress,now(),@documentstatusid,@ApplicantPermanentAddress,@WhetherSameAddress,@ActionPerformedBy);SELECT currval(pg_get_serial_sequence('web.registrationmaster','registrationid'))";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DocumentNo", model.ApplicantDetails.ApplicationNo + "|" + CaseNo);
            Cmd.Parameters.AddWithValue("@DocumentId", (int)DocumentId.RecoveryCaseNo);
            Cmd.Parameters.AddWithValue("@ApplicantName", model.ApplicantDetails.ApplicantName.ToUpper());
            Cmd.Parameters.AddWithValue("@ApplicantGender", model.ApplicantDetails.ApplicantGender.ToUpper());
            Cmd.Parameters.AddWithValue("@ApplicantFatherName", model.ApplicantDetails.ApplicantFatherName.ToUpper());
            Cmd.Parameters.AddWithValue("@ApplicantMotherName", model.ApplicantDetails.ApplicantMotherName.ToUpper());
            Cmd.Parameters.AddWithValue("@ApplicantSpouseName", model.ApplicantDetails.ApplicantHusbandName);
            Cmd.Parameters.AddWithValue("@ApplicantDOB", Utility.GetDateYYYYMMDD(model.ApplicantDetails.ApplicantDob, '/', "0/1/2"));
            Cmd.Parameters.AddWithValue("@ApplicantHouseNumber", model.ApplicantDetails.ApplicantHouseNumber);
            Cmd.Parameters.AddWithValue("@ApplicantStreetNumber", model.ApplicantDetails.ApplicantStreetNumber);
            Cmd.Parameters.AddWithValue("@ApplicantSubLocality", model.ApplicantDetails.ApplicantSubLocality);
            Cmd.Parameters.AddWithValue("@applicantstateid", model.ApplicantDetails.StateId);
            Cmd.Parameters.AddWithValue("@applicantcountryid", model.ApplicantDetails.CountryId);
            Cmd.Parameters.AddWithValue("@ApplicantDistrictCode", model.ApplicantDetails.ApplicantDistrictCode);
            Cmd.Parameters.AddWithValue("@ApplicantSubDivCode", model.ApplicantDetails.ApplicantSubDivCode);
            Cmd.Parameters.AddWithValue("@ApplicantPinCode", model.ApplicantDetails.ApplicantPinCode);
            Cmd.Parameters.AddWithValue("@ApplicantLocalityId", model.ApplicantDetails.ApplicantLocalityId);
            Cmd.Parameters.AddWithValue("@ApplicantMobileNo", model.ApplicantDetails.ApplicantMobileNo);
            Cmd.Parameters.AddWithValue("@ApplicantPassword", HashPassword);
            Cmd.Parameters.AddWithValue("@ApplicantAccessCode", AccessCode);
            Cmd.Parameters.AddWithValue("@RegistrationSourceId", (int)ApplicationSource.Window);
            Cmd.Parameters.AddWithValue("@ApplicantIpAddress", Utility.GetIP4Address());
            Cmd.Parameters.AddWithValue("@documentstatusid", (int)WebServiceResponse.WebServiceNotAvailable);
            Cmd.Parameters.AddWithValue("@ApplicantPermanentAddress", model.ApplicantDetails.ApplicantPermanentAddress);
            Cmd.Parameters.AddWithValue("@WhetherSameAddress", model.ApplicantDetails.WhetherSameAddress);
            Cmd.Parameters.AddWithValue("@ActionPerformedBy", Sessions.getEmployeeUser().UserId);
            CmdInfo = new CMDInfoList();
            CmdInfo.Cmd = Cmd; CmdInfo.ParamenterIndex = null; CmdInfo.Returns = true;
            cmdList.Add(CmdInfo);

            Qry = "insert into dbo.registrationtodocumentmaster (RegistrationID,DocumentId,DepartmentId,DocumentNo,DocumentStatusId,WhetherVerified,ConsentId,userid,ipaddress) values (@Parameter0,@DocumentId,@DepartmentId,dbo.udf_general_encrypt(@DocumentNo),@DocumentStatusId,@WhetherVerified,@ConsentId,@userid,@ipaddress)";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@DocumentId", model.ApplicantDetails.ApplicationNo + "|" + CaseNo);
            Cmd.Parameters.AddWithValue("@DocumentNo", (int)DocumentId.RecoveryCaseNo);
            Cmd.Parameters.AddWithValue("@ConsentId", (int)Consent.OtherDocumentCSC);
            Cmd.Parameters.AddWithValue("@DepartmentId", Utility.SelectColumnsValue("documenttodepartmentmaster", "departmentid", "documentid", ((int)DocumentId.RecoveryCaseNo).ToString())[0]);
            Cmd.Parameters.AddWithValue("@DocumentStatusId", (int)WebServiceResponse.WebServiceNotAvailable);
            Cmd.Parameters.AddWithValue("@WhetherVerified", CustomText.FALSE.ToString());
            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
            tempCmdInfo = new CMDInfoList();
            tempCmdInfo.Cmd = Cmd; tempCmdInfo.ParamenterIndex = null; tempCmdInfo.Returns = true;

            Qry = "insert into dbo.ApplicationDetails(RegistrationId,DocumentNo,DocumentId,ServiceCode,ApplicationSourceId,ApplicationRelatedId,ApplicantName,ApplicantGender,ApplicantFatherName,ApplicantMotherName,ApplicantHusbandName,ApplicantMobileNo,applicanthousenumber,applicantstreetnumber,applicantsublocality,stateid,countryid,ApplicantPinCode,ApplicantDob,ApplicantLocalityId,ApplicantSubDivCode,ApplicantDistrictCode,ApplicantNationality,ApplicationStatusId,applicationsubdivcode,applicationdistrictcode,ApplicationNo,ApplicationDate,ApplicantPermanentAddress,WhetherSameAddress,AcceptedBy,OfficeCode,ReferenceDetails,receiveduser,receivedpermission,userid,ipaddress,lastactiondate) values(@Parameter1,dbo.udf_general_encrypt(@DocumentNo),@DocumentId,@ServiceCode,@ApplicationSourceId,@ApplicationRelatedId,@ApplicantName,@ApplicantGender,@ApplicantFatherName,@ApplicantMotherName,@ApplicantHusbandName,@ApplicantMobileNo,@applicanthouseno,@applicantstreetno,@applicantsublocality,@stateid,@countryid,@ApplicantPinCode,@ApplicantDob,@ApplicantLocalityId,@ApplicantSubDivCode,@ApplicantDistrictCode,@ApplicantNationality,@ApplicationStatusId,@applicationsubdivcode,@applicationdistrictcode,@Parameter0,now(),@ApplicantPermanentAddress,@WhetherSameAddress,@AcceptedBy,@OfficeCode,@ReferenceDetails,@receiveduser,@receivedpermission,@userid,@ipaddress,now())";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.Recovery);
            Cmd.Parameters.AddWithValue("@ApplicationSourceId", (int)ApplicationSource.Window);
            Cmd.Parameters.AddWithValue("@DocumentId", (int)DocumentId.RecoveryCaseNo);
            Cmd.Parameters.AddWithValue("@DocumentNo", model.ApplicantDetails.ApplicationNo + "|" + CaseNo);
            Cmd.Parameters.AddWithValue("@ApplicationRelatedId", (int)RelatedTo.Self);
            Cmd.Parameters.AddWithValue("@ApplicantName", model.ApplicantDetails.ApplicantName.ToUpper());
            Cmd.Parameters.AddWithValue("@ApplicantGender", model.ApplicantDetails.ApplicantGender.ToUpper());
            Cmd.Parameters.AddWithValue("@ApplicantFatherName", model.ApplicantDetails.ApplicantFatherName.ToUpper());
            Cmd.Parameters.AddWithValue("@ApplicantMotherName", model.ApplicantDetails.ApplicantMotherName.ToUpper());
            Cmd.Parameters.AddWithValue("@ApplicantHusbandName", model.ApplicantDetails.ApplicantHusbandName);
            Cmd.Parameters.AddWithValue("@ApplicantMobileNo", model.ApplicantDetails.ApplicantMobileNo);
            Cmd.Parameters.AddWithValue("@applicanthouseno", model.ApplicantDetails.ApplicantHouseNumber);//
            Cmd.Parameters.AddWithValue("@applicantstreetno", model.ApplicantDetails.ApplicantStreetNumber);//
            Cmd.Parameters.AddWithValue("@applicantsublocality", model.ApplicantDetails.ApplicantSubLocality);
            Cmd.Parameters.AddWithValue("@stateid", model.ApplicantDetails.StateId);
            Cmd.Parameters.AddWithValue("@countryid", model.ApplicantDetails.CountryId);
            Cmd.Parameters.AddWithValue("@ApplicantPinCode", model.ApplicantDetails.ApplicantPinCode);
            Cmd.Parameters.AddWithValue("@ApplicantDob", Utility.GetDateYYYYMMDD(model.ApplicantDetails.ApplicantDob, '/', "0/1/2"));
            Cmd.Parameters.AddWithValue("@ApplicantLocalityId", model.ApplicantDetails.ApplicantLocalityId);
            Cmd.Parameters.AddWithValue("@ApplicantSubDivCode", model.ApplicantDetails.ApplicantSubDivCode);
            Cmd.Parameters.AddWithValue("@ApplicantDistrictCode", model.ApplicantDetails.ApplicantDistrictCode);
            Cmd.Parameters.AddWithValue("@applicationsubdivcode", revSD[0]);
            Cmd.Parameters.AddWithValue("@applicationdistrictcode", revSD[1]);
            Cmd.Parameters.AddWithValue("@ApplicantNationality", model.ApplicantDetails.ApplicantNationality);
            Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.SCOM033);
            Cmd.Parameters.AddWithValue("@ApplicantPermanentAddress", model.ApplicantDetails.ApplicantPermanentAddress);
            Cmd.Parameters.AddWithValue("@WhetherSameAddress", model.ApplicantDetails.WhetherSameAddress);
            Cmd.Parameters.AddWithValue("@ReferenceDetails", model.ApplicantDetails.ReferenceDetails);
            Cmd.Parameters.AddWithValue("@AcceptedBy", (int)Permission.WIND);
            Cmd.Parameters.AddWithValue("@OfficeCode", Sessions.getEmployeeUser().AuthorizationId);
            Cmd.Parameters.AddWithValue("@receiveduser", Sessions.getEmployeeUser().UserId);
            Cmd.Parameters.AddWithValue("@receivedpermission", Sessions.getEmployeeUser().Permission);
            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
            CmdInfo = new CMDInfoList();
            CmdInfo.Cmd = Cmd; CmdInfo.Returns = false; CmdInfo.ParamenterIndex = new int[] { 0, 1 };
            cmdList.Add(CmdInfo);

            //insert supporing details without enclosure & document serial/reference number
            CmdInfo = new CMDInfoList();
            CmdInfo.Cmd = Utility.InsertEnclosureDetails(((int)ServiceList.Recovery).ToString(), null, (int)RelatedTo.Self, DB.LS.ToString(), "Parameter0");
            CmdInfo.ParamenterIndex = new int[] { 0 }; CmdInfo.Returns = false;
            cmdList.Add(CmdInfo);

            //insert supporing details without enclosure & document serial/reference number for permanent address
            if (Utility.IsAllowPermanentAddress(Sessions.getEmployeeUser().DeptCode) == true)
            {
                if (model.ApplicantDetails.WhetherSameAddress.ToUpper() == CustomText.FALSE.ToString())
                {
                    CmdInfo = new CMDInfoList();
                    CmdInfo.Cmd = Utility.InsertConditionalEnclosureDetails(((int)ServiceList.Recovery).ToString(), model.ApplicantDetails.ApplicationNo, (int)DocumentTypeId.PermanentAddressProof, Convert.ToInt32(model.ApplicantDetails.ApplicationRelatedId), DB.LS.ToString(), "Parameter0");
                    CmdInfo.ParamenterIndex = new int[] { 0 }; CmdInfo.Returns = false;
                    cmdList.Add(CmdInfo);
                }
            }

            //insert in department audit trail
            CmdInfo = new CMDInfoList();
            CmdInfo.Cmd = Utility.InsertDepartmentAuditTrail(null, (int)ApplicationHistoryMessage.MSG007, null, (int)ApplicationSource.Window, "Parameter0");
            CmdInfo.ParamenterIndex = new int[] { 0 }; CmdInfo.Returns = false;
            cmdList.Add(CmdInfo);

            if (tempCmdInfo.Cmd != null)
            {
                cmdList.Add(tempCmdInfo);
            }

            data.SaveTransactionalDataCustom(cmdList);
            return View("message", ViewData["message"] = "Application has been processed successfully. Continue the process at Data Entry Operator login to complete recovery application");
        }

        #region action methods for verification letter and notices
        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult GenerateVerificationLetter(Int64? AppNo)
        {
            if (AppNo == null) { return View(); }
            GetData data = new GetData();
            SdmModels model = new SdmModels();
            model.ApplicationNo = AppNo.ToString();

            string Qry = "select ApplicationStatusId,ServiceCode from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ApplicationSubDivCode in (@ParamSubDivCode) and ServiceCode in(@ParamServiceCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            string[] GetValues = data.SelectColumns(Cmd);
            string StatusCheck = GetValues[0];
            model.ServiceCode = GetValues[1];
            if (model.ServiceCode == ((int)ServiceList.Solemnization).ToString())
            {
                if (StatusCheck == ((int)Status.NOTIACT).ToString())
                {
                    Qry = "select * from dgen.SolemnizationLetterDetails where ApplicationNo=@ApplicationNo and TypeValueId=@TypeValueId";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@TypeValueId", (int)LetterTypeValueId.SolemnizationVerificationLetter);
                    model.data = data.GetDataTable(Cmd);
                    return View(model);
                }
                else
                {
                    ViewBag.DisplayMessage = "This application is not pending for letter generation.";
                }
            }
            else if (model.ServiceCode == ((int)ServiceList.CDVolunteer).ToString())
            {
                if (StatusCheck == ((int)Status.TEHSPEN).ToString())
                {
                    Qry = "select * from dgen.SolemnizationLetterDetails where ApplicationNo=@ApplicationNo and TypeValueId=@TypeValueId";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@TypeValueId", (int)LetterTypeValueId.CDVerificationLetter);
                    model.data = data.GetDataTable(Cmd);
                    return View(model);
                }
                else
                {
                    ViewBag.DisplayMessage = "This application is not pending for letter generation.";
                }
            }
            return View();
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult GenerateVerificationLetter(SdmModels model)
        {
            if (ModelState.IsValid)
            {
                if (string.IsNullOrEmpty(model.IssuingAuthority))
                {
                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationNo });
                    return RedirectToAction("GenerateVerificationLetter", "SDM", new { q = QueryString });
                }
                else
                {
                    GetData data = new GetData();
                    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                    string LetterType = string.Empty;
                    if (model.ServiceCode == ((int)ServiceList.Solemnization).ToString())
                    {
                        LetterType = ((int)LetterTypeValueId.SolemnizationVerificationLetter).ToString();
                    }
                    else if (model.ServiceCode == ((int)ServiceList.CDVolunteer).ToString())
                    {
                        LetterType = ((int)LetterTypeValueId.CDVerificationLetter).ToString();
                    }
                    string Qry = "select LetterDetailsId from dgen.SolemnizationLetterDetails where ApplicationNo=@ApplicationNo and TypeValueId=@TypeValueId and LOWER(IssuingAuthority)=@IssuingAuthority and LOWER(IssuingAuthorityAddress)=@IssuingAuthorityAddress and TelephoneNo=@TelephoneNo";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@TypeValueId", LetterType);
                    Cmd.Parameters.AddWithValue("@IssuingAuthority", model.IssuingAuthority.Trim().ToLower());
                    Cmd.Parameters.AddWithValue("@IssuingAuthorityAddress", model.IssuingAuthorityAddress.Trim().ToLower());
                    Cmd.Parameters.AddWithValue("@TelephoneNo", model.TelephoneNo);
                    string Check = data.SelectColumns(Cmd)[0];
                    if (!string.IsNullOrEmpty(Check))
                    {
                        Qry = "select * from dgen.SolemnizationLetterDetails where ApplicationNo=@ApplicationNo and TypeValueId=@TypeValueId";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@TypeValueId", LetterType);
                        model.data = data.GetDataTable(Cmd);

                        ViewBag.DisplayMessage = "A verification letter with these details has already been generated, to re-print click on the link provided next to the desired letter.";
                        return View(model);
                    }
                    else
                    {
                        List<CMDInfoList> cmdList2 = new List<CMDInfoList>();
                        CMDInfoList CmdInfo = new CMDInfoList();

                        Qry = "insert into dgen.SolemnizationLetterDetails (ApplicationNo,TypevalueId,IssuingAuthority,IssuingAuthorityAddress,TelephoneNo,GenerateDate,GenerateBy,GenerateIpAddress)values(@ApplicationNo,@TypevalueId,@IssuingAuthority,@IssuingAuthorityAddress,@TelephoneNo,now(),@GenerateBy,@GenerateIpAddress); SELECT currval(pg_get_serial_sequence('dgen.solemnizationletterdetails','letterdetailsid'))";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@TypeValueId", LetterType);
                        Cmd.Parameters.AddWithValue("@IssuingAuthority", model.IssuingAuthority.Trim());
                        Cmd.Parameters.AddWithValue("@IssuingAuthorityAddress", model.IssuingAuthorityAddress.Trim());
                        Cmd.Parameters.AddWithValue("@TelephoneNo", model.TelephoneNo);
                        Cmd.Parameters.AddWithValue("@GenerateBy", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@GenerateIpAddress", Utility.GetIP4Address());
                        CmdInfo = new CMDInfoList();
                        CmdInfo.Cmd = Cmd; CmdInfo.Returns = true; CmdInfo.ParamenterIndex = null;
                        cmdList2.Add(CmdInfo);

                        //insert in department audit trail
                        CmdInfo = new CMDInfoList();
                        CmdInfo.Cmd = Utility.InsertDepartmentAuditTrail(model.ApplicationNo.ToString(), (int)ApplicationHistoryMessage.MSG029, null, (int)ApplicationSource.Window, null);
                        CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
                        cmdList2.Add(CmdInfo);

                        string LetterDetailsId = data.SaveTransactionalDataCustom(cmdList2)[1].ToString();

                        if (model.ServiceCode == ((int)ServiceList.Solemnization).ToString())
                        {
                            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "LetterDetailsId" }, new ArrayList() { LetterDetailsId });
                            return RedirectToAction("PrintSolemnizationVerificationLetter", "Print", new { q = QueryString });
                        }
                        else if (model.ServiceCode == ((int)ServiceList.CDVolunteer).ToString())
                        {
                            string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "LetterDetailsId" }, new ArrayList() { LetterDetailsId });
                            return RedirectToAction("PrintCDVerificationLetter", "Print", new { q = QueryString });
                        }
                    }
                }
            }
            return View();
        }
        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult GenerateNotice(Int64? AppNo)
        {
            if (AppNo == null) { return View(); }
            string StatusCheck = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ApplicationStatusId", "ApplicationNo", AppNo.ToString())[0];
            if (StatusCheck == ((int)Status.NOTIACT).ToString())
            {
                SdmModels model = new SdmModels();
                GetData data = new GetData();
                model.ApplicationNo = AppNo.ToString();
                model.ServiceCode = Utility.SelectColumnsValue("dbo.ApplicationDetails", "Servicecode", "ApplicationNo", model.ApplicationNo.ToString())[0];
                string Qry = "select * from dgen.SolemnizationLetterDetails where ApplicationNo=@ApplicationNo and TypeValueId=@TypeValueId";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@TypeValueId", (int)LetterTypeValueId.SolemnizationNotice);
                model.data = data.GetDataTable(Cmd);
                return View(model);
            }
            else
            {
                ViewBag.DisplayMessage = "This application is not pending for letter generation.";
            }
            return View();
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult GenerateNotice(SdmModels model)
        {
            if (ModelState.IsValid)
            {
                if (string.IsNullOrEmpty(model.IssuingAuthority))
                {
                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationNo });
                    return RedirectToAction("GenerateNotice", "SDM", new { q = QueryString });
                }
                else
                {
                    GetData data = new GetData();
                    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                    string Qry = "select LetterDetailsId from dgen.SolemnizationLetterDetails where ApplicationNo=@ApplicationNo and TypeValueId=@TypeValueId and LOWER(IssuingAuthority)=@IssuingAuthority and LOWER(IssuingAuthorityAddress)=@IssuingAuthorityAddress and TelephoneNo=@TelephoneNo";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    Cmd.Parameters.AddWithValue("@TypeValueId", (int)LetterTypeValueId.SolemnizationNotice);
                    Cmd.Parameters.AddWithValue("@IssuingAuthority", model.IssuingAuthority.Trim().ToLower());
                    Cmd.Parameters.AddWithValue("@IssuingAuthorityAddress", model.IssuingAuthorityAddress.Trim().ToLower());
                    Cmd.Parameters.AddWithValue("@TelephoneNo", model.TelephoneNo);
                    string Check = data.SelectColumns(Cmd)[0];
                    if (!string.IsNullOrEmpty(Check))
                    {
                        Qry = "select * from dgen.SolemnizationLetterDetails where ApplicationNo=@ApplicationNo and TypeValueId=@TypeValueId";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@TypeValueId", (int)LetterTypeValueId.SolemnizationNotice);
                        model.data = data.GetDataTable(Cmd);

                        ViewBag.DisplayMessage = "A verification letter with these details has already been generated, to re-print click on the link provided next to the desired letter.";
                        return View(model);
                    }
                    else
                    {
                        List<CMDInfoList> cmdList2 = new List<CMDInfoList>();
                        CMDInfoList CmdInfo = new CMDInfoList();

                        Qry = "insert into dgen.SolemnizationLetterDetails (ApplicationNo,TypevalueId,IssuingAuthority,IssuingAuthorityAddress,TelephoneNo,GenerateDate,GenerateBy,GenerateIpAddress)values(@ApplicationNo,@TypevalueId,@IssuingAuthority,@IssuingAuthorityAddress,@TelephoneNo,now(),@GenerateBy,@GenerateIpAddress); SELECT currval(pg_get_serial_sequence('dgen.solemnizationletterdetails','letterdetailsid'))";
                        Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                        Cmd.Parameters.AddWithValue("@TypeValueId", (int)LetterTypeValueId.SolemnizationNotice);
                        Cmd.Parameters.AddWithValue("@IssuingAuthority", model.IssuingAuthority.Trim());
                        Cmd.Parameters.AddWithValue("@IssuingAuthorityAddress", model.IssuingAuthorityAddress.Trim());
                        Cmd.Parameters.AddWithValue("@TelephoneNo", model.TelephoneNo);
                        Cmd.Parameters.AddWithValue("@GenerateBy", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@GenerateIpAddress", Utility.GetIP4Address());
                        CmdInfo = new CMDInfoList();
                        CmdInfo.Cmd = Cmd; CmdInfo.Returns = true; CmdInfo.ParamenterIndex = null;
                        cmdList2.Add(CmdInfo);

                        //insert in department audit trail
                        CmdInfo = new CMDInfoList();
                        CmdInfo.Cmd = Utility.InsertDepartmentAuditTrail(model.ApplicationNo.ToString(), (int)ApplicationHistoryMessage.MSG029, null, (int)ApplicationSource.Window, null);
                        CmdInfo.Returns = false; CmdInfo.ParamenterIndex = null;
                        cmdList2.Add(CmdInfo);

                        string LetterDetailsId = data.SaveTransactionalDataCustom(cmdList2)[1].ToString();

                        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "LetterDetailsId" }, new ArrayList() { LetterDetailsId });
                        return RedirectToAction("PrintSolemnizationNotice", "Print", new { q = QueryString });
                    }
                }
            }
            return View();
        }

        #endregion

        #region Send Application for Editing
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult SearchAppToSendForEditing()
        {
            SdmModels model = new SdmModels();

            if (TempData[Constant._ActionMessage] != null) { ViewBag.DisplayMessage = (string)TempData[Constant._ActionMessage]; }
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult SearchAppToSendForEditing(SdmModels model)
        {
            GetData data = new GetData();

            Dictionary<string, string> ValidateData = new Dictionary<string, string>();
            ValidateData.Add("ApplicationNo", model.ApplicationNo);

            string DisplayMessage = Utility.WhetherAccessAllowed(ValidateData, new int[] { (int)ValueId.AuthDigital, (int)ValueId.AutheKYC }, new int[] { (int)ValueId.SignDigital, (int)ValueId.SignEsign }, new int[] { (int)Status.TEHSPEN }, false, true, true);
            if (!string.IsNullOrEmpty(DisplayMessage))
            {
                ViewBag.DisplayMessage = DisplayMessage;
                return View(model);
            }

            string Qry = "select ApplicationNo,ApplicationSourceId,servicecode from dbo.ApplicationDetails where ApplicationNo=@ApplicationNo and ApplicationStatusId in (@PenTeh) and applicationsubdivcode in (@ParamSubDivCode) and ServiceCode in (@ParamServiceCode)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
            Cmd.Parameters.AddWithValue("@PenTeh", (int)Status.TEHSPEN);
            string[] GetValues = data.SelectColumns(Cmd);
            string AppNo = GetValues[0];
            string AppSourceId = GetValues[1];
            string ServiceCode = GetValues[2];

            if (!string.IsNullOrEmpty(AppNo))
            {
                if (ServiceCode != ((int)ServiceList.Marriage).ToString() && ServiceCode != ((int)ServiceList.Solemnization).ToString())
                {
                    if (AppSourceId == Convert.ToString((int)ApplicationSource.Online))
                    {
                        ViewBag.DisplayMessage = "Entered application is applied through citizen account, hence can not be edited.";
                        return View(model);
                    }
                }
                string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.ApplicationNo });
                return RedirectToAction("DpApplicationPreviewBeforeSubmit", "Receiving", new { q = QueryString });
            }
            else { ViewBag.DisplayMessage = "Entered ApplicationNo is not pending at this level."; }
            return View(model);
        }
        [EncryptedActionParameter]
        public ActionResult SendAppForEditing(Int64 AppNo)
        {
            SdmModels model = new SdmModels();
            GetData data = new GetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

            string Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where ApplicationNo=@ApplicationNo";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
            Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.CSCEDT);
            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
            cmdList.Add(Cmd);

            Qry = "update web.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where ApplicationNo=@ApplicationNo";
            Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
            Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.CSCEDT);
            Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
            Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
            cmdList.Add(Cmd);

            cmdList.Add(Utility.InsertDepartmentAuditTrail(AppNo.ToString(), (int)ApplicationHistoryMessage.MSG019, null, (int)ApplicationSource.Window, null));
            data.SaveData(cmdList);

            PreserveModelState(Constant._ActionMessage, "Selected application has been processed successfully.", false, true);
            return RedirectToAction("SearchAppToSendForEditing");
        }
        #endregion

        //#region Certificate Rectification/Cancellation process
        //[AcceptVerbs(HttpVerbs.Get)]
        //[EncryptedActionParameter]
        //public ActionResult SearchCertificateForRectification(int Type)
        //{
        //    SdmModels model = new SdmModels();
        //    model.Type = Type.ToString();
        //    return View(model);
        //}
        //[AcceptVerbs(HttpVerbs.Post)]
        //[ValidateAntiForgeryToken]
        //[ValidateOnlyIncomingValues]
        //public ActionResult SearchCertificateForRectification(SdmModels model)
        //{
        //    if (Sessions.getEmployeeUser().Permission != ((int)Permission.SDMG).ToString() && Sessions.getEmployeeUser().Permission != ((int)Permission.P123).ToString()) { return RedirectToAction("UnauthorizedRequest"); }
            
        //    GetData data = new GetData();
        //    string whethercondition = string.Empty;

        //    Dictionary<string, string> ValidateData = new Dictionary<string, string>();
        //    ValidateData.Add("ApplicationNo", model.ApplicationNo);

        //    string DisplayMessage = Utility.WhetherAccessAllowed(ValidateData, new int[] { (int)ValueId.AuthDigital, (int)ValueId.AutheKYC }, new int[] { (int)ValueId.SignDigital, (int)ValueId.SignEsign }, new int[] { (int)Status.ISSUCER }, false, false, true);
        //    if (!string.IsNullOrEmpty(DisplayMessage))
        //    {
        //        ViewBag.DisplayMessage = DisplayMessage;
        //        return View(model);
        //    }

        //    if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000) { whethercondition = whethercondition + " and OfficeCode in (@ParamAuthorizationId) "; }
        //    else { whethercondition = whethercondition + " and applicationsubdivcode in (@ParamSubDivCode) and OfficeCode=@OfficeCode "; }
        //    string Qry = "select ApplicationStatusId from dbo.ApplicationDetails where ServiceCode in (@ParamServiceCode) and ApplicationNo=@ApplicationNo " + whethercondition;
        //    NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
        //    cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
        //    cmd.Parameters.AddWithValue("@OfficeCode", (int)CountList.Type000);
        //    string status = data.SelectColumns(cmd)[0];
        //    if (string.IsNullOrEmpty(status))
        //    {
        //        ViewBag.DisplayMessage = "Application not pending at this level.";
        //        return View(model);
        //    }

        //    if (Convert.ToInt16(status) == (int)Status.ISSUCER)
        //    {
        //        string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "app", "Const" }, new ArrayList() { model.ApplicationNo, model.Type });
        //        return RedirectToAction("BasicApplicationPreview", "Report", new { q = QueryString });
        //    }
        //    else
        //    {
        //        ViewBag.DisplayMessage = "Application not pending at this level.";
        //        return View(model);
        //    }
        //}
        //[AcceptVerbs(HttpVerbs.Get)]
        //[EncryptedActionParameter]
        //public ActionResult SendCertificateForRectification(Int64 AppNo)
        //{
        //    SdmModels model = new SdmModels();
        //    GetData data = new GetData();
        //    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
        //    model.ApplicationNo = AppNo.ToString();
        //    model.ServiceCode = Utility.SelectColumnsValue("applicationdetails", "servicecode", "applicationno", model.ApplicationNo)[0];

        //    if (!Utility.CheckCurrentStatusBeforeUpdate(model.ApplicationNo, (int)Status.CSCEDT, (int)CountList.Type001))
        //    {
        //        ViewData["message"] = "Application is not pending at this level anymore!";
        //        return View("message");
        //    }

        //    string Qry = "update dbo.ApplicationDetails set ApplicationStatusId=@ApplicationStatusId,AcceptedBy=@AcceptedBy,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where  ApplicationNo=@ApplicationNo";
        //    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
        //    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
        //    Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.CSCEDT);
        //    Cmd.Parameters.AddWithValue("@AcceptedBy", Utility.GetTargetPermission(model.ApplicationNo, (int)Status.CSCEDT, (int)CountList.Type001, DB.LS.ToString()));
        //    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
        //    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
        //    cmdList.Add(Cmd);

        //    Qry = "insert into dsgn.DigitalDataDetailsCancelled(RowId,ApplicationNo,UnsignedData,WhetherDataSigned,SignedData,DataSignedDate,DataSignedBy,IpAddress,cancelledby,cancelleddate,cancelledipaddress) select RowId,ApplicationNo,UnsignedData,WhetherDataSigned,SignedData,DataSignedDate,DataSignedBy,IpAddress,@cancelledby,now(),@cancelledipaddress from dsgn.DigitalDataDetails where ApplicationNo=@ApplicationNo";
        //    Cmd = new NpgsqlCommand(Qry);
        //    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
        //    Cmd.Parameters.AddWithValue("@cancelledby", Sessions.getEmployeeUser().UserId);
        //    Cmd.Parameters.AddWithValue("@cancelledipaddress", Utility.GetIP4Address());
        //    cmdList.Add(Cmd);

        //    Qry = "insert into dsgn.DigitalDocumentDetailsCancelled(RowId,ApplicationNo,ReferenceNo,SignedDocument,SignedDate,SignedBy,IpAddress,cancelledby,cancelleddate,cancelledipaddress) select RowId,ApplicationNo,ReferenceNo,SignedDocument,SignedDate,SignedBy,IpAddress,@cancelledby,now(),@cancelledipaddress from dsgn.DigitalDocumentDetails where ApplicationNo=@ApplicationNo";
        //    Cmd = new NpgsqlCommand(Qry);
        //    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
        //    Cmd.Parameters.AddWithValue("@cancelledby", Sessions.getEmployeeUser().UserId);
        //    Cmd.Parameters.AddWithValue("@cancelledipaddress", Utility.GetIP4Address());
        //    cmdList.Add(Cmd);

        //    if (model.ServiceCode == ((int)ServiceList.Marriage).ToString() || model.ServiceCode == ((int)ServiceList.Solemnization).ToString())
        //    {
        //        //insert record in MarriagePhysicallySigningDetailsHistory tables
        //        Qry = "insert into dgen.MarriagePhysicallySigningDetailsHistory(DetailsId,ApplicationNo,Certificatedata,Certificatecontenttype,UserId,Ipaddress,Actiondatetime) select DetailsId,ApplicationNo,Certificatedata,Certificatecontenttype,@UserId,@Ipaddress,now() from dgen.MarriagePhysicallySigningDetails where ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
        //        Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
        //        Cmd.Parameters.AddWithValue("@Ipaddress", Utility.GetIP4Address());
        //        cmdList.Add(Cmd);

        //        //delete recrords from MarriagePhysicallySigningDetails
        //        Qry = "delete from dgen.MarriagePhysicallySigningDetails where ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
        //        cmdList.Add(Cmd);
        //    }

        //    Qry = "delete from dsgn.DigitalDataDetails where ApplicationNo=@ApplicationNo";
        //    Cmd = new NpgsqlCommand(Qry);
        //    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
        //    cmdList.Add(Cmd);

        //    Qry = "delete from dsgn.DigitalDocumentDetails where ApplicationNo=@ApplicationNo";
        //    Cmd = new NpgsqlCommand(Qry);
        //    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
        //    cmdList.Add(Cmd);


        //    //insert in application audit trail
        //    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicationNo, (int)ApplicationHistoryMessage.MSG020, null, (int)ApplicationSource.Window, null));

        //    data.SaveData(cmdList);
        //    ViewBag.DisplayMessage = "Certificate send for Rectification Successfully.";
        //    return View("SearchCertificateForRectification");
        //}
        //[AcceptVerbs(HttpVerbs.Post)]
        //[EncryptedActionParameter]
        //public ActionResult CancelCertificate(SdmModels model)
        //{
        //    GetData data = new GetData();
        //    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

        //    int SigningTypeId = Convert.ToInt32(Utility.SelectColumnsValue("dbo.usermaster", "signingtypeid", "UserId", Sessions.getEmployeeUser().UserId)[0]);
        //    if (SigningTypeId != (int)ValueId.SignDigital)
        //    {
        //        ViewBag.DisplayMessage = "Kindly Login with Digital Sign to Cancel the Certificate";
        //        return View("SearchCertificateForRectification");
        //    }

        //    string Qry = "update dbo.ApplicationDetails set Applicationremarks=@Applicationremarks,ApplicationStatusId=@ApplicationStatusId,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where  ApplicationNo=@ApplicationNo";
        //    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
        //    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
        //    Cmd.Parameters.AddWithValue("@Applicationremarks", model.ApplicationDetails.ApplicationRemarks);
        //    Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.CANCEL);
        //    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
        //    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
        //    cmdList.Add(Cmd);

        //    Qry = "update web.ApplicationDetails set Applicationremarks=@Applicationremarks,ApplicationStatusId=@ApplicationStatusId,userid=@userid,ipaddress=@ipaddress,actiondatetime=now() where  ApplicationNo=@ApplicationNo";
        //    Cmd = new NpgsqlCommand(Qry);
        //    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
        //    Cmd.Parameters.AddWithValue("@Applicationremarks", model.ApplicationDetails.ApplicationRemarks);
        //    Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.CANCEL);
        //    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
        //    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
        //    cmdList.Add(Cmd);

        //    Qry = "insert into dsgn.DigitalDataDetailsCancelled(RowId,ApplicationNo,UnsignedData,WhetherDataSigned,SignedData,DataSignedDate,DataSignedBy,IpAddress,cancelledby,cancelleddate,cancelledipaddress) select RowId,ApplicationNo,UnsignedData,WhetherDataSigned,SignedData,DataSignedDate,DataSignedBy,IpAddress,@cancelledby,now(),@cancelledipaddress from dsgn.DigitalDataDetails where ApplicationNo=@ApplicationNo";
        //    Cmd = new NpgsqlCommand(Qry);
        //    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
        //    Cmd.Parameters.AddWithValue("@cancelledby", Sessions.getEmployeeUser().UserId);
        //    Cmd.Parameters.AddWithValue("@cancelledipaddress", Utility.GetIP4Address());
        //    cmdList.Add(Cmd);

        //    Qry = "insert into dsgn.DigitalDocumentDetailsCancelled(RowId,ApplicationNo,ReferenceNo,SignedDocument,SignedDate,SignedBy,IpAddress,cancelledby,cancelleddate,cancelledipaddress) select RowId,ApplicationNo,ReferenceNo,SignedDocument,SignedDate,SignedBy,IpAddress,@cancelledby,now(),@cancelledipaddress from dsgn.DigitalDocumentDetails where ApplicationNo=@ApplicationNo";
        //    Cmd = new NpgsqlCommand(Qry);
        //    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
        //    Cmd.Parameters.AddWithValue("@cancelledby", Sessions.getEmployeeUser().UserId);
        //    Cmd.Parameters.AddWithValue("@cancelledipaddress", Utility.GetIP4Address());
        //    cmdList.Add(Cmd);

        //    Qry = "delete from dsgn.DigitalDataDetails where ApplicationNo=@ApplicationNo";
        //    Cmd = new NpgsqlCommand(Qry);
        //    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
        //    cmdList.Add(Cmd);

        //    Qry = "delete from dsgn.DigitalDocumentDetails where ApplicationNo=@ApplicationNo";
        //    Cmd = new NpgsqlCommand(Qry);
        //    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicantDetails.ApplicationNo);
        //    cmdList.Add(Cmd);

        //    //insert in application audit trail
        //    cmdList.Add(Utility.InsertDepartmentAuditTrail(model.ApplicantDetails.ApplicationNo, (int)ApplicationHistoryMessage.MSG023, model.ApplicationDetails.ApplicationRemarks, (int)ApplicationSource.Window, null));

        //    //send sms to applicant and insert record in table
        //    Dictionary<string, string> smsDic = new Dictionary<string, string>();
        //    smsDic.Add("ParamApplicationNo", model.ApplicantDetails.ApplicationNo);
        //    cmdList.Add(Utility.ApplicationProcessSms((int)SmsSendType.SMS006, smsDic));

        //    data.SaveData(cmdList);
        //    ViewBag.DisplayMessage = "Certificate Cancel Successfully.";
        //    return View("SearchCertificateForRectification");
        //}
        //#endregion

        #region Lobaour Department Process
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult PendingFirmGrievances()
        {
            SdmModels model = new SdmModels();
            GetData data = new GetData();
            string Qry = "select SC.ServiceName,SC.ServiceCode,AD.subdivcode,coalesce(sum(case when StatusId=@Pending then 1 end),0) as Pending  from dgen.LBRGrievanceDetails AD left outer join dbo.DistrictMaster DM on AD.districtcode=DM.DistrictCode right outer join dbo.SubDivMaster SM on AD.subdivcode=SM.SubDivCode right outer join dbo.ServiceMaster SC on AD.ServiceCode=SC.ServiceCode where DM.deptcode=@ParamDeptCode and AD.subdivcode in (@ParamSubDivCode) and AD.ServiceCode in (@ParamServiceCode) group by AD.subdivcode,SC.ServiceName,SC.ServiceCode order by SC.ServiceName";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@Pending", (int)LBRStatus.InProcess);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult PendingFirmGrievancesList(int ServiceCode, int StatusId)
        {
            SdmModels model = new SdmModels();
            GetData data = new GetData();
            string Qry = "select AD.ServiceCode,AD.GrievanceId,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantMobileNo,ServiceName,(houseno||' '||LM.LocalityName||' '||SD.subdivdescription||' '||DM.districtname) as ApplicantAddress,AD.ApplicantDob,AD.StatusId from dgen.LBRGrievanceDetails AD inner join dbo.servicemaster SCM on AD.ServiceCode=SCM.ServiceCode inner join localitymaster LM on LM.localityId=AD.localityid inner join districtmaster DM on DM.districtcode=AD.districtcode inner join subdivmaster SD on SD.subdivcode=AD.subdivcode where AD.ServiceCode=@ServiceCode and AD.subdivcode in (@ParamSubDivCode) and AD.StatusId=@StatusId order by AD.actiondatetime";
            NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
            cmd.Parameters.AddWithValue("@StatusId", StatusId);
            model.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Get)]
        [EncryptedActionParameter]
        public ActionResult PendingGrievanceInspectionDetails(int GId, int StatusId)
        {
            SdmModels model = new SdmModels();
            GetData data = new GetData();
            model.LBRGrievanceDetails = new LBRGrievanceDetails();
            model.LBRGrievanceDetails = Utility.GetGrievanceDetails(GId);
            model.LBRGrievanceDetails.InspectionId = Utility.SelectColumnsValue("dgen.lbrinspectionmaster", "InspectionId", "GrievanceId", GId.ToString())[0];
            string Qry = "select ControlTypeId,WhetherCountRequired,WhetherPrimaryCount,ColumnName,ID.ColumnValue,SC.ServiceName from dgen.LBRinspectioncolumnmaster IC left outer join dgen.LBRInspectionDetails ID on ID.columnid=IC.columnid  and ID.InspectionId=@InspectionId inner join ServiceMaster SC on SC.ServiceCode=IC.ServiceCode where IC.ServiceCode=@ServiceCode order by ColumnOrder";
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@ServiceCode", model.LBRGrievanceDetails.ServiceCode);
            cmd.Parameters.AddWithValue("@InspectionId", model.LBRGrievanceDetails.InspectionId);
            model.LBRGrievanceDetails.data = data.GetDataTable(cmd);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult PendingGrievanceInspectionDetails(SdmModels model)
        {
            GetData data = new GetData();
            string Qry = string.Empty; NpgsqlCommand cmd = null;
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

            Qry = "update dgen.lbrinspectionmaster set observationremarks=@observationremarks,observationby=@observationby,observationdate=now() where InspectionId=@InspectionId";
            cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@InspectionId", model.LBRGrievanceDetails.InspectionId);
            cmd.Parameters.AddWithValue("@observationremarks", model.LBRGrievanceDetails.Observation);
            cmd.Parameters.AddWithValue("@observationby", Sessions.getEmployeeUser().UserId);
            cmdList.Add(cmd);

            Qry = "update dgen.LBRGrievanceDetails set StatusId=@StatusId where GrievanceId=@GrievanceId";
            cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@GrievanceId", model.LBRGrievanceDetails.GrievanceId);
            cmd.Parameters.AddWithValue("@StatusId", model.LBRGrievanceDetails.StatusId);
            cmdList.Add(cmd);

            data.SaveData(cmdList);

            return RedirectToAction("PendingFirmGrievances", "Sdm");
        }
        #endregion

        #region update old EPP status and category
        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult UpdateOldEPPStatus(Int64? AppNo)
        {
            SdmModels model = new SdmModels();
            model.ApplicationDetails = new ApplicationDetails();
            if (AppNo == null) { return View(model); }
            GetData data = new GetData();
            model.EppApplicationNo = AppNo.ToString();

            string Qry = "select IdNo,ApplicantName,FName,to_char(Dateofapplication,'DD/MM/YYYY') as Dateofapplication,Status,to_char(StatusDate,'DD/MM/YYYY') as StatusDate,Address,ChildName,Attestingofficer,Dobd,Caste,to_char(Dop,'DD/MM/YYYY') as Dop,Remarks,Stcen,Distcode,Subdivcode,Servicecode,DistName,SubdivName,ServiceName,Nsdivcode,Orgstatus,DeptName,Rejectionreason from applicationdetailsepp where idno=@ApplicationNo and servicecode in (@ParamServiceCode) and subdivcode in (select eppsubdivcode from applicationeppsubdivmapping where edistsubdivcode=@ParamSubDivCode and whetheractive=@whetheractive)";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.EppApplicationNo);
            Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
            model.data = data.GetDataTable(Cmd);

            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult UpdateOldEPPStatus(SdmModels model)
        {
            if (ModelState.IsValid)
            {
                bool WhetherEntry = false;

                if (string.IsNullOrEmpty(model.StatusId))
                {
                    PreserveModelState(Constant._ModelStateParent, model, false, true);
                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.EppApplicationNo });
                    return RedirectToAction("UpdateOldEPPStatus", "SDM", new { q = QueryString });
                }
                else
                {
                    GetData data = new GetData();
                    int SigningTypeId = Convert.ToInt32(Utility.SelectColumnsValue("dbo.usermaster", "signingtypeid", "UserId", Sessions.getEmployeeUser().UserId)[0]);
                    if (SigningTypeId != (int)ValueId.SignDigital)
                    {
                        ViewBag.DisplayMessage = "You need to be digitally signed in to take action on this application.";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View("UpdateOldEPPStatus", (DecisionModels)TempData[Constant._ModelStateParent]);
                    }

                    string OldStatus = Utility.SelectColumnsValue("applicationdetailsepp", "Status", "idno", model.EppApplicationNo)[0];
                    if (model.StatusId == OldEppStatus.IssuedbyCourier.ToString())
                    {
                        // rejected allowed as per direction on Jain Sir on 23/07/2018
                        if (OldStatus == OldEppStatus.SignedBySDM.ToString() || OldStatus == OldEppStatus.SignedByTehsildar.ToString() || OldStatus == OldEppStatus.Rejected.ToString())
                        {
                            WhetherEntry = true;
                        }
                        else
                        {
                            ViewBag.DisplayMessage = "You have selected wrong status.";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("UpdateOldEPPStatus", (SdmModels)TempData[Constant._ModelStateParent]);
                        }
                    }
                    else if (model.StatusId == OldEppStatus.Cancelled.ToString())
                    {
                        if (OldStatus == OldEppStatus.Issued.ToString() || OldStatus == OldEppStatus.IssuedByHand.ToString() || OldStatus == OldEppStatus.IssuedToJeevanCenter.ToString() || OldStatus == OldEppStatus.IssuedBySpeedPost.ToString())
                        {

                            WhetherEntry = true;
                        }
                        else
                        {
                            ViewBag.DisplayMessage = "You have selected wrong status.";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("UpdateOldEPPStatus", (SdmModels)TempData[Constant._ModelStateParent]);
                        }
                    }
                    else if (model.StatusId == OldEppStatus.Rejected.ToString())
                    {
                        if (OldStatus != OldEppStatus.Cancelled.ToString() && OldStatus != OldEppStatus.Issued.ToString())
                        {

                            WhetherEntry = true;
                        }
                        else
                        {
                            ViewBag.DisplayMessage = "You have selected wrong status.";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("UpdateOldEPPStatus", (SdmModels)TempData[Constant._ModelStateParent]);
                        }
                    }
                    else if (model.StatusId == OldEppStatus.SignedByTehsildar.ToString())
                    {
                        if (OldStatus == OldEppStatus.Approved.ToString())
                        {

                            WhetherEntry = true;
                        }
                        else
                        {
                            ViewBag.DisplayMessage = "You have selected wrong status.";
                            PreserveModelState(Constant._ModelStateParent, null, true, false);
                            return View("UpdateOldEPPStatus", (SdmModels)TempData[Constant._ModelStateParent]);
                        }
                    }
                    else
                    {
                        return RedirectToAction("UnauthorizedRequest", "Error");
                    }

                    if (WhetherEntry == true)
                    {
                        string Qry = "Update Applicationdetailsepp set status=@status, orgstatus=@status,remarks=@remarks,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where idno=@ApplicationNo";
                        NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                        Cmd.Parameters.AddWithValue("@status", model.StatusId);
                        Cmd.Parameters.AddWithValue("@ApplicationNo", model.EppApplicationNo);
                        Cmd.Parameters.AddWithValue("@remarks", model.ApplicationRemarks);
                        Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                        Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                        data.UpdateData(Cmd);
                        ViewData["message"] = "Status Updated";
                        return View("message");
                    }
                    else
                    {
                        ViewData["message"] = "No Status Updated";
                        return View("message");
                    }
                }
            }
            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("UpdateOldEPPStatus", (SdmModels)TempData["Constant._ModelStateParent"]);
        }
        [EncryptedActionParameter]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult UpdateOldEPPCategory(Int64? AppNo)
        {
            SdmModels model = new SdmModels();
            model.ApplicationDetails = new ApplicationDetails();
            if (AppNo == null) { return View(model); }


            GetData data = new GetData();
            model.EppApplicationNo = AppNo.ToString();

            string Qry = "select IdNo,ApplicantName,FName,to_char(Dateofapplication,'DD/MM/YYYY') as Dateofapplication,Status,to_char(StatusDate,'DD/MM/YYYY') as StatusDate,Address,ChildName,Attestingofficer,Dobd,Caste,to_char(Dop,'DD/MM/YYYY') as Dop,Remarks,Stcen,Distcode,Subdivcode,Servicecode,DistName,SubdivName,ServiceName,Nsdivcode,Orgstatus,DeptName,Rejectionreason from applicationdetailsepp where idno=@ApplicationNo and servicecode in (@ParamServiceCode) and subdivcode in (select eppsubdivcode from applicationeppsubdivmapping where edistsubdivcode=@ParamSubDivCode and whetheractive=@whetheractive) and Category=@Category and OS=@OS ";
            NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
            Cmd.Parameters.AddWithValue("@ApplicationNo", model.EppApplicationNo);
            Cmd.Parameters.AddWithValue("@Category", CustomText.SC.ToString());
            Cmd.Parameters.AddWithValue("@OS", CustomText.Y.ToString());
            Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
            model.data = data.GetDataTable(Cmd);

            if (model.data.Rows.Count > 0) { model.ServiceCode = model.data.Rows[0]["Servicecode"].ToString(); }
            else
            {
                ViewData["message"] = "No Application found, Please check Application No. or the Sub-Division of the application or Category of Application.";
                return View("message");
            }

            if (model.ServiceCode != ((int)ServiceList.SCST).ToString())
            {
                ViewData["message"] = "No Application found, Please check Application No. or the Sub-Division of the application or Category of Application.";
                return View("message");
            }

            PreserveModelState(Constant._ModelStateParent, model, false, true);
            return View(model);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateOnlyIncomingValues]
        public ActionResult UpdateOldEPPCategory(SdmModels model)
        {
            if (ModelState.IsValid)
            {
                if (string.IsNullOrEmpty(model.Category))
                {
                    PreserveModelState(Constant._ModelStateParent, model, false, true);
                    string QueryString = Utility.CreateEncryptedQueyString(new ArrayList() { "AppNo" }, new ArrayList() { model.EppApplicationNo });
                    return RedirectToAction("UpdateOldEPPCategory", "SDM", new { q = QueryString });
                }
                else
                {

                    GetData data = new GetData();
                    int SigningTypeId = Convert.ToInt32(Utility.SelectColumnsValue("dbo.usermaster", "signingtypeid", "UserId", Sessions.getEmployeeUser().UserId)[0]);
                    if (SigningTypeId != (int)ValueId.SignDigital)
                    {
                        ViewBag.DisplayMessage = "You need to be digitally signed in to take action on this application.";
                        PreserveModelState(Constant._ModelStateParent, null, true, false);
                        return View("UpdateOldEPPCategory", (DecisionModels)TempData[Constant._ModelStateParent]);
                    }
                    string ServiceCode = ((int)ServiceList.ST).ToString();
                    string ServiceName = Utility.SelectColumnsValue("ServiceMaster", "ServiceName", "ServiceCode", ServiceCode)[0];

                    string Qry = "Update Applicationdetailsepp set Category=@Category,ServiceCode=@ServiceCode,ServiceName=@ServiceName,remarks=@remarks,userid=@userid,ipaddress=@ipaddress,lastactiondate=now() where idno=@ApplicationNo ";
                    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.EppApplicationNo);
                    Cmd.Parameters.AddWithValue("@remarks", model.ApplicationRemarks);
                    Cmd.Parameters.AddWithValue("@Category", model.Category);
                    Cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
                    Cmd.Parameters.AddWithValue("@ServiceName", ServiceName);
                    Cmd.Parameters.AddWithValue("@userid", Sessions.getEmployeeUser().UserId);
                    Cmd.Parameters.AddWithValue("@ipaddress", Utility.GetIP4Address());
                    data.UpdateData(Cmd);

                    ViewData["message"] = "Category Updated";
                    return View("message");
                }
            }

            PreserveModelState(Constant._ModelStateParent, null, true, false);
            return View("UpdateOldEPPCategory", (SdmModels)TempData["Constant._ModelStateParent"]);
        }
        #endregion

        #region global method current contoller
        //method for preserve nodel state
        public void PreserveModelState(string Key, object obj, bool IsKeep, bool IsRemove)
        {
            if (IsRemove == true) { TempData.Remove(Key); }
            if (obj != null) { TempData[Key] = obj; }
            if (IsKeep == true) { TempData.Keep(Key); }
        }
        #endregion global method current contoller
    }
}

