﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net.Http;
using System.Net;
using System.Web.UI;

namespace Edistrict.Controllers
{
    [OutputCache(Duration = 0, Location = OutputCacheLocation.None, VaryByParam = "None", NoStore = true)]
    public class AppapiController : Controller
    {

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Health()
        {
            return new HttpStatusCodeResult(200);
        }

    }
}
