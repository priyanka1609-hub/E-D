﻿using System;
using System.Web;
using Edistrict.Models.Entities;

namespace Edistrict.Models.ApplicationService
{
    #region public class for static value filed
    public class Constant
    {
        public static int _saltLength = 5;
        public static int _ViewDocCount = 5;
        public static int _globalPageRowCount = 50;
        public static string _pageData = "ATADDEGAPEBOT";
        public static string _saltValue = "OTUOOEOCYGQVRMQKQUKCYEGWODSRSNWRHESIPBKJJICPLQIHEH";
        public static string _ParamDeptCode = "@ParamDeptCode";
        public static string _ParamDistrictCode = "@ParamDistrictCode";
        public static string _ParamSubDivCode = "@ParamSubDivCode";
        public static string _ParamServiceCode = "@ParamServiceCode";
        public static string _ParamAuthorizationId = "@ParamAuthorizationId";
        public static string _ParamPermission = "@ParamPermission";
        public static string _DataObject = "DataOrDataTypeObject";
        public static string _ModelStateParent = "ModelStateParent";
        public static string _ModelStateChild = "ModelStateChild";
        public static string _ActionMessage = "ActionMessage";
        public static string _LastActionId = "LastActionId";
        public static string _SecondLastActionId = "SecondLastActionId";
        public static string _FinalSubmitActionId = "FinalSubmitActionId";
        public static string _UniqueId = "UniqueId";
        public static string _ProvisionalId = "ProvisionalId";
        public static string _IdNo = "IdNo324324";
        public static string _OBCDate = "2015/12/02 19:00:00";
        public static string _IndianTimeZone = "asia/calcutta";
        public static string _RationCardNo = "RationCardNo";
        public static string _HgCcMobile = "8826126853";
        public static string _eTaalTrackCode = "E003106709861";
        public static string _eTaalTokenCode = "HGJHGjhgjkfUYT87679659659yoi796tgygjkhHK";
        public static string _SmsUserName = "edistapp.sms";
        public static string _SmsUserPin = "Fg%243tR7%23kA";
        public static string _SmsSignature = "NICSMS";
        public static string _SmsGatewayNo = "917738299899";
        public static string _eDistrictHost = "edistrict.delhigovt.nic.in";
        public static string _eDistrictHostDomain = "http://edistrict.delhigovt.nic.in";
        //public static string _RasHost = "ras.gov.in";
        //public static string _CitizenDateForAppView = "2015/12/09 00:00:00";
        public static string _NicNetHost = "10.249.33.197";
        public static string _RandomUserId = "Edist@Mmp@Egov";
        public static string _RandomPassword = "N938>00q0f7e64E";
        public static string _NfsUserId = "edistrict";
        public static string _NfsPassword = "Edistrict#123";
        public static string _BsesMerchantId = "edistrict";
        public static string _BsesSecretKey = "SGUOP";
        public static string _PublicKey = "S4eae6qLP1q62RlG9QrFPtd0VjD1FLQV";

        //public static string _NicNetDomain = "http://10.249.33.197";
        public static string _NicNetDomain = "http://localhost:44775";
    }
    public class ForeignServer
    {
        //public static string _ForeignServer01 = "host=10.249.103.25 user=postgres password=postgres dbname=esigndocument"; //Production Digitally Signed Data of Certificates
        //public static string _ForeignServer02 = "host=10.249.103.26 user=postgres password=postgres dbname=ecitizendocument"; //Production Citizen Supporting Documents
        //public static string _ForeignServer03 = "host=10.249.103.27 user=postgres password=postgres dbname=edistenclosureminor"; //Production Minor/Small Enclosure
        //public static string _ForeignServer04 = "host=10.249.103.27 user=postgres password=postgres dbname=edistphotograph"; //Production Photograph Details
        //public static string _ForeignServer05 = "host=10.247.33.11 user=postgres password=postgres dbname=edistsignedmajor"; //Production Digitally Signed Data of Major/Large Documents
        //public static string _ForeignServer06 = "host=10.247.33.11 user=postgres password=postgres dbname=edistenclosuremajor"; //Production Major/Large Enclosure

        public static string _ForeignServer01 = "host=10.128.24.5 user=postgres password=postgres dbname=esigndocument"; //Local Digitally Signed Data of Certificates
        public static string _ForeignServer02 = "host=10.128.24.5 user=postgres password=postgres dbname=ecitizendocument"; //Local Citizen Supporting Documents
        public static string _ForeignServer03 = "host=10.128.24.5 user=postgres password=postgres dbname=edistenclosureminor"; //Local Minor/Small Enclosure
        public static string _ForeignServer04 = "host=10.128.24.5 user=postgres password=postgres dbname=edistphotograph"; //Local Photograph Details
        public static string _ForeignServer05 = "host=10.128.24.5 user=postgres password=postgres dbname=edistsignedmajor"; //Local Digitally Signed Data of Major/Large Documents
        public static string _ForeignServer06 = "host=10.128.24.5 user=postgres password=postgres dbname=edistenclosuremajor"; //Local Major/Large Enclosure
    }
    public class Digilocker
    {
        public static int CodePage = 1252;
        public static string Action = "A";
        public static string RootNode = "PushUriResponse";
        public static string DigiDocRequestUrl = "digilocker.gov.in";

        public static string OrgId = "in.nic.delhigovt.edistrict"; //Production Server OrgId
        public static string AppKey = "fGapz7ZZgPJqG6P1AEr5ZimeH"; //Production Server AppKey
        public static string PushUrl = "https://partners.digitallocker.gov.in/public/issuer/api/issuedoc/1/xml"; //Production Server PushURL

        //public static string OrgId = "edistrict.delhigovt.nic.in"; //Staging Server OrgId
        //public static string AppKey = "Aw1104UivIJEY7CeOE350pHsn"; //Staging Server AppKey
        //public static string PushUrl = "https://devpartners.digitallocker.gov.in/public/issuer/api/issuedoc/1/xml"; //Staging Server PushURL
    }
    public class KeyName
    {
        public static string _Key01 = "OTUOOEOCRH";
        public static string _Key02 = "VRMQKQUKCY";
        public static string _Key03 = "HESIPBKJJI";
        public static string _Key04 = "ODSBKJTUOO";
        public static string _Key05 = "XTWODHEHQU";
        public static string _Key06 = "NOITACIFIREV";
        public static string _Key07 = "NOITACIFIREVFOTRANSPORT";
        public static string _Key08 = "GGSDGDFGR";
        public static string _Key09 = "HJDUIDBNSHGJS";
        public static string _Key10 = "THGINKKRADEHT";
    }
    public class DigitalSignature
    {
        public static string SetupDoc = "DigitalSignatureSetup.doc";
        public static string JdkBit32 = "jdk-6u35-windows-i586.zip";
        public static string JdkBit64 = "jdk-7u51-windows-x64.zip";
        public static string SmartCardDriver = "SC SED NIC-04-09-2012.zip";
        public static string eTokenFile = "eToken.dll";
        public static string BrowserSetup = "FirefoxSetup51.0.1.zip";

    }
    public class ESign
    {
        public static string EsignPFXFile = "~/Downloads/DigitalSignature/esign.pfx";
        public static string _EsignAppId = "edistrictdelhi";
        public static string _EsignAppInstance = "edistrict";
        public static string _EsignAppName = "edistrictdelhi";
        public static string _EsignAppURL = "https://edistrict.delhigovt.nic.in";
        public static string _EsignAspCode = "ASP0001";

        public static string _EsignSessionKey = "esignid";

        public static string _EsignOtpTableName = "esignotptransaction";
        public static string _EsignOtpTableColumn = "otpid";
        public static string _EsignPdfTableName = "esignpdftransaction";
        public static string _EsignPdfTableColumn = "esignid";
    }
    public class FolderPath
    {
        public static string AbstractFile = "/Downloads/Abstract/";
        public static string AppForm = "/Downloads/ApplicationForm/";
        public static string PdfImage = "/Downloads/PdfImages/";
        public static string SigningPath = "/Downloads/SigningFile/";
        public static string StaticImage = "/Downloads/StaticImage/";
        public static string InstructionFile = "/Downloads/Instruction/";
        public static string SignAppletPath = "/Content/Applets/";
        public static string DigitalSetup = "/Downloads/DigitalSignature/";
        public static string SCSTSanctionFile = "/App_Data/Upload/";
        public static string EsignInputPath = "/App_Data/Esign/pdfin/";
        public static string EsignOutputPath = "/App_Data/Esign/pdfout/";
        public static string CommonFiles = "/Downloads/CommonFiles/";
    }
    public class FileName
    {
        public static string CabinateNote = "CabinateNote20151126.pdf";
        public static string ForeignNational = "ForeignNationalCircular.pdf";
        public static string OrderServiceLaunch20160916 = "OrderServiceLaunch20160916.pdf";
    }
    public class ImageList
    {
        public static string ViewImage = "/Images/View.png";
        public static string NoImage = "/Images/NoPhoto.jpg";
        public static string Download = "/Images/dwnld.jpg";
        public static string Verified = "/Images/DataVerified.jpg";
        public static string NoDocAttached = "/Images/NoDocAttach.jpg";
        public static string ErrorIcon = "/Images/ErrorIcon.png";
        public static string WarningIcon = "/Images/WarningIcon.png";
        public static string AlertIcon = "/Images/AlertIcon.png";
        public static string CautionIcon = "/Images/CautionIcon.png";
        public static string InfoIcon = "/Images/info.png";
    }
    public class MessagePopup
    {
        public static string INF001 = "After registration, access code and password will be sent at the mobile no. provided in the registration form. The registration needs to be completed within 72 hours by providing the access code and password at the e-District Delhi website otherwise registration will not be completed and citizen will be required to provide the registration details again.\n\nIn case you do not have an Aadhaar No. or Voter ID Card, please apply at any of the counters at Tehsil/Sub-Division Office.";
        public static string INF002 = "Please ensure your income is less than 1 Lakh. This scheme is for underprivileged, poor and less privileged people.";
    }
    public class StaticMessage
    {
        public static string MSG001 = "The Verification Of Supporting Documents has been in Accordance Within Department Order No: F.No. 87/27/CCS/2018/Misc./863-873 Dated: 09/09/2018.";
        public static string MSG002 = "The Verification Of Supporting Documents has been done as per the scheme and guideline of department.";
    }
    public class MiscellaneousValues
    {
        public static string TypeOfLiftList = "TYPEOFLIFTLIST";
        public static string LiftControlName = "LBRInspectionColumnMaster.bool301";
        public static string PulledBack = "[APPLICATION PULLED BACK]";
        public static string RenewalLiftControlName = "LBRInspectionColumnMaster.bool348";
        public static string CEAControlName = "LBRInspectionColumnMaster.bool301";
    }
    public class OldEppStatus
    {
        public static string SignedBySDM = "Signed By SDM";
        public static string SignedByTehsildar = "Signed By Tehsildar";
        public static string Issued = "Issued";
        public static string IssuedbyCourier = "Issued by Courier";
        public static string IssuedByHand = "Issued By Hand";
        public static string IssuedBySpeedPost = "Issued By Speed Post";
        public static string IssuedToJeevanCenter = "Issued To Jeevan Center";
        public static string Cancelled = "Cancelled";
        public static string CancelledbySDM = "Cancelled by SDM";
        public static string Rejected = "Rejected";
        public static string RejectedbyTehsildar = "Rejected by Tehsildar";
        public static string RejectedbySDM = "Rejected by SDM";
        public static string Approved = "Approved";
    }
    public class DocumentType
    {
        public static string typePdf = "application/pdf";
        public static string typeJpg = "image/jpeg";
        public static string typePng = "image/png";
    }
    public class ParamCookies
    {
        public static string AspNetSessionId = "ASP.NET_SessionId";
        public static string AspAuthToken = ".ASPXAUTH";
        public static string SessionToken = "__SessionVerificationToken";
        public static string RequestToken = "__RequestVerificationToken";
    }
    #endregion

    #region enumarator for staic value in application

    public enum ServiceList : int
    {
        Domicile = 9054,
        Death = 9064,
        LalDora = 9067,
        Nationality = 9056,
        ST = 9072,
        SCST = 9051,
        Surviving = 9066,
        Solvency = 9052,
        Income = 9055,
        Disability = 9080,
        Birth = 9063,
        OBC = 9050,
        Marriage = 9073,
        Solemnization = 9074,
        CDVolunteer = 9076,
        ProvisionalCinema = 9079,
        FreshCinemaLicense = 9077,
        RenewalCinemaLicense = 9078,
        NOC = 9058,
        Recovery = 9081,
        Migration = 9082,
        NT = 9083,
        FirmRegistration = 9084,
        SocietyRegistration = 9085,
        OnlineCauseList = 9086,
        TrackCourtCases = 9087,
        FinalJudgmentonCourtCases = 9088,
        CertifiedCopyFromSR = 9091,
        Demarcation = 9092,
        NGT = 9093,
        Mutation = 9059,
        TirthYatraYojna = 9095,

        OldAge = 2601,
        Handicapped = 2604,
        DFBScheme = 2606,

        NFSNewRc = 9008,
        NFSSurrenderRc = 9009,
        NFSHofChange = 9011,
        NFSMemberChange = 9013,
        NFSFpsChange = 9010,
        NFSDetailsUpdate = 9012,
        NFSMemberDeletion = 9015,
        NFSMemberAddition = 9014,

        ByplBillPayment = 5039,
        BrplBillPayment = 7099,
        NdplBillPayment = 7085,

        BOCW = 5052,
        ContractLabour = 5069,
        Contractors = 5070,
        PayWagesInspection = 5084,
        BonusActInspection = 5081,
        DelhiSEInspection = 5082,
        FactoryInspection = 5080,
        MinWagesInspection = 5087,
        CLActInspection = 5086,
        PayGratuityInspection = 5085,
        EqualRemunInspection = 5083,
        InstallationOfLift = 5088,
        GrantOfPassengerLift = 5089,
        RenewalOfPassengerLift = 5090,
        LbrRecovery = 5137,
        CEA1 = 5133,
        CEA2 = 5134,
        CEA3 = 5135,
        ECLicence = 5059,
        CompCertificate = 5057,
        RenewalOfContractor = 5136,

        ConstructionWorker = 5138,
        RenewalConsWorker = 5048,
        DeathBenefits = 5121,
        FuneralBenefit = 5122,
        FamilyPension = 5130,
        MarriageAssistance = 5129,
        EduScholarship = 5128,
        MedicalAssistance = 5127,
        HBA = 5132,
        DisabilityPension = 5125,
        Pension = 5124,
        MaternityBenefit = 5123,
        GrantofWork = 5131,
        InstrumentLoan = 5126,
        ExGratia = 5050,

        Widow = 2605,
        Ladli = 1404,

        HigherEducationSKGS = 3005,
        HeFinancialAssistance = 3006,

        MeritscholarshipProfessional = 4014,
        PostmatricScholarshipOBC = 4012,
        FinancialAssistanceStationery = 4016,
        PrematricScholarshipSC = 4011,
        PrematricScholarshipOBC = 4013,
        MeritscholarshipSchool = 4017,
        DrbrAmbedkarToppers = 4015,
        PrematricSC = 4019,
        PostmatricSC = 4018,

        //for djb
        DjbNewConnection = 5091,
        DjbMutation = 5092,
        DjbReconnection = 5094,
        DjbApplicationTracking = 5095,
        DjbBillPayment = 5096,
    }
    public enum DB
    {
        LS, //Live Server
        RS  //Registration Server
    }
    public enum RegistrationType
    {
        S = 1, //Self
        M = 2, //Minor
        H = 3, //Husband
        W = 4, //Wife
        B = 8, //Birth
        D = 9, //Death
    }
    public enum Permission : int
    {
        CITZ = 100,  //Citizen
        WIND = 101,  //Window
        DEAL = 102,  //Dealing Assistant
        TEHS = 103,  //Tehsildar
        SDMG = 104,  //SDM
        MONT = 105,  //Monitor
        DC = 106,    //Deputy Commissioner
        ADMN = 107,  //Admin
        VERF = 108,  //Verifier
        DCOM = 109,  //Observer (Higer Lever)
        P110 = 110, //Sanction Process Authority
        P111 = 111, //Sanction Approval Authority
        P112 = 112,  //CDV Incharge
        P113 = 113,  //Account Officer
        P114 = 114,  //Adm
        P115 = 115,  //Sdm Hq
        P116 = 116,  //Approved Bank
        P117 = 117,  //Agency Operator
        P118 = 118,  //Adminsitrator (HQ)
        P119 = 119,  //Super Adminsitrator
        P120 = 120,  //Academic Officer
        P121 = 121,  //SR Window
        P122 = 122,  //SR Dealing Assistant
        P123 = 123,  //SR SDM
        P124 = 124,  //Tehsildaar (NT)
        P129 = 129,  //Telecaller
        P130 = 130,//Verifier Tirth 
        P131 = 131,//MLA Tirth 
        P132 = 132,//Tirth Approval
        P133 = 133,//DTDC Tirth
        P136 = 136,//Mobile Sahayak
    }
    public enum Status : int
    {
        CANCEL = 1,    //Pending
        SCOM002 = 2,   //Pending For Approval (Existing CDV)
        VERSENT = 3,   //Sent For Verification
        SCOM004 = 4,   //Pending for Submit
        TEHSPEN = 5,   //Pending With Tehsildar
        TEHSREC = 6,   //Recommended by Tehsildar
        NOTIACT = 7,   //Notice Accepted
        INSPEND = 8,   //Pending for Inspection
        SCOM009 = 9,   //Discharge CDV
        //WINSEND = 10,  //Send To Window
        //WINDWAT = 11,  //At Window
        TEHSOBJ = 12,  //Objection by Tehsildar
        //SDMOBJC = 13,  //Objection by SDM                                                
        TEHSREJ = 14,  //Rejected by Tehsildar
        //REJECTE = 15,  //Rejected
        ISSUCER = 16,  //Issued
        //SDMSIGN = 17,  //Signed By SDM
        //SDMREJT = 18,  //Rejected By SDM                                                chnaged
        //PRINTRE = 19,  //Another Print Allowed
        //VERPENR = 20,  //Pending for Receive Verification
        DEALOLR = 21,  //Pending for Receining Online Application
        //DEALAPP = 22,  //Approved Online Application by Dealing Assistant
        //DEAKRJT = 23,  //Rejected by Dealing Assistant
        //DEALOBJ = 24,  //Objection by Dealing Assistant
        WEBPENC = 25,  //Pending for Enclosure
        //DEALCOM = 26,  //Pending for Completion
        WEBJST = 27,   //Query Replied
        //SDMPEND = 28,  //Pending With SDM                                                
        SCOM029 = 29,  //Pending for Photographs
        SCOM030 = 30,  //Pending for Fee Payment
        SCOM031 = 31,  //Pending for Appointment
        SCOM032 = 32,  //Pending for Priview
        SCOM033 = 33,  //Pending for Relevant details
        SCOM034 = 34,  //Pending for Collection Fee at Window
        SCOM035 = 35,  //Pending for Affidavit Collection at Window
        SCOM036 = 36,  //Certificate Physically Signed
        SCOM037 = 37,  //Pending At PIO
        SCOM038 = 38,  //Pending At APIO
        VERLGAZ = 39,  //Pending for Gazetted Verification Letter
        VERLOTHS = 40, //Pending for Other State Verification Letter
        CSCEDT = 41,   //Pending for Editing at CSC Level
        STRTINS = 43,  //Pending for Initiating Inspection
        OBSPEND = 44, //Pending For Observation
        OBSPEN2 = 45, //Pending for Secondary Observation
        SCOM046 = 46,  //Pending For Sanction
        SCOM047 = 47,  //Deficiency Submitted
        SCOM048 = 48,  //Justifcation Submitted
    }
    public enum ApplicantImageType : int
    {
        RegTemp = 1,
        RegMstr = 2,
        RegApp = 3,
        IntrApp = 4
    }
    public enum CustomText
    {
        TRUE,
        FALSE,
        True,
        False,
        N,
        Y,
        LastInsertedId,
        AadhaarNo,
        EnrolmentNo,
        ISSUED,
        FAIL,
        SUCCESS,
        NA,
        H,
        SC,
        YES,
        No,
    }
    public enum CustomValue : int
    {
        None = 1,
        No = 0,
        Yes = 1,
        YES=2,
        Forbidden = 403,
        OldAgeStaticCapping = 500,
    }
    public enum Nationality : int
    {
        Indian = 1,
    }
    public enum Country : int
    {
        India = 1,
    }
    public enum SelectControl : int
    {
        MatchedUnmatched = 1,
        VerifiedUnverified = 2,
        NonApplicable = 3,
        YesNo = 4,
    }
    public enum Dml : int
    {
        Insert = 1,
        Update = 2,
        Delete = 3,
        Select = 4,
    }
    public enum Objection : int
    {
        Other = 16
    }
    public enum ApplicationSource : int
    {
        Online = 1,
        Window = 2
    }
    public enum ControllerList : int
    {
        Account = 1,
        Admin = 2,
        Ajax = 3,
        Common = 4,
        Dealing = 5,
        Epay = 6,
        Error = 7,
        Home = 8,
        Print = 9,
        Public = 10,
        Receiving = 11,
        Report = 12,
        Sdm = 13,
        Sign = 14,
        Tehsildar = 15,
        Verifier = 16,
        Window = 17,
    }
    public enum Gender
    {
        M,
        F,
    }
    public enum ServiceGroup : int
    {
        Certificate = 1,
        Marriage = 2,
    }
    public enum RelatedTo
    {
        Self = 1,
        Minor = 2,
        Husband = 3,
        Wife = 4,
        Marriage = 5,
        WitnessI = 6,
        WitnessII = 7,
        WitnessIII = 10,
        Neighbor = 39,
        Applicant = 40,
        Spouse = 12,
        Attendant = 13,
    }
    public enum MaritalStatus : int
    {
        Spinster = 1,
        Bachelor = 2,
        Divorcee = 3,
        Widow = 4,
        Widower = 5,
    }
    public enum AppointmnetType : int
    {
        General = 1,
        Tatkal = 2,
    }
    public enum MarriageAct : int
    {
        Hindu = 69,
        Special = 70,
        Compulsory = 71,
        Special13 = 105,
        Special16 = 106,
        Anand = 841,
    }
    public enum PrintType : int
    {
        Reg = 1,
        App = 2,
        Cer = 3,
    }
    public enum CssClass
    {
        GridTable,
        InputForm,
        DisplayForm,
    }
    public enum LengthList
    {
        EncFile = 100,
        EncContent = 102400,
        AppPhoto = 50,
        AppLength = 51200,
        EncFileMarr = 200,
        EncContentMarr = 204800,
    }
    public enum ServiceFeeType : int
    {
        Basic = 1,
        Tatkal = 2,
        Penalty = 3,
        ApplicationCharges = 4,
        SecurityDeposit = 5,
        RenewalCharges = 6,
        LateFee = 7,
        LicenceFee = 8,
        AnnualCharges = 9,
    }
    public enum ServiceFee : int
    {
        CWAnnualFees = 20,
        CWApplicationFees = 25,
    }
    public enum PaymentMode : int
    {
        Online = 1,
        Offline = 2,
    }
    public enum DocumentTypeId : int
    {
        IdentityProof = 4,
        NotarizedAffidavit = 5,
        DeathProof = 8,
        ResidenceProofoflast5Years = 12,
        FirstYearDocumentProof = 13,
        SecondYearDocumentProof = 14,
        ThirdYearDocumentProof = 15,
        GazettedVerification = 16,
        FieldVerification = 17,
        DivorceProof = 18,
        NationalityProof = 19,
        MarriageReligiousPlace = 20,
        ProofBefore19510920 = 21,
        ProofBefore1993 = 22,
        BloodRelationCasteProof = 23,
        CasteProof = 23,
        RentRecieptThreeMonth = 24,
        BplRationCard = 25,
        SalariedFamilyIncome = 26,
        NotSalariedFamilyIncome = 27,
        ProofIncomeTaxPayer = 28,
        ProofRefugee = 29,
        ProofImmigrated = 30,
        LandOwnershipProof = 31,
        IncomeProof = 32,
        ProofOfBusiness = 33,
        ProofofPoliceReport = 38,
        OptionalDocument1 = 40,
        OptionalDocument2 = 41,
        ProofofIdentity = 43,
        GazettedOfficerAttestation = 44,
        GazettedOfficerAttestation1 = 45,
        GazettedOfficerAttestation2 = 46,
        SelfDeclaration = 53,
        IncomeProofNotSalaried = 54,
        ProofofElectricityConnection = 55,
        ProofofOldIncomeCertificate = 56,
        DomicileCertificateofotherstate = 58,
        ProofOfStayInDelhiAfter1951 = 59,
        BloodRelationProof = 60,
        PermanentAddressProof = 61,
        ProofofIncomeTaxreturnoflast3years = 62,
        ProofofLast3MonthSalarySlip = 63,
        SelfDeclarationL2 = 70,
        SelfDeclarationL1 = 75,
        SelfDeclarationL3 = 78,
        ProofofFIR = 81,
        IncomeProofSocialWelfare = 83,
        OptionalDocument3 = 84,
        Proofof12thCertificate = 93,
        ProofofITRStatement = 94,
        ProofofEmployment = 97,
        SelfDeclarationLbr1 = 118,
        SelfDeclarationLbr2 = 119,
        SelfDeclarationLbr3 = 120,
        CopyofCasteCertificate = 123,
        ProofofHostellerCertificate = 127,
        ResidanceProof = 133,
        IncomeSelfDeclaration = 134,
        SelfDeclarationLbr4 = 136,
        OptionalDocument4 = 137,
        SaleDeedCopy = 139,
        DeathCertificate = 140,
        WillCopy = 141,
        CourtOrder = 142,
        MortgageCopy = 143,
        LeaseCopy = 144,
        GiftDeed = 145,
        RelinquishmentDeed = 146,
        ExtensionOfLicenceProof = 147,
        ChangeInLicenceDetailsProof = 148,
        CopyofOldLicence = 149,
        SelfDeclarationLbrCons = 153,
        //MLACertificate = 154,
        NFSSCard = 162,
        FamilyIncomeCercategory2 = 163,
        //FamilyIncomeCercategory3 = 164,
        OutsideDelhiCertificate = 166,
        ProofofPermanentAddress = 168,
        proofofDOB = 169,
        CopyofChangeinNature = 172,
        LBREmployerCertificate = 173,
        CopyofROC = 174,
        CopyofAward = 176,
        PublicationCertificate = 177,
        ReasonDelay = 178,
        CalculationSheet = 179,
        DemandNotice = 180,
        AffidavitChangeName = 181,
        ChangeNameClaimant = 182,
        MPMLARecommendationLetter = 185,
        AuthorizationLetterEC = 195,
        MedicalCertificate = 229,
        SalaryCertificate = 230,
        MarriageCertificate = 231,
        PostmartomReport = 236,
        FIRCopy = 237,
        MarriageCard = 243,
        ConsentLetter = 248,
        IdentityProofofSpouse = 257,
        IdentityProofofAttendant = 258,
        DateofBirthProofofSpouse = 260,
        DateofBirthProofofAttendant = 261,
        IncomeProofFather = 277,
        IncomeProofMother = 278,
        FamilyIncomeCertificate = 279,
        LastLicenceNoc = 283,
        LbrLiftOwnerShipProof = 284,
        ProofofWitness1 = 285,
        ProofofWitness2 = 286,
        ProofofWitness3 = 287,
        ProofofWitness4 = 288,
        WBMembershipReceipt = 289,
    }
    public enum State : int
    {
        Haryana = 6,
        Delhi = 7,
        UP = 9,
        Mizoram = 15,
    }
    public enum MasterValueId : int
    {
        FixedAndMoveableAssets = 1,
        LalDoraDetails = 3,
        AcauiredDetailsForLalDora = 4,
        SourceofIncome = 5,
        FixedDeposits = 5,
        SharesDebentures = 6,
        Others = 7,
        PurposeToObtainIncomeCertificate = 7,
        CauseOfDeath = 8,
        SurvivingMemberRelationship = 9,
        PaternalRelationship = 10,
        SCSTDetails = 13,
        OBCIncomeDetails = 15,
        ZoneWiseSLAReport = 17,
        BloodGroup = 19,
        EducationalQualification = 20,
        LanguageKnown = 21,
        TechnicalQualification = 22,
        Occupation = 23,
        ProcessOption = 24,
        InspectionType = 25,
        CDVTrainingType = 26,
        CDVMembershipEarlier = 28,
        PCCReport = 29,
        NatureofNOCDocument = 30,
        BirthPlaceType = 33,
        CDVDutyType = 34,
        OddEvenApplicantType = 35,
        ElectricityProvider = 36,
        ElligibilityCategory = 37,
        NOCViolationAct = 38,
        NOCLandClassification = 39,
        NOCViolationSection = 40,
        NOCAquisitionType = 41,
        NFSMemberRelationship = 42,
        RecoveryType = 43,
        RecoveryPresentStatus = 44,
        RecoveryPresentStage = 45,
        WarnSMSType = 46,
        RecoveryNoticeType = 48,
        RecoveryNoticeServer = 49,
        RecoveryWarrantType = 50,
        ReliefType = 51,
        MigratedMemberRelationship = 52,
        Attendance = 53,
        KhataType = 54,
        MaritalStatus = 55,
        AccountType = 56,
        TimePeriod = 57,
        BirthCertificateType = 58,
        UidRelationType = 59,
        ServiceCategoryType = 60,
        PaymentMode = 61,
        HofChangeReason = 63,
        HigherEducationQualificationRequired = 67,
        HigherEducationAffiliatedBoard = 68,
        ResidentType = 69,
        ExaminationType = 70,
        HigherEducationMetriculation = 71,
        CitizenAppointmentType = 72,
        NatureOfEstLbr = 73,
        TypeOfEstLbr = 74,
        ComplainantTypeMaster = 75,
        ComplaintsNatureMaster = 76,
        LabourPaymentOptions = 77,
        CRProjectName = 78,
        HigherEducationCategory = 80,
        HigherEducationRelationList = 81,
        HigherEducationSecondry = 82,
        CLActComplaintTarget = 83,
        OperationType = 84,
        SocietyType = 85,
        HigherEducationSchoolCategory = 86,
        NatureofFirm = 87,
        ParentGuardianList = 88,
        OrganizationDetails = 89,
        HigherEducationSchoolCategory1 = 90,
        FreshOrRenewal = 91,
        PreMatScholarshipCategory = 92,
        PermissionRequiredList = 94,
        TeamMemberDept = 95,
        SCSTSchoolType = 98,
        SCSTSchoolNatureType = 99,
        SCSTFeeType = 100,
        SCSTFeeInitiateType = 101,
        SCSTDepartmentType = 102,
        GeneralNoticeList = 103,
        Declaration = 104,
        IntegrationModuleProcess = 105,
        FinancialAssistanceSchoolType = 106,
        DrbrAmbedkarToppersSchoolType = 107,
        PrematSchoolType = 108,
        MeritProfessionalSchoolType = 109,
        SCSTMeritGroup = 110,
        PreMatOBCCategory = 111,
        SendSms = 112,
        SendEmail = 113,
        CDVTrainingPreferenceList = 114,
        CDVServices = 115,
        DepartmentType = 116,
        PostMatSchoolType = 117,
        PayGatewayStatus = 118,
        EppStatusList = 119,
        TypeofLift1 = 120,
        TypeofLift2 = 121,
        TypeofLift3 = 122,
        TypeofSupportingCable = 123,
        HOFProfession = 124,
        VehicleType = 125,
        MutationType = 126,
        AuthenticationType = 127,
        AuthenticationDocument = 128,
        MutationRelation = 130,
        ConWorkerCategoryList = 131,
        ValidationCheckLevels = 132,
        SCSTApprovingDeptType = 133,
        ConsCertifyingAuthority = 136,
        ApparatusTypeList = 138,
        HigherEduAcadmicSession = 139,
        HEFinancialAssistanceCategory = 140,
        HECurrentStudyingClass = 141,
        HEPreviousClassPassed = 142,
        HELevelofCourse = 143,
        HeFinancialAssistanceDeclaration = 144,
        DisabilityType = 145,
        TransformerType = 146,
        PoleType = 147,
        DoorType = 148,
        LineCableTypeList = 149,
        PanelTypeList = 150,
        HeFeePaidMode = 151,
        RouteLengthType = 152,
        SizeofType = 153,
        SpanType = 154,
        RoadCrossingType = 155,
        PowerLinesTypeList = 156,
        SCSTWelfareAcadmicSession = 157,
        MatricScholarshipCategorySC = 159,
        VoltageLevel = 161,
        ConstitutionFirm = 162,
        TechnicalEduQual = 163,
        NatureofWork = 164,
        TirthYatraRouteList = 165,
        AcademicQualification = 167,
        ConsworkerWorkplaces = 168,
        GeneralSCSTOBC = 169,
        CourseType = 170,
        WorkmanCategory = 171,
        lbrClassList = 172,
        MeritCollegeGroupList = 173,
        TrithTravelBy = 194,
        DocumentVerificationMode = 195,
        SWStopPensionReasonList = 196,
        WidowWitness = 197,
        AuthorizationTypeList = 198,
    }
    public enum ValueId : int
    {
        AgricultureLand = 1,
        HouseBuilding = 2,
        PlantMachineryEquipment = 3,
        MotorVehicles = 4,
        LandTypePurchaseId = 11,
        GovernmentService = 14,
        PrivateService = 15,
        Business = 16,
        Natural = 33,
        UnNatural = 34,
        LoginSuccess = 64,
        WrongUserId = 65,
        WrongPassword = 66,
        SC = 67,
        ST = 68,
        TrackApplication = 76,
        VerifyCertificate = 77,
        GreenZone = 78,
        YellowZone = 79,
        RedZone = 80,
        SlaZone = 81,
        OtherStateLetter = 85,
        DownloadCertificate = 86,
        ChangeRequest = 109,
        ScheduledStaticData = 111,
        EnclosureData = 112,
        ScheduledverifierstatusData = 113,
        ScheduledEscalationData = 114,
        GovernmentPSU = 138,
        Private = 139,
        VthClass = 142,
        VIthClass = 143,
        VIIthClass = 144,
        BasicTraining = 168,
        SendSmsPendingDocSeen = 173,
        Adverse = 178,
        Annually = 186,
        Monthly = 187,
        Half = 190,
        VIIIthClass = 195,
        IXthClass = 196,
        Individual = 198,
        RWA = 199,
        Other = 200,
        SbiEpayPending = 213,
        US4 = 224,
        US6 = 225,
        Award = 226,
        Self = 227,
        IncompleteRegistration = 232,
        IncompleteApplication = 233,
        Notice = 234,
        Reminder = 235,
        FinalNotice = 236,
        AttachmentWarrant = 237,
        ArrestWarrant = 238,
        Present = 246,
        Absent = 247,
        UnMarried = 251,
        Married = 252,
        Divorcee = 253,
        Othervalue = 296,
        Single = 307,
        Joint = 308,
        Widow = 314,
        Divorced = 315,
        Seperated = 316,
        Quarterly = 323,
        Debit = 325,
        OtherComplainant = 362,
        Union = 371,
        Treasury = 381,
        Bank = 382,
        OBC = 387,
        General = 388,
        Minority = 389,
        Matriculation = 392,
        XthClass = 392,
        Highersecondary = 393,
        XIIthClass = 393,
        PrivateSchool = 424,
        Renewal = 434,
        PatwariReport = 435,
        Online = 437,
        NonBailableArrestWarrant = 437,
        Offline = 438,
        AttachmentWarrantNonMove = 438,
        BothType = 439,
        NoPayment = 440,
        CinemaInspectionInitiated = 477,
        CinemaInspectionEntered = 478,
        CinemaObjectionRaised = 479,
        CinemaInspectionComplete = 480,
        NotLinkTag = 481,
        LinkTag = 482,
        TuitionFees = 486,
        Applicant = 492,
        Department = 493,
        EducationDepartment = 494,
        TTE = 495,
        Declaration = 498,
        RASDataInsert = 500,
        DIGILockerDataInsert = 501,
        SLADataInsert = 502,
        IstClass = 503,
        IIndClass = 504,
        IIIrdClass = 505,
        IVthClass = 506,
        XIthClass = 507,
        Scholarship = 511,
        GroupA = 520,
        GroupB = 521,
        GroupC = 522,
        GroupD = 523,
        OtherCompulsoryFees = 529,
        InternalSMS = 530,
        NorthMCD = 556,
        SouthMCD = 557,
        EastMCD = 558,
        NDMC = 559,
        HigherEducationDepartment = 572,
        SbiEpayNewPayment = 578,
        SbiEpaySuccess = 579,
        SbiEpayFail = 580,
        ChallanBasedPayment = 581,
        OnlineBasedPayment = 582,
        SbiEpayCancel = 583,
        MinorProfileUpdate = 584,
        Issued = 590,
        Approved = 604,
        MachineRoomLess = 624,
        Rope = 625,
        Belt = 626,
        SaleDeed = 689,
        Virasat = 690,
        Vasiyat = 691,
        Courtorder = 692,
        MortgageDeed = 693,
        LeaseeInformation = 694,
        GiftDeed = 695,
        RelinquishmentDeed = 696,
        AuthCrendential = 697,
        AuthOtp = 698,
        AutheKYC = 699,
        AuthDigital = 700,
        SignDigital = 701,
        SignEsign = 702,
        SignNoSign = 703,
        OnlineCauseList = 726,
        TrackCourtCases = 727,
        FinalJudgmentonCourtCases = 728,
        TrackCourtCasesVillageWise = 729,
        TrackCourtCasesVillageKhasraWise = 730,
        CourtWisePendingCases = 731,
        Verified = 732,
        PFMSFileGenerated = 733,
        PFMSValidateComplete = 734,
        SanctionProcessed = 735,
        SanctionIssued = 736,
        InputEntry = 737,
        InspectionEntry = 738,
        EsignOTP = 742,
        EsignPDF = 743,
        EsignCerRequest = 747,
        Generator = 749,
        HigherEduCurAcadmicSession = 752,
        HeCategory1 = 753,
        HeCategory2 = 754,
        HeCategory3 = 755,
        HeDeclaration = 763,
        PendingVerification = 764,
        pForCertificateId = 765,
        Temporary = 766,
        Permanent = 767,
        Check = 781,
        DemandDraft = 782,
        SCSTWelfareAllowedDate = 803,
        OtpApplicationNo = 804,
        NonRefundableCourseFee = 806,
        HigherclassorEquivalent = 810,
        GovernmentSchool = 417,
        KendriyaVidyalaya = 561,
        Morethan650V = 811,
        DetailsModifyByAdmin = 824,
        DetailsModifyBySelfParent = 825,
        DeAttachProfile = 826,
        DeactivateProfile = 827,
        Additional = 823,
        Partnership = 365,
        Proprietorship = 366,
        CompanyRegistered = 812,
        Degree = 508,
        Diploma = 257,
        RehabilitationCouncilofIndia = 828,
        LoginConsent = 859,
        Cancelled = 593,
        Rectify = 605,
        Generatingplantofcapacityabove200KW = 860,
        OTPSubmitOnlineApplication = 861,
        RemaningFees = 868,
        AdditionalPaymentEntry = 869,
        AdditionalPaymentLetterUploaded = 870,
        AdditionalPaymentLetterApproved = 871,
        ProbableDuplicate = 872,
        AdditionalPaymentRevertBack = 1005,
        OTPMobileCitizenAuthenticate = 1017,
        Train = 1020,
        Bus = 1021,
        DefaultGeneralType = 1046,
        MobileSahakValueId = 1047,
        AuthorizationDeoForCM = 1048,
        AuthorizationDeoForMin = 1049,
    }
    public enum RejectionReason : int
    {
        Other = 8,
    }
    public enum Religion : int
    {
        Hindu = 1,
        Muslim = 2,
        Christian = 3,
        Sikh = 4,
        Buddhist = 5,
        Jain = 6,
        Parsi = 7,
    }
    public enum PrefixTypeList : int
    {
        SD = 1,// Son Daughter
        HW = 2,// Husband Wife
        SM = 3,// Shree Ms
        HH = 4,// His Her
        HS = 5,// He She
        MR = 6,// Him Her
        MM = 7,// mr mrs
    }
    public enum EnclosureDepartment : int
    {
        Other = 1,
        NDMC = 3,
        RevenueDepartment = 4,
        PassportAuthority = 5,
        UID = 6,
        MCD = 7,
        TransportDepartment = 8,
        ElectionCommission = 9,
        IncomTaxDepartment = 10,
        BSES = 11,
        TPDDL = 12,
        DJB = 16,
        FoodAndSupplyDepartment = 17,
        Aircel = 18,    
        BhartiAirtel = 19,    
        BSNL = 20,      
        Ideacellular = 21,    
        MTNL = 22,    
        MTSIndi = 23,    
        RelianceCommunications = 24,    
        TataDoCoMo = 25,    
        Uninor = 26, 
        CBSE = 27,
        EdistrictHaryana = 28,
        EdistrictUP = 29,
        EdistrictMizoram = 30,
        EdistrictDelhi = 31,
    }
    public enum DocumentId : int
    {
        AadhaarCard = 1,
        BankPassbookwithPhotographs = 3,
        BirthCertificate = 4,
        BurialSlip = 5,
        CremationSlip = 10,
        DeathCertificate = 11,
        DrivingLicense = 13,
        Electricityid = 14,
        Matriculation = 19,
        NationalityCertificate = 23,
        PANCard = 27,
        Passport = 28,
        RationCard = 30,
        RentAgreement = 31,
        Telephonebill = 35,
        VoterID = 36,
        WaterBill = 37,
        CasteCertificate = 43,
        BPLRelation = 44,
        Other = 65,
        StudentId = 75,
        SchoolIDcard = 82,
        LetterattestedschoolPrincipal = 83,
        GovtRecDoc = 84,
        GasBill = 85,
        Birthbelowfiveyear = 94,
        DomicileCertificate = 95,
        AadhaarCardVerifiedDOB = 98,
        RecoveryCaseNo = 110,
        tenthCertificate = 132,
        twelvethCertificate = 133,
        AadhaarCardBeneficiary = 149,
        CopyofBankDetails = 158,
        AadhaarCardCopy = 159,
        CopyOfCasteCertificate = 160,
        CopyOfIncomeCertificate = 165,
        AssistantLabourCommissioner = 201,
        Employeerincludingcontractor = 199,
        RegisteredTradeUnionConstruction = 200,
        IssuedRegisteredTradeUnionConstruction = 203,
        LBRBirthSelfCertification = 204,
        DischargeSummaryHospital = 240,
    }
    public enum WebServiceMethod : int
    {
        NfsService_GetDataFromFcs = 1,
        TransportService_GetDLdetails = 2,
        TataPowerDDLService_E_Dist_GetConsumer_CANO = 3,
        ElectionService_EpicinfoSearch = 4,
        NDMCBDService_GetData = 5,
        BSESService_ZBAPI_EDISTRICT = 6,
        GetAadhaarDetails_GetDetailsByNo = 7,
        CBSEXService_getData = 8,
        NDMCEWService_GetDetails = 9,
        DJBService_DJBXMLResponse = 10,
        MCDService_MCDResponse = 11,
        EdistrictHaryanaBDService_GetEdistrictHaryanaBDResponse = 12,
        PANVerification = 13,
        EdistrictMizoramService_GetEdistrictMizoramResponse = 15,
        EdistrictDelhi = 16,
    }
    public enum SigningType : int
    {
        SignedRecord = 1,
        SignedDocument = 2,
    }
    public enum Department
    {
        Dept001 = 1, //Department of Revenue
        Dept002 = 2, //Department of Social Welfare
        Dept003 = 3, //Department of NFS
        Dept004 = 4, //BSES Yamuna Power Limited
        Dept005 = 5, //BSES Rajdhani Power Limited
        Dept006 = 6, //NDPL
        Dept007 = 7, //Labour Department
        Dept008 = 8, //WCD
        Dept009 = 9, //HG
        Dept010 = 10,//Department For The Welfare Of Sc/ St
        Dept011 = 11,//Delhi Jal Board
        Dept015 = 15,//AR Department
        Dept016 = 16,//Welfare of Worker Board
    }
    public enum ControlType : int
    {
        txt = 1,
        ddl = 2,
    }
    public enum ApplicationHistoryMessage : int
    {
        MSG001 = 1, //Acknowledgement Receipt Generate                  
        MSG002 = 2, //Application Approved                              
        MSG003 = 3, //Application Rejected                              
        MSG004 = 4, //Appointment Taken                                 
        MSG005 = 5, //Certificate Signed                                
        MSG006 = 6, //Dealing Assistant Observation                     
        MSG007 = 7, //New Application Received                          
        MSG008 = 8, //Payemnt Fee Received                              
        MSG009 = 9, //Photo Captured                                    
        MSG010 = 10, //Physically Signed Certificate Attached            
        MSG011 = 11, //Print Unsigned Certificate                        
        MSG012 = 12, //Scrutiny of Reply Required by Citizen             
        MSG013 = 13, //Send for Verification                             
        MSG014 = 14, //Service Specific Details Saved                    
        MSG015 = 15, //Supporting Documents Attached                     
        MSG016 = 16, //Verification Report                               
        MSG017 = 17, //Witness Details Modified
        MSG018 = 18, //Query Raised on Application
        MSG019 = 19, //Application Send for Editing
        MSG020 = 20, //Send the Certificate for Rectification
        MSG021 = 21, //Verification Letter For Gazetted Officer Generated
        MSG022 = 22, //Verification Letter For Other State Generated
        MSG023 = 23, //Certificate Cancel
        MSG024 = 24, //Application Pulled from Verifier
        MSG025 = 25, //Verification Letter Uploaded
        MSG026 = 26, //Income Details Edited
        MSG027 = 27, //Assign New Verifier
        MSG028 = 28, //Modification Completed
        MSG029 = 29, //Verification Letter for Solemnization Generated
        MSG030 = 30, //Verification Letter for Solemnization Uploaded
        MSG031 = 31, //Solemnization Date Re-Assigned
        MSG032 = 32, //Documents Verified at CSC
        MSG033 = 33, //Application Details Edited
        MSG034 = 34, //Document Edited
        MSG035 = 35, //Inspection Date Generated by DM 
        MSG036 = 36, //Witness details processed & Photo re-captured
        MSG037 = 37, //Re-appointment taken
        MSG038 = 38, //Challan Generated changesinlbr
        MSG039 = 39, //Payment Done and Details Saved    
        MSG040 = 40, //Physically signed copy uploaded
        MSG041 = 41, //Observation Entered
        MSG043 = 43, //Application revert back to approval
        MSG044 = 44, //Existing CDV eneted
        MSG045 = 45, //Application marked for processing 
        MSG046 = 46, //Discharge CDV
        MSG047 = 47, //Notice Generated
        MSG048 = 48, //Case Disposed
        MSG049 = 49, //Solemnization Date Given
        MSG050 = 50, //Locality Change by Admin
        MSG051 = 51, //SCST Application revert back to Verification
        MSG052 = 52, //SCST Application Verified By School
        MSG053 = 53, //Sanction Approved  
        MSG054 = 54, //Application School/Department Change
        MSG058 = 58, //SCST Approval Update Scholarship
        MSG059 = 59, //SCST School Zone Changed
        MSG060 = 60, //Application Modify
        MSG061 = 61, //Age Verification Check Exempt
        MSG062 = 62, //Application revert back to Dealing 
        MSG063 = 63, //Enter Remaning Fees 
        MSG064 = 64, //Duplicate Identified
        MSG065 = 65, //Remaning Fees Letter Uploaded
        MSG066 = 66, //Remaning Fees Approved
        MSG067 = 67, //Selected in Draw 
        MSG068 = 68, //Travel Details Filled
        MSG069 = 69, //Submitted to Recommendation/Decision
        MSG070 = 70, //Additional Payment Revert Back
        MSG071 = 71, //Documents Verified at Tehsildar
        MSG072 = 72, //Contact Details Modified
        MSG073 = 73, //Contact Details Modified
    }
    public enum SourceEntityName
    {
        YesNoList,
        GenderList,
    }
    public enum ValueSourceType
    {
        DB, //Database
        M, //Model
    }
    public enum WebServiceResponse : int
    {
        Verified = 58,
        NotVerified = 59,
        AlreadyExist = 60,
        ExceptionOccurred = 61,
        WebServiceNotAvailable = 82,
        VerificationPending = 87,
    }
    public enum Source : int
    {
        UnderVerification = 1,
    }
    public enum InputControlType
    {
        txt,
        ddl,
    }
    public enum LetterTypeValueId : int
    {
        GazettedOfficerI = 83,
        GazettedOfficerII = 84,
        OtherStateLetter = 85,
        SolemnizationNotice = 89,
        SolemnizationVerificationLetter = 88,
        CDVerificationLetter = 107,
    }
    public enum SmsSendType : int
    {
        SMS001 = 1, //Registration Complete
        SMS002 = 2, //Application Received
        SMS003 = 3, //Application Approved
        SMS004 = 4, //Sent for Verification
        SMS005 = 5, //Application Rejection
        SMS006 = 6, //Application Cancelled
        SMS007 = 7, //Query Raised on Application
        SMS008 = 8, //Access Code and Password
        SMS009 = 9, //OTP for reset password
        SMS010 = 10, //Reset Password
        SMS011 = 11, //Change Password
        SMS012 = 12, //OTP for reset userid
        SMS013 = 13, //OTP for download certificate
        SMS014 = 14, //UserId created
        SMS015 = 15, //Pending For Document Seen
        SMS016 = 16, //Incomplete Registration
        SMS017 = 17, //Incomplete Application
        SMS018 = 18, //Application Approved for Sanction
        SMS019 = 19, //Application Approved for Sanction
        SMS020 = 20, //UserId Activated
        SMS021 = 21, //UserId Deactivated        
        SMS022 = 22, //UserId Updated
        SMS023 = 23, //Cinema//change169
        SMS024 = 24, //Send Internal Sms to authorized official
        SMS025 = 25, //Send child user credential to parent 
        SMS026 = 26, //Send UserId Password
        SMS027 = 27, //Send for Inspection 
        SMS028 = 28, //Send OTP for Department Login 
        SMS029 = 29, //send sms for SC/ST pending application
        SMS030 = 30, //SC/ST Application Send for Reverification
        SMS031 = 31, //SC/ST Processed by School
        SMS032 = 32, //SC/ST Processed by School 
        SMS033 = 33, //Revert Rejected Application
        SMS034 = 34, //Social Welfare Objection Message
        SMS035 = 35, //Application Revert to Approval
        SMS036 = 36, //Handicap Certificate Renewal
        SMS037 = 37, //Send SMS to Applicant For Rectify/Edit Application
        SMS038 = 38, //Send OTP For Modification Application
        SMS039 = 39, //Send SMS to applicant for certificate rectification
        SMS040 = 40, //Send GrievanceId To Applicant
        SMS041 = 41, //Locality Mapping Enable 
        SMS042 = 42, //Locality Mapping Disable 
        SMS043 = 43, //OTP Based Final Submit
        SMS044 = 44, //Re-Payment message for application
        SMS045 = 45, //Revert Application to Dealing Level
        SMS046 = 46, //Citizen Grievance Resolved
        SMS047 = 47, //Tirth Travel Details 
        SMS048 = 48, //Carry Forward Locality
        SMS049 = 49, //Carry Forward Locality
        SMS050 = 50, //Mobile Modification
    }
    public enum CountList : int
    {
        Type000 = 0,
        Type001 = 1,
        Type002 = 2,
        Type003 = 3,
        Type004 = 4,
        Type005 = 5,
        Type006 = 6,
        Type007 = 7,
        Type008 = 8,
        Type009 = 9,
        Type010 = 10,
        Type011 = 11,
        Type012 = 12,
        Type013 = 13,
        Type014 = 14,
        Type015 = 15,
        Type017 = 17,
        Type021 = 21,
        Type022 = 22,
        Type023 = 23,
        Type025 = 25,
        Type043 = 43,
        Type045 = 45,
        Type046 = 46,
        Type060 = 60,
        Type061 = 61,
        Type071 = 71,
        Type100 = 100,
        Type111 = 111,
        Type500 = 500,
    }
    public enum StaticTableMaster : int
    {
        GraphReportForHomePage = 1,
        SMSCountForHomePage = 2,
    }
    public enum InspectionTypeId : int
    {
        Fresh = 165,
        Renewal = 166,
        BiAnnual = 167,
        Provisional = 439,
    }
    public enum InspectionDocumentType : int
    {
        BuildingPlan = 1,
        FDClearance = 2,
        EDClearance = 3,
        MCDClearance = 4,
        DDMAClearance = 5,
        OD1 = 6,
        OD2 = 7,
        SitePlan = 8,
        TClearance = 9,
        CharCert = 10,
    }
    public enum DeathProof : int
    {
        Other = 6,
    }
    public enum NOCNotificationType : int
    {
        NotificationUS4 = 183,
        NotificationUS6 = 184,
        Award = 185,
        LinkArea = 999,
        EditArea = 9992,
    }
    public enum Category : int
    {
        General = 1,
        OBC = 2,
        SC = 3,
        ST = 4,
    }
    public enum LBRStatus : int
    {
        Pending = 328,
        InProcess = 329,
        Resolved = 330,
        Satisfactory = 332,
        PenaltyImposed = 333,
        InspectionCompleted = 339,
        NoticeGenerated = 340,
        SendForApproval = 341,
        NotSatisfactory = 386,
    }
    public enum LBRControlType : int
    {
        LabelGeneral = 334,
        LabelBold = 335,
        TextBox = 336,
        TextArea = 337,
        DropdownList = 338,
    }
    public enum TransactionType : int
    {
        Credit = 324,
        Debit = 325,
    }
    public enum NatureOfEstLbr : int
    {
        Other = 362,
    }
    public enum ChallanType : int
    {
        LicenseFee = 384,
        SecurityDeposit = 385,
        RenewalDeposit = 807,
        DemandSlip = 808,
        AmendmentDeposit = 809,
    }
    public enum LBRInspectionNoticeFields : int
    {
        MaxWorker = 421,
        StartDate = 422,
        EndDate = 423,
        DetailsOfWork = 424,
        NameAddressOFConOffice = 425,
        NameAddressOFPEOffice = 427,
        NameAddressOFConSite = 429,
        NameAddressOFPESite = 430,
    }
    public enum LBRCLInspectionTarget : int
    {
        PE = 390,
        Contractor = 391,
    }
    public enum ModuleMaster : int
    {
        ApplicantDetails = 1,
    }
    public enum InspectionColumnId : int
    {
        Name = 299,
        Address = 300,
        PerodicalInspectionDate = 345,
        RenewalName = 346,
        RenewalAddress = 347,
        
    }
    public enum Consent : int
    {
        AadhaarCitizen = 704,
        AadhaarCSC = 705,
        OtherDocumentCitizen = 706,
        OtherDocumentCSC = 707,
        VoterCitizen = 708,
        VoterCSC = 709,
    }
    public enum ValidationCheckLevels : int
    {
        CitizenReceivingGeneral = 718,
        CitizenReceivingMarriage = 719,
        DepartmentReceivingGeneral = 720,
        DepartmentReceivingMarriage = 721,
        DealingProcessGeneral = 722,
        DecisionProcessGeneralPost = 723,
        DecisionProcessGeneralGet = 725,
    }
    public enum ValidationChecks : int
    {
        AuthorizationIdCheck = 1,
        AuthenticationTypeCheck = 2,
        SigningTypeCheck = 3,
        StatusCheck = 4,
        EnclosreCheck = 5,
        AcceptedByCheck = 6,
        ApplicationDataCheck = 7,
        ApplicantDelhiStateCheck = 8,
        AgeCheck = 9,
        AadhaarVoterVerifiyCheck = 10,
        AdditionalDocVerifiyCheck = 11,
        DeactivatedLocalityCheck = 12,
        SubdivcodeCheck = 13,
        ApplicationDelhiCheck = 14,
        LocalityMappingCheck = 15,
        SRLocalityMappingCheck = 16,
        RegisteredWithAadhaarCheck = 17,
        RationCardWebServiceCheck = 18,
        RationCardWebService2Check = 19,
        SCSTServiceCheck = 20,
        OldAgeServiceCheck = 21,
        HEServiceCheck = 22,
        IsFemaleCheck = 23,
        IsLessThan1YrOld = 24,
        DuplicateCheck = 25,
        CSCSubdivCodeMatchCheck = 26,
        HusWifeUIDMatchCheck = 27,
        MarriageLocalityMappingCheck = 28,
        HusWifeIndianCheck = 29,
        DuplicateCheckPost = 30,
        LdRegWorkerValidity = 31,
        LdRegWorkerNomineeCheck = 32,
        LdRegWorkerDeathFuneral = 33,
        LdRegWorkerFamilyMemberCheck = 34,
        LdRegWorkerBaneficiaryCheck = 35,
        LdRegWorkerFamilyPensionCheck = 36,
        LdRegWorkerMembershipDurationForGrantOfWorkCheck = 37,
        LdRegWorkerMembershipDurationForInstrumentLoanCheck = 38,
        LdRegWorkerIsDisabilityAppliedCheck = 39,
        LdRegWorkerIsRenewalEligible = 40,
        AnotherCastCertCheck = 42,
        LdRenewalOfContractorLicenceCheck = 44,
        LbrApplicationStatuscheck = 45,
        TirthDocumentVerify = 46,
        SwdWcdApplicationVerificationCheck = 47,
        SwdWcdApplicationVerificationCheckPost = 48,

    }
    public enum HeUniversityInstitute : int
    {
        UnOutSideDehi = 43,
        InOutSideDehi10 = 286,
        InOutSideDehi12 = 287,
    }
    public enum AppTempCheck : int
    {
        Value0858 = 858, //for SC/ST approved duplicate
    }
    public enum RelationList : int
    {
        Daughter = 4,
        Son = 23,
        Wife = 25,
    }
    public enum BenefitAmount : int
    {
        DeathBenefit = 15000,
        DisabilityPensionBenefit = 15000,
        MedicalAssistanceBenefit = 15000,
    }
    public enum BirthPlace : int
    {
        Home = 1,
        Hospital = 2
    }
    public enum AllowYear : int
    {
        Y2016 = 2016,
    }


    public enum TempAppRange : int
    {
        Rev9055 = 1342647, //income certificate
    }
    public enum OccupationId : int
    {
        DAILYWAGESWORKER = 10,
        HOMESERVANT = 18,
        HOUSEWIFE = 20,
        MAID = 23,
        OTHER = 27,
        UNEMPLOYED = 46,
    }
    public enum WitnessType : int
    {
        NeighboursTwo = 5,
    }

    #endregion enumarator for staic value in application
}