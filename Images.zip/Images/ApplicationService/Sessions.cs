﻿using System;
using System.Web;
//using Edistrict.Models.Entities;
using Edistrict.Models.CustomClass;

namespace Edistrict.Models.ApplicationService
{
    public class Sessions
    {
        public static void setSalt(string usr) { HttpContext.Current.Session["salt"] = usr; }
        public static string getSalt() { return (string)HttpContext.Current.Session["salt"]; }

        public static void setCurrentUser(CitizenUserDetails User) { HttpContext.Current.Session["currentUser"] = User; }
        public static CitizenUserDetails getCurrentUser() { return (CitizenUserDetails)HttpContext.Current.Session["currentUser"]; }

        public static void setEmployeeUser(DepartmentUserDetails User) { HttpContext.Current.Session["employeeUser"] = User; }
        public static DepartmentUserDetails getEmployeeUser() { return (DepartmentUserDetails)HttpContext.Current.Session["employeeUser"]; }
    }
}