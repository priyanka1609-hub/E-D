﻿using System.Xml.Serialization;

namespace Api_MorphoAuthClient
{
  public class Bio
  {
    [XmlAttribute("type")]
    public string Type = "FMR";

    [XmlAttribute("posh")]
    public string FingerPosition { get; set; }

    [XmlText]
    public string Fmr_Base64 { get; set; }
  }
}
