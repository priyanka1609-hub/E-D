﻿using System.Xml.Serialization;

namespace Api_MorphoAuthClient
{
  public class Meta
  {
    [XmlAttribute("udc")]
    public string Unique_Device_Code { get; set; }

    [XmlAttribute("fdc")]
    public string Fingerprint_Device_Code { get; set; }

    [XmlAttribute("idc")]
    public string Unique_iris_Code { get; set; }

    [XmlAttribute("pip")]
    public string PublicIP_Device { get; set; }

    [XmlAttribute("lot")]
    public string Location_Type { get; set; }

    [XmlAttribute("lov")]
    public string Location_Value { get; set; }

    //changeuid20171017
    [XmlAttribute("cdc")]
    public string Camera_Device_Code { get; set; }


    [XmlAttribute("rdsId")]
    public string rdsId { get; set; }
    [XmlAttribute("rdsVer")]
    public string rdsVer { get; set; }
    [XmlAttribute("dpId")]
    public string dpId { get; set; }
    [XmlAttribute("dc")]
    public string dc { get; set; }
    [XmlAttribute("mi")]
    public string mi { get; set; }
    [XmlAttribute("mc")]
    public string mc { get; set; }


    }
}
