﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Api_MorphoAuthClient
{
    [XmlRootAttribute("PID")]
  public class BiosPID
  {
    public List<Bio> Bios;

    [XmlAttribute("ts")]
    public string TimeStamp { get; set; }

    [XmlAttribute("ver")]
    public string Version { get; set; }

    }
}
