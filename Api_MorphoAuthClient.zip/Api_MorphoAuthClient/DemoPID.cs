﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Api_MorphoAuthClient
{
  [XmlRootAttribute("PID")]
  public class DemoPID
  {
        public List<Pi> Demo;

        [XmlAttribute("ts")]
        public string TimeStamp { get; set; }

        [XmlAttribute("ver")]
        public string Version { get; set; }

        [XmlAttribute("wadh")]
        public string wadh { get; set; }
    }
}
