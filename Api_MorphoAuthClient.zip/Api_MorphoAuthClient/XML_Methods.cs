﻿using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Serialization;

namespace Api_MorphoAuthClient
{
    public class XML_Methods
    {
        public AuthRes ReadResponseXML(string response)
        {
            try
            {
                AuthRes authRes = XML_Methods.DeSerializeXmlToObject(response);
                if (authRes != null)
                {
                    authRes.Return = authRes.Return.ToUpper();
                    if (authRes.Return == "N" && !(authRes.Error_Code == "300") && !(authRes.Error_Code == "310"))
                        authRes.Return = "E";
                }
                return authRes;
            }
            catch
            {
                return (AuthRes)null;
            }
        }

        public static string SerializeObjectToXml(object objToSerialize, bool IsChildXml)
        {
            string input = string.Empty;
            try
            {
                XmlSerializer xmlSerializer = new XmlSerializer(objToSerialize.GetType());
                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Encoding = Encoding.UTF8;
                //changeuid20171017
                //if (IsChildXml) { settings.OmitXmlDeclaration = true; }
                    
                StringBuilder output = new StringBuilder();
                XmlWriter xmlWriter = XmlWriter.Create(output, settings);
                xmlWriter.WriteProcessingInstruction("xml", "version=\"1.0\"  encoding=\"UTF-8\" standalone=\"yes\"");
                XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
                if (IsChildXml)
                {
                    namespaces.Add(string.Empty, string.Empty);
                }
                else
                {
                    //namespaces.Add("ns", "http://www.uidai.gov.in/authentication/uid-auth-request/1.0");
                    namespaces.Add("ns", "http://www.uidai.gov.in/authentication/uid-auth-request/2.0");
                }
                xmlSerializer.Serialize(xmlWriter, objToSerialize, namespaces);
                input = ((object)output).ToString();
                input = Regex.Replace(input, ":ns", "");
            }
            catch
            {
                //code here
            }
            return input;
        }

        public static AuthRes DeSerializeXmlToObject(string xml)
        {
            AuthRes authRes = (AuthRes)null;
            try
            {
                if (!string.IsNullOrEmpty(xml))
                {
                    xml = XML_Methods.RemoveAllXmlNamespace(xml);
                    authRes = (AuthRes)new XmlSerializer(typeof(AuthRes)).Deserialize((Stream)new MemoryStream(Encoding.ASCII.GetBytes(xml)));
                }
            }
            catch
            {
                //code here
            }
            return authRes;
        }

        private static string RemoveAllXmlNamespace(string xmlData)
        {
            string pattern = "\\s+xmlns\\s*(:\\w)?\\s*=\\s*\\\"(?<url>[^\\\"]*)\\\"";
            IEnumerator enumerator = Regex.Matches(xmlData, pattern).GetEnumerator();
            try
            {
                if (enumerator.MoveNext())
                {
                    Match match = (Match)enumerator.Current;
                    xmlData = xmlData.Replace(match.ToString(), "");
                }
            }
            finally
            {
                IDisposable disposable = enumerator as IDisposable;
                if (disposable != null)
                    disposable.Dispose();
            }
            return xmlData;
        }
    }
}
