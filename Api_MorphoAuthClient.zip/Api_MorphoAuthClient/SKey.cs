﻿using System.Xml.Serialization;

namespace Api_MorphoAuthClient
{
  public class SKey
  {
    [XmlAttribute("ci")]
    public string Certificate_ExpDate { get; set; }

    [XmlText]
    public string SessionKey_Base64 { get; set; }
  }
}
