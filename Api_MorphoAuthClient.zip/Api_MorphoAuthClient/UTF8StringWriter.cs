﻿using System.IO;
using System.Text;

namespace Api_MorphoAuthClient
{
  internal class UTF8StringWriter : StringWriter
  {
    public override Encoding Encoding
    {
      get
      {
        return Encoding.UTF8;
      }
    }

    public UTF8StringWriter()
    {
    }

    public UTF8StringWriter(StringBuilder sb)
      : base(sb)
    {
    }
  }
}
