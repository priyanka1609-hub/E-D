﻿using System.Xml.Serialization;

namespace Api_MorphoAuthClient
{
  public class Auth
  {
    public Uses Uses;
    [XmlElement("Meta", IsNullable = false)]
    public Meta MetaTag;
    public SKey Skey;
    public Data Data;

    [XmlAttribute("uid")]
    public string UidNumber { get; set; }

    [XmlAttribute("tid")]
    public string Terminal_Id { get; set; }

    [XmlAttribute("ac")]
    public string Aua_Code { get; set; }

    [XmlAttribute("sa")]
    public string Sub_Aua_Code { get; set; }

    [XmlAttribute("ver")]
    public string API_Version { get; set; }

    [XmlAttribute("txn")]
    public string TransactionId { get; set; }

    [XmlAttribute("accessid")]
    public string AccessId { get; set; }

    //changeuid20171017
    [XmlAttribute("rc")]
    public string ResidentConsent { get; set; }

    //changeuid20171017
    [XmlAttribute("lk")]
    public string LicenseKey { get; set; }

    //[XmlAttribute("lk")]
    //public string License_Key { get; set; }

    

    public string Hmac { get; set; }

    public string Signature { get; set; }
  }
}
