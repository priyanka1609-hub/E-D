﻿using System.Xml.Serialization;

namespace Api_MorphoAuthClient
{
  public class AuthRes
  {
    [XmlAttribute("code")]
    public string Code { get; set; }

    [XmlAttribute("txn")]
    public string TransactionId { get; set; }

    [XmlAttribute("err")]
    public string Error_Code { get; set; }

    [XmlAttribute("ts")]
    public string Time_Stamp { get; set; }

    [XmlAttribute("ret")]
    public string Return { get; set; }

    [XmlAttribute("info")]
    public string Info { get; set; }

    [XmlAttribute("auaerr")]
    public string Aua_Error { get; set; }

    [XmlAttribute("accessid")]
    public string AccessId { get; set; }
  }
}
