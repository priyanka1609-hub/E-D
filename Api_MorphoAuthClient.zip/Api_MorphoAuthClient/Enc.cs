﻿using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Digests;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Paddings;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.X509;
using System;
using System.IO;

namespace ClassLibrary1
{
    public class Enc
    {
        public const string ASYMMETRIC_ALGO = "RSA/ECB/PKCS1Padding";

        public const int SYMMETRIC_KEY_SIZE = 256;

        public RsaKeyParameters publicKey;

        public DateTime certExpiryDate;

        public Enc(string publicKeyFileName)
        {
            FileStream fileStream = null;
            try
            {
                fileStream = new FileStream(publicKeyFileName, FileMode.Open, FileAccess.Read);
                Stream inStream = fileStream;
                X509Certificate x509Certificate = new X509CertificateParser().ReadCertificate(inStream);
                this.publicKey = (RsaKeyParameters)x509Certificate.GetPublicKey();
                this.certExpiryDate = x509Certificate.NotAfter;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                Console.Write(ex.StackTrace);
                throw new Exception("Could not intialize encryption module", ex);
            }
            finally
            {
                if (fileStream != null)
                {
                    try
                    {
                        fileStream.Close();
                    }
                    catch (IOException ex2)
                    {
                        Console.WriteLine(ex2.ToString());
                        Console.Write(ex2.StackTrace);
                    }
                }
            }
        }

        public Enc(byte[] publicKeyBytes)
        {
            try
            {
                X509Certificate x509Certificate = new X509CertificateParser().ReadCertificate(publicKeyBytes);
                this.publicKey = (RsaKeyParameters)x509Certificate.GetPublicKey();
                this.certExpiryDate = x509Certificate.NotAfter;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                Console.Write(ex.StackTrace);
                throw new Exception("Could not intialize encryption module", ex);
            }
        }

        public byte[] generateSessionKey()
        {
            SecureRandom random = new SecureRandom();
            KeyGenerationParameters parameters = new KeyGenerationParameters(random, 256);
            CipherKeyGenerator keyGenerator = GeneratorUtilities.GetKeyGenerator("AES");
            keyGenerator.Init(parameters);
            return keyGenerator.GenerateKey();
        }

        public byte[] encryptUsingPublicKey(byte[] data)
        {
            IBufferedCipher cipher = CipherUtilities.GetCipher("RSA/ECB/PKCS1Padding");
            cipher.Init(true, this.publicKey);
            return cipher.DoFinal(data);
        }

        public byte[] encryptUsingSessionKey(byte[] skey, byte[] data)
        {
            PaddedBufferedBlockCipher paddedBufferedBlockCipher = new PaddedBufferedBlockCipher(new AesEngine(), new Pkcs7Padding());
            paddedBufferedBlockCipher.Init(true, new KeyParameter(skey));
            int outputSize = paddedBufferedBlockCipher.GetOutputSize(data.Length);
            byte[] array = new byte[outputSize];
            int num = paddedBufferedBlockCipher.ProcessBytes(data, 0, data.Length, array, 0);
            int num2 = paddedBufferedBlockCipher.DoFinal(array, num);
            byte[] array2 = new byte[num + num2];
            Array.Copy(array, 0, array2, 0, array2.Length);
            return array2;
        }

        public byte[] generateSha256Hash(byte[] message)
        {
            IDigest digest = new Sha256Digest();
            digest.Reset();
            byte[] array = new byte[digest.GetDigestSize()];
            digest.BlockUpdate(message, 0, message.Length);
            digest.DoFinal(array, 0);
            return array;
        }

        public string getCertificateIdentifier()
        {
            return this.certExpiryDate.ToString("yyyyMMdd");
        }
    }
}