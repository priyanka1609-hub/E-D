﻿using System.Xml.Serialization;

namespace Api_MorphoAuthClient
{
    [XmlRootAttribute("Data")]
    public class Data
    {
        [XmlAttribute("type")]
        public string Data_Type { get; set; }

        [XmlText]
        public string EncodedPid_Base64 { get; set; }
    }
}