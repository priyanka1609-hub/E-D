﻿using System.Xml.Serialization;

namespace Api_MorphoAuthClient
{
   public class Pi
    {
        [XmlAttribute("ms")]
        public string MS = "E";

        [XmlAttribute("mv")]
        public string MV = "100";

        [XmlAttribute("name")]
        public string Name { get; set; }

        [XmlAttribute("gender")]
        public string Gender { get; set; }

        [XmlAttribute("dob")]
        public string Dob { get; set; }

        [XmlAttribute("phone")]
        public string Phone { get; set; }

        [XmlAttribute("email")]
        public string Email { get; set; }
    }
}
