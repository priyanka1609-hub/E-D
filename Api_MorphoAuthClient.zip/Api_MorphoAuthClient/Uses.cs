﻿using System.Xml.Serialization;

namespace Api_MorphoAuthClient
{
  public class Uses
  {
    [XmlAttribute("pi")]
    public string pi { get; set; }

    [XmlAttribute("pa")]
    public string pa { get; set; }

    [XmlAttribute("pfa")]
    public string Pfa { get; set; }

    [XmlAttribute("bio")]
    public string Bio { get; set; }

    [XmlAttribute("bt")]
    public string Bt { get; set; }

    [XmlAttribute("pin")]
    public string pin { get; set; }

    [XmlAttribute("otp")]
    public string otp { get; set; }
  }
}
