﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.Entities;
using System.Data;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomClass;
using Npgsql;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.DataService;

namespace Edistrict.Models
{
    public class AdminModels
    {
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        [Required(ErrorMessage = "Required")]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string ApplicantLocalityId { get; set; }
        public virtual string DeptCode { get; set; }
        [Required(ErrorMessage = "Select any one table")]
        public virtual string MasterTableId { get; set; }
        public virtual string MasterTableName { get; set; }
        public virtual string UpdateId { get; set; }
        public virtual string PKColumnName { get; set; }
        public virtual string LocalityId { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string LocalityName { get; set; }
        public virtual string SubDivCode { get; set; }
        public virtual string GeneratedScript { get; set; }
        public virtual string LocalityStatus { get; set; }
        public virtual string SubDivCodeStatus { get; set; }
        public virtual string ActionTaken { get; set; }
        public virtual string OutputPAN { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string ColumnId { get; set; }
        public virtual string ColumnName { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string ColumnValue { get; set; }
        public virtual string QueryDate { get; set; }
        public virtual string flag { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string MobileNo { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string Message { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string StateId { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string ServiceCode { get; set; }
        public virtual string ServiceName { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string LevelId { get; set; }
        public virtual string LevelName { get; set; }
        public virtual string ProcessId { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string Subject { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string ConcernedPerson { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string PerformedDate { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string Description { get; set; }
        public virtual string ScannedFile { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string SMSTypeId { get; set; }
        public virtual string ReqTypeId { get; set; }
        public virtual string AddDoc { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string OperationId { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string QueryInput { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string ModuleName { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string ModuleDescription { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string AllowedPermission { get; set; }
        public virtual string ModuleId { get; set; }
        public virtual string[] arrAllowedPermission { get; set; }
        [Required(ErrorMessage = "Select Constituency Name")]
        public virtual string ConstituencyID { get; set; }
        [Required(ErrorMessage = "Select Constituency Name")]
        public virtual string ConstituencyName { get; set; }
        [Required(ErrorMessage = "Select Constituency Name")]
        public virtual string UpdatedConstituencyID { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankBranchAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        [Required(ErrorMessage = "MicrCode Required")]
        [RegularExpression("([0-9]+)", ErrorMessage="Enter Valid MicrCode")]
        [StringLength(9, MinimumLength = 9, ErrorMessage="Enter Valid MicrCode")]
        public virtual string MICRCode { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string BankCode { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string ZoneId { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string DistrictId { get; set; }
        public virtual string CollegeZone { get; set; }
        public virtual string PermissionName { get; set; }
        public virtual string PCode { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string Schoolid { get; set; }
        [Required(ErrorMessage = "Please Capture/Upload Photo")]
        public virtual string PhotoSource { get; set; }
        [RequiredIf("PhotoSource", "C", ErrorMessage = "Plesae Capture Image")]
        public virtual string PhotoData { get; set; }
        public virtual byte[] UserPhoto { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string EmailId { get; set; }
        public virtual string SchoolName { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Please Check the checkbox")]
        public virtual bool check { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string SchoolCategoryId { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string HeSchoolName { get; set; }
        [RequiredIf("PhotoSource", "U", ErrorMessage = "Please Upload Scan Photo")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg" }, MaxContentLength = (int)LengthList.AppLength, MaxFileLength = (int)LengthList.AppPhoto, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase ApplicantPhoto { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual HttpPostedFileBase CasteFile { get; set; }
        public virtual HttpPostedFileBase SLAFile { get; set; }

        public virtual ApplicantDetails ApplicantDetails { get; set; }
        public virtual UserMaster UserMaster { get; set; }
        public virtual CasteMaster CasteMaster { get; set; }
        public virtual LocalityMaster LocalityMaster { get; set; }
        public virtual DashboardMessageMaster DashboardMessageMaster  { get; set; }
        public virtual UserCreationEnclosureDetails UserCreationEnclosureDetails { get; set; }
        public virtual RegistrationMaster RegistrationMaster { get; set; }
        public virtual MenuMaster MenuMaster { get; set; }
        public virtual CRRequestDetails CRRequestDetails { get; set; }
        public virtual DocumentMaster DocumentMaster { get; set; }
        public virtual BankMaster BankMaster { get; set; }
        public virtual ApplicationDetailsPrematsSC ApplicationDetailsPrematsSC { get; set; }
        public virtual HeUniversityMaster HeUniversityMaster { get; set; }
        public virtual HeCourseMaster HeCourseMaster { get; set; }
        public virtual HeInstitutionMaster HeInstitutionMaster { get; set; }
        public virtual HeBankBranchMaster HeBankBranchMaster { get; set; }
        public virtual ApplicationHandicappedDetails ApplicationHandicappedDetails { get; set; }
        public virtual ApplicationOldAgeDetails ApplicationDetailsOldAge { get; set; }
        public virtual ApplicationDetailsDFBScheme ApplicationDetailsDFBScheme { get; set; }
        public virtual ApplicationDetailsContractor ApplicationDetailsContractor { get; set; }
        public virtual ApplicationDetailsBOCWAct ApplicationDetailsBOCWAct { get; set; }
        public virtual ApplicationDetailsInstallationOfLift ApplicationDetailsInstallationOfLift { get; set; }
        public virtual ApplicationDetailsGrantOfPassengerLift ApplicationDetailsGrantOfPassengerLift { get; set; }
        public virtual ApplicationDetailsCLAct ApplicationDetailsCLAct { get; set; }
        public virtual SLAUtility SLAUtility { get; set; }
        public virtual ApiClientMaster ApiClientMaster { get; set; }

        public virtual DataTable dta { get; set; }
        public virtual DataTable dtb { get; set; }
        public virtual DataTable data { get; set; }
        public virtual DataTable dataS { get; set; }
        public virtual DataTable dataSC { get; set; }
        public virtual DataTable dataSCC { get; set; }
        
        public SelectList SchoolList { get; set; }
        public SelectList DeptMasterList
        {
            get
            {
                List<DeptMaster> DeptMasterList = DeptMaster.List<DeptMaster>(new Npgsql.NpgsqlCommand("select DeptCode,DeptName from dbo.deptmaster order by DeptName"));
                return new SelectList(DeptMasterList, "DeptCode", "DeptName");
            }
            set { }
        }
        public SelectList PermissionList
        {
            get
            {
                string Qry = "select PM.pcode,pname from dbo.permissionmaster PM inner join DeptToPermissionMaster DPM on DPM.pcode=PM.pcode::int and WhetherEntryAllowed=@WhetherEntryAllowed where deptcode=@ParamDeptCode and PM.pcode not in(@Permission)";
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DPM.whetherdistrequired=TRUE"; }
                Qry += " order by pname";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@WhetherEntryAllowed", CustomText.TRUE.ToString());
                cmd.Parameters.AddWithValue("@Permission", Sessions.getEmployeeUser().Permission);
                List<PermissionMaster> PermissionList = PermissionMaster.List<PermissionMaster>(cmd);
                return new SelectList(PermissionList, "Pcode", "Pname");
            }

            set { }
        }
        public SelectList DistrictList
        {
            get
            {
                string Qry = "select districtcode,districtname,stateid from dbo.DistrictMaster where deptcode=@ParamDeptCode";
                if (Sessions.getEmployeeUser() != null) { if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DistrictCode=@ParamDistrictCode"; } }
                Qry += " and stateid=@stateid order by districtname";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                List<DistrictMaster> DistrictList = DistrictMaster.List<DistrictMaster>(Cmd);
                return new SelectList(DistrictList, "districtcode", "districtname");
            }
            set { }
        }
        public SelectList SubDivList
        {
            get
            {
                string Qry = "select SubDivCode,SubDivDescription,DistrictCode from SubDivMaster where districtcode in (select districtcode from dbo.DistrictMaster where deptcode=@ParamDeptCode) order by SubDivDescription limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@ParamDeptCode", Sessions.getEmployeeUser().DeptCode);
                List<SubDivMaster> SubDivList = SubDivMaster.List<SubDivMaster>(Cmd);
                return new SelectList(SubDivList, "SubDivCode", "SubDivDescription");
            }
            set { }
        }
        public SelectList AllSubDivList
        {
            get
            {
                string Qry = "select SubDivCode,SubDivDescription,DistrictCode from SubDivMaster where districtcode in (select districtcode from dbo.DistrictMaster where deptcode=@ParamDeptCode and StateId=@Delhi) order by SubDivDescription";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@Delhi", (int)State.Delhi);
                List<SubDivMaster> SubDivList = SubDivMaster.List<SubDivMaster>(Cmd);
                return new SelectList(SubDivList, "SubDivCode", "SubDivDescription");
            }
            set { }
        }
        public SelectList MasterTableList
        {
            get
            {
                List<MasterTableMaster> MasterTableList = MasterTableMaster.List<MasterTableMaster>(new Npgsql.NpgsqlCommand("select tableid,tableheading as tablename from dbo.MasterTableMaster where whetheractive=TRUE order by tableheading"));
                return new SelectList(MasterTableList, "tableid", "tablename");
            }
            set { }
        }
        public SelectList AllLocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.WhetherActive=@WhetherActive and lm.WhetherActive=@WhetherActive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "Y" });
                list.Add(new SelectListItem() { Text = "No", Value = "N" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList DigitalCardTypeList
        {
            get
            {
                List<DigitalCardTypeMaster> DigitalCardTypeList = DigitalCardTypeMaster.List<DigitalCardTypeMaster>(new Npgsql.NpgsqlCommand("select Cardtypeid,CardTypeName from dbo.DigitalCardTypeMaster"));
                return new SelectList(DigitalCardTypeList, "Cardtypeid", "CardTypeName");
            }
            set { }
        }
        public SelectList CasteServiceList
        {
            get
            {
                string Qry = "select ServiceCode,ServiceName from ServiceMaster where ServiceCode in(@SC,@ST,@OBC) order by ServiceName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@SC", (int)ServiceList.SCST);
                Cmd.Parameters.AddWithValue("@ST", (int)ServiceList.ST);
                Cmd.Parameters.AddWithValue("@OBC", (int)ServiceList.OBC);
                List<ServiceMaster> CasteServiceList = ServiceMaster.List<ServiceMaster>(Cmd);
                return new SelectList(CasteServiceList, "ServiceCode", "ServiceName");
            }
            set { }
        }
        public SelectList StateMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select StateId,StateName from dbo.StateMaster where stateid=@stateid union all (select StateId,StateName from dbo.StateMaster where stateid<>@stateid order by statename)");
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                List<StateMaster> StateMasterList = StateMaster.List<StateMaster>(Cmd);
                return new SelectList(StateMasterList, "StateId", "StateName");
            }
            set { }
        }
        public SelectList DistList { get; set; }
        public SelectList WarnSMSTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.WarnSMSType);
                List<SelectValueMaster> WarnSMSTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(WarnSMSTypeList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList CRProjectMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMVTD.whetheractive=TRUE and SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CRProjectName);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList CRPermissionList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select pcode,pname from dbo.permissionmaster where pcode::integer in(@teh,@sdm,@dc) order by pname");
                cmd.Parameters.AddWithValue("@teh", (int)Permission.TEHS);
                cmd.Parameters.AddWithValue("@sdm", (int)Permission.SDMG);
                cmd.Parameters.AddWithValue("@dc", (int)Permission.DC);
                List<PermissionMaster> PermissionList = PermissionMaster.List<PermissionMaster>(cmd);
                return new SelectList(PermissionList, "Pcode", "Pname");
            }

            set { }
        }
        public SelectList CRYesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList ProcessTypeList { get; set; }
        public SelectList ServiceListMaster
        {
            get
            {
                string Qry = "select ServiceCode,ServiceName from ServiceMaster where WhetherActive=True and DeptCode=@DeptCode order by ServiceName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@DeptCode", Sessions.getEmployeeUser().DeptCode);
                List<ServiceMaster> ServiceListMaster = ServiceMaster.List<ServiceMaster>(Cmd);
                return new SelectList(ServiceListMaster, "ServiceCode", "ServiceName");
            }
            set { }
        }
        public SelectList OperationTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.IntegrationModuleProcess);
                List<SelectValueMaster> WarnSMSTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(WarnSMSTypeList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList ConstituencyList
        {
            get
            {
                string Qry = "select ConstituencyId,ConstituencyName from AssemblyConstituencyMaster order by ConstituencyName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                List<AssemblyConstituencyMaster> ConstituencyList = AssemblyConstituencyMaster.List<AssemblyConstituencyMaster>(Cmd);
                return new SelectList(ConstituencyList, "ConstituencyId", "ConstituencyName");
            }
            set { }
        }
        public SelectList AssemblyConstituencyMasterList
        {
            get
            {
                List<AssemblyConstituencyMaster> AssemblyConstituencyMasterList = AssemblyConstituencyMaster.List<AssemblyConstituencyMaster>(new Npgsql.NpgsqlCommand("select ConstituencyID,ConstituencyName from dbo.AssemblyConstituencyMaster"));
                return new SelectList(AssemblyConstituencyMasterList, "ConstituencyID", "ConstituencyName");
            }
            set { }
        }
        public SelectList BankMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select BankCode,BankName  from dbo.bankmaster  order by bankname");
                List<BankMaster> BankMasterList = BankMaster.List<BankMaster>(Cmd);
                return new SelectList(BankMasterList, "BankCode", "BankName");
            }
            set { }
        }
        public SelectList SCSTDeptZoneExistList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select distinct smvd.valueid,valuename from selectmastervaluedetails smvd inner join selectmastervaluetodetails smvtd on smvtd.valueid=smvd.valueid inner join dgen.prematdistrictmaster PDM on PDM.departmentid=smvd.valueid inner join dgen.prematzonemaster PZM on PZM.districtCode=PDM.districtid where mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.DepartmentType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList SCSTZoneList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select ZoneId as ValueId,ZoneName as ValueName from dgen.prematzonemaster  limit 0");
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList SCSTDistrictList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select DistrictId as ValueId,DistrictName as ValueName from dgen.prematdistrictmaster  limit 0");
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList SchoolTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.FinancialAssistanceSchoolType);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList AuthTypeList
        {
            get
            {
                string Qry = "select s1.valueid as SelectValueId,UPPER(s1.valuename) as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId  ";
                if (Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept015).ToString()) { Qry += " and s1.valueid=@AuthOtp "; } else { Qry += " and s1.valueid Not in (@eKYCAuth) "; }
                Qry += " order by s1.valuename";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.AuthenticationType);
                Cmd.Parameters.AddWithValue("@eKYCAuth", (int)ValueId.AutheKYC);
                Cmd.Parameters.AddWithValue("@AuthOtp", (int)ValueId.AuthOtp);
                List<SelectValueMaster> AuthenticationType = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(AuthenticationType, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList DocSignList
        {
            get
            {
                string Qry = "select s1.valueid as SelectValueId,UPPER(s1.valuename) as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId ";
                if (Sessions.getEmployeeUser().DeptCode == ((int)Department.Dept015).ToString()) { Qry += " and s1.valueid=@SignNoSign  "; } else { Qry += " and s1.valueid Not in (@eSignMod) "; }
                Qry += " order by s1.valuename desc";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.AuthenticationDocument);
                Cmd.Parameters.AddWithValue("@eSignMod", (int)ValueId.SignEsign);//only for display only digital signature
                Cmd.Parameters.AddWithValue("@SignNoSign", (int)ValueId.SignNoSign);
                List<SelectValueMaster> DocumentSign = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(DocumentSign, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList SchoolTypeListForUnlock
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.PostMatSchoolType);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList LevelList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.ValidationCheckLevels);
                List<SelectValueMaster> LevelList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(LevelList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList UserTimeTOList
        {
            get
            {
                List<string> list = new List<string>();
                DateTime Starttime = DateTime.ParseExact("00:00", "HH:mm", null);
                DateTime Endtime = DateTime.ParseExact("23:55", "HH:mm", null);
                int Inerval = 60;
                for (DateTime i = Starttime; i <= Endtime; i = i.AddMinutes(Inerval))
                {
                    list.Add(i.ToString("HH:mm"));
                }
                return new SelectList(list, null, null);
            }
            set { }
        }
        public SelectList UserTimeList
        {
            get
            {
                List<string> list = new List<string>();
                DateTime Starttime = DateTime.ParseExact("00:00", "HH:mm", null);
                DateTime Endtime = DateTime.ParseExact("23:55", "HH:mm", null);
                int Inerval = 60;
                for (DateTime i = Starttime; i <= Endtime; i = i.AddMinutes(Inerval))
                {
                    list.Add(i.ToString("HH:mm"));
                }
                return new SelectList(list, null, null);
            }
            set { }
        }
        public SelectList AllServiceListMaster
        {
            get
            {
                string Qry = "select ServiceCode,ServiceName from ServiceMaster where WhetherActive=True order by ServiceName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                List<ServiceMaster> ServiceListMaster = ServiceMaster.List<ServiceMaster>(Cmd);
                return new SelectList(ServiceListMaster, "ServiceCode", "ServiceName");
            }
            set { }
        }
        public SelectList UniversityList
        {
            get
            {
                List<HeUniversityMaster> UniversityList = HeUniversityMaster.List<HeUniversityMaster>(new Npgsql.NpgsqlCommand("select UniversityId,UniversityName from heuniversitymaster order by UniversityName limit 0"));
                return new SelectList(UniversityList, "UniversityId", "UniversityName");
            }
            set { }
        }
        public SelectList HeMCMUniversityMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select UniversityId,UniversityName from heuniversitymaster where servicecode=@ServiceCode order by UniversityName");
                Cmd.Parameters.AddWithValue("@ServiceCode", ServiceCode);
                List<HeUniversityMaster> HeMCMUniversityMasterList = SelectValueMaster.List<HeUniversityMaster>(Cmd);
                return new SelectList(HeMCMUniversityMasterList, "UniversityId", "UniversityName");

            }
            set { }
        }
        public SelectList HeMCMInstitutionMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select InstituitonId,InstituitonName from heinstitutionmaster where universityid=@UniversityId order by InstituitonName");
                Cmd.Parameters.AddWithValue("@UniversityId", Sessions.getEmployeeUser().AuthorizationId);
                List<HeInstitutionMaster> HeMCMInstitutionMasterList = SelectValueMaster.List<HeInstitutionMaster>(Cmd);
                return new SelectList(HeMCMInstitutionMasterList, "InstituitonId", "InstituitonName");

            }
            set { }
        }
        public SelectList HeBankMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select hebankcode,hebankname from hebankmaster where WhetherActive=True order by hebankname");
                List<BankMaster> HeMCMInstitutionMasterList = SelectValueMaster.List<BankMaster>(Cmd);
                return new SelectList(HeBankMasterList, "", "InstituitonName");

            }
            set { }
        }
        public SelectList HeBankBranchMasterList
        {
            get
            {
                List<HeBankBrachMaster> ServiceList = ServiceMaster.List<HeBankBrachMaster>(new Npgsql.NpgsqlCommand("select hebranchcode,branchname from hebankbranchmaster order by branchname LIMIT 0"));
                return new SelectList(ServiceList, "hebranchcode", "branchname");
            }
            set { }
        }
        public SelectList CourseEligibilityList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.HigherEducationQualificationRequired);
                List<SelectValueMaster> CourseEligibilityList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CourseEligibilityList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList CoursePeriodList
        {
            get
            {
                string Prefixval = string.Empty;
                List<SelectListItem> list = new List<SelectListItem>();
                for (int i = 1; i <= 6; i++)
                {
                    if (i == 1) { Prefixval = "st"; }
                    else if (i == 2) { Prefixval = "nd"; }
                    else if (i == 3) { Prefixval = "rd"; }
                    else { Prefixval = "th"; }
                    list.Add(new SelectListItem() { Text = i.ToString() + Prefixval + " Year", Value = (i).ToString() });
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList SCSTAcademicSessionList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int passedyear = 2016;
                //int curryear = 2016;   //----------------------Temp comment for 2017-18 session, un-comment when you wants to process for 2017-18
                int curryear = DateTime.Now.Year;

                for (int i = passedyear; i <= curryear; i++)
                {
                    list.Add(new SelectListItem() { Text = passedyear.ToString() + "-" + (passedyear + 1).ToString(), Value = passedyear.ToString() });
                    passedyear = passedyear + 1;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList IdentityDocumentList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select DocumentId,DocumentName from dbo.DocumentMaster where DocumentId in (@VoterID,@AadhaarCard) order by DocumentName");
                Cmd.Parameters.AddWithValue("@VoterID", (int)DocumentId.VoterID);
                Cmd.Parameters.AddWithValue("@AadhaarCard", (int)DocumentId.AadhaarCard);
                List<DocumentMaster> DocumentMasterList = DocumentMaster.List<DocumentMaster>(Cmd);
                return new SelectList(DocumentMasterList, "DocumentId", "DocumentName");
            }
            set { }
        }
        public SelectList SCSTDepartmentList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.DepartmentType);
                List<SelectValueMaster> WarnSMSTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(WarnSMSTypeList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList HeSchoolCategoryMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HigherEducationSchoolCategory);
                List<ServiceTypeMaster> ExaminationListMetri = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ExaminationListMetri, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList AuthorizationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select valueid as SelectValueId,valuename as SelectValueName from selectmastervaluedetails where valueid in (" + string.Join(",", Utility.GetSpecialPermissionForUser(Convert.ToInt32(UserMaster.Permission)).Values) + ")");
                List<SelectValueMaster> SelectUserTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(SelectUserTypeList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
    }
}