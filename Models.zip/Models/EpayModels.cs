﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.CustomClass;
using Edistrict.Models.Entities;

namespace Edistrict.Models
{
    public class EpayModels
    {
        public virtual string msg { get; set; }

        //public virtual PaymentResponseDetails PaymentResponseDetails { get; set; }



        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationId { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string StatusId { get; set; }
        public virtual bool IsResponse { get; set; }

        public virtual string ReferralValue { get; set; }
        public virtual string ResponseValue { get; set; }
        public virtual string ReferralUrl { get; set; }
        public virtual string MerchantId { get; set; }
        public virtual string ControllerName { get; set; }
        public virtual string ActionMethod { get; set; }
        public virtual ApplicationPaymentRequest ApplicationPaymentRequest { get; set; }
        public virtual ApplicationPaymentResponse ApplicationPaymentResponse { get; set; }
        public virtual PaymentGatewayParameter PaymentGatewayParameter { get; set; }
    }
}