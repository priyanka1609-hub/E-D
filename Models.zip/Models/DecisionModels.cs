﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.CustomClass;
using Edistrict.Models.Entities;
using System.ComponentModel.DataAnnotations;
using System.Data;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Edistrict.Models.ApplicationService;
using Npgsql;

namespace Edistrict.Models
{
    public class DecisionModels
    {
        [Required(ErrorMessage = "Application Id Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicationId { get; set; }
        [Required(ErrorMessage = "Application No. Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        [StringLength(14, MinimumLength = 14, ErrorMessage = "Enter Valid Application No.")]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string DeptCode { get; set; }
        [Required(ErrorMessage = "Please Select Marriage Act")]
        public virtual string MarriageActId { get; set; }
        [Required(ErrorMessage = "Please Enter Date")]
        public virtual string SolemnizationDate { get; set; }
        public virtual string Source { get; set; }
        public virtual string IsAlreadyVerified { get; set; }
        public virtual string IsAlreadyInspected { get; set; }
        public virtual string IsMarkedToSelf { get; set; }
        public virtual string CustomText { get; set; }
        public virtual System.Nullable<int> CustomId { get; set; }
        public virtual bool WhetherVerification { get; set; }
        public virtual bool WhetherVerificationLetterRequired { get; set; }
        [Required(ErrorMessage = "Select Value")]
        public virtual string StatusId { get; set; }
        [RequiredIf("SelectValueId", "Y", ErrorMessage = "Please Select Verifier")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string VerifierCode { get; set; }
        [Required(ErrorMessage = "Please Select Verification")]
        public virtual string SelectValueId { get; set; }
        public virtual int LBRPaymentStatus { get; set; }
        public virtual bool WhetherSolemnizationDatePassed { get; set; }
        public virtual string Flag { get; set; }
        [Required(ErrorMessage = "Please Select")]
        public virtual string WhetherNOCIssue { get; set; }
        public virtual string DocumentStatusId { get; set; }
        [Required(ErrorMessage = "Please Select")]
        public virtual string TransactionType { get; set; }
        public virtual string WhetherRecommend { get; set; }
        [Required(ErrorMessage = "Please Enter Remarks")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Minimum 2 & Maximum 250 character allowed")]
        public virtual string SchollRemarks { get; set; }
        public virtual string SCSTDepartmentId { get; set; }
        public virtual string SCSTDistrictId { get; set; }
        public virtual string SCSTZoneId { get; set; }
        public virtual string SchoolId { get; set; }
        public virtual string CategoryId { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PNo { get; set; }
        [RequiredIf("TransactionType", "382", ErrorMessage = "Please Fill")]
        public virtual string PName { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PAmount { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PDate { get; set; }
        public virtual bool WhetherDocVerified { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PNo2 { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PAmount2 { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PDate2 { get; set; }
        public virtual string PAmount3 { get; set; }
        public virtual string PAmount4 { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PNo3 { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PNo4 { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PDate3 { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PDate4 { get; set; }
        public virtual string WhetherWorkerIncreased { get; set; }
        public virtual string WhetherApplRenewal { get; set; }
        public virtual int PTotalAmount { get; set; }
        [Required(ErrorMessage = "Please Select Value")]
        public virtual string AcademicSession { get; set; }
        public virtual string AcademicSessionType { get; set; }
        public virtual string PAmount5 { get; set; }
        public virtual string WhetherApplAmend { get; set; }
        [Required(ErrorMessage = "Please Select")]
        public virtual string WhetherPertainEI { get; set; }
        public virtual string WhetherLastInspection { get; set; }
        public virtual string WhetherChangeRequired { get; set; }
        public virtual int[] verifierId { get; set; }
        public virtual string WhetherAllVerComp { get; set; }
        public virtual int IsPhysicalDocVerificationDone { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Please Check the checkbox")]
        public virtual bool ConditionCheck { get; set; }

        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg", "application/pdf" }, AllowedFileExtensions = new string[] { ".jpeg", ".jpg", ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public virtual HttpPostedFileBase PFile { get; set; }
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg", "application/pdf" }, AllowedFileExtensions = new string[] { ".jpeg", ".jpg", ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public virtual HttpPostedFileBase PFile2 { get; set; }
        [Required(ErrorMessage = "Please Upload")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg", "application/pdf" }, AllowedFileExtensions = new string[] { ".jpeg", ".jpg", ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public virtual HttpPostedFileBase PFile3 { get; set; }
        [Required(ErrorMessage = "Please Upload")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg", "application/pdf" }, AllowedFileExtensions = new string[] { ".jpeg", ".jpg", ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public virtual HttpPostedFileBase PFile4 { get; set; }

        public virtual DataTable data { get; set; }
        public virtual DataTable data1 { get; set; }
        public virtual DataTable data2 { get; set; }
        public virtual DataTable data3 { get; set; }
        public virtual DataTable data4 { get; set; }
        public virtual DataTable data5 { get; set; }
        public virtual DataTable data6 { get; set; }
        public virtual DataTable data7 { get; set; }
        public virtual DataTable data8 { get; set; }
        public virtual DataTable data9 { get; set; }
        public virtual DataTable data10 { get; set; }
        public virtual DataTable data11 { get; set; }
        public virtual DataTable datanoc { get; set; }
        public virtual DataTable datacdv { get; set; }
        public virtual DataTable dtVerificationLetter { get; set; }
        public virtual DataTable datadeficency { get; set; }
        public DataTable dtRegisteredWorkerDetails { get; set; }

        public virtual List<SelectListItem> AdditionalVerifier { get; set; }


        public virtual ApplicantDetails ApplicantDetails { get; set; }
        public virtual ApplicationDetails ApplicationDetails { get; set; }
        public virtual ApplicationDetailsDomicile ApplicationDetailsDomicile { get; set; }
        public virtual ApplicationHandicappedDetails ApplicationHandicappedDetails { get; set; }
        public virtual ApplicationOldAgeDetails ApplicationOldAgeDetails { get; set; }
        public virtual ApplicationDetailsNationality ApplicationDetailsNationality { get; set; }
        public virtual ApplicationDetailsDisability ApplicationDetailsDisability { get; set; }
        public virtual ApplicationDetailsSolvency ApplicationDetailsSolvency { get; set; }
        public virtual ApplicationDetailsBirth ApplicationDetailsBirth { get; set; }
        public virtual ApplicationDetailsDeath ApplicationDetailsDeath { get; set; }
        public virtual VerifierVerificationDetails VerifierVerificationDetails { get; set; }
        public virtual ApplicationDetailsIncome ApplicationDetailsIncome { get; set; }
        public virtual ApplicationDetailsSCST ApplicationDetailsSCST { get; set; }
        public virtual ApplicationDetailsST ApplicationDetailsST { get; set; }
        public virtual ApplicationDetailsOBC ApplicationDetailsOBC { get; set; }
        public virtual ApplicationDetailsLalDora ApplicationDetailsLalDora { get; set; }
        public virtual ApplicationDetailsSurviving ApplicationDetailsSurviving { get; set; }
        public virtual VerifierWitnessMaster VerifierWitnessMaster { get; set; }
        public virtual WitnessDetailsLalDora LalDoraWitnessDetails { get; set; }
        public virtual ApplicationLetterDetails ApplicationLetterDetailsModel { get; set; }
        public virtual MarriageWitnessMaster MarriageWitnessDetails { get; set; }
        public virtual ApplicationWidowDetails ApplicationWidowDetails { get; set; }
        public virtual ApplicationEnclosureDetails ApplicationEnclosureDetails { get; set; }
        public virtual ApplicationMarriageDetails ApplicationMarriageDetails { get; set; }
        public virtual ApplicationOldAgeDetails ApplicationDetailsOldAge { get; set; }
        public virtual ApplicationPhotoMaster ApplicationPhotoMaster { get; set; }
        public virtual SearchApplication SearchApplication { get; set; }
        public virtual ApplicantReciept ApplicantReciept { get; set; }
        //public virtual ApplicationRTIQuestionDetail ApplicationRTIQuestionDetail { get; set; }
        //public virtual ApplicationRTIMainDetail ApplicationRTIMainDetail { get; set; }
        //public virtual ApplicationDetailsRTIAns ApplicationDetailsRTIAns { get; set; }
        public virtual ApplicationDetailsCDV ApplicationDetailsCDV { get; set; }
        public virtual ApplicationDetailsCinematograph ApplicationDetailsCinematograph { get; set; }
        public virtual ApplicationInspectionDetails ApplicationInspectionDetails { get; set; }
        public virtual ApplicationDetailsNOC ApplicationDetailsNOC { get; set; }
        public virtual ApplicationDetailsMigration ApplicationDetailsMigration { get; set; }
        public virtual ApplicationDetailsBOCWAct ApplicationDetailsBOCWAct { get; set; }
        public virtual ApplicationDetailsCLAct ApplicationDetailsCLAct { get; set; }
        public virtual ApplicationDetailsContractor ApplicationDetailsContractor { get; set; }
        public virtual ApplicationDetailsDFBScheme ApplicationDetailsDFBScheme { get; set; }
        public virtual ApplicationDetailsLadli ApplicationDetailsLadli { get; set; }
        public virtual ApplicationDetailsNT ApplicationDetailsNT { get; set; }
        public virtual ApplicationDetailsRecovery ApplicationDetailsRecovery { get; set; }
        public virtual RecoveryNoticeDetails RecoveryNoticeDetails { get; set; }
        public virtual HeSkillDevelopmentScheme HeSkillDevelopmentScheme { get; set; }
        public virtual ApplicationDetailsSociety ApplicationDetailsSociety { get; set; }
        public virtual ApplicationDetailsFirm ApplicationDetailsFirm { get; set; }
        public virtual ApplicationDetailsPrematsSC ApplicationDetailsPrematsSC { get; set; }
        public virtual NOCApplicationRemarks NOCApplicationRemarks { get; set; }
        public virtual ApplicationDetailsFinancialAssistance ApplicationDetailsFinancialAssistance { get; set; }
        public virtual ApplicationDetailsMeritscholarshipSchool ApplicationDetailsMeritscholarshipSchool { get; set; }
        public virtual ApplicationDetailsDrbrAmbedkarToppers ApplicationDetailsDrbrAmbedkarToppers { get; set; }
        public virtual ApplicationDetailsMeritProfessional ApplicationDetailsMeritProfessional { get; set; }
        public virtual ApplicationDetailsPrematOBC ApplicationDetailsPrematOBC { get; set; }
        public virtual ApplicationDetailsPostmatOBC ApplicationDetailsPostmatOBC { get; set; }
        public virtual ApplicationDetailsSRCopy ApplicationDetailsSRCopy { get; set; }
        public virtual ApplicationDetailsDemarcation ApplicationDetailsDemarcation { get; set; }
        public virtual ApplicationDetailsInstallationOfLift ApplicationDetailsInstallationOfLift { get; set; }
        public virtual ApplicationDetailsGrantOfPassengerLift ApplicationDetailsGrantOfPassengerLift { get; set; }
        public virtual ApplicationDetailsLBRRecovery ApplicationDetailsLBRRecovery { get; set; }
        public virtual ApplicationDetailsRenewalOfPassengerLift ApplicationDetailsRenewalOfPassengerLift { get; set; }
        public virtual ApplicationDetailsRenewalContractor ApplicationDetailsRenewalContractor { get; set; }
        public virtual HeMCMFinancialAssistance HeMCMFinancialAssistance { get; set; }
        public virtual ApplicationDetailsConsWorker ApplicationDetailsConsWorker { get; set; }
        public virtual RenewalConsWorker RenewalConsWorker { get; set; }
        public virtual ApplicationDetailsCEA1 ApplicationDetailsCEA1 { get; set; }
        public virtual ApplicationDetailsCEA2 ApplicationDetailsCEA2 { get; set; }
        public virtual ApplicationDetailsCEA3 ApplicationDetailsCEA3 { get; set; }
        public virtual ApplicationDetailsEC ApplicationDetailsEC { get; set; }
        public virtual ApplicationDetailsCompCertificate ApplicationDetailsCompCertificate { get; set; }
        public virtual ApplicationDetailsDeathBenefits ApplicationDetailsDeathBenefits { get; set; }
        public virtual ApplicationDetailsFuneralBenefit ApplicationDetailsFuneralBenefit { get; set; }
        public virtual ApplicationDetailsFamilyPension ApplicationDetailsFamilyPension { get; set; }
        public virtual ApplicationDetailsMarriageAssistance ApplicationDetailsMarriageAssistance { get; set; }
        public virtual ApplicationDetailsEduScholarship ApplicationDetailsEduScholarship { get; set; }
        public virtual ApplicationDetailsMedicalAssistance ApplicationDetailsMedicalAssistance { get; set; }
        public virtual ApplicationDetailsHBA ApplicationDetailsHBA { get; set; }
        public virtual ApplicationDetailsDisabilityPension ApplicationDetailsDisabilityPension { get; set; }
        public virtual ApplicationDetailsPension ApplicationDetailsPension { get; set; }
        public virtual ApplicationDetailsMaternityBenefit ApplicationDetailsMaternityBenefit { get; set; }
        public virtual ApplicationDetailsGrantofWork ApplicationDetailsGrantofWork { get; set; }
        public virtual ApplicationDetailsInstrumentLoan ApplicationDetailsInstrumentLoan { get; set; }
        public virtual ApplicationDetailsExgratia ApplicationDetailsExgratia { get; set; }
        public virtual ApplicationDetailsPrematSCssd ApplicationDetailsPrematSCssd { get; set; }
        public virtual ApplicationDetailsPostmatSCssd ApplicationDetailsPostmatSCssd { get; set; }
        public virtual ApplicationDetailsTirthYatraYojana ApplicationDetailsTirthYatraYojana { get; set; }


        public virtual SelectList VerifierMaster { get; set; }
        public virtual SelectList SolemnizationDateList { get; set; }
        public virtual SelectList DecisionList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Approve", Value = ((int)Status.TEHSREC).ToString() });
                list.Add(new SelectListItem() { Text = "Reject", Value = ((int)Status.TEHSREJ).ToString() });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList MarriageActList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select ValueId as SelectValueId,ValueName as SelectValueName from dbo.SelectMasterValueDetails where ValueId in (@Under13,@Under16)");
                Cmd.Parameters.AddWithValue("@Under13", (int)MarriageAct.Special13);
                Cmd.Parameters.AddWithValue("@Under16", (int)MarriageAct.Special16);
                List<SelectValueMaster> MarriageActList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(MarriageActList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList ReasonMasterList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select RM.ReasonCode,RM.ReasonDetail from ReasonMaster RM  inner join  reasontoservicemaster RS on RM.ReasonCode=RS.ReasonCode where RM.whetheractive=@whetheractive and RS.whetheractive=@whetheractive and RS.ServiceCode=@ServiceCode order by RS.DisplaySequence ");
                cmd.Parameters.AddWithValue("@whetheractive", Edistrict.Models.ApplicationService.CustomText.TRUE.ToString());
                cmd.Parameters.AddWithValue("@ServiceCode", ApplicationDetails.ServiceCode);
                List<ReasonMaster> ReasonMasterList = ReasonMaster.List<ReasonMaster>(cmd);
                return new SelectList(ReasonMasterList, "ReasonCode", "ReasonDetail");
            }
            set { }
        }
        public virtual SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "Y" });
                list.Add(new SelectListItem() { Text = "No", Value = "N" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList SolemnizationMarriageActList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select ValueId as SelectValueId,ValueName as SelectValueName from dbo.SelectMasterValueDetails where ValueId in (@Special13)");
                Cmd.Parameters.AddWithValue("@Special13", (int)MarriageAct.Special13);
                //Cmd.Parameters.AddWithValue("@Special16", (int)MarriageAct.Special16);
                List<SelectValueMaster> MarriageActList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(MarriageActList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList YesList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "Y" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList LBRPaymentOptions
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.LabourPaymentOptions);
                List<SelectValueMaster> LBRPaymentOptions = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(LBRPaymentOptions, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList RecommendOptionList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Recommend", Value = "Recommended" });
                list.Add(new SelectListItem() { Text = "Not Recommend", Value = "Not Recommended" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList SCSTDepartmentList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select distinct smvd.valueid,valuename from selectmastervaluedetails smvd inner join selectmastervaluetodetails smvtd on smvtd.valueid=smvd.valueid where mastervalueid=@mastervalueid order by valuename ");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.SCSTApprovingDeptType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public virtual SelectList SCSTSchoolNameList
        {
            get
            {
                string Qry = "select SchoolId as SelectValueId,SchoolName||','||SchoolAddress as SelectValueName from dgen.prematschoolmaster where WhetherActive=@WhetherActive order by SchoolName limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", Edistrict.Models.ApplicationService.CustomText.True.ToString());
                List<SelectValueMaster> SubDivList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(SubDivList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList SCSTDistrictList
        {
            get
            {
                string Qry = "select DistrictId as SelectValueId,DistrictName as SelectValueName from dgen.prematdistrictmaster where WhetherActive=@WhetherActive order by DistrictName limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", Edistrict.Models.ApplicationService.CustomText.True.ToString());
                List<SelectValueMaster> SubDivList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(SubDivList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList SCSTZoneList
        {
            get
            {
                string Qry = "select ZoneId as SelectValueId,ZoneName as SelectValueName from dgen.prematzonemaster where WhetherActive=@WhetherActive order by ZoneName limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", Edistrict.Models.ApplicationService.CustomText.True.ToString());
                List<SelectValueMaster> SubDivList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(SubDivList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList SCSTCategoryList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.PreMatScholarshipCategory);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList DisbursalInsatllment
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int count = 10;
                for (int i = 1; i <= count; i++)
                {
                    list.Add(new SelectListItem() { Text = i.ToString(), Value = i.ToString() });
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList HeAcademicSessionList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valuename as SelectValueId,(s1.valuename::integer ||'-'||s1.valuename::integer + 1)  as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.HigherEduAcadmicSession);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList SCSTAcademicSessionList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int passedyear = 2016;
                //int curryear = 2016;//----------------------Temp comment for 2017-18 session, un-comment when you wants to process for 2017-18
                int curryear = DateTime.Now.Year;

                for (int i = passedyear; i <= curryear; i++)
                {
                    list.Add(new SelectListItem() { Text = passedyear.ToString() + "-" + (passedyear + 1).ToString(), Value = passedyear.ToString() });
                    passedyear = passedyear + 1;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
    }
}