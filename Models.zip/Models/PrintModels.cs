﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using Edistrict.Models.CustomClass;
using Edistrict.Models.Entities;

namespace Edistrict.Models
{
    public class PrintModels
    {
        public virtual System.Nullable<Int64> ApplicantUserId { get; set; }
        public virtual System.Nullable<int> ApplicationId { get; set; }
        public virtual System.Nullable<Int64> ApplicationNo { get; set; }
        
        public virtual string CssClass { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual System.Nullable<int> IsPrint { get; set; }
        public virtual string AnnualIncomeInWords { get; set; }
        public virtual string Message { get; set; }
        public virtual string UserName { get; set; }
        public virtual string ChallanFee { get; set; }
        public virtual string CLActInspectionTarget { get; set; }
        public virtual string SecurityDepositFee { get; set; }
        public virtual string FeeWords1 { get; set; }
        public virtual string FeeWords2 { get; set; }
        public virtual string DistrictCode { get; set; }
        public virtual string DistrictName { get; set; }
        public virtual string DAddress { get; set; }
        public virtual string RenewalDepositFee { get; set; }
        public virtual string AmendmentDepositFee { get; set; }
        public virtual string WhetherApplAmend { get; set; }
        public virtual string WhetherApplRenewal { get; set; }
        public virtual string FeeWords3 { get; set; }
        public virtual string FeeWords4 { get; set; }
        public virtual string WhetherWorkerIncreased { get; set; }
        public virtual string PenaltyFee { get; set; }
        public virtual string FeeWords5 { get; set; }
        public virtual string OldCertificateDate { get; set; }
        public virtual string AppliedMessage { get; set; }

        public ApplicantDetails ApplicantDetails { get; set; }
        public ApplicationDetailsLadli ApplicationDetailsLadli { get; set; }
        public ApplicationDetailsDFBScheme ApplicationDetailsDFBScheme { get; set; }
        public ApplicationHandicappedDetails ApplicationHandicappedDetails { get; set; }
        public ApplicationOldAgeDetails ApplicationOldAgeDetails { get; set; }
        public ApplicationWidowDetails ApplicationWidowDetails { get; set; }
        public NfsApplicationDetails NfsApplicationDetails { get; set; }
        public AffidavitDetails AffidavitDetails { get; set; }
        public SelfDeclarationDetails SelfDeclarationDetails { get; set; }

        public virtual DataTable dataa { get; set; }
        public virtual DataTable datab { get; set; }
        public virtual DataTable datac { get; set; }
        public virtual DataTable datad { get; set; }
        public virtual DataTable datae { get; set; }
    }
}