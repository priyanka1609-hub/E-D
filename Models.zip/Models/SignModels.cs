﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.Entities;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace Edistrict.Models
{
    public class SignModels
    {
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string UserAadhaarNo { get; set; }
        public virtual string UserName { get; set; }
        [Required(ErrorMessage = "Please enter OTP")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter a Valid OTP")]
        public virtual string EsignOTP { get; set; }
        public virtual int EsignAttempt { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string DownloadFileUrl { get; set; }
        public virtual string FilePath { get; set; }
        public virtual string ReturnUrl { get; set; }
        public virtual string RandomNo { get; set; }
        public virtual string ReferenceNo { get; set; }
        public virtual string UserId { get; set; }
        public virtual string CurrentDateTime { get; set; }
        public virtual string AnnualIncomeInWords { get; set; }
        public virtual string ViewName { get; set; }
        public virtual string RandomText { get; set; }

        public DigitalCardTypeMaster DigitalCardTypeMaster { get; set; }
        public UserDigitalMaster UserDigitalMaster { get; set; }
        public UserMaster UserMaster { get; set; }

        public HttpPostedFileBase DataFile { get; set; }

        public virtual DataTable dataa { get; set; }
        public virtual DataTable datab { get; set; }
        public virtual DataTable datac { get; set; }
        public virtual DataTable datad { get; set; }
        public virtual DataTable datae { get; set; }

        public virtual DataTable dataf { get; set; }
        public virtual DataTable datag { get; set; }
        public virtual DataTable datah { get; set; }
        public virtual DataTable datai { get; set; }
    }
}