﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.CustomClass;
using Edistrict.Models.Entities;
using System.ComponentModel.DataAnnotations;
using System.Data;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Edistrict.Models.ApplicationService;
using Npgsql;

namespace Edistrict.Models
{
    public class ProcessModels
    {
        [Required(ErrorMessage = "Application Id Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicationId { get; set; }
        [Required(ErrorMessage = "Application No. Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        [StringLength(14, MinimumLength = 14, ErrorMessage = "Enter Valid Application No.")]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        [Required(ErrorMessage = "Please Select Marriage Act")]
        public virtual string MarriageActId { get; set; }
        public virtual string Source { get; set; }
        public virtual string IsAlreadyVerified { get; set; }
        public virtual string CustomText { get; set; }
        public virtual System.Nullable<int> CustomId { get; set; }
        public virtual bool WhetherVerification { get; set; }
        public virtual bool WhetherVerificationLetterRequired { get; set; }
        [Required(ErrorMessage = "Select Value")]
        public virtual string StatusId { get; set; }
        [RequiredIf("SelectValueId", "Y", ErrorMessage = "Please Select Verifier")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string VerifierCode { get; set; }
        [Required(ErrorMessage = "Please Select Verification")]
        public virtual string SelectValueId { get; set; }
        public virtual string Flag { get; set; }
        public virtual string PoliceStationId { get; set; }
        [Required(ErrorMessage = "Please Enter Remarks")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Minimum 2 & Maximum 250 character allowed")]
        public virtual string ObsRemarks { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ActionDate { get; set; }
        [Required(ErrorMessage = "Please Select Recommendation")]
        public virtual string WhetherSchoolRecomended { get; set; }
        [Required(ErrorMessage = "Please Enter Remarks")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Minimum 2 & Maximum 250 character allowed")]
        public virtual string SchollRemarks { get; set; }
        public virtual bool WhetherDocVerified { get; set; }
        public virtual bool WhetherScStwelfateAllowed { get; set; }
        [Required(ErrorMessage = "Please Select Service")]
        public virtual string ServiceId { get; set; }
        public virtual string SCSTDepartmentId { get; set; }
        public virtual string SCSTDistrictId { get; set; }
        public virtual string SCSTZoneId { get; set; }
        public virtual string SchoolId { get; set; }
        public virtual string CategoryId { get; set; }
        public virtual string ActionType { get; set; }
        [DataFile(AllowedFileExtensions = new string[] { ".csv" }, ErrorMessage = "Invalid File")]
        public HttpPostedFileBase uploadFile { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Please Check the checkbox")]
        public virtual bool check { get; set; }
        [Required(ErrorMessage = "Please Select Value")]
        public virtual string AcademicSession { get; set; }
        public virtual string AcademicSessionType { get; set; }
        public virtual string ConstituencyId { get; set; }
        public virtual string RouteId { get; set; }

        public DataTable data { get; set; }
        public DataTable data1 { get; set; }
        public DataTable data2 { get; set; }
        public DataTable data3 { get; set; }
        public DataTable data4 { get; set; }
        public DataTable dtVerificationLetter { get; set; }

        public virtual ApplicantDetails ApplicantDetails { get; set; }
        public virtual ApplicationDetails ApplicationDetails { get; set; }
        public virtual ApplicationDetailsDomicile ApplicationDetailsDomicile { get; set; }
        public virtual ApplicationHandicappedDetails ApplicationHandicappedDetails { get; set; }
        public virtual ApplicationOldAgeDetails ApplicationOldAgeDetails { get; set; }
        public virtual ApplicationDetailsNationality ApplicationDetailsNationality { get; set; }
        public virtual ApplicationDetailsDisability ApplicationDetailsDisability { get; set; }
        public virtual ApplicationDetailsSolvency ApplicationDetailsSolvency { get; set; }
        public virtual ApplicationDetailsBirth ApplicationDetailsBirth { get; set; }
        public virtual ApplicationDetailsDeath ApplicationDetailsDeath { get; set; }
        public virtual VerifierVerificationDetails VerifierVerificationDetails { get; set; }
        public virtual ApplicationDetailsIncome ApplicationDetailsIncome { get; set; }
        public virtual ApplicationDetailsSCST ApplicationDetailsSCST { get; set; }
        public virtual ApplicationDetailsST ApplicationDetailsST { get; set; }
        public virtual ApplicationDetailsOBC ApplicationDetailsOBC { get; set; }
        public virtual ApplicationDetailsLalDora ApplicationDetailsLalDora { get; set; }
        public virtual ApplicationDetailsSurviving ApplicationDetailsSurviving { get; set; }
        public virtual VerifierWitnessMaster VerifierWitnessMaster { get; set; }
        public virtual WitnessDetailsLalDora LalDoraWitnessDetails { get; set; }
        public virtual ApplicationLetterDetails ApplicationLetterDetailsModel { get; set; }
        public virtual MarriageWitnessMaster MarriageWitnessDetails { get; set; }
        public ApplicationDetailsNT ApplicationDetailsNT { get; set; }
        public virtual ApplicationEnclosureDetails ApplicationEnclosureDetails { get; set; }
        public virtual ApplicationMarriageDetails ApplicationMarriageDetails { get; set; }
        public virtual ApplicationOldAgeDetails ApplicationDetailsOldAge { get; set; }
        public virtual ApplicationPhotoMaster ApplicationPhotoMaster { get; set; }
        public virtual SearchApplication SearchApplication { get; set; }
        public virtual ApplicantReciept ApplicantReciept { get; set; }
        public virtual ApplicationDetailsPrematsSC ApplicationDetailsPrematsSC { get; set; }
        public virtual ApplicationDetailsFinancialAssistance ApplicationDetailsFinancialAssistance { get; set; }
        public virtual ApplicationDetailsMeritscholarshipSchool ApplicationDetailsMeritscholarshipSchool { get; set; }
        public virtual ApplicationDetailsDrbrAmbedkarToppers ApplicationDetailsDrbrAmbedkarToppers { get; set; }
        public virtual ApplicationDetailsMeritProfessional ApplicationDetailsMeritProfessional { get; set; }
        public virtual ApplicationDetailsPrematOBC ApplicationDetailsPrematOBC { get; set; }
        public virtual ApplicationDetailsPostmatOBC ApplicationDetailsPostmatOBC { get; set; }

        public virtual ApplicationDetailsCDV ApplicationDetailsCDV { get; set; }
        public virtual CDVApplicantTrainingDetails CDVApplicantTrainingDetails { get; set; }
        public virtual CDVDutyDetails CDVDutyDetails { get; set; }
        public virtual ApplicationDetailsTirthYatraYojana ApplicationDetailsTirthYatraYojana { get; set; }

        //public ApplicationRTIQuestionDetail ApplicationRTIQuestionDetail { get; set; }
        //public ApplicationRTIMainDetail ApplicationRTIMainDetail { get; set; }
        //public ApplicationDetailsRTIAns ApplicationDetailsRTIAns { get; set; }
        public HeMCMFinancialAssistance HeMCMFinancialAssistance { get; set; }
        public virtual ApplicationDetailsPrematSCssd ApplicationDetailsPrematSCssd { get; set; }
        public virtual ApplicationDetailsPostmatSCssd ApplicationDetailsPostmatSCssd { get; set; }

        public SelectList VerifierMaster { get; set; }
        public SelectList DecisionList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Approve", Value = ((int)Status.TEHSREC).ToString() });
                list.Add(new SelectListItem() { Text = "Reject", Value = ((int)Status.TEHSREJ).ToString() });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList ReasonMasterList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select RM.ReasonCode,RM.ReasonDetail from ReasonMaster RM  inner join  reasontoservicemaster RS on RM.ReasonCode=RS.ReasonCode where RM.whetheractive=@whetheractive and RS.whetheractive=@whetheractive and RS.ServiceCode=@ServiceCode order by RS.DisplaySequence ");
                cmd.Parameters.AddWithValue("@whetheractive", Edistrict.Models.ApplicationService.CustomText.TRUE.ToString());
                cmd.Parameters.AddWithValue("@ServiceCode", ApplicationDetails.ServiceCode);
                List<ReasonMaster> ReasonMasterList = ReasonMaster.List<ReasonMaster>(cmd);
                return new SelectList(ReasonMasterList, "ReasonCode", "ReasonDetail");
            }
            set { }
        }
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "Y" });
                list.Add(new SelectListItem() { Text = "No", Value = "N" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList YesNoListTrueFalse
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList SWDCsvFormatStatusList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select StatusId,StatusName from StatusMaster where WhetherActive=True and StatusId in (@VERSENT,@TEHSPEN,@TEHSREC,@TEHSOBJ,@TEHSREJ,@ISSUCER,@DEALOLR,@WEBPENC,@WEBJST,@SCOM029,@SCOM032,@SCOM033) order by StatusName");
                cmd.Parameters.AddWithValue("@VERSENT", (int)Status.VERSENT);
                cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
                cmd.Parameters.AddWithValue("@TEHSREC", (int)Status.TEHSREC);
                cmd.Parameters.AddWithValue("@TEHSOBJ", (int)Status.TEHSOBJ);
                cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
                cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
                cmd.Parameters.AddWithValue("@DEALOLR", (int)Status.DEALOLR);
                cmd.Parameters.AddWithValue("@WEBPENC", (int)Status.WEBPENC);
                cmd.Parameters.AddWithValue("@WEBJST", (int)Status.WEBJST);
                cmd.Parameters.AddWithValue("@SCOM029", (int)Status.SCOM029);
                cmd.Parameters.AddWithValue("@SCOM032", (int)Status.SCOM032);
                cmd.Parameters.AddWithValue("@SCOM033", (int)Status.SCOM033);
                List<StatusMaster> ServiceList = Edistrict.Models.Entities.StatusMaster.List<StatusMaster>(cmd);
                return new SelectList(ServiceList, "StatusId", "StatusName");
            }
            set { }
        }

        public SelectList ServiceList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select ServiceCode,ServiceName from ServiceMaster where deptcode=@deptcode order by ServiceName ");
                cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                List<ServiceMaster> ServiceList = Edistrict.Models.Entities.ServiceMaster.List<ServiceMaster>(cmd);
                return new SelectList(ServiceList, "ServiceCode", "ServiceName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList SCSTSchoolTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.PostMatSchoolType);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList SCSTDepartmentList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select distinct smvd.valueid,valuename from selectmastervaluedetails smvd inner join selectmastervaluetodetails smvtd on smvtd.valueid=smvd.valueid where mastervalueid=@mastervalueid order by valuename ");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.SCSTApprovingDeptType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList SCSTSchoolNameList
        {
            get
            {
                string Qry = "select SchoolId as SelectValueId,SchoolName||','||SchoolAddress as SelectValueName from dgen.prematschoolmaster where WhetherActive=@WhetherActive order by SchoolName limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", Edistrict.Models.ApplicationService.CustomText.True.ToString());
                List<SelectValueMaster> SubDivList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(SubDivList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList SCSTDistrictList
        {
            get
            {
                string Qry = "select DistrictId as SelectValueId,DistrictName as SelectValueName from dgen.prematdistrictmaster where WhetherActive=@WhetherActive order by DistrictName limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", Edistrict.Models.ApplicationService.CustomText.True.ToString());
                List<SelectValueMaster> SubDivList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(SubDivList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList SCSTZoneList
        {
            get
            {
                string Qry = "select ZoneId as SelectValueId,ZoneName as SelectValueName from dgen.prematzonemaster where WhetherActive=@WhetherActive order by ZoneName limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", Edistrict.Models.ApplicationService.CustomText.True.ToString());
                List<SelectValueMaster> SubDivList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(SubDivList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList SCSTCategoryList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.PreMatScholarshipCategory);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList YesNoandotherList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "Y" });
                list.Add(new SelectListItem() { Text = "No", Value = "N" });
                list.Add(new SelectListItem() { Text = "SMS For Rectification/Edit", Value = "O" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList HeAcademicSessionList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valuename as SelectValueId,(s1.valuename::integer ||'-'||s1.valuename::integer + 1)  as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.HigherEduAcadmicSession);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList SCSTAcademicSessionList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int passedyear = 2016;
                //int curryear = 2016;//----------------------Temp comment for 2017-18 session, un-comment when you wants to process for 2017-18
                int curryear = DateTime.Now.Year;

                for (int i = passedyear; i <= curryear; i++)
                {
                    list.Add(new SelectListItem() { Text = passedyear.ToString() + "-" + (passedyear + 1).ToString(), Value = passedyear.ToString() });
                    passedyear = passedyear + 1;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList TirthYatraConstituencyList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select constituencyid,constituencyname from assemblyconstituencymaster where Whetheractive=@WhetherActive order by constituencyname");
                Cmd.Parameters.AddWithValue("@WhetherActive", Edistrict.Models.ApplicationService.CustomText.TRUE.ToString());
                List<AssemblyConstituencyMaster> ClassList = AssemblyConstituencyMaster.List<AssemblyConstituencyMaster>(Cmd);
                return new SelectList(ClassList, "constituencyid", "constituencyname");
            }
            set { }
        }
        public SelectList TirthYatraRouteList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.TirthYatraRouteList);
                List<SelectValueMaster> YatraRouteList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(YatraRouteList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList TourDaysNights
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                for (int i = 1; i <= (int)CountList.Type010; i++)
                {
                    list.Add(new SelectListItem() { Text = i.ToString(), Value = i.ToString() });
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList TimeList
        {
            get
            {
                DateTime start = DateTime.ParseExact("00:00 AM", "HH:mm tt", null);
                DateTime end = DateTime.ParseExact("23:59 PM", "HH:mm tt", null);

                int interval = 30;
                List<SelectListItem> list = new List<SelectListItem>();
                for (DateTime i = start; i < end; i = i.AddMinutes(interval))
                {
                    //lstTimeIntervals.Add(i.ToString("HH:mm tt"));
                    list.Add(new SelectListItem() { Text = i.ToString("HH:mm tt"), Value = i.ToString("HH:mm tt") });
                }
                return new SelectList(list, "Text", "Value");
            }
            set { }
        }
        [CustomProperty]
        public SelectList TirthTravelByList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select distinct smvd.valueid,valuename from selectmastervaluedetails smvd inner join selectmastervaluetodetails smvtd on smvtd.valueid=smvd.valueid where mastervalueid=@mastervalueid order by valuename ");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.TrithTravelBy);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
    }
}