﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Npgsql;
using Edistrict.Models.ApplicationService;
using ReportManagement;
using System.Data;

namespace Edistrict.Models.DataService
{
    public static class DigitalSignatureData
    {
        ///* method for getting the application data for digital signing
        // * the columns in given script are assigned in sequence based, do not change the sequence of column
        // * the sequence of column define in signservicetocolumndetails
        // * by default the basic details be automatically signed for every service request
        // */
        //public static string GetUnsignedData(Int64 AppNo)
        //{
        //    GetData data = new GetData();
        //    string CommonUnsignedString = string.Empty, SpecificUnsignedString = string.Empty;
        //    int ServiceCode = Convert.ToInt32(Utility.SelectColumnsValue("dbo.ApplicationDetails", "ServiceCode", "ApplicationNo", AppNo.ToString())[0]);

        //    string Qry = "select ad.applicationno,sm.servicename,ad.applicantname,ad.applicantgender,to_char(ad.applicantdob,'DD/MM/YYYY') as applicantdob,ad.applicantfathername,ad.applicantmothername,ad.applicanthusbandname,ad.applicantmobileno,ad.applicanthousenumber,ad.applicantstreetnumber,ad.applicantsublocality,lm.localityname,sd.subdivdescription,dm.districtname,st.statename,ad.applicantpincode,cm.countryname,nm.nationalityname,ad.applicationdate,ad.approveddate from applicationdetails ad inner join servicemaster sm on sm.servicecode=ad.servicecode inner join localitymaster lm on lm.localityid=ad.applicantlocalityid inner join subdivmaster sd on sd.subdivcode=ad.applicantsubdivcode inner join districtmaster dm on dm.districtcode=ad.applicantdistrictcode inner join statemaster st on st.stateid=ad.stateid inner join countrymaster cm on cm.countryid=ad.countryid inner join nationalitymaster nm on nm.nationalityid=ad.applicantnationality where ad.applicationno=@applicationno";
        //    NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
        //    Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //    CommonUnsignedString = Utility.GetUnsignedStringFromCmd(Cmd);

        //    if (ServiceCode == (int)ServiceList.Birth)
        //    {
        //        Qry = "select ChildName,FatherName,MotherName,to_char(DOB,'DD/MM/YYYY') as DOB,Gender,'' as PlaceofBirth,Reasonsofnonregistration,birthplacehouseno,birthplacestreetno,birthplacesublocality,LM.localityname,SD.subdivdescription,DM.districtname,SM.statename,CM.countryname,ADB.pincode,'' as Phouseno,'' as Pstreetno,'' as Psublocality ,'' as localityname,'' as subdivdescription,'' as districtname,'' as statename,'' as countryname,'' as Ppincode,'' as Whetheradoptedchild,'' as AdopterName,'' as AdopterFatherName,'' as AdopterMotherName,'' as AdopterSpouseName,'' as AdopterHouseNo,'' as AdopterStreetNo,'' as AdpoterSubLocality,'' as localityname,'' as subdivdescription,'' as districtname,'' as statename,'' as countryname,'' as AdopterPinCode,'' as OrphanageName,'' as OrphanageAddress,'' as OrphanageRegistrationNo,'' as caseno,'' as nameofjudge,'' as courtdetails,birthplaceid from drev.applicationdetailsbirth ADB  inner join dbo.localitymaster LM on LM.localityid=ADB.localityid inner join dbo.subdivmaster SD on SD.subdivcode=ADB.subdivcode  inner join dbo.districtmaster DM on DM.districtcode=ADB.districtcode  inner join dbo.statemaster SM on SM.stateid=ADB.stateid  inner join dbo.countrymaster CM on CM.countryid=ADB.countryid  left outer join dbo.localitymaster LM2 on LM2.localityid=ADB.plocalityid  left outer join dbo.subdivmaster SD2 on SD2.subdivcode=ADB.psubdivcode  left outer join dbo.districtmaster DM2 on DM2.districtcode=ADB.pdistrictcode  left outer join dbo.statemaster SM2 on SM2.stateid=ADB.pstateid  left outer join dbo.countrymaster CM2 on CM2.countryid=ADB.pcountryid  left outer join dbo.localitymaster LM3 on LM3.localityid=ADB.adopterlocalityid  left outer join dbo.subdivmaster SD3 on SD3.subdivcode=ADB.adoptersubdivcode  left outer join dbo.districtmaster DM3 on DM3.districtcode=ADB.adopterdistrictcode left outer join dbo.statemaster SM3 on SM3.stateid=ADB.adopterstateid left outer join dbo.countrymaster CM3 on CM3.countryid=ADB.adoptercountryid where ADB.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        SpecificUnsignedString = Utility.GetUnsignedStringFromCmd(Cmd);

        //    }
        //    else if (ServiceCode == (int)ServiceList.Death)
        //    {
        //        Qry = "select '' as relationwithdeceased,deceasedname, deceasedfathername, deceasedmothername, deceasedgender, rwithdeceasedid, dateofdeath, placeofdeath,  dateofcremation, placeofcremation, reasonsofnonregistration, deathproofid, '' as policereportdate, '' as policestationname, '' as causeofdeath, houseno, streetno, sublocality,LM.localityname, SD.subdivdescription, DM.districtname, SM.statename, CM.countryname, AD.pincode from drev.applicationdetailsdeath AD  inner join dbo.localitymaster LM on LM.localityid=AD.localityid  inner join dbo.subdivmaster SD on SD.subdivcode=AD.subdivcode  inner join dbo.districtmaster DM on DM.districtcode=AD.districtcode  inner join dbo.statemaster SM on SM.stateid=AD.stateid  inner join dbo.countrymaster CM on CM.countryid=AD.countryid where AD.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        SpecificUnsignedString = Utility.GetUnsignedStringFromCmd(Cmd);
        //    }
        //    else if (ServiceCode == (int)ServiceList.Disability)
        //    {
        //        Qry = "select birthplace,bloodgroup,'' as occupationtype,qualification,disabilitycertificateno,medicalcertificate,'' as whetherregempexchange, '' as  registrationno, '' as  registrationdate,  '' as identificationmarks,  DT.disabilitytypename,  DP.dpercentagename,  medicalcertificateissuedby,  dateofissue from drev.applicationdetailsdisability AD  inner join disabilitytypemaster DT on DT.disabilitytypeid=AD.disabilitytypeid  inner join disabilitypercentagemaster DP on DP.dpercentageid=AD.disabilitypercentageid  where AD.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        SpecificUnsignedString = Utility.GetUnsignedStringFromCmd(Cmd);
        //    }
        //    else if (ServiceCode == (int)ServiceList.Income)
        //    {
        //        Qry = "select '' as yearofstay,'' as monthofstay,placeofresidence,'' as propertyownername,'' as propertyownermobile,'' as propertyowneremail,'' as rentamount, '' as whetherbplrationcardholder ,'' as  rationcardissuedate, '' as rationcardno  ,'' as  whetherincomtaxpayable  ,'' as  panno , '' as salariedemployee  , annualincome,'' as  stampno ,'' as  stampperiodfrom, '' as stampperiodto, '' as occupationtype, SE.valuename as pforcertificate,SE1.valueid,SE1.valuename as FamilyincomeType from drev.applicationdetailsincome AD left outer join occupationmaster OM on OM.occupationid=AD.occupationid inner join selectmastervaluedetails SE on SE.valueid=AD.pforcertificateid inner join selectmastervaluedetails SE1 on SE1.valueid=AD.familyincomeid where AD.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        SpecificUnsignedString = Utility.GetUnsignedStringFromCmd(Cmd);
        //    }
        //    else if (ServiceCode == (int)ServiceList.LalDora)
        //    {
        //        Qry = "select applicationno ,  purposeofcertificate,'' as yearofliving,'' as monthofliving,SD.subdivdescription,DM.districtname,SM.statename,VM.villagename,'' as landtypename,  landdetail   ,  khasrano  ,  totallandmeasurement ,  landsurroundedeast  ,  landsurroundedwest  ,  landsurroundednorth  ,  landsurroundedsouth  ,  '' as  landacquiredtype from drev.applicationdetailslaldora AD  inner join villagemaster VM on VM.villageid=AD.villageid left outer join selectmastervaluedetails SE on SE.valueid=AD.landtypeid left outer join selectmastervaluedetails SE2 on SE2.valueid=AD.landacquiredtypeid inner join dbo.subdivmaster SD on SD.subdivcode=AD.subdivcode inner join dbo.districtmaster DM on DM.districtcode=AD.districtcode inner join dbo.statemaster SM on SM.stateid=AD.stateid where AD.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        string str1 = Utility.GetUnsignedStringFromCmd(Cmd);

        //        Qry = "select WDL.RelatedId,WDL.WName,WDL.Waadharno,WDL.Whouseno,WDL.Wstreetno,WDL.wsublocality,LM.LocalityName,SD.subdivdescription,DM.districtname,SM.statename,CM.countryname,WDL.wpincode,WDL.Wmobileno from drev.witnessdetailslaldora WDL inner join dbo.localitymaster LM on LM.localityid=WDL.wlocalityid inner join dbo.subdivmaster SD on SD.subdivcode=WDL.wsubdivcode inner join dbo.districtmaster DM on DM.districtcode=WDL.wdistrictcode  inner join dbo.statemaster SM on SM.stateid=WDL.wstateid inner join dbo.countrymaster CM on CM.countryid=WDL.wcountryid where ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        string str2 = Utility.GetUnsignedStringFromCmd(Cmd);

        //        if (string.IsNullOrEmpty(str1)) { SpecificUnsignedString = null; } else { SpecificUnsignedString = str1 + Environment.NewLine + str2; }
        //    }
        //    else if (ServiceCode == (int)ServiceList.Nationality)
        //    {
        //        Qry = "select   dateofbirth,  placeofbirth,  birthplaceofmother,  birthplaceoffather,  purposeforcertificate,  refugeeregistartioncertificateno,  refugeeregistartioncertificatedate,  migrationfromindiatopakistan,  migrationdate,  returndate,  returnedauthority,  whetherdisplacedperson,  displacedate,  displacedfrom,  yearofliving,  monthofliving,  whethermigrated,  migrationfrom,  dateofmigration,  whetherrefugee    from drev.applicationdetailsnationality where ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        SpecificUnsignedString = Utility.GetUnsignedStringFromCmd(Cmd);
        //    }
        //    else if (ServiceCode == (int)ServiceList.OBC)
        //    {
        //        Qry = "select ApplicationNo,CA.castename,'' as religionname,placeofbirth,SM.statename,whetherdelhiresident,'' as yearofliving,'' as monthofliving,whetherrelationobc,RL.relationname as certificateholderrelation,certificateholdername,certificateno,'' as obccertificateissuedate,'' as issuingauthority ,'' as  whetheragriculturalland, '' as iagrlandownername , '' as iagrlandaddress , '' as iagrlandarea , '' as iagrlanduse , '' as uagrlandownername , '' as uagrlandaddress ,'' as  uagrlandarea ,'' as  uagrlanduse     , '' as whethervacantland  ,'' as  vacantlandownername , '' as vacantlandaddress , '' as vacantlandarea , '' as vacantlanduse, '' as annualfamilyincomefromsalary ,'' as  annualfamilyincomefromagrland , '' as annualfamilyincomefromproperty , '' as annualfamilyincomefromother ,'' as  whethertaxpayer , '' as whetherwealthtaxact , AD.whethercentrecaste,'' as raddress,RS.statename,'' as rdesignation,whethercreamylayer from drev.applicationdetailsobc AD inner join castemaster CA on CA.casteid=AD.casteid left outer join relationmaster RL on RL.relationid=AD.certificateholderrelationid inner join dbo.statemaster SM on SM.stateid=AD.stateid left outer join dbo.statemaster RS on RS.stateid=AD.rstateid where AD.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        SpecificUnsignedString = Utility.GetUnsignedStringFromCmd(Cmd);
        //    }
        //    else if (ServiceCode == (int)ServiceList.SCST)
        //    {
        //        Qry = "select     SM.statename,  CM.castename,   RGM.religionname, '' as  applicantname,  '' as applicantfathername,  '' as applicantgender,  '' as  applicantdob, '' as  whethermarriedtodelhiresident, '' as  applicanthusbandname, '' as  marriagecertificateno,  '' as  issuedate,  whethermigrated ,  migrationstate,  migrationdistrict,  migrationvillage,  to_char(migrationdate,'DD/MM/YYYY') as migrationdate,  yearofliving,  monthofliving,  whetherrelationscst,  purposeofcertificate,  rname,  SV.valuename,  '' as rwithapplicant,  certificateno, '' as rissuedate, '' as  rissueaddress,'' as raddress,RS.statename,'' as rdesignation from  drev.applicationdetailsscst ADSCST  inner join dbo.statemaster SM on SM.stateid=ADSCST.stateid  inner join castemaster CM on CM.casteid=ADSCST.casteid   inner join dbo.ReligionMaster RGM on RGM.ReligionId=ADSCST.ReligionId  left outer join selectmastervaluedetails SV on SV.valueid=ADSCST.rwithapplicantid left outer join dbo.statemaster RS on RS.stateid=ADSCST.rstateid where ADSCST.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        SpecificUnsignedString = Utility.GetUnsignedStringFromCmd(Cmd);
        //    }
        //    else if (ServiceCode == (int)ServiceList.ST)
        //    {
        //        Qry = "select   SM.statename,  CM.castename,  RGM.religionname, '' as   applicantname, '' as   applicantfathername,  '' as  applicantgender,  '' as   applicantdob,  '' as  whethermarriedtodelhiresident, '' as   applicanthusbandname,  '' as  marriagecertificateno,  '' as   issuedate,  whethermigrated,  migrationstate,  migrationdistrict,  migrationvillage,  to_char(migrationdate,'DD/MM/YYYY') as migrationdate,  yearofliving,  monthofliving,  whetherrelationST,  purposeofcertificate,  rname,  SV.valuename,  '' as  rwithapplicant,  certificateno,  '' as  rissuedate, '' as   rissueaddress,'' as  raddress,RS.statename,'' as  rdesignation from  drev.applicationdetailsST ADST  inner join dbo.statemaster SM on SM.stateid=ADST.stateid  inner join castemaster CM on CM.casteid=ADST.casteid   inner join dbo.ReligionMaster RGM on RGM.ReligionId=ADST.ReligionId  left outer join selectmastervaluedetails SV on SV.valueid=ADST.rwithapplicantid left outer join dbo.statemaster RS on RS.stateid=ADST.rstateid where ADST.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        SpecificUnsignedString = Utility.GetUnsignedStringFromCmd(Cmd);
        //    }
        //    else if (ServiceCode == (int)ServiceList.Domicile)
        //    {
        //        Qry = "select AD.placeofbirth,AD.yearofliving,AD.monthofliving,AD.otherstatedomicile,AD.whetherdocumentproof,AD.whethergazettedproof,AD.whetherfieldverification,'' as gazettedofficername,'' as designation,'' as departmentname,'' as officertelephoneno,'' as officergender,'' as officermobileno,'' as officeraddress,'' as statename,'' as districtname from drev.applicationdetailsdomicile AD left outer join statemaster sm on sm.stateid=AD.officerstateid left outer join districtmaster DM on DM.districtcode=AD.officerdistrictcode where AD.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        SpecificUnsignedString = Utility.GetUnsignedStringFromCmd(Cmd);
        //    }
        //    else if (ServiceCode == (int)ServiceList.Solvency)
        //    {
        //        Qry = "select applicationno ,  purposeofcertificate,  certificateamount,  '' as valuename,  '' as  whetherpvtltd,  '' as  nameoforganisation,  '' as  ohouseno,  '' as  ostreetno, '' as   osublocality,  '' as  localityname,  '' as  subdivdescription,  '' as  districtname,  '' as  statename,  '' as  countryname,  '' as  opincode, '' as   designation,  monthlyincome, '' as   panno, '' as   tanno, '' as   cstno from  drev.applicationdetailssolvency ADS  where ADS.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        string str1 = Utility.GetUnsignedStringFromCmd(Cmd);

        //        Qry = "select   VD.valuename,  landaddress,  landarea,  landvalue,  to_char(landpurchasedate,'DD/MM/YYYY') as landpurchasedate   from drev.solvencyassetsdetails FNM  inner join dbo.selectmastervaluedetails as VD on VD.ValueId=FNM.ValueId where FNM.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        string str2 = Utility.GetUnsignedStringFromCmd(Cmd);

        //        Qry = "select   VD.valuename,  accountno,  BM.bankname,  branchname,  fdamount,  to_char(fdmaturitydate,'DD/MM/YYYY') as fdmaturitydate,  noofshares,  sharevalue,  sharecertificateno,  sharecompanyname,  otheramount,  otherdetails from drev.solvencycurrentassetsdetails CA   inner join dbo.selectmastervaluedetails as VD on VD.ValueId=CA.ValueId   inner join dbo.bankmaster as BM on BM.BankCode=CA.BankCode where CA.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        string str3 = Utility.GetUnsignedStringFromCmd(Cmd);

        //        Qry = "select   directorname,  to_char(appointmentdate,'DD/MM/YYYY') as appointmentdate,  noofshares,  sharevalue,  panno   from drev.solvencyshareholdingdetails SH where SH.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        string str4 = Utility.GetUnsignedStringFromCmd(Cmd);


        //        if (string.IsNullOrEmpty(str1)) { SpecificUnsignedString = null; } else { SpecificUnsignedString = str1 + Environment.NewLine + str2 + Environment.NewLine + str3 + Environment.NewLine + str4; }
        //    }
        //    else if (ServiceCode == (int)ServiceList.Surviving)
        //    {
        //        Qry = "select   purposeofcertificate,  RM.RelationName,  deceasedname,  deceasedfathername,  deceasedgender,deceasedaddress,  deathcertificateno,  to_char(deathcertificatedate,'DD/MM/YYYY') as deathcertificatedate,  to_char(dateofdeath,'DD/MM/YYYY') as dateofdeath,  placeofdeath,  rationcardno,  to_char(issuedate,'DD/MM/YYYY') as issuedate from  drev.applicationdetailssurviving SM   inner join dbo.relationmaster as RM on RM.RelationId=SM.RelationId  where SM.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        string str1 = Utility.GetUnsignedStringFromCmd(Cmd);

        //        Qry = "select NameOfMember, Age,SMVD.valueName,'' as Photo  from drev.survivingmembersdetails SM  inner join dbo.SelectMasterValueDetails SMVD on SMVD.valueid=SM.RelationId  where SM.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        string str2 = Utility.GetUnsignedStringFromCmd(Cmd);

        //        if (string.IsNullOrEmpty(str1) || string.IsNullOrEmpty(str2)) { SpecificUnsignedString = null; } else { SpecificUnsignedString = str1 + Environment.NewLine + str2; }
        //    }
        //    else if (ServiceCode == (int)ServiceList.Marriage)
        //    {
        //        Qry = "select   dc1.documentname,dbo.udf_general_decrypt(haadhaarno) as haadhaarno,HName,  HFatherName,  HMotherName,  to_char(AMD.HDOB,'DD/MM/YYYY') as HDOB,  HMS.MaritalStatusName,  HNM.NationalityName,'' as   Hpmhousenumber, '' as  Hpmstreetnumber, '' as  Hpmsublocality,  '' as localityname, '' as hpmpincode,  '' as subdivdescription, '' as districtname, '' as statename,  '' as countryname,  Hpshousenumber,  Hpsstreetnumber,  Hpssublocality,  LM2.localityname, Hpspincode,  SD2.subdivdescription,  DM2.districtname,  SM2.statename,  CM2.countryname,'' as   HEmail,'' as   HMobile, HRM.ReligionName,dc2.documentname,dbo.udf_general_decrypt(waadhaarno) as waadhaarno,  WName,  WFatherName,  WMotherName, to_char(WDOB,'DD/MM/YYYY') as WDOB, WMS.MaritalStatusName,WNM.NationalityName,'' as Wpmhousenumber,'' as Wpmstreetnumber,'' as Wpmsublocality,'' as localityname,'' as Wpmpincode,'' as subdivdescription,'' as districtname,'' as statename,'' as countryname,Wpshousenumber,Wpsstreetnumber,Wpssublocality,LM4.localityname,Wpspincode,SD4.subdivdescription,DM4.districtname,SM4.statename,CM4.countryname,'' as WEmail,'' as WMobile,WRM.ReligionName,to_char(MarriageDate,'DD/MM/YYYY')as Marriagedate,MarriagePlace,MarriageReligion,MarriageReligiousPlace,LM5.localityname,SD5.subdivdescription,DM5.districtname,SM5.statename,CM5.countryname,ATM.AppointmentType, to_char(APM.AppointmentDate,'DD/MM/YYYY')as AppointmentDate,whetherreligiousmarriage,smv.valuename as marriageact from dgen.ApplicationMarriageDetails AMD left outer join dbo.localitymaster as LM1 on LM1.LocalityId=AMD.hpmlocalityid  left outer join dbo.subdivmaster as SD1 on SD1.SubDivCode=AMD.hpmsubdivcode left outer join dbo.districtmaster as DM1 on DM1.DistrictCode=AMD.hpmdistrictcode left outer join dbo.statemaster as SM1 on SM1.StateId=AMD.hpmstateid  left outer join dbo.countrymaster as CM1 on CM1.CountryId=AMD.hpmcountryid   left outer join dbo.localitymaster as LM2 on LM2.LocalityId=AMD.hpslocalityid  left outer join dbo.subdivmaster as SD2 on SD2.SubDivCode=AMD.hpssubdivcode left outer join dbo.districtmaster as DM2 on DM2.DistrictCode=AMD.hpsdistrictcode left outer join dbo.statemaster as SM2 on SM2.StateId=AMD.hpsstateid  left outer join dbo.countrymaster as CM2 on CM2.CountryId=AMD.hpscountryid   left outer join dbo.localitymaster as LM3 on LM3.LocalityId=AMD.wpmlocalityid  left outer join dbo.subdivmaster as SD3 on SD3.SubDivCode=AMD.wpmsubdivcode left outer join dbo.districtmaster as DM3 on DM3.DistrictCode=AMD.wpmdistrictcode left outer join dbo.statemaster as SM3 on SM3.StateId=AMD.wpmstateid  left outer join dbo.countrymaster as CM3 on CM3.CountryId=AMD.wpmcountryid   left outer join dbo.localitymaster as LM4 on LM4.LocalityId=AMD.wpslocalityid  left outer join dbo.subdivmaster as SD4 on SD4.SubDivCode=AMD.wpssubdivcode left outer join dbo.districtmaster as DM4 on DM4.DistrictCode=AMD.wpsdistrictcode left outer join dbo.statemaster as SM4 on SM4.StateId=AMD.wpsstateid  left outer join dbo.countrymaster as CM4 on CM4.CountryId=AMD.wpscountryid   left outer join dbo.localitymaster as LM5 on LM5.LocalityId=AMD.marriagelocalityid  left outer join dbo.subdivmaster as SD5 on SD5.SubDivCode=AMD.marriagesubdivcode left outer join dbo.districtmaster as DM5 on DM5.DistrictCode=AMD.marriagedistrictcode left outer join dbo.statemaster as SM5 on SM5.StateId=AMD.marriagestateid  left outer join dbo.countrymaster as CM5 on CM5.CountryId=AMD.marriagecountryid    left outer join dbo.AppointmentMaster APM on APM.AppointmentId=AMD.AppointmentId   left outer join dbo.AppointmentTypeMaster ATM on ATM.AppointmentTypeId=AMD.AppointmentTypeId    inner join dbo.NationalityMaster HNM on HNM.NationalityId=AMD.HNationalityId   inner join dbo.NationalityMaster WNM on WNM.NationalityId=AMD.WNationalityId     inner join dbo.MaritalStatusMaster HMS on HMS.MaritalStatusId=AMD.HMaritalStatusId   inner join dbo.MaritalStatusMaster WMS on WMS.MaritalStatusId=AMD.WMaritalStatusId inner join dbo.ReligionMaster HRM on HRM.ReligionId=AMD.HReligionId   inner join dbo.ReligionMaster WRM on WRM.ReligionId=AMD.WReligionId inner join selectmastervaluedetails smv on smv.valueid=AMD.marriageactid inner join documentmaster dc1 on dc1.documentid=AMD.hdocumentid inner join documentmaster dc2 on dc2.documentid=AMD.wdocumentid where AMD.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        string str1 = Utility.GetUnsignedStringFromCmd(Cmd);

        //        Qry = "select WitnessName,WitnessfatherName,Witnesshousenumber,Witnessstreetnumber,Witnesssublocality,LM.LocalityName as WitnesslocalityName,SD.SubDivDescription as Witnesssubdiv,DM.DistrictName as WitnessdistrictName,SM.StateName as WitnessstateName,CM.CountryName as WitnesscountryName,Witnesspincode, WIT.Witnessidentitytype,dbo.udf_general_decrypt(WitnessidentificationNo) as WitnessidentificationNo from dgen.MarriageWitnessMaster  MW inner join localitymaster LM on LM.LocalityId=MW.WitnesslocalityId inner join subdivmaster SD on SD.Subdivcode=MW.WitnessSubdivCode inner join DistrictMaster DM on DM.Districtcode=MW.WitnessDistrictCode inner join StateMaster SM on SM.StateId=MW.WitnessStateId inner join CountryMaster CM on CM.CountryId=MW.WitnessCountryId inner join WitnessIdentityTypeMaster WIT on WIT.WitnessIdentityTypeId=MW.WitnessIdentityTypeId where MW.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        string str2 = Utility.GetUnsignedStringFromCmd(Cmd);

        //        if (string.IsNullOrEmpty(str1) || string.IsNullOrEmpty(str2)) { SpecificUnsignedString = null; } else { SpecificUnsignedString = str1 + Environment.NewLine + str2; }
        //    }
        //    else if (ServiceCode == (int)ServiceList.Solemnization)
        //    {
        //        Qry = "select   dc1.documentname,dbo.udf_general_decrypt(haadhaarno) as haadhaarno,HName,  HFatherName,  HMotherName,  to_char(AMD.HDOB,'DD/MM/YYYY') as HDOB,  HMS.MaritalStatusName,  HNM.NationalityName,  Hpmhousenumber,  Hpmstreetnumber,  Hpmsublocality,  LM1.localityname, hpmpincode,  SD1.subdivdescription,  DM1.districtname,  SM1.statename,  CM1.countryname,  Hpshousenumber,  Hpsstreetnumber,  Hpssublocality,  LM2.localityname, Hpspincode,  SD2.subdivdescription,  DM2.districtname,  SM2.statename,  CM2.countryname,  HEmail,  HMobile, HRM.ReligionName,dc2.documentname,dbo.udf_general_decrypt(waadhaarno) as waadhaarno,  WName,  WFatherName,  WMotherName, to_char(WDOB,'DD/MM/YYYY') as WDOB, WMS.MaritalStatusName,WNM.NationalityName,Wpmhousenumber,Wpmstreetnumber,Wpmsublocality,LM3.localityname,Wpmpincode,SD3.subdivdescription,DM3.districtname,SM3.statename,CM3.countryname,Wpshousenumber,Wpsstreetnumber,Wpssublocality,LM4.localityname,Wpspincode,SD4.subdivdescription,DM4.districtname,SM4.statename,CM4.countryname,WEmail,WMobile,WRM.ReligionName,ATM.AppointmentType, to_char(APM.AppointmentDate,'DD/MM/YYYY')as AppointmentDate,AMD.MarriageActId,SMV.ValueName as MarriageAct from dgen.ApplicationMarriageSolemnizationDetails AMD left outer join dbo.localitymaster as LM1 on LM1.LocalityId=AMD.hpmlocalityid  left outer join dbo.subdivmaster as SD1 on SD1.SubDivCode=AMD.hpmsubdivcode left outer join dbo.districtmaster as DM1 on DM1.DistrictCode=AMD.hpmdistrictcode left outer join dbo.statemaster as SM1 on SM1.StateId=AMD.hpmstateid  left outer join dbo.countrymaster as CM1 on CM1.CountryId=AMD.hpmcountryid   left outer join dbo.localitymaster as LM2 on LM2.LocalityId=AMD.hpslocalityid  left outer join dbo.subdivmaster as SD2 on SD2.SubDivCode=AMD.hpssubdivcode left outer join dbo.districtmaster as DM2 on DM2.DistrictCode=AMD.hpsdistrictcode left outer join dbo.statemaster as SM2 on SM2.StateId=AMD.hpsstateid  left outer join dbo.countrymaster as CM2 on CM2.CountryId=AMD.hpscountryid   left outer join dbo.localitymaster as LM3 on LM3.LocalityId=AMD.wpmlocalityid  left outer join dbo.subdivmaster as SD3 on SD3.SubDivCode=AMD.wpmsubdivcode left outer join dbo.districtmaster as DM3 on DM3.DistrictCode=AMD.wpmdistrictcode left outer join dbo.statemaster as SM3 on SM3.StateId=AMD.wpmstateid  left outer join dbo.countrymaster as CM3 on CM3.CountryId=AMD.wpmcountryid   left outer join dbo.localitymaster as LM4 on LM4.LocalityId=AMD.wpslocalityid  left outer join dbo.subdivmaster as SD4 on SD4.SubDivCode=AMD.wpssubdivcode left outer join dbo.districtmaster as DM4 on DM4.DistrictCode=AMD.wpsdistrictcode left outer join dbo.statemaster as SM4 on SM4.StateId=AMD.wpsstateid  left outer join dbo.countrymaster as CM4 on CM4.CountryId=AMD.wpscountryid left outer join dbo.AppointmentMaster APM on APM.AppointmentId=AMD.AppointmentId   left outer join dbo.AppointmentTypeMaster ATM on ATM.AppointmentTypeId=AMD.AppointmentTypeId    inner join dbo.NationalityMaster HNM on HNM.NationalityId=AMD.HNationalityId   inner join dbo.NationalityMaster WNM on WNM.NationalityId=AMD.WNationalityId     inner join dbo.MaritalStatusMaster HMS on HMS.MaritalStatusId=AMD.HMaritalStatusId   inner join dbo.MaritalStatusMaster WMS on WMS.MaritalStatusId=AMD.WMaritalStatusId inner join dbo.ReligionMaster HRM on HRM.ReligionId=AMD.HReligionId   inner join dbo.ReligionMaster WRM on WRM.ReligionId=AMD.WReligionId inner join documentmaster dc1 on dc1.documentid=AMD.hdocumentid inner join documentmaster dc2 on dc2.documentid=AMD.wdocumentid inner join selectmastervaluedetails smv on smv.valueid=AMD.marriageactid where AMD.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        string str1 = Utility.GetUnsignedStringFromCmd(Cmd);

        //        Qry = "select WitnessName,WitnessfatherName,Witnesshousenumber,Witnessstreetnumber,Witnesssublocality,LM.LocalityName as WitnesslocalityName,SD.SubDivDescription as Witnesssubdiv,DM.DistrictName as WitnessdistrictName,SM.StateName as WitnessstateName,CM.CountryName as WitnesscountryName,Witnesspincode, WIT.Witnessidentitytype,dbo.udf_general_decrypt(WitnessidentificationNo) as WitnessidentificationNo from dgen.MarriageWitnessMaster  MW inner join localitymaster LM on LM.LocalityId=MW.WitnesslocalityId inner join subdivmaster SD on SD.Subdivcode=MW.WitnessSubdivCode inner join DistrictMaster DM on DM.Districtcode=MW.WitnessDistrictCode inner join StateMaster SM on SM.StateId=MW.WitnessStateId inner join CountryMaster CM on CM.CountryId=MW.WitnessCountryId inner join WitnessIdentityTypeMaster WIT on WIT.WitnessIdentityTypeId=MW.WitnessIdentityTypeId where MW.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        string str2 = Utility.GetUnsignedStringFromCmd(Cmd);

        //        if (string.IsNullOrEmpty(str1) || string.IsNullOrEmpty(str2)) { SpecificUnsignedString = null; } else { SpecificUnsignedString = str1 + Environment.NewLine + str2; }
        //    }
        //    else if (ServiceCode == (int)ServiceList.NT)
        //    {
        //        Qry = "select   SM.statename,  CM.castename,  RGM.religionname,  whethermigrated,  migrationstate,  migrationdistrict,  migrationvillage,  to_char(migrationdate,'DD/MM/YYYY') as migrationdate,  yearofliving,  monthofliving,  whetherrelationNT,  purposeofcertificate,  rname,  SV.valuename,  certificateno, RS.statename from  drev.applicationdetailsNT ADST  inner join dbo.statemaster SM on SM.stateid=ADST.stateid  inner join castemaster CM on CM.casteid=ADST.casteid   inner join dbo.ReligionMaster RGM on RGM.ReligionId=ADST.ReligionId  left outer join selectmastervaluedetails SV on SV.valueid=ADST.rwithapplicantid left outer join dbo.statemaster RS on RS.stateid=ADST.rstateid where ADST.ApplicationNo=@ApplicationNo";
        //        Cmd = new NpgsqlCommand(Qry);
        //        Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo.ToString());
        //        SpecificUnsignedString = Utility.GetUnsignedStringFromCmd(Cmd);
        //    }
        //    else
        //    {
        //        SpecificUnsignedString = AppNo.ToString();
        //    }


        //    if (SpecificUnsignedString.Equals(AppNo.ToString())) { return CommonUnsignedString; }
        //    return CommonUnsignedString + SpecificUnsignedString;
        //}

        /* method for getting the certificate data for digital signing
         * model will be used in view which are resides in signcontroller
         */
        public static SignModels GetModelForCertificateView(Int64 AppNo)
        {
            GetData data = new GetData();
            SignModels model = new SignModels();
            model.ApplicationNo = AppNo.ToString();
            model.ServiceCode = Utility.SelectColumnsValue("dbo.ApplicationDetails", "ServiceCode", "ApplicationNo", model.ApplicationNo.ToString())[0];

            string Qry = string.Empty;
            NpgsqlCommand Cmd = new NpgsqlCommand();

            if (model.ServiceCode == ((int)ServiceList.Marriage).ToString())
            {
                Qry = "select DM.DistrictName,SD.SubDivAddress ,SD.Subdivdescription,AD.ApplicationNo,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,(EXTRACT(DAY FROM (ApprovedDate))) as ApprovedDay,(EXTRACT(YEAR FROM (ApprovedDate))) as ApprovedYear,to_char(to_timestamp ((EXTRACT(MONTH FROM (ApprovedDate)))::text, 'MM'), 'TMMonth') as ApprovedMonth,MD.HName,MD.HFatherName,MD.HMotherName,dbo.displaycompleteaddressfromid(MD.Hpshousenumber,MD.Hpsstreetnumber,MD.Hpssublocality,MD.Hpslocalityid,MD.HpsSubDivCode,MD.Hpsdistrictcode,MD.Hpsstateid,MD.Hpscountryid,MD.Hpspincode) as HPresentAddress,to_char(MD.HDOB,'DD/MM/YYYY') as HDOB,MD.WName,MD.WFatherName,MD.WMotherName,dbo.displaycompleteaddressfromid(MD.Wpshousenumber,MD.Wpsstreetnumber,MD.Wpssublocality,MD.Wpslocalityid,MD.WpsSubDivCode,MD.Wpsdistrictcode,MD.Wpsstateid,MD.Wpscountryid,MD.Wpspincode) as WPresentAddress,to_char(MD.WDOB,'DD/MM/YYYY') as WDOB,to_char(MD.MarriageDate, 'DD/MM/YYYY') as MarriageDate,MD.MarriagePlace,DATE_PART('year', now()) - DATE_PART('year',HDob) as HAge,DATE_PART('year', now()) - DATE_PART('year',WDob) as WAge,SV.valuename as MarriageActId,MD.WhetherFooterRequired,to_char(RegistrationPerformDate,'DD/MM/YYYY') as RegistrationPerformDate from dbo.ApplicationDetails AD inner join dgen.ApplicationMarriageDetails MD on MD.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode inner join dbo.selectmastervaluedetails SV on SV.valueid=MD.MarriageActId where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                Qry = "select WitnessName,WitnessFatherName,dbo.displaycompleteaddressfromid(witnesshousenumber,witnessstreetnumber,witnesssublocality,witnesslocalityid,witnesssubdivcode,witnessdistrictcode,witnessstateid,witnesscountryid,witnesspincode) as WitnessAddress from dgen.MarriageWitnessMaster where ApplicationNo=@ApplicationNo order by WitnessId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.datab = data.GetDataTable(Cmd);

                model.ViewName = "PrintMarriageCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.Solemnization).ToString())
            {
                Qry = "select DM.DistrictName,SD.SubDivAddress ,SD.Subdivdescription,AD.ApplicationNo,MD.HName,MD.HFatherName,MD.HMotherName,dbo.displaycompleteaddressfromid(MD.Hpshousenumber,MD.Hpsstreetnumber,MD.Hpssublocality,MD.Hpslocalityid,MD.HpsSubDivCode,MD.Hpsdistrictcode,MD.Hpsstateid,MD.Hpscountryid,MD.Hpspincode) as HPresentAddress,to_char(MD.HDOB,'DD/MM/YYYY') as HDOB,MD.WName,MD.WFatherName,MD.WMotherName,dbo.displaycompleteaddressfromid(MD.Wpshousenumber,MD.Wpsstreetnumber,MD.Wpssublocality,MD.Wpslocalityid,MD.WpsSubDivCode,MD.Wpsdistrictcode,MD.Wpsstateid,MD.Wpscountryid,MD.Wpspincode) as WPresentAddress,to_char(MD.WDOB,'DD/MM/YYYY') as WDOB,DATE_PART('year', now()) - DATE_PART('year',HDob) as HAge,DATE_PART('year', now()) - DATE_PART('year',WDob) as WAge,MD.MarriageActId,now()::date as Today,to_char(to_timestamp ((DATE_PART('day',SolemnizationPerformDate::date))::text, 'DD'), 'DDth') as Day,to_char(to_timestamp ((DATE_PART('month',SolemnizationPerformDate::date))::text, 'MM'), 'Month') as Month,DATE_PART('year',SolemnizationPerformDate::date) as Year from dbo.ApplicationDetails AD inner join dgen.ApplicationMarriageSolemnizationDetails MD on MD.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                Qry = "select WitnessName,WitnessFatherName,dbo.displaycompleteaddressfromid(witnesshousenumber,witnessstreetnumber,witnesssublocality,witnesslocalityid,witnesssubdivcode,witnessdistrictcode,witnessstateid,witnesscountryid,witnesspincode) as WitnessAddress from dgen.MarriageWitnessMaster where ApplicationNo=@ApplicationNo order by WitnessId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.datab = data.GetDataTable(Cmd);

                model.ViewName = "PrintMarriageSolemnizationCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.Domicile).ToString())
            {
                Qry = "select AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription from dbo.ApplicationDetails AD inner join drev.ApplicationDetailsDomicile DD on DD.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                model.ViewName = "PrintDomicileCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.Nationality).ToString())
            {
                Qry = "select AD.ApplicationNo,AD.ApplicantName,AD.ApplicantFatherName,AD.ApplicantGender,to_char(AD.applicantdob,'DD/MM/YYYY')as applicantdob,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription from dbo.ApplicationDetails AD inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode inner join drev.ApplicationDetailsNationality ADN on ADN.ApplicationNo=AD.ApplicationNo where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                model.ViewName = "PrintNationalityCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.Solvency).ToString())
            {
                Qry = "select AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,ADS.CertificateAmount,SD.SubDivAddress,SD.SubDivDescription,DM.DistrictName from dbo.ApplicationDetails AD inner join drev.ApplicationDetailsSolvency ADS on ADS.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                Qry = "select AssetType,AssetValue from (select 'Fixed Deposits/Shares/Debentures/Others' as AssetType,sum(fdamount)+sum(sharevalue) as AssetValue from drev.solvencycurrentassetsdetails where applicationno=@ApplicationNo union select 'Agriculture Land/House/Vehicle/others' as AssetType,sum(landvalue::int) as AssetValue from drev.solvencyassetsdetails where applicationno=@ApplicationNo union select 'Income from Service/Business/Others' as AssetType,sum(sharevalue) as AssetValue from drev.solvencyshareholdingdetails where applicationno=@ApplicationNo) RS order by AssetType";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.datab = data.GetDataTable(Cmd);

                model.ViewName = "PrintSolvencyCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.Disability).ToString())
            {
                Qry = "select AD.ApplicationNo,AD.ApplicationStatusId,AD.ApplicantGender,to_char(AD.Applicantdob,'DD/MM/YYYY') as Applicantdob,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(), 'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,AD.ApplicantFatherName,AD.ApplicantMotherName, dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,DITM.DisabilityTypeName,OM.OccupationType,ADDIS.DisabilityPercentageId,DPercentageName,DM.DistrictName, SD.SubDivAddress,SD.SubDivDescription, AD.applicantmobileno,ADDis.bloodgroup,ADDis,qualification,ADDis.disabilitycertificateno,ADDis.medicalcertificate,ADDis.whetherregempexchange,ADDis.registrationno,to_char(ADDis.registrationdate, 'DD/MM/YYYY') as registrationdate, ADDis.identificationmarks,ADDis.disabilitytypeid,ADDis.disabilitypercentageid,ADDis.medicalcertificateissuedby,to_char(ADDis.dateofissue, 'DD/MM/YYYY') as dateofissue,DiTM.DisabilityTypeName,DPM.dpercentagename from dbo.ApplicationDetails AD inner join drev.ApplicationDetailsDisability ADDis on ADDis.ApplicationNo=AD.ApplicationNo left outer join dbo.OccupationMaster OM on OM.OccupationId=ADDis.OccupationId left outer join dbo.DisabilityTypeMaster DiTM on DiTM.DisabilityTypeId=ADDis.DisabilityTypeId left outer join DisabilityPercentageMaster DPM on DPM.DPercentageId=ADDis.DisabilityPercentageId  inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                model.ViewName = "PrintDisabilityCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.Birth).ToString())
            {
                Qry = "select AD.ApplicationNo,to_char(now(), 'DD/MM/YYYY') as ApprovedDate,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,  ADB.ChildName,ADB.FatherName,ADB.MotherName,ADB.Gender,to_char(ADB.DOB,'DD/MM/YYYY') as DOB,ADB.whetheradoptedchild,ADB.adoptername,ADB.adopterfathername, ADB.adopterspousename,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,dbo.displaycompleteaddressfromid(ADB.birthplacehouseno,ADB.birthplacestreetno,ADB.birthplacesublocality,ADB.localityid,ADB.subdivcode,ADB.districtcode,ADB.stateid,ADB.countryid,ADB.pincode) as BirthAddress,dbo.displaycompleteaddressfromid(ADB.phouseno,ADB.pstreetno,ADB.psublocality,ADB.plocalityid,ADB.pSubDivcode, ADB.pdistrictcode,ADB.pstateid,ADB.pcountryid,ADB.ppincode) as BirthAddressParent,dbo.displaycompleteaddressfromid(ADB.adopterhouseno,ADB.adopterstreetno,ADB.adpotersublocality,ADB.adopterlocalityid,ADB.adoptersubdivcode,ADB.adopterdistrictcode,ADB.adopterstateid,ADB.adoptercountryid,ADB.adopterpincode) as AdopterAddress,ADB.orphanagename,ADB.orphanageaddress, ADB.orphanageregistrationno,ADB.CaseNo,ADB.NameOfJudge,ADB.CourtDetails from dbo.ApplicationDetails AD inner join drev.ApplicationDetailsBirth ADB on ADB.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                model.ViewName = "PrintBirthCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.Death).ToString())
            {
                Qry = "select ADE.ApplicationNo,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,ADE.DeceasedName,ADE.DeceasedFatherName,ADE.DeceasedMotherName,ADE.deceasedspousename,ADE.DeceasedGender,to_char(ADE.DateOfDeath,'DD/MM/YYYY') as DateOfDeath,ADE.PlaceOfDeath,ADE.DeceasedPermanentAddress,dbo.displaycompleteaddressfromid(ADE.houseno,ADE.streetno,ADE.sublocality,ADE.LocalityId,ADE.subdivcode,ADE.districtcode,ADE.stateid,ADE.countryid,ADE.pincode) as AddressAtDeathTime from dbo.ApplicationDetails AD inner join drev.ApplicationDetailsDeath ADE on ADE.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                model.ViewName = "PrintDeathCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.Income).ToString())
            {
                Qry = @"select AD.ApplicationNo,AD.ApplicantName,AD.ApplicantFatherName,AD.applicanthusbandname,AD.ApplicantGender,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,DD.annualincome,PforCertificateId from dbo.ApplicationDetails AD inner join drev.ApplicationDetailsIncome DD on DD.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);
                model.AnnualIncomeInWords = Utility.ConvertNumbertoWords(Convert.ToInt32(model.dataa.Rows[0]["annualincome"]));

                model.ViewName = "PrintIncomeCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.SCST).ToString())
            {
                Qry = "select AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantFatherName,CM.CasteName,SM.StateName as CasteStateName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber, AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid, AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,SD.subdivdescription,SCST.whetherrelationscst,SCST.rname,RM.valuename as relationname,SCST.certificateno,to_char(SCST.rissuedate,'DD/MM/YYYY') as rissuedate,SCST.rissueaddress,ST.StateName as RStateName,RAddress from dbo.ApplicationDetails AD inner join drev.ApplicationDetailsSCST SCST on SCST.ApplicationNo=AD.ApplicationNo inner join castemaster CM on CM.casteid=SCST.casteid inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.statemaster SM on SM.stateid=SCST.stateid left outer join dbo.selectmastervaluedetails RM on RM.valueid=SCST.rwithapplicantid left outer join statemaster ST on ST.stateid=SCST.rstateid where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                model.ViewName = "PrintSCSTCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.ST).ToString())
            {
                Qry = "select AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantFatherName,CM.CasteName,SM.StateName as CasteStateName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber, AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid, AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,SD.subdivdescription,ST.whetherrelationst,ST.rname,RM.valuename as relationname,ST.certificateno,to_char(ST.rissuedate,'DD/MM/YYYY') as rissuedate,ST.rissueaddress,SR.StateName as RStateName,RAddress from dbo.ApplicationDetails AD  inner join drev.ApplicationDetailsST ST on ST.ApplicationNo=AD.ApplicationNo inner join castemaster CM on CM.casteid=ST.casteid inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.statemaster SM on SM.stateid=ST.stateid left outer join dbo.selectmastervaluedetails RM on RM.valueid=ST.rwithapplicantid left outer join statemaster SR on SR.stateid=ST.rstateid where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                model.ViewName = "PrintSTCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.NT).ToString())
            {
                Qry = "select AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantFatherName,CM.CasteName,SM.StateName as CasteStateName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber, AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid, AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,SD.subdivdescription,ST.whetherrelationNt,ST.rname,RM.valuename as relationname,ST.certificateno,to_char(ST.rissuedate,'DD/MM/YYYY') as rissuedate,ST.rissueaddress,SR.StateName as RStateName,RAddress from dbo.ApplicationDetails AD  inner join drev.ApplicationDetailsNT ST on ST.ApplicationNo=AD.ApplicationNo inner join castemaster CM on CM.casteid=ST.casteid inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.statemaster SM on SM.stateid=ST.stateid left outer join dbo.selectmastervaluedetails RM on RM.valueid=ST.rwithapplicantid left outer join statemaster SR on SR.stateid=ST.rstateid where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                model.ViewName = "PrintNTCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.OBC).ToString())
            {
                Qry = "select AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,OBC.WhetherCentreCaste,CM.casteName,case when OBC.WhetherCentreCaste=TRUE then CM.CResolutionNo else CM.ResolutionNo end as ResolutionNo,(case when OBC.WhetherCentreCaste=TRUE then CM.CResolutionDate else CM.ResolutionDate end) as ResolutionDate,SD.SubDivDescription,SD.SubDivAddress,DM.DistrictName,OBC.stateid as CasteStateId,SM.StateName as CasteStateName,OBC.whetherrelationobc,RM.Valuename as RelationName,OBC.certificateholdername,OBC.certificateno,to_char(OBC.obccertificateissuedate, 'DD/MM/YYYY') as obccertificateissuedate,OBC.issuingauthority,OBC.raddress,ST.StateName as RStateName from dbo.ApplicationDetails AD inner join drev.ApplicationDetailsOBC OBC on OBC.ApplicationNo=AD.ApplicationNo left outer join selectmastervaluedetails RM on Rm.valueid=OBC.certificateholderrelationid inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode inner join dbo.StateMaster SM on SM.StateId=OBC.StateId left outer join dbo.StateMaster ST on ST.StateId=OBC.rstateid inner join castemaster CM on CM.casteid=OBC.casteid and AD.servicecode=AD.servicecode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                model.ViewName = "PrintOBCCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.LalDora).ToString())
            {
                Qry = "select AD.ApplicationNo,AD.ApplicantName,AD.ApplicantGender,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress ,ADLD.TotalLandMeasurement,ADLD.LandSurroundedEast,ADLD.LandSurroundedWest,ADLD.LandSurroundedNorth,ADLD.LandSurroundedSouth,ADLD.khasrano,VillageName,SD.SubDivDescription,SD.SubDivAddress,DM.DistrictName from dbo.ApplicationDetails AD inner join drev.ApplicationDetailsLalDora ADLD on ADLD.ApplicationNo=AD.ApplicationNo inner join dbo.villagemaster VM on VM.villageid=ADLD.villageid inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                model.ViewName = "PrintLalDoraCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.Surviving).ToString())
            {
                Qry = "select AD.ApplicationNo,ADS.DeceasedName,ADS.DeceasedGender,ADS.DeceasedAddress,ADS.DeceasedFatherName,ADS.DeceasedHusbandName,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality, applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,to_char(ADS.DateOfDeath, 'DD/MM/YYYY') as DateOfDeath,ADS.deathcertificateno,SD.SubDivAddress,SD.SubDivDescription,DM.DistrictName from dbo.ApplicationDetails AD inner join drev.ApplicationDetailsSurviving ADS on ADS.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                Qry = "select SMD.MemberId,SMD.NameOfMember,SMD.Age,SMVD.ValueName as relationname from drev.survivingmembersdetails SMD inner join dbo.selectmastervaluedetails SMVD on SMVD.valueid=SMD.relationid where SMD.ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.datab = data.GetDataTable(Cmd);

                model.ViewName = "PrintSurvivingCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.NOC).ToString())
            {
                Qry = "select AD.ApplicationNo,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,AD.ApplicationStatusId,Nameoftransferer,Fnameoftransferer,Addressoftransferer,Nameoftransferee,Fnameoftransferee,Addressoftransferee,SMVD.ValueName as Docnature,Propertydescription,VM.VillageName,OF.SRName,OF.SRAddress,Transferertitle,Transferamount,Transfereepurpose from dgen.ApplicationDetailsNOC NOC inner join dbo.ApplicationDetails AD on AD.ApplicationNo=NOC.ApplicationNo inner join SelectMasterValueDetails SMVD on SMVD.ValueId=NOC.DocNature left outer join villagemaster VM on VM.VillageId=NOC.VillageId inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode  left outer join srofficemaster OF on OF.srcode=VM.officecode   where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.OBSPEN2);
                model.dataa = data.GetDataTable(Cmd);

                Qry = "select AQ.acquisitiontypeid,SV1.valuename as Acquisitiontype,AQ.acquisitionno,to_char(AQ.acquisitiondate,'DD/MM/YYYY') as acquisitiondate,case when Min=true then AQ.RectangleNo||'//'||AQ.KhasraNo||'min('||Bigha|| ' - ' ||Biswa|| ' - '||Biswansi||')' else AQ.RectangleNo||'//'||AQ.KhasraNo||'('||Bigha|| ' - ' ||Biswa|| ' - '||Biswansi||')' end as Area from dgen.nocacquisitiondetails AQ inner join selectmastervaluedetails SV1 on SV1.valueid=AQ.AcquisitiontypeId where AQ.ApplicationNo=@ApplicationNo order by AQ.RectangleNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.datab = data.GetDataTable(Cmd);

                Qry = "select V.ViolationId,VM.villagename,V.khasrano,V.rectangleno,SV1.valuename as act,SV2.valuename as land,SV3.valuename as section,to_char(V.vdate,'DD/MM/YYYY') as vdate,v.remarks,v.whetheractive from dgen.nocviolationdetails V inner join villagemaster VM on VM.villageid=V.VillageId inner join selectmastervaluedetails SV1 on SV1.valueid=V.violationactid inner join selectmastervaluedetails SV2 on SV2.valueid=V.landid inner join selectmastervaluedetails SV3 on SV3.valueid=V.sectionid where V.ApplicationNo=@ApplicationNo order by V.RectangleNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.datac = data.GetDataTable(Cmd);

                Qry = "select RectangleNo,KhasraNo from dgen.NOCApplicationAreaDetails where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.datad = data.GetDataTable(Cmd);

                Qry = "select case when Whethervsec81t=true then 'YES' else 'NO' end as Whethervsec81t,Whethervsec81remarkst,case when Whethervsec33t=true then 'YES' else 'NO' end as Whethervsec33t ,Whethervsec33remarkst,case when Whetherlfsec74t=true then 'YES' else 'NO' end as  Whetherlfsec74t,Whetherlfsec74remarkst,case when Whethervsec81t=true then 'YES' else 'NO' end as Whethervsec81t,Whethervsec81remarkst,case when Whethervsec33t=true then 'YES' else 'NO' end as Whethervsec33t ,Whethervsec33remarkst,case when Whetherlfsec74t=true then 'YES' else 'NO' end as  Whetherlfsec74t,Whetherlfsec74remarkst,case when Whetheranystayt=true then 'YES' else 'NO' end as Whetheranystayt ,Whetheranystayremarkst,case when Whetheranyobjt=true then 'YES' else 'NO' end as Whetheranyobjt ,Whetheranyobjremarkst,SV.valuename as ApplicableActName,SV1.valuename as ClassificationOfLandName,TEHObs,NTEHObs from dgen.nocapplicationremarks AD inner join selectmastervaluedetails SV on SV.valueid=AD.ApplicableAct inner join selectmastervaluedetails SV1 on SV1.valueid=AD.ClassificationOfLand where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.datae = data.GetDataTable(Cmd);

                model.ViewName = "PrintNOCCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.Handicapped).ToString())
            {
                Qry = "select AD.ApplicationNo,AD.ApplicantGender,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(), 'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,BM.BankName,ABD.BranchAddress,ABD.MICRCode,ABD.IFSCCode,ABD.AccountNo,SVD.valuename as AccountTypeName,SD.SubDivAddress,ADH.CategoryId,DoM.DocumentName,DTM.DocumentTypeName,SD.SubDivDescription,ServiceName from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsHandicapped ADH on ADH.ApplicationNo=AD.ApplicationNo  inner join ApplicantBankDetails ABD on ABD.ApplicationNo=ADH.ApplicationNo  inner join BankMaster BM on BM.BankCode=ABD.BankCode  left outer join selectmastervaluedetails SVD on SVD.valueid=ABD.AccountTypeId  inner join dbo.ApplicationEnclosureDetails AED on AED.ApplicationNo=AD.ApplicationNo  inner join dbo.DocumentMaster DoM on DoM.DocumentId=AED.DocumentId    inner join dbo.DocumentTypeMaster DTM on DTM.DocumentTypeId=AED.DocumentTypeId   inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode  inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode Inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                model.ViewName = "PrintHandicappedCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.OldAge).ToString())
            {
                Qry = "select AD.ApplicationNo,AD.ApplicantGender,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,ADO.CategoryId,SD.SubDivDescription,SVD.valuename as AccountTypeName,AB.AccountNo,BM.BankName,AB.MICRCode,AB.IFSCCode,AB.BranchAddress,DTM.DocumentTypeName,DCM.DocumentName,ServiceName from dbo.ApplicationDetails AD inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode inner join dgen.ApplicationDetailsOldAge ADO on ADO.ApplicationNo=AD.ApplicationNo inner join dbo.ApplicantBankDetails AB on AB.ApplicationNo=ADO.ApplicationNo left outer join selectmastervaluedetails SVD on SVD.valueid=AB.AccountTypeId inner join dbo.BankMaster BM on BM.BankCode=AB.BankCode inner join dbo.ApplicationEnclosureDetails AED on AED.ApplicationNo=AD.ApplicationNo inner join dbo.DocumentMaster DCM on DCM.DocumentId=AED.DocumentId inner join dbo.DocumentTypeMaster DTM on DTM.DocumentTypeId=AED.DocumentTypeId Inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                model.ViewName = "PrintOldAgeCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.DFBScheme).ToString())
            {
                Qry = "select AD.ApplicationNo,AD.ApplicantGender,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,ADO.BankAccNo as  AccountNo,BM.BankName,ADO.MICRCode,ADO.BranchAddress,DTM.DocumentTypeName,DCM.DocumentName,ServiceName from dbo.ApplicationDetails AD inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode inner join dgen.ApplicationDetailsDFBScheme ADO on ADO.ApplicationNo=AD.ApplicationNo inner join dbo.BankMaster BM on BM.BankCode=ADO.BankCode inner join dbo.ApplicationEnclosureDetails AED on AED.ApplicationNo=AD.ApplicationNo inner join dbo.DocumentMaster DCM on DCM.DocumentId=AED.DocumentId inner join dbo.DocumentTypeMaster DTM on DTM.DocumentTypeId=AED.DocumentTypeId Inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode  where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                model.ViewName = "PrintDFBSchemeCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.Ladli).ToString())
            {
                Qry = "select AD.ApplicationNo,AD.ApplicantGender,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(), 'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,DoM.DocumentName,DTM.DocumentTypeName,SD.SubDivDescription,ServiceName,SMVD.ValueName as BirthPlaceName,Addressofbirth,to_char(DobcertificateNo,'DD/MM/YYYY') as DobcertificateNo,ADL.Dobdept,SMVD2.ValueName as Dobdeptname,ADL.MlaconstituencyId,ACM.constituencyname,ADL.CategoryId,CM.categoryname as Category,ADL.AnnualIncome,ADL.Noofdaughters from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsLadli ADL on ADL.ApplicationNo=AD.ApplicationNo  inner join dbo.SelectMasterValueDetails SMVD on SMVD.valueid=ADL.BirthPlaceId inner join dbo.SelectMasterValueDetails SMVD2 on SMVD2.valueid=ADL.Dobdept inner join dbo.ApplicationEnclosureDetails AED on AED.ApplicationNo=AD.ApplicationNo  inner join dbo.DocumentMaster DoM on DoM.DocumentId=AED.DocumentId  inner join AssemblyConstituencyMaster ACM on ACM.constituencyid=ADL.MlaconstituencyId inner join categorymaster CM on CM.categoryid=ADL.categoryid  inner join dbo.DocumentTypeMaster DTM on DTM.DocumentTypeId=AED.DocumentTypeId   inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode  inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode Inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode   where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                model.ViewName = "PrintLadliCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.Widow).ToString())
            {
                Qry = "select AD.ApplicationNo,AD.ApplicantGender,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(), 'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,BM.BankName,ABD.BranchAddress,ABD.MICRCode,ABD.IFSCCode,ABD.AccountNo,SVD.valuename as AccountTypeName,SD.SubDivAddress,ADH.CategoryId,DoM.DocumentName,DTM.DocumentTypeName,SD.SubDivDescription,ServiceName from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsWidow ADH on ADH.ApplicationNo=AD.ApplicationNo  inner join ApplicantBankDetails ABD on ABD.ApplicationNo=ADH.ApplicationNo  inner join BankMaster BM on BM.BankCode=ABD.BankCode  left outer join selectmastervaluedetails SVD on SVD.valueid=ABD.AccountTypeId  inner join dbo.ApplicationEnclosureDetails AED on AED.ApplicationNo=AD.ApplicationNo  inner join dbo.DocumentMaster DoM on DoM.DocumentId=AED.DocumentId    inner join dbo.DocumentTypeMaster DTM on DTM.DocumentTypeId=AED.DocumentTypeId   inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode  inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode Inner join ServiceMaster SM on SM.ServiceCode=AD.ServiceCode  where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                model.ViewName = "PrintWidowCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.BOCW).ToString())
            {
                Qry = "select BCW.Nameofest,BCW.NameofestCarrying,BCW.Addressofest,BCW.AddressofestPostal,BCW.AddressofestLocal,BCW.fullnameofest,to_char(now(),'DD/MM/YYYY') as today,to_char(BCW.completiondate,'DD/MM/YYYY') as completiondate,to_char(BCW.commencementdate,'DD/MM/YYYY') as commencementdate,BCW.maxworkers,BCW.addressofest,BCW.nameofest,BCW.locationofest,case when BCW.natureofbuilding=@Other then BCW.natureofbuildingdetails else SV.valuename end as natureofbuilding,AD.ApplicationNo,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription from dbo.ApplicationDetails AD inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode inner join dgen.ApplicationDetailsBOCWAct BCW on BCW.ApplicationNo=AD.ApplicationNo inner join selectmastervaluedetails SV on SV.valueid=BCW.natureofbuilding where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                Cmd.Parameters.AddWithValue("@Other", (int)NatureOfEstLbr.Other);
                model.dataa = data.GetDataTable(Cmd);

                model.ViewName = "PrintBOCWCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.ContractLabour).ToString())
            {
                Qry = "select CL.Addressofest,CL.Fullnameofpe,CL.LocalAddressofest,LM.localityname,CL.nameofest,CL.locationofest,case when CL.natureofest=@Other then CL.natureofestdetails else SV.valuename end as natureofest,AD.ApplicationNo,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription from dbo.ApplicationDetails AD inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode inner join dgen.ApplicationDetailsCLAct CL on CL.ApplicationNo=AD.ApplicationNo inner join selectmastervaluedetails SV on SV.valueid=CL.natureofest inner join localitymaster LM on LM.localityid=CL.Applocalityid where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                Cmd.Parameters.AddWithValue("@Other", (int)NatureOfEstLbr.Other);
                model.dataa = data.GetDataTable(Cmd);

                Qry = "select CO.ContractorName,CO.Contractoraddress,CO.Natureofwork,CO.Maxworkers,to_char(CO.EstDate,'DD/MM/YYYY') as EstDate,to_char(CO.StartDate,'DD/MM/YYYY') as StartDate from dgen.CLActContractorDetails CO inner join ApplicationDetails AD on AD.ApplicationNo=CO.ApplicationNo  where CO.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.datab = data.GetDataTable(Cmd);

                model.ViewName = "PrintCLActCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.Contractors).ToString())
            {
                Qry = "select CO.LocalAddressofcontractor,CO.nameofcontractor,CO.nameofestcontractor,LM.LocalityName,CO.addressofcontractor,CO.natureofwork,CO.pestname,CO.pestaddress,CO.maxworkers,AD.ApplicationNo,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription from dbo.ApplicationDetails AD inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode inner join dgen.ApplicationDetailsContractor CO on CO.ApplicationNo=AD.ApplicationNo inner join localitymaster LM on LM.localityid=CO.AppLocalityId where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                model.ViewName = "PrintContractorCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.RenewalOfContractor).ToString())
            {
                Qry = "select CO.OldCertificateNo,CO.Localaddressofcon,CO.nameofcon,CO.addressofcon,CO.natureofwork,CO.pestname,CO.pestaddress,CO.maxworkers,CO.IncreasedWorker,CO.whetherextensionrequired,to_char(CO.extensiondate,'DD/MM/YYYY') as extensiondate,CO.whetherchangesrequired,CO.whetherexist,AD.ApplicationNo,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,to_char(CO.OldCertificateDate,'DD/MM/YYYY') as OldCertificateDate,AD.ApplicantName,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,CO.WhetherChangeRequired,CO.Whetherworkerincreased,CO.Newnamecontest,CO.Newnamecontest,CO.WhetherApplAmend,CO.WhetherApplRenewal from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsRenewalContractor CO on CO.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);
                if (model.dataa.Rows[0]["WhetherWorkerIncreased"].ToString().ToUpper() == CustomText.TRUE.ToString())
                {
                    Int32 ProposedW = 0;
                    Int32 ExistingW = Convert.ToInt32(Utility.SelectColumnsValue("dgen.ApplicationDetailsRenewalContractor", "maxworkers", "ApplicationNo", model.ApplicationNo)[0]);
                    ProposedW = Convert.ToInt32(model.dataa.Rows[0]["IncreasedWorker"]);//
                    model.dataa.Columns.Add("Existing", typeof(System.Int32));
                    model.dataa.Columns.Add("Increased", typeof(System.Int32));
                    model.dataa.Rows[0]["Existing"] = ExistingW.ToString();
                    model.dataa.Rows[0]["Increased"] = (ProposedW - ExistingW).ToString();
                }
                model.ViewName = "PrintRenewalContractorCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.InstallationOfLift).ToString())
            {
                Qry = "select @Fee as Fee,UM.Username,ADC.ApplicationNo,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,ADC.nameofowner,ADC.LiftLocation,ADC.addrofowner,ADC.premises,ADC.maxpassenger,AD.ServiceCode from dgen.applicationdetailsinstallationoflift ADC inner join dbo.ApplicationDetails AD on ADC.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode inner join usermaster UM on UM.userid=@UserId  where  ADC.ApplicationNo=@ApplicationNo  and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                Cmd.Parameters.AddWithValue("@UserId", Sessions.getEmployeeUser().UserId);
                Cmd.Parameters.AddWithValue("@Fee", Utility.GetConditionalFee(model.ApplicationNo.ToString(), DB.LS.ToString()) - 20);
                model.dataa = data.GetDataTable(Cmd);
                model.ViewName = "PrintInstallationOfLiftCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.GrantOfPassengerLift).ToString())
            {
                Qry = "select ADC.ApplicationNo,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,ADC.nameofowner,ADC.addrofowner,ADC.premises,ADC.LiftLocation,ADC.ApprovalLetterNo,AD.ServiceCode from dgen.applicationdetailsgrantofpassengerlift ADC inner join dbo.ApplicationDetails AD on ADC.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode  where  ADC.ApplicationNo=@ApplicationNo  and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

             
                model.ViewName = "PrintGrantOfPassengerLiftCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.RenewalOfPassengerLift).ToString())
            {
                //Qry = "select ADC.ApplicationNo,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,ADC.nameofowner,ADC.addrofowner,ADC.premises,ADC.LiftLocation,ADC.LicenseNo,AD.ServiceCode from dgen.applicationdetailsrenewalofpassengerlift ADC inner join dbo.ApplicationDetails AD on ADC.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode  where  ADC.ApplicationNo=@ApplicationNo  and AD.ApplicationStatusId=@StatusId";
                Qry = "select ADC.ApplicationNo,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,ADC.nameofowner, case when whetherchangesrequired=true then proposedaddrofowner else addrofowner end as addrofowner,ADC.premises,ADC.LiftLocation,ADC.LicenseNo,AD.ServiceCode from dgen.applicationdetailsrenewalofpassengerlift ADC inner join dbo.ApplicationDetails AD on ADC.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode  where  ADC.ApplicationNo=@ApplicationNo  and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                //Qry = "select um.username as inpectionuser,to_char(lim.inspectedon,'DD/MM/YYYY') as inspectedon  from dgen.lbrliftinspectionmaster lim  inner join usermaster  um on lim.inspectedby=um.uid  inner join applicationdetails ad on lim.applicationno=ad.applicationno where ad.applicationno=@ApplicationNo and AD.ApplicationStatusId=@StatusId order by lim.inspectionid desc limit 1";
                Qry = "select um.username as inpectionuser,lid.columnvalue as inspectedon from dgen.lbrliftinspectionmaster lim  inner join usermaster  um on lim.inspectedby=um.uid  inner join applicationdetails ad on lim.applicationno=ad.applicationno inner join dgen.lbrliftinspectiondetails lid on lid.inspectionid=lim.inspectionid where ad.applicationno=@ApplicationNo and AD.ApplicationStatusId=@StatusId and lid.columnid=@InspectionDateId and lim.whetheractive=@whetheractive order by lim.inspectionid desc limit 1";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                Cmd.Parameters.AddWithValue("@InspectionDateId", (int)InspectionColumnId.PerodicalInspectionDate);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                model.datab = data.GetDataTable(Cmd);

                model.ViewName = "PrintRenewalOfPassengerLiftCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.CEA1).ToString())
            {
                Qry = "select CEA1.ApplicationNo,AD.ApplicationStatusId,CEA1.Nameofins,CEA1.addofins,CEA1.Detailsofins,CEA1.Localityofins,CEA1.Nameofowner,CEA1.Addrofowner,CEA1.Mobilenoofowner,CEA1.Emailofowner,CEA1.Nameofconcerned,CEA1.Addrofconcerned,CEA1.Mobilenoofconcerned,CEA1.Emailofconcerned,CEA1.Faultlevelofins,CEA1.Interruptingcap,CEA1.Mingrndclearance,CEA1.Whetherrpcomplied,CEA1.Whethercompleted,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,AD.ServiceCode from dgen.ApplicationDetailsCEA1 CEA1 inner join dbo.ApplicationDetails AD on CEA1.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode  where CEA1.ApplicationNo=@ApplicationNo  and AD.ApplicationStatusId=@StatusId";//changes1005
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                Qry = "select TR.tdid,TR.Sno,TR.Capacity,TR.Privoltage,TR.Secvoltage,TR.Remarks,TR.TransformerTypeId,TR.Make,SMV.ValueName as TransformerName from dgen.lbrceaTransformerdetails TR inner join dbo.selectmastervaluedetails SMV on SMV.Valueid=TR.TransformerTypeId where TR.ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                model.datab = data.GetDataTable(Cmd);

                Qry = "select  CB.cdid,CB.Specification,CB.Voltage,CB.Length,CB.Route,CB.Noofcable,CB.Remarks from dgen.lbrceacabledetails CB where CB.ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                model.datac = data.GetDataTable(Cmd);

                Qry = "select BR.bdid,BR.Sno,BR.Voltage,BR.Currentamp,BR.Make,BR.Remarks from dgen.lbrceaBreakerdetails BR where BR.ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                model.datad = data.GetDataTable(Cmd);

                Qry = "select SMV.ValueName as AppratustypeName,OT.appratustypeid,OT.OtId,OT.SNo,OT.Capacity,OT.Voltage,OT.Currentamp,OT.Make,OT.Specification,OT.Remarks from dgen.lbrceaotherdetails OT inner join dbo.selectmastervaluedetails SMV on SMV.Valueid=OT.Appratustypeid where OT.ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                model.datae = data.GetDataTable(Cmd);

                model.ViewName = "PrintCEA1Certificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.CEA2).ToString())
            {
                Qry = "select AD.ApplicationNo,AD.ApplicationStatusId,CEA2.Nameofohline,CEA2.Locationofohline,CEA2.Localityofins,CEA2.Nameofowner,CEA2.AddrofOwner,LM.LocalityName,CEA2.Nameofconcerned,CEA2.Addrofconcerned,CEA2.Mobilenoofconcerned,CEA2.Emailofconcerned,CEA2.Whetherinscompleted,to_char(CEA2.DateofInspection,'DD/MM/YYYY') as DateofInspection,to_char(CEA2.TargetDate,'DD/MM/YYYY') as TargetDate,to_char(CEA2.ProbDateofInsp,'DD/MM/YYYY') as ProbDateofInsp,CEA2.Feedeposit,CEA2.Singleciruit,CEA2.Doubleciruit,CEA2.Totalroutelen,CEA2.Conductor,CEA2.Groundwire,CEA2.Average,CEA2.Minimum,CEA2.Maximum,CEA2.NormalSpan,CEA2.Nhighway,CEA2.Shighway,CEA2.Otherroad,CEA2.Pl800kv,CEA2.Pl400kv,CEA2.Pl220kv,CEA2.Pl132kv,CEA2.Pl66kv,CEA2.Pl33kv,CEA2.Pl11kv,CEA2.Ltlines,CEA2.Railwaycrossing,CEA2.Rivercrossing,CEA2.Specialcrossing,CEA2.Factofsafety,CEA2.Whetherduly,CEA2.Toweracd,CEA2.Dangernb,CEA2.Lightningfaults,CEA2.Groundfaults,CEA2.Snappedconductors,CEA2.Otherprotection,CEA2.Volregulation,CEA2.Whetherceaprov,CEA2.Whetherinspsubstation,CEA2.Maxheightoftower,CEA2.Neardistofline,CEA2.Nameofsubstation,CEA2.BayNo,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,AD.ServiceCode  from dgen.applicationdetailscea2 CEA2 inner join dbo.applicationdetails AD on AD.ApplicationNo=@ApplicationNo inner join localitymaster LM on LM.localityid=CEA2.Localityofins inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode  where CEA2.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);
                model.ViewName = "PrintCEA2Certificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.CEA3).ToString())
            {
                Qry = "select AD.ApplicationNo,AD.ApplicationStatusId,CEA3.Nameofinstall,CEA3.NameofIns,CEA3.WhetherPertainEI,CEA3.Localityofins,CEA3.Nameofowner,CEA3.Addrofowner,CEA3.Nameofconcerned,CEA3.Addrofconcerned,CEA3.Mobilenoofconcerned,CEA3.Emailofconcerned,CEA3.Whetherrelprovcea,CEA3.Whetherappliedforown,to_char(CEA3.Dateofreceiptofinsp,'DD/MM/YYYY') as DateofReceiptofInsp,to_char(CEA3.Dateofreg43,'DD/MM/YYYY') as DateofReg43,to_char(CEA3.Dateofreg30,'DD/MM/YYYY') as DateofReg30,CEA3.Feedeposit,CEA3.Whetherobslastinsp,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,AD.ServiceCode from dgen.ApplicationDetailsCEA3 CEA3 inner join dbo.ApplicationDetails AD on CEA3.ApplicationNo=AD.ApplicationNo inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode inner join localitymaster LM on LM.localityid=CEA3.Localityofins where CEA3.ApplicationNo=@ApplicationNo  and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);
                model.ViewName = "PrintCEA3Certificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.ConstructionWorker).ToString())
            {
                Qry = "SELECT row_number() over (ORDER BY ad.applicationno) as Sno,foragencycode,to_char(now(),'DD/MM/YYYY') as registrationdate,to_char(now() + interval '1 year','DD/MM/YYYY') as renewaldate,ADCW.applicationNo, Ad.applicantname,Ad.applicantpermanentaddress,AD.applicantfathername,ad.applicantmothername,ad.applicanthusbandname  ,    dbo.displaycompleteaddressfromid(ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,ad.ApplicantLocalityId,ad.ApplicantSubDivCode,ad.ApplicantDistrictCode,ad.StateId,ad.CountryId,ApplicantPinCode) as ApplicantAddress, case when applicantgender='F' then 'Female' else 'Male' end as gender, to_char(ad.applicantdob,'DD/MM/YYYY') as applicantdob ,SMVD.valuename as whetherscstobc, SMVD1.valuename as  MaritalStatus, to_char(ADCW.dateofretirement,'DD/MM/YYYY') as dateofretirement , ADCW.nameofworkplace, ADCW.addressofworkplace,lm.localityname as localityworkplace, ADCW.esino, ADCW.pfno, ADCW.nameofemployeer, ADCW.addressofemployeer, ADCW.serviceperiodmonth, ADCW.serviceperiodyear, ADCW.presentworkpost, ADCW.detailsofboardmembership, BM.bankname as bankcode, ADCW.branchaddress as BankBranchName, ADCW.accountholdername, ADCW.accountno, ADCW.ifsccode, ADCW.micrcode,CASE WHEN WHETHERREGISTERWORKER=FALSE AND WHETHERUPLOADVOLUNTEERDATA=FALSE THEN to_char(NOW(),'DD/MM/YYYY')  WHEN WHETHERREGISTERWORKER=TRUE AND WHETHERUPLOADVOLUNTEERDATA=FALSE THEN  to_char(REGISTRATIONDATE,'DD/MM/YYYY')  WHEN WHETHERREGISTERWORKER=TRUE AND WHETHERUPLOADVOLUNTEERDATA=TRUE THEN to_char(REGISTRATIONDATE,'DD/MM/YYYY')  END AS REGDATE, CASE WHEN WHETHERREGISTERWORKER=FALSE AND WHETHERUPLOADVOLUNTEERDATA=FALSE THEN to_char(NOW(),'DD/MM/YYYY')  WHEN WHETHERREGISTERWORKER=TRUE AND WHETHERUPLOADVOLUNTEERDATA=FALSE THEN to_char(NOW(),'DD/MM/YYYY')  WHEN WHETHERREGISTERWORKER=TRUE AND WHETHERUPLOADVOLUNTEERDATA=TRUE THEN to_char(LASTRENEWALDATE,'DD/MM/YYYY')  END AS RENEWALDATE,CASE WHEN WHETHERREGISTERWORKER=FALSE AND WHETHERUPLOADVOLUNTEERDATA=FALSE THEN TO_CHAR(NOW() + INTERVAL ' 1 YEAR','DD/MM/YYYY')  WHEN WHETHERREGISTERWORKER=TRUE AND WHETHERUPLOADVOLUNTEERDATA=FALSE THEN TO_CHAR(LASTEXPREGISTRATION + INTERVAL  '1 YEAR','DD/MM/YYYY')WHEN WHETHERREGISTERWORKER=TRUE AND WHETHERUPLOADVOLUNTEERDATA=TRUE THEN TO_CHAR(LASTEXPREGISTRATION,'DD/MM/YYYY') END AS EXPIRYDATE  FROM dgen.applicationdetailsregconstructionworker ADCW inner join selectmastervaluedetails SMVD on SMVD.valueid=ADCW.whetherscstobc::int inner join selectmastervaluedetails SMVD1 on SMVD1.valueid=ADCW.maritalstatusid  inner join  localitymaster lm on lm.localityid=ADCW.localityworkplace inner join bankmaster bm on bm.bankcode=ADCW.bankcode inner join dbo.applicationdetails AD on ADCW.ApplicationNo=AD.ApplicationNo  where ADCW.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                Qry = "select to_char(regdate,'DD/MM/YYYY') as regdate,to_char(renewaldate,'DD/MM/YYYY') as renewaldate,to_char(expirydate,'DD/MM/YYYY') as expirydate,((now()::date-regdate::date)/365)::text as membershipperiod from applicationdetailsregvalidity  where applicationno=@applicationno";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.datab = data.GetDataTable(Cmd);

                Qry = "select stm.servicefeetype,paymentamount from applicationpaymentrequest apr inner join  applicationpaymentdescription apd on apr.paymentid=apd.paymentid  inner join servicefeetypemaster stm on stm.servicefeetypeid=apd.paymenttypeid where applicationno=@applicationno";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.datac = data.GetDataTable(Cmd);

                model.ViewName = "PrintRegConsWorkerCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.RenewalConsWorker).ToString())
            {
                Int64 latefees = 0;
                string registrationno = string.Empty, renewaldate = string.Empty;
                Qry = "select registrationno,latefees,renewaldate from dgen.applicationdetailsrenewalconsworker where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.dataf = data.GetDataTable(Cmd);
                if (model.dataf.Rows.Count > 0)
                {
                    registrationno = model.dataf.Rows[0]["registrationno"].ToString();
                    latefees = Convert.ToInt64(model.dataf.Rows[0]["latefees"].ToString());
                    renewaldate = model.dataf.Rows[0]["renewaldate"].ToString();

                    Qry = "SELECT row_number() over (ORDER BY ad.applicationno) as Sno,foragencycode,to_char(Ad.approveddate,'DD/MM/YYYY') as registrationdate,to_char(date (Ad.approveddate + interval '1 year'),'DD/MM/YYYY') as renewaldate,ADCW.applicationNo, Ad.applicantname,Ad.applicantpermanentaddress,AD.applicantfathername,ad.applicantmothername,ad.applicanthusbandname  ,    dbo.displaycompleteaddressfromid(ApplicantHouseNumber,ApplicantStreetNumber,ApplicantSubLocality,ad.ApplicantLocalityId,ad.ApplicantSubDivCode,ad.ApplicantDistrictCode,ad.StateId,ad.CountryId,ApplicantPinCode) as ApplicantAddress, case when applicantgender='F' then 'Female' else 'Male' end as gender, to_char(ad.applicantdob,'DD/MM/YYYY') as applicantdob ,SMVD.valuename as whetherscstobc, SMVD1.valuename as  MaritalStatus, to_char(ADCW.dateofretirement,'DD/MM/YYYY') as dateofretirement , ADCW.nameofworkplace, ADCW.addressofworkplace,lm.localityname as localityworkplace, ADCW.esino, ADCW.pfno, ADCW.nameofemployeer, ADCW.addressofemployeer, ADCW.serviceperiodmonth, ADCW.serviceperiodyear, ADCW.presentworkpost, ADCW.detailsofboardmembership, BM.bankname as bankcode, ADCW.branchaddress as BankBranchName, ADCW.accountholdername, ADCW.accountno, ADCW.ifsccode, ADCW.micrcode FROM dgen.applicationdetailsregconstructionworker ADCW inner join selectmastervaluedetails SMVD on SMVD.valueid=ADCW.whetherscstobc::int inner join selectmastervaluedetails SMVD1 on SMVD1.valueid=ADCW.maritalstatusid  inner join  localitymaster lm on lm.localityid=ADCW.localityworkplace inner join bankmaster bm on bm.bankcode=ADCW.bankcode inner join dbo.applicationdetails AD on ADCW.ApplicationNo=AD.ApplicationNo  where ADCW.ApplicationNo=@ApplicationNo";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", registrationno);
                    model.dataa = data.GetDataTable(Cmd);

                    //Qry = "select applicationno,to_char(regdate,'DD/MM/YYYY') as regdate,to_char(renewaldate,'DD/MM/YYYY') as renewaldate,to_char(expirydate,'DD/MM/YYYY') as expirydate,((now()::date-regdate::date)/365)::text as membershipperiod,((now()::date-regdate::date)/365)::int * @annualcharges as totalsubscriptionamount  from applicationdetailsregvalidity  where applicationno=@applicationno";
                    Qry = "select applicationno,to_char(regdate,'DD/MM/YYYY') as regdate,to_char(now(),'DD/MM/YYYY') as renewaldate,to_char((expirydate + interval '1 year'),'DD/MM/YYYY') as expirydate,((now()::date-regdate::date)/365)::text as membershipperiod,((now()::date-regdate::date)/365)::int * @annualcharges as totalsubscriptionamount  from applicationdetailsregvalidity  where applicationno=@applicationno";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", registrationno);
                    Cmd.Parameters.AddWithValue("@annualcharges", (int)ServiceFee.CWAnnualFees);
                    model.datab = data.GetDataTable(Cmd);

                    Qry = "select stm.servicefeetype,paymentamount from applicationpaymentrequest apr inner join  applicationpaymentdescription apd on apr.paymentid=apd.paymentid  inner join servicefeetypemaster stm on stm.servicefeetypeid=apd.paymenttypeid where applicationno=@applicationno";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                    model.datac = data.GetDataTable(Cmd);

                    Qry = "select ((count(applicationno)+1)*@annualcharges) as totalsubscriptionamount from dgen.applicationdetailsrenewalconsworker where registrationno=@registrationno";
                    Cmd = new NpgsqlCommand(Qry);
                    Cmd.Parameters.AddWithValue("@registrationno", registrationno);
                    Cmd.Parameters.AddWithValue("@annualcharges", (int)ServiceFee.CWAnnualFees);
                    model.datad = data.GetDataTable(Cmd);
                }
                model.ViewName = "PrintRenewalConsWorkerCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.FirmRegistration).ToString())
            {
                Qry = "select AD.ApplicationNo,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription , firmname,otherbusiness, dbo.displaycompleteaddressfromid(ADF.houseno,ADF.streetno,ADF.sublocality,ADF.localityid,ADF.subdivcode,ADF.districtcode,ADF.stateid,ADF.countryid,ADF.pincode) FirmAddredd from dbo.ApplicationDetails AD inner join dgen.applicationdetailsfirm ADF on ADF.ApplicationNo=AD.ApplicationNO  inner join dbo.subdivmaster SD on SD.subdivcode=AD.ApplicationSubDivCode  inner join dbo.districtmaster DM on DM.districtcode=AD.ApplicationDistrictCode where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                Qry = "select PartnerName,PartnerAddress,to_char(FirmjoiningDate,'DD/MM/YYYY')as FirmjoiningDate from dgen.firmpartnerdetails   where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.datab = data.GetDataTable(Cmd);

                Qry = "select count(partnerid)  as totalpartner from dgen.firmpartnerdetails   where ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.datac = data.GetDataTable(Cmd);

                model.ViewName = "PrintFirmCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.SocietyRegistration).ToString())
            {
                Qry = "select ADS.ApplicationNo,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SDM.SubDivAddress,SDM.SubDivDescription , SocietyName,ApplicantDesignation,OtherplaceofSociety,dbo.displaycompleteaddressfromid(HouseNo,StreetNo,SubLocality,ADs.LocalityId,ADS.SubDivCode,ADS.DistrictCode,ADS.StateId,ADS.CountryId,ADS.PinCode) as SocietyAddress ,ContactnoofSociety,SocietyTypeId,SMVD1.ValueName as SocietyTypeName,OperationAreaId,SMVD2.ValueName as OperationAreaName,ElectiontenureId from dgen.applicationdetailssociety ADS inner join dbo.ApplicationDetails AD on ADS.ApplicationNo=AD.ApplicationNo  inner join LocalityMaster LM on LM.LocalityId=ADS.LocalityId inner join subdivmaster SDM on SDM.subdivcode=ADS.subdivcode inner join districtmaster DM on DM.districtcode=ADS.districtcode inner join statemaster SM on SM.stateid=ADS.stateid inner join countrymaster CM on CM.countryid=ADS.countryid inner join dbo.SelectMasterValueDetails SMVD1 on SMVD1.valueid=ADS.SocietyTypeId inner join dbo.SelectMasterValueDetails SMVD2 on SMVD2.valueid=ADS.OperationAreaId where ADS.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);
                model.ViewName = "PrintSocietyCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.ProvisionalCinema).ToString())
            {
                Qry = "select ADC.ApplicationNo,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,ADC.CinemaOwner,ADC.CinemaOwnerAddress,ADC.FatherName,ADC.CinemaName,ADC.CinemaAddress,LM.LocalityName as CinemaLocalityName,ADC.CinemaLocalityId,OM.OccupationType as PresentOccupationName,ADC.PresentOccupation,SVM.ValueName as EducationalQualificationName,ADC.EducationalQualification,ADC.FinancialPosition,ADC.WhetherConvicted,ADC.ConvictedDetails,ADC.PanNo,ADC.NationalityId,NM.NationalityName,ADC.YearOfConstruction,ADC.NoOfScreens,ADC.YearsLicenseNeeded,to_char(ADC.ProLicenseDate,'DD/MM/YYYY') as ProLicenseDate,ADC.ProLicenseNo,AD.ServiceCode from dgen.applicationdetailscinematograph ADC inner join dbo.ApplicationDetails AD on ADC.ApplicationNo=AD.ApplicationNo  inner join NationalityMaster NM on NM.NationalityId=ADC.NationalityId  inner join LocalityMaster LM on LM.LocalityId=ADC.CinemaLocalityId  inner join occupationmaster OM on OM.occupationid=ADC.presentoccupation  inner join selectmastervaluedetails SVM on SVM.valueid=ADC.educationalqualification  where  ADC.ApplicationNo=@ApplicationNo  and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);
                model.ViewName = "PrintProvisionalCinemaCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.FreshCinemaLicense).ToString())
            {
                Qry = "select ADC.ApplicationNo,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,ADC.CinemaOwner,ADC.CinemaOwnerAddress,ADC.FatherName,ADC.CinemaName,ADC.CinemaAddress,LM.LocalityName as CinemaLocalityName,ADC.CinemaLocalityId,OM.OccupationType as PresentOccupationName,ADC.PresentOccupation,SVM.ValueName as EducationalQualificationName,ADC.EducationalQualification,ADC.FinancialPosition,ADC.WhetherConvicted,ADC.ConvictedDetails,ADC.PanNo,ADC.NationalityId,NM.NationalityName,ADC.YearOfConstruction,ADC.NoOfScreens,ADC.YearsLicenseNeeded,to_char(ADC.ProLicenseDate,'DD/MM/YYYY') as ProLicenseDate,ADC.ProLicenseNo,AD.ServiceCode from dgen.applicationdetailscinematograph ADC inner join dbo.ApplicationDetails AD on ADC.ApplicationNo=AD.ApplicationNo  inner join NationalityMaster NM on NM.NationalityId=ADC.NationalityId  inner join LocalityMaster LM on LM.LocalityId=ADC.CinemaLocalityId  inner join occupationmaster OM on OM.occupationid=ADC.presentoccupation  inner join selectmastervaluedetails SVM on SVM.valueid=ADC.educationalqualification  where  ADC.ApplicationNo=@ApplicationNo  and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);
                model.ViewName = "PrintFreshCinemaCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.RenewalCinemaLicense).ToString())
            {
                Qry = "select ADC.ApplicationNo,AD.ApplicationStatusId,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,AD.ApplicantFatherName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,ADC.CinemaOwner,ADC.CinemaOwnerAddress,ADC.FatherName,ADC.CinemaName,ADC.CinemaAddress,LM.LocalityName as CinemaLocalityName,ADC.CinemaLocalityId,OM.OccupationType as PresentOccupationName,ADC.PresentOccupation,SVM.ValueName as EducationalQualificationName,ADC.EducationalQualification,ADC.FinancialPosition,ADC.WhetherConvicted,ADC.ConvictedDetails,ADC.PanNo,ADC.NationalityId,NM.NationalityName,ADC.YearOfConstruction,ADC.NoOfScreens,ADC.YearsLicenseNeeded,to_char(ADC.ProLicenseDate,'DD/MM/YYYY') as ProLicenseDate,ADC.ProLicenseNo,AD.ServiceCode from dgen.applicationdetailscinematograph ADC inner join dbo.ApplicationDetails AD on ADC.ApplicationNo=AD.ApplicationNo  inner join NationalityMaster NM on NM.NationalityId=ADC.NationalityId  inner join LocalityMaster LM on LM.LocalityId=ADC.CinemaLocalityId  inner join occupationmaster OM on OM.occupationid=ADC.presentoccupation  inner join selectmastervaluedetails SVM on SVM.valueid=ADC.educationalqualification  where  ADC.ApplicationNo=@ApplicationNo  and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);
                model.ViewName = "PrintRenewalCinemaCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.CDVolunteer).ToString())
            {
                Qry = "select AD.ApplicationNo,to_char(now(), 'DD/MM/YYYY') as ApprovedDate,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription,  AD.ApplicantName,AD.ApplicantFatherName,case when  AD.ApplicantGender='M' Then 'Male' when AD.ApplicantGender='F' then 'Female' end as Gender,AD.ApplicantGender,to_char(AD.ApplicantDOB,'DD/MM/YYYY') as DOB,dbo.displaycompleteaddressfromid(applicanthousenumber,applicantstreetnumber,applicantsublocality,applicantLocalityId,applicantSubDivcode,applicantdistrictcode,AD.stateid,AD.countryid,applicantpincode) as ApplicantAddress,enrollmentNo,to_char(EnrollmentDate,'DD/MM/YYYY') as EnrollmentDate,to_char((EnrollmentDate + interval '3 year'::interval),'DD/MM/YYYY') as EnrollmentToDate,cdvsubdivname,NationalityName,IdentificationMark,ApplicantmobileNo,ADCDV.NameOfKin,ADCDV.AddressOfKin,ADCDV.SelectedServices from dbo.ApplicationDetails AD inner join dgen.ApplicationDetailsCDV  ADCDV on ADCDV.ApplicationNo=AD.ApplicationNo inner join cdvsubdivmaster CDVSDM on CDVSDM.cdvsubdivcode=ADCDV.cdvsubdivcode inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode inner join NationalityMaster NM on NM.NationalityId=AD.ApplicantNationality  where AD.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);
                string[] Val = model.dataa.Rows[0]["SelectedServices"].ToString().Split(',');
                string SS = string.Empty;
                for (int i = 0; i < Val.Length; i++)
                {
                    if (i == 0) { SS = Val[i]; }
                    else { SS += "," + Val[i]; }
                }
                Qry = "select ValueName from selectmastervaluedetails where valueid in (" + SS + ")";
                Cmd = new NpgsqlCommand(Qry);
                DataTable dt = data.GetDataTable(Cmd);
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (i == 0) { SS = dt.Rows[i]["ValueName"].ToString(); }
                    else { SS += "," + dt.Rows[i]["ValueName"].ToString(); }
                }
                model.dataa.Columns["SelectedServices"].ReadOnly = false;
                model.dataa.Rows[0]["SelectedServices"] = SS;
                model.dataa.Columns["SelectedServices"].ReadOnly = true;
                model.ViewName = "PrintCDVLetter";
            }
            else if (model.ServiceCode == ((int)ServiceList.ECLicence).ToString())
            {
                //Qry = "select AD.ApplicationNo,AD.ApplicationStatusId,dbo.udf_general_decrypt(AD.DocumentNo) as ApplicantAdharNo,EC.Nameofapplicant,EC.Localityofins,LM.LocalityName,EC.Addressofapplicant,EC.Nameofauthsignatory,EC.NameofAuthSignatory,dbo.udf_general_decrypt(EC.Adharnoofauthsign) as Adharnoofauthsign,EC.Resaddofauthsign,EC.ConstitutionId,EC.Detailsofprevlicence,EC.Feedeposit,SMV.ValueName as ConstitutionName,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription from dgen.ApplicationDetailsEC EC inner join dbo.applicationdetails AD on AD.ApplicationNo=@ApplicationNo inner join localitymaster LM on LM.localityid=EC.Localityofins inner join dbo.selectmastervaluedetails SMV on SMV.Valueid=EC.ConstitutionId inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where EC.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Qry = "select AD.ApplicationNo,AD.ApplicationStatusId,dbo.udf_general_decrypt(AD.DocumentNo) as ApplicantAdharNo,AD.ApplicantGender,EC.Nameofapplicant,EC.Localityofins,LM.LocalityName,EC.Addressofapplicant,EC.Nameofauthsignatory,EC.NameofAuthSignatory,dbo.udf_general_decrypt(EC.Adharnoofauthsign) as Adharnoofauthsign,EC.Resaddofauthsign,EC.ConstitutionId,EC.Detailsofprevlicence,EC.Feedeposit,SMV.ValueName as ConstitutionName,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription from dgen.ApplicationDetailsEC EC inner join dbo.applicationdetails AD on AD.ApplicationNo=@ApplicationNo inner join localitymaster LM on LM.localityid=EC.Localityofins inner join dbo.selectmastervaluedetails SMV on SMV.Valueid=EC.ConstitutionId inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where EC.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                int ConstitutionId = Convert.ToInt32(model.dataa.Rows[0]["ConstitutionId"]);

                Dictionary<int, string> mydict = new Dictionary<int, string>();
                mydict.Add((int)ValueId.CompanyRegistered, "Authorized Signatory");
                //mydict.Add((int)ValueId.CompanyRegistered, "Company");
                mydict.Add((int)ValueId.Proprietorship, "Proprietor");
                mydict.Add((int)ValueId.Partnership, "Partner");
                model.dataa.Rows[0]["ConstitutionName"] = mydict[ConstitutionId];

                //For Change Name                
                Dictionary<int, string> myNameDict = new Dictionary<int, string>();
                myNameDict.Add((int)ValueId.CompanyRegistered, model.dataa.Rows[0]["NameofAuthSignatory"].ToString());
                myNameDict.Add((int)ValueId.Partnership, model.dataa.Rows[0]["NameofAuthSignatory"].ToString());
                myNameDict.Add((int)ValueId.Proprietorship, model.dataa.Rows[0]["ApplicantName"].ToString());
                model.RandomText = myNameDict[ConstitutionId]; //              


                Qry = "select PID.PId,PID.ApplicationNo,PID.Nameofprop,PID.Resaddressofprop,dbo.udf_general_decrypt(PID.Adharnoprop) as Adharnoprop from dgen.ecpartnershipdetails PID where PID.ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", AppNo);
                model.datab = data.GetDataTable(Cmd);

                Qry = "select APR.PaymentId,APR.ApplicationNo,to_char(APR.PaymentGenerateDate,'DD/MM/YYYY') as PaymentGenerateDate,APD.PaymentAmount,to_char(AD.ApprovedDate,'DD/MM/YYYY') as ApprovedDate from applicationpaymentrequest APR inner join dbo.ApplicationDetails AD on AD.applicationno = APR.applicationno inner join ApplicationPaymentDescription APD on APD.PaymentId=APR.PaymentId where APR.Applicationno=@Applicationno";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.dataf = data.GetDataTable(Cmd);

                model.ViewName = "PrintECLicenceCertificate";
            }
            else if (model.ServiceCode == ((int)ServiceList.CompCertificate).ToString())
            {
                //Qry = "select AD.ApplicationNo,AD.ApplicationStatusId,AD.ApplicantName as Nameofapplicant,AD.ApplicantFatherName as FathersName,to_char(AD.ApplicantDob,'DD/MM/YYYY') as Dobofapplicant,Case when AD.applicantgender ='M' THEN 'Sh.' ELSE 'Smt.' end as applicantgender,AD.ApplicantPermanentAddress as ApplicantResiAdd,CO.Localityofins,LM.LocalityName,CO.EduqualiId,CO.Yearofpassing,CO.Feedeposit,SMV.ValueName as EduQualiName,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription from dgen.applicationdetailscompcertificate CO inner join dbo.applicationdetails AD on AD.ApplicationNo=@ApplicationNo inner join localitymaster LM on LM.localityid=CO.Localityofins inner join dbo.selectmastervaluedetails SMV on SMV.Valueid=CO.EduQualiId inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where CO.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Qry = "select  AD.ApplicationNo,AD.ApplicationStatusId,AD.ApplicantName as Nameofapplicant,AD.ApplicantFatherName as FathersName,dbo.udf_general_decrypt(AD.DocumentNo) as ApplicantAdharNo,to_char(AD.ApplicantDob,'DD/MM/YYYY') as Dobofapplicant,AD.ApplicantGender,AD.ApplicantPermanentAddress as ApplicantResiAdd,CO.Localityofins,LM.LocalityName,CO.EduqualiId,CO.Yearofpassing,CO.Feedeposit,SMV.ValueName as EduQualiName,to_char(AD.ApplicationDate,'DD/MM/YYYY') as ApplicationDate,to_char(now(),'DD/MM/YYYY') as ApprovedDate,AD.ApplicantName,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress,DM.DistrictName,SD.SubDivAddress,SD.SubDivDescription from dgen.applicationdetailscompcertificate CO inner join dbo.applicationdetails AD on AD.ApplicationNo=@ApplicationNo inner join localitymaster LM on LM.localityid=CO.Localityofins inner join dbo.selectmastervaluedetails SMV on SMV.Valueid=CO.EduQualiId inner join dbo.DistrictMaster DM on DM.DistrictCode=AD.ApplicationDistrictCode inner join dbo.SubDivMaster SD on SD.SubDivCode=AD.ApplicationSubDivCode where CO.ApplicationNo=@ApplicationNo and AD.ApplicationStatusId=@StatusId";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                Cmd.Parameters.AddWithValue("@StatusId", (int)Status.TEHSPEN);
                model.dataa = data.GetDataTable(Cmd);

                Qry = "select EXP.EId,EXP.ApplicationNo,EXP.Nameoffirm,to_char(EXP.Dateofjoining,'DD/MM/YYYY') as Dateofjoining,to_char(EXP.Dateofleaving,'DD/MM/YYYY') as Dateofleaving,EXP.Natureofwork from dgen.experiencedetails EXP where EXP.ApplicationNo=@ApplicationNo";
                Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ApplicationNo", model.ApplicationNo);
                model.datab = data.GetDataTable(Cmd);

                model.ViewName = "PrintCompetencyCertificate";
            }

            return model;
        }
    }
}