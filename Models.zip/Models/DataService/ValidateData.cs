﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text.RegularExpressions;

namespace Edistrict.Models.DataService
{
    public class ValidateData : Controller
    {
        public static bool CheckSqlInjectionName(String str)
        {
            bool IsValid = true;
            try
            {
                if (String.IsNullOrEmpty(str) || String.IsNullOrWhiteSpace(str))
                    IsValid = false;
                string ValidChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ,/.-() ";
                string InvalidChars = "-";//Check for Double Hyphen
                int flag = 0;
                string Char = "";
                for (int j = 0; j < str.Length && IsValid == true; j++)
                {
                    Char = str.Substring(j, 1);
                    if (ValidChars.IndexOf(Char) < 0) { IsValid = false; }
                    if (InvalidChars.IndexOf(Char) >= 0) { flag += 1; } else { flag = 0; }
                    if (flag == 2) { IsValid = false; }
                }
            }
            catch
            {
                IsValid = false;
            }
            return IsValid;
        }
        public static bool CheckSqlInjectionAddress(String str)
        {
            bool IsValid = true;
            try
            {
                if (String.IsNullOrEmpty(str) || String.IsNullOrWhiteSpace(str))
                    IsValid = false;
                str = str.Replace('\r', ' ').Replace('\n', ' ').Replace('\t', ' ');
                string ValidChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789,/\\.-() ";
                string InvalidChars = "-";//Check for Double Hyphen
                int flag = 0;
                string Char = "";
                for (int j = 0; j < str.Length && IsValid == true; j++)
                {
                    Char = str.Substring(j, 1);
                    if (ValidChars.IndexOf(Char) < 0) { IsValid = false; }
                    if (InvalidChars.IndexOf(Char) >= 0) { flag += 1; } else { flag = 0; }
                    if (flag == 2) { IsValid = false; }
                }
            }
            catch
            {
                IsValid = false;
            }
            return IsValid;
        }
        public static bool IsNumeric(String strg)
        {
            string str = strg.Trim();
            bool IsValid = true;
            try
            {
                if (String.IsNullOrEmpty(str) || String.IsNullOrWhiteSpace(str))
                    IsValid = false;

                string ValidChars = "0123456789";
                string Char = "";
                for (int j = 0; j < str.Length && IsValid == true; j++)
                {
                    Char = str.Substring(j, 1);
                    if (ValidChars.IndexOf(Char) < 0) { IsValid = false; }
                }
            }
            catch
            {
                IsValid = false;
            }
            return IsValid;
        }
        public static bool IsAplhanumeric(String str)
        {
            bool IsValid = true;
            try
            {
                if (String.IsNullOrEmpty(str) || String.IsNullOrWhiteSpace(str))
                    IsValid = false;
                string ValidChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ";
                int flag = 0;
                string Char = string.Empty;
                for (int j = 0; j < str.Length && IsValid == true; j++)
                {
                    Char = str.Substring(j, 1);
                    if (ValidChars.IndexOf(Char) < 0) { IsValid = false; }
                    if (flag == 2) { IsValid = false; }
                }
            }
            catch
            {
                IsValid = false;
            }
            return IsValid;
        }
        public static bool IsAplha(String str)
        {
            bool IsValid = true;
            try
            {
                if (String.IsNullOrEmpty(str) || String.IsNullOrWhiteSpace(str))
                    IsValid = false;
                string ValidChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
                int flag = 0;
                string Char = string.Empty;
                for (int j = 0; j < str.Length && IsValid == true; j++)
                {
                    Char = str.Substring(j, 1);
                    if (ValidChars.IndexOf(Char) < 0) { IsValid = false; }
                    if (flag == 2) { IsValid = false; }
                }
            }
            catch
            {
                IsValid = false;
            }
            return IsValid;
        }
        public static bool IsUserId(String str)
        {
            bool IsValid = true;
            try
            {
                if (String.IsNullOrEmpty(str) || String.IsNullOrWhiteSpace(str))
                    IsValid = false;
                string ValidChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                int flag = 0;
                string Char = string.Empty;
                for (int j = 0; j < str.Length && IsValid == true; j++)
                {
                    Char = str.Substring(j, 1);
                    if (ValidChars.IndexOf(Char) < 0) { IsValid = false; }
                    if (flag == 2) { IsValid = false; }
                }
            }
            catch
            {
                IsValid = false;
            }
            return IsValid;
        }
        public static bool IsDate(string str)
        {
            bool IsValid = true;
            try
            {
                string InvalidChars = ".-";

                string Char = "";
                if (String.IsNullOrEmpty(str) || String.IsNullOrWhiteSpace(str))
                    IsValid = false;
                for (int j = 0; j < str.Length && IsValid == true; j++)
                {
                    Char = str.Substring(j, 1);
                    int i = InvalidChars.IndexOf(Char);
                    if (InvalidChars.IndexOf(Char) >= 0) { IsValid = false; }
                }
                if (IsValid == true)
                {
                    try
                    {
                        DateTime dt = DateTime.Parse(str, Utility.FormattedDateWithCulture(str));
                        string[] str1 = str.Split('/');
                        if (Convert.ToInt16(str1[0].ToString()) > 31 || Convert.ToInt16(str1[1].ToString()) > 12 || Convert.ToInt16(str1[2].ToString()) < 1900 || Convert.ToInt16(str1[2].ToString()) > 2999)
                            IsValid = false;
                    }
                    catch (Exception)
                    {
                        IsValid = false;
                    }
                }
            }
            catch
            {
                IsValid = false;
            }
            return IsValid;
        }
        public static bool CheckValidLength(string Val, int Len)
        {
            try
            {
                if (Val.Length == Len)
                    return true;
                return false;
            }
            catch { return false; }
        }

        #region For UID Verification Validation
        public bool FullNameValidator(string val)
        {
            bool flag = true;
            string pattern = "^(?!.*\\.\\.)(?!.*\\s\\s)(?!.*\\'\\')[A-Za-z\\s\\.\\']+$";
            if (!Regex.IsMatch(val, pattern))
                flag = false;
            return flag;
        }

        public bool AlphanumericValidator(string val)
        {
            bool flag = true;
            string pattern = "^[A-Za-z0-9\\s\\.\\-\\/#,]*$";
            if (!Regex.IsMatch(val, pattern))
                flag = false;
            return flag;
        }

        public bool AlphanumericValidatorParan(string val)
        {
            bool flag = true;
            string pattern = "^[A-Za-z0-9\\s\\-\\,]*$";
            if (!Regex.IsMatch(val, pattern))
                flag = false;
            return flag;
        }

        public bool AlphanumericValidatorwithSpaceHypen(string val)
        {
            bool flag = true;
            string pattern = "^[A-Za-z0-9\\s\\-]*$";
            if (!Regex.IsMatch(val, pattern))
                flag = false;
            return flag;
        }

        public bool AlphanumericValidatorwithSpaceHypenslash(string val)
        {
            bool flag = true;
            string pattern = "^[A-Za-z0-9\\s\\-\\/]*$";
            if (!Regex.IsMatch(val, pattern))
                flag = false;
            return flag;
        }

        public bool AlphanumericValidatorwithDotSpace(string val)
        {
            bool flag = true;
            string pattern = "^[A-Za-z0-9\\s\\.]*$";
            if (!Regex.IsMatch(val, pattern))
                flag = false;
            return flag;
        }

        public bool AlphanumericValidatorwithampherSpace(string val)
        {
            bool flag = true;
            string pattern = "^[A-Za-z0-9\\s\\&]*$";
            if (!Regex.IsMatch(val, pattern))
                flag = false;
            return flag;
        }

        public bool EmailValidator(string val)
        {
            bool flag = true;
            string pattern = "^([a-zA-Z0-9_\\-\\.]+)@((([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$";
            if (!Regex.IsMatch(val, pattern))
                flag = false;
            return flag;
        }

        public bool AlphanumericValidatorNoSpecialSymbols(string val)
        {
            bool flag = true;
            string pattern = "^[A-Za-z0-9]*$";
            if (!Regex.IsMatch(val, pattern))
                flag = false;
            return flag;
        }

        public bool NumericValidator(string val)
        {
            bool flag = true;
            string pattern = "^[0-9]*$";
            if (!Regex.IsMatch(val, pattern))
                flag = false;
            return flag;
        }

        public bool ValidateUIDCheckSum(string uid)
        {
            return this.CheckArrayByVerhoeffAlogirithm(ValidateData.ConvertToIntArray(uid));
        }

        private static int[] ConvertToIntArray(string input)
        {
            int[] numArray = new int[input.Length];
            for (int startIndex = 0; startIndex < input.Length; ++startIndex)
                numArray[startIndex] = Convert.ToInt32(input.Substring(startIndex, 1));
            return numArray;
        }

        private bool CheckArrayByVerhoeffAlogirithm(int[] input)
        {
            int[][] numArray1 = new int[10][]
    {
      new int[10]
      {
        0,
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9
      },
      new int[10]
      {
        1,
        2,
        3,
        4,
        0,
        6,
        7,
        8,
        9,
        5
      },
      new int[10]
      {
        2,
        3,
        4,
        0,
        1,
        7,
        8,
        9,
        5,
        6
      },
      new int[10]
      {
        3,
        4,
        0,
        1,
        2,
        8,
        9,
        5,
        6,
        7
      },
      new int[10]
      {
        4,
        0,
        1,
        2,
        3,
        9,
        5,
        6,
        7,
        8
      },
      new int[10]
      {
        5,
        9,
        8,
        7,
        6,
        0,
        4,
        3,
        2,
        1
      },
      new int[10]
      {
        6,
        5,
        9,
        8,
        7,
        1,
        0,
        4,
        3,
        2
      },
      new int[10]
      {
        7,
        6,
        5,
        9,
        8,
        2,
        1,
        0,
        4,
        3
      },
      new int[10]
      {
        8,
        7,
        6,
        5,
        9,
        3,
        2,
        1,
        0,
        4
      },
      new int[10]
      {
        9,
        8,
        7,
        6,
        5,
        4,
        3,
        2,
        1,
        0
      }
    };
            int[][] numArray2 = new int[8][];
            numArray2[0] = new int[10]
    {
      0,
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9
    };
            numArray2[1] = new int[10]
    {
      1,
      5,
      7,
      6,
      2,
      8,
      3,
      0,
      9,
      4
    };
            for (int index1 = 2; index1 < 8; ++index1)
            {
                numArray2[index1] = new int[10];
                for (int index2 = 0; index2 < 10; ++index2)
                    numArray2[index1][index2] = numArray2[index1 - 1][numArray2[1][index2]];
            }
            int[] numArray3 = new int[input.Length];
            for (int index = 0; index < input.Length; ++index)
                numArray3[index] = input[input.Length - (index + 1)];
            int index3 = 0;
            for (int index1 = 0; index1 < numArray3.Length; ++index1)
                index3 = numArray1[index3][numArray2[index1 % 8][numArray3[index1]]];
            return index3 == 0;
        }

        public bool UrlValidator(string val)
        {
            bool flag = true;
            string pattern = "^((https?|ftp|gopher|telnet|file|notes|ms-help):((//)|(\\\\\\\\))+[\\w\\d:#@%/;$()~_?\\+-=\\\\\\.&]*)$";
            if (!Regex.IsMatch(val, pattern))
                flag = false;
            return flag;
        }

        public bool AlphanumericValidatorfortxn(string val)
        {
            bool flag = true;
            string pattern = "^[A-Za-z0-9]*$";
            if (!Regex.IsMatch(val, pattern))
                flag = false;
            return flag;
        }

        public bool NumericValidatorwithSign(string val)
        {
            bool flag = true;
            string pattern = "^[\\+-]?[0-9]*$";
            if (!Regex.IsMatch(val, pattern))
                flag = false;
            return flag;
        }

        public bool IpAddrValidator(string val)
        {
            bool flag = true;
            string pattern = "^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$";
            if (!Regex.IsMatch(val, pattern))
                flag = false;
            return flag;
        }
        #endregion For UID Verification Validation

    }
}