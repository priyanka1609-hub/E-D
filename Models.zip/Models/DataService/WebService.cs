﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Edistrict.Models.ApplicationService;
using System.Data;
using Edistrict.TransportService;
using Edistrict.TataPowerDDLService;
using Edistrict.ElectionService;
using System.Text.RegularExpressions;
using Edistrict.Models.CustomClass;
using Edistrict.BSESService;
using Edistrict.CBSEXService;
using Edistrict.NfsVerificationService;
using System.Web.Security;
using System.Net;
using System.Text;
using System.IO;
using System.Globalization;
using System.Xml;
using Edistrict.eRevLitigationService;
using Npgsql;

namespace Edistrict.Models.DataService
{
    public static class WebService
    {
        #region WebService

        public static string GetNFSResponse(string DocumentNo, string DocumentId)
        {
            string Response = string.Empty;
            int WebServiceResponseCode = 0;
            bool WhetherResponseReceived = false, WhetherDataFound = false;
            string[] Data = null;
            Int64 TID = Utility.InitiateTransactionId(DocumentId, (int)EnclosureDepartment.FoodAndSupplyDepartment, DocumentNo);
            string Key = DocumentNo + "|" + TID.ToString();

            ServiceClient client = new ServiceClient();
            Response = client.GetDataFromFcs(Key);
            if (!string.IsNullOrEmpty(Response))
            {
                WhetherResponseReceived = true;
                string DeptLogId = string.Empty;
                Data = Response.Split('|');
                DeptLogId = Data[15].ToString();
                if (!string.IsNullOrEmpty(DeptLogId) && (DeptLogId != "0") && (DeptLogId != "NA"))
                {
                    WhetherDataFound = true;
                    WebServiceResponseCode = (int)WebServiceResponse.Verified;
                }
                else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; }
            }
            if ((WhetherDataFound != false) || (WhetherResponseReceived != false)) { Utility.UpdateTransactionFlags(WhetherDataFound, WhetherResponseReceived, TID); } else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString(); }

            Response = WebServiceResponseCode + "|" + Data[0].ToString() + "|" + Data[1].ToString() + "|" + Data[2].ToString() + "|" + Data[9].ToString() + "|" + Data[10].ToString() + "|" + Data[11].ToString() + "|" + Data[8].ToString() + "|" + Data[7].ToString() + "|" + Data[5].ToString() + "|" + Data[12].ToString() + "|" + Data[6].ToString() + "|" + Data[3].ToString() + "|" + Data[4].ToString() + "|" + Data[14].ToString() + "|" + Data[15].ToString() + "|" + DocumentId + "|" + DocumentNo + "|" + WhetherResponseReceived + "|" + WhetherDataFound;
            return Response;
        }

        public static string GetDLResponse(string DocumentNo, string DocumentId)
        {
            string Key = string.Empty;
            int WebServiceResponseCode = 0;
            bool WhetherResponseReceived = false, WhetherDataFound = false;
            DataSet Response = new DataSet();

            DLwebservicesClient client = new DLwebservicesClient();
            Edistrict.TransportService.UserCredentials Credentials = new Edistrict.TransportService.UserCredentials();
            Credentials.userName = "Dimtsdlservices";
            Credentials.password = "transport@123";

            Int64 TID = Utility.InitiateTransactionId(DocumentId, (int)EnclosureDepartment.TransportDepartment, DocumentNo);
            Response = client.GetDLdetails(Credentials, DocumentNo);

            if (Response.Tables.Count > 0)
            {
                WhetherResponseReceived = true;
                string DataCheck = Response.Tables["Table1"].Rows[0][0].ToString();

                if (!string.IsNullOrEmpty(DataCheck) && (DataCheck != "0") && (DataCheck != "NA"))
                {
                    WhetherDataFound = true;
                    WebServiceResponseCode = (int)WebServiceResponse.Verified;
                }
                else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; }
            }
            if ((WhetherDataFound != false) || (WhetherResponseReceived != false)) { Utility.UpdateTransactionFlags(WhetherDataFound, WhetherResponseReceived, TID); } else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString(); }

            string strResponse = WebServiceResponseCode + "|" + Response.Tables["Table1"].Rows[0][0].ToString() + "|NA|" + Response.Tables["Table1"].Rows[0][1].ToString() + "|" + Response.Tables["Table1"].Rows[0][2].ToString() + "|NA|NA|NA|NA|" + Response.Tables["Table1"].Rows[0][3].ToString() + Response.Tables["Table1"].Rows[0][4].ToString() + Response.Tables["Table1"].Rows[0][5].ToString() + Response.Tables["Table1"].Rows[0][6].ToString() + "|NA|" + Response.Tables["Table1"].Rows[0][8].ToString() + "|" + Response.Tables["Table1"].Rows[0][7].ToString() + "|NA|NA|NA|" + DocumentId + "|" + DocumentNo + "|" + WhetherResponseReceived + "|" + WhetherDataFound;
            return strResponse;
        }

        public static string GetTataPowerDDLResponse(string DocumentNo, string DocumentId)
        {
            string Key = string.Empty, FatherName = string.Empty, MotherName = string.Empty, SpouseName = string.Empty;
            int WebServiceResponseCode = 0;
            bool WhetherResponseReceived = false, WhetherDataFound = false;
            string[] Data = null;

            Edistrict.TataPowerDDLService.ServiceSoapClient client = new Edistrict.TataPowerDDLService.ServiceSoapClient();

            Int64 TID = Utility.InitiateTransactionId(DocumentId, (int)EnclosureDepartment.TPDDL, DocumentNo);
            string Response = client.E_Dist_GetConsumer_CANO(DocumentNo, TID.ToString(), "ed_nic", "nic@9090");

            if (!string.IsNullOrEmpty(Response))
            {
                WhetherResponseReceived = true;
                string DataCheck = string.Empty;
                Data = Response.Split('|');
                DataCheck = Data[2].ToString();
                if (!string.IsNullOrEmpty(DataCheck) && (DataCheck != "0") && (DataCheck != "NA"))
                {
                    WhetherDataFound = true;
                    WebServiceResponseCode = (int)WebServiceResponse.Verified;
                }
                else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; }
            }
            if ((WhetherDataFound != false) || (WhetherResponseReceived != false)) { Utility.UpdateTransactionFlags(WhetherDataFound, WhetherResponseReceived, TID); } else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString(); }

            for (int i = 0; i < Data.Length; i++) { if (string.IsNullOrEmpty(Data[i])) { Data[i] = "NA"; } }
            if ((Data[3].ToString() != "NA") && (Data[4].ToString() != "NA"))
            {
                if (Regex.IsMatch(Data[3].ToString(), @"\bSon\b") || Regex.IsMatch(Data[3].ToString(), @"\bDaughter\b")) { FatherName = Data[4].ToString(); }
                else if (Regex.IsMatch(Data[3].ToString(), @"\bWife\b")) { SpouseName = Data[4].ToString(); }
                else { FatherName = Data[4].ToString(); }
            }
            //temp code to format date
            if (Data[8].Length < 10)
            {
                string[] recDate = Data[8].Split('/');
                if (recDate[0].Length == 1) { recDate[0] = "0" + recDate[0]; }
                if (recDate[1].Length == 1) { recDate[1] = "0" + recDate[1]; }
                Data[8] = recDate[0] + "/" + recDate[1] + "/" + recDate[2];
            }
            Response = WebServiceResponseCode + "|" + Data[0].ToString() + "|" + Data[1].ToString() + "|" + Data[2].ToString() + "|" + FatherName + "|" + MotherName + "|" + SpouseName + "|NA|NA|" + Data[5].ToString() + "|NA|NA|" + Data[8].ToString() + "|NA|" + Data[6].ToString() + "|NA|" + DocumentId + "|" + DocumentNo + "|" + WhetherResponseReceived + "|" + WhetherDataFound;
            return Response;
        }

        public static string GetElectionResponse(string DocumentNo, string DocumentId)
        {
            string Key = string.Empty, FatherName = string.Empty, MotherName = string.Empty, SpouseName = string.Empty;
            int WebServiceResponseCode = 0;
            bool WhetherResponseReceived = false, WhetherDataFound = false;
            string[] Data = null;

            Edistrict.ElectionService.ServiceSoapClient client = new Edistrict.ElectionService.ServiceSoapClient();
            Int64 TID = Utility.InitiateTransactionId(DocumentId, (int)EnclosureDepartment.ElectionCommission, DocumentNo);

            string Response = string.Empty;
            string firstThreeCharacters = DocumentNo.Substring(0, 3);
            if (firstThreeCharacters.ToUpper() == "DL/")
            {
                Response = client.EpicInfo(DocumentNo);
            }
            else
            {
                Response = client.EpicinfoSearch(DocumentNo);
            }

            if (!string.IsNullOrEmpty(Response))
            {
                WhetherResponseReceived = true;
                string DataCheck = string.Empty;
                Data = Response.Split(';');
                if (Data.Length > 1)
                {
                    DataCheck = Data[3];
                    if (!string.IsNullOrEmpty(DataCheck) && (DataCheck != "0") && (DataCheck != "NA"))
                    {
                        WhetherDataFound = true;
                        WebServiceResponseCode = (int)WebServiceResponse.Verified;
                    }
                    else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; }
                }
                else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; }
            }
            if ((WhetherDataFound != false) || (WhetherResponseReceived != false)) { Utility.UpdateTransactionFlags(WhetherDataFound, WhetherResponseReceived, TID); } else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString(); }
            if (WhetherDataFound == false) { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString(); }
            for (int i = 0; i < Data.Length; i++) { if (string.IsNullOrEmpty(Data[i])) { Data[i] = "NA"; } }

            Response = WebServiceResponseCode + "|NA|NA|" + Data[3].ToString() + "|" + Data[4].ToString() + "|NA|NA|NA|NA|" + Data[5].ToString() + "|NA|NA|NA|NA|NA|NA|" + DocumentId + "|" + DocumentNo + "|" + WhetherResponseReceived + "|" + WhetherDataFound;
            return Response;
        }

        public static string GetUIDResponse(string DocumentNo, string DocumentId, string RegistrationId, Dictionary<string, string> objDic)
        {
            int WebServiceResponseCode = 0;
            bool WhetherResponseReceived = false, WhetherDataFound = false;
            string Key = string.Empty, FatherName = string.Empty, MotherName = string.Empty, SpouseName = string.Empty, Response = string.Empty, ApplicantName = string.Empty, ApplicantGender = string.Empty, ApplicantDOb = string.Empty;

            GetData data = new GetData();
            if (objDic != null)
            {
                ApplicantName = objDic["ApplicantName"].ToString();
                ApplicantGender = objDic["ApplicantGender"].ToString();
                ApplicantDOb = objDic["ApplicantDob"].ToString();
            }
            else
            {
                String Qry = "select ApplicantName,ApplicantGender,to_char(ApplicantDOb,'DD/MM/YYYY') as ApplicantDOb from web.registrationmaster where RegistrationId=@RegistrationId";//main query
                //String Qry = "select ApplicantName,ApplicantGender,to_char(ApplicantDOb,'DD/MM/YYYY') as ApplicantDOb from web.registrationmaster where lower(documentno)=@documentno and documentid=@documentid";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@RegistrationId", RegistrationId);
                Cmd.Parameters.AddWithValue("@documentno", DocumentNo.ToLower());
                Cmd.Parameters.AddWithValue("@documentid", (int)CountList.Type001);
                DataTable dt = data.GetDataTable(Cmd);
                if (dt.Rows.Count > 0)
                {
                    ApplicantName = dt.Rows[0]["ApplicantName"].ToString();
                    ApplicantGender = dt.Rows[0]["ApplicantGender"].ToString();
                    ApplicantDOb = dt.Rows[0]["ApplicantDOb"].ToString();
                }
            }

            AadhaarResponse obj = new AadhaarResponse();
            if (!string.IsNullOrEmpty(ApplicantName))
            {
                int Result = Utility.ProcessVerifyUID(ApplicantName.ToUpper(), ApplicantGender.ToUpper(), ApplicantDOb, string.Empty, string.Empty, DocumentNo);
                if (Result == (int)CountList.Type000)
                {
                    WhetherResponseReceived = true;
                    WebServiceResponseCode = (int)WebServiceResponse.NotVerified;
                    Response = WebServiceResponseCode.ToString();
                    return Response;
                }
                else if (Result == (int)CountList.Type001)
                {
                    WhetherDataFound = true;
                    WhetherResponseReceived = true;
                    WebServiceResponseCode = (int)WebServiceResponse.Verified;
                    obj.AadhaarNo = DocumentNo;
                    obj.Name = ApplicantName.ToUpper();
                    obj.Gender = ApplicantGender.ToUpper();
                    obj.Dob = ApplicantDOb.ToUpper();
                }
                else
                {
                    WebServiceResponseCode = (int)WebServiceResponse.ExceptionOccurred;
                    Response = WebServiceResponseCode.ToString();
                    return Response;
                }
            }
            else
            {
                WebServiceResponseCode = (int)WebServiceResponse.NotVerified;
                Response = WebServiceResponseCode.ToString();
                return Response;
            }

            Int64 TID = Utility.InitiateTransactionId(DocumentId, (int)EnclosureDepartment.UID, DocumentNo);
            Response = WebServiceResponseCode + "|" + obj.AadhaarNo + "|" + TID + "|" + obj.Name + "|" + obj.FatherName + "|NA|NA|" + obj.Gender + "|" + obj.Dob + "|" + (obj.Address + " " + obj.PinCode) + "|" + obj.AadhaarNo + "|NA|NA|NA|NA|NA|" + DocumentId + "|" + DocumentNo + "|" + WhetherResponseReceived + "|" + WhetherDataFound;
            return Response;

            //AadhaarResponse obj = new AadhaarResponse();
            //Int64 TID = Utility.InitiateTransactionId(DocumentId, (int)EnclosureDepartment.ElectionCommission, DocumentNo);
            //obj = Utility.GetAdharDetails(DocumentNo);

            //if ((obj != null) && (!string.IsNullOrEmpty(obj.AadhaarNo)))
            //{
            //    WhetherResponseReceived = true;
            //    if ((!string.IsNullOrEmpty(obj.AadhaarNo)) && (!string.IsNullOrEmpty(obj.Name)) && (!string.IsNullOrEmpty(obj.Dob)))
            //    {
            //        WhetherDataFound = true;
            //        WebServiceResponseCode = (int)WebServiceResponse.Verified;
            //    }
            //    else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; }
            //}
            //if ((WhetherDataFound != false) || (WhetherResponseReceived != false)) { Utility.UpdateTransactionFlags(WhetherDataFound, WhetherResponseReceived, TID); } else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString(); }
            //if (WhetherDataFound == false) { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString(); }

            //DocumentNo|TxnId|Name|FatherName|MotherName|SpouseName|Gender|DOB|Address|AadhaarNo|ValidUpto|IssuingDate|IssuingAuthority|DocumentStatus|DeptLogId|DocumentId|DocumentNo|WhetherResponseReceived|WhetherDataFound|WebServiceResponseCode
        }

        public static string GetBSESResponse(string DocumentNo, string DocumentId)
        {
            string Key = string.Empty, FatherName = string.Empty, MotherName = string.Empty, SpouseName = string.Empty;
            int WebServiceResponseCode = 0;
            bool WhetherResponseReceived = false, WhetherDataFound = false;
            //string[] Data = null;

            Int64 TID = Utility.InitiateTransactionId(DocumentId, (int)EnclosureDepartment.BSES, DocumentNo);
            MobileServicesSoapClient client = new MobileServicesSoapClient();
            Edistrict.BSESService.UserCredentials Credentials = new Edistrict.BSESService.UserCredentials();
            Credentials.userName = "EXTUSER";
            Credentials.password = "pass@123";
            string Response = string.Empty;
            DataSet dsResponse = client.ZBAPI_EDISTRICT(Credentials, DocumentNo, "", TID.ToString());//Edistrict.BSESService.UserCredentials UserCredentials, string strCANumber, string strCRNNumber, string txnID

            if ((dsResponse != null) && (dsResponse.Tables.Count > 0))
            {
                WhetherResponseReceived = true;
                if (dsResponse.Tables[0].Rows.Count > 0)
                {
                    if (dsResponse.Tables[0].Columns.Count <= 1)
                    {
                        WebServiceResponseCode = (int)WebServiceResponse.NotVerified;
                        return WebServiceResponseCode.ToString();
                    }
                    else
                    {
                        WhetherDataFound = true;
                        WebServiceResponseCode = (int)WebServiceResponse.Verified;
                        string recDate = dsResponse.Tables[0].Rows[0][45].ToString();
                        if (recDate.Length == 8)
                        {
                            string y = recDate.Substring(0, 4);
                            string m = recDate.Substring(4, 2);
                            string d = recDate.Substring(6, 2);
                            recDate = d + "/" + m + "/" + y;
                            dsResponse.Tables[0].Rows[0][45] = recDate;
                        }
                    }
                }

            }
            if ((WhetherDataFound != false) || (WhetherResponseReceived != false)) { Utility.UpdateTransactionFlags(WhetherDataFound, WhetherResponseReceived, TID); } else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString(); }
            if (WebServiceResponseCode == (int)WebServiceResponse.NotVerified) { return WebServiceResponseCode.ToString(); }

            //DocumentNo|TxnId|Name|FatherName|MotherName|SpouseName|Gender|DOB|Address|AadhaarNo|ValidUpto|IssuingDate|IssuingAuthority|DocumentStatus|DeptLogId|DocumentId|DocumentNo|WhetherResponseReceived|WhetherDataFound|WebServiceResponseCode
            Response = WebServiceResponseCode + "|" + dsResponse.Tables[0].Rows[0][0].ToString() + "|" + TID.ToString() + "|" + dsResponse.Tables[0].Rows[0][2].ToString() + "|NA|NA|NA|NA|NA|" + dsResponse.Tables[0].Rows[0][6].ToString() + " " + dsResponse.Tables[0].Rows[0][7].ToString() + " " + dsResponse.Tables[0].Rows[0][8].ToString() + " " + dsResponse.Tables[0].Rows[0][10].ToString() + dsResponse.Tables[0].Rows[0][11].ToString() + " " + dsResponse.Tables[0].Rows[0][12].ToString() + " " + dsResponse.Tables[0].Rows[0][13].ToString() + " " + dsResponse.Tables[0].Rows[0][14].ToString() + " " + dsResponse.Tables[0].Rows[0][15].ToString() + " " + dsResponse.Tables[0].Rows[0][17].ToString() + "|NA|NA|" + dsResponse.Tables[0].Rows[0][45].ToString() + "|NA|NA|NA|" + DocumentId + "|" + DocumentNo + "|" + WhetherResponseReceived + "|" + WhetherDataFound;
            return Response;
        }

        public static string GetNDMCBDResponse(string DocumentNo, string DocumentId)
        {
            string Key = string.Empty, FatherName = string.Empty, MotherName = string.Empty, SpouseName = string.Empty;
            int WebServiceResponseCode = 0;
            bool WhetherResponseReceived = false, WhetherDataFound = false;
            string[] Data = null;

            Edistrict.NDMCServiceBD.ServiceSoapClient client = new Edistrict.NDMCServiceBD.ServiceSoapClient();
            Int64 TID = Utility.InitiateTransactionId(DocumentId, (int)EnclosureDepartment.NDMC, DocumentNo);
            string Response = string.Empty;
            //DataTable dtResponse = client.GetData("SJH0032826/2014", "141626", "15-Dec-2014", "14-Dec-2014", "", "");
            DataTable dtResponse = client.GetData(DocumentNo, string.Empty, string.Empty, string.Empty, "", "");

            if ((dtResponse != null) && (dtResponse.Rows.Count > 0))
            {
                WhetherResponseReceived = true;
                string DataCheck = string.Empty;
                Data = Response.Split(';');
                DataCheck = Data[3].ToString();
                if (!string.IsNullOrEmpty(DataCheck) && (DataCheck != "0") && (DataCheck != "NA"))
                {
                    WhetherDataFound = true;
                    WebServiceResponseCode = (int)WebServiceResponse.Verified;
                }
                else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; }
            }
            if ((WhetherDataFound != false) || (WhetherResponseReceived != false)) { Utility.UpdateTransactionFlags(WhetherDataFound, WhetherResponseReceived, TID); } else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; }

            for (int i = 0; i < Data.Length; i++) { if (string.IsNullOrEmpty(Data[i])) { Data[i] = "NA"; } }

            Response = WebServiceResponseCode + "|NA|NA|" + Data[3].ToString() + "|" + Data[4].ToString() + "|NA|NA|NA|NA|" + Data[5].ToString() + "|NA|NA|NA|NA|NA|NA|" + DocumentId + "|" + DocumentNo + "|" + WhetherResponseReceived + "|" + WhetherDataFound;
            return Response;
        }

        public static string GetNDMCEWResponse(string DocumentNo, string DocumentId)
        {
            string Key = string.Empty, FatherName = string.Empty, MotherName = string.Empty, SpouseName = string.Empty;
            int WebServiceResponseCode = 0;
            bool WhetherResponseReceived = false, WhetherDataFound = false;

            Edistrict.NDMCServiceEW.ServiceSoapClient client = new Edistrict.NDMCServiceEW.ServiceSoapClient();
            Int64 TID = Utility.InitiateTransactionId(DocumentId, (int)EnclosureDepartment.NDMC, DocumentNo);
            string Response = string.Empty;
            DataTable dtResponse = client.GetDetails("ndmc", "ndmc@123", DocumentNo);

            if ((dtResponse != null) && (dtResponse.Rows.Count > 0))
            {
                WhetherResponseReceived = true;
                string DataCheck = string.Empty;
                DataCheck = dtResponse.Rows[0][0].ToString();
                if (!string.IsNullOrEmpty(DataCheck))
                {
                    WhetherDataFound = true;
                    WebServiceResponseCode = (int)WebServiceResponse.Verified;
                }
                else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; }
            }
            if ((WhetherDataFound != false) || (WhetherResponseReceived != false)) { Utility.UpdateTransactionFlags(WhetherDataFound, WhetherResponseReceived, TID); } else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString(); }
            string[] Data = new string[dtResponse.Columns.Count];
            for (int i = 0; i < dtResponse.Columns.Count; i++)
            {
                if (string.IsNullOrEmpty(dtResponse.Rows[0][dtResponse.Columns[i].ColumnName.ToString()].ToString())) { Data[i] = "NA"; }
                else { Data[i] = dtResponse.Rows[0][dtResponse.Columns[i].ColumnName.ToString()].ToString(); }
            }

            Response = WebServiceResponseCode + "|" + Data[1] + "|" + TID.ToString() + "|" + Data[0] + "|NA|NA|NA|NA|NA|" + Data[2] + "|NA|NA|NA|NA|NA|NA|" + DocumentId + "|" + DocumentNo + "|" + WhetherResponseReceived + "|" + WhetherDataFound;
            return Response;
        }

        public static string GetCBSEXResponse(string DocumentNo, string DocumentId)
        {
            string Key = string.Empty, FatherName = string.Empty, MotherName = string.Empty, SpouseName = string.Empty;
            int WebServiceResponseCode = 0;
            bool WhetherResponseReceived = false, WhetherDataFound = false;
            string[] Data = null;

            wsGetCanDataSoapClient client = new wsGetCanDataSoapClient();
            Int64 TID = Utility.InitiateTransactionId(DocumentId, (int)EnclosureDepartment.NDMC, DocumentNo);
            string Response = string.Empty;
            AuthenticationHeader Auth = new AuthenticationHeader();
            Auth.Username = "RevDept";
            string pass = "RevCbse#15";
            pass = FormsAuthentication.HashPasswordForStoringInConfigFile(pass, "md5").ToString();
            Auth.Password = pass;
            AuthInfo retVal = client.getData(Auth, DocumentNo, "2015");
            if (retVal != null)
            {
                WhetherResponseReceived = true;
                string DataCheck = string.Empty;
                DataCheck = retVal.Dob;
                if (!string.IsNullOrEmpty(DataCheck) && (DataCheck != "0") && (DataCheck != "NA"))
                {
                    WhetherDataFound = true;
                    WebServiceResponseCode = (int)WebServiceResponse.Verified;
                }
                else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; }
            }
            if ((WhetherDataFound != false) || (WhetherResponseReceived != false)) { Utility.UpdateTransactionFlags(WhetherDataFound, WhetherResponseReceived, TID); } else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString(); }
            if (WebServiceResponseCode == (int)WebServiceResponse.NotVerified) { return WebServiceResponseCode.ToString(); }

            //DocumentNo|TxnId|Name|FatherName|MotherName|SpouseName|Gender|DOB|Address|AadhaarNo|ValidUpto|IssuingDate|IssuingAuthority|DocumentStatus|DeptLogId|DocumentId|DocumentNo|WhetherResponseReceived|WhetherDataFound|WebServiceResponseCode
            Response = WebServiceResponseCode + "|" + retVal.RollNo + "|NA|" + Data[3].ToString() + "|" + Data[4].ToString() + "|NA|NA|NA|NA|" + Data[5].ToString() + "|NA|NA|NA|NA|NA|NA|" + DocumentId + "|" + DocumentNo + "|" + WhetherResponseReceived + "|" + WhetherDataFound;
            return Response;
        }

        public static string GetDJBResponse(string DocumentNo, string DocumentId)
        {
            int WebServiceResponseCode = 0;
            bool WhetherResponseReceived = false, WhetherDataFound = false;
            Int64 TID = Utility.InitiateTransactionId(DocumentId, (int)EnclosureDepartment.DJB, DocumentNo);

            string uri = "http://10.248.136.21/DJBInfo/exchange/Document/Verification";
            HttpWebRequest req = WebRequest.Create(uri) as HttpWebRequest;
            req.KeepAlive = false;
            req.Method = "POST";

            String uniqueDocumentIdentifier = DocumentNo;
            String transactionId = TID.ToString();
            String userId = "DJBEDIST1";// Provide User Id
            String password = "DJB@E123";// Provide Password
            String checksumMessage = uniqueDocumentIdentifier + "|" + transactionId + "|" + userId + "|" + password;
            StringBuilder xmlSb = new StringBuilder();

            xmlSb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            xmlSb.Append("<DocumentVerificationRequest>");
            xmlSb.Append("<UniqueDocumentIdentifier>" + uniqueDocumentIdentifier + "</UniqueDocumentIdentifier>");
            xmlSb.Append("<TransactionId>" + transactionId + "</TransactionId>");
            xmlSb.Append("<UserId>" + userId + "</UserId>");
            xmlSb.Append("<Password>" + password + "</Password>");

            String checksumValue = string.Empty;
            checksumValue = Utility.GetHMACSHA256(checksumMessage, "EDISTDJBDL");

            xmlSb.Append("<ChecksumValue>" + checksumValue + "</ChecksumValue>");
            xmlSb.Append("</DocumentVerificationRequest>");

            byte[] buffer = Encoding.ASCII.GetBytes(xmlSb.ToString());
            req.ContentLength = buffer.Length;
            req.ContentType = "text/xml";
            Stream PostData = req.GetRequestStream();
            PostData.Write(buffer, 0, buffer.Length);
            PostData.Close();

            HttpWebResponse resp = req.GetResponse() as HttpWebResponse;
            Encoding enc = System.Text.Encoding.GetEncoding(1252);
            StreamReader loResponseStream = new StreamReader(resp.GetResponseStream(), enc);
            string Response = loResponseStream.ReadToEnd();
            loResponseStream.Close();
            resp.Close();

            if (!string.IsNullOrEmpty(Response)) { WhetherResponseReceived = true; }

            string strResponse = Utility.GetSeperatedStringFromXML(Response, "DocumentVerificationResponse");
            string[] Data = strResponse.Split('|');
            if (Data.Length > 5)
            {
                WhetherDataFound = true;
                WebServiceResponseCode = (int)WebServiceResponse.Verified;
            }
            else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; }
            if ((WhetherDataFound != false) || (WhetherResponseReceived != false)) { Utility.UpdateTransactionFlags(WhetherDataFound, WhetherResponseReceived, TID); } else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString(); }
            if (WebServiceResponseCode == (int)WebServiceResponse.NotVerified) { return WebServiceResponseCode.ToString(); }

            for (int i = 0; i < Data.Length; i++)
            {
                Data[i] = Data[i].Trim();
                if (string.IsNullOrEmpty(Data[i].ToString().ToString())) { Data[i] = "NA"; }
            }
            Data[4] = DateTime.Parse(Data[4].Trim()).ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);

            //WebServiceResponseCode|DocumentNo|TxnId|Name|FatherName|MotherName|SpouseName|Gender|DOB|Address|AadhaarNo|ValidUpto|IssuingDate|IssuingAuthority|DocumentStatus|DeptLogId|DocumentId|DocumentNo|WhetherResponseReceived|WhetherDataFound
            Response = WebServiceResponseCode + "|" + Data[17] + "|" + Data[16] + "|" + Data[12] + "|" + Data[10] + "|" + Data[11] + "|" + Data[14] + "|NA|" + Data[9] + "|" + Data[8] + "|NA|NA|" + Data[4] + "|" + Data[3] + "|" + Data[15] + "|" + Data[2] + "|" + DocumentId + "|" + DocumentNo + "|" + WhetherResponseReceived + "|" + WhetherDataFound;
            return Response;
        }

        public static string GetMCDResponse(string DocumentNo, string DocumentId)
        {
            string Key = string.Empty, Response = string.Empty;
            int WebServiceResponseCode = 0;
            bool WhetherResponseReceived = false, WhetherDataFound = false;

            Int64 TID = Utility.InitiateTransactionId(DocumentId, (int)EnclosureDepartment.MCD, DocumentNo);
            string Domain = new Uri(HttpContext.Current.Request.Url.AbsoluteUri).GetLeftPart(UriPartial.Authority);
            string RequestURL = "http://111.93.49.45/votdemo/votive.php?citizenid=" + DocumentNo + "&ackid=" + TID.ToString() + "&returnURL=" + Domain + "/Common/ProcessMCDRequest";
            using (WebClient client = new WebClient()) { Response = client.DownloadString(RequestURL); }
            if (!string.IsNullOrEmpty(Response)) { WhetherResponseReceived = true; }

            string[] Data = Response.Split('\'');
            string[] Params = new string[12];
            Uri myUri = new Uri(Data[1]);
            Params[0] = HttpUtility.ParseQueryString(myUri.Query).Get("regNo");
            Params[1] = HttpUtility.ParseQueryString(myUri.Query).Get("ackid");
            Params[2] = HttpUtility.ParseQueryString(myUri.Query).Get("custame");
            Params[3] = HttpUtility.ParseQueryString(myUri.Query).Get("Fname");
            Params[4] = HttpUtility.ParseQueryString(myUri.Query).Get("Mname");// NA
            Params[5] = Utility.GetGenderName(HttpUtility.ParseQueryString(myUri.Query).Get("gender"));
            Params[6] = HttpUtility.ParseQueryString(myUri.Query).Get("Dob").Replace('-', '/');
            Params[7] = HttpUtility.ParseQueryString(myUri.Query).Get("preAddr");//NA|NA
            Params[8] = HttpUtility.ParseQueryString(myUri.Query).Get("rgDate").Replace('-', '/');
            //Params[9] = HttpUtility.ParseQueryString(myUri.Query).Get("Birthplace");            
            //Params[10] = HttpUtility.ParseQueryString(myUri.Query).Get("PerAddr");


            if (!string.IsNullOrEmpty(Params[0])) { WhetherDataFound = true; WebServiceResponseCode = (int)WebServiceResponse.Verified; } else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; }
            if ((WhetherDataFound != false) || (WhetherResponseReceived != false)) { Utility.UpdateTransactionFlags(WhetherDataFound, WhetherResponseReceived, TID); } else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString(); }
            if (WebServiceResponseCode == (int)WebServiceResponse.NotVerified) { return WebServiceResponseCode.ToString(); }

            for (int i = 0; i < 9; i++)
            {
                if (string.IsNullOrEmpty(Params[i])) { Params[i] = "NA"; }
                if (i == 4) { Params[11] += Params[i] + "|NA|"; }//for spouse
                else if (i == 7) { Params[11] += Params[i] + "|NA|NA|"; }//for adarno and validupto
                else { Params[11] += Params[i] + "|"; }
            }
            Params[11] = Params[11].Substring(0, Params[11].Length - 1);

            //WebServiceResponseCode|DocumentNo|TxnId|Name|FatherName|MotherName|SpouseName|Gender|DOB|Address|AadhaarNo|ValidUpto|IssuingDate|IssuingAuthority|DocumentStatus|DeptLogId|DocumentId|DocumentNo|WhetherResponseReceived|WhetherDataFound
            Response = WebServiceResponseCode + "|" + Params[11] + "|NA|NA|NA|" + DocumentId + "|" + DocumentNo + "|" + WhetherResponseReceived + "|" + WhetherDataFound;
            return Response;
        }

        public static string GetEdistrictHaryanaBDResponse(string DocumentNo, string DocumentId)
        {
            string Response = string.Empty;
            int WebServiceResponseCode = 0;
            bool WhetherResponseReceived = false, WhetherDataFound = false;
            string[] Data = null;
            Int64 TID = Utility.InitiateTransactionId(DocumentId, (int)EnclosureDepartment.EdistrictHaryana, DocumentNo);

            string checksumMessage = DocumentNo + "|" + TID.ToString();
            string checksumValue = Utility.GetHMACSHA256(checksumMessage, "EDISTBDDL");

            Edistrict.EdistrictHaryanaBDService.ServiceSoapClient client = new EdistrictHaryanaBDService.ServiceSoapClient();
            Response = client.Document_Verify(DocumentNo, TID.ToString(), "", "", checksumValue);
            if (!string.IsNullOrEmpty(Response))
            {
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(Response);
                var node = doc.SelectSingleNode("/result");
                string strResponse = Utility.GetSeperatedStringFromXML(node.InnerXml, "DocumentVerificationRequest");

                WhetherResponseReceived = true;
                Data = strResponse.Split('|');
                if (Data.Length > 10)
                {
                    WhetherDataFound = true;
                    WebServiceResponseCode = (int)WebServiceResponse.Verified;
                }
                else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; }
            }
            if ((WhetherDataFound != false) || (WhetherResponseReceived != false)) { Utility.UpdateTransactionFlags(WhetherDataFound, WhetherResponseReceived, TID); } else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString(); }

            for (int i = 0; i < Data.Length; i++)
            {
                Data[i] = Data[i].Trim();
                if (string.IsNullOrEmpty(Data[i].ToString().ToString())) { Data[i] = "NA"; }
            }

            Response = WebServiceResponseCode + "|" + Data[0] + "|" + Data[1] + "|" + Data[2] + "|" + Data[6] + "|" + Data[7] + "|" + Data[8] + "|" + Data[5] + "|" + Data[4] + "|" + Data[3] + "|" + Data[9] + "|NA|" + Data[11] + "|" + Data[12] + "|" + Data[13] + "|" + Data[16] + "|" + DocumentId + "|" + DocumentNo + "|" + WhetherResponseReceived + "|" + WhetherDataFound;
            return Response;
        }

        public static string GetEdistrictMizoramResponse(string DocumentNo, string DocumentId)
        {
            string Key = string.Empty, Response = string.Empty;
            int WebServiceResponseCode = 0;
            bool WhetherResponseReceived = false, WhetherDataFound = false;

            Int64 TID = Utility.InitiateTransactionId(DocumentId, (int)EnclosureDepartment.EdistrictMizoram, DocumentNo);
            string Domain = new Uri(HttpContext.Current.Request.Url.AbsoluteUri).GetLeftPart(UriPartial.Authority);
            string RequestURL = "http://edistrict.mizoram.gov.in/mizoeda-webservices/tribalcertverification/tribalcertdetails?certificateNo=" + DocumentNo;
            using (WebClient client = new WebClient()) { Response = client.DownloadString(RequestURL); }

            if (!string.IsNullOrEmpty(Response)) { WhetherResponseReceived = true; }
            if (!Response.TrimStart().StartsWith("<")) { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString(); }

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(Response);
            var node = doc.SelectSingleNode("/output");
            string strResponse = Utility.GetSeperatedStringFromXML(node.InnerXml, "detail");
            string[] Data = strResponse.Split('|');
            if (Data.Length > 0)
            {
                WhetherDataFound = true;
                WebServiceResponseCode = (int)WebServiceResponse.Verified;
            }

            if ((WhetherDataFound != false) || (WhetherResponseReceived != false)) { Utility.UpdateTransactionFlags(WhetherDataFound, WhetherResponseReceived, TID); } else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString(); }
            for (int i = 0; i < Data.Length; i++)
            {
                Data[i] = Data[i].Trim();
                if (string.IsNullOrEmpty(Data[i].ToString().ToString())) { Data[i] = "NA"; }
            }

            //WebServiceResponseCode|DocumentNo|TxnId|Name|FatherName|MotherName|SpouseName|Gender|DOB|Address|AadhaarNo|ValidUpto|IssuingDate|IssuingAuthority|DocumentStatus|DeptLogId|DocumentId|DocumentNo|WhetherResponseReceived|WhetherDataFound
            Response = WebServiceResponseCode + "|" + Data[1] + "|" + TID + "|" + Data[3] + "|" + Data[5] + "|NA|NA|NA|NA|NA|NA|NA|" + Data[2] + "|NA|NA|NA|" + DocumentId + "|" + DocumentNo + "|" + WhetherResponseReceived + "|" + WhetherDataFound;
            return Response;
        }

        public static string GetEdistrictDelhiResponse(string DocumentNo, string DocumentId)
        {
            GetData data = new GetData();
            string Qry = null;
            string Response = string.Empty;
            int WebServiceResponseCode = 0;
            bool WhetherResponseReceived = false, WhetherDataFound = false;
            Int64 TID = Utility.InitiateTransactionId(DocumentId, (int)EnclosureDepartment.EdistrictDelhi, DocumentNo);

            if (DocumentNo.Length == 10)
            {
                Qry = "Select 'False' as WhetherEdistrictData,idno as ApplicationNo,ApplicantName,FName as ApplicantFatherName,'' as ApplicantGender ,to_char(DateOfApplication,'DD/MM/YYYY') as ApplicationDate,ServiceName,Status as trackingstatus,DistName as DistrictName,SubDivName as subdivdescription,deptname,Address as ApplicantAddress from Dbo.ApplicationDetailsEpp AD  where AD.Idno=@ApplicationNo and upper(Status)=@ApplicationStatusId ";
            }
            else if (DocumentNo.Length == 14)
            {
                if (Convert.ToInt32(DocumentNo.ToString().Substring(4, 1)) > 7)
                {
                    Qry = "Select 'False' as WhetherEdistrictData,idno as ApplicationNo,ApplicantName,FName as ApplicantFatherName,'' as ApplicantGender ,to_char(DateOfApplication,'DD/MM/YYYY') as ApplicationDate,ServiceName,Status as trackingstatus,DistName as DistrictName,SubDivName as subdivdescription,deptname,Address as ApplicantAddress from Dbo.ApplicationDetailsEpp AD  where AD.Idno=@ApplicationNo  and upper(Status)=@ApplicationStatusId ";
                }
                else
                {
                    Qry = "select 'True' as WhetherEdistrictData,ApplicationId,ApplicationNo,ApplicantName,ApplicantGender,ApplicantFatherName,ApplicantMotherName,ApplicantHusbandName,to_char(ApplicantDOB,'DD/MM/YYYY') as ApplicantDOB,to_char(ApplicationDate,'DD/MM/YYYY') as ApplicationDate,SM.ServiceName,ST.trackingstatus,DM.DistrictName,SD.subdivdescription,DP.deptname,dbo.displaycompleteaddressfromid(AD.applicanthousenumber,AD.applicantstreetnumber,AD.applicantsublocality,AD.applicantlocalityid,AD.applicantsubdivcode,AD.applicantdistrictcode,AD.stateid,AD.countryid,AD.applicantpincode) as ApplicantAddress FROM dbo.ApplicationDetails AD inner join dbo.ServiceMaster SM on SM.ServiceCode=AD.ServiceCode inner join dbo.StatusMaster ST on ST.StatusId=AD.ApplicationStatusId inner join dbo.districtmaster DM on DM.districtcode=AD.applicationdistrictcode inner join dbo.subdivmaster  SD on SD.subdivcode=AD.applicationsubdivcode inner join dbo.deptmaster DP on DP.deptcode=SM.deptcode where AD.ApplicationNo=@ApplicationNo and ApplicationStatusId=@ApplicationStatusId";
                }
            }
            else
            {
                WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString();
            }
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@ApplicationNo", DocumentNo);
            if (DocumentNo.Length == 10) { Cmd.Parameters.AddWithValue("@ApplicationStatusId", CustomText.ISSUED.ToString()); }
            else if (DocumentNo.Length == 14)
            {
                if (Convert.ToInt32(DocumentNo.ToString().Substring(4, 1)) > 7) { Cmd.Parameters.AddWithValue("@ApplicationStatusId", CustomText.ISSUED.ToString()); }
                else { Cmd.Parameters.AddWithValue("@ApplicationStatusId", (int)Status.ISSUCER); }
            }
            DataTable dt = data.GetDataTable(Cmd);
            if (dt.Rows.Count == 1)
            {
                WhetherResponseReceived = true; WhetherDataFound = true; WebServiceResponseCode = (int)WebServiceResponse.Verified;
                Utility.UpdateTransactionFlags(WhetherDataFound, WhetherResponseReceived, TID);

                if (dt.Rows[0]["WhetherEdistrictData"].ToString() == CustomText.False.ToString())
                {
                    Response = WebServiceResponseCode + "|" + dt.Rows[0]["ApplicationNo"].ToString() + "|" + TID.ToString() + "|" + dt.Rows[0]["ApplicantName"].ToString() + "|" + dt.Rows[0]["ApplicantFatherName"].ToString() + "|NA|NA|" + dt.Rows[0]["ApplicantGender"].ToString() + "|NA|" + dt.Rows[0]["ApplicantAddress"].ToString() + "|NA|NA|" + dt.Rows[0]["ApplicationDate"].ToString() + "|" + dt.Rows[0]["DeptName"].ToString() + "|" + dt.Rows[0]["TrackingStatus"].ToString() + "|NA|" + DocumentId + "|" + DocumentNo + "|" + WhetherResponseReceived + "|" + WhetherDataFound;
                }
                else if (dt.Rows[0]["WhetherEdistrictData"].ToString() == CustomText.True.ToString())
                {

                    Response = WebServiceResponseCode + "|" + dt.Rows[0]["ApplicationNo"].ToString() + "|" + TID.ToString() + "|" + dt.Rows[0]["ApplicantName"].ToString() + "|" + dt.Rows[0]["ApplicantFatherName"].ToString() + "|" + dt.Rows[0]["ApplicantMotherName"].ToString() + "|" + dt.Rows[0]["ApplicantHusbandName"].ToString() + "|" + dt.Rows[0]["ApplicantGender"].ToString() + "|" + dt.Rows[0]["ApplicantDOB"].ToString() + "|" + dt.Rows[0]["ApplicantAddress"].ToString() + "|NA|NA|" + dt.Rows[0]["ApplicationDate"].ToString() + "|" + dt.Rows[0]["DeptName"].ToString() + "|" + dt.Rows[0]["TrackingStatus"].ToString() + "|NA|" + DocumentId + "|" + DocumentNo + "|" + WhetherResponseReceived + "|" + WhetherDataFound;
                }
            }
            else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString(); }
            return Response;
            //WebServiceResponseCode|DocumentNo|TxnId|Name|FatherName|MotherName|SpouseName|Gender|DOB|Address|AadhaarNo|ValidUpto|IssuingDate|IssuingAuthority|DocumentStatus|DeptLogId|DocumentId|DocumentNo|WhetherResponseReceived|WhetherDataFound
        }

        //public static string GetUPEServiceResponse(string DocumentNo, string DocumentId)
        //{
        //    string Response = string.Empty;
        //    int WebServiceResponseCode = 0;
        //    bool WhetherResponseReceived = false, WhetherDataFound = false;
        //    string[] Data = null;
        //    Int64 TID = Utility.InitiateTransactionId(DocumentId, (int)EnclosureDepartment.EdistrictHaryana);

        //    string checksumMessage = DocumentNo + "|" + TID.ToString();
        //    string checksumValue = Utility.GetHMACSHA256(checksumMessage, "EDISTUPDL");

        //    Edistrict.EdistrictUPService.ServiceSoapClient client = new EdistrictUPService.ServiceSoapClient();
        //    XmlNode xmlResponse = client.GetCertificateVerificationDetail("15290030025531", "290331509062");
        //    if (xmlResponse != null)
        //    {
        //        //XmlDocument doc = new XmlDocument();
        //        //doc.LoadXml(Response);
        //        XmlNode node = xmlResponse.SelectSingleNode("/Cetificate");
        //        string strResponse = Utility.GetSeperatedStringFromXML(node.InnerXml, "Detail");

        //        WhetherResponseReceived = true;
        //        Data = strResponse.Split('|');
        //        if (Data.Length > 10)
        //        {
        //            WhetherDataFound = true;
        //            WebServiceResponseCode = (int)WebServiceResponse.Verified;
        //        }
        //        else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; }
        //    }
        //    if ((WhetherDataFound != false) || (WhetherResponseReceived != false)) { Utility.UpdateTransactionFlags(WhetherDataFound, WhetherResponseReceived, TID); } else { WebServiceResponseCode = (int)WebServiceResponse.NotVerified; return WebServiceResponseCode.ToString(); }

        //    for (int i = 0; i < Data.Length; i++)
        //    {
        //        Data[i] = Data[i].Trim();
        //        if (string.IsNullOrEmpty(Data[i].ToString().ToString())) { Data[i] = "NA"; }
        //    }

        //    Response = WebServiceResponseCode + "|" + Data[0] + "|" + Data[1] + "|" + Data[2] + "|" + Data[6] + "|" + Data[7] + "|" + Data[8] + "|" + Data[5] + "|" + Data[4] + "|" + Data[3] + "|" + Data[9] + "|NA|" + Data[11] + "|" + Data[12] + "|" + Data[13] + "|" + Data[16] + "|" + DocumentId + "|" + DocumentNo + "|" + WhetherResponseReceived + "|" + WhetherDataFound;
        //    return Response;
        //}

        public static SelectList FillCourtList()
        {
            ViewDateSoapClient client = new ViewDateSoapClient();
            DataSet dsCourt = new DataSet();
            dsCourt = client.fill_Courts();
            IEnumerable<DataRow> List = dsCourt.Tables[0].AsEnumerable();
            SelectList CourtList = new SelectList(List, "ItemArray[1]", "ItemArray[0]");
            return CourtList;
        }

        public static SelectList FillVillageList()
        {
            ViewDateSoapClient client = new ViewDateSoapClient();
            DataSet dsCourt = new DataSet();
            dsCourt = client.getVillages();
            IEnumerable<DataRow> List = dsCourt.Tables[0].AsEnumerable();
            SelectList CourtList = new SelectList(List, "ItemArray[0]", "ItemArray[1]");
            return CourtList;
        }

        public static SelectList FillSubCourtList(string CourtId)
        {
            ViewDateSoapClient client = new ViewDateSoapClient();
            DataSet dsSubCourt = new DataSet();
            dsSubCourt = client.fill_SubCourts(CourtId);
            IEnumerable<DataRow> List = dsSubCourt.Tables[0].AsEnumerable();
            SelectList SubCourtList = new SelectList(List, "ItemArray[0]", "ItemArray[1]");
            return SubCourtList;
        }
        public static DataTable GetVillageCourtCases(string VillageId)
        {
            DataSet dsResponse = new DataSet();
            try
            {
                ViewDateSoapClient client = new ViewDateSoapClient();
                dsResponse = client.getRegisteredCasesByVillage(VillageId);
            }
            catch
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("Status", typeof(string));
                dt.Rows.Add("0NotFound0");
                return dt;
            }
            return dsResponse.Tables[0];
        }
        public static DataTable GetVillageCourt(string VillageId, string SubCourtId, string Section)
        {
            DataSet dsResponse = new DataSet();
            try
            {
                ViewDateSoapClient client = new ViewDateSoapClient();
                dsResponse = client.getCasesByVillage(VillageId, SubCourtId, Section);
            }
            catch
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("Status", typeof(string));
                dt.Rows.Add("0NotFound0");
                return dt;
            }
            return dsResponse.Tables[0];
        }

        public static DataTable GetVillageKhasraCourtCases(string VillageId, string KhasraNo)
        {
            DataSet dsResponse = new DataSet();
            try
            {
                ViewDateSoapClient client = new ViewDateSoapClient();
                dsResponse = client.getRegisteredCasesByVillageWithKhasra(VillageId, KhasraNo);
            }
            catch
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("Status", typeof(string));
                dt.Rows.Add("0NotFound0");
                return dt;
            }
            return dsResponse.Tables[0];
        }
        public static DataTable GetVillageKhasraCourt(string VillageId, string Khasra, string SubCourtId, string Section)
        {
            DataSet dsResponse = new DataSet();
            try
            {
                ViewDateSoapClient client = new ViewDateSoapClient();
                dsResponse = client.getCasesByVillageWithKhasra(VillageId, SubCourtId, Section, Khasra);
            }
            catch
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("Status", typeof(string));
                dt.Rows.Add("0NotFound0");
                return dt;
            }
            return dsResponse.Tables[0];
        }
        public static DataTable GetCourtCasesPending()
        {
            DataSet dsResponse = new DataSet();
            try
            {
                ViewDateSoapClient client = new ViewDateSoapClient();
                dsResponse = client.getPendingCasesCountByCourtName();
            }
            catch
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("Status", typeof(string));
                dt.Rows.Add("0NotFound0");
                return dt;
            }
            return dsResponse.Tables[0];
        }
        public static DataTable GetCourtCasesPendingDetail(string SubCourtId)
        {
            DataSet dsResponse = new DataSet();
            try
            {
                ViewDateSoapClient client = new ViewDateSoapClient();
                dsResponse = client.getPendingCasesDetailByCourtName(SubCourtId);
            }
            catch
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("Status", typeof(string));
                dt.Rows.Add("0NotFound0");
                return dt;
            }
            return dsResponse.Tables[0];
        }
        public static DataTable GetCourtCasesResponse(string CaseNo, string CourtId, string SubCourtId, string NDOH, string CaseTitle, string FPartyName, string Section, int Type, string[] arrCase)
        {
            DataSet dsResponse = new DataSet();
            try
            {
                ViewDateSoapClient client = new ViewDateSoapClient();
                if (Type == (int)CountList.Type001) { dsResponse = client.Case_List(NDOH, CourtId, SubCourtId); }
                else if (Type == (int)CountList.Type002)
                {
                    if (!string.IsNullOrEmpty(CaseNo)) { dsResponse = client.ProceedingDetails(CaseNo); }
                    else { dsResponse = client.SearchedCasesList(CaseNo, CourtId, SubCourtId, Utility.GetDateYYYYMMDD(NDOH, '/', "0/1/2"), CaseTitle, FPartyName, Section); }
                }
                else if (Type == (int)CountList.Type003) { dsResponse = client.Judgement_Details(CaseNo, CourtId, SubCourtId); }
                else if (Type == (int)CountList.Type004) { dsResponse = client.AllCases(); }
                else if (Type == (int)CountList.Type005)
                {
                    string fromdt = string.Empty, todt = string.Empty, deptmt = string.Empty, casetype = string.Empty, subdept = string.Empty, flag = string.Empty,
                    sbcode = string.Empty, rblrvalue = string.Empty, rbldvalue = string.Empty, fromdtfl = string.Empty, todtfl = string.Empty, court = string.Empty, subcourt = string.Empty;

                    if (arrCase != null)
                    {
                        fromdt = arrCase[5]; todt = arrCase[6]; deptmt = arrCase[0]; casetype = arrCase[2]; subdept = arrCase[8]; flag = arrCase[4];
                        sbcode = arrCase[11]; rblrvalue = ""; rbldvalue = ""; fromdtfl = arrCase[12]; todtfl = arrCase[13]; court = arrCase[1]; subcourt = arrCase[10];
                    }

                    dsResponse = client.CaseStatistics(fromdt, todt, deptmt, CourtId, casetype, subdept, flag, sbcode, rblrvalue, rbldvalue, fromdtfl, todtfl, SubCourtId);
                }
                else if (Type == (int)CountList.Type006)
                {
                    string fromdt = string.Empty, todt = string.Empty, deptmt = string.Empty, casetype = string.Empty, subdept = string.Empty, flag = string.Empty, status = string.Empty,
                    sbcode = string.Empty, rblrvalue = string.Empty, rbldvalue = string.Empty, fromdtfl = string.Empty, todtfl = string.Empty, court = string.Empty, subcourt = string.Empty,
                    flag1 = string.Empty;

                    if (arrCase != null)
                    {
                        fromdt = arrCase[5]; todt = arrCase[6]; deptmt = arrCase[0]; casetype = arrCase[2]; subdept = arrCase[8]; flag = arrCase[4]; flag1 = arrCase[7];
                        sbcode = arrCase[11]; rblrvalue = ""; rbldvalue = ""; fromdtfl = arrCase[12]; todtfl = arrCase[13]; court = arrCase[1]; subcourt = arrCase[10];
                        status = arrCase[3];
                    }
                    dsResponse = client.CaseDetailRpt(deptmt, court, subcourt, status, casetype, "", "", flag, fromdt, todt, flag1, subdept, sbcode, "", "", "", "", fromdtfl, todtfl);
                    //dept, court, subcourtid, status, casetype, counselname, courtname, flag, frmdt, todt, flag1, subdept, sbcode, Session["usertype"].ToString().Trim(), Session["deptcode"].ToString().Trim(), Session["bcode"].ToString(), Session["userid"].ToString().Trim(),fromdtfl,todtfl
                }
            }
            catch
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("Status", typeof(string));
                dt.Rows.Add("0NotFound0");
                return dt;
            }
            return dsResponse.Tables[0];
        }

        public static DataTable getCaseCountDofYearwise(string InstitutedYear)
        {
            DataSet dsResponse = new DataSet();
            try
            {
                ViewDateSoapClient client = new ViewDateSoapClient();
                dsResponse = client.getCaseCountDofYearwise(InstitutedYear);
            }
            catch
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("Status", typeof(string));
                dt.Rows.Add("0NotFound0");
                return dt;
            }
            return dsResponse.Tables[0];
        }
        public static DataTable getCaseDetailsDofYearwise(string subcourtid, string InstitutedYear)
        {
            DataSet dsResponse = new DataSet();
            try
            {
                ViewDateSoapClient client = new ViewDateSoapClient();
                dsResponse = client.getCasesByDofYearwise(subcourtid, InstitutedYear);
            }
            catch
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("Status", typeof(string));
                dt.Rows.Add("0NotFound0");
                return dt;
            }
            return dsResponse.Tables[0];
        }
        public static DataTable getCasesSectionWise()
        {
            DataSet dsResponse = new DataSet();
            try
            {
                ViewDateSoapClient client = new ViewDateSoapClient();
                dsResponse = client.getCasesSectionWise();
            }
            catch
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("Status", typeof(string));
                dt.Rows.Add("0NotFound0");
                return dt;
            }
            return dsResponse.Tables[0];
        }


        public static string GetNDPLResponse(string CANo)
        {
            string[] Data = null;
            string ResponseList = string.Empty, ChkResponse = string.Empty;

            string CAMd5 = FormsAuthentication.HashPasswordForStoringInConfigFile(CANo, "md5").ToString().ToLower();

            string Key = CAMd5.Substring(CAMd5.Length - 3, 1);
            int newKey = Utility.convertToASCII(Key);
            string secureString = Utility.convertStringToHex(CANo, newKey);

            Edistrict.NdplService.ServiceSoapClient client = new Edistrict.NdplService.ServiceSoapClient();
            //Get Bill details here
            string Response = client.getbilldetails(secureString, CAMd5);
            if (Response == (((int)CustomValue.Forbidden).ToString())) { return Response; }
            string PlanResponse = Utility.convertHexToString(Response, newKey);

            if (!string.IsNullOrEmpty(PlanResponse))
            {
                string DataCheck = string.Empty;
                Data = PlanResponse.Split('#');
                ResponseList = Data[0].ToString() + "|" + Data[1].ToString() + "|" + Data[2].ToString() + "|" + Data[3].ToString();
            }
            return ResponseList;
        }

        #endregion WebService
    }
}