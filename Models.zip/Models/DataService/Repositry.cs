﻿using System;
using System.Web;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Text;
using Edistrict.Models.CustomAttribute;
using Npgsql;

namespace Edistrict.Models.DataService
{
    public abstract class Repositry<T>
    {
        public static E Get<E>(E Type, NpgsqlCommand cmd)
        {
            Type type = typeof(E);
            PropertyInfo[] properties = type.GetProperties();
            DataTable dt = new GetData().GetDataTable(cmd);
            if (dt.Rows.Count > 1)
                throw new Exception("Query returns more then one row.");
            if (dt.Rows.Count == 0)
                return Type;
            foreach (PropertyInfo property in properties)
            {
                if (dt.Columns.Contains(property.Name) && !String.IsNullOrEmpty(dt.Rows[0][property.Name].ToString()))
                {
                    string Subtyp = property.PropertyType.ToString();
                    object va = dt.Rows[0][property.Name].ToString();
                    object convertedValue = null;
                    if (property.PropertyType.FullName.ToString().Contains("System.Nullable"))
                        convertedValue = System.Convert.ChangeType(va, Nullable.GetUnderlyingType(property.PropertyType));
                    else
                        convertedValue = System.Convert.ChangeType(va, property.PropertyType);
                    property.SetValue(Type, convertedValue, null);
                }
            }
            return Type;
        }
        public static S GetInstance<S>(string type) { return (S)Activator.CreateInstance(Type.GetType(type)); }
        public static List<E> List<E>(NpgsqlCommand cmd) where E : new()
        {
            List<E> list = new System.Collections.Generic.List<E>();
            Type type = typeof(E);
            PropertyInfo[] properties = type.GetProperties();
            DataTable dt = new GetData().GetDataTable(cmd);
            int i = 0;
            foreach (DataRow row in dt.Rows)
            {
                E instance = (E)GetInstance<E>(type.ToString());
                foreach (PropertyInfo property in properties)
                {

                    if (dt.Columns.Contains(property.Name) && !String.IsNullOrEmpty(dt.Rows[i][property.Name].ToString()))
                    {
                        string Subtyp = property.PropertyType.ToString();
                        object va = dt.Rows[i][property.Name].ToString();

                        object convertedValue = null;
                        if (Subtyp == "System.String")
                            convertedValue = System.Convert.ChangeType(va, property.PropertyType);
                        else
                            convertedValue = System.Convert.ChangeType(va, Nullable.GetUnderlyingType(property.PropertyType));
                        property.SetValue(instance, convertedValue, null);
                    }

                }
                i += 1;
                list.Add(instance);
            }
            return list;
        }
        public NpgsqlCommand GetUpdateCmd<E>(E Type, string WhereCondition)
        {
            Type type = typeof(E);
            PropertyInfo[] properties = type.GetProperties();
            string[] ColumnNames = new string[properties.Length];
            string[] ColumnValues = new string[properties.Length];
            StringBuilder values = new StringBuilder("");
            StringBuilder whereCondition = new StringBuilder(" Where ");
            NpgsqlCommand cmd = new NpgsqlCommand("");
            int i = 0;
            foreach (PropertyInfo property in properties)
            {
                object obj = property.GetValue(Type, null);
                if (obj != null)
                {
                    string val = property.GetValue(Type, null).ToString();
                    values.Append(property.Name.ToString() + " = @" + property.Name.ToString() + ",");
                    if (property.PropertyType.FullName.ToString().Contains("System.DateTime"))
                    {
                        val = Convert.ToDateTime(val).ToString("yyyyMMdd");
                        cmd.Parameters.AddWithValue("@" + property.Name.ToString(), val);
                    }
                    else
                        cmd.Parameters.AddWithValue("@" + property.Name.ToString(), val);
                }
                i += 1;
            }
            string vals = values.ToString();
            vals = vals.Substring(0, vals.Length - 1);
            StringBuilder InsertQuery = new StringBuilder(" Update " + type.Name.ToString() + " set " + vals + " " + WhereCondition);
            cmd.CommandText = InsertQuery.ToString();
            return cmd;
        }
        public NpgsqlCommand GetInsertCmd<E>(E Type)
        {
            Type type = typeof(E);
            PropertyInfo[] properties = type.GetProperties();
            string[] ColumnNames = new string[properties.Length];
            string[] ColumnValues = new string[properties.Length];
            StringBuilder columns = new StringBuilder("");
            StringBuilder values = new StringBuilder();
            NpgsqlCommand cmd = new NpgsqlCommand("");
            int i = 0;
            foreach (PropertyInfo property in properties)
            {
                object[] attributes = property.GetCustomAttributes(true);
                if (attributes.Length > 0 && attributes[0] is CustomProperty)
                    continue;
                object obj = property.GetValue(Type, null);
                if (obj != null)
                {
                    string val = property.GetValue(Type, null).ToString();
                    columns.Append(" " + property.Name.ToString() + ",");
                    values.Append(" @" + property.Name.ToString() + ",");


                    if (property.PropertyType.FullName.ToString().Contains("System.DateTime"))
                    {
                        val = Convert.ToDateTime(val).ToString("yyyyMMdd");
                        cmd.Parameters.AddWithValue("@" + property.Name.ToString(), val);
                    }
                    else
                        cmd.Parameters.AddWithValue("@" + property.Name.ToString(), val);
                }
                i += 1;
            }

            string col = columns.ToString();
            string vals = values.ToString();
            col = col.Substring(0, col.Length - 1);
            vals = vals.Substring(0, vals.Length - 1);

            StringBuilder InsertQuery = new StringBuilder(" Insert into " + type.Name.ToString() + " (" + col + ") values (" + vals + ") ");
            cmd.CommandText = InsertQuery.ToString();
            return cmd;
        }
        public int Add(T Type)
        {
            Type type = typeof(T);
            PropertyInfo[] properties = type.GetProperties();
            string[] ColumnNames = new string[properties.Length];
            string[] ColumnValues = new string[properties.Length];
            StringBuilder cols = new StringBuilder();
            StringBuilder vals = new StringBuilder();
            NpgsqlCommand cmd = new NpgsqlCommand();
            int i = 0;
            foreach (PropertyInfo property in properties)
            {
                object obj = property.GetValue(Type, null);
                if (obj != null)
                {
                    if ((i + 1) != ColumnNames.Length)
                    {
                        cols.Append(property.Name + ",");
                        vals.Append("@" + property.Name + ",");
                        cmd.Parameters.AddWithValue("@" + property.Name, property.GetValue(Type, null).ToString());
                    }
                    else
                    {
                        cols.Append(property.Name);
                        vals.Append("@" + property.Name);
                        cmd.Parameters.AddWithValue("@" + property.Name, property.GetValue(Type, null).ToString());
                    }
                }
                i = i + 1;
            }
            cmd.CommandText = "INSERT INTO " + type.Name + " (" + cols.ToString() + ") " + " VALUES (" + vals.ToString() + ")";
            return new GetData().UpdateData(cmd);
        }

    }
}