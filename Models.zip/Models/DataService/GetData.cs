﻿using System;
using System.Web;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using Edistrict.Models.ApplicationService;
using Npgsql;
using System.Web.Mvc;
using Edistrict.Models.CustomClass;

namespace Edistrict.Models.DataService
{
    public class GetData
    {
        private static string ConStr = ConfigurationManager.ConnectionStrings["ConStrEdistrict"].ConnectionString.ToString();
        public int UpdateData(NpgsqlCommand cmd)
        {
            int rowsInserted = 0;
            using (NpgsqlConnection con = new NpgsqlConnection(ConStr))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                foreach (NpgsqlParameter Parameter in cmd.Parameters) {
                    if (Parameter.Value == null) { 
                        Parameter.Value = DBNull.Value; 
                    }
                }
                cmd.Connection = con;
                cmd.CommandTimeout = 30;
                rowsInserted = cmd.ExecuteNonQuery();
                con.Close();
            }
            return rowsInserted;
        }
        public int SaveData(List<NpgsqlCommand> cmdList)
        {
            int rowsInserted = 0, rowindex = 0;
            NpgsqlConnection con = new NpgsqlConnection(ConStr);
            if (con.State == ConnectionState.Closed)
                con.Open();
            NpgsqlTransaction transaction = con.BeginTransaction();
            try
            {
                foreach (NpgsqlCommand cmd in cmdList)
                {
                    foreach (NpgsqlParameter Parameter in cmd.Parameters) { if (Parameter.Value == null) { Parameter.Value = DBNull.Value; } }
                    cmd.Connection = con;
                    cmd.CommandTimeout = 30;
                    cmd.Transaction = transaction;
                    rowsInserted += cmd.ExecuteNonQuery();
                    rowindex = rowindex + 1;
                }
                transaction.Commit();
            }
            catch (Exception exce)
            {
                transaction.Rollback();
                rowsInserted = 0;
                throw exce;
            }
            finally
            {
                con.Close();
            }
            return rowsInserted;
        }
        public DataTable GetDataTable(NpgsqlCommand cmd)
        {
            DataTable dt = new DataTable();
            using (NpgsqlConnection con = new NpgsqlConnection(ConStr))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                cmd.Connection = con;
                cmd.CommandTimeout = 120;
                NpgsqlDataAdapter sda = new NpgsqlDataAdapter(cmd);
                sda.Fill(dt);
                con.Close();
            }
            return dt;
        }
        public string[] SelectColumns(NpgsqlCommand cmd)
        {
            using (NpgsqlConnection con = new NpgsqlConnection(ConStr))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                foreach (NpgsqlParameter Parameter in cmd.Parameters)
                {
                    if (Parameter.Value == null)
                    { Parameter.Value = DBNull.Value; }
                }

                cmd.Connection = con;
                cmd.CommandTimeout = 30;
                NpgsqlDataAdapter sda = new NpgsqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                string[] col = new string[dt.Columns.Count];
                for (int i = 0; i < col.Length && dt.Rows.Count > 0; i++)
                    col[i] = dt.Rows[0][i].ToString();
                con.Close();
                return col;
            }
        }
        public Int64[] SaveTransactionalData(List<NpgsqlCommand> cmdList)
        {
            Int64 LastInsertedId = 0;
            int rowsInserted = 0, rowindex = 0;
            NpgsqlCommand cmd = new NpgsqlCommand();
            NpgsqlConnection con = new NpgsqlConnection(ConStr);
            if (con.State == ConnectionState.Closed)
                con.Open();
            NpgsqlTransaction transaction = con.BeginTransaction();
            try
            {
                for (int i = 0; i < cmdList.Count; i++)
                {
                    cmd = cmdList[i];
                    foreach (NpgsqlParameter Parameter in cmd.Parameters) { if (Parameter.Value == null) { Parameter.Value = DBNull.Value; } }
                    cmd.Connection = con;
                    cmd.CommandTimeout = 30;
                    cmd.Transaction = transaction;
                    if (i == 0) {
                        NpgsqlDataAdapter objAdapter = new NpgsqlDataAdapter(cmd);
                        DataTable objTable = new DataTable();
                        objAdapter.Fill(objTable);
                        LastInsertedId = Convert.ToInt64(objTable.Rows[0][0].ToString());
                        rowindex = rowindex + 1;
                    } else {
                        if (LastInsertedId != 0) { cmd.Parameters.AddWithValue("@LastInsertedId", LastInsertedId); }
                        rowsInserted += cmd.ExecuteNonQuery();
                        rowindex = rowindex + 1;
                    }
                }
                transaction.Commit();
            }
            catch (Exception exce)
            {
                transaction.Rollback();
                rowsInserted = 0;
                throw exce;
            }
            finally
            {
                con.Close();
            }
            return new Int64[] { rowsInserted, LastInsertedId };
        }
        public Int64[] SaveTransactionalDataCustom(List<CMDInfoList> cmdList)
        {
            int rowsInserted = 0, rowindex = 0;
            NpgsqlCommand cmd = new NpgsqlCommand();
            CMDInfoList CMDInfo = new CMDInfoList();
            NpgsqlConnection con = new NpgsqlConnection(ConStr);
            if (con.State == ConnectionState.Closed)
                con.Open();
            NpgsqlTransaction transaction = con.BeginTransaction();
            string[] ArrParameter = new string[cmdList.Count];
            try
            {
                for (int i = 0; i < cmdList.Count; i++)
                {
                    CMDInfo = cmdList[i];
                    foreach (NpgsqlParameter Parameter in CMDInfo.Cmd.Parameters) { if (Parameter.Value == null) { Parameter.Value = DBNull.Value; } }
                    CMDInfo.Cmd.Connection = con;
                    CMDInfo.Cmd.CommandTimeout = 30;
                    CMDInfo.Cmd.Transaction = transaction;
                    if (CMDInfo.Returns == true)
                    {
                        if (CMDInfo.ParamenterIndex != null)
                        {
                            for (int j = 0; j < CMDInfo.ParamenterIndex.Length; j++)
                            {
                                CMDInfo.Cmd.Parameters.AddWithValue("@Parameter" + CMDInfo.ParamenterIndex[j], ArrParameter[Convert.ToInt16(CMDInfo.ParamenterIndex[j])]);
                            }
                        }
                        NpgsqlDataAdapter objAdapter = new NpgsqlDataAdapter(CMDInfo.Cmd);
                        DataTable objTable = new DataTable();
                        objAdapter.Fill(objTable);
                        ArrParameter[i] = objTable.Rows[0][0].ToString();
                        rowindex = rowindex + 1;
                    }
                    else
                    {
                        if (CMDInfo.ParamenterIndex != null)
                        {
                            for (int j = 0; j < CMDInfo.ParamenterIndex.Length; j++)
                            {
                                CMDInfo.Cmd.Parameters.AddWithValue("@Parameter" + CMDInfo.ParamenterIndex[j], ArrParameter[Convert.ToInt16(CMDInfo.ParamenterIndex[j])]);
                            }
                        }
                        rowsInserted += CMDInfo.Cmd.ExecuteNonQuery();
                        rowindex = rowindex + 1;
                    }
                }
                transaction.Commit();
            }
            catch (Exception exce)
            {
                transaction.Rollback();
                rowsInserted = 0;
                throw exce;
            }
            finally
            {
                con.Close();
            }
            if (ArrParameter[0] == null) {
                return new Int64[] { rowsInserted, 0 };
            } else {
                return new Int64[] { rowsInserted, Convert.ToInt64(ArrParameter[0].ToString()) };
            }
        }
    }
}