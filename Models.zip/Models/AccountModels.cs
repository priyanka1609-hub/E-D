﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Web;
using System.Web.Mvc;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.Entities;
using Edistrict.Models.CustomClass;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.DataService;
using System.Data;
using Npgsql;

namespace Edistrict.Models
{
    //public class UsersContext : DbContext
    //{
    //    public UsersContext() : base("EdistrictConnection")
    //    {
    //    }
    //    public DbSet<UserProfile> UserProfiles { get; set; }
    //}

    //[Table("UserProfile")]
    //public class UserProfile
    //{
    //    [Key]
    //    [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
    //    public int UserId { get; set; }
    //    public string UserName { get; set; }
    //}

    //public class RegisterExternalLoginModel
    //{
    //    [Required]
    //    [Display(Name = "User name")]
    //    public string UserName { get; set; }
    //    public string ExternalLoginData { get; set; }
    //}

    public class LocalPasswordModel
    {
        public virtual string UserName { get; set; }
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Current password")]
        public virtual string OldPassword { get; set; }
        [Required]
        [StringLength(250, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 8)]
        [DataType(DataType.Password)]
        [Display(Name = "New password")]
        public virtual string NewPassword { get; set; }
        [DataType(DataType.Password)]
        [Display(Name = "Confirm new password")]
        [Compare("NewPassword", ErrorMessage = "The new password and confirmation password do not match.")]
        public virtual string ConfirmPassword { get; set; }
        [Required]
        public virtual string LoginPasswordType { get; set; }
    }

    public class LocalUserIdModel
    {
        [Required]
        public virtual string OldUserId { get; set; }
        [Required]
        public virtual string NewUserId { get; set; }
        [Compare("NewUserId", ErrorMessage = "The new UserId and confirmation UserId do not match.")]
        public virtual string ConfirmUserId { get; set; }
    }

    public class LoginModel
    {
        [Required]
        [Display(Name = "User Id")]
        [StringLength(20, MinimumLength = 4, ErrorMessage = "Enter Valid User-Id")]
        [RegularExpression("([A-Za-z0-9]+)", ErrorMessage = "UserName can only be AlphaNumenric")]
        public virtual string CitizenUserName { get; set; }
        [Required]
        [Display(Name = "User Id")]
        [StringLength(20, MinimumLength = 4, ErrorMessage = "Enter Valid User-Id")]
        public virtual string EmployeeUserName { get; set; }
        [Required]
        [Display(Name = "OTP")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid OTP")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid OTP")]
        public virtual string OTP { get; set; }
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public virtual string Password { get; set; }
        [Display(Name = "Remember me?")]
        public virtual bool RememberMe { get; set; }
        public virtual string user { get; set; }
        [Required]
        public virtual string Captcha { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string certificationChain { get; set; }
        public virtual string fromdate { get; set; }
        public virtual string tilldate { get; set; }
        public virtual string serialnum { get; set; }
        public virtual string textname { get; set; }
        public virtual string TextArea_detail { get; set; }
        public virtual string FilePath { get; set; }
        public virtual string WhetherActive { get; set; }
        public virtual string ClientTimeZone { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Please agree to the terms by checking the checkbox to continue")]
        public virtual bool AcceptDeclaration { get; set; }
        public virtual string DeptName { get; set; }
        public virtual string DeptCode { get; set; }
        public virtual string CustomText { get; set; }
        public virtual string Flag { get; set; }
        public virtual DataTable data { get; set; }
        public virtual UserDigitalMaster UserDigitalMaster { get; set; }
        public virtual DigitalCardTypeMaster DigitalCardTypeMaster { get; set; }
    }

    public class RegisterModel
    {
        public virtual RegistrationMaster RegistrationMaster { get; set; }
        public virtual RegistrationMasterTemp RegistrationMasterTemp { get; set; }
        public virtual ApplicantReciept ApplicantReciept { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual System.Nullable<int> RegistrationId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SahayakId { get; set; }
        [StringLength(256, MinimumLength = 2, ErrorMessage = "Enter Valid Document No")]
        public virtual string AadhaarNo { get; set; }
        [StringLength(256, MinimumLength = 2, ErrorMessage = "Enter Valid Document No")]
        public virtual string DocumentNo { get; set; }
        [Required(ErrorMessage = "Select one Document.")]
        public virtual string DocId { get; set; }
        [Required(ErrorMessage = "Please Enter Locality")]
        public virtual string LocalityName { get; set; }
        [Required(ErrorMessage = "Please Capture/Upload Photo")]
        public virtual string PhotoSource { get; set; }
        [RequiredIf("PhotoSource", "C", ErrorMessage = "Plesae Capture Image")]
        public virtual string PhotoData { get; set; }
        [Required(ErrorMessage = "Captcha Required")]
        public string FirstCaptcha { get; set; }
        [Required(ErrorMessage = "Captcha Required")]
        public virtual string SecondCaptcha { get; set; }
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationId { get; set; }
        public virtual string ServiceCode { get; set; }
        public DataTable data { get; set; }
        [RequiredIf("PhotoSource", "U", ErrorMessage = "Please Upload Scan Photo")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg" }, MaxContentLength = (int)LengthList.AppLength, MaxFileLength = (int)LengthList.AppPhoto, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase ApplicantPhoto { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Check Box Checked Required")]
        public virtual bool check { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Check Box Checked Required")]
        public virtual bool consentcheck { get; set; }
        [Required(ErrorMessage = "Value Required")]        
        public virtual string consentcheckid { get; set; }
        public virtual int ResendAttempt { get; set; }
        [Required(ErrorMessage = "OTP Required")]
        public virtual string OTPGet { get; set; }
        [Required(ErrorMessage = "OTP Required")]
        public virtual string OTPPost { get; set; }
        public virtual SelectList AllLocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.whetheractive=@whetheractive and lm.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        public virtual SelectList LocalityList
        {
            get
            {
                string Qry = "select lm.LocalityId,lm.LocalityName from dbo.LocalityMaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and dm.stateid=@stateid and ls.whetheractive=@whetheractive and lm.whetheractive=@whetheractive";
                if (Sessions.getEmployeeUser() != null) { if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and sd.SubDivCode in (@ParamSubDivCode)"; } }
                Qry += " order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        public virtual SelectList DocumentAvailableAtCitizen
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select DocumentId,DocumentName from dbo.DocumentMaster where DocumentId in (@VoterID,@AadhaarCard) order by DocumentName");
                Cmd.Parameters.AddWithValue("@VoterID", (int)DocumentId.VoterID);
                Cmd.Parameters.AddWithValue("@AadhaarCard", (int)DocumentId.AadhaarCard);
                List<DocumentMaster> DocumentMasterList = DocumentMaster.List<DocumentMaster>(Cmd);
                return new SelectList(DocumentMasterList, "DocumentId", "DocumentName");
            }
            set { }
        }
        public virtual SelectList DocumentAvailableForAddProfile
        {
            get
            {
                //NpgsqlCommand Cmd = new NpgsqlCommand("select DocumentId,DocumentName from dbo.DocumentMaster where DocumentId in (@Passport,@AadhaarCard,@StudentId,@Birth) order by DocumentName");
                NpgsqlCommand Cmd = new NpgsqlCommand("select DocumentId,DocumentName from dbo.DocumentMaster where DocumentId in (@AadhaarCard) order by DocumentName");
                //Cmd.Parameters.AddWithValue("@Passport", (int)DocumentId.Passport);
                Cmd.Parameters.AddWithValue("@AadhaarCard", (int)DocumentId.AadhaarCard);
                //Cmd.Parameters.AddWithValue("@StudentId", (int)DocumentId.StudentId);
                //Cmd.Parameters.AddWithValue("@Birth", (int)DocumentId.BirthCertificate);
                List<DocumentMaster> DocumentMasterList = DocumentMaster.List<DocumentMaster>(Cmd);
                return new SelectList(DocumentMasterList, "DocumentId", "DocumentName");
            }
            set { }
        }
        public virtual SelectList RelationList
        {
            get
            {
                List<RelationMaster> RelationList = RelationMaster.List<RelationMaster>(new Npgsql.NpgsqlCommand("select RelationId,RelationName from RelationMaster where whetheractive=true and relationid in (4,23) order by RelationName"));
                return new SelectList(RelationList, "RelationId", "RelationName");
            }
            set { }
        }
        public virtual SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }        
    }

    public class ForgetPasswordModel
    {
        [Required(ErrorMessage = "Captcha Required")]
        public virtual string Captcha { get; set; }
        [Required(ErrorMessage = "User Id Required")]
        public virtual string UserId { get; set; }
        public virtual string UserType { get; set; }
        [Required(ErrorMessage = "Mobile No Required")]
        [Display(Name = "Mobile No")]
        public virtual string ContactNo { get; set; }
        [Display(Name = "Mobile No")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string ApplicantMobileNo { get; set; }
        [Required(ErrorMessage = "Document No Required")]
        public virtual string DocumentNo { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [Required(ErrorMessage = "Date Of Birth Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DOB { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [Required(ErrorMessage = "Date of Joining Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DateofJoining { get; set; }
        [Required(ErrorMessage = "Registration Id Required")]
        public virtual string RegistrationId { get; set; }
        public virtual string LoginType { get; set; }
        //public virtual string TransType { get; set; }
        public virtual string PassTypeId { get; set; }
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Current password")]
        public virtual string CurrentPassword { get; set; }
        public virtual RegistrationMaster RegistrationMaster { get; set; }
    }

    public class ResetForgetPasswordModel
    {
        public virtual string UserName { get; set; }
        [Required]
        [StringLength(250, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 8)]
        [DataType(DataType.Password)]
        [Display(Name = "New password")]
        public virtual string NewPassword { get; set; }
        [DataType(DataType.Password)]
        [Display(Name = "Confirm new password")]
        [Compare("NewPassword", ErrorMessage = "The new password and confirmation password do not match.")]
        public virtual string ConfirmPassword { get; set; }
        [Display(Name = "OTP")]
        public virtual string OTP { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string ApplicantMobileNo { get; set; }
        public virtual string UserType { get; set; }
        public virtual string PassTypeId { get; set; }
        public virtual string UserId { get; set; }
        public virtual string RegistrationId { get; set; }
        public virtual bool WhetherAllowSms { get; set; }
        public virtual RegistrationMaster RegistrationMaster { get; set; }
    }

    public class ResetForgetUserIdModel
    {
        [Required(ErrorMessage = "User Id Required")]
        [RegularExpression("(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)", ErrorMessage = "User-Id must be aplha numeric")]
        public virtual string NewUserId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [Compare("NewUserId", ErrorMessage = "The new UserId and confirmation UserId do not match.")]
        public virtual string ConfirmUserId { get; set; }

        public virtual string OTP { get; set; }
        public virtual string UserType { get; set; }
        public virtual string DocumentNo { get; set; }
        public virtual string DOB { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string ApplicantMobileNo { get; set; }
        public virtual RegistrationMaster RegistrationMaster { get; set; }
    }

    public class DocumentModel : Repositry<DocumentModel>
    {
        [Required(ErrorMessage = "Profile Required")]
        public virtual string RegistrationId { get; set; }
        public virtual string EnclosureId { get; set; }
        public virtual string ReferenceEnclosureId { get; set; }
        public virtual string ApplicationId { get; set; }
        public virtual string ServiceCode { get; set; }
        [Required(ErrorMessage = "Select atleast one profile ")]
        public virtual string ProfileId { get; set; }

        [RequiredIf("UpdateDocumentId", "null", ErrorMessage = "Select a document")]
        public virtual string DocumentId { get; set; }
        public virtual string UpdateDocumentId { get; set; }
        public virtual string DocumentName { get; set; }

        public string[] VerificationResponse { get; set; }
        
        [Required(ErrorMessage = "Please select department")]
        public virtual string DepartmentId { get; set; }
        public virtual string DeptName { get; set; }

        [Required(ErrorMessage = "Please enter document no.")]
        [StringLength(25, MinimumLength = 2, ErrorMessage = "Enter Valid DocumentNo.")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\-[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string DocumentNo { get; set; }

        public virtual string WhetherVerified { get; set; }
        public virtual string PhotoData { get; set; }
        public virtual string VerifyValueId { get; set; }
        public DataTable data { get; set; }
        public DataTable data2 { get; set; }
        [Required(ErrorMessage = "Please Upload File")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg", "application/pdf" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg", ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase ApplicantFile { get; set; }
        
        [BooleanMustBeTrue(ErrorMessage = "Check Box Checked Required")]
        public virtual bool consentcheck { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string consentcheckid { get; set; }

        public virtual ApplicantEnclosureDetails ApplicantEnclosureDetails { get; set; }

        public SelectList RegDocumentList
        {
            get
            {
                string Qry = "select DocumentId,DocumentName from dbo.DocumentMaster where whetherallowglobalupload=TRUE and DocumentId in (@Aadhaar,@Voter) order by DocumentName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@Aadhaar", 1);
                Cmd.Parameters.AddWithValue("@Voter", 36);
                //Cmd.Parameters.AddWithValue("@PAN", 27);
                //Cmd.Parameters.AddWithValue("@DL", 13);
                List<DocumentMaster> RegDocumentList = DocumentMaster.List<DocumentMaster>(Cmd);
                return new SelectList(RegDocumentList, "DocumentId", "DocumentName");
            }
            set { }
        }
        public SelectList DocumentList
        {
            get
            {
                List<DocumentMaster> DocumentList = DocumentMaster.List<DocumentMaster>(new Npgsql.NpgsqlCommand("select DocumentId,DocumentName from dbo.DocumentMaster where whetherallowglobalupload=TRUE order by DocumentName"));
                return new SelectList(DocumentList, "DocumentId", "DocumentName");
            }
            set { }
        }

        public SelectList EnclosureDepartmentMasterList
        {
            get
            {
                List<EnclosureDepartmentMaster> EnclosureDepartmentMasterList = EnclosureDepartmentMaster.List<EnclosureDepartmentMaster>(new Npgsql.NpgsqlCommand("select DepartmentId,DeptName from EnclosureDepartmentMaster order by DeptName"));
                return new SelectList(EnclosureDepartmentMasterList, "DepartmentId", "DeptName");
            }
            set { }
        }
    }

    //public class ExternalLogin
    //{
    //    public string Provider { get; set; }
    //    public string ProviderDisplayName { get; set; }
    //    public string ProviderUserId { get; set; }
    //}
}
