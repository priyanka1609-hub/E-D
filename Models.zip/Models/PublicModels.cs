﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.Mvc;
using Edistrict.Models.Entities;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.CustomClass;
using Edistrict.Models.DataService;

namespace Edistrict.Models
{
    public class PublicModels
    {
        [Required(ErrorMessage = "Service Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string ServiceCode { get; set; }
        [Required(ErrorMessage = "Department Required")]
        public virtual string DeptCode { get; set; }
        [Required(ErrorMessage = "Application No. Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        [StringLength(14, MinimumLength = 1, ErrorMessage = "Enter Valid Application No.")]
        public virtual string ApplicationNo { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [DataType(DataType.Date), Required(ErrorMessage = "DOB Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DOB { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("ServiceCode", "9073", ErrorMessage = "Locality/Pincode Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string WDOB { get; set; }
        [CustomProperty]
        public virtual string DocumentName { get; set; }
        [CustomProperty]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string ApplicantMobileNo { get; set; }
        [Display(Name = "OTP")]
        public string OTP { get; set; }
        [Required(ErrorMessage = "Document No Required")]
        [StringLength(25, MinimumLength = 2, ErrorMessage = "Enter Valid DocumentNo.")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\-[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string DocumentNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [Display(Name = "How much is the sum?")]
        public string Captcha { get; set; }
        [RequiredIf("LocalityName", null, ErrorMessage = "Locality/Pincode Required")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[1-1][1-1][0-9]{4}$", ErrorMessage = "Enter Valid PinCode")]
        public string PinCode { get; set; }
        [RequiredIf("PinCode", null, ErrorMessage = "Locality/Pincode Required")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string LocalityName { get; set; }
        [Required(ErrorMessage = "District Required")]
        public virtual string DistrictCode { get; set; }

        public DataTable data { get; set; }
        public DataTable data1 { get; set; }
        public DataTable data2 { get; set; }
        public DataTable data3 { get; set; }
        public DataTable data4 { get; set; }
        public DataTable data5 { get; set; }
        public DataTable data6 { get; set; }
        public DataTable data7 { get; set; }
        public DataTable dataEpp { get; set; }
        public DataTable dataMEpp { get; set; }
        public DataSet dataset { get; set; }

        [Required(ErrorMessage = "Name Required")]
        public virtual string ApplicantName { get; set; }
        [RequiredIf("ServiceCode", "9073", ErrorMessage = "Wife Name Required")]
        public virtual string WName { get; set; }
        public virtual string FatherName { get; set; }
        [Required(ErrorMessage = "Locality Required")]
        public virtual string LocalityId { get; set; }
        public virtual string DistrictName { get; set; }
        public virtual string SubDivName { get; set; }
        [Required(ErrorMessage = "Sub Division Required")]
        public virtual string SubDivCode { get; set; }
        [Required(ErrorMessage = "Year Required")]
        public string Year { get; set; }
        [Required(ErrorMessage = "Month Required")]
        public string Month { get; set; }

        [StringLength(9, MinimumLength = 4, ErrorMessage = "Enter Valid Income")]
        public string IncomeAmount { get; set; }
        public string IncomeCondition { get; set; }

        public string CasteId { get; set; }
        public string WhetherCentreCaste { get; set; }
        public string StateId { get; set; }
        [Required(ErrorMessage = "Village Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Village")]
        public virtual string VillageId { get; set; }
        [Required(ErrorMessage = "Khata Type Required")]
        public virtual string KhataTypeId { get; set; }
        [RequiredIf("OptionType", "0", ErrorMessage = "Khata No Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        [StringLength(3, MinimumLength = 1, ErrorMessage = "Enter Valid Khata No.")]
        public virtual string KhataNo { get; set; }
        [RequiredIf("OptionType", "1", ErrorMessage = "Rect No Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        [StringLength(3, MinimumLength = 1, ErrorMessage = "Enter Valid Rect No.")]
        public virtual string RectNo { get; set; }
        [RequiredIf("OptionType", "1", ErrorMessage = "Khasra Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        [StringLength(7, MinimumLength = 1, ErrorMessage = "Enter Valid Khasra No.")]
        public virtual string KhasraNo { get; set; }
        public virtual string MinNo { get; set; }
        [RequiredIf("OptionType", "2", ErrorMessage = "Name Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string Name { get; set; }
        [Required(ErrorMessage = "Select One Option")]
        public virtual string OptionType { get; set; }

        public virtual string RecoveryNo { get; set; }
        public virtual string CaseNo { get; set; }
        public virtual string DiaryNo { get; set; }
        public virtual string RecoverytypeId { get; set; }
        public virtual string Amount { get; set; }
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        [StringLength(14, MinimumLength = 1, ErrorMessage = "Enter Valid Application No.")]
        public virtual string AppNo { get; set; }
        public virtual string LabourGrievanceId { get; set; }
        public virtual string DistCode { get; set; }
        [Required(ErrorMessage = "Select One Option")]
        public virtual string MismatchType { get; set; }

        public virtual ApplicantDetails ApplicantDetails { get; set; }
        public virtual ApplicationGrievances ApplicationGrievances { get; set; }
        public virtual UserFeedBackMaster UserFeedBackMaster { get; set; }
        public virtual OddEvenApplicationDetails OddEvenApplicationDetails { get; set; }
        public virtual LBRGrievanceDetails LBRGrievanceDetails { get; set; }
        public virtual ApplicationDetailsMutation ApplicationDetailsMutation { get; set; }

        

        [CustomProperty]
        public SelectList StateList
        {
            get
            {
                List<StateMaster> StateList = StateMaster.List<StateMaster>(new Npgsql.NpgsqlCommand("select stateid,statename from dbo.statemaster order by statename"));
                return new SelectList(StateList, "stateid", "statename");
            }
            set { }
        }
        [CustomProperty]
        public SelectList CasteMasterList
        {
            get
            {
                List<CasteMaster> CasteMasterList = CasteMaster.List<CasteMaster>(new Npgsql.NpgsqlCommand("select casteid,castename from dbo.castemaster where whetheractive=TRUE order by castename"));
                return new SelectList(CasteMasterList, "casteid", "castename");
            }
            set { }
        }
        public virtual SelectList MonthList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                DateTime month = Convert.ToDateTime("01/01/2012");
                for (int i = 0; i < 12; i++)
                {
                    DateTime NextMonth = month.AddMonths(i);
                    list.Add(new SelectListItem() { Text = NextMonth.ToString("MMMM"), Value = (i + 1).ToString() });
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }

        public virtual SelectList YearList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int varYear = 2005;
                for (int i = varYear; i < DateTime.Now.AddYears(1).Year; i++)
                {
                    list.Add(new SelectListItem() { Text = varYear.ToString(), Value = varYear.ToString() });
                    varYear++;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList ServiceList
        {
            get
            {
                List<ServiceMaster> ServiceList = ServiceMaster.List<ServiceMaster>(new Npgsql.NpgsqlCommand("select ServiceCode,ServiceName from ServiceMaster order by ServiceName"));
                return new SelectList(ServiceList, "ServiceCode", "ServiceName");
            }
            set { }
        }
        public SelectList DeptList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select DeptCode,DeptName from DeptMaster where WhetherActive='1' order by DeptName");
                List<DeptMaster> DeptList = DeptMaster.List<DeptMaster>(Cmd);
                return new SelectList(DeptList, "DeptCode", "DeptName");
            }
            set { }
        }
        public SelectList DistrictList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select districtcode,districtname from dbo.districtmaster where deptcode=@deptcode and stateid=@state order by districtname");
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@state", (int)State.Delhi);
                List<DistrictMaster> DistrictList = DistrictMaster.List<DistrictMaster>(Cmd);
                return new SelectList(DistrictList, "DistrictCode", "DistrictName");
            }
            set { }
        }
        public SelectList LocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@ParamDeptCode and ls.whetheractive=@whetheractive and lm.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ParamDeptCode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList SubDivList
        {
            get
            {
                string Qry = "select SubDivCode,SubDivDescription from SubDivMaster where districtcode in (select districtcode from districtmaster where deptcode=1 and stateid=@stateid)  order by SubDivDescription limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                List<SubDivMaster> SubDivList = SubDivMaster.List<SubDivMaster>(Cmd);
                return new SelectList(SubDivList, "SubDivCode", "SubDivDescription");
            }
            set { }
        }
        [CustomProperty]
        public SelectList VillageList
        {
            get
            {
                List<VillageMaster> VillageList = VillageMaster.List<VillageMaster>(new Npgsql.NpgsqlCommand("select Villageid,villagename from dbo.villagemaster order by villagename limit 0"));
                return new SelectList(VillageList, "Villageid", "villagename");
            }
            set { }
        }
        [CustomProperty]
        public SelectList KhataTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select -1 + ROW_NUMBER() OVER (ORDER BY SMVD.valueid asc) AS valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.KhataType);
                List<ServiceTypeMaster> KhataTypeList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(KhataTypeList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList RecoveryTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.RecoveryType);
                List<SelectValueMaster> RecoveryTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(RecoveryTypeList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList OldEppServiceList
        {
            get
            {
                string Qry = "Select ServiceCode,ServiceName from ServiceMaster where deptcode=@deptcode and servicecode in (@ParamServiceCode) order by ServiceName ";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                List<ServiceMaster> OldEppServiceList = ServiceMaster.List<ServiceMaster>(Cmd);
                return new SelectList(OldEppServiceList, "ServiceCode", "ServiceName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList DeptListForGrievance
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select DeptCode,case when DeptCode=1 then 'Department of Revenue/Nodal Department' else  DeptName end as DeptName from DeptMaster where WhetherActive='1' order by DeptCode");
                List<DeptMaster> DeptList = DeptMaster.List<DeptMaster>(Cmd);
                return new SelectList(DeptList, "DeptCode", "DeptName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MismatchList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Invalid Age", Value = "Invalid Age" });
                list.Add(new SelectListItem() { Text = "Duplictae Records", Value = "Duplictae Records" });
                list.Add(new SelectListItem() { Text = "Invalid DOB", Value = "Invalid DOB" });
                list.Add(new SelectListItem() { Text = "Duplictae Mobile", Value = "Duplictae Mobile" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
    }
}