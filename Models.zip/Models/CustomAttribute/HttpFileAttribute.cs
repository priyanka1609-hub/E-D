﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomAttribute
{
    public class HttpFileAttribute : ValidationAttribute
    {
        public int MaxContentLength = 51200;
        public int MaxFileLength = 50;
        public string[] AllowedFileExtensions;
        public string[] AllowedContentTypes;
        public string[] CheckNullBytes = new string[2] { "\0", "%" };

        public override bool IsValid(object value)
        {
            var file = value as HttpPostedFileBase;
            if (file == null)
            {
                return true;
            }

            if (file.ContentLength > MaxContentLength)
            {
                ErrorMessage = "File is too large, maximum allowed is " + MaxFileLength + " KB";
                return false;
            }
            if (AllowedFileExtensions != null)
            {
                int extensionIndex = file.FileName.LastIndexOf('.');
                if (extensionIndex < 1) { ErrorMessage = "Please upload file of type: " + string.Join(", ", AllowedFileExtensions); return false; }

                if (Utility.CheckArrayValueToString(CheckNullBytes, file.FileName))
                {
                    ErrorMessage = "Null byte file does not allowed in file name.";
                    return false;
                }

                if (!AllowedFileExtensions.Contains(file.FileName.Substring(extensionIndex)))
                {
                    ErrorMessage = "Please upload file of type: " + string.Join(", ", AllowedFileExtensions);
                    return false;
                }
            }
            if (AllowedContentTypes != null)
            {
                if (!AllowedContentTypes.Contains(file.ContentType))
                {
                    ErrorMessage = "Please upload file of type: " + string.Join(", ", AllowedContentTypes);
                    return false;
                }


                var fileNameParts = file.FileName.Split('.');
                if(fileNameParts.Length > 2)
                {
                    ErrorMessage = "Double extension file is not allowed, Please check your file extension.";
                    return false;
                }

                //HttpPostedFileBase fileCopy = file;
                //if (fileCopy.ContentType.ToLower().Contains("image"))
                //{
                //    bool IsImage = Utility.IsImage(fileCopy);
                //    if (IsImage == false)
                //    {
                //        ErrorMessage = "Please upload correct file of image";
                //        return false;
                //    }
                //}
                //else if (fileCopy.ContentType.ToLower().Contains("pdf"))
                //{
                //    bool IsPdf = Utility.IsPDFHeader(fileCopy);
                //    if (IsPdf == false)
                //    {
                //        ErrorMessage = "Please upload correct file of PDF";
                //        return false;
                //    }
                //}
                //else
                //{
                //    ErrorMessage = "Application didn't understand the file type, kindly check and try again.";
                //    return false;
                //}
            }

            return true;
        }


    }

    public class DataFileAttribute : ValidationAttribute
    {
        public string[] AllowedFileExtensions;
        public string[] AllowedContentTypes;

        public override bool IsValid(object value)
        {
            var file = value as HttpPostedFileBase;
            if (file == null)
                return true;
            if (AllowedFileExtensions != null)
            {
                if (!AllowedFileExtensions.Contains(file.FileName.Substring(file.FileName.LastIndexOf('.'))))
                {
                    ErrorMessage = "Please upload file of type: " + string.Join(", ", AllowedFileExtensions);
                    return false;
                }
            }
            if (AllowedContentTypes != null)
            {
                if (!AllowedContentTypes.Contains(file.ContentType))
                {
                    ErrorMessage = "Please upload file of type: " + string.Join(", ", AllowedContentTypes);
                    return false;
                }
            }
            return true;
        }
    }
}