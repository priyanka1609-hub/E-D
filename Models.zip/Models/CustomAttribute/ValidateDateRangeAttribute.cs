﻿using Edistrict.Models.DataService;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Edistrict.Models.CustomAttribute
{
    public class ValidateDateRangeAttribute : ValidationAttribute
    {
        public string minDate { get; set; }
        public string maxDate { get; set; }
        public override bool IsValid(object value)
        {
            DateTime minDateVal;
            DateTime maxDateVal;
            DateTime ValDate = DateTime.Now;

            // if find empty or null then return the true
            if (value == null) { return true; }

            if (minDate != null)
            {
                minDateVal = Convert.ToDateTime(Utility.ConvertDateSequence(minDate, '/', "0/1/2"));
            }
            else
            {
                // minimum date of birth is allowing is current date - 100 years
                minDateVal = Convert.ToDateTime(Utility.ConvertDateSequence(DateTime.Now.AddYears(-100).ToString("dd/MM/yyyy"), '/', "0/1/2"));
            }

            if (maxDate != null)
            {
                maxDateVal = Convert.ToDateTime(Utility.ConvertDateSequence(maxDate, '/', "0/1/2"));
            }
            else
            {
                // maximum date for DOB is allowing is current date - 1 day
                maxDateVal = Convert.ToDateTime(Utility.ConvertDateSequence(DateTime.Now.AddDays(-1).ToString("dd/MM/yyyy"), '/', "0/1/2"));
            }

            if (value != null)
            {
                ValDate = Convert.ToDateTime(Utility.ConvertDateSequence(value.ToString(), '/', "0/1/2"));
            }

            if (ValDate >= minDateVal && ValDate <= maxDateVal)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
