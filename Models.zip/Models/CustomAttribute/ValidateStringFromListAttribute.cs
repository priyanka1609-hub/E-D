﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.CustomAttribute
{
    public class ValidateStringFromListAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (value != null)
            {
                string firstName = value.ToString();
                string[] splitString = firstName.Split(' ');

                if (splitString.Length > 0)
                {
                    firstName = splitString[0];
                }
                if (InvalidStringList.Any(s => s.Equals(firstName.ToUpper())))
                {
                    return false;
                }

            }
            return true;
        }
        public static List<string> InvalidStringList = new List<string>()
        {
	        "NA",
	        "NOT AVAILABLE",
	        "XXX",
            "ABC",
            "MR",
            "MRS",
            "N A",
            "N.A.",
            "NIL",
            "NO",
            "NOT",
            "XXX",
            "XYZ",
        };
    }
}