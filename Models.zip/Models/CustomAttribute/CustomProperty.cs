﻿using System;
using System.Web;

namespace Edistrict.Models.CustomAttribute
{
    public class CustomProperty : Attribute
    {

    }
}