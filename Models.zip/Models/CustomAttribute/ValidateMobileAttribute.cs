﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Edistrict.Models.CustomAttribute
{
    public class ValidateMobileAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                bool isValidMobile = true;
                string phone = value.ToString();
                Char[] a = phone.ToCharArray();
                if (phone.Length == 10)
                {
                    var g = from c in phone.ToCharArray()
                            group c by c into m
                            select new { Key = m.Key, Count = m.Count() };
                    foreach (var item in g)
                    {
                        if (item.Count > 6)
                        {
                            isValidMobile = false;
                        }
                    }

                    if (isValidMobile)
                    {
                        return ValidationResult.Success;
                    }
                    else
                    {
                        return new ValidationResult("Please Enter a Valid Phone No.");
                    }
                }
                else
                {
                    return new ValidationResult(" Phone No. Should be of 10 Digits Only.");
                }
            }
            else
            {
                if (string.IsNullOrEmpty(validationContext.DisplayName)) { validationContext.DisplayName = "Mobile No. Required"; }
                return new ValidationResult(validationContext.DisplayName);
            }
        }
    }
}