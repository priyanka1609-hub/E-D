﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomAttribute
{
    public class DateRangeAttribute : ValidationAttribute
    {
        public int DifferenceYear;
        public bool RequiredGreater;
        public bool RequiredLess;
        public string FromDate;
        public string ToDate;

        public override bool IsValid(object value)
        {
            DateTime GetFromDate = DateTime.Now;
            DateTime GetToDate = DateTime.Now;

            if (value != null)
            {
                GetFromDate = Convert.ToDateTime(Utility.ConvertDateSequence(value.ToString(), '/', "0/1/2"));
            }
            if (!string.IsNullOrEmpty(FromDate))
            {
                GetFromDate = Convert.ToDateTime(Utility.ConvertDateSequence(FromDate, '/', "0/1/2"));
            }
            if (!string.IsNullOrEmpty(ToDate))
            {
                GetToDate = Convert.ToDateTime(Utility.ConvertDateSequence(ToDate, '/', "0/1/2"));
            }
            if (RequiredGreater == true)
            {
                if (GetFromDate.AddYears(DifferenceYear) > GetToDate)
                {
                    return false;
                }
            }
            else
            {
                if (GetFromDate.AddYears(DifferenceYear) < GetToDate)
                {
                    return false;
                }
            }
            if (RequiredLess == true)
            {
                if (GetFromDate.AddYears(DifferenceYear) < GetToDate)
                {
                    return false;
                }
            }
            return true;
        }
    }
}