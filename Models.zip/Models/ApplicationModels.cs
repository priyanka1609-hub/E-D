﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Web;
using System.Web.Mvc;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.CustomClass;
using Edistrict.Models.Entities;
using Edistrict.Models.ApplicationService;
using System.Data.SqlClient;
using Npgsql;
using Edistrict.Models.DataService;

namespace Edistrict.Models
{
    public class ReceivingModels
    {
        [Required(ErrorMessage = "Please Select Service")]
        public virtual string ServiceCode { get; set; }
        [Required(ErrorMessage = "Please Select Service")]
        public virtual string DeptCode { get; set; }
        public virtual string DeptName { get; set; }
        [Required(ErrorMessage = "Please Select Type")]
        public virtual string ApplicantTypeId { get; set; }
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("ApplicantTypeId", "2", ErrorMessage = "DOB Required")]
        [DateRange(DifferenceYear = 18, RequiredGreater = false, ErrorMessage = "Minor Applicant must be less then 18 Yrs.")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string ApplicantDob { get; set; }
        [Required(ErrorMessage = "Please Upload Document")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg", "application/pdf" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg", ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase ApplicantFile { get; set; }
        [Required(ErrorMessage = "Please Capture/Upload Photo")]
        public virtual string PhotoSource { get; set; }
        [RequiredIf("PhotoSource", "C", ErrorMessage = "Plesae Capture Image")]
        public virtual string PhotoData { get; set; }
        [RequiredIf("PhotoSource", "U", ErrorMessage = "Please Upload Scan Photo")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg" }, MaxContentLength = (int)LengthList.AppLength, MaxFileLength = (int)LengthList.AppPhoto, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase ApplicantPhoto { get; set; }
        public virtual string ApplicantPhotoData { get; set; }
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase ApplicantPhotoFile { get; set; }
        [Required(ErrorMessage = "Please Select Option")]
        public virtual string WhetherAadhaarAvailable { get; set; }
        public virtual string AadhaarNo { get; set; }
        public virtual string readOnly { get; set; }
        [Required(ErrorMessage = "Invalid Locality")]
        public virtual string LocalityName { get; set; }
        public virtual string LocalityErrorName { get; set; }
        [Required(ErrorMessage = "Invalid Sub Division")]
        public virtual string SubDivName { get; set; }
        [Required(ErrorMessage = "Invalid District")]
        public virtual string DistrictName { get; set; }
        public virtual string StateName { get; set; }
        public virtual string CountryName { get; set; }
        public virtual string CustumId { get; set; }
        public virtual string ObjectionDetailId { get; set; }
        public virtual string ObjectionId { get; set; }
        public string JustifyRemarks { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicantGender { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual System.Nullable<int> PaymentModeId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AppointmentId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AppointmentTypeId { get; set; }
        public virtual string HSubDivCode { get; set; }
        public virtual string WSubDivCode { get; set; }
        public virtual string MSubDivCode { get; set; }
        [Required(ErrorMessage = "Select atleast one profile ")]
        public virtual string ProfileId { get; set; }
        public virtual string ApplicantProfileId { get; set; }
        public virtual string ParentRegistrationId { get; set; }
        public string[] VerificationResponse { get; set; }
        public virtual string WhetherFeeRequired { get; set; }
        [Required(ErrorMessage = "Enter Fee")]
        public virtual string FeeAmount { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Please Check the checkbox")]
        public virtual bool check { get; set; }
        [Required(ErrorMessage = "Please Check CheckBox")]
        public virtual bool checkDeclaration { get; set; }
        public virtual bool Age { get; set; }
        public virtual string Message { get; set; }
        public virtual bool WhetherActive { get; set; }
        public virtual bool RtrnResponse { get; set; }
        public virtual string HSRCode { get; set; }
        public virtual string WSRCode { get; set; }
        public virtual string MSRCode { get; set; }
        public virtual string ControllerName { get; set; }
        public virtual string ActionMethod { get; set; }
        [Required(ErrorMessage = "Please Select")]
        public virtual string BsesCANo { get; set; }
        public virtual string WhetherAdditionalDocRequired { get; set; }
        public virtual string[] dataArr { get; set; }
        [Required(ErrorMessage = "Select atleast one document ")]
        public virtual string RegDocId { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Check Box Checked Required")]
        public virtual bool consentcheck { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string consentcheckid { get; set; }
        [Required(ErrorMessage = "Value Required.")]
        public virtual string NdplCANo { get; set; }
        public virtual bool WhetherDocVerified { get; set; }
        public virtual string WhetherWorkerIncreased { get; set; }
        public virtual string WhetherDeficiency { get; set; }
        public virtual string WhetherLastInspection { get; set; }
        public virtual string MarriageActId { get; set; }
        [Required(ErrorMessage = "OTP Required")]
        public virtual string OTPGet { get; set; }
        [Required(ErrorMessage = "OTP Required")]
        public virtual string OTPPost { get; set; }
        public virtual int ResendAttempt { get; set; }
        [Required(ErrorMessage = "Please enter ARN")]
        public virtual string arn { get; set; }
        public virtual Int64 requestID { get; set; }
        public virtual string citizenFirstName { get; set; }
        public virtual string citizenName { get; set; }
        public virtual string cafKey { get; set; }
        [Required(ErrorMessage = "Please enter KNO")]
        public virtual string KNO { get; set; }
        public virtual string DjbAppStatus { get; set; }

        public DataTable data { get; set; }
        public DataTable datab { get; set; }
        public DataTable data2 { get; set; }
        public DataSet Ds { get; set; }

        public virtual ApplicationDetails ApplicationDetails { get; set; }
        public virtual ApplicationEnclosureDetails ApplicationEnclosureDetails { get; set; }
        public virtual ApplicationDetailsDomicile ApplicationDetailsDomicile { get; set; }
        public virtual ApplicationHandicappedDetails ApplicationHandicappedDetails { get; set; }
        public virtual ApplicationOldAgeDetails ApplicationOldAgeDetails { get; set; }
        public virtual ApplicationDetailsBirth ApplicationDetailsBirth { get; set; }
        public virtual ApplicationDetailsDeath ApplicationDetailsDeath { get; set; }
        public virtual ApplicantBankDetails ApplicantBankDetails { get; set; }
        public virtual ApplicationDetailsNationality ApplicationDetailsNationality { get; set; }
        public virtual ApplicationDetailsSolvency ApplicationDetailsSolvency { get; set; }
        public virtual ApplicationDetailsDisability ApplicationDetailsDisability { get; set; }
        public virtual ApplicationDetailsIncome ApplicationDetailsIncome { get; set; }
        public virtual ApplicationDetailsSCST ApplicationDetailsSCST { get; set; }
        public virtual ApplicationDetailsST ApplicationDetailsST { get; set; }
        public virtual ApplicationDetailsOBC ApplicationDetailsOBC { get; set; }
        public virtual ApplicationDetailsLalDora ApplicationDetailsLalDora { get; set; }
        public virtual WitnessDetailsLalDora LalDoraWitnessDetails { get; set; }
        public virtual ApplicationDetailsSurviving ApplicationDetailsSurviving { get; set; }
        public virtual RegistrationMaster RegistrationMaster { get; set; }
        public virtual ApplicationWidowDetails ApplicationWidowDetails { get; set; }
        public virtual ApplicationPhotoMaster ApplicationPhotoMaster { get; set; }
        public virtual ApplicantDetails ApplicantDetails { get; set; }
        public virtual ApplicationMarriageDetails ApplicationMarriageDetails { get; set; }
        public virtual MarriageWitnessMaster MarriageWitnessDetails { get; set; }
        public virtual MarriageWitnessMaster MarriageWitness1 { get; set; }
        public virtual MarriageWitnessMaster MarriageWitness2 { get; set; }
        public virtual MarriageWitnessMaster MarriageWitness3 { get; set; }
        public virtual ServiceDetailsBeforeApply ServiceDetailsBeforeApply { get; set; }
        public virtual ParentApplicantDetails ParentApplicantDetails { get; set; }
        public virtual ApplicationLetterDetails ApplicationLetterDetailsModel { get; set; }
        //public virtual ApplicationRTIQuestionDetail ApplicationRTIQuestionDetail { get; set; }
        //public virtual ApplicationRTIMainDetail ApplicationRTIMainDetail { get; set; }
        //public virtual ApplicationDetailsRTIAns ApplicationDetailsRTIAns { get; set; }
        public virtual ApplicationDetailsCDV ApplicationDetailsCDV { get; set; }
        public virtual ApplicationDetailsCinematograph ApplicationDetailsCinematograph { get; set; }
        public virtual ApplicationDetailsNOC ApplicationDetailsNOC { get; set; }
        public virtual ApplicationDetailsMigration ApplicationDetailsMigration { get; set; }
        public virtual ApplicationDetailsBOCWAct ApplicationDetailsBOCWAct { get; set; }
        public virtual ApplicationDetailsCLAct ApplicationDetailsCLAct { get; set; }
        public virtual ApplicationDetailsContractor ApplicationDetailsContractor { get; set; }
        public virtual ApplicationDetailsDFBScheme ApplicationDetailsDFBScheme { get; set; }
        public virtual ApplicationDetailsLadli ApplicationDetailsLadli { get; set; }
        public virtual ApplicationDetailsNT ApplicationDetailsNT { get; set; }
        public virtual ApplicationDetailsRecovery ApplicationDetailsRecovery { get; set; }
        public virtual NfsApplicationDetails NfsApplicationDetails { get; set; }
        public virtual NfsUpdateBasicDetails NfsUpdateBasicDetails { get; set; }
        public virtual HeSkillDevelopmentScheme HeSkillDevelopmentScheme { get; set; }
        public virtual ApplicationDetailsSociety ApplicationDetailsSociety { get; set; }
        public virtual ApplicationDetailsFirm ApplicationDetailsFirm { get; set; }
        public virtual ApplicationDetailsPrematsSC ApplicationDetailsPrematsSC { get; set; }
        public virtual ApplicationDetailsFinancialAssistance ApplicationDetailsFinancialAssistance { get; set; }
        public virtual ApplicationDetailsMeritscholarshipSchool ApplicationDetailsMeritscholarshipSchool { get; set; }
        public virtual ApplicationDetailsDrbrAmbedkarToppers ApplicationDetailsDrbrAmbedkarToppers { get; set; }
        public virtual ApplicationDetailsMeritProfessional ApplicationDetailsMeritProfessional { get; set; }
        public virtual ApplicationDetailsPrematOBC ApplicationDetailsPrematOBC { get; set; }
        public virtual ApplicationDetailsPostmatOBC ApplicationDetailsPostmatOBC { get; set; }
        public virtual ApplicationPaymentRequest ApplicationPaymentRequest { get; set; }
        public virtual ApplicationPaymentResponse ApplicationPaymentResponse { get; set; }
        public virtual ApplicationDetailsSRCopy ApplicationDetailsSRCopy { get; set; }
        public virtual ApplicationDetailsDemarcation ApplicationDetailsDemarcation { get; set; }
        public virtual NGTOrderCopy NGTOrderCopy { get; set; }
        public virtual ApplicationDetailsInstallationOfLift ApplicationDetailsInstallationOfLift { get; set; }
        public virtual ApplicationDetailsGrantOfPassengerLift ApplicationDetailsGrantOfPassengerLift { get; set; }
        public virtual ApplicationDetailsLBRRecovery ApplicationDetailsLBRRecovery { get; set; }
        public virtual ApplicationDetailsMutation ApplicationDetailsMutation { get; set; }
        public virtual ApplicationDetailsRenewalOfPassengerLift ApplicationDetailsRenewalOfPassengerLift { get; set; }
        public virtual ApplicationDetailsRenewalContractor ApplicationDetailsRenewalContractor { get; set; }
        public virtual BsesUtilityService BsesUtilityService { get; set; }
        public virtual NdplUtilityService NdplUtilityService { get; set; }
        public virtual ApplicationDetailsCEA1 ApplicationDetailsCEA1 { get; set; }
        public virtual ApplicationDetailsCEA2 ApplicationDetailsCEA2 { get; set; }
        public virtual ApplicationDetailsCEA3 ApplicationDetailsCEA3 { get; set; }
        public virtual HeMCMFinancialAssistance HeMCMFinancialAssistance { get; set; }
        public virtual ApplicationDetailsConsWorker ApplicationDetailsConsWorker { get; set; }
        public virtual RenewalConsWorker RenewalConsWorker { get; set; }
        public virtual ApplicationDetailsPrematSCssd ApplicationDetailsPrematSCssd { get; set; }
        public virtual ApplicationDetailsPostmatSCssd ApplicationDetailsPostmatSCssd { get; set; }
        public virtual ApplicationDetailsEC ApplicationDetailsEC { get; set; }
        public virtual ApplicationDetailsCompCertificate ApplicationDetailsCompCertificate { get; set; }
        public virtual ApplicationDetailsDeathBenefits ApplicationDetailsDeathBenefits { get; set; }
        public virtual ApplicationDetailsFuneralBenefit ApplicationDetailsFuneralBenefit { get; set; }
        public virtual ApplicationDetailsFamilyPension ApplicationDetailsFamilyPension { get; set; }
        public virtual ApplicationDetailsMarriageAssistance ApplicationDetailsMarriageAssistance { get; set; }
        public virtual ApplicationDetailsEduScholarship ApplicationDetailsEduScholarship { get; set; }
        public virtual ApplicationDetailsMedicalAssistance ApplicationDetailsMedicalAssistance { get; set; }
        public virtual ApplicationDetailsHBA ApplicationDetailsHBA { get; set; }
        public virtual ApplicationDetailsDisabilityPension ApplicationDetailsDisabilityPension { get; set; }
        public virtual ApplicationDetailsPension ApplicationDetailsPension { get; set; }
        public virtual ApplicationDetailsMaternityBenefit ApplicationDetailsMaternityBenefit { get; set; }
        public virtual ApplicationDetailsGrantofWork ApplicationDetailsGrantofWork { get; set; }
        public virtual ApplicationDetailsInstrumentLoan ApplicationDetailsInstrumentLoan { get; set; }
        public virtual ApplicationDetailsExgratia ApplicationDetailsExgratia { get; set; }
        public ApplicationDetailsTirthYatraYojana ApplicationDetailsTirthYatraYojana { get; set; }

        public virtual List<WitnessDetailsLalDora> WitnessDetailsLalDora { get; set; }
        public virtual List<MarriageWitnessMaster> MarriageWitnessMaster { get; set; }
        public virtual List<ApplicationLetterDetails> ApplicationLetterDetails { get; set; }

        public virtual SelectList PaymentModeList { get; set; }
        public virtual SelectList AddDocumentAtCSCorCitizen
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select DocumentId,DocumentName from dbo.DocumentMaster where DocumentId in (@AadhaarCard,@PANCard)");
                Cmd.Parameters.AddWithValue("@PANCard", (int)DocumentId.PANCard);
                Cmd.Parameters.AddWithValue("@AadhaarCard", (int)DocumentId.AadhaarCard);
                List<DocumentMaster> DocumentMasterList = DocumentMaster.List<DocumentMaster>(Cmd);
                return new SelectList(DocumentMasterList, "DocumentId", "DocumentName");
            }
            set { }
        }
        public virtual SelectList SubDivList
        {
            get
            {
                DeptCode = Utility.SelectColumnsValue("ServiceMaster", "DeptCode", "ServiceCode", ApplicationDetails.ServiceCode)[0];

                string Qry = "select SubDivCode,SubDivDescription from SubDivMaster where DistrictCode in (select DistrictCode from DistrictMaster where deptcode=@ParamDeptCode) order by SubDivDescription";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@ParamDeptCode", DeptCode);
                List<SubDivMaster> SubDivList = SubDivMaster.List<SubDivMaster>(Cmd);
                return new SelectList(SubDivList, "SubDivCode", "SubDivDescription");
            }
            set { }
        }
        public virtual SelectList DistrictList
        {
            get
            {
                //list used for only marriage
                DeptCode = Utility.SelectColumnsValue("ServiceMaster", "DeptCode", "ServiceCode", ApplicationDetails.ServiceCode)[0];

                string Qry = "select DistrictCode,DistrictName from DistrictMaster where deptcode=@ParamDeptCode order by DistrictName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@ParamDeptCode", DeptCode);
                List<DistrictMaster> DistrictList = DistrictMaster.List<DistrictMaster>(Cmd);
                return new SelectList(DistrictList, "DistrictCode", "DistrictName");
            }
            set { }
        }
        public virtual SelectList LocalityList
        {
            get
            {
                DeptCode = Utility.SelectColumnsValue("ServiceMaster", "DeptCode", "ServiceCode", ApplicationDetails.ServiceCode)[0];

                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode ";
                if (Sessions.getEmployeeUser() != null) {
                    if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().AuthorizationId) && Convert.ToInt32(Sessions.getEmployeeUser().DeptCode) == (int)Department.Dept002) { Qry += " inner join localitytoconstituencymaster lcm on lcm.localityid=lm.localityid and lcm.localityid=LS.localityid  and lcm.deptcode=@ParamDeptCode and lcm.whetheractive=@whetheractive"; }
                }
                Qry += " where dm.deptcode=@ParamDeptCode and ls.whetheractive=@whetheractive and lm.whetheractive=@whetheractive";
                if (Sessions.getEmployeeUser() != null) {
                    if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and sd.SubDivCode in (@ParamSubDivCode)"; }
                    if (Convert.ToInt32(Sessions.getEmployeeUser().AuthorizationId) != (int)CountList.Type000 && Convert.ToInt32(Sessions.getEmployeeUser().DeptCode) == (int)Department.Dept002) { Qry += " and lcm.deptcode=@ParamDeptCode and lcm.constituencyid=@ParamAuthorizationId "; }
                }
                Qry += " order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@ParamDeptCode", DeptCode);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        public virtual SelectList DelhiLocalityList
        {
            get
            {
                DeptCode = Utility.SelectColumnsValue("ServiceMaster", "DeptCode", "ServiceCode", ApplicationDetails.ServiceCode)[0];

                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@ParamDeptCode and dm.stateid=@stateid and LM.whetheractive=@whetheractive and LS.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@ParamDeptCode", DeptCode);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        public virtual SelectList AllLocalityList
        {
            get
            {
                //used for birth and death service
                DeptCode = Utility.SelectColumnsValue("ServiceMaster", "DeptCode", "ServiceCode", ApplicationDetails.ServiceCode)[0];

                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@ParamDeptCode and ls.whetheractive=@whetheractive and lm.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@ParamDeptCode", DeptCode);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        public virtual SelectList MarriageActList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select ValueId as SelectValueId,ValueName as SelectValueName from dbo.SelectMasterValueDetails where ValueId in (@Special,@Hindu)");
                Cmd.Parameters.AddWithValue("@Special", (int)MarriageAct.Special);
                Cmd.Parameters.AddWithValue("@Hindu", (int)MarriageAct.Hindu);
                //Cmd.Parameters.AddWithValue("@Compulsory", (int)MarriageAct.Compulsory);
                List<SelectValueMaster> MarriageActList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(MarriageActList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList SolemnizationActList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select ValueId as SelectValueId,ValueName as SelectValueName from dbo.SelectMasterValueDetails where ValueId in (@Special13)");
                Cmd.Parameters.AddWithValue("@Special13", (int)MarriageAct.Special13);
                //Cmd.Parameters.AddWithValue("@Special16", (int)MarriageAct.Special16);
                List<SelectValueMaster> MarriageActList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(MarriageActList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList DocumentName { get; set; }
        public virtual SelectList DocumentTypeName { get; set; }
        public virtual SelectList ServiceMaster { get; set; }
        public virtual SelectList LocalityMasterList { get; set; }
        public virtual SelectList DocumentList { get; set; }
        public virtual SelectList DocumentAvailableAtCSC
        {
            get
            {
                int RtnServiceCode = Utility.GetServiceCodeForApplyDoc(ApplicationDetails.ServiceCode);
                string Qry = "select DM.DocumentId,DocumentName from dbo.DocumentMaster DM inner join servicetovalidateddocumentmaster STVD on STVD.DocumentId=DM.DocumentId where servicecode=@ServiceCode and DM.DocumentId not in(@AadhaarCard)";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@AadhaarCard", (int)DocumentId.AadhaarCard);
                Cmd.Parameters.AddWithValue("@ServiceCode", RtnServiceCode);
                List<DocumentMaster> DocumentMasterList = DocumentMaster.List<DocumentMaster>(Cmd);
                return new SelectList(DocumentMasterList, "DocumentId", "DocumentName");
            }
            set { }
        }
        public virtual SelectList HMaritalStatusList
        {
            get
            {
                List<MaritalStatusMaster> MaritalStatusList = MaritalStatusMaster.List<MaritalStatusMaster>(new Npgsql.NpgsqlCommand("select MaritalStatusId,MaritalStatusName from dbo.MaritalStatusMaster where MaritalStatusId in (1,3,5)"));
                return new SelectList(MaritalStatusList, "MaritalStatusId", "MaritalStatusName");
            }
            set { }
        }
        public virtual SelectList WMaritalStatusList
        {
            get
            {
                List<MaritalStatusMaster> MaritalStatusList = MaritalStatusMaster.List<MaritalStatusMaster>(new Npgsql.NpgsqlCommand("select MaritalStatusId,MaritalStatusName from dbo.MaritalStatusMaster where MaritalStatusId in (1,3,4)"));
                return new SelectList(MaritalStatusList, "MaritalStatusId", "MaritalStatusName");
            }
            set { }
        }
        public virtual SelectList NationalityList
        {
            get
            {
                List<NationalityMaster> NationalityList = NationalityMaster.List<NationalityMaster>(new Npgsql.NpgsqlCommand("select NationalityId,NationalityName from NationalityMaster order by NationalityId"));
                return new SelectList(NationalityList, "NationalityId", "NationalityName");
            }
            set { }
        }
        public virtual SelectList DepartmentName { get; set; }
        public virtual SelectList ObjectionMarriageRelatedList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Husband", Value = "3" });
                list.Add(new SelectListItem() { Text = "Wife", Value = "4" });
                list.Add(new SelectListItem() { Text = "Marriage Ceremony", Value = "5" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList EnclosureDepartmentMasterList
        {
            get
            {
                List<EnclosureDepartmentMaster> EnclosureDepartmentMasterList = EnclosureDepartmentMaster.List<EnclosureDepartmentMaster>(new Npgsql.NpgsqlCommand("select DepartmentId,DeptName from EnclosureDepartmentMaster order by DeptName"));
                return new SelectList(EnclosureDepartmentMasterList, "DepartmentId", "DeptName");
            }
            set { }
        }
        public virtual SelectList DocumentAvailableAtCitizen
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select DocumentId,DocumentName from dbo.DocumentMaster where DocumentId in (@AadharCard,@DrivingLicense,@VoterID,@PANCard,@Passport,@RationCard)");
                Cmd.Parameters.AddWithValue("@AadharCard", (int)DocumentId.AadhaarCard);
                Cmd.Parameters.AddWithValue("@DrivingLicense", (int)DocumentId.DrivingLicense);
                Cmd.Parameters.AddWithValue("@VoterID", (int)DocumentId.VoterID);
                Cmd.Parameters.AddWithValue("@PANCard", (int)DocumentId.PANCard);
                Cmd.Parameters.AddWithValue("@Passport", (int)DocumentId.Passport);
                Cmd.Parameters.AddWithValue("@RationCard", (int)DocumentId.RationCard);
                List<DocumentMaster> DocumentMasterList = DocumentMaster.List<DocumentMaster>(Cmd);
                return new SelectList(DocumentMasterList, "DocumentId", "DocumentName");
            }
            set { }
        }
        public virtual SelectList CountryList
        {
            get
            {
                List<CountryMaster> CountryList = CountryMaster.List<CountryMaster>(new Npgsql.NpgsqlCommand("select CountryId,CountryName from countrymaster order by CountryId"));
                return new SelectList(CountryList, "CountryId", "CountryName");
            }
            set { }
        }
        public virtual SelectList StateList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select StateId,StateName from StateMaster where stateid <>@state order by StateName");
                cmd.Parameters.AddWithValue("@state", (int)State.Delhi);
                List<StateMaster> StateList = StateMaster.List<StateMaster>(cmd);
                return new SelectList(StateList, "StateId", "StateName");
            }
            set { }
        }
        public virtual SelectList ReligionList
        {
            get
            {
                List<ReligionMaster> ReligionList = ReligionMaster.List<ReligionMaster>(new Npgsql.NpgsqlCommand("select ReligionId,ReligionName from religionmaster order by ReligionName"));
                return new SelectList(ReligionList, "ReligionId", "ReligionName");
            }
            set { }
        }
        public virtual SelectList SelectAdhaarList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Adhaar No", Value = "A" });
                list.Add(new SelectListItem() { Text = "Enrolment No", Value = "E" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList ReasonMasterList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select RM.ReasonCode,RM.ReasonDetail from ReasonMaster RM  inner join  reasontoservicemaster RS on RM.ReasonCode=RS.ReasonCode where RM.whetheractive=@whetheractive and RS.whetheractive=@whetheractive and RS.ServiceCode=@ServiceCode order by RS.DisplaySequence ");
                cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                cmd.Parameters.AddWithValue("@ServiceCode", ApplicationDetails.ServiceCode);
                List<ReasonMaster> ReasonMasterList = ReasonMaster.List<ReasonMaster>(cmd);
                return new SelectList(ReasonMasterList, "ReasonCode", "ReasonDetail");
            }
            set { }
        }
        public virtual SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "Y" });
                list.Add(new SelectListItem() { Text = "No", Value = "N" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                list.Add(new SelectListItem() { Text = "Transgender", Value = "T" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList GenderWCDList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList OccupationMasterList
        {
            get
            {
                List<OccupationMaster> OccupationMasterList = OccupationMaster.List<OccupationMaster>(new Npgsql.NpgsqlCommand("select OccupationId,OccupationType from dbo.OccupationMaster order by OccupationType"));
                return new SelectList(OccupationMasterList, "OccupationId", "OccupationType");
            }
            set { }
        }
    }

}