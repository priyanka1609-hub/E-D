﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using Edistrict.Models.DataService;

namespace Edistrict.Models
{
    public class PagingModel : Repositry<PagingModel>
    {
        public virtual int PageIndex { get; set; }
        public virtual int CurrentPage { get; set; }
        public virtual Int32 TotalRows { get; set; }
        public virtual int RowsPerPage { get; set; }
        public virtual DataTable dtPage { get; set; }
        public virtual Dictionary<int, string> Parameters { get; set; }
        public virtual string ReturnAction { get; set; }
        public virtual string ReturnController { get; set; }
        public virtual string RequestType { get; set; }
        public virtual int StartCounter
        {
            get
            {
                return (CurrentPage - 1) * RowsPerPage + 1;
            }
            set
            {
                StartCounter = value;
            }
        }


    }
}