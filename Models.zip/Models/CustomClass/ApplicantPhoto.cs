﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.CustomClass
{
    public class ApplicantPhoto : Repositry<ApplicantPhoto>
    {
        [Required(ErrorMessage = "Please Capture/Upload Photo")]
        public virtual string PhotoSource { get; set; }
        [RequiredIf("PhotoSource", "C", ErrorMessage = "Plesae Capture Image")]
        public virtual string PhotoData { get; set; }
        [RequiredIf("PhotoSource", "U", ErrorMessage = "Please Upload Scan Photo")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid File")]
        public HttpPostedFileBase ApplicantImage { get; set; }

    }
}