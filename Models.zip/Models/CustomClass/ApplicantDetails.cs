﻿using System;
using System.Web;
using Edistrict.Models.Entities;

namespace Edistrict.Models.CustomClass
{
    public class ApplicantDetails : ApplicationDetails
    {
        
    }
}