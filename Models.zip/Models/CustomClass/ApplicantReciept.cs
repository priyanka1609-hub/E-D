﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.CustomClass
{
    public class ApplicantReciept : Repositry<ApplicantReciept>
    {
        public virtual string RegistrationId { get; set; }
        public virtual string ApplicationId { get; set; }
        public virtual string ApplicantAadhaarNo { get; set; }
        public virtual string ApplicantName { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual string ApplicationStatus { get; set; }
        public virtual string AppliedFor { get; set; }
        public virtual string ApplicantAddress { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string ApplicantMobileNo { get; set; }
        public virtual string RegistrationDate { get; set; }
        public virtual string ApplicationDate { get; set; }
        public virtual string ApplicationSubmitAt { get; set; }
        
    }
}