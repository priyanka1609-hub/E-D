﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Edistrict.Models.CustomClass
{
    public class PieChartValues
    {
        public string Name { get; set; }
        public int Value { get; set; }
    }
}