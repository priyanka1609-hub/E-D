﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.CustomClass
{
    public class DeptUtilityResponse
    {
        [Required]
        public virtual string applicationRefNo { get; set; }
        [Required]
        public virtual string applicationUniqueNumber { get; set; }
        public virtual string USER_INFO { get; set; }
        public virtual string applicationStatus { get; set; }
        public virtual string serviceName { get; set; }
        public virtual string deptName { get; set; }

        public virtual string deptStatus { get; set; }
    }
}