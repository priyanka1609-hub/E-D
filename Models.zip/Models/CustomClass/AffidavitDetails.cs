﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomClass
{
    public class AffidavitDetails : Repositry<AffidavitDetails>
    {
        public virtual string ApplicationId { get; set; }
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicantName { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string ApplicantGender { get; set; }
        public virtual string ApplicantFatherName { get; set; }
        public virtual string ApplicantAddress { get; set; }
        public virtual string ApplicantDob { get; set; }
        public virtual string Age { get; set; }
        public virtual string BirthPlace { get; set; }
        public virtual string ChildName { get; set; }
        public virtual string RelationName { get; set; }
        public virtual string DeceasedName { get; set; }
        public virtual string DeceasedFatherName { get; set; }
        public virtual string DateOfDeath { get; set; }
        public virtual string PlaceOfDeath { get; set; }
        public virtual string DeceasedGender { get; set; }
        public virtual string DOB { get; set; }


    }
}