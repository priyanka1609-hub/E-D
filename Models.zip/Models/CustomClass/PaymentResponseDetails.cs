﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomClass
{
    public class PaymentResponseDetails : Repositry<PaymentResponseDetails>
    {
        public virtual string MerchantID { get; set; }
        public virtual string CustomerID { get; set; }
        public virtual string TxnReferenceNo { get; set; }
        public virtual string BankReferenceNo { get; set; }
        public virtual string TxnAmount { get; set; }
        public virtual string BankID { get; set; }
        public virtual string BankMerchantID { get; set; }
        public virtual string TxnType { get; set; }
        public virtual string CurrencyName { get; set; }
        public virtual string ItemCode { get; set; }
        public virtual string SecurityType { get; set; }
        public virtual string SecurityID { get; set; }
        public virtual string SecurityPassword { get; set; }
        public virtual string TxnDate { get; set; }
        public virtual string AuthStatus { get; set; }
        public virtual string SettlementType { get; set; }
        public virtual string AdditionalInfo1 { get; set; }
        public virtual string AdditionalInfo2 { get; set; }
        public virtual string AdditionalInfo3 { get; set; }
        public virtual string AdditionalInfo4 { get; set; }
        public virtual string AdditionalInfo5 { get; set; }
        public virtual string AdditionalInfo6 { get; set; }
        public virtual string AdditionalInfo7 { get; set; }
        public virtual string ErrorStatus { get; set; }
        public virtual string ErrorDescription { get; set; }
        public virtual string CheckSum { get; set; }

    }
}