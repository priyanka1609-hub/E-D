﻿using Morpho_AuthClient;
using System;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Xml;

public class Helper
{
  public static string SignAuthXml(string AuthXml, string password)
  {
    string str = string.Empty;
    try
    {
      if (!(AuthXml != string.Empty))
        return string.Empty;
      XmlDocument document = new XmlDocument();
      X509Certificate2 x509Certificate2 = new X509Certificate2(!(ConfigurationManager.AppSettings["ver"] == "1.5") ? "CertificateStore\\public_16.p12" : "CertificateStore\\public_15.p12", password);
      RSACryptoServiceProvider cryptoServiceProvider = (RSACryptoServiceProvider) x509Certificate2.PrivateKey;
      document.PreserveWhitespace = true;
      document.LoadXml(AuthXml);
      if (document == null)
        throw new ArgumentException("xmlDoc");
      if (cryptoServiceProvider == null)
        throw new ArgumentException("Key");
      SignedXml signedXml = new SignedXml(document);
      signedXml.SigningKey = (AsymmetricAlgorithm) cryptoServiceProvider;
      Reference reference = new Reference();
      reference.Uri = "";
      XmlDsigEnvelopedSignatureTransform signatureTransform = new XmlDsigEnvelopedSignatureTransform();
      reference.AddTransform((Transform) signatureTransform);
      signedXml.AddReference(reference);
      KeyInfoX509Data keyInfoX509Data = new KeyInfoX509Data((X509Certificate) x509Certificate2);
      keyInfoX509Data.AddSubjectName(x509Certificate2.Subject);
      KeyInfo keyInfo = new KeyInfo();
      keyInfo.AddClause((KeyInfoClause) keyInfoX509Data);
      signedXml.KeyInfo = keyInfo;
      signedXml.ComputeSignature();
      XmlElement xml = signedXml.GetXml();
      document.DocumentElement.AppendChild(document.ImportNode((XmlNode) xml, true));
      return document.InnerXml;
    }
    catch
    {
      return string.Empty;
    }
  }

  public static string HTTP_Post_AuthXML(string AuthXML, string uidNumber)
  {
    string str = string.Empty;
    string host = ApplicationStore.Host;
    string versionAadhaar = ApplicationStore.Version_Aadhaar;
    string ac = ApplicationStore.AC;
    string doFileOperation = ApplicationStore.DoFileOperation;
    //string licenseKey = ApplicationStore.LicenseKey;
    string targetUrl = ApplicationStore.TargetURL;
    ASCIIEncoding asciiEncoding = new ASCIIEncoding();
    WebRequest webRequest;
    if (targetUrl == "1")
    {
      webRequest = WebRequest.Create(ApplicationStore.TelcoServerURL);
    }
    else
    {
      if (versionAadhaar.Trim().Equals("1.6"))
      {
        if (ApplicationStore.UseLicensekey == "1")
          webRequest = WebRequest.Create(host + versionAadhaar + "/" + ac + "/" + uidNumber.Substring(0, 1) + "/" + uidNumber.Substring(1, 1) + "/"/* + licenseKey + "/"*/);
        else
          webRequest = WebRequest.Create(host + versionAadhaar + "/" + ac + "/" + uidNumber.Substring(0, 1) + "/" + uidNumber.Substring(1, 1) + "/");
      }
      else if (versionAadhaar.Trim().Equals("1.5"))
        webRequest = WebRequest.Create(host + versionAadhaar + "/" + ac + "/" + uidNumber.Substring(0, 1) + "/" + uidNumber.Substring(1, 1) + "/");
      else
        webRequest = WebRequest.Create(host + ac + "/" + uidNumber.Substring(0, 1) + "/" + uidNumber.Substring(1, 1) + "/");
      if (ApplicationStore.UseRemoteAddr == "1" && !string.IsNullOrEmpty(ApplicationStore.Remote_Addr))
        ((NameValueCollection) webRequest.Headers).Add("REMOTE_ADDR", ApplicationStore.Remote_Addr);
    }
    byte[] bytes = asciiEncoding.GetBytes(AuthXML);
    webRequest.Method = "POST";
    webRequest.ContentLength = (long) bytes.Length;
    Stream stream = (Stream) null;
    StreamReader streamReader = (StreamReader) null;
    HttpWebResponse httpWebResponse = (HttpWebResponse) null;
    try
    {
      stream = webRequest.GetRequestStream();
      stream.Write(bytes, 0, bytes.Length);
      stream.Flush();
      stream.Close();
      httpWebResponse = (HttpWebResponse) webRequest.GetResponse();
      streamReader = new StreamReader(httpWebResponse.GetResponseStream());
      return streamReader.ReadToEnd();
    }
    catch (WebException ex)
    {
      return ((object) ex.Message).ToString();
    }
    finally
    {
      if (stream != null)
        stream.Close();
      if (streamReader != null)
        streamReader.Close();
      if (httpWebResponse != null)
        httpWebResponse.Close();
    }
  }

  public static Bitmap CreateGreyscaleBitmap(byte[] buffer, int width, int height)
  {
    Bitmap bitmap1 = new Bitmap(width, height, PixelFormat.Format8bppIndexed);
    BitmapData bitmapdata = bitmap1.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadWrite, PixelFormat.Format8bppIndexed);
    Marshal.Copy(buffer, 0, bitmapdata.Scan0, width * height);
    bitmap1.UnlockBits(bitmapdata);
    ColorPalette palette = bitmap1.Palette;
    for (int index = 0; index < 256; ++index)
      palette.Entries[index] = Color.FromArgb(index, index, index);
    bitmap1.Palette = palette;
    Bitmap bitmap2 = new Bitmap(145, 190);
    using (Graphics graphics = Graphics.FromImage((Image) bitmap2))
      graphics.DrawImage((Image) bitmap1, 0, 0, 145, 190);
    return bitmap2;
  }

  public static string HTTP_Post_GetDetailByNo(string serviceURL, string AuthXML)
  {
    string str = string.Empty;
    string requestUriString = serviceURL;
    ASCIIEncoding asciiEncoding = new ASCIIEncoding();
    WebRequest webRequest = WebRequest.Create(requestUriString);
    byte[] bytes = asciiEncoding.GetBytes(AuthXML);
    webRequest.Method = "POST";
    webRequest.ContentLength = (long) bytes.Length;
    webRequest.ContentType = "text/xml;charset=UTF-8";
    Stream stream = (Stream) null;
    StreamReader streamReader = (StreamReader) null;
    HttpWebResponse httpWebResponse = (HttpWebResponse) null;
    try
    {
      stream = webRequest.GetRequestStream();
      stream.Write(bytes, 0, bytes.Length);
      stream.Flush();
      stream.Close();
      httpWebResponse = (HttpWebResponse) webRequest.GetResponse();
      streamReader = new StreamReader(httpWebResponse.GetResponseStream());
      return streamReader.ReadToEnd();
    }
    catch (WebException ex)
    {
      return ((object) ex.Message).ToString();
    }
    finally
    {
      if (stream != null)
        stream.Close();
      if (streamReader != null)
        streamReader.Close();
      if (httpWebResponse != null)
        httpWebResponse.Close();
    }
  }
}
