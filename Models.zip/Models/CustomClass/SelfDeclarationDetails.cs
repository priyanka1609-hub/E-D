﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomClass
{
    public class SelfDeclarationDetails : Repositry<SelfDeclarationDetails>
    {
        public virtual string ApplicationId { get; set; }
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicantName { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string ApplicantGender { get; set; }
        public virtual string ApplicantFatherName { get; set; }
        public virtual string ApplicantAddress { get; set; }
        public virtual string ApplicantDob { get; set; }
        public virtual string ServiceName { get; set; }

        public virtual string CurrentClass { get; set; }
        public virtual string CourseName { get; set; }
        public virtual string InstitutionName { get; set; }

    }
}