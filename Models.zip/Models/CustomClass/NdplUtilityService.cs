﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Edistrict.Models.CustomClass
{
    public class NdplUtilityService
    {
        public virtual string CANo { get; set; }
        public virtual string ConsumerName { get; set; }
        public virtual string BillAmount { get; set; }
        public virtual string DueDate { get; set; }

    }
}