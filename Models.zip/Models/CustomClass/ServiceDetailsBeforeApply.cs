﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.CustomClass
{
    public class ServiceDetailsBeforeApply : Repositry<ServiceDetailsBeforeApply>
    {
        public virtual string ServiceCode { get; set; }
        public virtual string ServiceName { get; set; }
        public virtual string ProcessingDays { get; set; }
        public virtual string IssuingAuthorities { get; set; }
        public virtual string DeptName { get; set; }
        public virtual string FeeStructure { get; set; }
        public virtual string SubmitAt { get; set; }
        public virtual string DeptCode { get; set; }
    }
}