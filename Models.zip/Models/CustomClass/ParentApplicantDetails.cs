﻿using System;
using System.Web;
using Edistrict.Models.Entities;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomClass
{
    public class ParentApplicantDetails : Repositry<ParentApplicantDetails>
    {
        public virtual string AadhaarNo { get; set; }
        public virtual string DocumentNo { get; set; }
        public virtual string ApplicantName { get; set; }
        public virtual string ApplicantGender { get; set; }
    }
}