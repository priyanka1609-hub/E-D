﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomClass
{
    public class AppointmentSubDiv : Repositry<AppointmentSubDiv>
    {
        public virtual string SubDivDescription { get; set; }
        public virtual string SubDivCode { get; set; }
    }
}