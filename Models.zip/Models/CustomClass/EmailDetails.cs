﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomClass
{
    public class EmailDetails : Repositry<EmailDetails>
    {
        public virtual string EmailServerFrom { get; set; }
        public virtual string EmailServerTo { get; set; }
        public virtual string EmailPassword { get; set; }
        public virtual string EmailSmtpServer { get; set; }
        public virtual string EmailPort { get; set; }
        public virtual string EmailSubject { get; set; }
        public virtual string EmailBody { get; set; }
        public virtual string EmailFromName { get; set; }
        public virtual string EmailServerCC { get; set; }
        public virtual string AttachFilePath { get; set; }
        public virtual string AttachFileName { get; set; }
    }
}