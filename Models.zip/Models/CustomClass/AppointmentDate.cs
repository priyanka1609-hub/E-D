﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomClass
{
    public class AppointmentDate : Repositry<AppointmentDate>
    {
        public virtual string AppointmentDateValue { get; set; }
        public virtual string AppointmentDateText { get; set; }
    }
}