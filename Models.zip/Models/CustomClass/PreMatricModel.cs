﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Npgsql;
using Edistrict.Models.Entities;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Edistrict.Models.ApplicationService;
using System.Data;

namespace Edistrict.Models.CustomClass
{
    public class PreMatricModel : Repositry<PreMatricModel>
    {
        [Required(ErrorMessage = "Value Required")]
        public virtual string CourseId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CourseName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AffiliatedId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string NoofSeats { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherApproved { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherActive { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string SchoolId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SchoolName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SchoolCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SchoolAddress { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string District { get; set; }
        public virtual string DistrictCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SubDivision { get; set; }
        public virtual string SubDivCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PinCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SchoolState { get; set; }
        public virtual string StateId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SchoolAffiliationId { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string UniversityName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AffiliationFrom { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AffiliationUpto { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string MobileNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string EmailId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]	
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string NodalOfficer { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string DepartmentId { get; set; }
        public virtual string DepartmentType { get; set; }
        public virtual string TypeId { get; set; }
        public virtual string Schooltypeid { get; set; }

        public DataTable data { get; set; }

        public SelectList DistrictList
        {
            get
            {
                //list used for only marriage

                string Qry = "select DistrictCode,DistrictName from DistrictMaster where deptcode=@DeptCode order by DistrictName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@DeptCode", (int)Department.Dept010);
                List<DistrictMaster> DistrictList = DistrictMaster.List<DistrictMaster>(Cmd);
                return new SelectList(DistrictList, "DistrictCode", "DistrictName");
            }
            set { }
        }
        public SelectList SubDivList
        {
            get
            {

                string Qry = "select SubDivCode,SubDivDescription from SubDivMaster where DistrictCode in (select DistrictCode from DistrictMaster where deptcode=@ParamDeptCode) order by SubDivDescription";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@ParamDeptCode", (int)Department.Dept010);
                List<SubDivMaster> SubDivList = SubDivMaster.List<SubDivMaster>(Cmd);
                return new SelectList(SubDivList, "SubDivCode", "SubDivDescription");
            }
            set { }
        }
        [CustomProperty]
        public SelectList StateMasterDelhiList
        {
            get
            {
                string Qry = "select StateId,StateName from dbo.StateMaster where stateid=@Delhi order by StateName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@Delhi", (int)State.Delhi);
                List<StateMaster> SubDivList = StateMaster.List<StateMaster>(Cmd);
                return new SelectList(SubDivList, "StateId", "StateName");
            }
            set { }
        }
    }
}