﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomClass
{
    public class SbiEpayParameterDetails : Repositry<SbiEpayParameterDetails>
    {
        
        public virtual string PaymentAmount { get; set; }
        public virtual string MerchantId { get; set; }
        public virtual string OperatingMode { get; set; }
        public virtual string MerchantCountry { get; set; }
        public virtual string MerchantCurrency { get; set; }
        public virtual string SuccessURL { get; set; }
        public virtual string FailURL { get; set; }
        public virtual string dbReturnUrl { get; set; }
        public virtual string AggregatorId { get; set; }
        public virtual string PayMode { get; set; }
        public virtual string AccesMedium { get; set; }
        public virtual string TransactionSource { get; set; }
        public virtual string EncodedKey { get; set; }
        public virtual int KeySize { get; set; }
    }
}
