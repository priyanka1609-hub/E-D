﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.CustomClass
{
    public class MICRResponse
    {
        public string MICRCode { get; set; }
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public string IFSCCode { get; set; }
        public string BankName { get; set; }
        public string BranchAddress { get; set; }
        public string BankCode { get; set; }
    }
}