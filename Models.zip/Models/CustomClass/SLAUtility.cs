﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomClass
{
    public class SLAUtility
    {
        public virtual string SLAID { get; set; }
        public virtual string Message { get; set; }
        public virtual string DataTransfred { get; set; }
    }
}