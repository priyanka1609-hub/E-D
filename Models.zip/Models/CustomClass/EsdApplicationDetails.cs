﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomClass
{
    public class EsdApplicationDetails : Repositry<EsdApplicationDetails>
    {
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string ApplicantName { get; set; }
        public virtual string FatherName { get; set; }
        public virtual string Address { get; set; }
        public virtual string DateOfApplication { get; set; }
        public virtual string DeptCode { get; set; }
        public virtual string DistrictCode { get; set; }
        public virtual string SubDivCode { get; set; }
        public virtual string VarField1 { get; set; }
        public virtual string VarField2 { get; set; }
        public virtual string VarField3 { get; set; }
        public virtual string VarField4 { get; set; }
        public virtual string VarField5 { get; set; }
        public virtual byte[] CertificateByteArray { get; set; }
    }
}