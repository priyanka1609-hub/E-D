﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomClass
{
    public class CitizenUserDetails : Repositry<CitizenUserDetails>
    {
        //public virtual string ApplicantUserID { get; set; }
        public virtual string RegistrationId { get; set; }
        public virtual string SahayakId { get; set; }
    }
}