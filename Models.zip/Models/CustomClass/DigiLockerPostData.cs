﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomClass
{
    public class DigiLockerPostData : Repositry<DigiLockerPostData>
    {
        public virtual string OrgId { get; set; }
        public virtual string KeyHash { get; set; }
        public virtual string TxnValue { get; set; }
        public virtual string TsValue { get; set; }
        public virtual string AppKey { get; set; }
        public virtual string PushUrl { get; set; }

        public virtual string Aadhaar { get; set; }
        public virtual string Uri { get; set; }
        public virtual string DocType { get; set; }
        public virtual string DocName { get; set; }
        public virtual string DocId { get; set; }
        public virtual string IssuedOn { get; set; }
        public virtual string ValidFrom { get; set; }
        public virtual string ValidTo { get; set; }
        public virtual string Timestamp { get; set; }
        public virtual string Action { get; set; }
    }
}