﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomClass
{
    public class DigiLockerRequestData : Repositry<DigiLockerRequestData>
    {
        public virtual string ApplicationNo { get; set; }


        public virtual string OrgId { get; set; }
        public virtual string KeyHash { get; set; }
        public virtual string TxnValue { get; set; }
        public virtual string TsValue { get; set; }
        public virtual string AppKey { get; set; }

        public virtual string Uri { get; set; }
        public virtual string DtxnValue { get; set; }
        public virtual string UDF1 { get; set; }
        public virtual string UDF2 { get; set; }
        public virtual string UDF3 { get; set; }

        public virtual string StatusCode { get; set; }
        public virtual string StatusName { get; set; }

    }
}