﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.Data;

namespace Edistrict.Models.CustomClass
{
    public class SLADetails : Repositry<SLADetails>
    {
        public virtual string username { get; set; }
        public virtual string password { get; set; }

        public virtual DataTable data { get; set; }
    }
}