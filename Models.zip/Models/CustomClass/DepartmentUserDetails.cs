﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomClass
{
    public class DepartmentUserDetails : Repositry<DepartmentUserDetails>
    {
        public virtual string UserId { get; set; }
        public virtual string Permission { get; set; }
        public virtual string DistrictCode { get; set; }
        public virtual string SubDivCode { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string DeptCode { get; set; }
        public virtual string AuthorizationId { get; set; }
        public virtual bool WhetherPasswordChange { get; set; }
        public virtual string LastLoginAttempt { get; set; }
    }
}