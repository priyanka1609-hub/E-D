﻿using System;
using System.Web;

namespace Edistrict.Models.CustomClass
{
    public class AadhaarResponse
    {
        public string AadhaarNo { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public string FatherName { get; set; }
        public string Dob { get; set; }
        public string Address { get; set; }
        public string PinCode { get; set; }
        public byte[] Photo { get; set; }
    }
}