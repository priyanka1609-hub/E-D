﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.Entities;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomClass
{
    public class VerifierVerificationDetails : Repositry<VerifierVerificationDetails>
    {
        public virtual string SentBy { get; set; }
        public virtual string SentTo { get; set; }
        public virtual string SentDate { get; set; }
        public virtual string VerificationDate { get; set; }
        public virtual string VerifierRemarks { get; set; }
        public List<VerifierVerificationReport> VerifierVerificationReport { get; set; }
    }
}