﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Data.SqlClient;
using Edistrict.Models.Entities;
using System.Web.Mvc;

namespace Edistrict.Models.CustomClass
{
    public class MarriageEnclosureDetails : Repositry<MarriageEnclosureDetails>
    {
        [ScaffoldColumn(false)]
        public virtual System.Nullable<int> EnclosureId { get; set; }
        [RegularExpression("([0-9]+)")]
        public virtual string DocumentTypeId { get; set; }
        [RegularExpression("([0-9]+)")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string HDocumentId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string HDocumentNo { get; set; }
        [RegularExpression("([0-9]+)")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string WDocumentId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WDocumentNo { get; set; }

        [CustomProperty]
        public virtual string RowNumber { get; set; }
        [CustomProperty]
        public virtual string DocumentTypeName { get; set; }
        [CustomProperty]
        public virtual SelectList EnclosureList
        {
            get
            {
                SqlCommand Cmd = new SqlCommand("select case when DMS.DocumentId is null then 0 else DMS.DocumentId end as DocumentId,case when DMS.DocumentName is null then DTM.DocumentTypeName else DMS.DocumentName end as DocumentName from DocumentTypeMaster DTM left outer join dbo.DocumentToTypeMaster DTT on DTT.DocumentTypeId=DTM.DocumentTypeId left outer join DocumentMaster DMS on DMS.DocumentId=DTT.DocumentId where DTM.DocumentTypeId=@DocumentTypeId;");
                Cmd.Parameters.AddWithValue("@DocumentTypeId", DocumentTypeId);
                return new SelectList(DocumentMaster.List<DocumentMaster>(Cmd), "DocumentId", "DocumentName");
            }
            set { }
        }
    }
}