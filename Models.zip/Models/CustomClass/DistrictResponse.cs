﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.CustomClass
{
    public class DistrictResponse : Repositry<DistrictResponse>
    {
        public string ApplicantDistrictCode { get; set; }
        public string ApplicantDistrictName { get; set; }
        public string ApplicantSubDivCode { get; set; }
        public string ApplicantSubDivDescription { get; set; }
        public string StateId { get; set; }
        public string StateName { get; set; }
        public string CountryId { get; set; }
        public string CountryName { get; set; }
        public string Pincode { get; set; }
        public string LocalityName { get; set; }
    }
}