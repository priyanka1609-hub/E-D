﻿using System;
using System.Web;

namespace Edistrict.Models.CustomClass
{
    public static class CustomRoles
    {
        public const string R101 = "101"; //Window
        public const string R102 = "102"; //Dealing Assistant
        public const string R103 = "103"; //Tehsildaar
        public const string R104 = "104"; //Sub Divisional Magistrate
        public const string R105 = "105"; //Monitoring
        public const string R106 = "106"; //Deputy Commissione
        public const string R107 = "107"; //Administrator
        public const string R108 = "108"; //Verifier
        public const string R109 = "109"; //Divisinol Commissioner
    }
}