﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.CustomClass
{
    public class RasPostData : Repositry<DigiLockerPostData>
    {
        public virtual string ApplicationNo { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string ApplicantMobileNo { get; set; }
        public virtual string ApplicantEmail { get; set; }

        public virtual string EdistServiceCode { get; set; }
        public virtual string EdistDeptCode { get; set; }
        public virtual string EdistStateCode { get; set; }

        public virtual string RasServiceCode { get; set; }
        public virtual string RasDeptCode { get; set; }
        public virtual string RasStateCode { get; set; }
    
    }
}