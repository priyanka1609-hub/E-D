﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Npgsql;

namespace Edistrict.Models.CustomClass
{
    public class CMDInfoList
    {
        public virtual int[] ParamenterIndex { get; set; }
        public bool Returns { get; set; }
        public NpgsqlCommand Cmd { get; set; }
        public virtual string Id { get; set; }
    }
}