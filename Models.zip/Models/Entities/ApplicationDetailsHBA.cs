﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsHBA : Repositry<ApplicationDetailsContractor>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual string DeptCode { get; set; }
        public virtual string DeptName { get; set; }
        public virtual string Whetherexist { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerRegNo { get; set; }        
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicantName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Permanentaddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Presentaddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Applicantdob { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateofretirment { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicantregNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateofreg { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Rateofremittence { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateoffirstremittance { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Totalamountremitted { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whethermembrevived { get; set; }
        [RequiredIf("Whethermembrevived", "True", ErrorMessage = "Value Required")]
        public virtual string Detailsofrevival { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Purposeofadvance { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherownhouse { get; set; }
        [RequiredIf("Whetherownhouse", "True", ErrorMessage = "Value Required")]
        public virtual string Detailsofhouse { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Advanceamount { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Panchayat { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Village { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Taluka { get; set; }
        [Required(ErrorMessage = "Invalid District")]
        public virtual string DistrictCode { get; set; }
        public virtual string DistrictName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Area { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SurveyNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Propertyvaluation { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherloanreceived { get; set; }
        [RequiredIf("Whetherloanreceived", "True", ErrorMessage = "Value Required")]
        public virtual string Detailsofloan { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Buildingestimation { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Amountraised { get; set; }
         [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherpreviousloan { get; set; }
               

        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList DistrictList
        {
            get
            {
                string Qry = "select DistrictCode,DistrictName from DistrictMaster where deptcode=@DeptCode order by DistrictName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@DeptCode", (int)Department.Dept016);
                List<DistrictMaster> DistrictList = DistrictMaster.List<DistrictMaster>(Cmd);
                return new SelectList(DistrictList, "DistrictCode", "DistrictName");
            }
            set { }
        }
    }
}