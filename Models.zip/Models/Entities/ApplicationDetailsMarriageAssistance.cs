﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    
    public class ApplicationDetailsMarriageAssistance: Repositry<ApplicationDetailsContractor>,IValidatableObject //change22022018
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string Dob { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Check Box Checked Required")]
        public virtual bool check { get; set; }
        public virtual string Whetherexist { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicantRelationId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicantrelationName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerRegNo { get; set; }
        
        [Required(ErrorMessage = "Value Required")]
        public virtual string Workerdob { get; set; }
       
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateoffirstpayment { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateoflasttsubscription { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string Firstsubsamount { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Firstsubscription { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string Lastsubsamount { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Lasttsubscription { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Firstnameofbank { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Lastnameofbank { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FirstbranchName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LastbranchName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Durationofmembership { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherworkermemblive { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Whethermarriageapplication { get; set; }

        [RequiredIf("Whethermarriageapplication", "True", ErrorMessage = "Value Required")]
        public virtual string Whethermembofboard { get; set; }
        [RequiredIf("Whethermembofboard", "True", ErrorMessage = "Value Required")]
        public virtual string Whetherappliedforfa { get; set; }

        [RequiredIf("Whethermarriageapplication", "True", ErrorMessage = "Value Required")]
        public virtual string Sondaughterdob { get; set; }
        [RequiredIf("Whethermarriageapplication", "True", ErrorMessage = "Value Required")]
        public virtual string Addressofbridegroom { get; set; }
        [RequiredIf("Whethermarriageapplication", "True", ErrorMessage = "Value Required")]
        public virtual string Mariagedateofcerti { get; set; }
        [RequiredIf("Whethermarriageapplication", "True", ErrorMessage = "Value Required")]
        public virtual string MarriagecertiNo { get; set; }
        [RequiredIf("Whethermarriageapplication", "True", ErrorMessage = "Value Required")]
        public virtual string Nameofauthotiry { get; set; }
        [RequiredIf("Whethermarriageapplication", "True", ErrorMessage = "Value Required")]
        public virtual string Addressofauthority { get; set; }
        [RequiredIf("Whethermarriageapplication", "True", ErrorMessage = "Value Required")]
        public virtual string whetherappliedforfaself { get; set; }
        [RequiredIf("Whethermarriageapplication", "True", ErrorMessage = "Value Required")]
        public virtual string Detailsoffinassistance { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherselfmarriage { get; set; }
        [RequiredIf("Whetherselfmarriage", "True", ErrorMessage = "Value Required")]
        public virtual string Nameofhusband { get; set; }
        [RequiredIf("Whetherselfmarriage", "True", ErrorMessage = "Value Required")]
        public virtual string Addressofhusband { get; set; }
        
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateofmarriage { get; set; }
        
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string Addressofmarriageplace { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string Selfdateofissuedcerti { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string SelfissuedcertiNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherreceivedfinassistance { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string BeneficiaryAadhaarNo { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string FirstBankMICR { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string LastBankMICR { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerRegDate { get; set; }
        
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string BrideName { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string GroomName { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string BrideDOB { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string GroomDOB { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountHolderName { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountNo { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string MICRCode { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankCode { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string BranchAddress { get; set; }


        //change22022018
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (Convert.ToDateTime(Dateoffirstpayment) > Convert.ToDateTime(Dateoflasttsubscription))
            {
                yield return new ValidationResult("Date of fist subscription can not be greater than date of last subscription", new string[] { "Dateoffirstpayment" });
            }
            if (DateTime.Now.Year - Convert.ToDateTime(GroomDOB).Year < 17)
            {
                yield return new ValidationResult("Age of Groom must not be less than 18 Years", new string[] { "GroomDOB" });
            }
            if (DateTime.Now.Year - Convert.ToDateTime(BrideDOB).Year < 17)
            {
                yield return new ValidationResult("Age of Bride must not be less than 18 Years", new string[] { "BrideDOB" });
            }
        }

        //change16022018
        [CustomProperty]
        public SelectList BankMasterList
        {
            get
            {
                List<BankMaster> BankMasterList = BankMaster.List<BankMaster>(new Npgsql.NpgsqlCommand("select BankCode,BankName from dbo.BankMaster"));
                return new SelectList(BankMasterList, "BankCode", "BankName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList MaritalStatusMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.MaritalStatus);
                List<ServiceTypeMaster> MaritalStatusMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(MaritalStatusMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList NatureofDeath
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CauseOfDeath);
                List<ServiceTypeMaster> MaritalStatusMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(MaritalStatusMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MemberRelationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select relationid as Valueid,relationname as Valuename from relationmaster  order by 1");
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
    }
}