﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsMaternityBenefit : Repositry<ApplicationDetailsContractor>, IValidatableObject //change16022018
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual bool WhetherExist { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerRegNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Workerdob { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Gender { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofhusband { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateofconfinement { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherapplied { get; set; }

        [RequiredIf("Whetherapplied", "True", ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string Nooftimeapplied { get; set; }
        [RequiredIf("Whetherapplied", "True", ErrorMessage = "Value Required")]
        public virtual string Detailsofbenefit { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateofreg { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateoffirstsubspayment { get; set; }
        
        //change16022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string Firstsubsamount { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateoflastsubspayment { get; set; }
        
        //change16022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string Lastsubsamount { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofbank { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Placeofbank { get; set; }


        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountHolderName { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountNo { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string MICRCode { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankCode { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string BranchAddress { get; set; }
        
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string BirthPlace { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string HospitalDetails { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string HomeDetails { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string NameOfDai { get; set; }
        
        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }

        //change16022018
        [CustomProperty]
        public SelectList BankMasterList
        {
            get
            {
                List<BankMaster> BankMasterList = BankMaster.List<BankMaster>(new Npgsql.NpgsqlCommand("select BankCode,BankName from dbo.BankMaster"));
                return new SelectList(BankMasterList, "BankCode", "BankName");
            }
            set { }
        }

        //change22022018
        [CustomProperty]
        public SelectList BirthPlaceList
        {
            get {
              
                List<SelectListItem> selectItemList = new List<SelectListItem>();

                // Get all values of the Industry enum
                var enumValues = Enum.GetValues(typeof(BirthPlace)) as BirthPlace[];
                if (enumValues == null)
                    return null;

                foreach (var enumValue in enumValues)
                {
                    selectItemList.Add(new SelectListItem
                    {
                        Value =((int)enumValue).ToString(),
                        Text = enumValue.ToString()
                    });
                }

                return new SelectList(selectItemList.AsEnumerable(),"value","text");
            }
        }

        //change16022018
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (Convert.ToDateTime(Dateoffirstsubspayment) > Convert.ToDateTime(Dateoflastsubspayment))
            {
                yield return new ValidationResult("Date of fist subscription can not be greater than date of last subscription", new string[] { "Dateoffirstsubspayment" });
            }

            if (Convert.ToDateTime(Dateofreg) > Convert.ToDateTime(Dateoffirstsubspayment))
            {
                yield return new ValidationResult("Date of Registration can not be greater than date of fist subscription", new string[] { "Dateofreg" });
            }
        }
    }
}