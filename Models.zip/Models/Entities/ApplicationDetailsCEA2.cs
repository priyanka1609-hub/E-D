﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsCEA2 : Repositry<ApplicationDetailsCEA2>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationStatusId { get; set; }

        public virtual string RIOName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string NameofohLine { get; set; }        
        [Required(ErrorMessage = "Value Required")]
        public virtual string Localityofins { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LocationofohLine { get; set; }  
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofowner { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AddrofOwner { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofconcerned { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Addrofconcerned { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Mobilenoofconcerned { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Emailofconcerned { get; set; }        
        public virtual string FeeDeposit { get; set; }
        public virtual string LocalityName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherInsCompleted { get; set; }
        [RequiredIf("WhetherInsCompleted", "True", ErrorMessage = "Value Required")]
        public virtual string DateofInspection { get; set; }
        [RequiredIf("WhetherInsCompleted", "No", ErrorMessage = "Value Required")]
        public virtual string TargetDate { get; set; }
        [RequiredIf("WhetherInsCompleted", "No", ErrorMessage = "Value Required")]
        public virtual string ProbDateofInsp { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SingleCiruit { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DoubleCiruit { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string TotalRouteLen { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Conductor { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string GroundWire { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Average { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Minimum { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Maximum { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string NormalSpan { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string NHighway { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SHighway { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string OtherRoad { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PL800kV { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PL400kV { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PL220kV { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PL132kV { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PL66kV { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PL33kV { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PL11kV { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LTLines { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string RailwayCrossing { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string RiverCrossing { get; set; }        
        [Required(ErrorMessage = "Value Required")]
        public virtual string SpecialCrossing { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FactofSafety { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherDuly { get; set; }
        [RequiredIf("WhetherDuly", "True", ErrorMessage = "Value Required")]
        public virtual string TowerACD { get; set; }
        [RequiredIf("WhetherDuly", "True", ErrorMessage = "Value Required")]
        public virtual string DangerNB { get; set; }
        [RequiredIf("WhetherDuly", "True", ErrorMessage = "Value Required")]
        public virtual string LightningFaults { get; set; }
        [RequiredIf("WhetherDuly", "True", ErrorMessage = "Value Required")]
        public virtual string GroundFaults { get; set; }
        [RequiredIf("WhetherDuly", "True", ErrorMessage = "Value Required")]
        public virtual string SnappedConductors { get; set; }
        [RequiredIf("WhetherDuly", "True", ErrorMessage = "Value Required")]
        public virtual string OtherProtection { get; set; }
        [RequiredIf("WhetherDuly", "True", ErrorMessage = "Value Required")]
        public virtual string VolRegulation { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherCEAProv { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherInspSubstation { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AppforInspection { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MaxHeightofTower { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string NearDistofLine { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string NameofSubStation { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BayNo { get; set; }
        public virtual string Counter1 { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherPertainEI { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string NoofTowers { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ConductorType { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Route { get; set; }

        public virtual DataTable data { get; set; }
        public virtual DataTable data1 { get; set; }

        public SelectList LocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@Dept and dm.stateid=@stateid and LM.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@Dept", (int)Department.Dept007);
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList YesList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList YesNoNAList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                list.Add(new SelectListItem() { Text = "N/A", Value = "NA" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList RouteLengthList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.RouteLengthType);
                List<SelectValueMaster> NatureOfEstList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(NatureOfEstList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList SizeofList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SizeofType);
                List<SelectValueMaster> NatureOfEstList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(NatureOfEstList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList SpanList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SpanType);
                List<SelectValueMaster> NatureOfEstList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(NatureOfEstList, "SelectValueId", "SelectValueName");
            }
            set { }
        }   
        public SelectList RoadCrossingTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.RoadCrossingType);
                List<SelectValueMaster> NatureOfEstList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(NatureOfEstList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList PowerLinesList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId ");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.PowerLinesTypeList);
                List<SelectValueMaster> NatureOfEstList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(NatureOfEstList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
    }
}