﻿using System;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class CDVSubDivMaster : Repositry<CDVSubDivMaster>
    {
        public virtual string CDVSubDivCode { get; set; }
        public virtual string CDVSubDivName { get; set; }
        public virtual bool WhetherActive { get; set; }
    }
}