﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsCompCertificate:Repositry<ApplicationDetailsCompCertificate>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string NameofApplicant { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DOBofApplicant { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LocalityofIns { get; set; }
        public virtual string LocalityName { get; set; }
        public virtual string FeeDeposit { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("^[0-9]*$", ErrorMessage = "Enter Valid Value")]
        public virtual string AgeofApplicant { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicantadharNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FathersName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string EduQualiId { get; set; }
        public virtual string EduQualiName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicantResiAdd { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string YearofPassing { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string AcademicQualification { get; set; }
        public virtual string AcademicQualificationName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CourseType { get; set; }
        public virtual string CourseTypeName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PassingMonth { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string NameofFirm { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string NatureofWork { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DateofJoining { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DateofLeaving { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string TotalExp { get; set; }
        public virtual string Counter1 { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual DataTable data { get; set; }
        public virtual DataTable data1 { get; set; }

        public SelectList LocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@Dept and dm.stateid=@stateid and LM.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@Dept", (int)Department.Dept007);
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList EducationQualificationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.TechnicalEduQual);
                List<SelectValueMaster> Constitution = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(Constitution, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList YearList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int varYear = 1960;
                for (int i = varYear; i < DateTime.Now.AddYears(1).Year; i++)
                {
                    list.Add(new SelectListItem() { Text = varYear.ToString(), Value = varYear.ToString() });
                    varYear++;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList TypeofCourse
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.NatureofWork);
                List<SelectValueMaster> NatureofWork = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(NatureofWork, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        //Change02022018
        public SelectList TypeofAcademicQuali
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.AcademicQualification);
                List<SelectValueMaster> NatureofWork = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(NatureofWork, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList MonthList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                DateTime month = Convert.ToDateTime("1/1/2000");
                for (int i = 0; i < 12; i++)
                {
                    DateTime NextMont = month.AddMonths(i);
                    list.Add(new SelectListItem() { Text = NextMont.ToString("MMMM"), Value = NextMont.Month.ToString() });
                }
                return new SelectList(list, "Text", "Text");
            }
            set { }
        }       
    }
}