﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;
using System.Data;

namespace Edistrict.Models.Entities
{

    public class ApplicationDetailsEduScholarship : Repositry<ApplicationDetailsContractor>, IValidatableObject//change19022018
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual string Whetherexist { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicantrelationName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerRegNo { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofstudent { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Gender { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Category { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherproofattached { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CollegeName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Affiliatedboard { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CourseName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Courseyear { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateofadmission { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Studentdob { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofexam { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CollegeaffiliationName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Passingmonth { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Passingyear { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicantparentName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string RegNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateoffirstpayment { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateoflastpayment { get; set; }

        //change19022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string Noofpaidinstallments { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Applicantpermanentaddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whethermembshiprevived { get; set; }
        [RequiredIf("Whethermembshiprevived", "True", ErrorMessage = "Value Required")]
        public virtual string Periodofrevival { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string SubjectName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Markesobtained { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Maxmarks { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Markspercentage { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Totalmarks { get; set; }

        public DataSet ds { get; set; }
        public DataTable dt1 { get; set; }

        public virtual string WCounter1 { get; set; }
        public virtual string CCounter { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public string BeneficiaryAadhaarNo { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public string WhetherStudentMarried { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public string WhetherStudentWorking { get; set; }


        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public string CourseType { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public string Education { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public string CourseStartMonth { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public string CourseEndMonth { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public string CourseStartYear { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public string CourseEndYear { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public string CourseDuration { get; set; }

        //change28032018
        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountHolderName { get; set; }
        //change28032018
        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountNo { get; set; }
        //change28032018
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        //change28032018
        [Required(ErrorMessage = "Value Required")]
        public virtual string MICRCode { get; set; }
        //change28032018
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankCode { get; set; }
        //change28032018
        [Required(ErrorMessage = "Value Required")]
        public virtual string BranchAddress { get; set; }

        //change19022018
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (Convert.ToDateTime(Dateoffirstpayment) > Convert.ToDateTime(Dateoflastpayment))
            {
                yield return new ValidationResult("Date of fist subscription can not be greater than date of last subscription", new string[] { "Dateoffirstpayment" });
            }
        }



        //change22022018
        public virtual SelectList YearList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int varYear = 2000;
                for (int i = varYear; i < DateTime.Now.AddYears(1).Year; i++)
                {
                    list.Add(new SelectListItem() { Text = varYear.ToString(), Value = varYear.ToString() });
                    varYear++;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }


        //change22022018
        public virtual SelectList DurationList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem { Text = "First Year", Value = "First Year" });
                list.Add(new SelectListItem { Text = "Second Year", Value = "Second Year" });
                list.Add(new SelectListItem { Text = "Third Year", Value = "Third Year" });
                list.Add(new SelectListItem { Text = "Fourth Year", Value = "Fourth Year" });
                list.Add(new SelectListItem { Text = "Completed", Value = "Completed" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }

        //change22022018
        public virtual SelectList EducationList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem { Text = "MCD", Value = "MCD" });
                list.Add(new SelectListItem { Text = "Higher Education", Value = "Higher Education" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }

        public virtual SelectList MonthList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                DateTime month = Convert.ToDateTime("1/1/2000");
                for (int i = 0; i < 12; i++)
                {
                    DateTime NextMont = month.AddMonths(i);
                    list.Add(new SelectListItem() { Text = NextMont.ToString("MMMM"), Value = NextMont.Month.ToString() });
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }

        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }

        //change22022018
        public SelectList CourseTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.CourseType);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }

        //change22022018
        public SelectList CourseNameList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select hecourseid as SelectValueId,coursename as SelectValueName from hecoursemaster where servicecode=@servicecode");
                Cmd.Parameters.AddWithValue("@servicecode", (int)ServiceList.EduScholarship);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }

        //change22022018
        public SelectList CategoryList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.GeneralSCSTOBC);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }


        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }

        [CustomProperty]
        public SelectList MemberRelationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select relationid as Valueid,relationname as Valuename from relationmaster  order by 1");
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
    }
}