﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;

namespace Edistrict.Models.Entities
{
    public class SocietyMemberDetails : Repositry<SocietyMemberDetails>
    {
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string MemberId { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string MemberName { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string MemberFatherName { get; set; }
        public virtual string MemberAddress { get; set; }
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid")]
        [Range(1, 10, ErrorMessage = "Enter Valid")]
        [StringLength(2, MinimumLength = 1)]
        public virtual string MemberAge { get; set; }
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter valid Value")]
        public virtual string SocietyJoiningDate { get; set; }
        public virtual string IdentityDocumentId { get; set; }
        public virtual string IdentityDocumentNo { get; set; }
        public virtual string IdentityDocumentData { get; set; }
    }
}