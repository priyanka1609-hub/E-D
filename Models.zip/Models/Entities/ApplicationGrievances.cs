﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class ApplicationGrievances : Repositry<ApplicationGrievances>
    {
        
        [Required(ErrorMessage = "{0} Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string ApplicantName { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string ApplicantMobileNo { get; set; }
        [StringLength(100, MinimumLength = 8), Required(ErrorMessage = "Email Required")]
        [DataType(DataType.EmailAddress, ErrorMessage = "Enter valid Email")]
        [RegularExpression(@"[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Enter valid Email")]
        public virtual string ApplicantEmail { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [StringLength(500, MinimumLength = 20, ErrorMessage = "Minimum 20 & Maximum 500 character allowed")]
        [Required(ErrorMessage = "Query Description Required")]
        public virtual string QueryDescription { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string QueryDate { get; set; }
        public virtual string WhetherReplied { get; set; }
        [StringLength(500, MinimumLength = 20, ErrorMessage = "Minimum 20 & Maximum 500 character allowed")]
        public virtual string RepliedAnswer { get; set; }
        public virtual string RepliedBy { get; set; }
        public virtual string RepliedDate { get; set; }
        public virtual string RepliedByIpAddress { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherTechnical { get; set; }
        public virtual string WhetherAssigned { get; set; }
        public virtual string AssignedSubdivision { get; set; }
        public virtual string AssignedBy { get; set; }
        public virtual string AssignedDate { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(10, MinimumLength = 10)]
        public virtual string RegistrationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(10, MinimumLength = 10)]
        public virtual string OldGrievanceId { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string DepartmentId { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string GrievanceId { get; set; }
    }
}