﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsRenewalOfPassengerLift : Repositry<ApplicationDetailsRenewalOfPassengerLift>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofowner { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Addrofowner { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LicenseNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LicenseDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Premises { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LiftLocation { get; set; }
        //public virtual string FeeDeposit { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [Range(0.5, 5.0, ErrorMessage = "Speed must be between 0.5 and 5.0")]
        [RegularExpression(@"^(\d{0,9}|\d{1}\.\d{1,2})$", ErrorMessage = "Only Decimal allowed")]
        public virtual string MaxSpeed { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AppLocalityId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string InspectorName { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string InspectorMobileNo { get; set; }
        public virtual string AadhaarNo { get; set; }
        public DataTable data { get; set; }
        [RequiredIf("whetherchangesrequired", "True", ErrorMessage = "Required")]
        public virtual string ProposedAddrofOwner { get; set; }
        [RequiredIf("whetherchangesrequired", "True", ErrorMessage = "Required")]
        public virtual string ProposedNameofOwner { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string whetherchangesrequired { get; set; }
        public virtual bool WhetherExist { get; set; }
        public virtual string ServerType { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Check Box Checked Required")]
        public virtual bool check { get; set; }
        public virtual string LocalityName { get; set; }

        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList LocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@Dept and dm.stateid=@stateid and LM.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@Dept", (int)Department.Dept007);
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
    }
}