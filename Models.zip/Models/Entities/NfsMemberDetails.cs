﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;

namespace Edistrict.Models.Entities
{
    public class NfsMemberDetails : Repositry<NfsMemberDetails>
    {
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string MemberId { get; set; }
        [Required(ErrorMessage = "AadhaarNo Required")]
        [StringLength(12, MinimumLength = 12)]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Aadhaar No")]
        public virtual string Aadhaarno { get; set; }
        [Required(ErrorMessage = "Name Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        public virtual string MemberName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Gender { get; set; }
        public virtual string GenderType { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DOB { get; set; }
        [Required(ErrorMessage = "Name Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        public virtual string MotherName { get; set; }
        [Required(ErrorMessage = "Name Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        public virtual string FatherName { get; set; }
        [Required(ErrorMessage = "Name Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        public virtual string SpouseName { get; set; }
        public virtual string RelationWithHOFId { get; set; }
        public virtual string RelationWithHOFType { get; set; }
    }
}