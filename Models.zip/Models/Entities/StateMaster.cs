﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class StateMaster : Repositry<StateMaster>
    {
        public virtual string StateId { get; set; }
        public virtual string StateName { get; set; }
    }
}