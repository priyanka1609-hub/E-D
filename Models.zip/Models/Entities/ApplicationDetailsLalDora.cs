﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.ApplicationService;
using Npgsql;
namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsLalDora : Repositry<ApplicationDetailsLalDora>
    {
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationId { get; set; }

        public virtual string RowNumber { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string PurposeOfCertificate { get; set; }


        [Range(0, 99, ErrorMessage = "Enter Valid Year")]
        [RegularExpression("[0-9]+", ErrorMessage = " InValid Input")]
        [StringLength(2, MinimumLength = 1, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Year Required")]
        public virtual string YearOfLiving { get; set; }

        [StringLength(2, MinimumLength = 1, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Month Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Month")]
        [Range(0, 12, ErrorMessage = "Enter Valid Month")]
        public virtual string MonthOfLiving { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string StateId { get; set; }
        public virtual string StateName { get; set; }

        [Required(ErrorMessage = "District Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid District")]
        public virtual string DistrictCode { get; set; }
        public virtual string DistrictName { get; set; }

        [Required(ErrorMessage = "Sub Division Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Sub Division")]
        public virtual string SubDivCode { get; set; }
        public virtual string SubDivName { get; set; }

        [Required(ErrorMessage = "Village Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Village")]
        public virtual string VillageId { get; set; }
        public virtual string VillageName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string LandDetail { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string KhasraNo { get; set; }

        [Required(ErrorMessage = "Land Information Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Land Information")]
        public virtual string LandTypeId { get; set; }
        public virtual string LandTypeName { get; set; }


        [Required(ErrorMessage = "Value Required")]
        public virtual string TotalLandMeasurement { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string LandSurroundedEast { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string LandSurroundedWest { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string LandSurroundedNorth { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string LandSurroundedSouth { get; set; }

        [Required(ErrorMessage = "Acquired Plot Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Acquired Plot Information")]
        public virtual string LandAcquiredTypeId { get; set; }
        public virtual string LandAcquiredTypeName { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string LastActionDate { get; set; }

        public virtual WitnessDetailsLalDora WitnessDetailsLalDora { get; set; }

        [CustomProperty]
        public SelectList StateList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select stateid,statename from StateMaster where stateid in(@state) order by StateName");
                cmd.Parameters.AddWithValue("@state", (int)State.Delhi);
                List<StateMaster> StateList = StateMaster.List<StateMaster>(cmd);
                return new SelectList(StateList, "stateid", "statename");
            }
            set { }
        }

        [CustomProperty]
        public SelectList DistrictList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select districtcode,districtname from dbo.districtmaster where deptcode=@deptcode and stateid=@state order by districtname");
                cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                cmd.Parameters.AddWithValue("@state", (int)State.Delhi);
                List<DistrictMaster> DistrictList = DistrictMaster.List<DistrictMaster>(cmd);
                return new SelectList(DistrictList, "districtcode", "districtname");
            }
            set { }
        }

        [CustomProperty]
        public SelectList SubDivtList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select Subdivcode,SubDivdescription from dbo.Subdivmaster where districtcode in (select districtcode from dbo.districtmaster where deptcode=@deptcode) order by SubDivdescription");
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                List<SubDivMaster> SubDivtList = SubDivMaster.List<SubDivMaster>(Cmd);
                return new SelectList(SubDivtList, "Subdivcode", "SubDivdescription");
            }
            set { }
        }

        [CustomProperty]
        public SelectList VillageList
        {
            get
            {
                List<VillageMaster> VillageList = VillageMaster.List<VillageMaster>(new Npgsql.NpgsqlCommand("select Villageid,villagename from dbo.villagemaster order by villagename"));
                return new SelectList(VillageList, "Villageid", "villagename");
            }
            set { }
        }

        [CustomProperty]
        public SelectList LandTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.Solvency);
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.LalDoraDetails);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList LandAcquireTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.Solvency);
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.AcauiredDetailsForLalDora);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }


    }
}