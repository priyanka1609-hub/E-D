﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class PermissionMaster : Repositry<PermissionMaster>
    {
        public virtual System.Nullable<int> Pid { get; set; }
        public virtual string Pcode { get; set; }
        public virtual string Pname { get; set; }
        public virtual string WhetherActive { get; set; }
    }
}