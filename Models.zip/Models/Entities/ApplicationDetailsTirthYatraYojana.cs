﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Collections.Generic;
using Edistrict.Models.CustomAttribute;
using Npgsql;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsTirthYatraYojana : Repositry<ApplicationDetails>
    {
        [Required(ErrorMessage = "Route is Required")]
        public virtual string RouteId { get; set; }
        public virtual string RouteName { get; set; }
        public virtual string ApplicationId { get; set; }
        [Required(ErrorMessage = "Constituency is Required")]
        public virtual string ConstituencyId { get; set; }
        public virtual string ApplicantGender { get; set; }
        public virtual string ApplicantDob { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string whetherGovtEmp { get; set; }
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string whetherAppyingWithSpouse { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Valid Spouse Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Spouse Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Spouse Name")]
        [RequiredIf("whetherAppyingWithSpouse", "True", ErrorMessage = "Spouse Name Required")]
        public virtual string SpouseName { get; set; }
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        [RequiredIf("whetherAppyingWithSpouse", "True", ErrorMessage = "Spouse Date of Birth Required")]
        public virtual string SpouseDob { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string whetherSpouseGovtEmp { get; set; }
        [RequiredIf("whetherAppyingWithSpouse", "True", ErrorMessage = "Spouse  Voter Id Required")]
        [StringLength(17, MinimumLength = 10, ErrorMessage = "Enter Valid Voter Id No")]
        //[RegularExpression("([A-Za-z0-9]+)", ErrorMessage = "Enter Valid Voter Id No")]
        [RegularExpression(@"^([a-zA-Z0-9\\\/]{10,17})$", ErrorMessage = "Enter Valid Voter Id No")]
        public virtual string SpouseDocumentNo { get; set; }
        [RequiredIf("whetherAppyingWithSpouse", "True", ErrorMessage = "Required")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter 10 Digit mobile No.")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Spouse Mobile No.")]
        public virtual string SpouseMobileNo { get; set; }
        [RequiredIf("whetherAppyingWithSpouse", "True", ErrorMessage = "Required")]
        public virtual string SpouseGender { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string optingForAttendant { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Valid Attendant Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Attendant Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Attendant Name")]
        [RequiredIf("optingForAttendant", "True", ErrorMessage = "Attendant Name Required")]
        public virtual string AttendantName { get; set; }
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        [RequiredIf("optingForAttendant", "True", ErrorMessage = "Attendant Date of Birth Required")]
        public virtual string AttendantDob { get; set; }
        [RequiredIf("optingForAttendant", "True", ErrorMessage = "Attendant Gender Required")]
        public virtual string AttendantGender { get; set; }
        [RequiredIf("optingForAttendant", "True", ErrorMessage = "Attendant  Voter Id Required")]
        [StringLength(17, MinimumLength = 10, ErrorMessage = "Enter Valid Voter Id No")]
        //[RegularExpression("([A-Za-z0-9]+)", ErrorMessage = "Enter Valid Voter Id No")]
        [RegularExpression(@"^([a-zA-Z0-9\\\/]{10,17})$", ErrorMessage = "Enter Valid Voter Id No")]
        public virtual string AttendantDocumentNo { get; set; }
        [RequiredIf("optingForAttendant", "True", ErrorMessage = "Attendant No. Mobile Required")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter 10 Digit mobile No.")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Attendant Mobile No.")]
        public virtual string AttendantMobileNo { get; set; }
        public virtual string ConstituencyName { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [Required(ErrorMessage = "Ref Person 1 Name Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Valid Ref Person 1 Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Ref Person 1 Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Ref Person 1 Name")]
        public virtual string Ref1Name { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Mobile No."), Required(ErrorMessage = "Mobile Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string Ref1MobileNo { get; set; }
        [Required(ErrorMessage = "Address Required")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string Ref1Address { get; set; }
        [Required(ErrorMessage = "Ref Person 2 Name Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Valid Ref Person 2 Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Ref Person 2 Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Ref Person 2 Name")]
        public virtual string Ref2Name { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Mobile No."), Required(ErrorMessage = "Mobile Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string Ref2MobileNo { get; set; }
        [Required(ErrorMessage = "Address Required")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string Ref2Address { get; set; }
        public virtual string WhetherAllocateTravel { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string TravelDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string TravelTime { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BoardingFrom { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string TourDetails { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BusDetails { get; set; }
        public virtual string VerifyByRemarks { get; set; }
        public virtual string VerifyBy { get; set; }
        public virtual string VerifyIpAddress { get; set; }
        public virtual string VerifyDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SeatNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CoachNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string TravelByTypeId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DrawNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PriorityNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherInDraw { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DurationId { get; set; }

        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter 10 Digit mobile No.")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Alternate Mobile No.")]
        public virtual string AlternateMobileNo { get; set; }
        //[StringLength(15, MinimumLength = 11, ErrorMessage = "Enter valid Landline No.")]
        //[RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter valid Landline No.")]
        public virtual string LandlineNo { get; set; }
        [StringLength(50, MinimumLength = 8)]
        [DataType(DataType.EmailAddress, ErrorMessage = "Enter valid Email Id")]
        [RegularExpression(@"[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Enter valid Email Id")]
        public virtual string EmailId { get; set; }

        [CustomProperty]
        public SelectList RouteList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename||' ('|| routeduration||')' as valuename  from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid inner join routedurationmaster RDM on RDM.RouteId=SMVD.valueid where SMVTD.whetheractive=TRUE and SMV.mastervalueid=@mastervalueid and RDM.whetheractive=TRUE");//Changes20180801
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.TirthYatraRouteList);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList YearList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int varYear = 2018;
                for (int i = varYear; i < DateTime.Now.AddYears(1).Year; i++)
                {
                    list.Add(new SelectListItem() { Text = varYear.ToString(), Value = varYear.ToString() });
                    varYear++;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList MonthList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                DateTime month = Convert.ToDateTime("1/1/2000");
                for (int i = 0; i < 12; i++)
                {
                    DateTime NextMont = month.AddMonths(i);
                    list.Add(new SelectListItem() { Text = NextMont.ToString("MMMM"), Value = NextMont.Month.ToString() });
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public virtual SelectList AssemblyConstituencyList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select constituencyid,constituencyname from assemblyconstituencymaster where whetheractive=true order by constituencyname ;");
                List<AssemblyConstituencyMaster> AssemblyConstituencyList = AssemblyConstituencyMaster.List<AssemblyConstituencyMaster>(Cmd);
                return new SelectList(AssemblyConstituencyList, "constituencyid", "constituencyname");
            }
            set { }
        }

    }
}