﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class RelationMaster : Repositry<RelationMaster>
    {
        public virtual string RelationId { get; set; }
        public virtual string RelationName { get; set; }


    }
}