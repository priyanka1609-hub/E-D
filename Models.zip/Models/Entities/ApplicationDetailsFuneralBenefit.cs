﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsFuneralBenefit : Repositry<ApplicationDetailsFuneralBenefit>,IValidatableObject //change19022018
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string Dob { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Check Box Checked Required")]
        public virtual bool check { get; set; }
        public virtual string Whetherexist { get; set; }
        
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicantRelationId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicantrelationName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerRegNo { get; set; }
        [Required(ErrorMessage = "Value Required")]

        public virtual string WorkerRegDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerAge { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Workerdob { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateoffirstpayment { get; set; }
        
        //change22022018
        //[Required(ErrorMessage = "Value Required")]
        public virtual string Dateoflastpayment { get; set; }
        
        //change19022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)",ErrorMessage="Enter only numbers")]
        public virtual string Firstsubsamount { get; set; }

        //change19022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string Firstsubscription { get; set; }

        //change19022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string Lastsubsamount { get; set; }

        //change19022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string Lasttsubscription { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Firstnameofbank { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Lastnameofbank { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FirstbranchName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LastBranchName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Durationofmembership { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherworkermemblive { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Workerdateofdeath { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Workerdeathreason { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherworkernominee { get; set; }
        [RequiredIf("Whetherworkernominee", "True", ErrorMessage = "Value Required")]
        public virtual string Whtherapplicantdependencecerti { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string NomineeName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nomineedob { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whethernomineeminor { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string NomineguardianName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string NomineerelationshipId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whethernomineeconsentletter { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherminorcertificate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Amountofbenefit { get; set; }
        
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string WhetherWorkerMarriedId { get; set; }
        
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherWorkerMarriedName { get; set; }


        //change22022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string NomineeAccountNo { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string NomineeBankMICR { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string NomineeBankName { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string NomineeBankBranch { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string FirstBankMICR { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string LastBankMICR { get; set; }


        public DataTable dt1 { get; set; }


        //change19022018
        [CustomProperty]
        public SelectList BankMasterList
        {
            get
            {
                List<BankMaster> BankMasterList = BankMaster.List<BankMaster>(new Npgsql.NpgsqlCommand("select BankCode,BankName from dbo.BankMaster"));
                return new SelectList(BankMasterList, "BankCode", "BankName");
            }
            set { }
        }

        //change19022018
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (Convert.ToDateTime(Dateoffirstpayment) > Convert.ToDateTime(Dateoflastpayment))
            {
                yield return new ValidationResult("Date of fist subscription can not be greater than date of last subscription", new string[] { "Dateoffirstpayment" });
            }
        }


        [CustomProperty]
        public SelectList MaritalStatusMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.MaritalStatus);
                List<ServiceTypeMaster> MaritalStatusMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(MaritalStatusMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList NatureofDeath
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CauseOfDeath);
                List<ServiceTypeMaster> MaritalStatusMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(MaritalStatusMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MemberRelationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select relationid as Valueid,relationname as Valuename from relationmaster  order by 1");
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        public SelectList LocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@Dept and dm.stateid=@stateid and LM.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@Dept", (int)Department.Dept016);
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
    }
}