﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Data;
using Npgsql;

namespace Edistrict.Models.Entities
{
    public class MarriageWitnessMaster : Repositry<MarriageWitnessMaster>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string WitnessId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string WitnessName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Father Name")]
        public virtual string WitnessFatherName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WitnessAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[a-zA-Z0-9]+$", ErrorMessage = "Enter Valid Value")]
        public virtual string WitnessIdentificationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual byte[] WitnessIdentificationData { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WitnessIdentityTypeId { get; set; }
        public virtual string RowNumber { get; set; }
        [Required(ErrorMessage = "House No Required")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string witnesshousenumber { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string witnessstreetnumber { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string witnesssublocality { get; set; }
        public virtual string witnessstateid { get; set; }
        public virtual string witnessstatename { get; set; }
        public virtual string witnesscountryid { get; set; }
        public virtual string witnessCountryName { get; set; }
        [Required(ErrorMessage = "SubDivision Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid SubDivision")]
        public virtual string witnesssubdivcode { get; set; }
        public virtual string witnessSubDivDescription { get; set; }
        [Required(ErrorMessage = "District Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid District")]
        public virtual string witnessdistrictcode { get; set; }
        public virtual string witnessDistrictName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string witnesslocalityid { get; set; }
        [CustomProperty]
        public virtual string witnessLocalityName { get; set; }
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "PinCode required")]
        [RegularExpression(@"^[0-9]{6}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string witnesspincode { get; set; }
        public virtual string witnesstypeid { get; set; }
        public virtual string RelatedId { get; set; }

        [CustomProperty]
        public DataTable dt { get; set; }

        [CustomProperty]
        public virtual string WitnessIdentityType { get; set; }
        [CustomProperty]
        public SelectList WitnessIdentityTypeMasterList
        {
            get
            {
                List<WitnessIdentityTypeMaster> WitnessIdentityTypeMasterList = WitnessIdentityTypeMaster.List<WitnessIdentityTypeMaster>(new Npgsql.NpgsqlCommand("select witnessidentitytypeid,witnessidentitytype from dbo.witnessidentitytypemaster"));
                return new SelectList(WitnessIdentityTypeMasterList, "witnessidentitytypeid", "witnessidentitytype");
            }
            set { }
        }
        [CustomProperty]
        public SelectList LocalityList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.whetheractive=@whetheractive order by lm.LocalityName");
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
    }
}