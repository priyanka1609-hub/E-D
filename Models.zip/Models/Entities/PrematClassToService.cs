﻿using System;
using System.Web;
using Edistrict.Models.DataService;
//SCST Changes Main
namespace Edistrict.Models.Entities
{
    public class PrematClassToService : Repositry<PrematClassToService>
    {
        public virtual string ClassId { get; set; }
        public virtual string ClassName { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual bool WhetherActive { get; set; }
    }
}