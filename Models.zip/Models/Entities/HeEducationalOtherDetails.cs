﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class HeEducationalOtherDetails : Repositry<HeEducationalOtherDetails>
    {
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationId { get; set; }

        public virtual string ExaminationId { get; set; }
        public virtual string ExaminationType { get; set; }
        [RequiredIf("ExaminationId", "7", ErrorMessage = "Value Required")]
        public virtual string InstitutionDetails { get; set; }
        [RequiredIf("ExaminationId", "7", ErrorMessage = "Value Required")]
        public virtual string BoardDetails { get; set; }
        [RequiredIf("ExaminationId", "7", ErrorMessage = "Value Required")]
        public virtual string PassingYear { get; set; }
        [RequiredIf("ExaminationId", "7", ErrorMessage = "Value Required")]
        public virtual string MarkPercentage { get; set; }

        //public virtual string InstitutionId { get; set; }
        //public virtual string InstitutionType { get; set; }
        //public virtual string BoardId { get; set; }
        //public virtual string BoardType { get; set; }


    }
}