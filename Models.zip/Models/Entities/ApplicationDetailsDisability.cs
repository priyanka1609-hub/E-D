﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsDisability : Repositry<ApplicationDetailsDisability>
    {
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DisabilityTypeId { get; set; }
        public virtual string DisabilityTypeName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string DisabilityPercentageId { get; set; }
        public virtual string DPercentageName { get; set; }

        [Required(ErrorMessage = "Occupation Name Required")]
        public virtual string OccupationId { get; set; }
        public virtual string OccupationType { get; set; }

        [Required(ErrorMessage = "Birth Place Required")]
        [StringLength(100, MinimumLength = 2)]
        [RegularExpression(@"^(?=\S)([a-zA-Z\s]+){3,}$", ErrorMessage = "Enter valid Place")]
        public virtual string BirthPlace { get; set; }
        [Required(ErrorMessage = "Blood Group Required")]
        [StringLength(3, MinimumLength = 1, ErrorMessage = "Enter valid value")]
        public virtual string Bloodgroup { get; set; }
        [Required(ErrorMessage = "Qualification Required")]
        [StringLength(100, MinimumLength = 2)]
        [RegularExpression(@"^(?=\S)([a-zA-Z\s]+){3,}$", ErrorMessage = "Enter valid value")]
        public virtual string Qualification { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\-[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter Valid Value")]
        [StringLength(25, MinimumLength = 2, ErrorMessage = "Enter valid value")]
        public virtual string DisabilityCertificateNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(25, MinimumLength = 2, ErrorMessage = "Enter valid value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\-[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string MedicalCertificate { get; set; }
        public virtual string WhetherRegEmpExchange { get; set; }
        [RequiredIf("WhetherRegEmpExchange", "true", ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter valid value")]
        public virtual string RegistrationNo { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("WhetherRegEmpExchange", "true", ErrorMessage = "Value Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string RegistrationDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter valid value")]
        [RegularExpression(@"^(?=\S)([a-zA-Z\s]+){3,}$", ErrorMessage = "Enter valid value")]
        public virtual string IdentificationMarks { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter valid value")]
        [RegularExpression(@"^(?=\S)([a-zA-Z\s]+){3,}$", ErrorMessage = "Enter valid value")]
        public virtual string MedicalCertificateIssuedBy { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DateofIssue { get; set; }
        public virtual string ApplicationStatusId { get; set; }

        [CustomProperty]
        public SelectList OccupationMasterList
        {
            get
            {
                List<OccupationMaster> OccupationMasterList = OccupationMaster.List<OccupationMaster>(new Npgsql.NpgsqlCommand("select OccupationId,OccupationType from dbo.OccupationMaster"));
                return new SelectList(OccupationMasterList, "OccupationId", "OccupationType");
            }
            set { }
        }
        [CustomProperty]
        public SelectList DisabilityTypeMasterList
        {
            get
            {
                List<DisabilityTypeMaster> DisabilityTypeMasterList = DisabilityTypeMaster.List<DisabilityTypeMaster>(new Npgsql.NpgsqlCommand("select DisabilityTypeId,DisabilityTypeName from dbo.DisabilityTypeMaster"));
                return new SelectList(DisabilityTypeMasterList, "DisabilityTypeId", "DisabilityTypeName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList DPercentageMasterList
        {
            get
            {
                List<DisabilityPercentageMaster> DPercentageMasterList = DisabilityPercentageMaster.List<DisabilityPercentageMaster>(new Npgsql.NpgsqlCommand("select DPercentageId,DPercentageName from dbo.DisabilityPercentageMaster"));
                return new SelectList(DPercentageMasterList, "DPercentageId", "DPercentageName");
            }
            set { }
        }
    }
}