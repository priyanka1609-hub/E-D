﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.Entities
{
    public class HeInstitutionMaster : Repositry<HeInstitutionMaster>
    {
        [Required(ErrorMessage = "Value Required")]
        public virtual string InstituitonId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string InstituitonName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string InstitutionAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AffiliationCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FeeAmount { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string UniversityId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CourseEligibility { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string InstitutionEmail { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string InstitutionContact { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string NodalOfficer { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string AcademicSession { get; set; }
        public virtual string AcademicSessionType { get; set; }
        public virtual HeCourseMaster HeCourseMaster { get; set; }

    }
}