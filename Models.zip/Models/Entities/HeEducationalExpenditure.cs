﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class HeEducationalExpenditure : Repositry<HeEducationalExpenditure>
    {
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationId { get; set; }
        public virtual string RequirementFor { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PayableFees { get; set; }
        public virtual string ExaminationFees { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CostofBooks { get; set; }
        public virtual string CautiondePosits { get; set; }
        public virtual string InsurancePremium { get; set; }
        public virtual string AnyOtherExpense { get; set; }
    }
}