﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.Entities
{
    public class HeUniversityMaster : Repositry<HeUniversityMaster>
    {
        [Required(ErrorMessage = "Value Required")]
        public virtual string UniversityId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string UniversityName { get; set; }

        [Required(ErrorMessage = "Required")]
        public virtual string UniversityAddress { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string UniversityContactNo { get; set; }
        [Required(ErrorMessage = "Required")]
        [StringLength(50)]
        [DataType(DataType.EmailAddress, ErrorMessage = "Enter valid Email")]
        [RegularExpression(@"[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Enter valid Email")]
        public virtual string UniversityEmail { get; set; }
    }
}