﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class PaymentGatewayParameter : Repositry<PaymentGatewayParameter>
    {
        public virtual string ParameterId { get; set; }
        public virtual string DeptCode { get; set; }
        public virtual string MerchantId { get; set; }
        public virtual string OperatingMode { get; set; }
        public virtual string MerchantCountry { get; set; }
        public virtual string MerchantCurrency { get; set; }
        public virtual string AggregatorId { get; set; }
        public virtual string PaymentMode { get; set; }
        public virtual string AccesMedium { get; set; }
        public virtual string TransactionSource { get; set; }
        public virtual string EncodedKey { get; set; }
        public virtual int KeySize { get; set; }
        public virtual string SuccessUrl { get; set; }
        public virtual string FailureUrl { get; set; }
        public virtual string VerifyUrl { get; set; }
        public virtual string QueryUrl { get; set; }
        public virtual string PushPostUrl { get; set; }
        public virtual string VerifyPostUrl { get; set; }
        public virtual string UserId { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string ActionDateTime { get; set; }
    }
}