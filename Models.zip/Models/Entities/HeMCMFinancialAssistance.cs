﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;
using System.Data;
using System;

namespace Edistrict.Models.Entities
{
    public class HeMCMFinancialAssistance : Repositry<HeMCMFinancialAssistance>
    {
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationId { get; set; }
        public virtual string ServiceCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AcademicSession { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AcademicSessionType { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string NameAsPerSchool { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplyingFor { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CategoryId { get; set; }
        public virtual string Category { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CertificateIssueState { get; set; }
        public virtual string CerIssueState { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("[0-9]+", ErrorMessage = " InValid Input")]
        [StringLength(14, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        public virtual string CastecerNo { get; set; }
        public virtual string WhetherCasteVerified { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[1-9][0-9]*$", ErrorMessage = "Enter Valid annual income.")]
        [Range(0, 600000, ErrorMessage = "Family Annual Income exceeds maximum limit")]
        public virtual string AnnualIncome { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherNFSSscheme { get; set; }
        [RequiredIf("WhetherNFSSscheme", "True", ErrorMessage = "Details Required")]
        [RegularExpression(@"^[0-9]{12}$", ErrorMessage = "Enter Valid Card No.")]
        public virtual string NFSSCardNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FinancialAssistanceCategoryId { get; set; }
        public virtual string FinancialAssistanceCategory { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string UniversityId { get; set; }
        public virtual string UniversityName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string InstitutionId { get; set; }
        public virtual string InstitutionName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string InstitutionAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string InstitutionAffiliationId { get; set; }

        [Range(0, 500000, ErrorMessage = "Family Annual Income exceeds maximum limit")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string TutionFee { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LevelOfCourse { get; set; }
        public virtual string CourseType { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string CourseId { get; set; }
        public virtual string CourseName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string CurrentStudyingClass { get; set; }
        public virtual string PresentClass { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PreviousClassPassed { get; set; }
        public virtual string PreviousClass { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PreviousClassPassedYear { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("[0-9]+", ErrorMessage = " InValid Input")]
        [Range(55, 100, ErrorMessage = "Marks Not Allowed Less than 55% in Previous Year")]
        public virtual string Marks { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountHolderName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("[0-9]+", ErrorMessage = " InValid Input")]
        public virtual string AccountNo { get; set; }
        public virtual string BankName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankCode { get; set; }
        public virtual string BankBranchName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = "InValid Input")]
        public virtual string IFSCCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("[0-9]+", ErrorMessage = " InValid Input")]
        [StringLength(9, MinimumLength = 9, ErrorMessage = "Enter Valid MICR")]
        public virtual string MICRCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AadhaarNo { get; set; }
        [Required(ErrorMessage = "Please Select Declaration")]
        public virtual string DeclarationId { get; set; }
        public virtual string Declaration { get; set; }

        [Required(ErrorMessage = "Please Select Recommendation")]
        public virtual string WhetherSchoolRecomended { get; set; }
        public virtual string WhetherSchoolRecomend { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string InstituteRemarks { get; set; }
        [Required(ErrorMessage = "Please Check CheckBox")]
        public virtual bool checkDetails { get; set; }
        public virtual string InstId { get; set; }
        public virtual string FinancialAssistanceCategId { get; set; }

        public virtual string CouseCode { get; set; }
        public virtual string PresentClassId { get; set; }
        public virtual string PreviousClassId { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public List<ScStFeeDetails> ScStFeeDetails { get; set; }
        public DataTable dt { get; set; }
        public DataTable dt1 { get; set; }

        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList ApplyingForList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.FreshOrRenewal);
                List<SelectValueMaster> ApplyingForList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(ApplyingForList, "SelectValueId", "SelectValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList CategoryMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HigherEducationCategory);
                List<ServiceTypeMaster> CategoryMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(CategoryMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList StateMasterList
        {
            get
            {
                string Qry = "select StateId,StateName from dbo.StateMaster order by StateName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                List<StateMaster> StateMasterList = StateMaster.List<StateMaster>(Cmd);
                return new SelectList(StateMasterList, "StateId", "StateName");
            }
            set { }
        }


        [CustomProperty]
        public SelectList FinancialAssistanceCategoryMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename limit 0");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HEFinancialAssistanceCategory);
                List<ServiceTypeMaster> FinancialAssistanceCategoryMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(FinancialAssistanceCategoryMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList UniversityMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select UniversityId,UniversityName from heuniversitymaster where whetheractive=true and ServiceCode=@ServiceCode order by UniversityName");
                Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.HeFinancialAssistance);
                List<HeUniversityMaster> UniversityMasterList = HeUniversityMaster.List<HeUniversityMaster>(Cmd);
                return new SelectList(UniversityMasterList, "UniversityId", "UniversityName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList InstitutionMasterList
        {
            get
            {
                List<HeInstitutionMaster> InstitutionMasterList = HeInstitutionMaster.List<HeInstitutionMaster>(new Npgsql.NpgsqlCommand("select InstituitonId,InstituitonName from HeInstitutionMaster where whetheractive=true order by InstituitonName limit 0"));
                return new SelectList(InstitutionMasterList, "InstituitonId", "InstituitonName");
            }
            set { }
        }



        [CustomProperty]
        public SelectList CourseLevelMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HELevelofCourse);
                List<ServiceTypeMaster> CourseLevelMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(CourseLevelMasterList, "ValueId", "ValueName");
            }
            set { }
        }


        [CustomProperty]
        public SelectList CourseList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select HecourseId,CourseName from dbo.hecoursemaster where ServiceCode=@ServiceCode order by CourseName limit 0");
                Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.HeFinancialAssistance);
                List<CourseMaster> CourseList = CourseMaster.List<CourseMaster>(Cmd);
                return new SelectList(CourseList, "HeCourseId", "CourseName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList PresentClassMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid limit 0");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HECurrentStudyingClass);
                List<ServiceTypeMaster> PresentClassMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(PresentClassMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList PreviousClassMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename limit 0");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HEPreviousClassPassed);
                List<ServiceTypeMaster> PreviousClassMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(PreviousClassMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public virtual SelectList PreviousClassPassedyearList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int curryear = DateTime.Now.Year - 1;
                int passedyear = curryear - 2;

                for (int i = passedyear; i <= curryear; i++)
                {
                    list.Add(new SelectListItem() { Text = passedyear.ToString() + "-" + (passedyear + 1).ToString(), Value = passedyear.ToString() });
                    passedyear = passedyear + 1;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
    }
}