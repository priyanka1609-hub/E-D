﻿using System;
using System.Web;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;

namespace Edistrict.Models.Entities
{
    public class UserDigitalMaster : Repositry<UserDigitalMaster>
    {
        public virtual string UserId { get; set; }
        public virtual string UserName { get; set; }
        public virtual string SerialNo { get; set; }
        public virtual string CertificateChain { get; set; }
        public virtual string ValidFrom { get; set; }
        public virtual string ValidTo { get; set; }
        public virtual string WhetherActive { get; set; }
        public virtual string DeactivateDate { get; set; }
    }
}