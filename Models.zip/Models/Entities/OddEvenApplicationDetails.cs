﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class OddEvenApplicationDetails : Repositry<OddEvenApplicationDetails>
    {
        public virtual string Id { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string RType { get; set; }
        public virtual string RTypeName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Name { get; set; }
        public virtual string RegistrationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateofcommencement { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Typeofinstitution { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Natureofwork { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Noofemployees { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Employeeonpvt4wheeler { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Membersinterested { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Phone No.")]
        [StringLength(11, MinimumLength = 10, ErrorMessage = "Enter Valid Phone No.")]
        public virtual string Phoneno1 { get; set; }
        [RequiredIf("Phoneno1", null, ErrorMessage = "Enter Atleast One Phone No.")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Phone No.")]
        [StringLength(11, MinimumLength = 10, ErrorMessage = "Enter Valid Phone No.")]
        public virtual string Phoneno2 { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FhName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Address { get; set; }
        public virtual string Occupation { get; set; }
        public virtual string Officeaddress { get; set; }
        public virtual string Nameofemployer { get; set; }
        public virtual string Addressofemployer { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Eduqualification { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetheranyvehicle { get; set; }
        [RequiredIf("Whetheranyvehicle", "True", ErrorMessage = "Vehicle Type Required")]
        public virtual string Vehicletype { get; set; }
        [RequiredIf("Whetheranyvehicle", "True", ErrorMessage = "Vehicle Registration No. Required")]
        public virtual string VehicleregistrationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Noofpersonconvinced { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Noofhourstospare { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofrcomplex { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofpresorsec { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Noofmembers { get; set; }
        public virtual string McdwardNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Noofvehiclesownedbyra { get; set; }
        public virtual string Nameofmaintrafficpoints { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LocalityId { get; set; }
        public virtual string SubDivName { get; set; }

        [CustomProperty]
        public SelectList OddEvenApplicantList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid as valueid,SMVD.valuename as valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by SMVD.valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.OddEvenApplicantType);
                List<ServiceTypeMaster> OddEvenApplicantList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(OddEvenApplicantList, "valueid", "valuename");
            }
            set { }
        }
        public SelectList AllLocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
    }
}