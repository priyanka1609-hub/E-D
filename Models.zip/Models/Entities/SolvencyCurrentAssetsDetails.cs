﻿using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.Entities
{
    public class SolvencyCurrentAssetsDetails : Repositry<SolvencyCurrentAssetsDetails>
    {
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }

        public virtual string ValueId{ get; set; }
        public virtual string AccountNo{ get; set; }
        public virtual string BankCode{ get; set; }
        public virtual string BranchName{ get; set; }
        public virtual string FDAmount{ get; set; }
        public virtual string FDMaturityDate{ get; set; }
        public virtual string NoOfShares{ get; set; }
        public virtual string ShareValue{ get; set; }
        public virtual string ShareCertificateNo{ get; set; }
        public virtual string ShareCompanyName{ get; set; }
        public virtual string OtherAmount{ get; set; }
        public virtual string OtherDetails { get; set; }

        public virtual string Counter { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string LastActionDate { get; set; }
    }
}