﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsPension : Repositry<ApplicationDetailsContractor>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual string Whetherexist { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerRegNo { get; set; }
       

        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateofcompletion { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateoffirstsubspayment { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Firstnameofbank { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Detailsofdefault { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateoflastsubspayment { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Lastnameofbank { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string PensionerrelId { get; set; }
        public virtual string PensionerrelName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherrecbenefits { get; set; }
        [RequiredIf("Whetherrecbenefits", "True", ErrorMessage = "Value Required")]
        public virtual string Detailsofbenefits { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountHolderName { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountNo { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string MICRCode { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankCode { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string BranchAddress { get; set; }


        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        
        [CustomProperty]
        public SelectList RelationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select relationid as Valueid,relationname as Valuename from relationmaster  order by 1");
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
    }
}