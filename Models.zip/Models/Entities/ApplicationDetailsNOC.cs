﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsNOC : Repositry<ApplicationDetailsNOC>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameoftransferer { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Fnameoftransferer { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Addressoftransferer { get; set; }
        public virtual string Nameoftransferee { get; set; }
        public virtual string Fnameoftransferee { get; set; }
        public virtual string Addressoftransferee { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Docnature { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Propertydescription { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string VillageId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LocalityId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string KhasraNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string RectangleNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Transferertitle { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Amount")]
        public virtual string Transferamount { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Transfereepurpose { get; set; }
        public virtual string SubDivName { get; set; }
        public virtual string DistrictName { get; set; }
        public virtual string VillageName { get; set; }
        public virtual string LocalityName { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual string ACounter { get; set; }
        public virtual string ApplicantName { get; set; }
        public virtual string ApplicantFatherName { get; set; }
        public virtual string ApplicantAddress { get; set; }
        public DataTable dt { get; set; }
        public DataTable dt2 { get; set; }
        public DataTable dt3 { get; set; }
        public virtual string StatusId { get; set; }
        public virtual NOCApplicationAreaDetails NOCApplicationAreaDetails { get; set; }
        [CustomProperty]
        public SelectList NatureofNOCDocument
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.NatureofNOCDocument);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList AllLocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@ParamDeptCode and LS.WhetherActive=@WhetherActive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@ParamDeptCode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        public SelectList VillageList
        {
            get
            {
                string Qry = "select villageid,villagename from villagemaster where whetheractive=@whetheractive order by villagename";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue(@"whetheractive", CustomText.TRUE.ToString());
                List<VillageMaster> VillageList = VillageMaster.List<VillageMaster>(Cmd);
                return new SelectList(VillageList, "villageid", "villagename");
            }
            set { }
        }
        public SelectList VillageSDList
        {
            get
            {
                string Qry = "select villageid,villagename from villagemaster where whetheractive=@whetheractive and subdivcode in (@ParamSubDivCode) order by villagename";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue(@"whetheractive", CustomText.TRUE.ToString());
                List<VillageMaster> VillageSDList = VillageMaster.List<VillageMaster>(Cmd);
                return new SelectList(VillageSDList, "villageid", "villagename");
            }
            set { }
        }
    }
}