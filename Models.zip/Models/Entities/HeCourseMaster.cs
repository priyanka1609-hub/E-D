﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.Entities
{
    public class HeCourseMaster : Repositry<HeCourseMaster>
    {
        [Required(ErrorMessage = "Value Required")]
        public virtual string HeCourseId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CourseName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CoursePeriod { get; set; }
    }
}