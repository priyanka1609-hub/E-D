﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.CustomAttribute;
namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsGrantOfPassengerLift : Repositry<ApplicationDetailsGrantOfPassengerLift>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string Nameofowner { get; set; }
        [Required(ErrorMessage = "Value Required")]
        //[RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Address")]
        [RegularExpression(@"^[a-zA-Z0-9.-\/,)( -]+$", ErrorMessage = "Enter InValid Address")]
        public virtual string Addrofowner { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApprovalLetterNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ChallanNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ChallanDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        //[RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter Invalid Value")]
        [RegularExpression(@"^[a-zA-Z0-9.-\/,)( -]+$", ErrorMessage = "Enter Invalid Value")]
        public virtual string Premises { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "EnterD InValid Identification no ")]
        public virtual string LiftLocation { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AppLocalityId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LocalityName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameof { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApprovalLetterDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CompletionDate { get; set; }
        public virtual string FeeDeposit { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [Range(0.5, 5.0, ErrorMessage = "Speed must be between 0.5 and 5.0")]
        [RegularExpression(@"^(\d{0,9}|\d{1}\.\d{1,2})$", ErrorMessage = "Only Decimal allowed")]
        public virtual string MaxSpeed { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual bool WhetherExist { get; set; }
        public virtual string ServerType { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Check Box Checked Required")]
        public virtual bool check { get; set; }

        public SelectList LocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@Dept and dm.stateid=@stateid and LM.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@Dept", (int)Department.Dept007);
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
    }
}