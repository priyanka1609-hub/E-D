﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Data;
using Npgsql;

namespace Edistrict.Models.Entities
{
    public class WitnessDetailsLalDora : Repositry<WitnessDetailsLalDora>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string WitnessId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationId { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        [RequiredIf("WLandTypeId", (int)ValueId.LandTypePurchaseId, ErrorMessage = "Witness Name Required")]
        public virtual string WName { get; set; }
        [RequiredIf("WLandTypeId", (int)ValueId.LandTypePurchaseId, ErrorMessage = "Witness AADHAAR No Required")]
        [StringLength(12, MinimumLength = 12, ErrorMessage = "Enter Valid AADHAAR")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid AADHAAR")]
        public virtual string WaadharNo { get; set; }
        public virtual string RowNumber { get; set; }
        [RequiredIf("WLandTypeId", (int)ValueId.LandTypePurchaseId, ErrorMessage = "Witness House No Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string WHouseNo { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string WStreetNo { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string WSubLocality { get; set; }

        [RequiredIf("WLandTypeId", (int)ValueId.LandTypePurchaseId, ErrorMessage = "Witness Locality Required")]
        public virtual string WLocalityId { get; set; }
        [CustomProperty]
        public virtual string WLocalityName { get; set; }

        [RequiredIf("WLandTypeId", (int)ValueId.LandTypePurchaseId, ErrorMessage = "Witness Sub Division Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid SubDivision")]
        public virtual string WSubDivCode { get; set; }
        public virtual string WSubDivName { get; set; }

        [RequiredIf("WLandTypeId", (int)ValueId.LandTypePurchaseId, ErrorMessage = "Witness District Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid District")]
        public virtual string WDistrictCode { get; set; }
        public virtual string WDistrictName { get; set; }
        [RequiredIf("WLandTypeId", (int)ValueId.LandTypePurchaseId, ErrorMessage = "Witness State Required")]
        public virtual string WStateId { get; set; }
        public virtual string WStateName { get; set; }
        [RequiredIf("WLandTypeId", (int)ValueId.LandTypePurchaseId, ErrorMessage = "Witness Country Required")]
        public virtual string WCountryId { get; set; }
        public virtual string WCountryName { get; set; }
        public virtual string RelatedId { get; set; }
        [RequiredIf("WLandTypeId", (int)ValueId.LandTypePurchaseId, ErrorMessage = "Witness Pin Code Required")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[1-1][1-1][0-9]{4}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string WPinCode { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string WMobileNo { get; set; }

        public DataTable dt { get; set; }
        public List<WitnessDetailsLalDora> WitnessDetailsLalDora1 { get; set; }

        [CustomProperty]
        public virtual string WLandTypeId { get; set; }
        [CustomProperty]
        public SelectList LocalityList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.whetheractive=@whetheractive order by lm.LocalityName");
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
    }
}