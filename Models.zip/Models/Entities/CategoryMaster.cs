﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class CategoryMaster : Repositry<CategoryMaster>
    {
        public virtual string CategoryId { get; set; }
        public virtual string CategoryName { get; set; }
    }
}