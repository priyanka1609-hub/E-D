﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class HeFinanceDetails : Repositry<HeFinanceDetails>
    {
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationId { get; set; }
        public virtual string LoanPeriodFor { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LoanAmount { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string OwnSource { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Scholarship { get; set; }
    }
}