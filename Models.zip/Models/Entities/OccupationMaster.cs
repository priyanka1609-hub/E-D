﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class OccupationMaster : Repositry<OccupationMaster>
    {
        public virtual string OccupationId { get; set; }
        public virtual string OccupationType { get; set; }
        public virtual string WhetherActive { get; set; }
    }
}