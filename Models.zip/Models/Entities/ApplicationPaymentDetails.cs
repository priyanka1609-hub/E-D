﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationPaymentDetails : Repositry<ApplicationPaymentDetails>
    {
        public virtual string PaymentId { get; set; }
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "Year is Required")]
        public virtual string Paymentyear { get; set; }
        [Required(ErrorMessage = "Month is Required")]
        public virtual string Paymentmonth { get; set; }
        [Required(ErrorMessage = "Mode is Required")]
        public virtual string Paymentfrequency { get; set; }
        public virtual string Amountgiven { get; set; }
        public virtual string Bankcode { get; set; }
        public virtual string Bankbranch { get; set; }
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string Ifsccode { get; set; }
        public virtual string Micrcode { get; set; }
        public virtual string AccountNo { get; set; }
        public virtual string Whetherfilerequired { get; set; }
        public virtual string Whetherfilegenerated { get; set; }
        public virtual string FilegenerateDate { get; set; }
        public virtual string Filegenerateby { get; set; }
        public virtual string Filegenerateipaddress { get; set; }
        public virtual string Whetherresponserequired { get; set; }
        public virtual string Whetherresponseuploaded { get; set; }
        public virtual string ResponsestatusId { get; set; }
        public virtual string Responseremarks { get; set; }
        public virtual string ResponseuploadDate { get; set; }
        public virtual string Responseuploadby { get; set; }
        public virtual string Responseipaddress { get; set; }

        public virtual string Page { get; set; }
        public virtual string ApplicantName { get; set; }
        public virtual string DistrictCode { get; set; }
        public virtual string SubDivCode { get; set; }
        public virtual string ServiceCode { get; set; }
        [Required(ErrorMessage = "Select Year")]
        public virtual string Excludeyear { get; set; }
        [Required(ErrorMessage = "Select Month")]
        public virtual string Excludemonth { get; set; }

        public SelectList ServiceListForSanction
        {
            get
            {
                string Dept = Sessions.getEmployeeUser().DeptCode;
                string Qry = "select ServiceCode,ServiceName from ServiceMaster where WhetherSanctionAllowed=@WhetherSanctionAllowed ";
                if (!string.IsNullOrEmpty(Dept)) { Qry += " and DeptCode=@DeptCode"; }
                Qry += " order by ServiceName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                if (!string.IsNullOrEmpty(Dept))
                {
                    Cmd.Parameters.AddWithValue("@DeptCode", Dept);
                }
                Cmd.Parameters.AddWithValue("@WhetherSanctionAllowed", Edistrict.Models.ApplicationService.CustomText.TRUE.ToString());
                List<ServiceMaster> ServiceListForSanction = Edistrict.Models.Entities.ServiceMaster.List<ServiceMaster>(Cmd);
                return new SelectList(ServiceListForSanction, "ServiceCode", "ServiceName");
            }
            set { }
        }
        public SelectList SubDivListForSanction
        {
            get
            {
                string SubDiv = Sessions.getEmployeeUser().SubDivCode;
                if (!string.IsNullOrEmpty(SubDiv)) { SubDiv = " SubDivCode in (@ParamSubDivCode) "; } else { SubDiv = string.Empty; }
                string Qry = "select SubDivCode,SubDivDescription from SubDivMaster where WhetherActive=@WhetherActive and DistrictCode=@DistrictCode and " + SubDiv + " order by SubDivDescription";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@DistrictCode", Sessions.getEmployeeUser().DistrictCode);
                Cmd.Parameters.AddWithValue("@WhetherActive", Edistrict.Models.ApplicationService.CustomText.TRUE.ToString());
                List<SubDivMaster> SubDivListForSanction = SubDivMaster.List<SubDivMaster>(Cmd);
                return new SelectList(SubDivListForSanction, "SubDivCode", "SubDivDescription");
            }
            set { }
        }

        public virtual SelectList MonthList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                DateTime month = Convert.ToDateTime("01/01/2012");
                for (int i = 0; i < 12; i++)
                {
                    DateTime NextMonth = month.AddMonths(i);
                    list.Add(new SelectListItem() { Text = NextMonth.ToString("MMMM"), Value = (i + 1).ToString() });
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList YearList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int varYear = DateTime.Now.Year - 1;
                for (int i = varYear; i < DateTime.Now.AddYears(1).Year; i++)
                {
                    list.Add(new SelectListItem() { Text = varYear.ToString(), Value = varYear.ToString() });
                    varYear++;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList PaymentModeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.PaymentMode);
                List<SelectValueMaster> PaymentModeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(PaymentModeList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
    }
}