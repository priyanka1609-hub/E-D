﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{

    public class ApplicationDetailsDisabilityPension : Repositry<ApplicationDetailsContractor>, IValidatableObject //change15022018
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string Dob { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Check Box Checked Required")]
        public virtual bool check { get; set; }
        public virtual string Whetherexist { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerRegNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Workerdob { get; set; }
               
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateoffirstpayment { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateoflasttsubscription { get; set; }
      
        [Required(ErrorMessage = "Value Required")]
        public virtual string Firstnameofbank { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Lastnameofbank { get; set; }
         
        //change15022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)",ErrorMessage="Enter only numbers")]
        public virtual string Totalsubsamount { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Detailsofdisease { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Natureofdisability { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Detailsoftreatmentgovt { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateofadmission { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateofdischarge { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherplaster { get; set; }
        
        //change22022018
        [RequiredIf("Whetherplaster", "True", ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage="Enter only numbers")]
        public virtual string Noofdaysonplaster { get; set; }
        
        //change15022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string Amountspent { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherbenefitsreceived { get; set; }
        [RequiredIf("Whetherbenefitsreceived", "True", ErrorMessage = "Value Required")]
        public virtual string detailsofbenefits { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherrecgovtbenefit { get; set; }
        [RequiredIf("Whetherrecgovtbenefit", "True", ErrorMessage = "Value Required")]
        public virtual string Detailsgovtbenefits { get; set; }



        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string HospitalName { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string HospitalAddress { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string DisCertificateInstituteName { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string DateOfDisCerificate { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string DisPercentage { get; set; }


        
        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }


        //change22022018
        [CustomProperty]
        public SelectList NatureofDisabilityList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.DisabilityType);
                List<ServiceTypeMaster> DisabilityList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(DisabilityList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList NatureofDeath
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CauseOfDeath);
                List<ServiceTypeMaster> MaritalStatusMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(MaritalStatusMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        //change22022018
        [CustomProperty]
        public SelectList DPercentageMasterList
        {
            get
            {
                List<DisabilityPercentageMaster> DPercentageMasterList = DisabilityPercentageMaster.List<DisabilityPercentageMaster>(new Npgsql.NpgsqlCommand("select DPercentageId,DPercentageName,replace(DPercentageName,'%','')::integer as pvalue from disabilitypercentagemaster order by pvalue"));
                return new SelectList(DPercentageMasterList, "DPercentageId", "DPercentageName");
            }
            set { }
        }

        //change13022018
        [CustomProperty]
        public SelectList BankMasterList
        {
            get
            {
                List<BankMaster> BankMasterList = BankMaster.List<BankMaster>(new Npgsql.NpgsqlCommand("select BankCode,BankName from dbo.BankMaster"));
                return new SelectList(BankMasterList, "BankCode", "BankName");
            }
            set { }
        }

        //change15022018
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (Convert.ToDateTime(Dateoffirstpayment) > Convert.ToDateTime(Dateoflasttsubscription))
            {
                yield return new ValidationResult("Date of fist subscription can not be greater than date of last subscription", new string[] { "Dateoffirstpayment" });
            }

            if (Convert.ToDateTime(Dateofadmission) > Convert.ToDateTime(Dateofdischarge))
            {
                yield return new ValidationResult("Date of admission can not be greater than date of discharge", new string[] { "Dateofadmission" });
            }
        }
         
       
    }
}