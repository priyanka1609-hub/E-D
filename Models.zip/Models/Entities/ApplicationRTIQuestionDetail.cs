﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Collections.Generic;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class ApplicationRTIQuestionDetail : Repositry<ApplicationRTIQuestionDetail>
    {
        
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string UserId { get; set; }
        public virtual string UserName { get; set; }
        public virtual string RTIQuestionId { get; set; }
        public virtual string DeptCode { get; set; }
        [Required(ErrorMessage = "Question Required")]
        public virtual string RTIQuestion { get; set; }
        public virtual string WhetherAssigned { get; set; }
        public virtual string WhetherAnsSubmitted { get; set; }

        public virtual string FinalAnswer { get; set; }
        public virtual string WhetherDataSigned { get; set; }
        public virtual string SignedData { get; set; }
        public virtual string AssignedTo { get; set; }
        public DataTable data { get; set; }
        public DataTable dataS { get; set; }

        public ApplicationDetailsRTIAns ApplicationDetailsRTIAns { get; set; }

        //public SelectList RTIPIOtList
        //{
        //    get
        //    {

        //        NpgsqlCommand cmd = new NpgsqlCommand("select UserId,UserName from Usermaster where Permission=@Permission order by UserName");
        //        cmd.Parameters.AddWithValue("@Permission", Convert.ToString((int)Permission.DEPTM));
        //        List<ApplicationRTIQuestionDetail> PIOList = ApplicationRTIQuestionDetail.List<ApplicationRTIQuestionDetail>(cmd);
        //        return new SelectList(PIOList, "UserId", "UserName");
        //    }
        //    set { }
        //}

        [CustomProperty]
        public SelectList RTIDeptList
        {
            get
            {
                List<DeptMaster> DeptList = DeptMaster.List<DeptMaster>(new Npgsql.NpgsqlCommand("select DeptCode,DeptName from DeptMaster where WhetherRTIDept=True order by DeptName"));
                return new SelectList(DeptList, "DeptCode", "DeptName");
            }
            set { }
        }
    }
}