﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class CountryMaster  : Repositry<CountryMaster>
    {
        public virtual string CountryId { get; set; }
        public virtual string CountryName { get; set; }
    }
    
}