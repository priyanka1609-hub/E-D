﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsCEA1 : Repositry<ApplicationDetailsCEA1>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofins { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Detailsofins { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Localityofins { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofowner { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Addrofowner { get; set; }
        public virtual string Mobilenoofowner { get; set; }
        public virtual string Emailofowner { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofconcerned { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Addrofconcerned { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Mobilenoofconcerned { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Emailofconcerned { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherPertainEI { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string VoltageLevel { get; set; }
        public virtual string VoltageName { get; set; }
        public virtual string Faultlevelofins { get; set; }
        public virtual string Interruptingcap { get; set; }
        public virtual string Mingrndclearance { get; set; }
        public virtual string LocalityName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherrpcomplied { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whethercompleted { get; set; }
        public virtual string Counter1 { get; set; }
        public virtual string Counter2 { get; set; }
        public virtual string Counter3 { get; set; }
        public virtual string Counter4 { get; set; }
        public virtual string Counter5 { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Addofins { get; set; }

        public virtual DataTable data { get; set; }
        public virtual DataTable data1 { get; set; }
        public virtual DataTable data2 { get; set; }
        public virtual DataTable data3 { get; set; }
        public virtual DataTable data4 { get; set; }

        public SelectList LocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@Dept and dm.stateid=@stateid and LM.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@Dept", (int)Department.Dept007);
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList YesList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList YesNoNAList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                list.Add(new SelectListItem() { Text = "N/A", Value = "NA" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList ApparatusTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId and s1.valueid not in (@generator) order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.ApparatusTypeList);
                Cmd.Parameters.AddWithValue("@Generator", (int)ValueId.Generator);
                List<SelectValueMaster> NatureOfEstList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(NatureOfEstList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList VoltageLevelList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.VoltageLevel);
                List<SelectValueMaster> VoltageLevel = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(VoltageLevel, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList TransformerTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.TransformerType);
                List<SelectValueMaster> TransformerType = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(TransformerType, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        //
    }
}