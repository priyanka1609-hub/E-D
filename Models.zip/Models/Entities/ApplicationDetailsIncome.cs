﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Collections.Generic;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsIncome : Repositry<ApplicationDetailsIncome>
    {
        [Required(ErrorMessage = "Annual Income is  Required")]
        public virtual string PforCertificateId { get; set; }
        public virtual string PforCertificateName { get; set; }
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Year")]
        [Range(0, 99, ErrorMessage = "Enter Valid Year")]
        public virtual string yearofstay { get; set; }
        [StringLength(2, MinimumLength = 1), Required(ErrorMessage = "Month Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Month")]
        [Range(0, 11, ErrorMessage = "Enter Valid Month")]
        public virtual string monthofstay { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter valid place of residence")]
        public virtual string placeofresidence { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Owner Name")]
        [RequiredIf("placeofresidence", "Rent", ErrorMessage = "Name Required")]
        public virtual string propertyownername { get; set; }
        [RequiredIf("placeofresidence", "Rent", ErrorMessage = "Mobile No Required")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]   
        public virtual string propertyownermobile { get; set; }
        [StringLength(100, MinimumLength = 8)]
        [DataType(DataType.EmailAddress, ErrorMessage = "Enter valid Email")]
        [RegularExpression(@"[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Enter valid Email")]
        public virtual string propertyowneremail { get; set; }
        [Range(100, 8000, ErrorMessage = "Enter Valid Amount")]
        [RegularExpression(@"([0-9]+)", ErrorMessage = "Enter Valid value")]
        [StringLength(5, MinimumLength = 3, ErrorMessage = "Enter Valid Value")]
        [RequiredIf("placeofresidence", "Rent", ErrorMessage = "Rent Amount Required")]
        public virtual string rentamount { get; set; }
        [StringLength(30, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z0-9])+(?:(([A-Za-z0-9\s]))|(\.[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter valid StampNo")]
        public virtual string StampNo { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string StampPeriodFrom { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string StampPeriodTo { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string whetherbplrationcardholder { get; set; }
        [StringLength(11, MinimumLength = 11, ErrorMessage = "Enter Valid Value")]
        [RequiredIf("whetherbplrationcardholder", "True", ErrorMessage = "Ration Card No Required")]
        public virtual string rationcardno { get; set; }
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("whetherbplrationcardholder", "True", ErrorMessage = "Issue date Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string rationcardissuedate { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string whetherincomtaxpayable { get; set; }
        [RequiredIf("whetherincomtaxpayable", "True", ErrorMessage = "PAN No Required")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Z]{5})+([0-9]{4})+([A-Z]{1})?", ErrorMessage = "Enter Valid value")]
        public virtual string panno { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string salariedemployee { get; set; }
        [RequiredIf("salariedemployee", "True", ErrorMessage = "Occupation Required")]
        public virtual string OccupationId { get; set; }
        public virtual string OccupationType { get; set; }
        [Required(ErrorMessage = "Annual Income is  Required")]
        [Range(500, 2000000, ErrorMessage = "Enter Valid Amount")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Annual Income")]
        public virtual string annualincome { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string WhetherIncomeCer { get; set; }
        [StringLength(14, MinimumLength = 14, ErrorMessage = "Invalid Certificate No.")]
        [RequiredIf("WhetherIncomeCer", "True", ErrorMessage = "Income Certificate No Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "PLease enter valid Certificate  Number")]
        public virtual string IncomeCerNo { get; set; }
        [Range(500, 2000000, ErrorMessage = "Enter Valid Amount")]
        [RequiredIf("WhetherIncomeCer", "True", ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string CerAnnualIncome { get; set; }
        [RequiredIf("WhetherIncomeCer", "True", ErrorMessage = "Value Required")]
        public virtual string CerIssueAuthority { get; set; }
        [Range(500, 2000000, ErrorMessage = "Enter Valid Amount")]
        [RequiredIf("whetherincomtaxpayable", "True", ErrorMessage = "Value Required")]
        public virtual string TaxAnnualIncome { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string WhetherElecConn { get; set; }
        [RequiredIf("WhetherElecConn", "True", ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string ElecBillAmount { get; set; }
        [Required(ErrorMessage = "value Required")]
        [Range(0, 15000, ErrorMessage = "Enter Valid Amount")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string SchlFeePaid { get; set; }
        public virtual string FamilyIncomeId { get; set; }
        public virtual string SMCounter { get; set; }
        public virtual string StatusId { get; set; }
        public DataTable dt { get; set; }
        public virtual IncomeDetailsFamilyMember IncomeDetailsFamilyMember { get; set; }
        [CustomProperty]
        public SelectList RelationMasterList
        {
            get
            {
                List<RelationMaster> RelationMasterList = RelationMaster.List<RelationMaster>(new Npgsql.NpgsqlCommand("select relationid,relationname from dbo.RelationMaster"));
                return new SelectList(RelationMasterList, "RelationId", "RelationName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList PCertificateList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMVTD.whetheractive=TRUE and SMV.mastervalueid=@mastervalueid");
                //Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.Income);
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.PurposeToObtainIncomeCertificate);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }

    }
}