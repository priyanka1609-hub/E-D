﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;

namespace Edistrict.Models.Entities
{
    public class ApplicationPaymentRequest : Repositry<ApplicationPaymentRequest>
    {
        public virtual string PaymentId { get; set; }
        public virtual string PaymentModeId { get; set; }
        public virtual string ApplicationId { get; set; }
        public virtual string ApplicationNo { get; set; }
        public virtual string PaymentElaborateId { get; set; }
        public virtual string PaymentorderNo { get; set; }
        public virtual string PaymentCustomerId { get; set; }
        public virtual string PaymentGenerateDate { get; set; }
        public virtual string PaymentStatusId { get; set; }
        public virtual string PaymentDate { get; set; }
        public virtual string OtherDetails { get; set; }
        public virtual string PaymentTypeValueId { get; set; }
        public virtual string ActionUserId { get; set; }
        public virtual string ActionIpAddress { get; set; }

        public virtual string ServiceCode { get; set; }
        public virtual string PaymentAmount { get; set; }
    }
}