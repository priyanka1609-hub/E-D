﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsLadli : Repositry<ApplicationDetailsLadli>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationStatusId { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Addressofbirth { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [DataType(DataType.Date),Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DobcertificateNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dobdept { get; set; }
        public virtual string Dobdeptname { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MlaconstituencyId { get; set; }
        public virtual string ConstituencyName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CategoryId { get; set; }
        public virtual string Category { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Noofdaughters { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetheralreadyapplied { get; set; }
        [RegularExpression("([0-1]+)", ErrorMessage = "you can apply only for maximum surviving 2 daughters")]
        [RequiredIf("Whetheralreadyapplied", "True", ErrorMessage = "Value Required")]
        public virtual string Daughtercount { get; set; }
        [RequiredIf("Whetheralreadyapplied", "True", ErrorMessage = "Value Required")]
        public virtual string GroupmemberId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string UidRelationId { get; set; }
        public virtual string UidRelationName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whethersimilarscheme { get; set; }
        [RequiredIf("Whethersimilarscheme", "True", ErrorMessage = "Value Required")]
        public virtual string SchemeName { get; set; }
        [RequiredIf("Whethersimilarscheme", "True", ErrorMessage = "Value Required")]
        public virtual string SchemeapplicationNo { get; set; }
        [RequiredIf("Whethersimilarscheme", "True", ErrorMessage = "Value Required")]
        public virtual string SchemestateId { get; set; }
        public virtual string StateName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BirthplaceId { get; set; }
        public virtual string BirthplaceName { get; set; }
        [Range(0, 100000, ErrorMessage = "Family Annual Income exceeds maximum limit")]
        public virtual string AnnualIncome { get; set; }
        public virtual int TableWidth { get; set; }
        [CustomProperty]
        public SelectList CategoryList
        {
            get
            {
                List<CategoryMaster> CategoryList = CategoryMaster.List<CategoryMaster>(new Npgsql.NpgsqlCommand("select CategoryId,CategoryName from dbo.CategoryMaster order by CategoryName"));
                return new SelectList(CategoryList, "CategoryId", "CategoryName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList ConstituencyList
        {
            get
            {
                List<AssemblyConstituencyMaster> ConstituencyList = AssemblyConstituencyMaster.List<AssemblyConstituencyMaster>(new Npgsql.NpgsqlCommand("select ConstituencyID,ConstituencyName from dbo.AssemblyConstituencyMaster order by ConstituencyName"));
                return new SelectList(ConstituencyList, "ConstituencyID", "ConstituencyName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList StateMasterList
        {
            get
            {
                List<StateMaster> StateMasterList = StateMaster.List<StateMaster>(new Npgsql.NpgsqlCommand("select StateId,StateName from dbo.StateMaster order by StateName"));
                return new SelectList(StateMasterList, "StateId", "StateName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList BirthPlaceList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.BirthPlaceType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList BirthCertificateList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.BirthCertificateType);
                List<ServiceTypeMaster> BirthCertificateList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(BirthCertificateList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList UidRelationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.UidRelationType);
                List<ServiceTypeMaster> UidRelationList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(UidRelationList, "ValueId", "ValueName");
            }
            set { }
        }
    }
}