﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class DocumentMaster : Repositry<DocumentMaster>
    {
        public virtual string DocumentID { get; set; }
        public virtual string DocumentName { get; set; }
        public virtual string WhetherActive { get; set; }
    }
}