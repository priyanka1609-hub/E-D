﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class FirmPartnerDetails : Repositry<FirmPartnerDetails>
    {
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string PartnerId { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string PartnerName { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string PartnerFatherName { get; set; }
        public virtual string PartnerAddress { get; set; }
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid")]
        [Range(1, 10, ErrorMessage = "Enter Valid")]
        [StringLength(2, MinimumLength = 1)]
        public virtual string PartnerAge { get; set; }
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter valid Value")]
        public virtual string FirmJoiningDate { get; set; }

        public virtual string IdentityDocumentId { get; set; }
        public virtual string IdentityDocumentNo { get; set; }
        public virtual string IdentityDocumentData { get; set; }

        public virtual string ResidentDocumentId { get; set; }
        public virtual string ResidentDocumentNo { get; set; }
        public virtual string ResidentDocumentData { get; set; }


        

    }
}