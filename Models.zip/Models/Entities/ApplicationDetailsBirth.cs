﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsBirth : Repositry<ApplicationDetailsBirth>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid child Name")]
        public virtual string ChildName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Father Name")]
        public virtual string FatherName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Mother Name")]
        public virtual string MotherName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DOB { get; set; }
        [StringLength(250), Required(ErrorMessage = "Address Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter valid place")]
        public virtual string PlaceOfBirth { get; set; }
        public virtual string CompleteAddress { get; set; }
        public virtual string PermanentAddress { get; set; }
        [Required(ErrorMessage = "House No Required")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string birthplacehouseno { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string birthplacestreetno { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string birthplacesublocality { get; set; }
        public virtual string stateid { get; set; }
        public virtual string statename { get; set; }
        public virtual string CountryId { get; set; }
        public virtual string CountryName { get; set; }
        [Required(ErrorMessage = "SubDivision Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid SubDivision")]
        public virtual string SubDivCode { get; set; }
        public virtual string ApplicantSubDivDescription { get; set; }
        [Required(ErrorMessage = "District Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid District")]
        public virtual string DistrictCode { get; set; }
        public virtual string ApplicantDistrictName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ReasonsOfNonRegistration { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Gender { get; set; }
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "PinCode required")]
        [RegularExpression(@"^[1-1][1-1][0-9]{4}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string pincode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LocalityId { get; set; }
        [CustomProperty]
        public virtual string LocalityName { get; set; }
        [Required(ErrorMessage = "House No Required")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string phouseno { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string pstreetno { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string psublocality { get; set; }
        public virtual string pstateid { get; set; }
        public virtual string PStateName { get; set; }
        public virtual string pcountryid { get; set; }
        public virtual string PCountryName { get; set; }
        [Required(ErrorMessage = "SubDivision Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid SubDivision")]
        public virtual string psubdivcode { get; set; }
        public virtual string PSubDivDescription { get; set; }
        [Required(ErrorMessage = "District Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid District")]
        public virtual string pdistrictcode { get; set; }
        public virtual string PDistrictName { get; set; }
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "PinCode required")]
        [RegularExpression(@"^[0-9]{6}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string ppincode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string plocalityid { get; set; }
        [CustomProperty]
        public virtual string PLocalityName { get; set; }
        [Required(ErrorMessage = "Selection Required")]
        public virtual string whetheradoptedchild { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("whetheradoptedchild", "true", ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string adoptername { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("whetheradoptedchild", "true", ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string adopterfathername { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("whetheradoptedchild", "true", ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string adoptermothername { get; set; }
        public virtual string adopterspousename { get; set; }
        [RequiredIf("whetheradoptedchild", "true", ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string adopterhouseno { get; set; }
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string adopterstreetno { get; set; }
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string adpotersublocality { get; set; }
        [RequiredIf("whetheradoptedchild", "true", ErrorMessage = "Value Required")]
        public virtual string adopterlocalityid { get; set; }
        public virtual string adoptersubdivcode { get; set; }
        public virtual string ASubDivDescription { get; set; }
        public virtual string adopterdistrictcode { get; set; }
        public virtual string ADistrictName { get; set; }
        public virtual string adopterstateid { get; set; }
        public virtual string Astatename { get; set; }
        public virtual string adoptercountryid { get; set; }
        public virtual string Acountryname { get; set; }
        [RequiredIf("whetheradoptedchild", "true", ErrorMessage = "Value Required")]
        public virtual string adopterpincode { get; set; }
        [RequiredIf("whetheradoptedchild", "true", ErrorMessage = "Value Required")]
        public virtual string orphanagename { get; set; }
        [RequiredIf("whetheradoptedchild", "true", ErrorMessage = "Value Required")]
        public virtual string orphanageaddress { get; set; }
        [RequiredIf("whetheradoptedchild", "true", ErrorMessage = "Value Required")]
        public virtual string orphanageregistrationno { get; set; }
        public virtual string adopteraddress { get; set; }

        [RequiredIf("whetheradoptedchild", "true", ErrorMessage = "Value Required")]
        public virtual string CaseNo { get; set; }
        [RequiredIf("whetheradoptedchild", "true", ErrorMessage = "Value Required")]
        public virtual string NameOfJudge { get; set; }
        [RequiredIf("whetheradoptedchild", "true", ErrorMessage = "Value Required")]
        public virtual string CourtDetails { get; set; }
        public virtual string ApplicationStatusId { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherOtherState { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BirthplaceId { get; set; }
        public virtual string BirthTypeName { get; set; }


        [CustomProperty]
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList LocalityList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.whetheractive=@whetheractive order by lm.LocalityName");
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList LocalityListSubdivWise
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.whetheractive=@whetheractive";
                if (Sessions.getEmployeeUser() != null) { Qry += " and sd.subdivcode in (@ParamSubDivCode)"; }
                Qry += " order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        public SelectList PLocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.whetheractive=@whetheractive order by lm.LocalityName limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> PLocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(PLocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList BirthPlaceList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.BirthPlaceType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
    }
}