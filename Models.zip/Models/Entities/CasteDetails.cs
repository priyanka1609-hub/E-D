﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
//SCST Changes Main
namespace Edistrict.Models.Entities
{
    public class CasteDetails : Repositry<CasteDetails>
    {
        public virtual string CasteId { get; set; }
        public virtual string CasteName { get; set; }
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string IssuedDate { get; set; }
        public virtual string WhetherCasteVerified { get; set; }
        public virtual bool WhetherCasteDetailsValidated { get; set; }
        public virtual bool WhetherCasteDetailsAvailable { get; set; }
    }
}