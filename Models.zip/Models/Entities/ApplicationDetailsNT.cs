﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsNT : Repositry<ApplicationDetailsNT>
    {
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationId { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string PurposeofCertificate { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        //public virtual string CasteValueId { get; set; }
        //public virtual string CasteValue { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplyingForState { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string CasteorTribeName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string ReligionName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ReligionId { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherMigrated { get; set; }

        [RequiredIf("WhetherMigrated", "True", ErrorMessage = "Migration State Required")]
        public virtual string MigrationState { get; set; }

        [RequiredIf("WhetherMigrated", "True", ErrorMessage = "Migration District Required")]
        public virtual string MigrationDistrict { get; set; }

        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid Village Name")]
        [RequiredIf("WhetherMigrated", "True", ErrorMessage = "Migration Village Required")]
        public virtual string MigrationVillage { get; set; }

        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("WhetherMigrated", "True", ErrorMessage = "Migration Date Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string MigrationDate { get; set; }

        [RequiredIf("WhetherMigrated", "False", ErrorMessage = "Year Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Year")]
        [Range(0, 99, ErrorMessage = "Enter Valid Year")]
        public virtual string YearofLiving { get; set; }
        [RequiredIf("WhetherMigrated", "False", ErrorMessage = "Month Required")]
        [StringLength(2, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Month")]
        [Range(0, 11, ErrorMessage = "Enter Valid Month")]
        public virtual string MonthofLiving { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherRelationNT { get; set; }

        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z0-9])+(?:(([A-Za-z0-9\s]))|(\.[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter valid Certificate No")]
        [RequiredIf("WhetherRelationST", "True", ErrorMessage = "Certificate No Required")]
        public virtual string CertificateNo { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        [RequiredIf("WhetherRelationST", "True", ErrorMessage = "Name Required")]
        public virtual string Rname { get; set; }
        [RequiredIf("WhetherRelationST", "True", ErrorMessage = "Relation Required")]
        public virtual string RWithApplicant { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("WhetherRelationST", "True", ErrorMessage = "Issue Date Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string RIssueDate { get; set; }
        [RequiredIf("WhetherRelationST", "True", ErrorMessage = "Address Required")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s\(\)]+)|(\,[A-Za-z0-9\s\(\)]+)|(\/[A-Za-z0-9\s\(\)]+)|(\([A-Za-z0-9\s]+)|(\)[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string RIssueAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CasteId { get; set; }
        public virtual string CasteName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string StateId { get; set; }
        public virtual string StateName { get; set; }

        [RequiredIf("WhetherRelationST", "True", ErrorMessage = "Relation Required")]
        public virtual string RwithApplicantId { get; set; }
        public virtual string RelationName { get; set; }

        [RequiredIf("WhetherRelationST", "True", ErrorMessage = "Address Required")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s\(\)]+)|(\,[A-Za-z0-9\s\(\)]+)|(\/[A-Za-z0-9\s\(\)]+)|(\([A-Za-z0-9\s]+)|(\)[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string RAddress { get; set; }
        [RequiredIf("WhetherRelationST", "True", ErrorMessage = "State Required")]
        public virtual string RStateId { get; set; }
        public virtual string RStateName { get; set; }
        [RequiredIf("WhetherRelationST", "True", ErrorMessage = "State Required")]
        public virtual string RDesignation { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string LastActionDate { get; set; }

        [CustomProperty]
        public SelectList StateList
        {
            get
            {
                List<StateMaster> StateList = StateMaster.List<StateMaster>(new Npgsql.NpgsqlCommand("select stateid,statename from dbo.statemaster order by statename"));
                return new SelectList(StateList, "stateid", "statename");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MigrationStateList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select stateid,statename from StateMaster where stateid <>@state order by StateName");
                cmd.Parameters.AddWithValue("@state", (int)State.Delhi);
                List<StateMaster> StateList = StateMaster.List<StateMaster>(cmd);
                return new SelectList(StateList, "stateid", "statename");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MigrationDistrictList
        {
            get
            {
                List<DistrictMaster> DistrictList = DistrictMaster.List<DistrictMaster>(new Npgsql.NpgsqlCommand("select DistrictCode,DistrictName from DistrictMaster order by DistrictName"));
                return new SelectList(DistrictList, "DistrictCode", "DistrictName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList CasteMasterList
        {
            get
            {
                List<CasteMaster> CasteMasterList = CasteMaster.List<CasteMaster>(new Npgsql.NpgsqlCommand("select casteid,castename from dbo.castemaster order by castename"));
                return new SelectList(CasteMasterList, "casteid", "castename");
            }
            set { }
        }
        [CustomProperty]
        public SelectList RelationMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as relationid,s1.valuename as relationname from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.PaternalRelationship);
                List<RelationMaster> RelationMasterList = RelationMaster.List<RelationMaster>(Cmd);
                return new SelectList(RelationMasterList, "relationid", "relationname");
            }
            set { }
        }
        [CustomProperty]
        public SelectList ReligionList
        {
            get
            {
                List<ReligionMaster> ReligionList = ReligionMaster.List<ReligionMaster>(new Npgsql.NpgsqlCommand("select ReligionId,ReligionName from dbo.ReligionMaster order by ReligionName"));
                return new SelectList(ReligionList, "ReligionId", "ReligionName");
            }
            set { }
        }
    }
}