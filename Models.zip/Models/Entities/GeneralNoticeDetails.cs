﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using System.Web.Mvc;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class GeneralNoticeDetails : Repositry<GeneralNoticeDetails>
    {
        public virtual string Id { get; set; }
        public virtual string CaseNo { get; set; }
        public virtual string Casetitle { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string NoticeName { get; set; }
        public virtual string SearchName { get; set; }
        public virtual string FName { get; set; }
        public virtual string Address { get; set; }
        public virtual string Dateofnotice { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string UsectionId { get; set; }
        public virtual string SearchSectionId { get; set; }
        public virtual string District { get; set; }
        public virtual string Subdivcode { get; set; }
        public virtual string Remarks { get; set; }

        [CustomProperty]
        public SelectList GeneralNoticeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.GeneralNoticeList);
                List<ServiceTypeMaster> GeneralNoticeList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(GeneralNoticeList, "ValueId", "ValueName");
            }
            set { }
        }
    }
}