﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using System.Web.Mvc;
using Edistrict.Models.ApplicationService;
using Npgsql;
using System.Data;
using Edistrict.Models.CustomAttribute;

namespace Edistrict.Models.Entities
{
    public class RecoveryNoticeDetails : Repositry<RecoveryNoticeDetails>
    {
        public virtual string NId { get; set; }
        public virtual string ApplicationNo { get; set; }
        public virtual string DId { get; set; }

        [RequiredIf("WhetherNoticeRequired", "Y", ErrorMessage = "Value Required")]
        public virtual string TypeId { get; set; }
        [RequiredIf("WhetherWarrantRequired", "Y", ErrorMessage = "Value Required")]
        public virtual string WTypeId { get; set; }

        [RequiredIf("WhetherNoticeRequired", "Y", ErrorMessage = "Value Required")]
        public virtual string RName { get; set; }
        [RequiredIf("WhetherWarrantRequired", "Y", ErrorMessage = "Value Required")]
        public virtual string WRName { get; set; }

        [RequiredIf("WhetherWarrantRequired", "Y", ErrorMessage = "Value Required")]
        public virtual string Servicecharge { get; set; }
        [RequiredIf("WhetherDisposedOff", "N", ErrorMessage = "Value Required")]
        public virtual string IssueDate { get; set; }

        [RequiredIf("WhetherNoticeRequired", "Y", ErrorMessage = "Value Required")]
        public virtual string ExpiryDate { get; set; }
        [RequiredIf("WhetherWarrantRequired", "Y", ErrorMessage = "Value Required")]
        public virtual string WExpiryDate { get; set; }

        [RequiredIf("WhetherWarrantRequired", "Y", ErrorMessage = "Value Required")]
        public virtual string PoliceStationId { get; set; }
        public virtual string Note { get; set; }

        [RequiredIf("WhetherNoticeRequired", "Y", ErrorMessage = "Value Required")]
        public virtual string Remarks { get; set; }
        [RequiredIf("WhetherWarrantRequired", "Y", ErrorMessage = "Value Required")]
        public virtual string WRemarks { get; set; }

        [RequiredIf("WhetherNoticeRequired", "Y", ErrorMessage = "Value Required")]
        public virtual string Servedby { get; set; }
        [RequiredIf("WTypeId", "237", ErrorMessage = "Value Required")]
        public virtual string Propertydetails { get; set; }
        public virtual Int32 NType { get; set; }

        public virtual string ProceedingHeading { get; set; }
        public virtual string WhetherProceedingDetails { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ProceedingDetails { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ProceedingDate { get; set; }
        [RequiredIf("WhetherDisposedOff", "N", ErrorMessage = "Value Required")]
        public virtual string WhetherNoticeRequired { get; set; }
        [RequiredIf("WhetherNoticeRequired", "N", ErrorMessage = "Value Required")]
        public virtual string WhetherWarrantRequired { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherDisposedOff { get; set; }
        public virtual string WhetherGenerated { get; set; }
        public DataTable dtDef { get; set; }
        [RequiredIf("WhetherDisposedOff", "Y", ErrorMessage = "Value Required")]
        public virtual string DisposalRemarks { get; set; }
        public virtual string WhetherAddFound { get; set; }

        public SelectList NoticeTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.RecoveryNoticeType);
                List<SelectValueMaster> NoticeTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(NoticeTypeList, "SelectValueId", "SelectValueName");
            }
            set { }
        }

        public SelectList NoticeServedByList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.RecoveryNoticeServer);
                List<SelectValueMaster> NoticeServedByList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(NoticeServedByList, "SelectValueId", "SelectValueName");
            }
            set { }
        }

        public SelectList WarrantTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.RecoveryWarrantType);
                List<SelectValueMaster> WarrantTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(WarrantTypeList, "SelectValueId", "SelectValueName");
            }
            set { }
        }

        public SelectList PoliceStationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select policestationid as SelectValueId,policestationname as SelectValueName from dbo.policestationmaster where servicecode=@servicecode and whetheractive=@whetheractive order by policestationname");
                Cmd.Parameters.AddWithValue("@servicecode", (int)ServiceList.Recovery);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.True.ToString());
                List<SelectValueMaster> PoliceStationList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(PoliceStationList, "SelectValueId", "SelectValueName");
            }
            set { }
        }

        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
    }
}