﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class ApplicationInspectionDetails : Repositry<ApplicationDetailsCinematograph>
    {

        [Required(ErrorMessage = "Application No. Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        [StringLength(14, MinimumLength = 14, ErrorMessage = "Enter Valid Application No.")]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string InspectionId { get; set; }
        [Required(ErrorMessage = "Please Enter Date")]
        public virtual string InspectionDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string OfficerName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string OfficerDesignation { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string OfficerContactNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PreInspectionRemarks { get; set; }
        public virtual string WhetherActive { get; set; }
        public virtual string WhetherInspected { get; set; }
        public virtual string WhetherDCInspected { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Observation { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ObservationADM { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ObservationDC { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string InspectedOn { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string TeamMembers { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string InspectionTypeId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BPlanDocumentNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BPlanIssueDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BPlanRemarksSDM { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BPlanRemarksADM { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BPlanRemarksDC { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DDMADocumentNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DDMAIssueDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DDMARemarksSDM { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DDMARemarksADM { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DDMARemarksDC { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MCDDocumentNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MCDIssueDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MCDRemarksSDM { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MCDRemarksADM { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MCDRemarksDC { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FDDocumentNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FDIssueDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FDRemarksSDM { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FDRemarksADM { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FDRemarksDC { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string EDDocumentNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string EDIssueDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string EDRemarksSDM { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string EDRemarksADM { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string EDRemarksDC { get; set; }
        //change809
        [Required(ErrorMessage = "Value Required")]
        public virtual string SitePlanDocumentNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SitePlanIssueDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SitePlanRemarksSDM { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SitePlanRemarksADM { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SitePlanRemarksDC { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string TClearanceDocumentNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string TClearanceIssueDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string TClearanceRemarksSDM { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string TClearanceRemarksADM { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string TClearanceRemarksDC { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CharCertDocumentNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CharCertIssueDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CharCertRemarksSDM { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CharCertRemarksADM { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CharCertRemarksDC { get; set; }

        public virtual string ODoc1DocumentNo { get; set; }
        public virtual string ODoc1IssueDate { get; set; }
        public virtual string ODoc1RemarksSDM { get; set; }
        public virtual string ODoc1RemarksADM { get; set; }
        public virtual string ODoc1RemarksDC { get; set; }
        public virtual string ODoc2DocumentNo { get; set; }
        public virtual string ODoc2IssueDate { get; set; }
        public virtual string ODoc2RemarksSDM { get; set; }
        public virtual string ODoc2RemarksADM { get; set; }
        public virtual string ODoc2RemarksDC { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string whetherbplanobjectiondc { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string whetherddmaobjectiondc { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string whethermcdobjectiondc { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string whetherfdobjectiondc { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string whetheredobjectiondc { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string whethersiteplanobjectiondc { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string whethertclearanceobjectiondc { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string whethercharcertobjectiondc { get; set; }
        public virtual string whetherodoc1objectiondc { get; set; }
        public virtual string whetherodoc2objectiondc { get; set; }
        public virtual string UserId { get; set; }
        public virtual string Ipaddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherProperOrder { get; set; }
        public virtual string cid { get; set; }
        public virtual string id { get; set; }
        public virtual string RowNumber { get; set; }
        public virtual string ScreenNo { get; set; }
        public virtual string TMCounter { get; set; }//change169

        public List<ApplicationInspectionDetails> InspectionDetails { get; set; }
        public DataTable data { get; set; }
        public DataTable datatm { get; set; }//change169

        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList InspectionTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.InspectionType);
                List<SelectValueMaster> InspectionTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(InspectionTypeList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList TMList//change169
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid as valueid,SMVD.valuename as valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by SMVD.valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.TeamMemberDept);
                List<ServiceTypeMaster> FNMList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(FNMList, "valueid", "valuename");
            }
            set { }
        }

    }
}