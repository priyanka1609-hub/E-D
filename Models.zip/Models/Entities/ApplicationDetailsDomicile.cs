﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Collections.Generic;
using Edistrict.Models.CustomAttribute;
using Npgsql;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsDomicile : Repositry<ApplicationDetails>
    {
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [StringLength(50), Required(ErrorMessage = "Birth Place Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter valid Birth place")]
        public virtual string PlaceOfBirth { get; set; }
        [StringLength(2, MinimumLength = 1), Required(ErrorMessage = "Year Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Year")]
        [Range(0, 99, ErrorMessage = "Enter Valid Year")]
        public virtual string YearOfLiving { get; set; }
        [StringLength(2, MinimumLength = 1), Required(ErrorMessage = "Month Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Month")]
        [Range(0, 11, ErrorMessage = "Enter Valid Month")]
        public virtual string MonthOfLiving { get; set; }
        [StringLength(5), Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Enter valid Value")]
        public virtual string OtherStateDomicile { get; set; }

        public virtual string WhetherDocumentProof { get; set; }
        public virtual string WhetherGazettedProof { get; set; }
        public virtual string WhetherFieldVerification { get; set; }
        [Required(ErrorMessage = "Select atleast one option")]
        public virtual string ResidenceProof { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("ResidenceProof", "2", ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Officer Name")]
        public virtual string GazettedOfficerName { get; set; }
        [RequiredIf("ResidenceProof", "2", ErrorMessage = "Value Required")]
        public virtual string OfficerGender { get; set; }
        [RequiredIf("ResidenceProof", "2", ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid Designation")]
        public virtual string Designation { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("ResidenceProof", "2", ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Department Name")]
        public virtual string DepartmentName { get; set; }
        [RequiredIf("ResidenceProof", "2", ErrorMessage = "Value Required")]
        [StringLength(11, MinimumLength = 11, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[0-9]{11}$", ErrorMessage = "Enter Valid Landline No.")]
        public virtual string OfficerTelephoneNo { get; set; }
        [RequiredIf("ResidenceProof", "2", ErrorMessage = "Value Required")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string OfficerMobileNo { get; set; }
        [RequiredIf("ResidenceProof", "2", ErrorMessage = "Value Required")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string OfficerAddress { get; set; }
        [RequiredIf("ResidenceProof", "2", ErrorMessage = "Value Required")]
        public virtual string OfficerStateId { get; set; }
        public virtual string OfficerStateName { get; set; }
        [RequiredIf("ResidenceProof", "2", ErrorMessage = "Value Required")]
        public virtual string OfficerDistrictCode { get; set; }
        public virtual string OfficerDistrictName { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string LastActionDate { get; set; }
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }

        public SelectList NoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "No", Value = "N" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList StateList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select StateId,StateName from StateMaster order by StateName");
                List<StateMaster> StateList = StateMaster.List<StateMaster>(cmd);
                return new SelectList(StateList, "StateId", "StateName");
            }
            set { }
        }
        public SelectList DistrictList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select DistrictCode,DistrictName from DistrictMaster where deptcode=@deptcode order by DistrictName");
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                List<DistrictMaster> DistrictList = DistrictMaster.List<DistrictMaster>(Cmd);
                return new SelectList(DistrictList, "DistrictCode", "DistrictName");
            }
            set { }
        }
    }
}