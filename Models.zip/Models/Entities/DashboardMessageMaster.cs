﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;

namespace Edistrict.Models.Entities
{
    public class DashboardMessageMaster : Repositry<DashboardMessageMaster>
    {
        public virtual string Id { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string DepartmentId { get; set; }
        public virtual string DepartmentName { get; set; }
        public virtual string PermissionId { get; set; }
        public virtual string PermissionName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string InformationTitle { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string InformationDescription { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [DataType(DataType.Date), Required(ErrorMessage = "value Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string AddDate { get; set; }
        public virtual string Displayorder { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string WhetherActive { get; set; }
        public virtual string RType { get; set; }

    }
}