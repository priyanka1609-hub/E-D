﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.CustomAttribute;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsConsWorker : Repositry<ApplicationDetailsConsWorker>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicationNo { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        public virtual string whetherscstobc { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string MaritalStatus { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string RegistrationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string presentworkpost { get; set; }
        public virtual string detailsofBoardMembership { get; set; }
        public virtual string localityworkplace { get; set; }
        public virtual string nid { get; set; }
        public virtual string fid { get; set; }
        public virtual string cid { get; set; }
        public virtual string MaritalName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MemberName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string fathername { get; set; }
        public virtual string mothername { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string husbandname { get; set; }
        public virtual string ESINo { get; set; }
        public virtual string PFNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string localaddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string permaddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string nameofhusband { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Addressofemployer { get; set; }
        [Required(ErrorMessage = "Month Required")]
        [StringLength(2, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Month")]
        [Range(0, 11, ErrorMessage = "Enter Valid Month")]
        public virtual string Serviceperiodmonth { get; set; }
        [StringLength(3, MinimumLength = 1, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Days Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Year")]
        [Range(0, 365, ErrorMessage = "Enter Valid Days")]
        public virtual string Serviceperioddays { get; set; }
        [StringLength(500, MinimumLength = 1, ErrorMessage = "Min 1 and Max 500 Characters are allowed")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string OtherEmployerDetails { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string dob { get; set; }
        [Required(ErrorMessage = "Value Required")]
        //[ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string dateofretirement { get; set; }
        public virtual string CCounter { get; set; }
        public virtual string Rateofsub { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherwelfaremember { get; set; }
        [RequiredIf("Whetherwelfaremember", "True", ErrorMessage = "Required")]
        public virtual string nameofboard { get; set; }
        [RequiredIf("Whetherwelfaremember", "True", ErrorMessage = "Required")]
        public virtual string regnoofboard { get; set; }
        [RequiredIf("Whetherwelfaremember", "True", ErrorMessage = "Required")]
        public virtual string Membershipperiod { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Workplaceid { get; set; }
        public virtual string NameofWorkplace { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AddressofWorkplace { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string NameofEmployeer { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        public virtual string AddressofEmployeer { get; set; }
        [RequiredIf("memberunion", "True", ErrorMessage = "Value Required")]
        public virtual string unionid { get; set; }
        public virtual string unionname { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string memberunion { get; set; }
        public virtual string WCounter1 { get; set; }
        public virtual string WCounter2 { get; set; }
        public virtual string WCounter3 { get; set; }
        public virtual string WCounter4 { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherRegisterWorker { get; set; }
        public virtual string WhetherUploadVolunteerData { get; set; }
        [RequiredIf("WhetherRegisterWorker", "True", ErrorMessage = "Required")]
        public virtual string OldRegistrationNo { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("WhetherRegisterWorker", "True", ErrorMessage = "Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string RegistrationDate { get; set; }
        [RequiredIf("WhetherRegisterWorker", "True", ErrorMessage = "Required")]
        public virtual string LastExpRegistration { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string RegAmount { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string RenewalFees { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LateFees { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Total { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DepositMode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DepositDetails { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string gendername { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountHolderName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountNo { get; set; }
        public virtual string BankName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankCode { get; set; }
        public virtual string BankBranchName { get; set; }
        public virtual string Branchaddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MICRCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherBuildingApplicant { get; set; }
        public virtual string EmployerEmailid { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string EmployerMobileNo { get; set; }
        public virtual string servicefee { get; set; }
        [RequiredIf("WhetherRegisterWorker", "True", ErrorMessage = "Required")]
        public virtual string LastRenewalDate { get; set; }
        public virtual string AppliedMessage { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PresentWorkpostOtherDetails { get; set; }
        public virtual string ApplicantSubDiv { get; set; }
        public virtual string ApplicationSubDiv { get; set; }

        public DataSet ds { get; set; }
        public DataTable dt1 { get; set; }
        public DataTable dt2 { get; set; }
        public DataTable dt3 { get; set; }
        public DataTable dt4 { get; set; }

        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList SCSTOBCList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as CasteId,s1.valuename as CasteName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.ConWorkerCategoryList);
                List<CasteMaster> SCSTList = CasteMaster.List<CasteMaster>(Cmd);
                return new SelectList(SCSTList, "CasteId", "CasteName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MaritalStatusMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.MaritalStatus);
                List<ServiceTypeMaster> MaritalStatusMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(MaritalStatusMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList ConsWorkerCertiAuthority
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.ConsCertifyingAuthority);
                List<ServiceTypeMaster> MaritalStatusMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(MaritalStatusMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList Depositlist
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select paymentmodeid as valueid,paymentmode as valuename from dbo.paymentmodemaster");
                List<ServiceTypeMaster> Depositlist = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(Depositlist, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList PLocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.whetheractive=@whetheractive and lm.whetheractive=@whetheractive and dm.stateid=@stateid ";//changes1603
                if (Sessions.getEmployeeUser() != null) { Qry += " and Ls.subdivcode in (@ParamSubDivCode)"; }
                Qry += "  order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept016);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                List<LocalityMaster> PLocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(PLocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        public SelectList PAllLocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.whetheractive=@whetheractive and lm.whetheractive=@whetheractive and dm.stateid=@stateid order by lm.LocalityName ";//changes1603
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept016);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                List<LocalityMaster> PLocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(PLocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MemberRelationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select relationid as Valueid,relationname as Valuename from relationmaster where relationid in(25,14,4,8,17,19,20,23) order by 2 desc");
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MemberRelationListForFamily
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select relationid as Valueid,relationname as Valuename from relationmaster where relationid in(25,14,4,23) order by 2 desc");
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList UnionList
        {
            get
            {
                string Qry = "select unid as ValueId,unionname as ValueName from lbrunionmaster where whetheractive=@whetheractive order by ValueName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<ServiceTypeMaster> UnionList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(UnionList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList WorkplaceList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select  s1.ValueId, s1.ValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.ValueName");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.ConsworkerWorkplaces);
                List<ServiceTypeMaster> WorkplaceList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(WorkplaceList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList WorkmanCategory
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select  s1.ValueId, s1.ValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.ValueName");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.WorkmanCategory);
                List<ServiceTypeMaster> WorkplaceList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(WorkplaceList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList lbrclasslist
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select  s1.ValueId, s1.ValueName, (case when char_length(s1.valuename)=4 then substring(s1.valuename from 0 for 3) else substring(s1.valuename from 0 for 2) end)::int as classvalue from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by  classvalue");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.lbrClassList);
                List<ServiceTypeMaster> WorkplaceList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(WorkplaceList, "ValueId", "ValueName");
            }
            set { }
        }
    }
}