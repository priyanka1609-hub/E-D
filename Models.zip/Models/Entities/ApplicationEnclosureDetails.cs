﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using System.Data.SqlClient;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationEnclosureDetails : Repositry<ApplicationEnclosureDetails>
    {
        [ScaffoldColumn(false)]
        public virtual System.Nullable<int> EnclosureId { get; set; }
        public virtual string RefEnclosureId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(4, MinimumLength = 4)]
        public virtual string ServiceCode { get; set; }
        [RegularExpression("([0-9]+)")]
        public virtual string DocumentTypeId { get; set; }
        [RegularExpression("([0-9]+)")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string DocumentId { get; set; }
        public virtual string VerifyValueId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DepartmentId { get; set; }
        [RequiredIf("DepartmentId", 1, ErrorMessage = "Value Required")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string DeptName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DocumentNo { get; set; }
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg", "application/pdf" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg", ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string DocumentData { get; set; }
        public virtual string DocumentDetails { get; set; }
        public virtual string ContentType { get; set; }
        public virtual string RelatedId { get; set; }
        public virtual string WhetherVerified { get; set; }
        public virtual string WhetherOptional { get; set; }
        public virtual string WhetherActive { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string LastActionDate { get; set; }

        public virtual string Consent { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Please Check the checkbox")]
        public virtual bool consentcheck { get; set; }
        public virtual string consentcheckid { get; set; }
        [CustomProperty]
        public virtual string DocumentName { get; set; }
        [CustomProperty]
        public virtual string DocTypeId { get; set; }
    }
}