﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Data;
using Npgsql;
//SCST Changes Main
namespace Edistrict.Models.Entities
{
    public class ScStFeeDetails : Repositry<ScStFeeDetails>
    {
        public virtual string Sno { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FeeTypeId { get; set; }
        public virtual string FeeTypeName { get; set; }
        public virtual string ServiceCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FeeAmount { get; set; }

        [CustomProperty]
        public DataTable dt { get; set; }

    }
}