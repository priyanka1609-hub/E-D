﻿using Edistrict.Models.DataService;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Edistrict.Models.Entities
{
    public class HeBankBranchMaster : Repositry<HeBankBranchMaster>
    {
        public virtual string HeBranchCode { get; set; }
        public virtual string BranchName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string BranchCode { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string HeBranchName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string BranchAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BranchEmail { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BranchContactNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BaseInterestRate { get; set; }



    }
}