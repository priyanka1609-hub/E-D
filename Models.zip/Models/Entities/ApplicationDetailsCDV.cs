﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Collections.Generic;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsCDV : Repositry<ApplicationDetailsCDV>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [StringLength(12, MinimumLength = 12)]
        [Required(ErrorMessage = "Aadhaar No Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Aadhaar No")]
        public virtual string aadhaarno { get; set; }
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid Identification Mark")]
        [StringLength(100, MinimumLength = 2), Required(ErrorMessage = "Identification Mark Required")]
        public virtual string IdentificationMark { get; set; }
        [Required(ErrorMessage = "Occupation Required")]
        public virtual string OccupationId { get; set; }
        public virtual string OccupationType { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Employer Name ")]
        [StringLength(100, MinimumLength = 2)]
        public virtual string EmployerName { get; set; }
        //[RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter valid Office Address")]
        [StringLength(500, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string OfficeAddress { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Contact No.")]
        [RegularExpression(@"^[7-9][0-9]{9}$", ErrorMessage = "Enter Valid Contact No.")]
        public virtual string OfficeContactNo { get; set; }
        [Required(ErrorMessage = "Educational Qualification is  Required")]
        public virtual string EqualificationId { get; set; }
        public virtual string EducationName { get; set; }
        public virtual string TqualificationId { get; set; }
        public virtual string TqualificationName { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherCDexperience { get; set; }
        [StringLength(250, MinimumLength = 2)]
        [RequiredIf("WhetherCDexperience", "True", ErrorMessage = "Civil Defence Experience Details Required")]
        public virtual string CDexperienceDetails { get; set; }

        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherOwnVehicle { get; set; }
        [StringLength(250, MinimumLength = 2)]
        [RequiredIf("WhetherOwnVehicle", "True", ErrorMessage = "Vehicle Details Required")]
        public virtual string VehicleDetails { get; set; }

        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherKnowDriving { get; set; }
        [StringLength(250, MinimumLength = 2)]
        [RequiredIf("WhetherKnowDriving", "True", ErrorMessage = "Driving Details Required")]
        public virtual string DrivingDetails { get; set; }

        [Required(ErrorMessage = "Value  Required")]
        public virtual string BloodGroup { get; set; }
        public virtual string BloodGroupName { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherBloodDonor { get; set; }
        [StringLength(1, MinimumLength = 1), Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Height")]
        [Range(4, 8, ErrorMessage = "Enter Valid Height")]
        public virtual string HeightFeet { get; set; }
        [StringLength(2, MinimumLength = 1), Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Height")]
        [Range(0, 12, ErrorMessage = "Enter Valid Height")]
        public virtual string HeightInch { get; set; }
        [StringLength(3, MinimumLength = 2), Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid weight in Kg")]
        [Range(40, 200, ErrorMessage = "Enter Valid Height")]
        public virtual string weight { get; set; }
        [StringLength(2, MinimumLength = 1, ErrorMessage="Enter Valid Value")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value in Cm")]
        public virtual string Chest { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherMemberEarlier { get; set; }
        [RequiredIf("WhetherMemberEarlier", "True", ErrorMessage = "Member Details Required")]
        public virtual string MemberEarlierId { get; set; }
        public virtual string MemberEarlierType { get; set; }
        [StringLength(250, MinimumLength = 2)]
        [RequiredIf("WhetherMemberEarlier", "True", ErrorMessage = "Member Details Required")]
        public virtual string MemberEarlierDetails { get; set; }
        [RequiredIf("MemberEarlierId", "136", ErrorMessage = "Member Details Required")]
        public virtual string OrgMemberEarlier { get; set; }

        public virtual string WhetherDischarge { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string CDVSubDivCode { get; set; }
        public virtual string CDVSubDivName { get; set; }
        [Required(ErrorMessage = "House No Required")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string phouseno { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string pstreetno { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string psublocality { get; set; }
        public virtual string pstateid { get; set; }
        public virtual string Hiddenpstateid { get; set; }
        public virtual string PStateName { get; set; }
        public virtual string pcountryid { get; set; }
        public virtual string PCountryName { get; set; }
        public virtual string psubdivcode { get; set; }
        public virtual string PSubDivDescription { get; set; }
        [Required(ErrorMessage = "District Required")]
        public virtual string pdistrictcode { get; set; }
        public virtual string PDistrictName { get; set; }
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "PinCode required")]
        public virtual string ppincode { get; set; }
        public virtual string plocalityid { get; set; }
        [CustomProperty]
        public virtual string PLocalityName { get; set; }

        [StringLength(15, MinimumLength = 2)]
        public virtual string EnrollmentIdOld { get; set; }
        public virtual string WhetherBasicTrainingComplete { get; set; }
        public virtual string EnrollmentNo { get; set; }
        public virtual string EnrollmentDate { get; set; }
        public virtual string Flag { get; set; }

        public virtual string LanguageId { get; set; }
        public virtual string LanguageName { get; set; }
        public virtual string WhetherRead { get; set; }
        public virtual string WhetherWrite { get; set; }
        public virtual string WhetherSpeak { get; set; }
        public virtual string DocumentId { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid account Name")]
        public virtual string AccountHolderName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("[0-9]+", ErrorMessage = " Invalid Input")]
        public virtual string AccountNo { get; set; }
        public virtual string BankName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankCode { get; set; }
        public virtual string BankBranchName { get; set; }
        [StringLength(11, MinimumLength = 11)]
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        [StringLength(9, MinimumLength = 9)]
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("[0-9]+", ErrorMessage = " Invalid Input")]
        public virtual string MICRCode { get; set; }


        //for police verification start

        public virtual string CDVPoliceVerificationId { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherPccComplete { get; set; }
        [RequiredIf("WhetherPccComplete", "True", ErrorMessage = "Police Verification Required")]
        public virtual string PccCompleteId { get; set; }
        public virtual string PCCCompletedType { get; set; }
        [StringLength(250, MinimumLength = 2)]
        [RequiredIf("PccCompleteId", "178", ErrorMessage = "Police Verification Required")]
        public virtual string PccCompleteDetails { get; set; }
        [StringLength(15, MinimumLength = 2)]
        [RequiredIf("WhetherPccComplete", "True", ErrorMessage = "Police Verification No Required")]
        public virtual string VerificationNo { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("WhetherPccComplete", "True", ErrorMessage = "Police Verification Date Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string PoliceVerificationDate { get; set; }

        [RequiredIf("WhetherPccComplete", "True", ErrorMessage = "Please Upload Document")]
        [HttpFile(AllowedContentTypes = new string[] { "application/pdf" }, AllowedFileExtensions = new string[] { ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase DocumentData { get; set; }
        [RequiredIf("WhetherPccComplete", "True", ErrorMessage = "Value Required")]
        public virtual string ContentType { get; set; }
        public virtual string DocumentEntryDate { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherPccUploaded { get; set; }
        [RequiredIf("WhetherPccUploaded", "True", ErrorMessage = "Value Required")]
        public virtual string WhetherPccOk { get; set; }	

        //for police verification start End
        //for police verification for dealing start
        [RequiredIf("WhetherPccOk", "False", ErrorMessage = "Please Upload Document")]
        public virtual string WhetherPccAttached { get; set; }
        [Required(ErrorMessage = "Value Required")]
        //[RequiredIf("WhetherPccAttached", "False", ErrorMessage = "Police Verification Required")]
        public virtual string PccCompleteIdDeal { get; set; }
        public virtual string PCCCompletedTypeDeal { get; set; }
        [StringLength(250, MinimumLength = 2)]
        [RequiredIf("PccCompleteIdDeal", "178", ErrorMessage = "Police Verification Required")]
        public virtual string PccCompleteDetailsDeal { get; set; }
        [StringLength(15, MinimumLength = 2)]
        [Required(ErrorMessage = "Value Required")]
        //[RequiredIf("WhetherPccAttached", "False", ErrorMessage = "Police Verification No Required")]
        public virtual string VerificationNoDeal { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string PoliceVerificationDateDeal { get; set; }
        [Required(ErrorMessage = "File Required")]
        //[RequiredIf("WhetherPccAttached", "False", ErrorMessage = "Please Upload Document")]
        [HttpFile(AllowedContentTypes = new string[] { "application/pdf" }, AllowedFileExtensions = new string[] { ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase DocumentDataDeal { get; set; }
        //for police verification for dealing End




        public virtual string Address { get; set; }
        public virtual string CDVCounter { get; set; }
        public virtual string CDVQuaCounter { get; set; }
        public virtual string StatusId { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual ApplicationDetails ApplicationDetails { get; set; }
        public SelectList CDVSubDivList { get; set; }
        public DataTable dt { get; set; }
        public DataTable dtEdu { get; set; }
        public virtual CDVDutyDetails CDVDutyDetails { get; set; }
        public virtual string DeptCode { get; set; }
        //for filter in the process control forms start
        public virtual string SEqualificationId { get; set; }
        public virtual string STqualificationId { get; set; }
        public virtual string SBloodGroup { get; set; }
        public virtual string SGender { get; set; }
        public virtual string SCDVSubDivCode { get; set; }
        public virtual string SOccupationId { get; set; }
        public virtual string Sweight { get; set; }
        public virtual string SOprheight { get; set; }
        public virtual string Sheight { get; set; }
        public virtual string SOprChest { get; set; }
        public virtual string SChest { get; set; }
        public virtual string SSubDivCode { get; set; }
        //for filter in the process control forms end

        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Employer Name ")]
        public virtual string NameOfKin { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DOBOfKin { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string RelationWithKin { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherAddressSameAsKin { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherAddressSameOfKin { get; set; }
        [RequiredIf("WhetherAddressSameAsKin", "False", ErrorMessage = "Address Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter valid Address")]
        public virtual string AddressOfKin { get; set; }
        [RequiredIf("WhetherAddressSameOfKin", "False", ErrorMessage = "Address Required")]
        public virtual string PermAddressOfKin { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string TrainingPreference { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string NishkamSewaTime { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SelectedServices { get; set; }
        public virtual string HiddenApplicantAddress { get; set; }  



        public DataTable dataseta { get; set; }
        public DataTable datasetb { get; set; }
        public DataTable datasetc { get; set; }

        [CustomProperty]
        public SelectList LocalityList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.whetheractive=@whetheractive order by lm.LocalityName");
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList BloodGroupList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.BloodGroup);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList QualificationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.EducationalQualification);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList OccupationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by SMVD.valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.Occupation);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList LanguageList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by SMVD.valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.LanguageKnown);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList TQualificationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by SMVD.valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.TechnicalQualification);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MembershipearlierList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CDVMembershipEarlier);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList PccReportList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.PCCReport);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList SubDivList
        {
            get
            {
                string Qry = "select SubDivCode,SubDivDescription from SubDivMaster where DistrictCode=@ParamDistrictCode order by SubDivDescription";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode))
                {
                    Cmd.Parameters.AddWithValue("@ParamDistrictCode", Sessions.getEmployeeUser().DistrictCode);
                }
                List<SubDivMaster> SubDivList = SubDivMaster.List<SubDivMaster>(Cmd);
                return new SelectList(SubDivList, "SubDivCode", "SubDivDescription");
            }
            set { }
        }
        public SelectList StateList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select StateId,StateName from StateMaster where stateid <>@state order by StateName");
                cmd.Parameters.AddWithValue("@state", (int)State.Delhi);
                List<StateMaster> StateList = StateMaster.List<StateMaster>(cmd);
                return new SelectList(StateList, "StateId", "StateName");
            }
            set { }
        }
        public SelectList DistrictList
        {
            get
            {
                string Qry = "select DistrictCode,DistrictName from DistrictMaster where deptcode=@ParamDeptCode order by DistrictName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@ParamDeptCode", (int)CountList.Type001);
                List<DistrictMaster> DistrictList = DistrictMaster.List<DistrictMaster>(Cmd);
                return new SelectList(DistrictList, "DistrictCode", "DistrictName");
            }
            set { }
        }
        public SelectList CountryList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select CountryId,CountryName from countrymaster where CountryId=@CountryId  order by CountryId");
                cmd.Parameters.AddWithValue("@CountryId", (int)Country.India);
                List<CountryMaster> CountryList = CountryMaster.List<CountryMaster>(cmd);
                return new SelectList(CountryList, "CountryId", "CountryName");
            }
            set { }
        }
        public SelectList RelationList
        {
            get
            {
                List<RelationMaster> RelationList = RelationMaster.List<RelationMaster>(new Npgsql.NpgsqlCommand("select RelationId,RelationName from RelationMaster where whetheractive=true order by RelationName"));
                return new SelectList(RelationList, "RelationId", "RelationName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList TrainingPreferenceList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CDVTrainingPreferenceList);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
    }
}