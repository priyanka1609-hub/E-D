﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;

namespace Edistrict.Models.Entities
{
    public class CasteMaster : Repositry<CasteMaster>
    {
        public virtual string CasteId { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string CasteName { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string StateId { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string ServiceCode { get; set; }
        [RequiredIf("ServiceCode", "9050", ErrorMessage = "Value Required")]
        public virtual string ResolutionNo { get; set; }
        [RequiredIf("ServiceCode", "9050", ErrorMessage = "Value Required")]
        public virtual string ResolutionDate { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string WhetherCentreCaste { get; set; }
        [RequiredIf("WhetherCentreCaste", "true", ErrorMessage = "Value Required")]
        public virtual string CResolutionNo { get; set; }
        [RequiredIf("WhetherCentreCaste", "true", ErrorMessage = "Value Required")]
        public virtual string CResolutionDate { get; set; }
        public virtual string WhetherActive { get; set; }
        public virtual string UserId { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string ActionDatetime { get; set; }
    }
}