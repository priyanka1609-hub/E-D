﻿using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
namespace Edistrict.Models.Entities
{
    public class OBCIncomeDetails : Repositry<OBCIncomeDetails>
    {

        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationId { get; set; }
        [RequiredIf("FWhetherAlive", "True", ErrorMessage = "Value Required")]
        public virtual string FatherOccupationId { get; set; }
        public virtual string FatherOccupationType { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FWhetherAlive { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("FWhetherAlive", "False", ErrorMessage = "Death Date Required")]
        //[DataType(DataType.Date)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string FDeathDate { get; set; }
        [RequiredIf("FWhetherAlive", "False", ErrorMessage = "Death Certificate No Required")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z0-9])+(?:(([A-Za-z0-9\s]))|(\.[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter valid Certificate No")]
        public virtual string FDeathCertificateNo { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string FWhetherIncapacitation { get; set; }
        
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("FWhetherIncapacitation", "True", ErrorMessage = "Incapacitation Death Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string FPermIncapacitationDate { get; set; }
        [RequiredIf("FWhetherIncapacitation", "True", ErrorMessage = "Incapacitation No Required")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z0-9])+(?:(([A-Za-z0-9\s]))|(\.[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter valid Certificate No")]
        public virtual string FPermIncapacitationCertificateNo { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string FWhetherRetired { get; set; }
        [RequiredIf("FWhetherRetired", "True", ErrorMessage = "Retirement Date Required")]
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string FRetirementDate { get; set; }

        [StringLength(25, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        public virtual string FNameOfOrganisation { get; set; }

        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string FAddressOfOrganisation { get; set; }

        [StringLength(25, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        public virtual string FDesignation { get; set; }

        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string FDateOfJoining { get; set; }

        [StringLength(10, MinimumLength = 4, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([0-9]{4,7})+(\.[0-9]{1,2})?", ErrorMessage = "Enter Valid value")]
        public virtual string FMonthlySalary { get; set; }

        //[Required(ErrorMessage = "Value Required")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Z]{5})+([0-9]{4})+([A-Z]{1})?", ErrorMessage = "Enter Valid value")]
        public virtual string FPanNo { get; set; }




        //[RequiredIf("MWhetherAlive", "True", ErrorMessage = "Value Required")]
        public virtual string MotherOccupationId { get; set; }
        public virtual string MotherOccupationType { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string MWhetherAlive { get; set; }
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("MWhetherAlive", "False", ErrorMessage = "Death Date Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string MDeathDate { get; set; }
       
        [RequiredIf("MWhetherAlive", "False", ErrorMessage = "Death Certificate No Required")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z0-9])+(?:(([A-Za-z0-9\s]))|(\.[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter valid Certificate No")]
        public virtual string MDeathCertificateNo { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string MWhetherIncapacitation { get; set; }
        [RequiredIf("MWhetherIncapacitation", "True", ErrorMessage = "Incapacitation Date Required")]
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string MPermIncapacitationDate { get; set; }
        [RequiredIf("MWhetherIncapacitation", "True", ErrorMessage = "Incapacitation Certificate No Required")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z0-9])+(?:(([A-Za-z0-9\s]))|(\.[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter valid Certificate No")]
        public virtual string MPermIncapacitationCertificateNo { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string MWhetherRetired { get; set; }
        [RequiredIf("MWhetherRetired", "True", ErrorMessage = "Retirement Date Required")]
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]

        public virtual string MRetirementDate { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid value")] 
        public virtual string MNameOfOrganisation { get; set; }

        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string MAddressOfOrganisation { get; set; }

        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid value")] 
        public virtual string MDesignation { get; set; }

        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string MDateOfJoining { get; set; }

        [StringLength(10, MinimumLength = 4, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([0-9]{4,7})+(\.[0-9]{1,2})?", ErrorMessage = "Enter Valid value")]
        public virtual string MMonthlySalary { get; set; }

        //[Required(ErrorMessage = "Value Required")] 
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Z]{5})+([0-9]{4})+([A-Z]{1})?", ErrorMessage = "Enter Valid value")]
        public virtual string MPanNo { get; set; }




        public virtual string HusbandOccupationId { get; set; }
        public virtual string HusbandOccupationType { get; set; }

        public virtual string HWhetherAlive { get; set; }
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        [RequiredIf("HWhetherAlive", "False", ErrorMessage = "Death Date Required")]
        public virtual string HDeathDate { get; set; }

        [RequiredIf("HWhetherAlive", "False", ErrorMessage = "Certificate No Required")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z0-9])+(?:(([A-Za-z0-9\s]))|(\.[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter valid Certificate No")]
        public virtual string HDeathCertificateNo { get; set; }

        public virtual string HWhetherIncapacitation { get; set; }
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        [RequiredIf("HWhetherIncapacitation", "True", ErrorMessage = "PermIncapacitation Date Required")]
        public virtual string HPermIncapacitationDate { get; set; }

        [RequiredIf("HWhetherIncapacitation", "True", ErrorMessage = "PermIncapacitation No Required")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z0-9])+(?:(([A-Za-z0-9\s]))|(\.[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter valid Certificate No")]
        public virtual string HPermIncapacitationCertificateNo { get; set; }

        public virtual string HWhetherRetired { get; set; }
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        [RequiredIf("HWhetherRetired", "True", ErrorMessage = "Retirement Date Required")]
        public virtual string HRetirementDate { get; set; }

        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid value")] 
        public virtual string HNameOfOrganisation { get; set; }

        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string HAddressOfOrganisation { get; set; }

        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid value")] 
        public virtual string HDesignation { get; set; }

        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string HDateOfJoining { get; set; }

        [StringLength(10, MinimumLength = 4, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([0-9]{4,7})+(\.[0-9]{1,2})?", ErrorMessage = "Enter Valid value")]
        public virtual string HMonthlySalary { get; set; }

        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Z]{5})+([0-9]{4})+([A-Z]{1})?", ErrorMessage = "Enter Valid value")]
        public virtual string HPanNo { get; set; }
    }
}