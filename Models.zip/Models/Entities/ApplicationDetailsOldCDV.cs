﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Collections.Generic;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using System.Data;
namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsOldCDV : Repositry<ApplicationDetailsOldCDV>
    {
        public virtual string RegistrationID { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DocId { get; set; }
        public virtual string DocType { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DocumentNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(12, MinimumLength = 12)]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Aadhaar No")]
        public virtual string AadhaarNo { get; set; }

        [Required(ErrorMessage = "Name Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string ApplicantName { get; set; }
        [StringLength(1), Required(ErrorMessage = "Gender Required")]
        public virtual string ApplicantGender { get; set; }
        [Required(ErrorMessage = "Father Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Father Name")]
        public virtual string ApplicantFatherName { get; set; }
        [Required(ErrorMessage = "Mother Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid  Mother Name")]
        public virtual string ApplicantMotherName { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter valid Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid  Spouse Name")]
        public virtual string ApplicantSpouseName { get; set; }
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string ApplicantDOB { get; set; }

        [StringLength(100, MinimumLength = 2), Required(ErrorMessage = "House No Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicantHouseNumber { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Street No Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicantStreetNumber { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Sublocality Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicantSubLocality { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter valid Name")]
        [RegularExpression(@"^[0-9]{6}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string ApplicantPinCode { get; set; }
        [Required(ErrorMessage = "Locality Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Locality")]
        public virtual string ApplicantLocalityId { get; set; }

        [Required(ErrorMessage = "SubDivision Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid SubDivision")]
        public virtual string ApplicantSubDivCode { get; set; }
        [Required(ErrorMessage = "District Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid District")]
        public virtual string ApplicantDistrictCode { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string ApplicantMobileNo { get; set; }
        [Required(ErrorMessage = "Address Required")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicantPermanentAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherSameAddress { get; set; }
        [StringLength(100, MinimumLength = 8)]
        [DataType(DataType.EmailAddress, ErrorMessage = "Enter valid Email")]
        [RegularExpression(@"[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Enter valid Email")]
        public virtual string ApplicantEmail { get; set; }

        




        public virtual string DocumentStatusId { get; set; }
        public virtual string ApplicantUserID { get; set; }
        public virtual string ApplicantPassword { get; set; }
        public virtual string ApplicantAccessCode { get; set; }
        public virtual string RegistrationDate { get; set; }
        public virtual string StateId { get; set; }
        public virtual string ApplicantStateId { get; set; }
        public virtual string StateName { get; set; }
        public virtual string ApplicantCountryId { get; set; }
        public virtual string CountryId { get; set; }
        public virtual string ApplicantSubDivDescription { get; set; }
        public virtual string ApplicantDistrictName { get; set; }
        public virtual string CountryName { get; set; }





        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(4, MinimumLength = 4)]
        public virtual string ServiceCode { get; set; }
        [StringLength(1, MinimumLength = 1)]
        public virtual string ApplicationSourceId { get; set; }
        [StringLength(1, MinimumLength = 1)]
        public virtual string ApplicationRelatedId { get; set; }

        public virtual string ApplicantNationality { get; set; }
        public virtual string ApplicationStatusId { get; set; }



        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountHolderName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid AccountNo.")]
        public virtual string AccountNo { get; set; }
        public virtual string BankName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankCode { get; set; }
        public virtual string BankBranchName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MICRCode { get; set; }

        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid Identification Mark")]
        [StringLength(100, MinimumLength = 2), Required(ErrorMessage = "Identification Mark Required")]
        public virtual string IdentificationMark { get; set; }
        [Required(ErrorMessage = "Occupation Required")]
        public virtual string OccupationId { get; set; }
        public virtual string OccupationType { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Employer Name ")]
        [StringLength(100, MinimumLength = 2)]
        public virtual string EmployerName { get; set; }
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter valid Office Address")]
        public virtual string OfficeAddress { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Contact No.")]
        [RegularExpression(@"^[7-9][0-9]{9}$", ErrorMessage = "Enter Valid Contact No.")]
        public virtual string OfficeContactNo { get; set; }
        [Required(ErrorMessage = "Educational Qualification is  Required")]
        public virtual string EqualificationId { get; set; }
        public virtual string EducationName { get; set; }
        public virtual string TqualificationId { get; set; }
        public virtual string TqualificationName { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherCDexperience { get; set; }
        [StringLength(250, MinimumLength = 2)]
        public virtual string CDexperienceDetails { get; set; }

        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherOwnVehicle { get; set; }
        [StringLength(250, MinimumLength = 2)]
        public virtual string VehicleDetails { get; set; }

        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherKnowDriving { get; set; }
        [StringLength(250, MinimumLength = 2)]
        public virtual string DrivingDetails { get; set; }

        [Required(ErrorMessage = "Value  Required")]
        public virtual string BloodGroup { get; set; }
        public virtual string BloodGroupName { get; set; }
        public virtual string WhetherBloodDonor { get; set; }
        [StringLength(1, MinimumLength = 0)]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Height")]
        [Range(0, 8, ErrorMessage = "Enter Valid Height")]
        public virtual string HeightFeet { get; set; }
        [StringLength(2, MinimumLength = 0)]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Height")]
        [Range(0, 12, ErrorMessage = "Enter Valid Height")]
        public virtual string HeightInch { get; set; }
        [StringLength(3, MinimumLength = 0)]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid weight in Kg")]
        [Range(0, 200, ErrorMessage = "Enter Valid Height")]
        public virtual string weight { get; set; }
        [StringLength(2, MinimumLength = 0)]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Chest in Cm")]
        public virtual string Chest { get; set; }
        public virtual string WhetherMemberEarlier { get; set; }
        public virtual string MemberEarlierId { get; set; }
        public virtual string MemberEarlierType { get; set; }
        [StringLength(250, MinimumLength = 2)]
        public virtual string MemberEarlierDetails { get; set; }

        public virtual string WhetherDischarge { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string CDVSubDivCode { get; set; }
        public virtual string CDVSubDivName { get; set; }

        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherBasicTrainingComplete { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string EnrollmentNo { get; set; }
        public virtual string WhetherOldCDVEntry { get; set; }

        [Required(ErrorMessage = "Value  Required")]
        public virtual string EnrollmentDate { get; set; }
        public virtual string Flag { get; set; }

        public virtual string LanguageId { get; set; }
        public virtual string LanguageName { get; set; }
        public virtual string WhetherRead { get; set; }
        public virtual string WhetherWrite { get; set; }
        public virtual string WhetherSpeak { get; set; }

        //[Required(ErrorMessage = "Value Required")]
        public virtual string NameOfKin { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        public virtual string DOBOfKin { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        public virtual string RelationWithKin { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        public virtual string WhetherAddressSameAsKin { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        public virtual string WhetherAddressSameOfKin { get; set; }
        [RequiredIf("WhetherAddressSameAsKin", "False", ErrorMessage = "Address Required")]
        public virtual string AddressOfKin { get; set; }
        [RequiredIf("WhetherAddressSameOfKin", "False", ErrorMessage = "Address Required")]
        public virtual string PermAddressOfKin { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        public virtual string TrainingPreference { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        public virtual string NishkamSewaTime { get; set; }

        //for police verification start

        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherPccComplete { get; set; }
        [RequiredIf("WhetherPccComplete", "True", ErrorMessage = "Police Verification Required")]
        public virtual string PccCompleteId { get; set; }
        public virtual string PCCCompletedType { get; set; }
        [StringLength(250, MinimumLength = 2)]
        [RequiredIf("PccCompleteId", "178", ErrorMessage = "Police Verification Required")]
        public virtual string PccCompleteDetails { get; set; }
        [StringLength(15, MinimumLength = 2)]
        [RequiredIf("WhetherPccComplete", "True", ErrorMessage = "Police Verification No Required")]
        public virtual string VerificationNo { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("WhetherPccComplete", "True", ErrorMessage = "Police Verification Date Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string PoliceVerificationDate { get; set; }

        [RequiredIf("WhetherPccComplete", "True", ErrorMessage = "Please Upload Document")]
        [HttpFile(AllowedContentTypes = new string[] { "application/pdf" }, AllowedFileExtensions = new string[] { ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase DocumentData { get; set; }
        [HttpFile(AllowedContentTypes = new string[] { "application/pdf" }, AllowedFileExtensions = new string[] { ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase DocumentData1 { get; set; }
        [RequiredIf("WhetherPccComplete", "True", ErrorMessage = "Value Required")]
        public virtual string ContentType { get; set; }
        public virtual string DocumentEntryDate { get; set; }
        [Required(ErrorMessage = "Value  Required")]

        //for police verification start End

        public virtual string CDVCounter { get; set; }
        public virtual string CDVQuaCounter { get; set; }
        public virtual ApplicationDetails ApplicationDetails { get; set; }
        public SelectList CDVSubDivList { get; set; }
        public DataTable dt { get; set; }
        public DataTable dtEdu { get; set; }
        public virtual CDVDutyDetails CDVDutyDetails { get; set; }
        public virtual string DeptCode { get; set; }
        public DataTable dataseta { get; set; }
        public DataTable datasetb { get; set; }
        public DataTable datasetc { get; set; }

        [CustomProperty]
        public SelectList DocumentAvailableAtCitizen
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select DocumentId,DocumentName from dbo.DocumentMaster where DocumentId in (@VoterID,@AadhaarCard) order by DocumentName");
                Cmd.Parameters.AddWithValue("@VoterID", (int)DocumentId.VoterID);
                Cmd.Parameters.AddWithValue("@AadhaarCard", (int)DocumentId.AadhaarCard);
                List<DocumentMaster> DocumentMasterList = DocumentMaster.List<DocumentMaster>(Cmd);
                return new SelectList(DocumentMasterList, "DocumentId", "DocumentName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList LocalityList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and lm.whetheractive=@whetheractive and dm.stateid=@stateid order by lm.LocalityName");
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList BloodGroupList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.BloodGroup);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList QualificationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.EducationalQualification);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList OccupationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by SMVD.valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.Occupation);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList LanguageList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by SMVD.valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.LanguageKnown);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList TQualificationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by SMVD.valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.TechnicalQualification);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "No", Value = "False", Selected = true });
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MembershipearlierList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CDVMembershipEarlier);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList PccReportList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.PCCReport);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList SubDivList
        {
            get
            {
                string Qry = "select SubDivCode,SubDivDescription from SubDivMaster where DistrictCode=@ParamDistrictCode order by SubDivDescription";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode))
                {
                    Cmd.Parameters.AddWithValue("@ParamDistrictCode", Sessions.getEmployeeUser().DistrictCode);
                }
                List<SubDivMaster> SubDivList = SubDivMaster.List<SubDivMaster>(Cmd);
                return new SelectList(SubDivList, "SubDivCode", "SubDivDescription");
            }
            set { }
        }
        public SelectList StateList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select StateId,StateName from StateMaster where stateid <>@state order by StateName");
                cmd.Parameters.AddWithValue("@state", (int)State.Delhi);
                List<StateMaster> StateList = StateMaster.List<StateMaster>(cmd);
                return new SelectList(StateList, "StateId", "StateName");
            }
            set { }
        }
        public SelectList DistrictList
        {
            get
            {
                string Qry = "select DistrictCode,DistrictName from DistrictMaster where deptcode=@ParamDeptCode order by DistrictName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@ParamDeptCode", (int)CountList.Type001);
                List<DistrictMaster> DistrictList = DistrictMaster.List<DistrictMaster>(Cmd);
                return new SelectList(DistrictList, "DistrictCode", "DistrictName");
            }
            set { }
        }
        public SelectList CountryList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select CountryId,CountryName from countrymaster where CountryId=@CountryId  order by CountryId");
                cmd.Parameters.AddWithValue("@CountryId", (int)Country.India);
                List<CountryMaster> CountryList = CountryMaster.List<CountryMaster>(cmd);
                return new SelectList(CountryList, "CountryId", "CountryName");
            }
            set { }
        }
        public SelectList RelationList
        {
            get
            {
                List<RelationMaster> RelationList = RelationMaster.List<RelationMaster>(new Npgsql.NpgsqlCommand("select RelationId,RelationName from RelationMaster where whetheractive=true order by RelationName"));
                return new SelectList(RelationList, "RelationId", "RelationName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList TrainingPreferenceList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CDVTrainingPreferenceList);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
    }
}