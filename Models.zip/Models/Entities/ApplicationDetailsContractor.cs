﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsContractor : Repositry<ApplicationDetailsContractor>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(150, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Please InValid Name")]
        public virtual string Nameofcontractor { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(150, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        //[RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Please InValid Name")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Value")]
        public virtual string NameofEstContractor { get; set; }
        [StringLength(150, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Please InValid Name")]
        public virtual string Fnameofcontractor { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(200, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Address")]
        public virtual string Addressofcontractor { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(200, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Address")]
        public virtual string LocalAddressofcontractor { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^[a-zA-Z0-9]*$", ErrorMessage = "Enter InValid value")]
        public virtual string Natureofwork { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CommencementDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CompletionDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string Dob { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(200, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter InValid name")]
        public virtual string Nameofmanageratsite { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(150, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Address")]
        public virtual string Addressofmanageratsite { get; set; }
        [StringLength(4, MinimumLength = 1)]
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^0*([1-9]\d{2,}|[2-9]\d)$", ErrorMessage = "Enter InValid value.")]
        public virtual string Maxworkers { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherconvicted { get; set; }
        [RequiredIf("Whetherconvicted", "True", ErrorMessage = "Details Required")]
        [RegularExpression("^[a-zA-Z0-9]*$", ErrorMessage = " In Valid Input")]
        public virtual string Convictiondetails { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherlicensesuspend { get; set; }
        [RequiredIf("Whetherlicensesuspend", "True", ErrorMessage = "Required")]
        public virtual string SuspensionorderDate { get; set; }
        [RequiredIf("Whetherlicensesuspend", "True", ErrorMessage = "Required")]
        [RegularExpression("^[a-zA-Z0-9-/]*$", ErrorMessage = " In Valid Input")]
        public virtual string SuspensionorderNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherworkedinpast { get; set; }
        [RequiredIf("Whetherworkedinpast", "True", ErrorMessage = "Required")]
        [StringLength(150, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Please InValid Name")]
        public virtual string Nameofest { get; set; }
        [RequiredIf("Whetherworkedinpast", "True", ErrorMessage = "Required")]
        [StringLength(200, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Address")]
        public virtual string Addressofest { get; set; }
        [RequiredIf("Whetherworkedinpast", "True", ErrorMessage = "Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^[a-zA-Z0-9]*$", ErrorMessage = "Enter InValid value")]
        public virtual string Natureofest { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AppLocalityId { get; set; }
        public virtual string LocalityName { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter InValid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string MobileNoOfContractor { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Enter InValid Email")]
        public virtual string EmailOfContractor { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(150, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^((?:https?\:\/\/|www\.)(?:[-a-z0-9]+\.)*[-a-z0-9]+.*)$", ErrorMessage = "Enter InValid Website(Ex. www.example.com)")]
        public virtual string WebsiteOfContractor { get; set; }
        [StringLength(150, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^((?:https?\:\/\/|www\.)(?:[-a-z0-9]+\.)*[-a-z0-9]+.*)$", ErrorMessage = "Enter InValid Website(Ex. www.example.com)")]
        public virtual string PeWebsite { get; set; }
        [RegularExpression("^[a-zA-Z0-9-/]*$", ErrorMessage = "Invalid Input")]
        public virtual string PeapplicationNo { get; set; }
        public virtual string PeapplicationDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(150, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Please InValid Name")]
        public virtual string PeName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(200, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Address")]
        public virtual string Peaddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter InValid value")]
        public virtual string Petype { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(150, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Please InValid Name")]
        public virtual string PestName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(200, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Address")]
        public virtual string Pestaddress { get; set; }
        public virtual string Peduration { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Check Box Checked Required")]
        public virtual bool check { get; set; }
        public virtual string Whetherexist { get; set; }
        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList LocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@Dept and dm.stateid=@stateid and LM.whetheractive=@whetheractive and LS.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@Dept", (int)Department.Dept007);
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
    }
}