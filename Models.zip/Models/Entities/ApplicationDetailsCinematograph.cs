﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Collections.Generic;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsCinematograph : Repositry<ApplicationDetailsCinematograph>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string CinemaOwner { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string FatherName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [StringLength(500, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter valid Address")]
        public virtual string CinemaOwnerAddress { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter valid Cinema Name")]
        public virtual string CinemaName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [StringLength(500, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter valid Cinema Address")]
        public virtual string CinemaAddress { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string CinemaLocalityId { get; set; }
        public virtual string CinemaLocalityName { get; set; }

        [Required(ErrorMessage = "Select atleast one option")]
        public virtual string EducationalQualification { get; set; }
        public virtual string EducationalQualificationName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(200, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter Valid Value")]
        public virtual string FinancialPosition { get; set; }
        [Required(ErrorMessage = "Select atleast one option")]
        public virtual string PresentOccupation { get; set; }
        public virtual string PresentOccupationName { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherConvicted { get; set; }
        [RequiredIf("WhetherConvicted", "True", ErrorMessage = "Details Required")]
        public virtual string ConvictedDetails { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Z]{5})+([0-9]{4})+([A-Z]{1})?", ErrorMessage = "Enter Valid value")]
        public virtual string PanNo { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string NationalityId { get; set; }
        public virtual string NationalityName { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        [StringLength(4, MinimumLength = 4, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([1-2]{1})+([0-9]{3})?", ErrorMessage = "Enter Valid value")]
        public virtual string YearOfConstruction { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        [StringLength(1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[1-9]$", ErrorMessage = "Enter Valid value")]
        public virtual string NoOfScreens { get; set; }
        public virtual string ApplicationStatusId { get; set; }

        [Required(ErrorMessage = "Value  Required")]
        public virtual string LicenceNo { get; set; }
        public virtual string LocalityId { get; set; }
        public virtual string LocalityName { get; set; }
        public virtual string DistrictCode { get; set; }
        public virtual string DistrictName { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"([7-9]{1})+([0-9]{9})", ErrorMessage = "Enter Valid value")]
        public virtual string ContactNo { get; set; }
        [StringLength(100, MinimumLength = 8), Required(ErrorMessage = "Email Required")]
        [DataType(DataType.EmailAddress, ErrorMessage = "Enter valid Email")]
        [RegularExpression(@"[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Enter valid Email")]
        public virtual string EmailId { get; set; }

        [Required(ErrorMessage = "Value  Required")]
        public virtual string LicenceGrantDate { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string LastInspectionDate { get; set; }
        public virtual string DocumentImage { get; set; }
        public virtual string ContentType { get; set; }

        public virtual string YearsLicenseNeeded { get; set; }
        public virtual string ProLicenseNo { get; set; }
        public virtual string ProLicenseDate { get; set; }
        public virtual string ExpiryDate { get; set; }
        public virtual bool WhetherInSystem { get; set; }

        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList OccupationMasterList
        {
            get
            {
                List<OccupationMaster> OccupationMasterList = OccupationMaster.List<OccupationMaster>(new Npgsql.NpgsqlCommand("select OccupationId,OccupationType from dbo.OccupationMaster order by OccupationType"));
                return new SelectList(OccupationMasterList, "OccupationId", "OccupationType");
            }
            set { }
        }
        [CustomProperty]
        public SelectList NationalityMasterList
        {
            get
            {
                List<NationalityMaster> NationalityMasterList = NationalityMaster.List<NationalityMaster>(new Npgsql.NpgsqlCommand("select NationalityId,NationalityName from dbo.NationalityMaster order by NationalityName"));
                return new SelectList(NationalityMasterList, "NationalityId", "NationalityName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList QualificationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.EducationalQualification);
                List<SelectValueMaster> QualificationList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(QualificationList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList LocalityList
        {
            get
            {
                string Qry = "select lm.LocalityId,lm.LocalityName from dbo.LocalityMaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.whetheractive=@whetheractive";
                if (Sessions.getEmployeeUser() != null) { if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and sd.SubDivCode in (@ParamSubDivCode)"; } }
                Qry += " order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
    }
}