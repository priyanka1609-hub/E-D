﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;
//changes by devansh on 10/10/2017
namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsExgratia : Repositry<ApplicationDetailsExgratia>
    {

        public virtual string ApplicationStatusId { get; set; }

        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }


        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }


        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[a-zA-Z\s\.]+$", ErrorMessage = "Enter Beneficiary Name ")]
        public virtual string BeneficiaryName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter valid Registration No")]
        public virtual string RegistrationNO { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string RegistrationDate { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]

        public virtual string BeneficiaryAddress { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("married", (int)ValueId.Married, ErrorMessage = "Value Required")]
        [StringLength(150, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Spouse Name")]
        public virtual string SpouseName { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("married", (int)ValueId.Married, ErrorMessage = "Value Required")]
        [StringLength(500, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Spouse Address")]
        public virtual string SpouseAddress { get; set; }

        public virtual string ExCounter { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [StringLength(150, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid Hospital Name")]
        public virtual string HospitalName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [StringLength(15, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DisabilityCertificateDate { get; set; }

        [RequiredIf("whthrgetdisapension", "True", ErrorMessage = "Value Required")]
        [StringLength(10, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string DisabilityPension { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [StringLength(10, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        public virtual string ExGratiaAmount { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Nominee Name")]
        public virtual string NomineeName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [StringLength(500, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string NomineeAddress { get; set; }


        [Required(ErrorMessage = "Value Required")]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [StringLength(15, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string NomineeDOB { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(5, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid DeceasedMember Name")]
        public virtual string DeceasedMember { get; set; }


        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid  Name")]
        public virtual string Withthe { get; set; }


        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid  Name")]
        public virtual string AccountHolderName { get; set; }



        [Required(ErrorMessage = "Value Required")]
        [StringLength(16, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter valid AccountNo")]
        public virtual string AccountNo { get; set; }



        [Required(ErrorMessage = "Value Required")]
        [StringLength(9, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string MICRCode { get; set; }


        [Required(ErrorMessage = "Value Required")]
        [StringLength(11, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }


        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid  Name")]
        public virtual string BankName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [StringLength(250, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]

        public virtual string BankBranchAddress { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [CustomProperty]
        public virtual string Gendername { get; set; }


        [Required(ErrorMessage = "Value Required")]
        [CustomProperty]
        public virtual string DisabilityPercentage { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [CustomProperty]
        public virtual string permanentdisabled { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [CustomProperty]
        public virtual string whthrgetdisapension { get; set; }


        [Required(ErrorMessage = "Value Required")]
        [CustomProperty]
        public virtual string districtcode { get; set; }

        public virtual string married { get; set; }//changes1502


        public DataTable data { get; set; }


        public DataTable data1 { get; set; }




        [CustomProperty]
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                list.Add(new SelectListItem() { Text = "Transgender", Value = "T" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList RelationMasterList
        {
            get
            {
                List<RelationMaster> RelationMasterList = RelationMaster.List<RelationMaster>(new Npgsql.NpgsqlCommand("select relationid,relationname from dbo.relationmaster order by relationname"));
                return new SelectList(RelationMasterList, "relationid", "relationname");
            }
            set { }
        }

        [CustomProperty]
        public SelectList SelectYesNo
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "true" });
                list.Add(new SelectListItem() { Text = "No", Value = "false" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }


        [CustomProperty]
        public SelectList DPercentageMasterList
        {
            get
            {
                List<DisabilityPercentageMaster> DPercentageMasterList = DisabilityPercentageMaster.List<DisabilityPercentageMaster>(new Npgsql.NpgsqlCommand("select DPercentageId,DPercentageName,replace(DPercentageName,'%','')::integer as pvalue from disabilitypercentagemaster order by pvalue"));
                return new SelectList(DPercentageMasterList, "DPercentageId", "DPercentageName");
            }
            set { }
        }


        [CustomProperty]
        public SelectList DistrictMasterList
        {
            get
            {

                NpgsqlCommand Cmd = new NpgsqlCommand("select DistrictCode,DistrictName from dbo.DistrictMaster where stateid=@stateid");
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                List<DistrictMaster> DistrictMasterList = DistrictMaster.List<DistrictMaster>(Cmd);
                return new SelectList(DistrictMasterList, "DistrictName", "DistrictName");



            }
            set { }
        }
    }
}