﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsPostmatSCssd : Repositry<ApplicationDetailsPostmatSCssd>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplyingFor { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherPANNo { get; set; }
        [RequiredIf("WhetherPANCard", "True", ErrorMessage = "Details Required")]
        [RegularExpression("^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$", ErrorMessage = "Please Enter Valid PAN")]
        public virtual string PANNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CategoryId { get; set; }
        public virtual string Category { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("^[1-9][0-9]*$", ErrorMessage = "Please Enter Valid PAN")]
        public virtual string AnnualIncome { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string NameAsPerSchool { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherCollegeInDelhi { get; set; }
        [RequiredIf("WhetherCollegeInDelhi", "True", ErrorMessage = "Details Required")]
        public virtual string SchoolId { get; set; }
        [RequiredIf("WhetherCollegeInDelhi", "False", ErrorMessage = "Details Required")]
        public virtual string CollegeName { get; set; }
        [RequiredIf("WhetherCollegeInDelhi", "False", ErrorMessage = "Details Required")]
        public virtual string CollegePincode { get; set; }
        [RequiredIf("WhetherCollegeInDelhi", "False", ErrorMessage = "Details Required")]
        public virtual string CollegeDistrict { get; set; }
        [RequiredIf("WhetherCollegeInDelhi", "False", ErrorMessage = "Details Required")]
        public virtual string CollegeState { get; set; }
        [RequiredIf("WhetherCollegeInDelhi", "False", ErrorMessage = "Details Required")]
        public virtual string CollegeAddress { get; set; }
        [RequiredIf("WhetherCollegeInDelhi", "False", ErrorMessage = "Details Required")]
        public virtual string CollegeAffiliationId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CollegeCode { get; set; }
        public virtual string DeptId { get; set; }
        public virtual string SchId { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string SchoolTypeId { get; set; }
        public virtual string SchoolType { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DepartmentId { get; set; }
        public virtual string DepartmentType { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string NatureTypeId { get; set; }
        public virtual string NatureType { get; set; }


        [Required(ErrorMessage = "Value Required")]
        public virtual string PresentClass { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[-_ a-zA-Z]+$", ErrorMessage = "Enter Valid Value")]
        public virtual string PresentCourse { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PreviousClass { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[-_ a-zA-Z]+$", ErrorMessage = "Enter Valid Value")]
        public virtual string PreviousCourse { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherHostler { get; set; }
        public virtual string WhetherHostlerType { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string YearClassPassed { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("[0-9]+", ErrorMessage = "InValid Input")]
        public virtual string AttendancePercentage { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("[0-9]+", ErrorMessage = "InValid Input")]
        public virtual string MarksPercentage { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountHolderName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("[0-9]+", ErrorMessage = " InValid Input")]
        public virtual string AccountNo { get; set; }
        public virtual string BankName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankCode { get; set; }
        public virtual string BankBranchName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("[0-9]+", ErrorMessage = " InValid Input")]
        [StringLength(9, MinimumLength = 9, ErrorMessage = "Enter Valid MICR")]
        public virtual string MICRCode { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [RequiredIf("WhetherCollegeInDelhi", "False", ErrorMessage = "Details Required")]
        public virtual string WhetherReceiptUploaded { get; set; }

        [Required(ErrorMessage = "Please Select Recommendation")]
        public virtual string WhetherSchoolRecomended { get; set; }
        public virtual string WhetherSchoolRecomend { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SchollRemarks { get; set; }


        [Required(ErrorMessage = "Please Select Declaration")]
        public virtual string DeclarationId { get; set; }
        public virtual string Declaration { get; set; }
        public virtual string Observation { get; set; }

        [Required(ErrorMessage = "Please Select Value")]
        public virtual string WhetherIssuedFromDelhi { get; set; }
        public virtual string WhetherIssuedFDelhi { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(14, MinimumLength = 5, ErrorMessage = "Enter Valid Value")]
        [RegularExpression("[0-9]+", ErrorMessage = "certificate No must be numeric")]
        public virtual string CasteCerNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CasteCerIssueDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(14, MinimumLength = 14, ErrorMessage = "Enter Valid Value")]
        [RegularExpression("[0-9]+", ErrorMessage = "certificate No must be numeric")]
        public virtual string DomicileCerNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DomicileCerIssueDate { get; set; }
        public virtual string SchollRemarksBy { get; set; }
        public virtual string SchollRemarksIpAddress { get; set; }

        [Required(ErrorMessage = "Please Select Value")]
        public virtual string GroupId { get; set; }
        public virtual string GroupType { get; set; }
        public virtual string WhetherCasteVerified { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AcademicSession { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AcademicSessionType { get; set; }

        public virtual string ApplyingServiceFor { get; set; }

        public virtual bool WhetherOldDataFound { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(15, MinimumLength = 2)]
        public virtual string EnrolmentId { get; set; }

        public List<ScStFeeDetails> ScStFeeDetails { get; set; }
        public DataTable dt { get; set; }
        public SelectList ClassList { get; set; }

        public virtual SelectList YearList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int varYear = DateTime.Now.Year - 3;
                for (int i = varYear; i < DateTime.Now.AddYears(1).Year; i++)
                {
                    list.Add(new SelectListItem() { Text = varYear.ToString(), Value = varYear.ToString() });
                    varYear++;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList ApplyingForList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.FreshOrRenewal);
                List<SelectValueMaster> ApplyingForList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(ApplyingForList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList CategoryList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.MatricScholarshipCategorySC);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList StateMasterExceptDelhiList
        {
            get
            {
                string Qry = "select StateId,StateName from dbo.StateMaster where stateid<>@Delhi order by StateName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@Delhi", (int)State.Delhi);
                List<StateMaster> SubDivList = StateMaster.List<StateMaster>(Cmd);
                return new SelectList(SubDivList, "StateId", "StateName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList SchoolList
        {
            get
            {
                //string Qry = "select PSM.SchoolId as SelectValueId,SchoolName||','||SchoolAddress as SelectValueName from dgen.prematschoolmaster PSM inner join dgen.prematschooltoservice PSTS on PSTS.SchoolId=PSM.SchoolId where PSM.WhetherActive=@WhetherActive and ServiceCode=@ServiceCode order by SchoolName";
                string Qry = "select PSM.SchoolId as SelectValueId,SchoolName||','||SchoolAddress as SelectValueName from dgen.prematschoolmaster PSM where PSM.WhetherActive=@WhetherActive order by SchoolName limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                //Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.MeritscholarshipProfessional);
                List<SelectValueMaster> SubDivList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(SubDivList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList MeritGroupList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SCSTMeritGroup);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList SchoolTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.PostMatSchoolType);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }

        public SelectList DepartmentList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.SCSTDepartmentType);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
    }
}
