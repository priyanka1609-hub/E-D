﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
     public class HeSchoolMaster : Repositry<HeSchoolMaster>
    {
        public virtual string SchoolId { get; set; }
        public virtual string SchoolName { get; set; }
    }
}