﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.Entities
{
    public class ApiClientMaster : Repositry<ApiClientMaster>
    {
        [Required(ErrorMessage = "Plese Enter ClientId")]
        [RegularExpression(@"^[a-zA-Z0-9 /s]{5,20}$", ErrorMessage = "Only AlphaNumeric and  must be between 5 and 20.")]
        public virtual string ClientId { get; set; }
        [Required(ErrorMessage = "Plese Enter Client Name")]
        [RegularExpression(@"^[a-zA-Z0-9 /s]{5,20}$", ErrorMessage = "Only AlphaNumeric and  must be between 5 and 20.")]
        public virtual string ClientName { get; set; }
        [Required(ErrorMessage = "Plese Enter Nodal Officer Name")]
        [RegularExpression("^[a-zA-Z0-9 /s]*$", ErrorMessage = "Only AlphaNumeric allowed.")]
        public virtual string NodalOfficerName { get; set; }
        [Required(ErrorMessage = "Plese Enter Nodal Officer Mobile No")]
        [RegularExpression("^[0-9]{10}$", ErrorMessage = "Please Enetr Valid Mobile Number.")]
        public virtual string NodalOfficerMobNo { get; set; }
        //public virtual string KeyValidUpTo { get; set; }
        //public virtual string EncdecKey { get; set; }
    }
}