﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class SocialCategoryMaster : Repositry<SocialCategoryMaster>
    {
        public virtual string SocialCategoryId { get; set; }
        public virtual string SocialCategoryName { get; set; }
        public virtual string WhetherActive { get; set; }
    }
}