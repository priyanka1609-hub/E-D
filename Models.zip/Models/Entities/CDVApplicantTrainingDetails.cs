﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Collections.Generic;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class CDVApplicantTrainingDetails : Repositry<CDVApplicantTrainingDetails>
    {
        public virtual string TApplicationNo { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string TrainingId { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string TrainingTypeId { get; set; }
        public virtual string TrainingType { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string TrainingCourseId { get; set; }
        public virtual string TrainingCourseName { get; set; }

        [Required(ErrorMessage = "Required")]
        public virtual string VenueId { get; set; }
        public virtual string VenueName { get; set; }

        public virtual string VenueAddress { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string TrainingDuration { get; set; }

        public virtual string PoliceStationId { get; set; }
        public virtual string WhetherTrainingCompleted { get; set; }
        public virtual string TsessionId { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string TrainingObservation { get; set; }
        public virtual string WhetherPresent { get; set; }


        [Required(ErrorMessage = "Required")]
        public virtual string TrainingPeriodId { get; set; }

        [RequiredIf("TrainingPeriodId", "True", ErrorMessage = "Training Period From Rquired")]
        public virtual string TrainingFrom { get; set; }
        [RequiredIf("TrainingPeriodId", "True", ErrorMessage = "Training Period To Rquired")]
        public virtual string TrainingTo { get; set; }

        [Required(ErrorMessage = "Required")]
        [RegularExpression("([0-9]+)")]
        [StringLength(4, MinimumLength = 1)]
        public virtual string ChkChecked { get; set; }

        public DataTable dt { get; set; }
        public DataTable dtEdu { get; set; }
        public SelectList TrainingTypeList { get; set; }
        public SelectList CDVrefNumber { get; set; }
        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList TrainingPeriodList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "5 Regular Days", Value = "True" });
                //list.Add(new SelectListItem() { Text = "5 Sunday", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList AttendanceList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.Attendance);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        //[CustomProperty]
        //public SelectList TrainingTypeList
        //{
        //    get
        //    {
        //        NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
        //        Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CDVTrainingType);
        //        List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
        //        return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
        //    }
        //    set { }
        //}
        [CustomProperty]
        public SelectList TrainingCourseList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select CourseId,CourseName from CourseMaster order by CourseName");
                List<CourseMaster> ServiceTypeMasterList = CourseMaster.List<CourseMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "CourseId", "CourseName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList VenueList
        {
            get
            {
                string Qry = "select VenueId,VenueName from VenueMaster ";
                if (Sessions.getEmployeeUser() != null)
                {
                    if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode))
                    {
                        Qry += " where DistrictCode=@ParamDistrictCode";
                    }
                }
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                if (Sessions.getEmployeeUser() != null)
                {
                    if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode))
                    {
                        Cmd.Parameters.AddWithValue("@ParamDistrictCode", Sessions.getEmployeeUser().DistrictCode);
                    }
                }
                List<VenueMaster> VenueList = VenueMaster.List<VenueMaster>(Cmd);
                return new SelectList(VenueList, "VenueId", "VenueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList DurationList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                for (int i = 0; i < 60; i++)
                {
                    list.Add(new SelectListItem() { Text = (i + 1).ToString(), Value = (i + 1).ToString() });
                }
                return new SelectList(list, "Text", "Value");
            }
            set { }
        }

    }
}