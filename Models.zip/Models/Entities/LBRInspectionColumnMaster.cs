﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Web.Mvc;
using Edistrict.Models.DataService;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class LBRInspectionColumnMaster
    {
        public DataTable data { get; set; }
        public DataTable dtb { get; set; }
        public string LicenseNo { get; set; }
        public string ServiceCode { get; set; }
        public string ServiceName { get; set; }
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList SatisUnsatisList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Satisfactory", Value = "Satisfactory" });
                list.Add(new SelectListItem() { Text = "Unsatisfactory", Value = "Unsatisfactory" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList TypeOfLiftList1
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.TypeofLift1);
                List<SelectValueMaster> TypeOfLiftList1 = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(TypeOfLiftList1, "SelectValueName", "SelectValueName");
            }
            set { }
        }
        public SelectList TypeOfLiftList2
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.TypeofLift2);
                List<SelectValueMaster> TypeOfLiftList2 = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(TypeOfLiftList2, "SelectValueName", "SelectValueName");
            }
            set { }
        }
        public SelectList TypeOfLiftList3
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.TypeofLift3);
                List<SelectValueMaster> TypeOfLiftList3 = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(TypeOfLiftList3, "SelectValueName", "SelectValueName");
            }
            set { }
        }
        public SelectList SatisUnsatisNAList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Not Required", Value = "Not Required" });
                list.Add(new SelectListItem() { Text = "Satisfactory", Value = "Satisfactory" });
                list.Add(new SelectListItem() { Text = "Unsatisfactory", Value = "Unsatisfactory" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList YesNoNAList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                list.Add(new SelectListItem() { Text = "NA", Value = "NA" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList TransformerTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.TransformerType);
                List<SelectValueMaster> TransformerTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(TransformerTypeList, "SelectValueName", "SelectValueName");
            }
            set { }
        }
        public SelectList PoleTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.PoleType);
                List<SelectValueMaster> PoleTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(PoleTypeList, "SelectValueName", "SelectValueName");
            }
            set { }
        }
        public SelectList DoorTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.DoorType);
                List<SelectValueMaster> DoorTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(DoorTypeList, "SelectValueName", "SelectValueName");
            }
            set { }
        }
        public SelectList ElectricPanel
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.PanelTypeList);
                List<SelectValueMaster> ElectricPanel = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(ElectricPanel, "SelectValueName", "SelectValueName");
            }
            set { }
        }
        public SelectList CableTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.LineCableTypeList);
                List<SelectValueMaster> CableTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CableTypeList, "SelectValueName", "SelectValueName");
            }
            set { }
        }
    }
}