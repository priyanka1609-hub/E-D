﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class DocumentTypeMaster : Repositry<DocumentTypeMaster>
    {
        public virtual string DocumentTypeID { get; set; }
        public virtual string DocumentTypeName { get; set; }
        public virtual string WhetherSubDocument { get; set; }
        public virtual string WhetherActive { get; set; }

    }
}