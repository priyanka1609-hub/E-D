﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;


namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsNationality : Repositry<ApplicationDetailsNationality>
    {
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]	
        [StringLength(50,MinimumLength=2, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Enter place of Birth")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter Valid Value")]
        public virtual string PlaceOfBirth { get; set; }
        [DataType(DataType.Date)]
        [RegularExpression(@"^(0[1-9]|[12][0-9]|3[01])[-/.](0[1-9]|1[012])[-/.](19|20)\d\d$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        [Required(ErrorMessage = "Enter Date Of Birth")]
        public virtual string DateOfBirth { get; set; }
        [Required(ErrorMessage = "Enter Period of Residence")]
        [StringLength(3, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Year")]
        [Range(0, 99, ErrorMessage = "Enter Valid Year")]
        public virtual string YearOfLiving { get; set; }
        [Required(ErrorMessage = "Enter Period of Residence")]
        [StringLength(2, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Month")]
        [Range(0, 11, ErrorMessage = "Enter Valid Month")]
        public virtual string MonthOfLiving { get; set; }
        [StringLength(50,MinimumLength=2, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Enter Birth Place of Mother")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter valid Birth place of Mother")]
        public virtual string BirthPlaceOfMother { get; set; }
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Enter Birth Place of Father")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter valid Birth place of Father")]
        public virtual string BirthPlaceOfFather { get; set; }
        [Required(ErrorMessage = "select one Option")]
        public virtual string WhetherDisplacedPerson { get; set; }
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("WhetherDisplacedPerson", "true", ErrorMessage = "Displace Date Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DisplaceDate { get; set; }
        [RequiredIf("WhetherDisplacedPerson", "true", ErrorMessage = "Displaced From Required")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string DisplacedFrom { get; set; }
        [Required(ErrorMessage = "select one Option")]
        public virtual string WhetherMigrated { get; set; }
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("WhetherMigrated", "true", ErrorMessage = "Date of Migration Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DateofMigration { get; set; }
        [RequiredIf("WhetherMigrated", "true", ErrorMessage = " Migrated from Required")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string MigrationFrom { get; set; }

        [Required(ErrorMessage = "select one Option")]
        public virtual string WhetherRefugee { get; set; }
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RequiredIf("WhetherRefugee", "true", ErrorMessage = "Refugee Registartion Certificate No Required")]
        [RegularExpression(@"^([A-Za-z0-9])+(?:(([A-Za-z0-9\s]))|(\.[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter valid Name")]
        public virtual string RefugeeRegistartionCertificateNo { get; set; }
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("WhetherRefugee", "true", ErrorMessage = "Refugee Registartion Certificate Date Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string RefugeeRegistartionCertificateDate { get; set; }
        [StringLength(50), Required(ErrorMessage = "select one Option")]
        public virtual string MigrationFromIndiaToPakistan { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("MigrationFromIndiaToPakistan", "true", ErrorMessage = "Migration Date Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string MigrationDate { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("MigrationFromIndiaToPakistan", "true", ErrorMessage = "Return Date Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string Returndate { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100,MinimumLength=2, ErrorMessage = "Enter Valid Value")]
        [RequiredIf("MigrationFromIndiaToPakistan", "true", ErrorMessage = "Returned Authority Required")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        public virtual string ReturnedAuthority { get; set; }
        [StringLength(150), Required(ErrorMessage = "Enter Purpose for Certificate")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid purpose")]
        public virtual string PurposeForCertificate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Officer Name")]
        public virtual string GazettedOfficerName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string OfficerGender { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid Designation")]
        public virtual string Designation { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid Department Name")]
        public virtual string DepartmentName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(11, MinimumLength = 11, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[0-9]{11}$", ErrorMessage = "Enter Valid Landline No.")]
        public virtual string OfficerTelephoneNo { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string OfficerMobileNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string OfficerAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string OfficerStateId { get; set; }
        public virtual string OfficerStateName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string OfficerDistrictCode { get; set; }
        public virtual string OfficerDistrictName { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string LastActionDate { get; set; }
        public virtual string ApplicationStatusId { get; set; }

        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList StateList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select StateId,StateName from StateMaster order by StateName");
                List<StateMaster> StateList = StateMaster.List<StateMaster>(cmd);
                return new SelectList(StateList, "StateId", "StateName");
            }
            set { }
        }
        public SelectList DistrictList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select districtcode,districtname from dbo.districtmaster where deptcode=@deptcode and stateid=@state order by districtname");
                cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                cmd.Parameters.AddWithValue("@state", (int)State.Delhi);
                List<DistrictMaster> DistrictList = DistrictMaster.List<DistrictMaster>(cmd);
                return new SelectList(DistrictList, "DistrictCode", "DistrictName");
            }
            set { }
        }
    }
}