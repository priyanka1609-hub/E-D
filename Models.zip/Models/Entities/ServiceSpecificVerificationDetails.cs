﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Web.Mvc;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class ServiceSpecificVerificationDetails
    {
        [StringLength(4, MinimumLength = 4)]
        public virtual string ServiceCode { get; set; }
        public virtual string HeadingId { get; set; }
        public virtual string HeadingName { get; set; }
        public virtual string HeadingValue { get; set; }
        public virtual string ApplicationNo { get; set; }
        public DataTable data { get; set; }
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
    }
}