﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Collections.Generic;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class CRRequestDetails : Repositry<CRRequestDetails>
    {
        public virtual string RequestId { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string ProjectId { get; set; }
        public virtual string ProjectName { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string ProjectUrl { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string DepartmentId { get; set; }
        public virtual string DepartmentName { get; set; }
        //[Required(ErrorMessage = "value Required")]
        public virtual string ServiceCode { get; set; }
        public virtual string ServiceName { get; set; }

        [Required(ErrorMessage = "value Required")]
        public virtual string Nodalofficer { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string ChangeTitle { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string ChangeDetails { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string WhetherFlowAttached { get; set; }
        [StringLength(250, MinimumLength = 2)]
        [RequiredIf("WhetherFlowAttached", "False", ErrorMessage = "Details Required")]
        public virtual string FlowDetails { get; set; }
        [RequiredIf("WhetherFlowAttached", "True", ErrorMessage = "Details Required")]
        public virtual byte[] FlowData { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string WhetherNodalApproved { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [DataType(DataType.Date),Required(ErrorMessage = "value Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string RequestedDate { get; set; }



        public virtual string WhetherComplete { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [DataType(DataType.Date), Required(ErrorMessage = "value Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string CompletionDate { get; set; }

        public virtual string WhetherUATDone { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [DataType(DataType.Date), Required(ErrorMessage = "value Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string UatDate { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string OfficerName { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string OfficerDesignation { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string WhetherDetailsChecked { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string WhetherResultWorking { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string WhetherDeploymentReady { get; set; }
        public virtual string UatRemarks { get; set; }


        public virtual string WhetherReleased { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [DataType(DataType.Date), Required(ErrorMessage = "value Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string ReleaseDate { get; set; }
        public virtual string Remarks { get; set; }

        public virtual string WhetherSigned { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual byte[] SignedData { get; set; }


        public virtual string ProcessId { get; set; }

        public DataTable dt { get; set; }



    }
}