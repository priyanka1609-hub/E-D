﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class AccountTypeMaster : Repositry<AccountTypeMaster>
    {
        public virtual string AccountTypeId { get; set; }
        public virtual string AccountTypeName { get; set; }
        public virtual string WhetherActive { get; set; }
    }
}