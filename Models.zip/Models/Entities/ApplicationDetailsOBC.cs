﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;
namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsOBC : Repositry<ApplicationDetailsOBC>
    {
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CasteId { get; set; }
        public virtual string CasteName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string StateId { get; set; }
        public virtual string StateName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Religion { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherDelhiResident { get; set; }
        [RequiredIf("WhetherDelhiResident", "True", ErrorMessage = "Year Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Year")]
        [Range(0, 99, ErrorMessage = "Enter Valid Year")]
        public virtual string YearOfLiving { get; set; }
        [RequiredIf("WhetherDelhiResident", "True", ErrorMessage = "Month Required")]
        [StringLength(2, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Month")]
        [Range(0, 11, ErrorMessage = "Enter Valid Month")]
        public virtual string MonthOfLiving { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter valid place")]
        public virtual string PlaceOfBirth { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherRelationObc { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        [RequiredIf("WhetherRelationObc", "True", ErrorMessage = "Name Required")]
        public virtual string CertificateHolderName { get; set; }
        [RequiredIf("WhetherRelationObc", "True", ErrorMessage = "Relation Required")]
        public virtual string CertificateHolderRelationId { get; set; }
        [RequiredIf("WhetherRelationObc", "True", ErrorMessage = "Certificate No Required")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z0-9])+(?:(([A-Za-z0-9\s]))|(\.[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter valid Certificate No")]
        public virtual string CertificateNo { get; set; }
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("WhetherRelationObc", "True", ErrorMessage = "Issue Date Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string ObcCertificateIssueDate { get; set; }
        [RequiredIf("WhetherRelationObc", "True", ErrorMessage = "Issuing Authority Required")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string IssuingAuthority { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherAgriculturalLand { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        [RequiredIf("WhetherAgriculturalLand", "True", ErrorMessage = "Name Required")]
        public virtual string UAgrLandOwnerName { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        [RequiredIf("WhetherAgriculturalLand", "True", ErrorMessage = "Address Required")]
        public virtual string UAgrLandAddress { get; set; }
        [RequiredIf("WhetherAgriculturalLand", "True", ErrorMessage = "Area Required")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z0-9])+(?:(([A-Za-z0-9\s]))|(\.[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter valid Area")]
        public virtual string UAgrLandArea { get; set; }
        [RequiredIf("WhetherAgriculturalLand", "True", ErrorMessage = "Area Required")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z0-9])+(?:(([A-Za-z0-9\s]))|(\.[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter valid Land Use")]
        public virtual string UAgrLandUse { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        [RequiredIf("WhetherAgriculturalLand", "True", ErrorMessage = "Land Information Required")]
        public virtual string IAgrLandOwnerName { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        [RequiredIf("WhetherAgriculturalLand", "True", ErrorMessage = "Address Required")]
        public virtual string IAgrLandAddress { get; set; }
        [RequiredIf("WhetherAgriculturalLand", "True", ErrorMessage = "Area Required")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z0-9])+(?:(([A-Za-z0-9\s]))|(\.[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter valid Area")]
        public virtual string IAgrLandArea { get; set; }
        [RequiredIf("WhetherAgriculturalLand", "True", ErrorMessage = "Land Information Required")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z0-9])+(?:(([A-Za-z0-9\s]))|(\.[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter valid Land Use")]
        public virtual string IAgrLandUse { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherVacantLand { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        [RequiredIf("WhetherVacantLand", "True", ErrorMessage = "Name Required")]
        public virtual string VacantLandOwnerName { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        [RequiredIf("WhetherVacantLand", "True", ErrorMessage = "Address Required")]
        public virtual string VacantLandAddress { get; set; }
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RequiredIf("WhetherVacantLand", "True", ErrorMessage = "Area Required")]
        [RegularExpression(@"^([A-Za-z0-9])+(?:(([A-Za-z0-9\s]))|(\.[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter valid Area")]
        public virtual string VacantLandArea { get; set; }
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RequiredIf("WhetherVacantLand", "True", ErrorMessage = "Land Information Required")]
        [RegularExpression(@"^([A-Za-z0-9])+(?:(([A-Za-z0-9\s]))|(\.[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter valid Land Use")]
        public virtual string VacantLandUse { get; set; }
        [StringLength(10, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^([0-9]{1,7})+(\.[0-9]{1,2})?$", ErrorMessage = "Enter Valid value")]
        public virtual string AnnualFamilyIncomeFromSalary { get; set; }
        [StringLength(10, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^([0-9]{1,7})+(\.[0-9]{1,2})?", ErrorMessage = "Enter Valid value")]
        public virtual string AnnualFamilyIncomeFromAgrLand { get; set; }
        [StringLength(10, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([0-9]{1,7})+(\.[0-9]{1,2})?", ErrorMessage = "Enter Valid value")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string AnnualFamilyIncomeFromProperty { get; set; }
        [StringLength(10, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([0-9]{1,7})+(\.[0-9]{1,2})?", ErrorMessage = "Enter Valid value")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string AnnualFamilyIncomeFromOther { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherTaxPayer { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherWealthTaxAct { get; set; }
        [RequiredIf("WhetherRelationObc", "True", ErrorMessage = "Address Required")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s\(\)]+)|(\,[A-Za-z0-9\s\(\)]+)|(\/[A-Za-z0-9\s\(\)]+)|(\([A-Za-z0-9\s]+)|(\)[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string RAddress { get; set; }
        [RequiredIf("WhetherRelationObc", "True", ErrorMessage = "State Required")]
        public virtual string RStateId { get; set; }
        public virtual string RStateName { get; set; }
        [RequiredIf("WhetherRelationObc", "True", ErrorMessage = "State Required")]
        public virtual string RDesignation { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string LastActionDate { get; set; }
        public virtual string WhetherCentreCaste { get; set; }
        public virtual string ApplicationStatusId { get; set; }


        public virtual bool WhetherOld { get; set; }
        [RequiredIf("WhetherDelhiResident", "False", ErrorMessage = "Value Required")]
        public virtual string Whethermigrated { get; set; }
        [RequiredIf("Whethermigrated", "True", ErrorMessage = "Value Required")]
        public virtual string OriginstateId { get; set; }
        public virtual string OriginstateName { get; set; }
        [RequiredIf("Whethermigrated", "True", ErrorMessage = "Value Required")]
        public virtual string OrigindistrictId { get; set; }
        public virtual string OrigindistrictName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Conspreindia { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Consvicepreindia { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Consjudgecourt { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Consgeneralindia { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Consholdconspost { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Scbothclassioffcr { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Sceitherclassioffcr { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Scbothclassioffcrdies { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Scbothclassioffcrbothdies { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Scbothclassioffcreitherdies { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Scbothclassiioffcr { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Schusbandclassiioffcr { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Scclassiioffcreitherdies { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Scclassiioffcrwifedies { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Scclassiioffcrhusbanddies { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Armdforceboth { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Pconlyirrigatedland { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Pcbothlands { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Pcintaxact { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Pcincomeact { get; set; }
        public virtual string Whethercreamylayer { get; set; }



        public OBCIncomeDetails OBCIncomeDetails { get; set; }
        [CustomProperty]
        public SelectList OccupationMasterList
        {
            get
            {
                List<OccupationMaster> OccupationMasterList = OccupationMaster.List<OccupationMaster>(new Npgsql.NpgsqlCommand("select OccupationId,OccupationType from dbo.OccupationMaster order by OccupationType"));
                return new SelectList(OccupationMasterList, "OccupationId", "OccupationType");
            }
            set { }
        }
        public SelectList OBCServiceTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.OBCIncomeDetails);
                List<SelectValueMaster> OBCServiceTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(OBCServiceTypeList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList StateMasterList
        {
            get
            {
                List<StateMaster> StateMasterList = StateMaster.List<StateMaster>(new Npgsql.NpgsqlCommand("select StateId,StateName from dbo.StateMaster order by StateName"));
                return new SelectList(StateMasterList, "StateId", "StateName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList CasteMasterList
        {
            get
            {
                List<CasteMaster> CasteMasterList = CasteMaster.List<CasteMaster>(new Npgsql.NpgsqlCommand("select CasteId,CasteName from dbo.CasteMaster"));
                return new SelectList(CasteMasterList, "CasteId", "CasteName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList DistrictMasterList
        {
            get
            {
                List<DistrictMaster> DistrictMasterList = DistrictMaster.List<DistrictMaster>(new Npgsql.NpgsqlCommand("select DistrictCode,DistrictName from dbo.DistrictMaster"));
                return new SelectList(DistrictMasterList, "DistrictCode", "DistrictName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList RelationMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as relationid,s1.valuename as relationname from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.PaternalRelationship);
                List<RelationMaster> RelationMasterList = RelationMaster.List<RelationMaster>(Cmd);
                return new SelectList(RelationMasterList, "relationid", "relationname");
            }
            set { }
        }
        [CustomProperty]
        public SelectList ReligionList
        {
            get
            {
                List<ReligionMaster> ReligionList = ReligionMaster.List<ReligionMaster>(new Npgsql.NpgsqlCommand("select ReligionId,ReligionName from dbo.ReligionMaster order by ReligionName"));
                return new SelectList(ReligionList, "ReligionId", "ReligionName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
    }
}