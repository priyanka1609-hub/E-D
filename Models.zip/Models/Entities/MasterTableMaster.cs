﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class MasterTableMaster : Repositry<ApplicationMarriageDetails>
    {
        public virtual string TableId { get; set; }
        public virtual string TableName { get; set; }
        public virtual string TableHeading { get; set; }
        public virtual string SchemaName { get; set; }
    }
}