﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;

namespace Edistrict.Models.Entities
{
    public class DigitalCardTypeMaster :  Repositry<DigitalCardTypeMaster>
    {
        public virtual string Cardtypeid { get; set; }
        public virtual string CardTypeName { get; set; }
        public virtual string CardPath { get; set; }
        public virtual string SessionSerialNo { get; set; }
        public virtual string JarAccountName { get; set; }
        public virtual string JarAccountLogin { get; set; }
        public virtual string JarRecordName { get; set; }
        public virtual string JarRecordLogin { get; set; }
        public virtual string JarRecordBulk { get; set; }
        public virtual string JarDocumentName { get; set; }
        public virtual string JarDocumentLogin { get; set; }
        public virtual string JarDocumentBulk { get; set; }
        public virtual string ExeFilePath { get; set; }
        public virtual string WhetherActive { get; set; }

        [CustomProperty]
        public virtual string[] JarDocumentBulkArray { get; set; }
        [CustomProperty]
        public virtual string UserName { get; set; }
    }
}