﻿using System;
using System.Web;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.Entities
{
    public class UserMaster : Repositry<UserMaster>
    {
        public virtual System.Nullable<int> UID { get; set; }
        [Required(ErrorMessage = "User Id Required")]
        [RegularExpression(@"^\d*[a-zA-Z][a-zA-Z0-9]*$", ErrorMessage = "Enter valid value")]
        [StringLength(15, MinimumLength = 4, ErrorMessage = "Enter Valid User-Id")]
        public virtual string UserId { get; set; }
        [Required(ErrorMessage = "Password Required")]
        [StringLength(250, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 8)]
        [DataType(DataType.Password)]
        [Display(Name = "password")]
        public virtual string Password { get; set; }
        [Required(ErrorMessage = "Password Required")]
        [StringLength(250, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 8)]
        [DataType(DataType.Password)]
        [Display(Name = "password")]
        public virtual string TransactionPassword { get; set; }
        [Required(ErrorMessage = "User Name Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(50), RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        public virtual string UserName { get; set; }
        public virtual string Permission { get; set; }
        public virtual string Pcode { get; set; }
        [StringLength(50), Required(ErrorMessage = "District Required")]
        public virtual string DistrictCode { get; set; }
        public virtual string DistrictName { get; set; }
        [Required(ErrorMessage = "Designation Required")]
        public virtual string Designation { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [StringLength(50), Required(ErrorMessage = "Date of Birth Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DateOfBirth { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter 10 Digit mobile No."), Required(ErrorMessage = "Contact No Required")]
        [RegularExpression(@"^[7-9][0-9]{9}$", ErrorMessage = "Enter Valid Contact No.")]
        public virtual string ContactNo { get; set; }
        [RegularExpression(@"[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Enter In InValid Email")]
        [Required(ErrorMessage = "Email Id Required")]
        public virtual string EmailId { get; set; }
        [Required(ErrorMessage = "Permanent Address Required")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s\(\)]+)|(\,[A-Za-z0-9\s\(\)]+)|(\/[A-Za-z0-9\s\(\)]+)|(\([A-Za-z0-9\s]+)|(\)[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string PermanentAddress { get; set; }
        [Required(ErrorMessage = "Present Address Required")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s\(\)]+)|(\,[A-Za-z0-9\s\(\)]+)|(\/[A-Za-z0-9\s\(\)]+)|(\([A-Za-z0-9\s]+)|(\)[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string PresentAddress { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [Required(ErrorMessage = "Date of joining Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DateOfJoining { get; set; }
        public virtual string DateOfRelieving { get; set; }
        public virtual string DeptCode { get; set; }
        public virtual string CreateDate { get; set; }
        public virtual string UserIpAddress { get; set; }
        public virtual string LastUpdateDate { get; set; }
        public virtual string WhetherActive { get; set; }
        public virtual string WhetherPasswordChange { get; set; }
        
        

        public virtual bool WhetherDisableDSMapping { get; set; }
        public virtual bool WhetherUserDSMapped { get; set; }
        public virtual bool IsValidityExpired { get; set; }
        public virtual string DistCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AuthorizationId { get; set; }
        public virtual string AuthorizationName { get; set; }
        public virtual string SubDivisionCode { get; set; } 
        [CustomProperty]
        [Required(ErrorMessage = "Sub Division Required")]
        public virtual string SubDivCode { get; set; }
        [CustomProperty]
        public virtual string ServiceCode { get; set; }
        //[ValidateDateRange(minDate = null, maxDate = null)]
        [Required(ErrorMessage = "Date FROM Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DateFrom { get; set; }
        //[ValidateDateRange(minDate = null, maxDate = null)]
        [Required(ErrorMessage = "Date TO Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DateTo { get; set; }
        public virtual string WhetherDistRequired { get; set; }
        public virtual string WhetherSubdivRequired { get; set; }
        [Required(ErrorMessage = "Gender Required")]
        public virtual string Gender { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SigningTypeId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AuthenticationTypeId { get; set; }
        [Required(ErrorMessage = "Value Required.")]
        [RegularExpression(@"^[0-9]{0,3}$", ErrorMessage = "Valid value required.")]
        public virtual string UserIpSeg1 { get; set; }
        [Required(ErrorMessage = "Value Required.")]
        [RegularExpression(@"^[0-9]{0,3}$", ErrorMessage = "Valid value required.")]
        public virtual string UserIpSeg2 { get; set; }
        [Required(ErrorMessage = "Value Required.")]
        [RegularExpression(@"^[0-9]{0,3}$", ErrorMessage = "Valid value required.")]
        public virtual string UserIpSeg3 { get; set; }
        [Required(ErrorMessage = "Value Required.")]
        [RegularExpression(@"^[0-9]{0,3}$", ErrorMessage = "Valid value required.")]
        public virtual string UserIpSeg4 { get; set; }
        [Required(ErrorMessage = "Time FROM Required.")]
        public virtual string TimeFrom { get; set; }
        [Required(ErrorMessage = "Time TO Required.")]
        public virtual string TimeTo { get; set; }
        [Required(ErrorMessage = "AadhaarNo Required")]
        public virtual string AadhaarNo { get; set; }
        public virtual bool RememberMe { get; set; }
        public virtual string OTP { get; set; }
        public virtual string LastLoginAttempt { get; set; }
        public virtual string WhetherLogout { get; set; }
        public virtual string MaxLoginAttempt { get; set; }
        public virtual string Cardtypeid { get; set; }
        public virtual string DocId { get; set; }
        public virtual string WhetherDetailUpdate { get; set; }
        public virtual string UserPhoto { get; set; }
        public virtual string WhetherDocumentData { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherPoliceVerDone { get; set; }
    }
}