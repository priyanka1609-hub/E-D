﻿using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.Entities
{
    public class SolvencyShareholdingDetails : Repositry<SolvencyShareholdingDetails>
    {
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }

        public virtual string DirectorName { get; set; }

        public virtual string AppointmentDate { get; set; }

        public virtual string NoOfShares { get; set; }

        public virtual string ShareValue { get; set; }

        public virtual string PANNo { get; set; }

        public virtual string Counter { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string LastActionDate { get; set; }
    }
}