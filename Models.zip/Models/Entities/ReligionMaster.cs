﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class ReligionMaster : Repositry<ReligionMaster>
    {
        public virtual string ReligionId { get; set; }
        public virtual string ReligionName { get; set; }
    }
}