﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class ApplicationPaymentDescription : Repositry<ApplicationPaymentDescription>
    {
        public virtual string DescriptionId { get; set; }
        public virtual string PaymentId { get; set; }
        public virtual string PaymentTypeId { get; set; }
        public virtual string PaymentAmount { get; set; }
        public virtual string ActionDate { get; set; }
        public virtual string ActionUserId { get; set; }
        public virtual string ActionIpAddress { get; set; }
    }
}