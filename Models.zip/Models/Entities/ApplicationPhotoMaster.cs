﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class ApplicationPhotoMaster : Repositry<ApplicationDetails>
    {
        [ScaffoldColumn(false)]
        public virtual System.Nullable<int> PhotoId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        public virtual string PhotoData { get; set; }
        public virtual string RelatedId { get; set; }
        public virtual bool WhetherActive { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string LastActionDate { get; set; }
    }
}