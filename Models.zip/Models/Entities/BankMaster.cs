﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.Entities
{
    public class BankMaster : Repositry<BankMaster>
    {
        public virtual string BankCode { get; set; }
        public virtual string HeBankCode { get; set; }
        public virtual string HeBankName { get; set; }
        public virtual string BankName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string BankId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankEmail { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankContactNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BaseInterestRate { get; set; }
    }
}