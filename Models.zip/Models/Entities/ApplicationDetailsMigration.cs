﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;
using System.Data;
using Edistrict.Models.CustomClass;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsMigration : Repositry<ApplicationDetailsMigration>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ReliefTypeId { get; set; }
        public virtual string ReliefTypeName { get; set; }
        [Required(ErrorMessage = "Enter Period of Residence")]
        [StringLength(3, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression("^[1-9][0-9]*$", ErrorMessage = "Enter Valid Year")]
        [Range(0, 99, ErrorMessage = "Enter Valid Year")]
        public virtual string YearOfLiving { get; set; }
        [Required(ErrorMessage = "Enter Period of Residence")]
        [StringLength(2, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression("^[1-9][0-9]*$", ErrorMessage = "Enter Valid Month")]
        [Range(0, 11, ErrorMessage = "Enter Valid Month")]
        public virtual string MonthOfLiving { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [DataType(DataType.Date), Required(ErrorMessage = "Date of Migration Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DateofMigration { get; set; }
        [StringLength(18, MinimumLength = 2, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Enter Account No")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Account No")]
        public virtual string AccountNo { get; set; }
        [Required(ErrorMessage = "MICR Code Required")]
        [StringLength(9, ErrorMessage = "MICR Code must be of 9 digits. ", MinimumLength = 9)]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid MICRCode")]
        public virtual string MICRCode { get; set; }
        [StringLength(50), Required(ErrorMessage = "Select Bank Name")]
        public virtual string BankCode { get; set; }
        public virtual string BankName { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Enter Branch Address")]
        public virtual string BranchAddress { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(12, MinimumLength = 12), Required(ErrorMessage = "Enter User Reference Number")]
        public virtual string UserReferenceNo { get; set; }
        public virtual string MMCounter { get; set; }
        public virtual string StatusId { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual MigrationMembersDetails MigrationMembersDetails { get; set; }
        public virtual ApplicationDetails ApplicationDetails { get; set; }
        public virtual ApplicantDetails ApplicantDetails { get; set; }
        public DataTable dt { get; set; }
        [CustomProperty]
        public SelectList ReliefTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.ReliefType);
                List<ServiceTypeMaster> ReliefTypeList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ReliefTypeList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MemberRelationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.MigratedMemberRelationship);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList DocumentAvailableAtMigration
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select DocumentId,DocumentName from dbo.DocumentMaster where DocumentId in (@DrivingLicense,@VoterID,@PANCard,@Passport,@RationCard,@AadhaarCard,@GovtDoc)");
                Cmd.Parameters.AddWithValue("@DrivingLicense", (int)DocumentId.DrivingLicense);
                Cmd.Parameters.AddWithValue("@VoterID", (int)DocumentId.VoterID);
                Cmd.Parameters.AddWithValue("@PANCard", (int)DocumentId.PANCard);
                Cmd.Parameters.AddWithValue("@Passport", (int)DocumentId.Passport);
                Cmd.Parameters.AddWithValue("@RationCard", (int)DocumentId.RationCard);
                Cmd.Parameters.AddWithValue("@AadhaarCard", (int)DocumentId.AadhaarCard);
                Cmd.Parameters.AddWithValue("@GovtDoc", (int)DocumentId.GovtRecDoc);
                List<DocumentMaster> DocumentMasterList = DocumentMaster.List<DocumentMaster>(Cmd);
                return new SelectList(DocumentMasterList, "DocumentId", "DocumentName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList RelationMasterList
        {
            get
            {
                List<RelationMaster> RelationMasterList = RelationMaster.List<RelationMaster>(new Npgsql.NpgsqlCommand("select relationid,relationname from dbo.RelationMaster"));
                return new SelectList(RelationMasterList, "RelationId", "RelationName");
            }
            set { }
        }

    }
}
