﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationOldAgeDetails : Repositry<ApplicationOldAgeDetails>
    {
        public virtual string BankDetailsId { get; set; }
        public virtual string FirstWitnessType { get; set; }
        public virtual string SecondWitnessType { get; set; }
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [StringLength(18, MinimumLength = 2, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Enter Account No")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Account No")]
        public virtual string AccountNo { get; set; }
        [RequiredIf("IFSCCode", null, ErrorMessage = "MICR Code Required")]
        [StringLength(9, ErrorMessage = "MICR Code must be of 9 digits. ", MinimumLength = 9)]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid MICRCode")]
        public virtual string MICRCode { get; set; }
        [RequiredIf("MICRCode", null, ErrorMessage = "IFSC Code Required")]
        [StringLength(11, ErrorMessage = "IFSC Code must be of 11 digits. ", MinimumLength = 11)]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        [Required(ErrorMessage = "Select any one")]
        public virtual string MICRorIFSC { get; set; }
        [StringLength(50), Required(ErrorMessage = "Select Bank Name")]
        public virtual string BankCode { get; set; }
        [Required(ErrorMessage = "Enter Branch Address")]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "Enter Valid Value")]
        public virtual string BankName { get; set; }
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Enter Branch Address")]
        public virtual string BranchAddress { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [StringLength(100), Required(ErrorMessage = "Select Constituency Name")]
        public virtual string ConstituencyID { get; set; }
        public virtual string ConstituencyName { get; set; }
        [StringLength(100), Required(ErrorMessage = "Select Category Name")]
        public virtual string CategoryId { get; set; }
        public virtual string CategoryName { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string LastActionDate { get; set; }
        [StringLength(50), Required(ErrorMessage = "Select Marital Status")]
        public virtual string MaritalStatusId { get; set; }
        public virtual string MaritalStatusName { get; set; }
        [StringLength(50), Required(ErrorMessage = "Select Occupation Type")]
        public virtual string OccupationId { get; set; }
        public virtual string OccupationType { get; set; }
        [StringLength(50), Required(ErrorMessage = "Select Any One")]
        public virtual string WhetherStayPeriodValid { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("WhetherStayPeriodValid", "No", ErrorMessage = "Witness Name Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string FirstWitnessName { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("WhetherStayPeriodValid", "No", ErrorMessage = "Witness Name Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string SecondWitnessName { get; set; }
        [RequiredIf("WhetherStayPeriodValid", "No", ErrorMessage = "Witness Type Required")]
        public virtual string FirstWitnessTypeId { get; set; }
        [RequiredIf("WhetherStayPeriodValid", "No", ErrorMessage = "Witness Type Required")]
        public virtual string SecondWitnessTypeId { get; set; }
        public virtual string WitnessTypeId { get; set; }
        public virtual string WitnessTypeName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherDrawMCDSanction { get; set; }
        public virtual string WhetherDrawSanction { get; set; }
        [Range(0, 100000, ErrorMessage = "Family Annual Income exceeds maximum limit")]
        [StringLength(50), Required(ErrorMessage = "Enter Family Annual Income")]
        public virtual string FamilyAnnualIncome { get; set; }
        [StringLength(50), Required(ErrorMessage = "Enter File No")]
        public virtual string FileNo { get; set; }
        [StringLength(50), Required(ErrorMessage = "Select Account Type")]
        public virtual string AccountTypeId { get; set; }
        public virtual string AccountTypeName { get; set; }
        [StringLength(50), Required(ErrorMessage = "Select Ration card Type")]
        public virtual string RationCardTypeId { get; set; }
        public virtual string RationCardTypeName { get; set; }
        [StringLength(50), Required(ErrorMessage = "Ration Card No required")]
        public virtual string RationCardNo { get; set; }
        [RequiredIf("GazettedOfficerRecommendation", "Yes", ErrorMessage = " Select Any One")]
        public virtual string GazettedOfficer { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("GazettedOfficerRecommendation", "Yes", ErrorMessage = " Name Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string GazettedOfficerName { get; set; }
        [StringLength(50), Required(ErrorMessage = "whether MLA/MP/Gazetted Officer Recommendation")]
        public virtual string GazettedOfficerRecommendation { get; set; }
        [StringLength(50), Required(ErrorMessage = "Remarks")]
        public virtual string GazettedOfficerRemarks { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual int TableWidth { get; set; }
        public virtual string DistrictName { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("FirstWitnessTypeId", "5", ErrorMessage = "Witness Name Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string FirstWitnessName1 { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("SecondWitnessTypeId", "5", ErrorMessage = "Witness Name Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string SecondWitnessName1 { get; set; }

        [CustomProperty]
        public SelectList CategoryMasterList
        {
            get
            {
                List<CategoryMaster> CategoryMasterList = CategoryMaster.List<CategoryMaster>(new Npgsql.NpgsqlCommand("select CategoryId,CategoryName from dbo.CategoryMaster"));
                return new SelectList(CategoryMasterList, "CategoryId", "CategoryName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList BankMasterList
        {
            get
            {
                List<BankMaster> BankMasterList = BankMaster.List<BankMaster>(new Npgsql.NpgsqlCommand("select BankCode,BankName from dbo.BankMaster"));
                return new SelectList(BankMasterList, "BankCode", "BankName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList AssemblyConstituencyMasterList
        {
            get
            {
                List<AssemblyConstituencyMaster> AssemblyConstituencyMasterList = AssemblyConstituencyMaster.List<AssemblyConstituencyMaster>(new Npgsql.NpgsqlCommand("select ConstituencyID,ConstituencyName from dbo.AssemblyConstituencyMaster"));
                return new SelectList(AssemblyConstituencyMasterList, "ConstituencyID", "ConstituencyName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MaritalStatusMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.MaritalStatus);
                List<ServiceTypeMaster> MaritalStatusMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(MaritalStatusMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList OccupationMasterList
        {
            get
            {
                List<OccupationMaster> OccupationMasterList = OccupationMaster.List<OccupationMaster>(new Npgsql.NpgsqlCommand("select OccupationId,OccupationType from dbo.OccupationMaster"));
                return new SelectList(OccupationMasterList, "OccupationId", "OccupationType");
            }
            set { }
        }
        [CustomProperty]
        public SelectList WitnessTypeMasterList
        {
            get
            {
                List<WitnessTypeMaster> WitnessTypeMasterList = WitnessTypeMaster.List<WitnessTypeMaster>(new Npgsql.NpgsqlCommand("select WitnessTypeId,WitnessTypeName from dbo.WitnessTypeMaster"));
                return new SelectList(WitnessTypeMasterList, "WitnessTypeId", "WitnessTypeName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList RationCardDetailsMasterList
        {
            get
            {
                List<RationCardDetailsMaster> RationCardDetailsMasterList = RationCardDetailsMaster.List<RationCardDetailsMaster>(new Npgsql.NpgsqlCommand("select RationCardTypeId,RationCardTypeName from dbo.RationCardDetailsMaster"));
                return new SelectList(RationCardDetailsMasterList, "RationCardTypeId", "RationCardTypeName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList AccountTypeMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.AccountType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
    }
}