﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;

namespace Edistrict.Models.Entities
{
    public class SurvivingMembersDetails : Repositry<SurvivingMembersDetails>
    {
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string MemberId { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        public virtual string NameOfMember { get; set; }
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid value")]
        public virtual string Age { get; set; }
        public virtual string IdentityDocumentId { get; set; }
        public virtual string IdentityDocumentNo { get; set; }
        public virtual string IdentityDocumentData { get; set; }
        public virtual string RelationId { get; set; }
        public virtual string Photo { get; set; }
    }
}