﻿using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using System.Collections.Generic;


namespace Edistrict.Models.Entities
{
    public class VerifierVerificationReport : Repositry<VerifierVerificationReport>
    {
        public virtual string ApplicationNo { get; set; }
        public virtual string EnclosureId { get; set; }
        [Required(ErrorMessage = "Select Result")]
        public virtual string SelectValueId { get; set; }
        [Required(ErrorMessage = "Enter Remarks")]
        [StringLength(250, ErrorMessage = "Remarks must be at least 2 characters long.", MinimumLength = 2)]
        public virtual string Remarks { get; set; }
        [CustomProperty]
        public virtual string RowNumber { get; set; }
        [CustomProperty]
        public virtual string DocumentName { get; set; }
        [CustomProperty]
        public virtual string DocumentTypeName { get; set; }
        [CustomProperty]
        public virtual string SelectTypeId { get; set; }
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
    }
}