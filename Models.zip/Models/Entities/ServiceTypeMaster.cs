﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class ServiceTypeMaster : Repositry<ServiceTypeMaster>
    {
        public virtual string ValueId { get; set; }
        public virtual string ValueName { get; set; }
       
    }
}