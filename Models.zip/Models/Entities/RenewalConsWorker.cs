﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Web;
using System.Web.Mvc;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.CustomClass;
using Edistrict.Models.Entities;
using Edistrict.Models.ApplicationService;
using System.Data.SqlClient;
using Npgsql;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class RenewalConsWorker : Repositry<RenewalConsWorker>
    {


        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicationNo { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string RegistrationNo { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string RegistrationDate { get; set; }


        [Required(ErrorMessage = "Value Required")]
        public virtual string LastSubscriptionPaid { get; set; }


        [Required(ErrorMessage = "Value Required")]
        public virtual string Renewaldate { get; set; }



        [Required(ErrorMessage = "Value Required")]
        public virtual string MembershipPeriod { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string LateFees { get; set; }



        public virtual string whetherSameBankDetails { get; set; }

        public virtual string CCounter { get; set; }
        public virtual string Rateofsub { get; set; }





        public virtual string WCounter1 { get; set; }
        public virtual string WCounter2 { get; set; }
        public virtual string WCounter3 { get; set; }
        public virtual string WCounter4 { get; set; }
        public virtual string ApplicationStatusId { get; set; }

        public DataTable dt1 { get; set; }
        public DataTable dt2 { get; set; }
        public DataTable dt3 { get; set; }
        public DataTable dt4 { get; set; }
        public DataSet ds { get; set; }




        public virtual string whetherexist { get; set; }

        public virtual string DelayReasons { get; set; }//changes1502




        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountHolderName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountNo { get; set; }
        public virtual string BankName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankCode { get; set; }
        public virtual string BankBranchName { get; set; }
        public virtual string Branchaddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MICRCode { get; set; }



        [Required(ErrorMessage = "Value Required")]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList SCSTOBCList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as CasteId,s1.valuename as CasteName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.ConWorkerCategoryList);
                List<CasteMaster> SCSTList = CasteMaster.List<CasteMaster>(Cmd);
                return new SelectList(SCSTList, "CasteId", "CasteName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MaritalStatusMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.MaritalStatus);
                List<ServiceTypeMaster> MaritalStatusMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(MaritalStatusMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MemberRelationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select relationid as Valueid,relationname as Valuename from relationmaster  order by 1");
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList ConsWorkerCertiAuthority
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.ConsCertifyingAuthority);
                List<ServiceTypeMaster> MaritalStatusMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(MaritalStatusMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        public SelectList Depositlist
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select paymentmodeid as valueid,paymentmode as valuename from dbo.paymentmodemaster");
                List<ServiceTypeMaster> Depositlist = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(Depositlist, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList PLocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.whetheractive=@whetheractive and lm.whetheractive=@whetheractive and dm.stateid=@stateid  order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept016);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                List<LocalityMaster> PLocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(PLocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
    }
}
