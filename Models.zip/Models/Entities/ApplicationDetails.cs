﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetails : Repositry<ApplicationDetails>
    {
        [ScaffoldColumn(false)]
        public virtual System.Nullable<int> ApplicationId { get; set; }
        [RequiredIf("WhetherAlreadyRegistered", "Y", ErrorMessage = "Registration Id Required")]
        public virtual System.Nullable<int> RegistrationId { get; set; }
        [RequiredIf("WhetherHusbandAlreadyRegistered", "Y", ErrorMessage = "Registration Id Required")]
        public virtual System.Nullable<int> HRegistrationId { get; set; }
        [RequiredIf("WhetherWifeAlreadyRegistered", "Y", ErrorMessage = "Registration Id Required")]
        public virtual System.Nullable<int> WRegistrationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(4, MinimumLength = 4)]
        public virtual string ServiceCode { get; set; }
        [StringLength(1, MinimumLength = 1)]
        public virtual string ApplicationSourceId { get; set; }
        [StringLength(1, MinimumLength = 1)]
        public virtual string ApplicationRelatedId { get; set; }
        
        [Required(ErrorMessage = "{0} Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]	
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string ApplicantName { get; set; }
        [StringLength(1), Required(ErrorMessage = "Gender Required")]
        public virtual string ApplicantGender { get; set; }
        [StringLength(12, MinimumLength = 12, ErrorMessage = "Enter Valid AADHAAR")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid AADHAAR")]
        [RequiredIf("WhetherAadhaarAvailable", "Y", ErrorMessage = "AadhaarNo. Required")]
        public virtual string ApplicantAadhaarNo { get; set; }
        [StringLength(12, MinimumLength = 12, ErrorMessage = "Enter Valid AADHAAR")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid AADHAAR")]
        [RequiredIf("WhetherHusbandAadhaarAvailable", "Y", ErrorMessage = "AadhaarNo. Required")]
        public virtual string ApplicantHusbandAadhaarNo { get; set; }
        [StringLength(12, MinimumLength = 12, ErrorMessage = "Enter Valid AADHAAR")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid AADHAAR")]
        [RequiredIf("WhetherWifeAadhaarAvailable", "Y", ErrorMessage = "AadhaarNo. Required")]
        public virtual string ApplicantWifeAadhaarNo { get; set; }
        [StringLength(14, MinimumLength = 14, ErrorMessage = "Enter Valid EnrolmentNo.")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid EnrolmentNo.")]
        public virtual string ApplicantEnrolmentNo { get; set; }
        [RequiredIf("WhetherAadhaarAvailable", "N", ErrorMessage = "Document No Required")]
        [StringLength(25, MinimumLength = 2, ErrorMessage = "Enter Valid DocumentNo.")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\-[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string DocumentNo { get; set; }
        [RequiredIf("WhetherHusbandAadhaarAvailable", "N", ErrorMessage = "Document No Required")]
        [StringLength(25, MinimumLength = 2, ErrorMessage = "Enter Valid DocumentNo.")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\-[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string HDocumentNo { get; set; }
        [RequiredIf("WhetherWifeAadhaarAvailable", "N", ErrorMessage = "Document No Required")]
        [StringLength(25, MinimumLength = 2, ErrorMessage = "Enter Valid DocumentNo.")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\-[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string WDocumentNo { get; set; }
        public virtual string DocNo { get; set; }
        public virtual string ApplicantEmail { get; set; }
        public virtual string DocumentName { get; set; }
        public virtual string HDocumentName { get; set; }
        public virtual string WDocumentName { get; set; }
        [RequiredIf("WhetherAadhaarAvailable", "N", ErrorMessage = "Selection Required")]
        public virtual string DocumentId { get; set; }
        [RequiredIf("WhetherHusbandAadhaarAvailable", "N", ErrorMessage = "Selection Required")]
        public virtual string HDocumentId { get; set; }
        [RequiredIf("WhetherWifeAadhaarAvailable", "N", ErrorMessage = "Selection Required")]
        public virtual string WDocumentId { get; set; }
        [Required(ErrorMessage = "Father Name Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]	
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Father Name")]
        public virtual string ApplicantFatherName { get; set; }
        [Required(ErrorMessage = "Mother Name Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]	
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid  Mother Name")]
        public virtual string ApplicantMotherName { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]	
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Spouse Name")]
        [RequiredIf("ApplicantFatherName", null, ErrorMessage = "Father/Spouse Required")]
        public virtual string ApplicantHusbandName { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string ApplicantMobileNo { get; set; }
        [Required(ErrorMessage = "Address Required")]
        [StringLength(500, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicantPermanentAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherSameAddress { get; set; }

        [RequiredIf("WhetherAlreadyRegistered", "N", ErrorMessage = "Selection Required")]
        public virtual string WhetherAadhaarAvailable { get; set; }
        [Required(ErrorMessage = "Please Select Option")]
        public virtual string WhetherAlreadyRegistered { get; set; }
        [RequiredIf("WhetherHusbandAlreadyRegistered", "N", ErrorMessage = "Selection Required")]
        public virtual string WhetherHusbandAadhaarAvailable { get; set; }
        [Required(ErrorMessage = "Please Select Option")]
        public virtual string WhetherHusbandAlreadyRegistered { get; set; }
        [RequiredIf("WhetherWifeAlreadyRegistered", "N", ErrorMessage = "Selection Required")]
        public virtual string WhetherWifeAadhaarAvailable { get; set; }
        [Required(ErrorMessage = "Please Select Option")]
        public virtual string WhetherWifeAlreadyRegistered { get; set; }

        [Required(ErrorMessage = "House No Required")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicantHouseNumber { get; set; }
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicantStreetNumber { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicantSubLocality { get; set; }
        [Required(ErrorMessage = "Locality Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicantLocalityId { get; set; }
        public virtual string ApplicantLocalityname { get; set; }
        public virtual string ApplicantSubDivCode { get; set; }
        public virtual string ApplicantSubDivName { get; set; }
        public virtual string StateId { get; set; }
        public virtual string StateName { get; set; }
        public virtual string CountryId { get; set; }
        public virtual string CountryName { get; set; }
        public virtual string ApplicantDistrictCode { get; set; }
        public virtual string ApplicantDistrictName { get; set; }
        [Required(ErrorMessage = "Please Select Reason")]
        public virtual string RejectionReasonCode { get; set; }
        public virtual string ReasonDetail { get; set; }
        public virtual string StatusId { get; set; }
        [Required(ErrorMessage = "Please Select an option")]
        public virtual string WhetherOtherState { get; set; }

        public virtual string ApplicantAddress { get; set; }
        [Required(ErrorMessage = "PinCode required")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[0-9]{6}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string ApplicantPinCode { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [DataType(DataType.Date), Required(ErrorMessage = "DOB Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string ApplicantDob { get; set; }

        public virtual string ApplicantNationality { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicationStatusId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicationSubDivCode { get; set; }
        public virtual string ApplicationSubDivName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicationDistrictCode { get; set; }
        public virtual string WhetherDocumentSeen { get; set; }
        public virtual string SourceId { get; set; }
        public virtual string MacAddress { get; set; }
        public virtual string BiosAddress { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string ApplicantUserId { get; set; }
        public virtual string ApplicationDate { get; set; }
        public virtual string LastActionDate { get; set; }
        public virtual string SolemnizationDate { get; set; }
        public virtual bool WhetherSolemnizationDatePassed { get; set; }
        public virtual string InspectionDate { get; set; }
        [Required(ErrorMessage = "Provisional No required")]
        [StringLength(14, MinimumLength = 14, ErrorMessage = "Enter Valid Value")]
        public virtual string ProvisionalNo { get; set; }

        public virtual string IdNo { get; set; }
        [Required(ErrorMessage = "Please Enter Old Licence No.")]
        [RegularExpression(@"^[A-Za-z0-9\/]{3,14}$", ErrorMessage = "Old License No. should be of 3-14-digit and can contain A-Z,0-9,/ only.")]
        public virtual string PEApplicationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string RegApplicationNo { get; set; }
        public virtual string PaymentOrderNo { get; set; }

        [Required(ErrorMessage = "Please Enter Remarks")]
        [StringLength(250, MinimumLength = 20, ErrorMessage = "Minimum 20 & Maximum 250 character allowed")]
        public virtual string ApplicationRemarks { get; set; }
        [Required(ErrorMessage = "Please Enter Remarks")]
        [StringLength(250, MinimumLength = 20, ErrorMessage = "Minimum 20 & Maximum 250 character allowed")]
        public virtual string ApplicationDARemarks { get; set; }
        [Required(ErrorMessage = "{0} Required")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"[a-zA-Z0-9\/.-\\]*", ErrorMessage = "Enter Valid value")]
        public virtual string ApplicantNameR { get; set; }
        public virtual string SCode { get; set; }
        [CustomProperty]
        public virtual string ServiceName { get; set; }
        public virtual string WhetherAdditionalDocRequired { get; set; }

        [StringLength(12, MinimumLength = 12, ErrorMessage = "Enter Valid Value")]
        public virtual string RationCardNo { get; set; }
        public virtual string NFSDocumentNo { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [DataType(DataType.Date), Required(ErrorMessage = "Approve Date Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string ApproveDate { get; set; }

        [StringLength(10, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([0-9]{1,7})+(\.[0-9]{1,2})?", ErrorMessage = "Enter Valid value")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApproveLoanAmount { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string AddDocumentId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(25, MinimumLength = 2, ErrorMessage = "Enter Valid DocumentNo.")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\-[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string AddDocumentNo { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [StringLength(10, MinimumLength = 5, ErrorMessage = "Enter Valid Value")]
        public virtual string ReferenceNo { get; set; }
        [StringLength(12, MinimumLength = 12, ErrorMessage = "Enter Valid AADHAAR")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid AADHAAR")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string BioApplicantAadhaarNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string OfficeCode { get; set; }
        public virtual string ReferenceDetails { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]	
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string UpdatedApplicantName { get; set; }
        public virtual string UpdatedApplicantGender { get; set; }
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string UpdatedApplicantDob { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Please Check the checkbox")]
        public virtual bool check { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DeptCode { get; set; }

        public virtual string WhetherWorkerIncreased { get; set; }
        public virtual string WhetherApplRenewal { get; set; }
        public virtual string WhetherApplAmend { get; set; }
        public virtual string WhetherChangeRequired { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ReceivedUser { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ReceivedPermission { get; set; }
    }
}