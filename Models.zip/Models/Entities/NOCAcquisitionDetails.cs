﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class NOCAcquisitionDetails : Repositry<NOCAcquisitionDetails>
    {
        public virtual string NId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }

        public virtual string AcquisitionId { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string VillageId { get; set; }
        public virtual string VillageName { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string KhasraNo { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string RectangleNo { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string AcquisitionNo { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string AcquisitionTypeId { get; set; }
        public virtual string AcquisitionType { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string AcquisitionDate { get; set; }
        public virtual string AcquisitionApprovalDate { get; set; }
        [Required(ErrorMessage = "value Required")]
        public virtual string AcquisitionRemarks { get; set; }
        public virtual string Bigha { get; set; }
        public virtual string Biswa { get; set; }
        public virtual string Biswansi { get; set; }
        public virtual bool Min { get; set; }
        public virtual string Whetheractive { get; set; }
        public virtual string ACounter { get; set; }
        public virtual string RType { get; set; }

        public SelectList VillageList
        {
            get
            {
                string Qry = "select villageid,villagename from villagemaster where subdivcode=@ParamSubDivCode order by villagename";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                List<VillageMaster> VillageList = VillageMaster.List<VillageMaster>(Cmd);
                return new SelectList(VillageList, "villageid", "villagename");
            }
            set { }
        }
        public SelectList AcquisitionTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename desc");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.NOCAquisitionType);
                List<SelectValueMaster> AcquisitionTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(AcquisitionTypeList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
    }
}