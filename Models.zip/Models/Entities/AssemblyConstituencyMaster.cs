﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class AssemblyConstituencyMaster : Repositry<AssemblyConstituencyMaster>
    {
        public virtual string ConstituencyID { get; set; }
        public virtual string ConstituencyName { get; set; }
    }
}