﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;
using System.Data;
using System;

namespace Edistrict.Models.Entities
{
    public class HeSkillDevelopmentScheme : Repositry<HeSkillDevelopmentScheme>
    {
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationId { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string UniversityId { get; set; }
        public virtual string UniversityName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string InstitutionId { get; set; }
        public virtual string Institution { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CourseId { get; set; }
        public virtual string CourseType { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [Range(1, 8, ErrorMessage = "Enter Valid Course Period")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Course Period")]
        public virtual string CoursePeriod { get; set; }
        [RequiredIf("CourseId", "1", ErrorMessage = "Relation Required")]
        public virtual string Course { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string QualificationRequired { get; set; }
        public virtual string QualificationRequiredType { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherMatricDelhi { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherSecondaryDelhi { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherDelhiGovtEmp { get; set; }
        [RequiredIf("WhetherDelhiGovtEmp", "True", ErrorMessage = "Relation Required")]
        public virtual string RelationId { get; set; }
        public virtual string RelationName { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        [RequiredIf("WhetherDelhiGovtEmp", "True", ErrorMessage = "Name Required")]
        public virtual string ParentName { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid Department Name")]
        [RequiredIf("WhetherDelhiGovtEmp", "True", ErrorMessage = "Department Name Required")]
        public virtual string DepartmentName { get; set; }
        [RequiredIf("WhetherDelhiGovtEmp", "True", ErrorMessage = "Posted Since Date Required")]
        public virtual string PostedSince { get; set; }


        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherExistingLoan { get; set; }
        [RequiredIf("WhetherExistingLoan", "True", ErrorMessage = "Value Required")]
        public virtual string BankId { get; set; }
        public virtual string BankName { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RequiredIf("WhetherExistingLoan", "True", ErrorMessage = "Value Required")]
        public virtual string BankDetails { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RequiredIf("WhetherExistingLoan", "True", ErrorMessage = "Value Required")]
        public virtual string LoanType { get; set; }
        [StringLength(10, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        [RequiredIf("WhetherExistingLoan", "True", ErrorMessage = "Value Required")]
        public virtual string LoanAmount { get; set; }
        [StringLength(10, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        [RequiredIf("WhetherExistingLoan", "True", ErrorMessage = "Value Required")]
        public virtual string OutSandingAmount { get; set; }



        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherPhysicallyChallange { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CasteId { get; set; }
        public virtual string CasteName { get; set; }
        public virtual string ReligionId { get; set; }
        public virtual string ReligionName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MaritalStatusId { get; set; }
        public virtual string MaritalStatus { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression("^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$", ErrorMessage = "Please Enter Valid PAN")]
        public virtual string StudentPANNo { get; set; }

        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string GuardianName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string RelationStudentId { get; set; }
        public virtual string RelationStudent { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [DataType(DataType.Date), Required(ErrorMessage = "value Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string GuardianDob { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string GuardianGender { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherTaxPayable { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression("^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$", ErrorMessage = "Please Enter Valid PAN")]
        public virtual string GuardianPANNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string GuardianIdProof { get; set; }
        public virtual string GuardianProofType { get; set; }
        [StringLength(30, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z0-9])+(?:(([A-Za-z0-9\s]))|(\.[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter valid No")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string GuardianIdProofNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string GuardianPsAdress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[0-9]{6}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string PsPinCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherSamePs { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string GuardianPmAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[0-9]{6}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string PmPinCode { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string GuardianContactNo { get; set; }
        public virtual string GuardianEmail { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ResidingTypeId { get; set; }
        public virtual string ResidingType { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Year")]
        [Range(0, 99, ErrorMessage = "Enter Valid Year")]
        public virtual string ResidingPeriod { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherSalaried { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Name Required")]
        public virtual string OrganizationName { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid Value")]
        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        public virtual string OffcieAddress { get; set; }
        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[0-9]{6}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string OfficePinCode { get; set; }
        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string OfficeContactNo { get; set; }
        public virtual string OfficeEmail { get; set; }
        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        public virtual string OrganizationTypeId { get; set; }
        public virtual string OrganizationType { get; set; }
        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        public virtual string WorkingSince { get; set; }
        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Year")]
        [Range(0, 99, ErrorMessage = "Enter Valid Year")]
        public virtual string RetirementAge { get; set; }
        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        public virtual string GrossMonthlyIncome { get; set; }
        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        public virtual string CurrentBusinessYear { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string LoanBankId { get; set; }
        public virtual string LoanBank { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BranchId { get; set; }
        public virtual string BranchName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual bool WhetherDeclarationGiven { get; set; }
        public virtual string RowIndex { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual string DesignationType { get; set; }

        [StringLength(10, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([0-9]{1,7})+(\.[0-9]{1,2})?", ErrorMessage = "Enter Valid value")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string DisbursalAmount { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [DataType(DataType.Date), Required(ErrorMessage = "Disbursal Date Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DisbursalDate { get; set; }
        [StringLength(10, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([0-9]{1,7})+(\.[0-9]{1,2})?", ErrorMessage = "Enter Valid value")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string AFGAmount { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [DataType(DataType.Date), Required(ErrorMessage = "Payment Date Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string AFGDate { get; set; }
        public virtual string AFGid { get; set; }





        //Changes20171011
        [StringLength(25, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string TrustAccNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankCode { get; set; }
        public virtual string BankBranchName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankBranchCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MICRCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AcademicSession { get; set; }
        public virtual string AcademicSessionType { get; set; }
        public virtual string CourseYear { get; set; }
        [RequiredIf("WhetherDelhiGovtEmp", "True", ErrorMessage = "Permanent Address Required")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string ParentPermanentAddress { get; set; }
        [RequiredIf("WhetherDelhiGovtEmp", "True", ErrorMessage = "PinCode Required")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[0-9]{6}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string ParentPinCode { get; set; }
        [RequiredIf("WhetherDelhiGovtEmp", "True", ErrorMessage = "State Required")]
        public virtual string ParentState { get; set; }

        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid College Name")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string CollegeName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string CollegeAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CollegeState { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter valid University Name")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string OutUniversityName { get; set; }

        //[Required(ErrorMessage = "Value Required")]
        public virtual string BranchAddress { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        public virtual string BranchEmail { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        public virtual string BranchContactNo { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        public virtual string BaseInterestRate { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        public virtual string BankAddress { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        public virtual string BankEmail { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        public virtual string BankContactNo { get; set; }

        public virtual string BranchCode { get; set; }
        public virtual string InstitutionCode { get; set; }
        public virtual string UniId { get; set; }
        public virtual string WhetherGovtEmp { get; set; }








        public virtual HeEducationalDetails HeEducationalDetails { get; set; }
        public virtual HeEducationalDetails HeEducationalDetails1 { get; set; }
        public virtual HeEducationalDetails HeEducationalDetails2 { get; set; }
        public virtual HeEducationalDetails HeEducationalDetails3 { get; set; }

        public virtual HeEducationalOtherDetails HeEducationalOtherDetails { get; set; }
        public virtual HeEducationalExpenditure HeEducationalExpenditure { get; set; }
        public virtual HeFinanceDetails HeFinanceDetails { get; set; }

        public virtual HeReferenceDetails HeReferenceDetails { get; set; }
        public virtual HeReferenceDetails HeReferenceDetails1 { get; set; }

        public DataTable dt { get; set; }
        public DataTable dt1 { get; set; }
        public DataTable dt2 { get; set; }
        public DataTable dt3 { get; set; }


        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }

        //[CustomProperty]
        //public SelectList UniversityMasterList
        //{
        //    get
        //    {
        //        List<HeUniversityMaster> UniversityMasterList = HeUniversityMaster.List<HeUniversityMaster>(new Npgsql.NpgsqlCommand("select UniversityId,UniversityName from heuniversitymaster where whetheractive=true order by UniversityName limit 0"));
        //        return new SelectList(UniversityMasterList, "UniversityId", "UniversityName");
        //    }
        //    set { }
        //}
        [CustomProperty]
        public SelectList UniversityMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select UniversityId,UniversityName from heuniversitymaster where whetheractive=true and ServiceCode=@ServiceCode order by UniversityName limit 0");
                Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.HigherEducationSKGS);
                List<HeUniversityMaster> UniversityMasterList = HeUniversityMaster.List<HeUniversityMaster>(Cmd);
                return new SelectList(UniversityMasterList, "UniversityId", "UniversityName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList InstitutionMasterList
        {
            get
            {
                List<HeInstitutionMaster> InstitutionMasterList = HeInstitutionMaster.List<HeInstitutionMaster>(new Npgsql.NpgsqlCommand("select InstituitonId,InstituitonName from HeInstitutionMaster where whetheractive=true order by InstituitonName limit 0"));
                return new SelectList(InstitutionMasterList, "InstituitonId", "InstituitonName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList SchoolMasterList
        {
            get
            {
                List<HeSchoolMaster> SchoolMasterList = HeSchoolMaster.List<HeSchoolMaster>(new Npgsql.NpgsqlCommand("select SchoolId,SchoolName from HeSchoolMaster where whetheractive=true order by SchoolName limit 0"));
                return new SelectList(SchoolMasterList, "SchoolId", "SchoolName");
            }
            set { }
        }

        //[CustomProperty]
        //public SelectList CourseList
        //{
        //    get
        //    {
        //        List<CourseMaster> CourseList = CourseMaster.List<CourseMaster>(new Npgsql.NpgsqlCommand("select HecourseId,CourseName from dbo.hecoursemaster order by CourseName"));
        //        return new SelectList(CourseList, "HeCourseId", "CourseName");
        //    }
        //    set { }
        //}
        [CustomProperty]
        public SelectList CourseList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select HecourseId,CourseName from dbo.hecoursemaster where ServiceCode=@ServiceCode order by CourseName");
                Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.HigherEducationSKGS);
                List<CourseMaster> CourseList = CourseMaster.List<CourseMaster>(Cmd);
                return new SelectList(CourseList, "HeCourseId", "CourseName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList QualificationRequiredList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HigherEducationQualificationRequired);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList MarrialialList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.MaritalStatus);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList ResidentList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.ResidentType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList RelationMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HigherEducationRelationList);
                List<ServiceTypeMaster> RelationMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(RelationMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList ParentGuardianMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.ParentGuardianList);
                List<ServiceTypeMaster> RelationMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(RelationMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList ReligionList
        {
            get
            {
                List<ReligionMaster> ReligionList = ReligionMaster.List<ReligionMaster>(new Npgsql.NpgsqlCommand("select ReligionId,ReligionName from dbo.ReligionMaster order by ReligionName"));
                return new SelectList(ReligionList, "ReligionId", "ReligionName");
            }
            set { }
        }
        public virtual SelectList YearList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int varYear = 1900;
                for (int i = varYear; i < DateTime.Now.AddYears(1).Year; i++)
                {
                    list.Add(new SelectListItem() { Text = varYear.ToString(), Value = varYear.ToString() });
                    varYear++;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                list.Add(new SelectListItem() { Text = "Transgender", Value = "T" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList ExaminationListMetri
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HigherEducationMetriculation);
                List<ServiceTypeMaster> ExaminationListMetri = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ExaminationListMetri, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList SchoolCategoryMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HigherEducationSchoolCategory);
                List<ServiceTypeMaster> ExaminationListMetri = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ExaminationListMetri, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList ExaminationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HigherEducationSecondry);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList OtherExaminationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.ExaminationType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList BankMasterList
        {
            get
            {
                List<BankMaster> BankMasterList = BankMaster.List<BankMaster>(new Npgsql.NpgsqlCommand("select BankCode,BankName from dbo.BankMaster where whetheractive='Y' order by BankName"));
                return new SelectList(BankMasterList, "BankCode", "BankName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList ApprovedBankMasterList
        {
            get
            {
                List<BankMaster> ApprovedBankMasterList = BankMaster.List<BankMaster>(new Npgsql.NpgsqlCommand("select HeBankCode,BankName from dbo.HeBankMaster where whetheractive=True order by BankName"));
                return new SelectList(ApprovedBankMasterList, "HeBankCode", "BankName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList BranchMasterList
        {
            get
            {
                List<HeBankBrachMaster> BranchMasterList = HeBankBrachMaster.List<HeBankBrachMaster>(new Npgsql.NpgsqlCommand("select HeBranchCode,BranchName from dbo.HeBankBranchMaster where whetheractive=True order by BranchName limit 0"));
                return new SelectList(BranchMasterList, "HeBranchCode", "BranchName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList CategoryMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HigherEducationCategory);
                List<ServiceTypeMaster> CategoryMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(CategoryMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList OrganizationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by SMVD.valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.OrganizationDetails);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList BoardList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by SMVD.valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HigherEducationAffiliatedBoard);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList DocumentList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select DocumentId,DocumentName from dbo.DocumentMaster where DocumentId in (@PANCard,@AadhaarCard)");
                Cmd.Parameters.AddWithValue("@PANCard", (int)DocumentId.PANCard);
                Cmd.Parameters.AddWithValue("@AadhaarCard", (int)DocumentId.AadhaarCard);
                List<DocumentMaster> DocumentMasterList = DocumentMaster.List<DocumentMaster>(Cmd);
                return new SelectList(DocumentMasterList, "DocumentId", "DocumentName");
            }
            set { }
        }
        public SelectList SchoolCategoryMasterList1
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HigherEducationSchoolCategory1);
                List<ServiceTypeMaster> ExaminationListMetri = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ExaminationListMetri, "ValueId", "ValueName");
            }
            set { }
        }

        //Changes20171011
        [CustomProperty]
        public SelectList StateList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select StateId,StateName from dbo.statemaster order by StateName");
                Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.HigherEducationSKGS);
                List<StateMaster> StateList = StateMaster.List<StateMaster>(Cmd);
                return new SelectList(StateList, "StateId", "StateName");
            }
            set { }
        }
    }
}