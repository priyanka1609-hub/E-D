﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationWidowDetails : Repositry<ApplicationWidowDetails>
    {
        public virtual string BankDetailsId { get; set; }
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [StringLength(18, MinimumLength = 2, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Enter Account No")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Account No")]
        public virtual string AccountNo { get; set; }
        [RequiredIf("IFSCCode", null, ErrorMessage = "MICR Code Required")]
        [StringLength(9, ErrorMessage = "MICR Code must be of 9 digits. ", MinimumLength = 9)]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid MICRCode")]
        public virtual string MICRCode { get; set; }
        [RequiredIf("MICRCode", null, ErrorMessage = "IFSC Code Required")]
        [StringLength(11, ErrorMessage = "IFSC Code must be of 11 digits. ", MinimumLength = 11)]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        [Required(ErrorMessage = "Select any one")]
        public virtual string MICRorIFSC { get; set; }
        [StringLength(50), Required(ErrorMessage = "Select Bank Name")]
        public virtual string BankCode { get; set; }

        public virtual string BankName { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Enter Branch Address")]
        //[RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string BranchAddress { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string HusbandDeathDate { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("ServiceCategoryId", ((int)ValueId.Widow), ErrorMessage = "Husband Name Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string HusbandName { get; set; }
        [StringLength(100), Required(ErrorMessage = "Select Constituency Name")]
        public virtual string ConstituencyID { get; set; }

        public virtual string ConstituencyName { get; set; }
        [StringLength(100), Required(ErrorMessage = "Select Category Name")]
        public virtual string CategoryId { get; set; }

        public virtual string CategoryName { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string LastActionDate { get; set; }
        [StringLength(50), Required(ErrorMessage = "Select Occupation Type")]
        public virtual string OccupationId { get; set; }

        public virtual string OccupationType { get; set; }
        [StringLength(50), Required(ErrorMessage = "Select Any One")]
        public virtual string WhetherStayPeriodValid { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("WhetherStayPeriodValid", "Yes", ErrorMessage = "Witness Name Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string Witness1Name { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("WhetherStayPeriodValid", "Yes", ErrorMessage = "Witness Name Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string Witness2Name { get; set; }
        [RequiredIf("WhetherStayPeriodValid", "Yes", ErrorMessage = "Witness Type Required")]
        public virtual string Witness1TypeId { get; set; }
        [RequiredIf("WhetherStayPeriodValid", "Yes", ErrorMessage = "Witness Type Required")]
        public virtual string Witness2TypeId { get; set; }
        public virtual string Witness2_Type { get; set; }
        public virtual string WitnessTypeId { get; set; }
        public virtual string Witness1_Type { get; set; }
        public virtual string WitnessTypeName { get; set; }

        [Range(0, 100000, ErrorMessage = "Family Annual Income exceeds maximum limit")]
        [StringLength(50), Required(ErrorMessage = "Enter Family Annual Income")]
        public virtual string FamilyAnnualIncome { get; set; }

        [StringLength(50), Required(ErrorMessage = "Select Account Type")]
        public virtual string AccountTypeId { get; set; }
        public virtual string AccountTypeName { get; set; }
        [StringLength(50), Required(ErrorMessage = "Select Ration card Type")]
        public virtual string RationCardTypeId { get; set; }
        public virtual string RationCardTypeName { get; set; }
        [StringLength(50), Required(ErrorMessage = "Ration Card No required")]
        public virtual string RationCardNo { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [StringLength(50), Required(ErrorMessage = "Select Account Type")]
        public virtual string ServiceCategoryId { get; set; }
        public virtual string ServiceCategoryName { get; set; }
        public virtual int TableWidth { get; set; }
        [CustomProperty]
        public SelectList CategoryMasterList
        {
            get
            {
                List<CategoryMaster> CategoryMasterList = CategoryMaster.List<CategoryMaster>(new Npgsql.NpgsqlCommand("select CategoryId,CategoryName from dbo.CategoryMaster"));
                return new SelectList(CategoryMasterList, "CategoryId", "CategoryName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList BankMasterList
        {
            get
            {
                List<BankMaster> BankMasterList = BankMaster.List<BankMaster>(new Npgsql.NpgsqlCommand("select BankCode,BankName from dbo.BankMaster"));
                return new SelectList(BankMasterList, "BankCode", "BankName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList AssemblyConstituencyMasterList
        {
            get
            {
                List<AssemblyConstituencyMaster> AssemblyConstituencyMasterList = AssemblyConstituencyMaster.List<AssemblyConstituencyMaster>(new Npgsql.NpgsqlCommand("select ConstituencyID,ConstituencyName from dbo.AssemblyConstituencyMaster order by ConstituencyName "));
                return new SelectList(AssemblyConstituencyMasterList, "ConstituencyID", "ConstituencyName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList OccupationMasterList
        {
            get
            {
                string Qry = "select OccupationId,OccupationType from dbo.OccupationMaster where OccupationId in (@DAILYWAGESWORKER,@HOMESERVANT,@HOUSEWIFE,@MAID,@OTHER,@UNEMPLOYED) order by OccupationType";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@DAILYWAGESWORKER", (int)Edistrict.Models.ApplicationService.OccupationId.DAILYWAGESWORKER);
                Cmd.Parameters.AddWithValue("@HOMESERVANT", (int)Edistrict.Models.ApplicationService.OccupationId.HOMESERVANT);
                Cmd.Parameters.AddWithValue("@HOUSEWIFE", (int)Edistrict.Models.ApplicationService.OccupationId.HOUSEWIFE);
                Cmd.Parameters.AddWithValue("@MAID", (int)Edistrict.Models.ApplicationService.OccupationId.MAID);
                Cmd.Parameters.AddWithValue("@OTHER", (int)Edistrict.Models.ApplicationService.OccupationId.OTHER);
                Cmd.Parameters.AddWithValue("@UNEMPLOYED", (int)Edistrict.Models.ApplicationService.OccupationId.UNEMPLOYED);
                List<OccupationMaster> OccupationMasterList = OccupationMaster.List<OccupationMaster>(Cmd);
                return new SelectList(OccupationMasterList, "OccupationId", "OccupationType");
            }
            set { }
        }
        [CustomProperty]
        public SelectList WitnessTypeMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by SMVD.valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.WidowWitness);
                List<ServiceTypeMaster> SocialCategoryList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(SocialCategoryList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList WitnessTypeMasterListEmpty
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by SMVD.valuename limit 0");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.WidowWitness);
                List<ServiceTypeMaster> SocialCategoryList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(SocialCategoryList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList RationCardDetailsMasterList
        {
            get
            {
                List<RationCardDetailsMaster> RationCardDetailsMasterList = RationCardDetailsMaster.List<RationCardDetailsMaster>(new Npgsql.NpgsqlCommand("select RationCardTypeId,RationCardTypeName from dbo.RationCardDetailsMaster"));
                return new SelectList(RationCardDetailsMasterList, "RationCardTypeId", "RationCardTypeName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList AccountTypeMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMVD.ValueId=@ValueId");
                Cmd.Parameters.AddWithValue("@ValueId", (int)ValueId.Single);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList SocialCategoryList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by SMVD.valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.ServiceCategoryType);
                List<ServiceTypeMaster> SocialCategoryList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(SocialCategoryList, "ValueId", "ValueName");
            }
            set { }
        }

    }
}