﻿using System;
using System.Data;
using System.Web.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationHandicappedDetails : Repositry<ApplicationHandicappedDetails>
    {
        public virtual string BankDetailsId { get; set; }
        public virtual string ApplicationId { get; set; }
        [StringLength(18, MinimumLength = 10), Required(ErrorMessage = "Account No Required")]
        public virtual string AccountNo { get; set; }
        [Required(ErrorMessage = "Account Type Required")]
        public virtual string AccountTypeId { get; set; }
        public virtual string AccountTypeName { get; set; }
        [RequiredIf("IFSCCode", null, ErrorMessage = "MICR Code Required")]
        [StringLength(9, ErrorMessage = "MICR Code must be of 9 digits. ", MinimumLength = 9)]
        public virtual string MICRCode { get; set; }
        [RequiredIf("MICRCode", null, ErrorMessage = "IFSC Code Required")]
        [StringLength(11, ErrorMessage = "IFSC Code must be of 11 digits. ", MinimumLength = 11)]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        [Required(ErrorMessage = "Select any one")]
        public virtual string MICRorIFSC { get; set; }
        [Required(ErrorMessage = "Bank Name Required")]
        public virtual string BankCode { get; set; }
        [Required(ErrorMessage = "Bank Name Required")]
        public virtual string BankName { get; set; }
        [Required(ErrorMessage = "Branch Address Required")]
        public virtual string BranchAddress { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "Constituency Name Required")]
        public virtual string ConstituencyId { get; set; }
        public virtual string ConstituencyName { get; set; }
        [Required(ErrorMessage = "Category Name Required")]
        public virtual string CategoryId { get; set; }
        public virtual string CategoryName { get; set; }
        [Required(ErrorMessage = "Social Category Required")]
        public virtual string SocialCategoryId { get; set; }
        public virtual string SocialCategoryName { get; set; }
        [Range(0, 100000, ErrorMessage = "Family Annual Income exceeds maximum limit")]
        [Required(ErrorMessage = "Family Annual Income Required")]
        public virtual string FamilyAnnualIncome { get; set; }
        [Required(ErrorMessage = "Marital Status Required")]
        public virtual string MaritalStatusId { get; set; }
        public virtual string MaritalStatusName { get; set; }
        [Required(ErrorMessage = "Occupation Required")]
        public virtual string OccupationId { get; set; }
        public virtual string OccupationType { get; set; }
        [Required(ErrorMessage = "Stay Period Validation Required")]
        public virtual string WhetherStayPeriodValid { get; set; }
        [Required(ErrorMessage = "File Number Required")]
        public virtual string FileNumber { get; set; }
        public virtual string RecommendOfficerName { get; set; }
        public virtual string RecommendOfficerType { get; set; }
        [Required(ErrorMessage = "MLA/MP/Gazetted Officer Recommendation Required")]
        public virtual string WhetherRecommend { get; set; }
        public virtual string RecommendOfficerRemarks { get; set; }
        [Required(ErrorMessage = "Pension Required")]
        public virtual string WhetherPensionBeneficiary { get; set; }
        public virtual string OtherFinancialAssistance { get; set; }
        [Required(ErrorMessage = "Percentage Disability Required")]
        public virtual string DisabilityPercentage { get; set; }
        [Required(ErrorMessage = "Disability Type Required")]
        public virtual string DisabilityTypeId { get; set; }
        public virtual string DisabilityTypeName { get; set; }
        [Required(ErrorMessage = "Disability Certificate No Required")]
        public virtual string DisabilityCertificateNo { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [Required(ErrorMessage = "Date of  Certificate Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DateofIssuedCertificate { get; set; }
        [Required(ErrorMessage = "Issuing Authority Required")]
        public virtual string IssuingAuthority { get; set; }
        public virtual string RationCardTypeId { get; set; }
        public virtual string RationCardNo { get; set; }
        public virtual string RationCardTypeName { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("WhetherStayPeriodValid", "False", ErrorMessage = "Witness Name Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string Witness1Name { get; set; }
        [RequiredIf("WhetherStayPeriodValid", "False", ErrorMessage = "Witness Type Required")]
        public virtual string Witness1TypeId { get; set; }
        public virtual string Witness1_Type { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("WhetherStayPeriodValid", "False", ErrorMessage = "Witness Name Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string Witness2Name { get; set; }
        [Required(ErrorMessage = "Disability Type Required")]
        public virtual string DisabilityType { get; set; }
        public virtual string Disability { get; set; }
        [RequiredIf("DisabilityType", "766", ErrorMessage = "Value Required")]
        public virtual string DisabilityCerMonth { get; set; }
        [RequiredIf("DisabilityType", "766", ErrorMessage = "Value Required")]
        public virtual string DisabilityCerYear { get; set; }
        [RequiredIf("DisabilityType", "766", ErrorMessage = "Value Required")]
        public virtual string DisabilityCerRemarks { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [RequiredIf("WhetherStayPeriodValid", "False", ErrorMessage = "Witness Type Required")]
        public virtual string Witness2TypeId { get; set; }
        public virtual string Witness2_Type { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherDrawMCDSanction { get; set; }
        public virtual string WhetherDrawSanction { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string LastActionDate { get; set; }
        public virtual int TableWidth { get; set; }
        public virtual string DistrictName { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("Witness1TypeId", "5", ErrorMessage = "Witness Name Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string Witness1Name1 { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("Witness2TypeId", "5", ErrorMessage = "Witness Name Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string Witness2Name2 { get; set; }

        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList BankMasterList
        {
            get
            {
                List<BankMaster> BankMasterList = BankMaster.List<BankMaster>(new Npgsql.NpgsqlCommand("select BankCode,BankName from dbo.BankMaster"));
                return new SelectList(BankMasterList, "BankCode", "BankName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList AssemblyConstituencyMasterList
        {
            get
            {
                List<AssemblyConstituencyMaster> AssemblyConstituencyMasterList = AssemblyConstituencyMaster.List<AssemblyConstituencyMaster>(new Npgsql.NpgsqlCommand("select ConstituencyID,ConstituencyName from dbo.AssemblyConstituencyMaster"));
                return new SelectList(AssemblyConstituencyMasterList, "ConstituencyID", "ConstituencyName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList CategoryMasterList
        {
            get
            {
                List<CategoryMaster> CategoryMasterList = CategoryMaster.List<CategoryMaster>(new Npgsql.NpgsqlCommand("select CategoryId,CategoryName from dbo.CategoryMaster"));
                return new SelectList(CategoryMasterList, "CategoryId", "CategoryName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList SocialCategoryMasterList
        {
            get
            {
                List<SocialCategoryMaster> SocialCategoryMasterList = SocialCategoryMaster.List<SocialCategoryMaster>(new Npgsql.NpgsqlCommand("select SocialCategoryId,SocialCategoryName from dbo.SocialCategoryMaster"));
                return new SelectList(SocialCategoryMasterList, "SocialCategoryId", "SocialCategoryName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MaritalStatusMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.MaritalStatus);
                List<ServiceTypeMaster> MaritalStatusMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(MaritalStatusMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList OccupationMasterList
        {
            get
            {
                List<OccupationMaster> OccupationMasterList = OccupationMaster.List<OccupationMaster>(new Npgsql.NpgsqlCommand("select OccupationId,OccupationType from dbo.OccupationMaster"));
                return new SelectList(OccupationMasterList, "OccupationId", "OccupationType");
            }
            set { }
        }
        [CustomProperty]
        public SelectList DisabilityTypeMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select * from disabilitytypemaster where disabilitytypeid in (select disabilitytypeid from disabilitytopercentagemaster where servicecode=@servicecode)  order by disabilitytypename");
                Cmd.Parameters.AddWithValue("@servicecode", (int)ServiceList.Handicapped);
                List<DisabilityTypeMaster> DisabilityTypeMasterList = DisabilityTypeMaster.List<DisabilityTypeMaster>(Cmd);
                return new SelectList(DisabilityTypeMasterList, "DisabilityTypeId", "DisabilityTypeName");


            }
            set { }
        }
        [CustomProperty]
        public SelectList RationCardDetailsMasterList
        {
            get
            {
                List<RationCardDetailsMaster> RationCardDetailsMasterList = RationCardDetailsMaster.List<RationCardDetailsMaster>(new Npgsql.NpgsqlCommand("select RationCardTypeId,RationCardTypeName from dbo.RationCardDetailsMaster"));
                return new SelectList(RationCardDetailsMasterList, "RationCardTypeId", "RationCardTypeName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList WitnessTypeMasterList
        {
            get
            {
                List<WitnessTypeMaster> WitnessTypeMasterList = WitnessTypeMaster.List<WitnessTypeMaster>(new Npgsql.NpgsqlCommand("select WitnessTypeId,WitnessTypeName from dbo.WitnessTypeMaster"));
                return new SelectList(WitnessTypeMasterList, "WitnessTypeId", "WitnessTypeName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList AccountTypeMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.AccountType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList DPercentageMasterList
        {
            get
            {
                List<DisabilityPercentageMaster> DPercentageMasterList = DisabilityPercentageMaster.List<DisabilityPercentageMaster>(new Npgsql.NpgsqlCommand("select DPercentageId,DPercentageName,replace(DPercentageName,'%','')::integer as pvalue from disabilitypercentagemaster order by pvalue"));
                return new SelectList(DPercentageMasterList, "DPercentageId", "DPercentageName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList DisabilityTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.DisabilityType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public virtual SelectList MonthList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                DateTime month = Convert.ToDateTime("01/01/2017");
                for (int i = 0; i < 12; i++)
                {
                    DateTime NextMonth = month.AddMonths(i);
                    list.Add(new SelectListItem() { Text = NextMonth.ToString("MMMM"), Value = (i + 1).ToString() });
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList YearList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int varYear = DateTime.Now.Year;
                int ToYear = varYear + 5;
                for (int i = varYear; i < ToYear; i++)
                {
                    list.Add(new SelectListItem() { Text = varYear.ToString(), Value = varYear.ToString() });
                    varYear++;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
    }
}