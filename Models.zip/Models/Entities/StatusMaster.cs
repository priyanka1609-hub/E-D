﻿using System;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class StatusMaster : Repositry<StatusMaster>
    {
        public virtual string StatusId { get; set; }
        public virtual string StatusName { get; set; }
        public virtual string StatusDesription { get; set; }
        public virtual string DisplayOrder { get; set; }
        public virtual string WhetherActive { get; set; }
    }
}