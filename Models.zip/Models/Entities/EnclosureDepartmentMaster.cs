﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class EnclosureDepartmentMaster : Repositry<EnclosureDepartmentMaster>
    {
        public virtual string DepartmentId { get; set; }
        public virtual string DeptName { get; set; }
        public virtual string WhetherActive { get; set; }
    }
}