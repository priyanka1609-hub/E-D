﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsDeath : Repositry<ApplicationDetailsDeath>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string RwithDeceasedId { get; set; }
        public virtual string RelationName { get; set; }
        [RegularExpression(@"^[a-zA-Z\s\.]+$", ErrorMessage = "Enter Relation With Deceased ")]
        public virtual string RelationWithDeceased { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Deceased Name")]
        public virtual string DeceasedName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Deceased Father Name")]
        public virtual string DeceasedFatherName { get; set; }
        public virtual string deceasedspousename { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DateOfDeath { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter valid place")]
        public virtual string PlaceOfDeath { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DateOfCremation { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter valid place of Cremation")]
        public virtual string PlaceOfCremation { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ReasonsOfNonRegistration { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string deceasedmothername { get; set; }
        [Required(ErrorMessage = "Death Proof Required")]
        public virtual string deathproofid { get; set; }
        public virtual string deathproofname { get; set; }
        public virtual string DeathAddress { get; set; }
        [Required(ErrorMessage = "House No Required")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string houseno { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string streetno { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string sublocality { get; set; }
        [Required(ErrorMessage = "SubDivision Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid SubDivision")]
        public virtual string subdivcode { get; set; }
        public virtual string SubDivDescription { get; set; }
        [Required(ErrorMessage = "District Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid District")]
        public virtual string districtcode { get; set; }
        public virtual string DistrictName { get; set; }
        public virtual string stateid { get; set; }
        public virtual string statename { get; set; }
        public virtual string countryid { get; set; }
        public virtual string CountryName { get; set; }
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "PinCode required")]
        [RegularExpression(@"^[1-1][1-1][0-9]{4}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string pincode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LocalityId { get; set; }
        [CustomProperty]
        public virtual string LocalityName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string deceasedgender { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CauseofDeath { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("CauseofDeath", "34", ErrorMessage = "Police Report Date Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string PoliceReportdate { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RequiredIf("CauseofDeath", "34", ErrorMessage = "Police Station Name Required")]
        public virtual string PoliceStationName { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter valid Address")]
        public virtual string DeceasedPermanentAddress { get; set; }
        [RequiredIf("deathproofid", "6", ErrorMessage = "Details Required")]
        public virtual string OtherDeathProof { get; set; }
        [CustomProperty]
        public SelectList LocalityList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select lm.localityid,lm.localityname from localitymaster lm inner join subdivmaster sd on sd.subdivcode=lm.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and lm.whetheractive=@whetheractive order by lm.LocalityName");
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList LocalityListSubdivWise
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.whetheractive=@whetheractive";
                if (Sessions.getEmployeeUser() != null) { Qry += " and sd.subdivcode in (@ParamSubDivCode)"; }
                Qry += " order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList DeathMasterList
        {
            get
            {

                List<DeathMaster> DeathMasterList = DeathMaster.List<DeathMaster>(new Npgsql.NpgsqlCommand("select deathproofid,deathproofname from dbo.deathproofmaster where whetheractive=TRUE"));
                return new SelectList(DeathMasterList, "deathproofid", "deathproofname");
            }
            set { }
        }
        [CustomProperty]
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                list.Add(new SelectListItem() { Text = "Transgender", Value = "T" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList RelationMasterList
        {
            get
            {
                List<RelationMaster> RelationMasterList = RelationMaster.List<RelationMaster>(new Npgsql.NpgsqlCommand("select relationid,relationname from dbo.relationmaster order by relationname"));
                return new SelectList(RelationMasterList, "relationid", "relationname");
            }
            set { }
        }
        [CustomProperty]
        public SelectList CauseofDeathList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.CauseOfDeath);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
    }
}