﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsCEA3 : Repositry<ApplicationDetailsCEA3>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationStatusId { get; set; }

        public virtual string RIOName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherPertainEI { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string NameofInstall { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string NameofIns { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Localityofins { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofowner { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AddrofOwner { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofconcerned { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Addrofconcerned { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Mobilenoofconcerned { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Emailofconcerned { get; set; }
        public virtual string FeeDeposit { get; set; }
        public virtual string LocalityName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherRelProvCEA { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherAppliedforOwn { get; set; }
        [RequiredIf("WhetherAppliedforOwn", "No", ErrorMessage = "Value Required")]
        public virtual string DateofReceiptofInsp { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DateofReg43 { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DateofReg30 { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherObsLastInsp { get; set; }

        public virtual DataTable data { get; set; }
        public virtual DataTable data1 { get; set; }

        public SelectList LocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@Dept and dm.stateid=@stateid and LM.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@Dept", (int)Department.Dept007);
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList YesList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList YesNoNAList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                list.Add(new SelectListItem() { Text = "N/A", Value = "NA" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }      
    }
}