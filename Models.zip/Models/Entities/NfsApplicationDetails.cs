﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Collections.Generic;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using System.Data;
namespace Edistrict.Models.Entities
{
    public class NfsApplicationDetails : Repositry<NfsApplicationDetails>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "AadhaarNo Required")]
        [StringLength(12, MinimumLength = 12)]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Aadhaar No")]
        public virtual string Aadhaarno { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string HOFProfession { get; set; }
        public virtual string HOFProfessionType { get; set; }
        [Required(ErrorMessage = "Name Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name ")]
        [StringLength(100, MinimumLength = 2)]
        public virtual string EldestFemaleMemberName { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherEldestFemaleMember { get; set; }
        [StringLength(10, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^([0-9]{1,7})+(\.[0-9]{1,2})?$", ErrorMessage = "Enter Valid value")]
        public virtual string AnuualFamilyIncome { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string ElligibiltyCategory { get; set; }
        public virtual string ElligibiltyCategoryType { get; set; }

        [Required(ErrorMessage = "Value  Required")]
        public virtual string NearestFPS1 { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string NearestFPS2 { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string NearestFPS3 { get; set; }
        
        //[Required(ErrorMessage = "Value  Required")]
        public virtual string AccountHolderName { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        public virtual string AccountNo { get; set; }
        public virtual string BankName { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        public virtual string BankCode { get; set; }
        public virtual string BankBranchName { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        //[Required(ErrorMessage = "Value Required")]
        public virtual string MICRCode { get; set; }

        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherIndian { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherResideDelhi { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherForAnotherUsed { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherHavingVehicle { get; set; }
        [RequiredIf("WhetherHavingVehicle", "False", ErrorMessage = "Details Required")]
        public virtual string NoOfVehicle { get; set; }
        [RequiredIf("WhetherHavingVehicle", "False", ErrorMessage = "Details Required")]
        public virtual string VehicleType { get; set; }
        public virtual string VehicleTypeDetails { get; set; }
        [StringLength(100, MinimumLength = 2)]
        [RequiredIf("WhetherHavingVehicle", "False", ErrorMessage = "Details Required")]
        public virtual string VehicleRegistrationNo { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("WhetherHavingVehicle", "False", ErrorMessage = "Details Required")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name ")]
        [StringLength(100, MinimumLength = 2)]
        public virtual string VehicleOwnerName { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherElectricityConn { get; set; }
        [RequiredIf("WhetherElectricityConn", "True", ErrorMessage = "Details Required")]
        public virtual string ElectricityProviderId { get; set; }
        public virtual string ElectricityProvider { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherConsumptionExceed { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string CAnumber { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        [StringLength(2, MinimumLength = 1)]
        [RegularExpression(@"^\d+$", ErrorMessage = "Enter valid Sanction ")]
        public virtual string LoadSanctiononCA { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string FamilySharingConn { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string ResidenceType { get; set; }
        public virtual string ResidenceTypeDetails { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherTaxPayble { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherHavingLand { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherGovtEmployee { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string WhetherAnotherScheme { get; set; }


        [Required(ErrorMessage = "Value  Required")]
        public virtual string HOFChangeReasonCode { get; set; }
        public virtual string HOFChangeReason { get; set; }


        public virtual string RCMemberCounter { get; set; }
        public DataTable dt { get; set; }
        public DataSet ds { get; set; }
        public virtual string StatusId { get; set; }
        public virtual string ApplicationStatusId { get; set; }

        public virtual string NewRationCardNo { get; set; }
        public virtual string OldRationCardNo { get; set; }
        public virtual string Cardcategory { get; set; }
        public virtual string Circle { get; set; }
        public virtual string AssignedFps { get; set; }
        public virtual string NfsApplicationId { get; set; }
        public virtual string DeptCode { get; set; }
        public virtual int TableWidth { get; set; }

        public virtual NfsMemberDetails NfsMemberDetails { get; set; }
        public virtual NfsUpdateBasicDetails NfsUpdateBasicDetails { get; set; }
        public SelectList CircleWiseFPSList { get; set; }

        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList OccupationMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HOFProfession);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList VehicleTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.VehicleType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList ResidentTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.ResidentType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList HOFChangeReasonList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HofChangeReason);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList LocalityMasterList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@ParamDeptCode";
                if (Sessions.getEmployeeUser() != null) { if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and sd.SubDivCode in (@ParamSubDivCode)"; } }
                Qry += " order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@ParamDeptCode", (int)Department.Dept003);
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MemberRelationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.NFSMemberRelationship);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList ElectricityProviderList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.ElectricityProvider);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList ElligibiltyCategoryList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.ElligibilityCategory);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MemberWithoutHoFRelationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid and SMVD.valueid <> @valueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.NFSMemberRelationship);
                Cmd.Parameters.AddWithValue("@valueid", (int)ValueId.Self);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
    }
}