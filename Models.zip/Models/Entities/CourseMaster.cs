﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class CourseMaster : Repositry<CourseMaster>
    {
        public virtual string CourseId { get; set; }
        public virtual string HeCourseId { get; set; }
        public virtual string CourseName { get; set; }
    }
}