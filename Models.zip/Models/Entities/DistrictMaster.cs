﻿using System;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class DistrictMaster : Repositry<DistrictMaster>
    {
        public virtual string DistrictCode { get; set; }
        public virtual string DistrictName { get; set; }
        public virtual string StateId { get; set; }
        public virtual bool WhetherActive { get; set; }
    }
}