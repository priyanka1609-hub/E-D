﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;

namespace Edistrict.Models.Entities
{
    public class NOCApplicationAreaDetails : Repositry<NOCApplicationAreaDetails>
    {
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string AId { get; set; }
        public virtual string KhasraNo { get; set; }
        public virtual string RectangleNo { get; set; }
    }
}