﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using System.Data;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsRecovery : Repositry<ApplicationDetailsRecovery>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string RecoveryNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CaseNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DiaryNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DeptId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string RecoverytypeId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Subdivcode { get; set; }
        public virtual string SubdivName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Policestation { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Presentstatus { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Presentstage { get; set; }
        public virtual string Nameoffirm { get; set; }
        public virtual string Addroffirm { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Remarks { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Amount { get; set; }
        public virtual string InterestAmount { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DeptAddress { get; set; }
        [StringLength(10, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        public virtual string InterestRate { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string InterestStartDate { get; set; }

        public virtual string ApplicationStatusId { get; set; }
        public virtual string BeneficiaryCount { get; set; }
        public virtual string DefaulterCount { get; set; }
        public DataTable dt1 { get; set; }
        public DataTable dt2 { get; set; }
        public DataTable dt3 { get; set; }
        public DataTable dt4 { get; set; }

        [CustomProperty]
        public SelectList DeptMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select deptcode,deptname from dbo.recoverydeptmaster where whetheractive=@whetheractive order by deptname");
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.True.ToString());
                List<DeptMaster> DeptMasterList = DeptMaster.List<DeptMaster>(Cmd);
                return new SelectList(DeptMasterList, "deptcode", "deptname");
            }
            set { }
        }
        [CustomProperty]
        public SelectList RecoveryTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.RecoveryType);
                List<SelectValueMaster> RecoveryTypeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(RecoveryTypeList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList PoliceStationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select policestationid as SelectValueId,policestationname as SelectValueName from dbo.policestationmaster where whetheractive=TRUE and servicecode=@servicecode and cdvsubdivcode=@subdivcode");
                Cmd.Parameters.AddWithValue("@servicecode", (int)ServiceList.Recovery);
                Cmd.Parameters.AddWithValue("@subdivcode", Sessions.getEmployeeUser().SubDivCode);
                List<SelectValueMaster> PoliceStationList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(PoliceStationList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList PresentStatusList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.RecoveryPresentStatus);
                List<SelectValueMaster> PresentStatusList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(PresentStatusList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList PresentStageList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.RecoveryPresentStage);
                List<SelectValueMaster> PresentStageList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(PresentStageList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
    }
}