﻿using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Web;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class UserCreationEnclosureDetails : Repositry<UserCreationEnclosureDetails>
    {
        [Required(ErrorMessage = "Please Upload Document")]
        [HttpFile(AllowedContentTypes = new string[] { "application/pdf" }, AllowedFileExtensions = new string[] { ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase DocumentData { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string UserId { get; set; }
        public virtual string ContentType { get; set; }
        public virtual string ActionUserId { get; set; }
        public virtual string ActionIpAddress { get; set; }
        public virtual string LastUpdateDate { get; set; }
        public virtual string DocumentEntryDate { get; set; }
        public bool flag { get; set; }

        [Required(ErrorMessage = "Select one Document.")]
        public string DocId { get; set; }
        [StringLength(12, MinimumLength = 12, ErrorMessage = "Enter Valid Document No")]
        public string AadhaarNo { get; set; }
        [Required(ErrorMessage = "Document No Required")]
        [StringLength(20, MinimumLength = 2, ErrorMessage = "Enter Valid Document No")]
        public string DocumentNo { get; set; }
        [Required(ErrorMessage = "Please Upload Document")]
        [HttpFile(AllowedContentTypes = new string[] { "application/pdf" }, AllowedFileExtensions = new string[] { ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase ReferenceDocumentData { get; set; }
        [Required(ErrorMessage = "Please Upload Police Certificate")]
        [HttpFile(AllowedContentTypes = new string[] { "application/pdf" }, AllowedFileExtensions = new string[] { ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase PoliceVerDocumentData { get; set; }
    }
}