﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.Entities
{
    public class MaritalStatusMaster : Repositry<ApplicationMarriageDetails>
    {
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string MaritalStatusId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MaritalStatusName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherActive { get; set; }
    }
}