﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Collections.Generic;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class CDVAwardDetails : Repositry<CDVAwardDetails>
    {
        [Required(ErrorMessage = "Required")]
        public virtual string ApplicationNo { get; set; }

        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }

        [Required(ErrorMessage = "Required")]
        public virtual string AwardName { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string AwardDetails { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string AwardgivenBy { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string AwardDate { get; set; }

        public SelectList CDVrefNumber { get; set; }
        public DataTable dt { get; set; }
        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
    }
}