﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsInstrumentLoan : Repositry<ApplicationDetailsInstrumentLoan>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual string Whetherexist { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerRegNo { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofstudent { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameoffather { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofhusband { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Residentialaddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string RegNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankCode { get; set; }
        public virtual string BankName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Applicantdob { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)",ErrorMessage="Enter only numbers")]
        public virtual string Monthlyincome { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherownprop { get; set; }
        [RequiredIf("Whetherownprop", "True", ErrorMessage = "Value Required")]
        public virtual string Detailsofprop { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofsureties { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Addressofsureties { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Suretyoccupation { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Occupationaddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Suretiesdob { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string Netmonthlyincome { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Detailspropsureties { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whethertransaction { get; set; }
        [RequiredIf("Whethertransaction", "True", ErrorMessage = "Value Required")]
        public virtual string Detailsoftrans { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Whethersalarycerti { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Description { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Make { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Model { get; set; }
        
        //change22022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string Costoftools { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofsupplier { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Addressofsupplier { get; set; }
        
        //change22022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string Loanamount { get; set; }
        
        //change22022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers"),Range(0,60)]
        public virtual string Noofinstallment { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountHolderName { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountNo { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string MICRCode { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string BranchAddress { get; set; }

        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList DistrictList
        {
            get
            {
                string Qry = "select DistrictCode,DistrictName from DistrictMaster where deptcode=@DeptCode order by DistrictName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@DeptCode", (int)Department.Dept016);
                List<DistrictMaster> DistrictList = DistrictMaster.List<DistrictMaster>(Cmd);
                return new SelectList(DistrictList, "DistrictCode", "DistrictName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList BankMasterList
        {
            get
            {
                List<BankMaster> BankMasterList = BankMaster.List<BankMaster>(new Npgsql.NpgsqlCommand("select BankCode,BankName from dbo.BankMaster"));
                return new SelectList(BankMasterList, "BankCode", "BankName");
            }
            set { }
        }
    }
}