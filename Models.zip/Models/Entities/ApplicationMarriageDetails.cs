﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;

namespace Edistrict.Models.Entities
{
    public class ApplicationMarriageDetails : Repositry<ApplicationMarriageDetails>
    {
        [Required(ErrorMessage = "Application No. Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicationId { get; set; }
        [Required(ErrorMessage = "Application No. Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicationNo { get; set; }
        [RequiredIf("HSelect", "A", ErrorMessage = "Aadhaar No Required")]
        [StringLength(12, MinimumLength = 12, ErrorMessage = "Enter Valid AADHAAR")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid AADHAAR")]
        public virtual string HAadhaarNo { get; set; }
        [RequiredIf("HSelect", "E", ErrorMessage = "Enrolment No Required")]
        [StringLength(14, MinimumLength = 14, ErrorMessage = "Enter Valid Enrollment No")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Enrollment No")]
        public virtual string HEnrolmentNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string HName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z])+(?:(([A-Za-z\s]))|(\.[A-Za-z\s]+))*([A-Za-z])*", ErrorMessage = "Enter valid Father Name")]
        public virtual string HFatherName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid MotherName")]
        public virtual string HMotherName { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [DataType(DataType.Date), Required(ErrorMessage = "DOB Required")]
        [DateRange(DifferenceYear = 18, RequiredGreater = true, ErrorMessage = "Minimum age criteria not fullfill")]
        //[RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string HDOB { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string HMaritalStatusId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string HNationalityId { get; set; }
        [Required(ErrorMessage = "House No Required")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string HpmHouseNumber { get; set; }
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string HpmStreetNumber { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string HpmSubLocality { get; set; }

        public virtual string HpmLocalityId { get; set; }
        public virtual string HpmLocalityName { get; set; }
        [RequiredIf("HpmCountryId", "1", ErrorMessage = "PinCode Required")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value")]
        public virtual string Hpmpincode { get; set; }
        [Required(ErrorMessage = "House No Required")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string HpsHouseNumber { get; set; }
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string HpsStreetNumber { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string HpsSubLocality { get; set; }

        public virtual string HpsLocalityId { get; set; }
        public virtual string HpsLocalityName { get; set; }
        [RequiredIf("HpsCountryId", "1", ErrorMessage = "PinCode Required")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value")]
        public virtual string Hpspincode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string HDocumentNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WDocumentNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string HDocumentId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WDocumentId { get; set; }
        
        public virtual string HDocumentName { get; set; }
        public virtual string WDocumentName { get; set; }
        public virtual System.Nullable<int> HRegistrationId { get; set; }
        public virtual System.Nullable<int> WRegistrationId { get; set; }
        public virtual string HpmCountryName { get; set; }
        public virtual string WpmCountryName { get; set; }
        public virtual string HReligionName { get; set; }
        public virtual string WReligionName { get; set; }

        [StringLength(100, MinimumLength = 8), Required(ErrorMessage = "Email Id Required")]
        [DataType(DataType.EmailAddress, ErrorMessage = "Enter valid Email")]
        [RegularExpression(@"[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Enter valid Email")]
        public virtual string HEmail { get; set; }
        [DataType(DataType.PhoneNumber, ErrorMessage = "Enter valid mobile no")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string HMobile { get; set; }
        [RequiredIf("WSelect", "A", ErrorMessage = "Aadhaar No Required")]
        [StringLength(12, MinimumLength = 12, ErrorMessage = "Enter Valid AADHAAR")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid AADHAAR")]
        public virtual string WAadhaarNo { get; set; }
        [RequiredIf("WSelect", "E", ErrorMessage = "Enrolment No Required")]
        [StringLength(14, MinimumLength = 14, ErrorMessage = "Enter Valid Enrollment No")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Enrollment No")]
        public virtual string WEnrolmentNo { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string WName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Father Name")]
        public virtual string WFatherName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid  Mother Name")]
        public virtual string WMotherName { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [DataType(DataType.Date), Required(ErrorMessage = "DOB Required")]
        [DateRange(DifferenceYear = 15, RequiredGreater = true, ErrorMessage = "Minimum age criteria not fullfill")]
        //[RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string WDOB { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string WMaritalStatusId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WNationalityId { get; set; }
        public virtual string HPermanentAddress { get; set; }
        public virtual string WPermanentAddress { get; set; }
        public virtual string HPresentAddress { get; set; }
        public virtual string WPresentAddress { get; set; }
        [Required(ErrorMessage = "House No Required")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string WpmHouseNumber { get; set; }
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string WpmStreetNumber { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string WpmSubLocality { get; set; }
        [RequiredIf("WpmCountryId", "1", ErrorMessage = "PinCode Required")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value")]
        public virtual string Wpmpincode { get; set; }

        public virtual string WpmLocalityId { get; set; }
        public virtual string WpmLocalityName { get; set; }
        [Required(ErrorMessage = "House No Required")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string WpsHouseNumber { get; set; }
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string WpsStreetNumber { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string WpsSubLocality { get; set; }
        [RequiredIf("WpsCountryId", "1", ErrorMessage = "PinCode Required")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value")]
        public virtual string Wpspincode { get; set; }

        public virtual string WpsLocalityId { get; set; }
        public virtual string WpsLocalityName { get; set; }


        [Required(ErrorMessage = "Value Required")]
        public virtual string HOccupationId { get; set; }
        public virtual string HOccupationName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WOccupationId { get; set; }
        public virtual string WOccupationName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [Range(0, 99, ErrorMessage = "Enter Valid Year")]
        [RegularExpression("^[0-9]{1,2}$", ErrorMessage = "InValid Input")]
        public virtual string HResidenceYears { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [Range(0, 99, ErrorMessage = "Enter Valid Year")]
        [RegularExpression("^[0-9]{1,2}$", ErrorMessage = "InValid Input")]
        public virtual string WResidenceYears { get; set; }

        [StringLength(100, MinimumLength = 8), Required(ErrorMessage = "Email Id Required")]
        [DataType(DataType.EmailAddress, ErrorMessage = "Enter valid Email")]
        [RegularExpression(@"[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Enter valid Email")]
        public virtual string WEmail { get; set; }
        [DataType(DataType.PhoneNumber, ErrorMessage = "Enter valid mobile no")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string WMobile { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [DataType(DataType.Date), Required(ErrorMessage = "Date of Marriage Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string MarriageDate { get; set; }
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "value Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string MarriagePlace { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RequiredIf("WhetherReligiousMarriage", "Y", ErrorMessage = "Value Required")]
        public virtual string MarriageReligion { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RequiredIf("WhetherReligiousMarriage", "Y", ErrorMessage = "Value Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string MarriageReligiousPlace { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AppointmentTypeId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AppointmentId { get; set; }

        public virtual string MarriageSubdivCode { get; set; }
        [RequiredIf("MarriageCountryId", "1", ErrorMessage = "District Required")]
        public virtual string MarriageDistrictCode { get; set; }
        [RequiredIf("MarriageLocalityId", null, ErrorMessage = "State Required")]
        public virtual string MarriageStateId { get; set; }
        [Required(ErrorMessage = "Select Country")]
        public virtual string MarriageCountryId { get; set; }

        public virtual string MarriageLocalityId { get; set; }
        public virtual string MarriageLocalityName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string HReligionId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WReligionId { get; set; }
        public virtual string ReligionName { get; set; }

        [RequiredIf("HpmLocalityId", null, ErrorMessage = "State Required")]
        public virtual string HpmStateId { get; set; }
        [RequiredIf("HpsLocalityId", null, ErrorMessage = "State Required")]
        public virtual string HpsStateId { get; set; }
        [RequiredIf("WpmLocalityId", null, ErrorMessage = "State Required")]
        public virtual string WpmStateId { get; set; }
        [RequiredIf("WpsLocalityId", null, ErrorMessage = "State Required")]
        public virtual string WpsStateId { get; set; }
        public virtual string ApplicantStateId { get; set; }
        public virtual string StateName { get; set; }
        public virtual string ApplicantCountryId { get; set; }
        [Required(ErrorMessage = "Select Country")]
        public virtual string HpmCountryId { get; set; }
        [Required(ErrorMessage = "Select Country")]
        public virtual string HpsCountryId { get; set; }
        [Required(ErrorMessage = "Select Country")]
        public virtual string WpmCountryId { get; set; }
        [Required(ErrorMessage = "Select Country")]
        public virtual string WpsCountryId { get; set; }
        public virtual string CountryName { get; set; }
        public virtual string Hpmsubdivcode { get; set; }
        public virtual string Hpssubdivcode { get; set; }
        public virtual string Wpmsubdivcode { get; set; }
        public virtual string Wpssubdivcode { get; set; }
        [RequiredIf("HpmCountryId", "1", ErrorMessage = "District Required")]
        public virtual string Hpmdistrictcode { get; set; }
        [RequiredIf("HpsCountryId", "1", ErrorMessage = "District Required")]
        public virtual string Hpsdistrictcode { get; set; }
        [RequiredIf("WpmCountryId", "1", ErrorMessage = "District Required")]
        public virtual string Wpmdistrictcode { get; set; }
        [RequiredIf("WpsCountryId", "1", ErrorMessage = "District Required")]
        public virtual string Wpsdistrictcode { get; set; }
        public virtual string ApplicantDistrictName { get; set; }
        public virtual string ApplicantSubDivDescription { get; set; }

        [Required(ErrorMessage = "Please Select Option")]
        public virtual string HSelect { get; set; }
        [Required(ErrorMessage = "Please Select Option")]
        public virtual string WSelect { get; set; } 

        public virtual string HpmHiddenStateId { get; set; }
        public virtual string HpsHiddenStateId { get; set; }
        public virtual string WpmHiddenStateId { get; set; }
        public virtual string WpsHiddenStateId { get; set; }
        public virtual string MarriageHiddenStateId { get; set; }
        public virtual string AppointmentDate { get; set; }
        public virtual string AppointmentSubDiv { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual string SolemnizationDate { get; set; }
        public virtual string MarriageAct { get; set; }

        public SelectList SelectAppointmentSubDiv { get; set; }
        public SelectList SelectAppointmentDate { get; set; }

        [CustomProperty]
        public virtual string MSubDivName { get; set; }
        [CustomProperty]
        public virtual string MDistrictName { get; set; }
        [CustomProperty]
        public virtual string MStateName { get; set; }
        [CustomProperty]
        public virtual string HpmSubDivName { get; set; }
        [CustomProperty]
        public virtual string HpmDistrictName { get; set; }
        [CustomProperty]
        public virtual string HpmStateName { get; set; }
        [CustomProperty]
        public virtual string HpsSubDivName { get; set; }
        [CustomProperty]
        public virtual string HpsDistrictName { get; set; }
        [CustomProperty]
        public virtual string HpsStateName { get; set; }
        [CustomProperty]
        public virtual string WpmSubDivName { get; set; }
        [CustomProperty]
        public virtual string WpmDistrictName { get; set; }
        [CustomProperty]
        public virtual string WpmStateName { get; set; }
        [CustomProperty]
        public virtual string WpsSubDivName { get; set; }
        [CustomProperty]
        public virtual string WpsDistrictName { get; set; }
        [CustomProperty]
        public virtual string WpsStateName { get; set; }
        [CustomProperty]
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherReligiousMarriage { get; set; }
        [CustomProperty]
        [Required(ErrorMessage = "Value Required")]
        public virtual System.Nullable<float> TotalServiceFee { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MarriageActId { get; set; }
        public virtual string MarriageActName { get; set; }
        public virtual bool Age { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherFooterRequired { get; set; }
        [DataType(DataType.Date), Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DealingRecommandDate { get; set; }
        [DataType(DataType.Date), Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string RegistrationSystemDate { get; set; }
        [DataType(DataType.Date), Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string RegistrationPerformDate { get; set; }
        [DataType(DataType.Date), Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string SolemnizationSystemDate { get; set; }
        [DataType(DataType.Date), Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string SolemnizationPerformDate { get; set; }
        public virtual string ActualAppointmentDate { get; set; }
        public virtual string WhetherPriorAfterDecisionRemark { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PriorAfterDecisionRemarks { get; set; }
    }
}