﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.CustomAttribute;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsLBRRecovery : Repositry<ApplicationDetailsLBRRecovery>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CaseNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AwardDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CourtName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Awardamount { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string EstName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PersonName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Persondesignaton { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PersoncontactNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Personlandline { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Addrofest { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string EstlocalityId { get; set; }
        public virtual string EstlocalityName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Addrofesthq { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string EsthqlocalityId { get; set; }
        public virtual string EsthqlocalityName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Personaddr { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PersonlocalityId { get; set; }
        public virtual string PersonlocalityName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Otherdetails { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string IsSettled { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string IsNoticeRequired { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string IsRecoveryCertRequired { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ProceedingDetails { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ProceedingDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Remarks { get; set; }
        public virtual string WhetherProceedingDetails { get; set; }
        public virtual string NoticeId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PresidingOfficerName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PubAwardDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string EnforceAwardDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherDateofEnforce { get; set; }
        [RequiredIf("WhetherDateofEnforce", "No", ErrorMessage = "Value Required")]
        public virtual string ReasonofDelay { get; set; }
        [RequiredIf("WhetherDateofEnforce", "No", ErrorMessage = "Value Required")]
        public virtual string CondonationofDelay { get; set; }
        [RequiredIf("WhetherDateofEnforce", "No", ErrorMessage = "Value Required")]
        public virtual string ReliefAward { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ClaimedAwardAmount { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherDemandNotice { get; set; }
        [RequiredIf("WhetherDemandNotice", "Yes", ErrorMessage = "Value Required")]
        public virtual string NoticeDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherChanges { get; set; }
        [RequiredIf("WhetherChanges", "Yes", ErrorMessage = "Value Required")]
        public virtual string PresentNameEstt { get; set; }
        [RequiredIf("WhetherChanges", "Yes", ErrorMessage = "Value Required")]
        public virtual string PresentAddrEstt { get; set; }
        [RequiredIf("WhetherChanges", "Yes", ErrorMessage = "Value Required")]
        public virtual string PresentNameofProp { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherClaim { get; set; }
        [RequiredIf("WhetherClaim", "No", ErrorMessage = "Value Required")]
        public virtual string NameofClaimant { get; set; }
        [RequiredIf("WhetherClaim", "No", ErrorMessage = "Value Required")]
        public virtual string RelWithWorkMen { get; set; }
        public virtual string RelationshipName { get; set; }
        [RequiredIf("WhetherClaim", "No", ErrorMessage = "Value Required")]
        public virtual string AddrofClaimant { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public string PersonMobileNo { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Check Box Checked Required")]
        public virtual bool check { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LCCourtNo { get; set; }

        [CustomProperty]
        public SelectList LocalityList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.whetheractive=@whetheractive order by lm.LocalityName");
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept007);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
    }
}