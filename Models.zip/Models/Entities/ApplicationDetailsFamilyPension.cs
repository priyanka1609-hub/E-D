﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsFamilyPension : Repositry<ApplicationDetailsFamilyPension>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherexist { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicantRelationId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicantrelationName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerRegNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerAge { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Workerdateofdeath { get; set; }        
        
        //change19022018
        [Required(ErrorMessage = "Value Required"),RegularExpression("([0-9]+)",ErrorMessage="Enter only numbers")]
        public virtual string Workerpensionreceived { get; set; }
        
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherworkerrecevingpension { get; set; }
        [RequiredIf("Whetherworkerrecevingpension", "True", ErrorMessage = "Value Required")]
        public virtual string Workerpensiondetails { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherworkerrecevingsalary { get; set; }
        [RequiredIf("Whetherworkerrecevingsalary", "True", ErrorMessage = "Value Required")]
        public virtual string Workersalarydetails { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string AccountNo { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string MICRCode { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankName { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string BranchAddress { get; set; }


        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList MemberRelationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select relationid as Valueid,relationname as Valuename from relationmaster  order by 1");
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
    }
}