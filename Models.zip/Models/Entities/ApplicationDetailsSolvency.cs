﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsSolvency : Repositry<ApplicationDetailsSolvency>
    {
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [Range(1, 99999999, ErrorMessage = "{0} value must be between {1} and {2}")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Certificate Amount")]
        [StringLength(8, MinimumLength = 4, ErrorMessage = "Enter valid amount"), Required(ErrorMessage = "Certificate Amount Required")]
        public virtual string CertificateAmount { get; set; }
        [Required(ErrorMessage = "Purpose for Certificate Required")]
        [StringLength(100, MinimumLength = 4, ErrorMessage = "Enter valid Purpose for Certificate")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter alphabet only")]
        public virtual string PurposeOfCertificate { get; set; }

        [Required(ErrorMessage = "value Required")]
        public virtual string WhetherPvtLtd { get; set; }

        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        public virtual string ValueId { get; set; }
        public virtual string ValueName { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter Valid Value")]
        public virtual string NameofOrganisation { get; set; }

        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string OHouseNo { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string OStreetNo { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string OSubLocality { get; set; }

        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        public virtual string OLocalityId { get; set; }
        public virtual string OLocalityName { get; set; }

        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        public virtual string OSubDivCode { get; set; }
        public virtual string OSubDivName { get; set; }

        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        public virtual string ODistrictCode { get; set; }
        public virtual string ODistrictName { get; set; }

        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        public virtual string OStateId { get; set; }
        public virtual string OStateName { get; set; }

        [RequiredIf("WhetherSalaried", "False", ErrorMessage = "Value Required")]
        public virtual string Occupation { get; set; }

        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        public virtual string OContactNo { get; set; }

        [RegularExpression("[0-9]+", ErrorMessage = " InValid Input")]
        [RequiredIf("WhetherSalaried", "False", ErrorMessage = "Value Required")]
        public virtual string AccountNo { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter Valid Value")]
        public virtual string ValuerName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[-_ a-zA-Z0-9]+$", ErrorMessage = "Enter Valid Value")]
        public virtual string ValuerRegistrationNo { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherSalaried { get; set; }

        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        public virtual string OCountryId { get; set; }
        public virtual string OCountryName { get; set; }
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value")]
        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        [RegularExpression(@"^[1-1][1-1][0-9]{4}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string OPinCode { get; set; }

        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Enter Valid Value")]
        public virtual string Designation { get; set; }

        [Required(ErrorMessage = "value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Monthly Income")]//Change20150205
        public virtual string MonthlyIncome { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Z]{5})+([0-9]{4})+([A-Z]{1})?", ErrorMessage = "Enter Valid value")]
        [RequiredIf("WhetherSalaried", "True", ErrorMessage = "Value Required")]
        public virtual string PANNo { get; set; }
        [RequiredIf("WhetherSalaried", "False", ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string TANNo { get; set; }
        [RequiredIf("WhetherSalaried", "False", ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string CSTNo { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string LastActionDate { get; set; }
        public virtual string SHCounter { get; set; }
        public virtual string FNMCounter { get; set; }
        public virtual string FDCounter { get; set; }
        public virtual string SDCounter { get; set; }
        public virtual string StatusId { get; set; }
        public virtual string ApplicationStatusId { get; set; }

        public DataSet ds { get; set; }
        public virtual SolvencyShareholdingDetails SolvencyShareholdingDetails { get; set; }
        public virtual SolvencyAssetsDetails SolvencyAssetsDetails { get; set; }
        public virtual SolvencyCurrentAssetsDetails SolvencyCurrentAssetsDetails { get; set; }

        [CustomProperty]
        public SelectList ServiceTypeMasterList//change20151130 hard coded
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid  and SMVD.valueid in(@Govt,@Pvt)");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.SourceofIncome);
                Cmd.Parameters.AddWithValue("@Govt", 14);
                Cmd.Parameters.AddWithValue("@Pvt", 15);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList BankMasterList
        {
            get
            {
                List<BankMaster> BankMasterList = BankMaster.List<BankMaster>(new Npgsql.NpgsqlCommand("select BankCode,BankName from dbo.BankMaster"));
                return new SelectList(BankMasterList, "BankCode", "BankName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList CountryList
        {
            get
            {
                List<CountryMaster> CountryList = CountryMaster.List<CountryMaster>(new Npgsql.NpgsqlCommand("select CountryId,CountryName from countrymaster where CountryId=1 order by CountryName"));
                return new SelectList(CountryList, "CountryId", "CountryName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList LocalityList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.whetheractive=@whetheractive order by lm.LocalityName");
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList FNMList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid as valueid,SMVD.valuename as valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by SMVD.valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.FixedAndMoveableAssets);
                List<ServiceTypeMaster> FNMList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(FNMList, "valueid", "valuename");
            }
            set { }
        }
    }
}