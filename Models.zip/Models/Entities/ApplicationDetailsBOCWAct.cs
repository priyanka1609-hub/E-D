﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.CustomAttribute;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsBOCWAct : Repositry<ApplicationDetailsBOCWAct>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14, ErrorMessage = "Enter InValid Value")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicationNo { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [StringLength(200, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Please InValid Name")]
        public virtual string Nameofest { get; set; }


        [Required(ErrorMessage = "Value Required")]
        [StringLength(200, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Please InValid Name")]
        public virtual string NameofestCarrying { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string AddressofManager { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Check Box Checked Required")]
        public virtual bool check { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Locationofest { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Typeofest { get; set; }
        [RequiredIf("Typeofest", "362", ErrorMessage = "Required")]
        [RegularExpression(@"^[a-zA-Z0-9]*$", ErrorMessage = "Enter InValid value")]
        public virtual string Typeofestdetails { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Addressofest { get; set; }//change36
        [Required(ErrorMessage = "Value Required")]
        public virtual string AddressofestPostal { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AddressofestLocal { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Please InValid Name")]
        public virtual string Fullnameofest { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Natureofbuilding { get; set; }
        [RequiredIf("Natureofbuilding", "362", ErrorMessage = "Required")]
        public virtual string Natureofbuildingdetails { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Maxworkers { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CommencementDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CompletionDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Amount { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DdNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DdDate { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AppLocalityId { get; set; }
        public virtual string LocalityName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Please InValid Name")]
        public virtual string NameOfEstOwnerCarrying { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string MobileNoOfEstOwnerCarrying { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 8, ErrorMessage = "Enter InValid Value")]
        [DataType(DataType.EmailAddress, ErrorMessage = "Enter valid Email")]
        [RegularExpression(@"[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Enter InValid Email")]
        public virtual string EmailOfEstOwnerCarrying { get; set; }

        [RegularExpression(@"^((?:https?\:\/\/|www\.)(?:[-a-z0-9]+\.)*[-a-z0-9]+.*)$", ErrorMessage = "Enter InValid Website(Ex. www.example.com)")]
        public virtual string WebsiteOfEstOwnerCarrying { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string MobileNoOfEstManagerCarrying { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(100, MinimumLength = 8, ErrorMessage = "Enter InValid Value")]
        [DataType(DataType.EmailAddress, ErrorMessage = "Enter valid Email")]
        [RegularExpression(@"[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Enter InValid Email")]
        public virtual string EmailOfEstManagerCarrying { get; set; }
        public SelectList NatureOfEstList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.NatureOfEstLbr);
                List<SelectValueMaster> NatureOfEstList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(NatureOfEstList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList TypeOfEstList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.TypeOfEstLbr);
                List<SelectValueMaster> TypeOfEstList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(TypeOfEstList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList LocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@Dept and dm.stateid=@stateid and LM.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@Dept", (int)Department.Dept007);
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
    }
}