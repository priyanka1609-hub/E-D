﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Collections.Generic;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsSRCopy : Repositry<ApplicationDetailsSRCopy>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [StringLength(100, MinimumLength = 2), Required(ErrorMessage = "Value Required")]
        public virtual string RegisteredAsNo { get; set; }
        [StringLength(100, MinimumLength = 2), Required(ErrorMessage = "Value Required")]
        public virtual string AddlBookNo { get; set; }
        [StringLength(100, MinimumLength = 2), Required(ErrorMessage = "Value Required")]
        public virtual string VolumeNo { get; set; }
        [StringLength(3, MinimumLength = 1)]
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string PagesFrom { get; set; }
        [StringLength(3, MinimumLength = 1)]
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string PagesTo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string RegisteredDate { get; set; }
        [StringLength(250, MinimumLength = 2), Required(ErrorMessage = "Value Required")]
        public virtual string FirstParty { get; set; }
        [StringLength(250, MinimumLength = 2), Required(ErrorMessage = "Value Required")]
        public virtual string PropertyNo { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public DataTable dt { get; set; }
        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
    }
}