﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
//changes20180912
namespace Edistrict.Models.Entities
{
    public class EnclosureVerificationMaster : Repositry<EnclosureVerificationMaster>
    {
        [Required(ErrorMessage = "Required")]
        public virtual string EnclosureId { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string WhetherVerified { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string VerificationTypeId { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string VerificationDate { get; set; }
    }
}