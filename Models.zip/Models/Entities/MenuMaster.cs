﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using System.Web.Mvc;

namespace Edistrict.Models.Entities
{
    public class MenuMaster : Repositry<MenuMaster>
    {
        public virtual string MenuId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Menutext { get; set; }
        public virtual string Menuaction { get; set; }
        public virtual string Menucontroller { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Head { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Deptcode { get; set; }
        public virtual string DeptName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Permission { get; set; }
        public virtual string PermissionName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Parameter { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherLink { get; set; }
        public virtual string Displayorder { get; set; }
        public virtual string GroupId { get; set; }
        public virtual string RType { get; set; }
        public virtual string[] arrNode { get; set; }
        public SelectList PeersList { get; set; }
        public bool AddAsSubMenu { get; set; }
        public bool AddParameter { get; set; }
        public bool RemoveParameter { get; set; }
        public virtual string TargetMenuName { get; set; }
        public virtual string NoteMessage { get; set; }
        public virtual bool Flag { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ParameterName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ParameterValue { get; set; }
    }
}