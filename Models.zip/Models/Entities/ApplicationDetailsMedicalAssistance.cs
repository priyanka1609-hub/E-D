﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsMedicalAssistance : Repositry<ApplicationDetailsContractor>, IValidatableObject //change22022018
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string Dob { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Check Box Checked Required")]
        public virtual bool check { get; set; }
        public virtual string Whetherexist { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerRegNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Workerdob { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateoffirstpayment { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateofpaylastsubscription { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Firstsubsamount { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Firstsubscription { get; set; }

        
        [Required(ErrorMessage = "Value Required")]
        public virtual string Firstnameofbank{get;set;}
        [Required(ErrorMessage = "Value Required")]
        public virtual string FirstbranchName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Lastsubsamount { get; set; }               
        [Required(ErrorMessage = "Value Required")]
        public virtual string Lastnameofbank { get; set; }        
        [Required(ErrorMessage = "Value Required")]
        public virtual string LastbranchName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Totalamountremitted { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Detailsofdisease { get; set; }
        public virtual string Detailsofdiseaseduetosurgery { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateofadmission { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateofdischarge { get; set; }
        public virtual string Detailsofmedicalbenefit { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string HospitalName { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string HospitalAddress { get; set; }
         //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherPlaster { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string DateOfPlasterFrom { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string DateOfPlasterTo { get; set; }

        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }

        //change 09022018
        [CustomProperty]
        public SelectList BankMasterList
        {
            get
            {
                List<BankMaster> BankMasterList = BankMaster.List<BankMaster>(new Npgsql.NpgsqlCommand("select BankCode,BankName from dbo.BankMaster"));
                return new SelectList(BankMasterList, "BankCode", "BankName");
            }
            set { }
        }

        //change22022018
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (Convert.ToDateTime(Dateofadmission) > Convert.ToDateTime(Dateofdischarge))
            {
                yield return new ValidationResult("Date of admission can not be greater than date of discharge", new string[] { "Dateofadmission" });
            }

            if (Convert.ToDateTime(DateOfPlasterFrom) > Convert.ToDateTime(DateOfPlasterTo))
            {
                yield return new ValidationResult("Date of Plaster from can not be greater than date of Plaster to", new string[] { "DateOfPlasterFrom" });
            }
        }
         
    }
}