﻿using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.Entities
{
    public class SolvencyAssetsDetails: Repositry<SolvencyAssetsDetails>
    {
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }

        public virtual string Id { get; set; }
        public virtual string ValueId { get; set; }
        public virtual string LandAddress { get; set; }
        public virtual string LandArea { get; set; }
        public virtual string LandValue { get; set; }
        public virtual string LandPurchaseDate { get; set; }

        public virtual string Counter { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string LastActionDate { get; set; }
    }
}