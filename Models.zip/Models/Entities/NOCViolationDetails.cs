﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class NOCViolationDetails : Repositry<NOCViolationDetails>
    {
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }

        public virtual string ViolationId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string VillageId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LocalityId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string KhasraNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string RectangleNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ViolationactId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Remarks { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string VDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LandId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SectionId { get; set; }
        public virtual string Whetheractive { get; set; }
        public virtual string ApprovalDate { get; set; }
        public virtual string RType { get; set; }
        public virtual string WhetherDeViolate { get; set; }

        public SelectList VillageList
        {
            get
            {
                //string Qry = "select villageid,villagename from villagemaster order by villagename";
                //NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                //List<VillageMaster> VillageList = VillageMaster.List<VillageMaster>(Cmd);
                //return new SelectList(VillageList, "villageid", "villagename");

                string Qry = "select villageid,villagename from villagemaster where subdivcode=@ParamSubDivCode order by villagename";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                List<VillageMaster> VillageList = VillageMaster.List<VillageMaster>(Cmd);
                return new SelectList(VillageList, "villageid", "villagename");
            }
            set { }
        }

        public SelectList ViolationActList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.NOCViolationAct);
                List<SelectValueMaster> ViolationActList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(ViolationActList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList LandClassificationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.NOCLandClassification);
                List<SelectValueMaster> LandClassificationList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(LandClassificationList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList ViolationSectionList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.NOCViolationSection);
                List<SelectValueMaster> LandClassificationList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(LandClassificationList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
    }
}