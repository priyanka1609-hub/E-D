﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Collections.Generic;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class NfsUpdateBasicDetails : Repositry<NfsUpdateBasicDetails>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "AadhaarNo Required")]
        [StringLength(12, MinimumLength = 12)]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Aadhaar No")]
        public virtual string Aadhaarno { get; set; }
        [StringLength(12, MinimumLength = 12)]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Ration Card No")]
        public virtual string NewRCNo { get; set; }
        [StringLength(14, MinimumLength = 12)]
        public virtual string OldRcNo { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string MobileNo { get; set; }
        public virtual string OccupationCode { get; set; }
        public virtual string OccupationType { get; set; }
        public virtual string ModificationType { get; set; }


        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string HouseNumber { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string StreetNumber { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string SubLocality { get; set; }
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string LocalityId { get; set; }
        public virtual string Localityname { get; set; }
        public virtual string SubDivCode { get; set; }
        public virtual string SubDivName { get; set; }
        public virtual string StateId { get; set; }
        public virtual string StateName { get; set; }
        public virtual string CountryId { get; set; }
        public virtual string CountryName { get; set; }
        public virtual string DistrictCode { get; set; }
        public virtual string DistrictName { get; set; }
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[0-9]{6}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string PinCode { get; set; }
        public virtual string FpsLicenceNo { get; set; }
        public virtual string FpsAddress { get; set; }

        public DataTable dt { get; set; }
        public virtual string StatusId { get; set; }
        [Required(ErrorMessage = "Value  Required")]
        public virtual string FpsId { get; set; }
        public virtual string FpsName { get; set; }
        public virtual string ApplicationStatusId { get; set; }

        public SelectList FpsList { get; set; }
        public SelectList HofList { get; set; }
        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList OccupationMasterList
        {
            get
            {
                List<OccupationMaster> OccupationMasterList = OccupationMaster.List<OccupationMaster>(new Npgsql.NpgsqlCommand("select OccupationId,OccupationType from dbo.OccupationMaster order by OccupationType"));
                return new SelectList(OccupationMasterList, "OccupationId", "OccupationType");
            }
            set { }
        }
        
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }        
    }
}