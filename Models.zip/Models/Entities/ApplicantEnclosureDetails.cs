﻿using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using System.Collections.Generic;
using System.Web.Mvc;

namespace Edistrict.Models.Entities
{
    public class ApplicantEnclosureDetails : Repositry<ApplicantEnclosureDetails>
    {
        public virtual System.Nullable<int> ReferenceEnclosureId { get; set; }
        public virtual System.Nullable<int> EnclosureId { get; set; }
        public virtual string OtherDepartment { get; set; }
        [RegularExpression("([0-9]+)")]
        [Required(ErrorMessage = "Value Required")]
        public virtual string DocumentId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DocumentNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DepartmentId { get; set; }
        public virtual string DeptName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual byte[] DocumentData { get; set; }
        public virtual string ContentType { get; set; }
        public virtual string RelatedId { get; set; }
        public virtual string WhetherVerified { get; set; }
        public virtual string WhetherActive { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string LastActionDate { get; set; }
        public virtual string DocumentEntryDate { get; set; }
        public virtual string DocumentDetails { get; set; }
        public virtual string VerifyValue { get; set; }

        public IEnumerable<SelectListItem> DocumentNoList = new List<SelectListItem>();
        public bool flag { get; set; }
    }
}