﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.CustomAttribute;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsCLAct : Repositry<ApplicationDetailsCLAct>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicationNo { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [StringLength(200, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Please InValid Name")]
        public virtual string Nameofest { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [StringLength(200, MinimumLength = 2, ErrorMessage = "Enter InValid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Address")]
        public virtual string Locationofest { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Address")]
        public virtual string Addressofest { get; set; }

        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Address")]
        public virtual string LocalAddressofest { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Check Box Checked Required")]
        public virtual bool check { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Please InValid Name")]
        public virtual string Fullnameofpe { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Address")]
        public virtual string Peaddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z])\s)|([A-Za-z]))*([A-Za-z])+$", ErrorMessage = "Please InValid Name")]
        public virtual string Fullnameofmanager { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Address")]
        public virtual string Manageraddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Natureofest { get; set; }
        [RequiredIf("Natureofest", "362", ErrorMessage = "Required")]
        public virtual string Natureofestdetails { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string TreasuryName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Treasuryamount { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string TreasuryDate { get; set; }
        public virtual string CCounter { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AppLocalityId { get; set; }
        public virtual string LocalityName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Enter In InValid Email")]
        public virtual string EmailOfEst { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string MobileNoOfEst { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^((?:https?\:\/\/|www\.)(?:[-a-z0-9]+\.)*[-a-z0-9]+.*)$", ErrorMessage = "Enter InValid Website(Ex. www.example.com)")]
        public virtual string WebsiteOfEst { get; set; }
        public virtual string CId { get; set; }
        public virtual string IdDocId { get; set; }
        public virtual string IdDocNo { get; set; }
        public virtual string IdDocName { get; set; }
        public virtual string ContractorName { get; set; }
        public virtual string Contractoraddress { get; set; }
        public virtual string Natureofwork { get; set; }
        public virtual string Maxworkers { get; set; }
        public virtual string EstDate { get; set; }

        public DataTable dt { get; set; }

        public SelectList DocumentAvailableForContractors
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select DocumentId,DocumentName from dbo.DocumentMaster where DocumentId in (@DrivingLicense,@VoterID,@PANCard,@Passport,@RationCard,@StudentId,@Birth)");
                Cmd.Parameters.AddWithValue("@DrivingLicense", (int)DocumentId.DrivingLicense);
                Cmd.Parameters.AddWithValue("@VoterID", (int)DocumentId.VoterID);
                Cmd.Parameters.AddWithValue("@PANCard", (int)DocumentId.PANCard);
                Cmd.Parameters.AddWithValue("@Passport", (int)DocumentId.Passport);
                Cmd.Parameters.AddWithValue("@RationCard", (int)DocumentId.RationCard);
                Cmd.Parameters.AddWithValue("@StudentId", (int)DocumentId.StudentId);
                Cmd.Parameters.AddWithValue("@Birth", (int)DocumentId.BirthCertificate);
                List<DocumentMaster> DocumentMasterList = DocumentMaster.List<DocumentMaster>(Cmd);
                return new SelectList(DocumentMasterList, "DocumentId", "DocumentName");
            }
            set { }
        }
        public SelectList NatureOfEstList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.NatureOfEstLbr);
                List<SelectValueMaster> NatureOfEstList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(NatureOfEstList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList LocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@Dept and dm.stateid=@stateid and LM.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@Dept", (int)Department.Dept007);
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
    }
}