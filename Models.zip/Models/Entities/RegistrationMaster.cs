﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;

namespace Edistrict.Models.Entities
{
    public class RegistrationMaster : Repositry<RegistrationMaster>
    {
        [ScaffoldColumn(false)]
        public virtual System.Nullable<int> RegistrationID { get; set; }
        [StringLength(12, MinimumLength = 12, ErrorMessage = "Enter Valid AADHAAR"), Required(ErrorMessage = "AADHAAR No. Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid AADHAAR")]
        public virtual string AadhaarNo { get; set; }
        public virtual string DocumentNo { get; set; }
        [Required(ErrorMessage = "Name Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string ApplicantName { get; set; }
        [StringLength(1), Required(ErrorMessage = "Gender Required")]
        public virtual string ApplicantGender { get; set; }
        [Required(ErrorMessage = "Father Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Father Name")]
        public virtual string AadharApplicantFatherName { get; set; }
        [Required(ErrorMessage = "Father Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Father Name")]
        public virtual string ApplicantFatherName { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid  Mother Name")]
        public virtual string ApplicantMotherName { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter valid Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid  Spouse Name")]
        public virtual string ApplicantSpouseName { get; set; }
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string AadharApplicantDOB { get; set; }
        [DataType(DataType.Date)]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string ApplicantDOB { get; set; }
        [Required(ErrorMessage = "Relation Required")]
        public virtual string ApplicantRelationId { get; set; }
        
        public virtual string AadharApplicantAddress { get; set; }
        [StringLength(100, MinimumLength = 2), Required(ErrorMessage = "House No Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicantHouseNumber { get; set; }
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Street No Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicantStreetNumber { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Sublocality Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicantSubLocality { get; set; }
        [Required(ErrorMessage = "PinCode required")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter valid Name")]
        [RegularExpression(@"^[0-9]{6}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string AadharApplicantPinCode { get; set; }
        [Required(ErrorMessage = "PinCode required")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter valid Name")]
        [RegularExpression(@"^[0-9]{6}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string ApplicantPinCode { get; set; }
        [Required(ErrorMessage = "Locality Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Locality")]
        public virtual string ApplicantLocalityId { get; set; }

        [Required(ErrorMessage = "SubDivision Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid SubDivision")]
        public virtual string ApplicantSubDivCode { get; set; }
        [Required(ErrorMessage = "District Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid District")]
        public virtual string ApplicantDistrictCode { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string ApplicantMobileNo { get; set; }
        [Required(ErrorMessage = "Address Required")]
        [StringLength(500, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        //[RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicantPermanentAddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherSameAddress { get; set; }
        [StringLength(100, MinimumLength = 8)]
        [DataType(DataType.EmailAddress, ErrorMessage = "Enter valid Email")]
        [RegularExpression(@"[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Enter valid Email")]
        public virtual string ApplicantEmail { get; set; }
        public virtual string documentstatusid { get; set; }
        public virtual byte[] ApplicantPhoto { get; set; }
        public virtual string ApplicantUserID { get; set; }
        public virtual string ApplicantPassword { get; set; }
        public virtual string ApplicantAccessCode { get; set; }
        public virtual string RegistrationDate { get; set; }
        public virtual string StateId { get; set; }
        public virtual string ApplicantStateId { get; set; }
        public virtual string StateName { get; set; }
        public virtual string ApplicantCountryId { get; set; }
        public virtual string CountryId { get; set; }
        public virtual string SubDivDescription { get; set; }
        public virtual string DistrictName { get; set; }
        public virtual string CountryName { get; set; }

        public virtual string CompleteAddress { get; set; }

        public virtual string ApplicantIpAddress { get; set; }
        public virtual string LastActionPerformed { get; set; }
        public virtual string WhetherPasswordChange { get; set; }
        public virtual string WhetherOtherState { get; set; }
    }
}