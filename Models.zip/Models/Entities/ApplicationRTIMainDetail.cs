﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Collections.Generic;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class ApplicationRTIMainDetail : Repositry<ApplicationRTIMainDetail>
    {
        
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual string DeptCode { get; set; }
        public virtual string AssignedTo { get; set; }
        public virtual string DeptName { get; set; }
        public virtual string QCounter { get; set; }
        public ApplicationRTIQuestionDetail ApplicationRTIQuestionDetail { get; set; }
        public ApplicationDetailsRTIAns ApplicationDetailsRTIAns { get; set; }
        public DataTable dt { get; set; }
        [CustomProperty]
        public SelectList RTIDeptList
        {
            get
            {
                List<DeptMaster> DeptList = DeptMaster.List<DeptMaster>(new Npgsql.NpgsqlCommand("select DeptCode,DeptName from DeptMaster where WhetherRTIDept=True order by DeptName"));
                return new SelectList(DeptList, "DeptCode", "DeptName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList RTIPIOtList
        {
            get
            {
                List<UserMaster> PIOList = UserMaster.List<UserMaster>(new Npgsql.NpgsqlCommand("select UserId,Username from dbo.UserMaster"));
                return new SelectList(PIOList, "UserId", "Username");
            }
            set { }
        }
       

    }
}