﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsGrantofWork : Repositry<ApplicationDetailsGrantofWork>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual string Whetherexist { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WorkerRegNo { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameoffather { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofhusband { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Residentialaddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BeneficiaryName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Beneficiaryaddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string RegNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateofreg { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Districtcode { get; set; }
        public virtual string DistrictName { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Gender { get; set; }
        [RequiredIf("Gender", "M", ErrorMessage = "Value Required")]
        public virtual string WifeName { get; set; }
        [RequiredIf("Gender", "M", ErrorMessage = "Value Required")]
        public virtual string Wifepresentaddress { get; set; }
        [RequiredIf("Gender", "F", ErrorMessage = "Value Required")]
        public virtual string HusbandName { get; set; }
        [RequiredIf("Gender", "F", ErrorMessage = "Value Required")]
        public virtual string Husbandpresentaddress { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string BankCode { get; set; }
        public virtual string BankName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Applicantdob { get; set; }
        
        //change22022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)",ErrorMessage="Enter only numbers")]
        public virtual string Monthlyincome { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherownprop { get; set; }
        [RequiredIf("Whetherownprop", "True", ErrorMessage = "Value Required")]
        public virtual string Detailsofprop { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Whethersalarycerti { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Description { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Make { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Model { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string Costoftools { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofsupplier { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Addressofsupplier { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateofmembcomp { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateofremitreg { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Dateofagecomp { get; set; }

        //change22022018
        [Required(ErrorMessage = "Value Required"), RegularExpression("([0-9]+)", ErrorMessage = "Enter only numbers")]
        public virtual string Grantamount { get; set; }


        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountHolderName { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string AccountNo { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string MICRCode { get; set; }
        //change22022018
        [Required(ErrorMessage = "Value Required")]
        public virtual string BranchAddress { get; set; }
      

        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList DistrictList
        {
            get
            {
                string Qry = "select DistrictCode,DistrictName from DistrictMaster where deptcode=@DeptCode order by DistrictName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@DeptCode", (int)Department.Dept016);
                List<DistrictMaster> DistrictList = DistrictMaster.List<DistrictMaster>(Cmd);
                return new SelectList(DistrictList, "DistrictCode", "DistrictName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList BankMasterList
        {
            get
            {
                List<BankMaster> BankMasterList = BankMaster.List<BankMaster>(new Npgsql.NpgsqlCommand("select BankCode,BankName from dbo.BankMaster"));
                return new SelectList(BankMasterList, "BankCode", "BankName");
            }
            set { }
        }
       
    }
}