﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsDFBScheme : Repositry<ApplicationDetailsDFBScheme>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MlaconstituencyId { get; set; }
        public virtual string ConstituencyName { get; set; }
        public virtual string DistrictName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherscst { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Religion { get; set; }
        public virtual string ReligionName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string BankaccNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Bankcode { get; set; }
        public virtual string BankName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Branchaddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Micrcode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Annualsalary { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [Range(18, 60, ErrorMessage = "Age of the Deceased should be between 18 to 60 years.")]
        public virtual string Hofageatdeath { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DeathDate { get; set; }
        public virtual int TableWidth { get; set; }
        [RequiredIf("MICRCode", null, ErrorMessage = "IFSC Code Required")]
        [StringLength(11, ErrorMessage = "IFSC Code must be of 11 digits. ", MinimumLength = 11)]
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        [Required(ErrorMessage = "Stay Period Validation Required")]
        public virtual string WhetherStayPeriodValid { get; set; }
        [RequiredIf("WhetherStayPeriodValid", "False", ErrorMessage = "Witness Type Required")]
        public virtual string Witness1TypeId { get; set; }
        public virtual string Witness1_Type { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("WhetherStayPeriodValid", "False", ErrorMessage = "Witness Name Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string Witness1Name { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("Witness1TypeId", "5", ErrorMessage = "Witness Name Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string Witness1Name1 { get; set; }
        [RequiredIf("WhetherStayPeriodValid", "False", ErrorMessage = "Witness Type Required")]
        public virtual string Witness2TypeId { get; set; }
        public virtual string Witness2_Type { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("WhetherStayPeriodValid", "False", ErrorMessage = "Witness Name Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string Witness2Name { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("Witness2TypeId", "5", ErrorMessage = "Witness Name Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string Witness2Name2 { get; set; }

        [CustomProperty]
        public SelectList ConstituencyList
        {
            get
            {
                List<AssemblyConstituencyMaster> ConstituencyList = AssemblyConstituencyMaster.List<AssemblyConstituencyMaster>(new Npgsql.NpgsqlCommand("select ConstituencyID,ConstituencyName from dbo.AssemblyConstituencyMaster order by ConstituencyName"));
                return new SelectList(ConstituencyList, "ConstituencyID", "ConstituencyName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList ReligionList
        {
            get
            {
                List<ReligionMaster> ReligionList = ReligionMaster.List<ReligionMaster>(new Npgsql.NpgsqlCommand("select ReligionId,ReligionName from dbo.ReligionMaster order by ReligionName"));
                return new SelectList(ReligionList, "ReligionId", "ReligionName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList WitnessTypeMasterList
        {
            get
            {
                List<WitnessTypeMaster> WitnessTypeMasterList = WitnessTypeMaster.List<WitnessTypeMaster>(new Npgsql.NpgsqlCommand("select WitnessTypeId,WitnessTypeName from dbo.WitnessTypeMaster"));
                return new SelectList(WitnessTypeMasterList, "WitnessTypeId", "WitnessTypeName");
            }
            set { }
        }
    }
}