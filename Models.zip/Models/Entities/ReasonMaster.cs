﻿using System;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class ReasonMaster : Repositry<ReasonMaster>
    {
        public virtual string ReasonCode { get; set; }
        public virtual string ReasonDetail { get; set; }
        
    }
}