﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsRenewalContractor : Repositry<ApplicationDetailsRenewalContractor>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofconest { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nameofcon { get; set; }
        public virtual string Fnameofcon { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Mobilenoofcon { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Emailofcon { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Addressofcon { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Localaddressofcon { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Websiteofcon { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Natureofwork { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CommencementDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CompletionDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ManagerName { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string ManagerMobileNo { get; set; }
        [StringLength(100, MinimumLength = 8)]
        [DataType(DataType.EmailAddress, ErrorMessage = "Enter valid Email")]
        [RegularExpression(@"[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,4}", ErrorMessage = "Enter valid Email")]
        public virtual string ManagerEmail { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Manageraddr { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [Range(20, 999, ErrorMessage = "Enter Minimum Workers 20")]
        public virtual string Maxworkers { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherconvicted { get; set; }

        [RequiredIf("Whetherconvicted", "True", ErrorMessage = "Details Required")]
        public virtual string Convictiondetails { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherlicensesuspend { get; set; }
        [RequiredIf("Whetherlicensesuspend", "True", ErrorMessage = "Required")]
        public virtual string SuspensionorderNo { get; set; }
        [RequiredIf("Whetherlicensesuspend", "True", ErrorMessage = "Required")]
        public virtual string SuspensionorderDate { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string PeapplicationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PestName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Pestaddress { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Peaddress { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Petype { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AppLocalityId { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string OldcertificateNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string OldcertificateDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherexist { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherextensionrequired { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string UserId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Ipaddress { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LastactionDate { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Check Box Checked Required")]
        public virtual bool check { get; set; }
        public virtual string LocalityName { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [RequiredIf("WhetherApplAmend", "True", ErrorMessage = "Required")]//Changes170119
        public virtual string Whetherworkerincreased { get; set; }
        [RequiredIf("Whetherworkerincreased", "True", ErrorMessage = "Required")]
        public virtual string Increasedworker { get; set; }

        [Required(ErrorMessage = "Value Required")]
        ///public virtual string DistrictCode { get; set; }//changes040119
        public virtual string SubDivCode { get; set; }
        public virtual string SubDivCodeName { get; set; }//changes040119
        //public virtual string DistrictName { get; set; }//changes040119
        [Required(ErrorMessage = "Value Required")]
        public virtual string AddContractWork { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherApplRenewal { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherApplAmend { get; set; }
        [RequiredIf("WhetherApplAmend", "True", ErrorMessage = "Required")]//Changes170119
        public virtual string WhetherChangeRequired { get; set; }
        [RequiredIf("WhetherChangeRequired", "True", ErrorMessage = "Required")]
        public virtual string NewNameContEst { get; set; }
        [RequiredIf("WhetherChangeRequired", "True", ErrorMessage = "Required")]
        public virtual string NewAddressContEst { get; set; }

        [RequiredIf("WhetherApplAmend", "True", ErrorMessage = "Required")]//Changes170119
        public virtual string WhetherChangeNatWork { get; set; }
        [RequiredIf("WhetherChangeNatWork", "True", ErrorMessage = "Required")]
        public virtual string NewNatureofWork { get; set; }
        public virtual string ExpiryDate { get; set; }
        public virtual string pename { get; set; }

        [CustomProperty]
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList LocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@Dept and dm.stateid=@stateid and LM.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@Dept", (int)Department.Dept007);
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        public SelectList LocalityListPlace
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@Dept and dm.stateid=@stateid and LM.whetheractive=@whetheractive order by lm.LocalityName Limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@Dept", (int)Department.Dept007);
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        public SelectList SubDivcodeList
        {
            get
            {
                string Qry = "Select SubDivCode,SubDivDescription from SubDivMaster SM Inner Join DistrictMaster DM on DM.DistrictCode=SM.DistrictCode Where DM.StateId=@StateId and DM.DeptCode=@DeptCode order by SubDivDescription";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@DeptCode", (int)Department.Dept007);
                Cmd.Parameters.AddWithValue("@StateId", (int)CountList.Type007);
                List<SubDivMaster> SubDivcodeList = SubDivMaster.List<SubDivMaster>(Cmd);
                return new SelectList(SubDivcodeList, "SubDivCode", "SubDivDescription");
            }
            set { }
        }
    }
}