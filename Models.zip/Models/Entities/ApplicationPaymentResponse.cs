﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class ApplicationPaymentResponse : Repositry<ApplicationPaymentResponse>
    {
        public virtual string TransactionId { get; set; }
        public virtual string PaymentId { get; set; }
        public virtual string MerchantOrderNo { get; set; }
        public virtual string GatewayReferenceId { get; set; }
        public virtual string PaymentStatus { get; set; }
        public virtual string PaymentStatusId { get; set; }
        public virtual string PaymentAmount { get; set; }
        public virtual string PaymentCurrency { get; set; }
        public virtual string PaymentMode { get; set; }
        public virtual string OtherDetails { get; set; }
        public virtual string TransactionReason { get; set; }
        public virtual string BankCode { get; set; }
        public virtual string BankReferenceNo { get; set; }
        public virtual string TransactionDate { get; set; }
        public virtual string TransactionCountry { get; set; }
        public virtual string TransactionCin { get; set; }
        public virtual string ActionDate { get; set; }
        public virtual string ActionUserId { get; set; }
        public virtual string AtionIpAddress { get; set; }

        public virtual string ApplicationId { get; set; }
        public virtual string ApplicationNo { get; set; }
    }
}