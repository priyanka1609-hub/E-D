﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class ApplicationLetterDetails : Repositry<ApplicationLetterDetails>
    {
        public virtual string RowNumber { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string TypeValueId { get; set; }
        [RequiredIf("WhetherGazettedRequired", true, ErrorMessage = "Officer Name Required")]
        public virtual string OfficerName { get; set; }
        [RequiredIf("WhetherGazettedRequired", true, ErrorMessage = "Officer Designation Required")]
        public virtual string OfficerDesignation { get; set; }
        [RequiredIf("WhetherGazettedRequired", true, ErrorMessage = "Officer Department Name Required")]
        public virtual string OfficerDepartmentName { get; set; }
        [RequiredIf("WhetherGazettedRequired", true, ErrorMessage = "Officer Telephone No Required")]
        [RegularExpression("([0-9]+)")]
        [StringLength(11, MinimumLength = 11, ErrorMessage = "Enter Valid Officer Telephone No.")]
        public virtual string OfficerTelephoneNo { get; set; }
        [RequiredIf("WhetherGazettedRequired", true, ErrorMessage = "Officer Mobile No Required")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string OfficerMobileNo { get; set; }
        [RequiredIf("WhetherGazettedRequired", true, ErrorMessage = "Officer Address Required")]
        public virtual string OfficerAddress { get; set; }
        [CustomProperty]
        public virtual string WhetherGazettedRequired { get; set; }
        public DataTable dt { get; set; }
    }
}