﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class WitnessIdentityTypeMaster : Repositry<WitnessIdentityTypeMaster>
    {
        public virtual string WitnessIdentityTypeId { get; set; }
        public virtual string WitnessIdentityType { get; set; }
    }
}