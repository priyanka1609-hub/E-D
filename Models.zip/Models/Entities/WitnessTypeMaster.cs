﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class WitnessTypeMaster : Repositry<WitnessTypeMaster>
    {
        public virtual string WitnessTypeId { get; set; }
        public virtual string WitnessTypeName { get; set; }
        public virtual string WhetherActive { get; set; }
    }
}