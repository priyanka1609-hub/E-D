﻿using System;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.Entities
{
    public class VenueMaster : Repositry<VenueMaster>
    {
        public virtual string VenueId { get; set; }
        public virtual string VenueName { get; set; }
        public virtual string VenueAddress { get; set; }
    }
}