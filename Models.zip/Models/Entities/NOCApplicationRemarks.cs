﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class NOCApplicationRemarks : Repositry<NOCApplicationRemarks>
    {

        [Required(ErrorMessage = "Value Required")]
        public virtual string Whethervsec81t { get; set; }
        [RequiredIf("Whethervsec81t", "Y", ErrorMessage = "Please Fill Remarks")]
        public virtual string Whethervsec81remarkst { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whethervsec33t { get; set; }
        [RequiredIf("Whethervsec33t", "Y", ErrorMessage = "Please Fill Remarks")]
        public virtual string Whethervsec33remarkst { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherlfsec74t { get; set; }
        [RequiredIf("Whetherlfsec74t", "Y", ErrorMessage = "Please Fill Remarks")]
        public virtual string Whetherlfsec74remarkst { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetheranystayt { get; set; }
        [RequiredIf("Whetheranystayt", "Y", ErrorMessage = "Please Fill Remarks")]
        public virtual string Whetheranystayremarkst { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetheranyobjt { get; set; }
        [RequiredIf("Whetheranyobjt", "Y", ErrorMessage = "Please Fill Remarks")]
        public virtual string Whetheranyobjremarkst { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whethernsec4nt { get; set; }
        [RequiredIf("Whethernsec4nt", "Y", ErrorMessage = "Please Fill Remarks")]
        public virtual string Whethernsec4remarksnt { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whethernsec6nt { get; set; }
        [RequiredIf("Whethernsec6nt", "Y", ErrorMessage = "Please Fill Remarks")]
        public virtual string Whethernsec6remarksnt { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherldenotifynt { get; set; }
        [RequiredIf("Whetherldenotifynt", "Y", ErrorMessage = "Please Fill Remarks")]
        public virtual string Whetherldenotifyremarksnt { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherapquestnt { get; set; }
        [RequiredIf("Whetherapquestnt", "Y", ErrorMessage = "Please Fill Remarks")]
        public virtual string Whetherapquestremarksnt { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherlitigationnt { get; set; }
        [RequiredIf("Whetherlitigationnt", "Y", ErrorMessage = "Please Fill Remarks")]
        public virtual string Whetherlitigationremarksnt { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string PermReqFor { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicableAct { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ClassificationOfLand { get; set; }
        public virtual string TEHObs { get; set; }
        public virtual string NTEHObs { get; set; }

        public SelectList PermissionRequiredList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.PermissionRequiredList);
                List<SelectValueMaster> LBRPaymentOptions = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(LBRPaymentOptions, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList LandClassificationList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.NOCLandClassification);
                List<SelectValueMaster> LandClassificationList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(LandClassificationList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList ApplicableActList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.NOCViolationAct);
                List<SelectValueMaster> ViolationActList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(ViolationActList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
    }
}