﻿using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using Npgsql;
using System.Collections.Generic;
using System.Web;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class VerifierWitnessMaster : Repositry<VerifierWitnessMaster>
    {
        public virtual System.Nullable<int> WitnessId { get; set; }
        public virtual string ApplicationNo { get; set; }
        [CustomProperty]
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        public virtual string WitnessName { get; set; }
        [CustomProperty]
        [Required(ErrorMessage = "Value Required")]
        public virtual string WitnessGender { get; set; }
        [Required(ErrorMessage = "House No Required")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string HouseNo { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string StreetNo { get; set; }
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string SubLocality { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SubDivCode { get; set; }
        public virtual string SubDivName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LocalityId { get; set; }
        public virtual string LocalityName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DistrictCode { get; set; }
        public virtual string DistrictName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string StateId { get; set; }
        public virtual string StateName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CountryId { get; set; }
        public virtual string CountryName { get; set; }
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "PinCode required")]
        [RegularExpression(@"^[1-1][1-1][0-9]{4}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string PinCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DocumentId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string RelationId { get; set; }
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z])*$", ErrorMessage = "Enter Valid Value")]
        public virtual string WitnessAddress { get; set; }
        [CustomProperty]
        [Required(ErrorMessage = "Value Required")]
        public virtual string DocumentName { get; set; }
        [CustomProperty]
        [Required(ErrorMessage = "Value Required")]
        public virtual string DocumentNo { get; set; }
        //[Required(ErrorMessage = "Photo Required")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg" }, MaxContentLength = (int)LengthList.AppLength, MaxFileLength = (int)LengthList.AppPhoto, ErrorMessage = "Invalid / Maximum length File")]
        public virtual HttpPostedFileBase Photo { get; set; }
        //[Required(ErrorMessage = "Enclosure Required")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public virtual HttpPostedFileBase Enclosure { get; set; }
        public List<VerifierWitnessMaster> VerifierWitnessMasterDetails { get; set; }
        [CustomProperty]
        public virtual string RowNumber { get; set; }
        [CustomProperty]
        public virtual string ServiceCode { get; set; }
        [CustomProperty]
        public SelectList WitnessRelationList
        {
            get
            {
                NpgsqlCommand Cmd = new Npgsql.NpgsqlCommand("select valueid as RelationId,valuename as RelationName from dbo.selectmastervaluedetails where valueid=@valueid order by valuename");
                Cmd.Parameters.AddWithValue("@valueid", (int)RelatedTo.Neighbor);
                List<RelationMaster> WitnessRelationList = RelationMaster.List<RelationMaster>(Cmd);
                return new SelectList(WitnessRelationList, "RelationId", "RelationName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList WitnessDocumentList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select DM.DocumentId,DM.DocumentName from DocumentMaster DM inner join DocumentToTypeMaster DTTM  on DM.DocumentId=DTTM.DocumentId inner Join DocumentTypeMaster DTM on DTM.DocumentTypeId=DTTM.DocumentTypeId where  DTM.DocumentTypeId=@DocumentTypeId");
                Cmd.Parameters.AddWithValue("@DocumentTypeId", (int)DocumentTypeId.IdentityProof);
                List<DocumentMaster> WitnessDocumentList = DocumentMaster.List<DocumentMaster>(Cmd);
                return new SelectList(WitnessDocumentList, "DocumentId", "DocumentName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList LocalityList
        {
            get
            {
                string DeptCode = Utility.GetDeptCode(ServiceCode);

                NpgsqlCommand Cmd = new NpgsqlCommand("select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.whetheractive=@whetheractive order by lm.LocalityName");
                Cmd.Parameters.AddWithValue("@deptcode", DeptCode);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
    }
}