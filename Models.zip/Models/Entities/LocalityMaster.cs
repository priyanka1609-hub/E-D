﻿using System;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.Entities
{
    public class LocalityMaster : Repositry<LocalityMaster>
    {
        public virtual string LocalityId { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string LocalityName { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string SubDivCode { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string DistrictCode { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string StateId { get; set; }
        public virtual string Remarks { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string ConstituencyId { get; set; }
    }
}