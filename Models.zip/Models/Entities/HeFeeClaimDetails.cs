﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.CustomAttribute;

namespace Edistrict.Models.Entities
{
    public class HeFeeClaimDetails : Repositry<HeFeeClaimDetails>
    {
        [Required(ErrorMessage = "Value Required")]
        public virtual string FeePaidMode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FeePaidNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Feepaid { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FeePaidDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AcademicSession { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ReceiptNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ReceiptDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string CourseId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string InstitutionId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string UniversityId { get; set; }


        public SelectList FeeModeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.HeFeePaidMode);
                List<SelectValueMaster> FeeModeList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(FeeModeList, "SelectValueId", "SelectValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList CourseList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select HecourseId,CourseName from dbo.hecoursemaster where ServiceCode=@ServiceCode order by CourseName");
                Cmd.Parameters.AddWithValue("@ServiceCode", (int)ServiceList.HigherEducationSKGS);
                List<CourseMaster> CourseList = CourseMaster.List<CourseMaster>(Cmd);
                return new SelectList(CourseList, "HeCourseId", "CourseName");
            }
            set { }
        }
        public virtual SelectList AcademicSessionList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int curryear = DateTime.Now.Year - 1;
                int passedyear = curryear - 1;

                for (int i = passedyear; i <= curryear; i++)
                {
                    list.Add(new SelectListItem() { Text = passedyear.ToString() + "-" + (passedyear + 1).ToString(), Value = passedyear.ToString() });
                    passedyear = passedyear + 1;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }

    }
}