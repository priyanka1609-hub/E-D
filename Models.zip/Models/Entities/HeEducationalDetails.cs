﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using Edistrict.Models.ApplicationService;

namespace Edistrict.Models.Entities
{
    public class HeEducationalDetails : Repositry<HeEducationalDetails>
    {
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string ApplicationId { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string ExaminationId { get; set; }
        public virtual string ExaminationType { get; set; }

        public virtual string SchoolCategoryId { get; set; }
        public virtual string SchoolCategoryType { get; set; }

        public virtual string InstitutionId { get; set; }
        public virtual string InstitutionType { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string InstitutionDetails { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string InstitutionAddress { get; set; }


        [Required(ErrorMessage = "Value Required")]
        public virtual string BoardId { get; set; }
        public virtual string BoardType { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string BoardDetails { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PassingYear { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MarkPercentage { get; set; }
        public virtual string InstId { get; set; }

    }
}