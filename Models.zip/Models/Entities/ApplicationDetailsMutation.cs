﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using Edistrict.Models.ApplicationService;
using System.Web.Mvc;
using System.Collections.Generic;
using Edistrict.Models.CustomAttribute;
using Npgsql;
using System.Data;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsMutation : Repositry<ApplicationDetailsMutation>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string VillageId { get; set; }
        public virtual string VillageName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DistrictCode { get; set; }
        public virtual string DistrictName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string SubDivCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PropertyDeatils { get; set; }
        public virtual string SubDivName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string KhataId { get; set; }
        public virtual string KhataType { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string MutationTypeId { get; set; }
        public virtual string MutationType { get; set; }

        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("MutationTypeId", "690", ErrorMessage = "Selection Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter Valid Value")]
        public virtual string VrDeceasedName { get; set; }
        [RequiredIf("MutationTypeId", "690", ErrorMessage = "Selection Required")]
        public virtual string VrRelationshipId { get; set; }
        public virtual string VrRelationship { get; set; }
        [RequiredIf("MutationTypeId", "690", ErrorMessage = "Selection Required")]
        public virtual string VrDeathCertificateNo { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("MutationTypeId", "690", ErrorMessage = "Selection Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string VrCertificateDate { get; set; }
        [RequiredIf("MutationTypeId", "690", ErrorMessage = "Selection Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string VrCertificateDetails { get; set; }

        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("MutationTypeId", "691", ErrorMessage = "Selection Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter Valid Value")]
        public virtual string VsDeceasedName { get; set; }
        [RequiredIf("MutationTypeId", "691", ErrorMessage = "Selection Required")]
        public virtual string VsRelationshipId { get; set; }
        public virtual string VsRelationship { get; set; }
        [RequiredIf("MutationTypeId", "691", ErrorMessage = "Selection Required")]
        public virtual string VsDeathCertificateNo { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("MutationTypeId", "691", ErrorMessage = "Selection Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string VsCertificateDate { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("MutationTypeId", "691", ErrorMessage = "Selection Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter Valid Value")]
        public virtual string VsFirstWitness { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RequiredIf("MutationTypeId", "691", ErrorMessage = "Selection Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter Valid Value")]
        public virtual string VsSecondWitness { get; set; }



        [RequiredIf("MutationTypeId", "692", ErrorMessage = "Selection Required")]
        [RegularExpression("([0-9]+)")]
        public virtual string CoCaseNo { get; set; }
        [RequiredIf("MutationTypeId", "692", ErrorMessage = "Selection Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string CoCourtName { get; set; }
        [RequiredIf("MutationTypeId", "692", ErrorMessage = "Selection Required")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string CoCaseTitle { get; set; }
        [RequiredIf("MutationTypeId", "692", ErrorMessage = "Selection Required")]
        [StringLength(10, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string CoOrderNo { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RequiredIf("MutationTypeId", "692", ErrorMessage = "Selection Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string CoOrderDate { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string CmSubRegistrarId { get; set; }
        public virtual string CmSubRegistrar { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)")]
        public virtual string CmDeedNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string CmRegistrationDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(10, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string CmRegistrationYear { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter Valid Value")]
        public virtual string CmFirstPartyName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter Valid Value")]
        public virtual string CmSecondPartyName { get; set; }
        [RequiredIf("MutationTypeId", "689", ErrorMessage = "Selection Required")]
        public virtual string ConsiderationAmount { get; set; }

        public virtual string ApplicationStatusId { get; set; }
        public DataTable dataseta { get; set; }

        [CustomProperty]
        public SelectList MutationTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.MutationType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList SRList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SrCode as ValueId,SrName as ValueName from dbo.srofficemaster");
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }

        [CustomProperty]
        public SelectList RelationMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.MutationRelation);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList KhataList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Select", Value = "" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList VillageList
        {
            get
            {
                string Qry = "select VillageId,VillageName from VillageMaster where 1=1 ";
                if (Sessions.getEmployeeUser() != null)
                { Qry += " and SubDivCode=@ParamSubDivCode "; }
                Qry += " order by VillageName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                if (Sessions.getEmployeeUser() != null)
                {
                    if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode))
                    {
                        Cmd.Parameters.AddWithValue("@ParamSubDivCode", Sessions.getEmployeeUser().SubDivCode);
                    }
                }
                List<VillageMaster> VillageMasterList = VillageMaster.List<VillageMaster>(Cmd);
                return new SelectList(VillageMasterList, "VillageId", "VillageName");
            }
            set { }
        }
    }
}