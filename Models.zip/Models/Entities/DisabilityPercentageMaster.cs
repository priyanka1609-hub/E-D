﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class DisabilityPercentageMaster : Repositry<DisabilityPercentageMaster>
    {
        public virtual string DPercentageId { get; set; }
        public virtual string DPercentageName { get; set; }
        public virtual string WhetherActive { get; set; }
    }
}