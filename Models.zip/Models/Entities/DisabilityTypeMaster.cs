﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class DisabilityTypeMaster : Repositry<DisabilityTypeMaster>
    {
        public virtual string DisabilityTypeId { get; set; }
        public virtual string DisabilityTypeName { get; set; }
        public virtual string WhetherActive { get; set; }
    }
}