﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;

namespace Edistrict.Models.Entities
{
    public class MigrationMembersDetails : Repositry<MigrationMembersDetails>
    {
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        public virtual string ApplicationNo { get; set; }
        public virtual string MemberId { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        public virtual string NameOfMember { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        public virtual string NameOfFather { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        public virtual string NameOfMother { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        public virtual string NameOfSpouse { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string DOB { get; set; }
        public virtual string IdentityDocumentId { get; set; }
        public virtual string IdentityDocumentNo { get; set; }
        public virtual string IdentityDocumentData { get; set; }
        public virtual string RelationId { get; set; }
        public virtual string Photo { get; set; }

    }
}
