﻿using System;
using System.Web;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class SubDivMaster : Repositry<SubDivMaster>
    {
        public virtual string SubDivCode { get; set; }
        public virtual string SubDivName { get; set; }
        public virtual string SubDivDescription { get; set; }
        public virtual string SubDivAddress { get; set; }
        public virtual string DistrictCode { get; set; }
        public virtual bool WhetherActive { get; set; }
    }
}