﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;

namespace Edistrict.Models.Entities
{
    public class PaymentModeMaster : Repositry<PaymentModeMaster>
    {
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string PaymentModeId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string PaymentMode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherActive { get; set; }
    }
}