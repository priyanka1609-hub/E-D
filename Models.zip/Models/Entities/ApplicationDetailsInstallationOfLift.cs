﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.DataService;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.CustomAttribute;

namespace Edistrict.Models.Entities
{
    public class ApplicationDetailsInstallationOfLift : Repositry<ApplicationDetailsInstallationOfLift>
    {
        [RegularExpression("([0-9]+)")]
        public virtual string ApplicationId { get; set; }
        [RegularExpression("([0-9]+)")]
        [StringLength(14, MinimumLength = 14)]
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicationNo { get; set; }
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string Nameofagent { get; set; }
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Address")]
        public virtual string Addrofagent { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Address")]
        public virtual string Addrofowner { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string Nameofowner { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Address")]
        public virtual string Premises { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whetherprelicence { get; set; }
        [RequiredIf("Whetherprelicence", "True", ErrorMessage = "Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enterd InValid LicenceNo")]
        public virtual string LicenceNo { get; set; }
        [DataType(DataType.Date)]
        [RequiredIf("Whetherprelicence", "True", ErrorMessage = "Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((19|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((19|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((19|[2-9]\d)\d{2}))|(29\/02\/((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))+$", ErrorMessage = "Use Date only")]
        public virtual string Licencedate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Whethermorelift { get; set; }
        [RequiredIf("Whethermorelift", "True", ErrorMessage = "Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Address")]
        public virtual string Liftlocation { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string Nameoffirm { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[A-Za-z0-9]+(?:(([A-Za-z\s]))|(\.[A-Za-z0-9\s]+)|(\-[A-Za-z0-9\s]+)|(\,[A-Za-z0-9\s]+)|(\/[A-Za-z0-9\s]+))*([A-Za-z0-9])*$", ErrorMessage = "Enter InValid Address")]
        public virtual string Addroffirm { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Typeoflift1 { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Typeoflift2 { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Typeoflift3 { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [Range(0.5, 5.0, ErrorMessage = "Speed must be between 0.5 and 5.0")]
        [RegularExpression(@"^\s*(?=.*[1-9])\d*(?:\.\d{1,2})?\s*$", ErrorMessage = "Only Numbers allowed")]
        public virtual string Maxspeed { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^\s*(?=.*[1-9])\d*(?:\.\d{1,2})?\s*$", ErrorMessage = "Only Numbers allowed")]
        public virtual string Makerscapacity { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^\s*(?=.*[1-9])\d*(?:\.\d{1,2})?\s*$", ErrorMessage = "Only Numbers allowed")]
        public virtual string Liftcageweight { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression("^[0-9]*$", ErrorMessage = "Only Numbers allowed")]
        public virtual string Maxpassenger { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^\s*(?=.*[1-9])\d*(?:\.\d{1,2})?\s*$", ErrorMessage = "Only Numbers allowed")]
        public virtual string Counterweight { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Typeofcable { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Noofsupportingcable { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^\s*(?=.*[1-9])\d*(?:\.\d{1,2})?\s*$", ErrorMessage = "Only Numbers allowed")]
        public virtual string Descofsupportingcable { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^\s*(?=.*[1-9])\d*(?:\.\d{1,2})?\s*$", ErrorMessage = "Only Numbers allowed")]
        public virtual string Depthofpit { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^\s*(?=.*[1-9])\d*(?:\.\d{1,2})?\s*$", ErrorMessage = "Only Numbers allowed")]
        public virtual string Topclearance { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^\s*(?=.*[1-9])\d*(?:\.\d{1,2})?\s*$", ErrorMessage = "Only Numbers allowed")]
        public virtual string Bottomclearance { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^\s*(?=.*[1-9])\d*(?:\.\d{1,2})?\s*$", ErrorMessage = "Only Numbers allowed")]
        public virtual string Overheadweightdetails { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Totalnoofstops { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Noofbasementstops { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Nooffloorstops { get; set; }
        [RequiredIf("Typeoflift3", "623", ErrorMessage = "Required")]
        [RegularExpression(@"^\s*(?=.*[1-9])\d*(?:\.\d{1,2})?\s*$", ErrorMessage = "Only Numbers allowed")]
        public virtual string Machineroomheight { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Use letters only please")]
        public virtual string InsName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string InsmobileNo { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AppLocalityId { get; set; }
        public virtual string LocalityName { get; set; }
        public SelectList TypeOfLiftList1
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.TypeofLift1);
                List<SelectValueMaster> TypeOfLiftList1 = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(TypeOfLiftList1, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList TypeOfLiftList2
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.TypeofLift2);
                List<SelectValueMaster> TypeOfLiftList2 = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(TypeOfLiftList2, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList TypeOfLiftList3
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.TypeofLift3);
                List<SelectValueMaster> TypeOfLiftList3 = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(TypeOfLiftList3, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList TypeOfCableList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.TypeofSupportingCable);
                List<SelectValueMaster> TypeOfCableList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(TypeOfCableList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList LocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@Dept and dm.stateid=@stateid and LM.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@Dept", (int)Department.Dept007);
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
    }
}