﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.DataService;
using System.ComponentModel.DataAnnotations;

namespace Edistrict.Models.Entities
{
    public class ApplicantBankDetails : Repositry<ApplicantBankDetails>
    {
        public virtual string BankDetailsId { get; set; }
        public virtual string ApplicationId { get; set; }
        public virtual string ApplicationNo { get; set; }
        public virtual string AccountTypeId { get; set; }
        public virtual string AccountNo { get; set; }
        public virtual string MICRCode { get; set; }
        [RegularExpression("^[A-Za-z]{4}0[A-Z0-9a-z]{6}$", ErrorMessage = " InValid Input")]
        public virtual string IFSCCode { get; set; }
        public virtual string BankCode { get; set; }
        public virtual string BranchAddress { get; set; }
    }
}