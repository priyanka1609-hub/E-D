﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.Mvc;
using Edistrict.Models.Entities;
using Edistrict.Models.CustomClass;
using System.ComponentModel.DataAnnotations;
using Npgsql;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.DataService;

namespace Edistrict.Models
{
    public class ReportModels
    {
        public virtual string SelectDateReport { get; set; }
        public virtual string DistrictCode { get; set; }
        public virtual string StatusId { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string ServiceName { get; set; }
        public virtual string ApplicationId { get; set; }
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicantDistrictCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicantSubDivCode { get; set; }
        public virtual string ApplicationSubDivCode { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        public virtual string ApplicationSourceId { get; set; }
        public virtual string AppointmentTypeId { get; set; }
        public virtual string DateFrom { get; set; }
        public virtual string DateTo { get; set; }
        public virtual string ApplicationDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DaysCountFrom { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DaysCountTo { get; set; }
        public virtual string Flag { get; set; }
        [RequiredIf("AppCount", null, ErrorMessage = "Select any one option")]
        public virtual int RegCount { get; set; }
        [RequiredIf("RegCount", null, ErrorMessage = "Select any one option")]
        public virtual int AppCount { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ActionDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Pcode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string UserId { get; set; }
        public virtual string CSCUserId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ActionSourceId { get; set; }
        public virtual string PermissionCode { get; set; }
        public virtual string LocalityName { get; set; }
        [Required(ErrorMessage = "Year Required")]
        public string Year { get; set; }
        [Required(ErrorMessage = "Month Required")]
        public string Month { get; set; }
        public virtual string readOnly { get; set; }
        public string LoanBankId { get; set; }
        public string DistrictName { get; set; }
        public string SubDivName { get; set; }
        public virtual string ApplicantGender { get; set; }
        public virtual string ApplicantCategory { get; set; }
        public virtual string CDVEntryType { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string DepartmentId { get; set; }
        public string SelMonth { get; set; }
        public virtual string AcademicSession { get; set; }
        public virtual string AcademicSessionType { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public string ServiceId { get; set; }
        public virtual string FinancialCategory { get; set; }
        public virtual string UniversityId { get; set; }
        public virtual string InstitutionId { get; set; }
        public virtual string CourseId { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string ServiceDateFrom { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string ServiceDateTo { get; set; }
        public virtual string StateId { get; set; }
        public virtual string SCSTDepartmentId { get; set; }
        public virtual string SCSTZoneId { get; set; }
        public virtual string SchoolId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public string ConstituencyId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public string RouteId { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string StateCode { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string CasteId { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string WhetherCentreCaste { get; set; }

        [Required(ErrorMessage = "Value Required")]
        public virtual string ReqServiceCode { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ReqDateFrom { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ReqDateTo { get; set; }

        public DataTable data { get; set; }
        public DataTable dataa { get; set; }
        public DataTable dataS { get; set; }

        public virtual ApplicantDetails ApplicantDetails { get; set; }
        public virtual ApplicationDetails ApplicationDetails { get; set; }
        public virtual ApplicationDetailsDomicile ApplicationDetailsDomicile { get; set; }
        public virtual ApplicationMarriageDetails ApplicationMarriageDetails { get; set; }
        public virtual ApplicationHandicappedDetails ApplicationHandicappedDetails { get; set; }
        public virtual ApplicationOldAgeDetails ApplicationOldAgeDetails { get; set; }
        public virtual ApplicationWidowDetails ApplicationWidowDetails { get; set; }
        public virtual ApplicationDetailsNationality ApplicationDetailsNationality { get; set; }
        public virtual ApplicationDetailsDisability ApplicationDetailsDisability { get; set; }
        public virtual ApplicationDetailsSolvency ApplicationDetailsSolvency { get; set; }
        public virtual ApplicationDetailsBirth ApplicationDetailsBirth { get; set; }
        public virtual ApplicationDetailsDeath ApplicationDetailsDeath { get; set; }
        public virtual VerifierVerificationDetails VerifierVerificationDetails { get; set; }
        public virtual ApplicationDetailsSCST ApplicationDetailsSCST { get; set; }
        public virtual ApplicationDetailsST ApplicationDetailsST { get; set; }
        public virtual ApplicationDetailsOBC ApplicationDetailsOBC { get; set; }
        public virtual ApplicationDetailsLalDora ApplicationDetailsLalDora { get; set; }
        public virtual ApplicationDetailsSurviving ApplicationDetailsSurviving { get; set; }
        public virtual WitnessDetailsLalDora LalDoraWitnessDetails { get; set; }
        public virtual ApplicationDetailsIncome ApplicationDetailsIncome { get; set; }
        public virtual VerifierWitnessMaster VerifierWitnessMaster { get; set; }
        public virtual ApplicationLetterDetails ApplicationLetterDetailsModel { get; set; }
        public virtual ApplicationDetailsCDV ApplicationDetailsCDV { get; set; }
        public virtual ApplicationDetailsCinematograph ApplicationDetailsCinematograph { get; set; }
        public virtual MarriageWitnessMaster MarriageWitnessDetails { get; set; }
        public virtual ApplicationDetailsNOC ApplicationDetailsNOC { get; set; }
        public virtual ApplicationDetailsLadli ApplicationDetailsLadli { get; set; }
        public virtual ApplicationDetailsDFBScheme ApplicationDetailsDFBScheme { get; set; }
        public virtual ApplicationDetailsNT ApplicationDetailsNT { get; set; }
        public virtual NfsApplicationDetails NfsApplicationDetails { get; set; }
        public virtual NfsUpdateBasicDetails NfsUpdateBasicDetails { get; set; }
        public virtual HeSkillDevelopmentScheme HeSkillDevelopmentScheme { get; set; }
        public virtual ApplicationDetailsPrematsSC ApplicationDetailsPrematsSC { get; set; }
        public virtual ApplicationDetailsMigration ApplicationDetailsMigration { get; set; }
        public virtual ApplicationDetailsFirm ApplicationDetailsFirm { get; set; }
        public virtual ApplicationDetailsRecovery ApplicationDetailsRecovery { get; set; }
        public virtual ApplicationDetailsFinancialAssistance ApplicationDetailsFinancialAssistance { get; set; }
        public virtual ApplicationDetailsMeritscholarshipSchool ApplicationDetailsMeritscholarshipSchool { get; set; }
        public virtual ApplicationDetailsDrbrAmbedkarToppers ApplicationDetailsDrbrAmbedkarToppers { get; set; }
        public virtual ApplicationDetailsMeritProfessional ApplicationDetailsMeritProfessional { get; set; }
        public virtual ApplicationDetailsPrematOBC ApplicationDetailsPrematOBC { get; set; }
        public virtual ApplicationDetailsPostmatOBC ApplicationDetailsPostmatOBC { get; set; }
        public virtual ApplicationDetailsBOCWAct ApplicationDetailsBOCWAct { get; set; }
        public virtual ApplicationDetailsCLAct ApplicationDetailsCLAct { get; set; }
        public virtual ApplicationDetailsContractor ApplicationDetailsContractor { get; set; }
        public virtual ApplicationDetailsInstallationOfLift ApplicationDetailsInstallationOfLift { get; set; }
        public virtual ApplicationDetailsGrantOfPassengerLift ApplicationDetailsGrantOfPassengerLift { get; set; }
        public virtual ApplicationDetailsLBRRecovery ApplicationDetailsLBRRecovery { get; set; }
        public virtual ApplicationDetailsRenewalContractor ApplicationDetailsRenewalContractor { get; set; }
        public virtual HeInstitutionMaster HeInstitutionMaster { get; set; }
        public virtual HeMCMFinancialAssistance HeMCMFinancialAssistance { get; set; }
        public virtual ApplicationDetailsPrematSCssd ApplicationDetailsPrematSCssd { get; set; }
        public virtual ApplicationDetailsPostmatSCssd ApplicationDetailsPostmatSCssd { get; set; }
        public virtual ApplicationDetailsTirthYatraYojana ApplicationDetailsTirthYatraYojana { get; set; }
        public virtual ApplicationDetailsRenewalOfPassengerLift ApplicationDetailsRenewalOfPassengerLift { get; set; }
        public virtual ApplicationDetailsEC ApplicationDetailsEC { get; set; }
        public virtual ApplicationDetailsCompCertificate ApplicationDetailsCompCertificate { get; set; }
        public virtual PagingModel PagingModel { get; set; }

        public SelectList HeInstitutionList { get; set; }
        public SelectList DistrictList
        {
            get
            {
                string Qry = "select DistrictCode,DistrictName from DistrictMaster where deptcode=@deptcode and stateid=@stateid";
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DistrictCode=@ParamDistrictCode"; }
                Qry += " order by DistrictName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                List<DistrictMaster> DistrictList = DistrictMaster.List<DistrictMaster>(Cmd);
                return new SelectList(DistrictList, "DistrictCode", "DistrictName");
            }
            set { }
        }
        public SelectList SubDivList
        {
            get
            {
                string Qry = "select SubDivCode,SubDivDescription from SubDivMaster where districtcode in (select districtcode from districtmaster where deptcode=@ParamDeptCode and stateid=@stateid)";
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DistrictCode in (@ParamDistrictCode)"; }
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and SubDivCode in (@ParamSubDivCode)"; }
                Qry += " order by SubDivDescription";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                List<SubDivMaster> SubDivList = SubDivMaster.List<SubDivMaster>(Cmd);
                return new SelectList(SubDivList, "SubDivCode", "SubDivDescription");
            }
            set { }
        }
        public SelectList ServiceList
        {
            get
            {
                string Qry = "select ServiceCode,ServiceName from ServiceMaster where deptcode=@deptcode order by ServiceName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                List<ServiceMaster> ServiceList1 = ServiceMaster.List<ServiceMaster>(Cmd);
                return new SelectList(ServiceList1, "ServiceCode", "ServiceName");
            }
            set { }
        }
        public SelectList CounterList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                for (int i = 1; i < 21; i++)
                {
                    list.Add(new SelectListItem() { Text = (i+1).ToString(), Value = (i+1).ToString() });
                }
                return new SelectList(list, "Text", "Value");
            }
            set { }
        }
        public SelectList CounterList1
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                for (int i = 0; i < 100; i++)
                {
                    list.Add(new SelectListItem() { Text = (i + 1).ToString(), Value = (i + 1).ToString() });
                }
                return new SelectList(list, "Text", "Value");
            }
            set { }
        }
        public SelectList PermissionList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select pcode,pname from dbo.permissionmaster order by pname");
                List<PermissionMaster> PermissionList = PermissionMaster.List<PermissionMaster>(cmd);
                return new SelectList(PermissionList, "Pcode", "Pname");
            }

            set { }
        }
        public SelectList PermList
        {
            get
            {
                string Qry = "select pcode,pname from dbo.permissionmaster where pcode :: integer in (@sdm,@sdmhq,@adm,@dc)";
                if (Convert.ToInt32(Sessions.getEmployeeUser().Permission).Equals((int)Permission.SDMG)) { Qry += " and PCode :: integer in(@sdm)"; }
                else if (Convert.ToInt32(Sessions.getEmployeeUser().Permission).Equals((int)Permission.DCOM)) { Qry += " and PCode :: integer in(@adm,@sdmhq,@sdm,@dc)"; }
                else if (Convert.ToInt32(Sessions.getEmployeeUser().Permission).Equals((int)Permission.DC)) { Qry += " and PCode :: integer in(@adm,@sdmhq,@sdm)"; }
                else if (Convert.ToInt32(Sessions.getEmployeeUser().Permission).Equals((int)Permission.P114)) { Qry += " and PCode :: integer in(@sdmhq,@sdm)"; }
                else if (Convert.ToInt32(Sessions.getEmployeeUser().Permission).Equals((int)Permission.P115)) { Qry += " and PCode :: integer in(@sdm)"; }
                else { Qry += " and PCode :: integer in(0)"; }
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@sdm", (int)Permission.SDMG);
                cmd.Parameters.AddWithValue("@dc", (int)Permission.DC);
                cmd.Parameters.AddWithValue("@adm", (int)Permission.P114);
                cmd.Parameters.AddWithValue("@sdmhq", (int)Permission.P115);

                //if (Convert.ToInt32(Sessions.getEmployeeUser().Permission).Equals((int)Permission.DCOM))
                //{
                //    cmd.Parameters.AddWithValue("@sdm", (int)Permission.SDMG);
                //    cmd.Parameters.AddWithValue("@dc", (int)Permission.DC);
                //    cmd.Parameters.AddWithValue("@adm", (int)Permission.P114);
                //    cmd.Parameters.AddWithValue("@sdmhq", (int)Permission.P115);
                //}
                //if (Convert.ToInt32(Sessions.getEmployeeUser().Permission).Equals((int)Permission.DC))
                //{
                //    cmd.Parameters.AddWithValue("@sdm", (int)Permission.SDMG);
                //    cmd.Parameters.AddWithValue("@adm", (int)Permission.P114);
                //    cmd.Parameters.AddWithValue("@sdmhq", (int)Permission.P115);
                //}
                //if (Convert.ToInt32(Sessions.getEmployeeUser().Permission).Equals((int)Permission.P114))
                //{
                //    cmd.Parameters.AddWithValue("@sdm", (int)Permission.SDMG);
                //    cmd.Parameters.AddWithValue("@sdmhq", (int)Permission.P115);
                //}
                //if (Convert.ToInt32(Sessions.getEmployeeUser().Permission).Equals((int)Permission.P115)) { cmd.Parameters.AddWithValue("@sdm", (int)Permission.SDMG); }
                List<PermissionMaster> PermList = PermissionMaster.List<PermissionMaster>(cmd);
                return new SelectList(PermList, "Pcode", "Pname");
            }

            set { }
        }
        public SelectList UserMasterList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select UserId,UserName from dbo.UserMaster order by UserName");
                List<UserMaster> UserMasterList = UserMaster.List<UserMaster>(cmd);
                return new SelectList(UserMasterList, "UserId", "UserName");
            }

            set { }
        }
        public SelectList ActionSourceList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select ApplicationSourceId,ApplicationSource from ApplicationSourceMaster Order By ApplicationSource");
                List<ApplicationSourceMaster> ActionSourceList = ApplicationSourceMaster.List<ApplicationSourceMaster>(cmd);
                return new SelectList(ActionSourceList, "ApplicationSourceId", "ApplicationSource");
            }

            set { }
        }
        public SelectList selectserviceType { get; set; }
        public SelectList VerifierMaster { get; set; }
        public SelectList VerificationSelectList { get; set; }
        public virtual SelectList MonthList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                DateTime month = Convert.ToDateTime("01/01/2012");
                for (int i = 0; i < 12; i++)
                {
                    DateTime NextMonth = month.AddMonths(i);
                    list.Add(new SelectListItem() { Text = NextMonth.ToString("MMMM"), Value = (i + 1).ToString() });
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList YearList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int varYear = 2015;
                for (int i = varYear; i < DateTime.Now.AddYears(1).Year; i++)
                {
                    list.Add(new SelectListItem() { Text = varYear.ToString(), Value = varYear.ToString() });
                    varYear++;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList SubDivisionList
        {
            get
            {
                string Qry = "select SubDivCode,SubDivDescription from SubDivMaster where districtcode in (select districtcode from districtmaster where deptcode=1 and stateid=@stateid)  order by SubDivDescription limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@stateid", (int)State.Delhi);
                List<SubDivMaster> SubDivList = SubDivMaster.List<SubDivMaster>(Cmd);
                return new SelectList(SubDivList, "SubDivCode", "SubDivDescription");
            }
            set { }
        }
        [CustomProperty]
        public SelectList ApprovedBankMasterList
        {
            get
            {
                List<BankMaster> ApprovedBankMasterList = BankMaster.List<BankMaster>(new Npgsql.NpgsqlCommand("select HeBankCode,BankName from dbo.HeBankMaster where whetheractive=True order by BankName"));
                return new SelectList(ApprovedBankMasterList, "HeBankCode", "BankName");
            }
            set { }
        }
        public SelectList SCSTSchoolDepartmentList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.DepartmentType);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList SCSTCategoryList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.PreMatScholarshipCategory);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList CDVTypeList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "All", Value = "0" });
                list.Add(new SelectListItem() { Text = "New CDV", Value = "1" });
                list.Add(new SelectListItem() { Text = "Existing CDV", Value = "2" });
                return new SelectList(list, "Value", "Text");
            }
            set { }

        }
        public SelectList HeSatusList
        {
            get
            {
                string Qry = "select StatusId,StatusName from StatusMaster where StatusId in (@TEHSPEN,@ISSUCER,@OBSPEND,@TEHSREJ) order by StatusName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@TEHSPEN", (int)Status.TEHSPEN);
                Cmd.Parameters.AddWithValue("@ISSUCER", (int)Status.ISSUCER);
                Cmd.Parameters.AddWithValue("@OBSPEND", (int)Status.OBSPEND);
                Cmd.Parameters.AddWithValue("@TEHSREJ", (int)Status.TEHSREJ);
                List<StatusMaster> StatusList1 = StatusMaster.List<StatusMaster>(Cmd);
                return new SelectList(StatusList1, "StatusId", "StatusName");
            }
            set { }
        }
        public virtual SelectList HeAcademicSessionList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int curryear = DateTime.Now.Year - 2;
                int passedyear = curryear + 2;

                for (int i = passedyear; i >= curryear; i--)
                {
                    list.Add(new SelectListItem() { Text = passedyear.ToString() + "-" + (passedyear + 1).ToString(), Value = passedyear.ToString() });
                    passedyear = passedyear - 1;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList SCSTAcademicSessionList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int passedyear = 2016;
                int curryear = DateTime.Now.Year;


                for (int i = passedyear; i <= curryear; i++)
                {
                    list.Add(new SelectListItem() { Text = passedyear.ToString() + "-" + (passedyear + 1).ToString(), Value = passedyear.ToString() });
                    passedyear = passedyear + 1;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList HEUniversityMasterList
        {
            get
            {
                string Qry = "select UniversityId,UniversityName from heuniversitymaster where whetheractive=true and ServiceCode=3006 ";
                if (Sessions.getEmployeeUser() != null) { if (Sessions.getEmployeeUser().AuthorizationId != ((int)CountList.Type000).ToString()) { Qry += " and UniversityId=@UniversityId "; } }
                Qry += " order by UniversityName ";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                if (Sessions.getEmployeeUser() != null) { if (Sessions.getEmployeeUser().AuthorizationId != ((int)CountList.Type000).ToString()) { Cmd.Parameters.AddWithValue("@UniversityId", Sessions.getEmployeeUser().AuthorizationId); } }
                List<HeUniversityMaster> UniversityMasterList = HeUniversityMaster.List<HeUniversityMaster>(Cmd);
                return new SelectList(UniversityMasterList, "UniversityId", "UniversityName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList FinancialAssistanceCategoryMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMV.mastervalueid=@mastervalueid order by valuename");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.HEFinancialAssistanceCategory);
                List<ServiceTypeMaster> FinancialAssistanceCategoryMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(FinancialAssistanceCategoryMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList ServiceTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select ServiceCode,ServiceName from ServiceMaster where deptcode=@deptcode and ServiceCode in (@ServiceObc,@ServiceSc,@ServiceSt) order by ServiceName");
                Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                Cmd.Parameters.AddWithValue("@ServiceObc", (int)ApplicationService.ServiceList.OBC);
                Cmd.Parameters.AddWithValue("@ServiceSc", (int)ApplicationService.ServiceList.SCST);
                Cmd.Parameters.AddWithValue("@ServiceSt", (int)ApplicationService.ServiceList.ST);
                List<ServiceMaster> ServiceList = ServiceMaster.List<ServiceMaster>(Cmd);
                return new SelectList(ServiceList, "ServiceCode", "ServiceName");
            }
            set { }
        }
        public SelectList HeStateList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Delhi", Value = "7" });
                list.Add(new SelectListItem() { Text = "Out Side Delhi", Value = "100" });
                return new SelectList(list, "Value", "Text");
            }
            set { }

        }
        public SelectList SCSTSatusList
        {
            get
            {
                 List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Pending For Verification/Recommendation By School/College/Institute/Dealing", Value = "0" });
                list.Add(new SelectListItem() { Text = "Pending For Decision By Department/Zone", Value = "1" });
                list.Add(new SelectListItem() { Text = "Pending For Sanction By SC/ST Department", Value = "2" });
                list.Add(new SelectListItem() { Text = "Sanctioned By SC/ST Department", Value = "3" });
                list.Add(new SelectListItem() { Text = "PFMS Payment File Uploaded", Value = "4" });
                list.Add(new SelectListItem() { Text = "Not Recommended By School/College/Institute/Dealing", Value = "5" });
                list.Add(new SelectListItem() { Text = "Rejected By Department/Zone", Value = "6" });
                return new SelectList(list, "Value", "Text");

            }
            set { }
        }
        [CustomProperty]
        public SelectList SCSTDepartmentList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select distinct smvd.valueid,valuename from selectmastervaluedetails smvd inner join selectmastervaluetodetails smvtd on smvtd.valueid=smvd.valueid where mastervalueid=@mastervalueid order by valuename ");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.SCSTApprovingDeptType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList SCSTDistrictList
        {
            get
            {
                string Qry = "select DistrictId as SelectValueId,DistrictName as SelectValueName from dgen.prematdistrictmaster where WhetherActive=@WhetherActive order by DistrictName limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", Edistrict.Models.ApplicationService.CustomText.True.ToString());
                List<SelectValueMaster> SubDivList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(SubDivList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList SCSTZoneList
        {
            get
            {
                string Qry = "select ZoneId as SelectValueId,ZoneName as SelectValueName from dgen.prematzonemaster where WhetherActive=@WhetherActive order by ZoneName limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", Edistrict.Models.ApplicationService.CustomText.True.ToString());
                List<SelectValueMaster> SubDivList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(SubDivList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        [CustomProperty]
        public SelectList SCSTSchoolNameList
        {
            get
            {
                string Qry = "select SchoolId as SelectValueId,SchoolName||','||SchoolAddress as SelectValueName from dgen.prematschoolmaster where WhetherActive=@WhetherActive order by SchoolName limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", Edistrict.Models.ApplicationService.CustomText.True.ToString());
                List<SelectValueMaster> SubDivList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(SubDivList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public SelectList NULMStatusList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Application Received", Value = "AR" });
                list.Add(new SelectListItem() { Text = "Pending For Decision", Value = "0" });
                list.Add(new SelectListItem() { Text = "Issued", Value = ((int)Status.ISSUCER).ToString() });
                list.Add(new SelectListItem() { Text = "Cancelled", Value = ((int)Status.CANCEL).ToString() });
                list.Add(new SelectListItem() { Text = "Rejected", Value = ((int)Status.TEHSREJ).ToString() });
                return new SelectList(list, "Value", "Text");
            }

            set { }
        }
        public SelectList ConstituencyList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select constituencyid,constituencyname from assemblyconstituencymaster where Whetheractive=@WhetherActive order by constituencyname");
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                List<AssemblyConstituencyMaster> ClassList = AssemblyConstituencyMaster.List<AssemblyConstituencyMaster>(Cmd);
                return new SelectList(ClassList, "constituencyid", "constituencyname");
            }
            set { }
        }
        public SelectList ConstituencyListTirth
        {
            get
            {
                string Qry = "select constituencyid,constituencyname from assemblyconstituencymaster where Whetheractive=@WhetherActive";
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and constituencyid in (select constituencyid from districttoconstituencymaster where districtcode = @ParamDistrictCode)"; }
                Qry += " order by constituencyname";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                List<AssemblyConstituencyMaster> ConstituencyList = AssemblyConstituencyMaster.List<AssemblyConstituencyMaster>(Cmd);
                return new SelectList(ConstituencyList, "constituencyid", "constituencyname");

            }
            set { }
        }
        public SelectList RouteList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select SMVD.valueid,SMVD.valuename from dbo.selectmastervaluedetails SMVD inner join dbo.selectmastervaluetodetails SMVTD on SMVTD.valueid=SMVD.valueid inner join dbo.selectmastervalue SMV on SMV.mastervalueid=SMVTD.mastervalueid where SMVTD.whetheractive=TRUE and SMV.mastervalueid=@mastervalueid");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.TirthYatraRouteList);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public SelectList MobileSahayakServiceList
        {
            get
            {
                string Qry = "select SM.ServiceCode,ServiceName from ServiceMaster  SM inner join serviceattributemaster SAM on SAM.ServiceCode=SM.ServiceCode where whethersahayakapply=@WhetherSahayakApply ";
                if (Sessions.getEmployeeUser().DeptCode != ((int)Department.Dept015).ToString()) { Qry += " and deptcode=@deptcode"; }
                Qry += " order by deptcode";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                Cmd.Parameters.AddWithValue("@WhetherSahayakApply", CustomText.TRUE.ToString());
                List<ServiceMaster> ServiceList = ServiceMaster.List<ServiceMaster>(Cmd);
                return new SelectList(ServiceList, "ServiceCode", "ServiceName");
            }
            set { }
        }
        public SelectList StateMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select StateId,StateName from statemaster order by StateName");
                List<StateMaster> StateList = StateMaster.List<StateMaster>(Cmd);
                return new SelectList(StateList, "StateId", "StateName");
            }
            set { }
        }
        public SelectList CasteMasterList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select CasteId,CasteName from castemaster where whetheractive=true order by CasteName limit 0");
                List<CasteMaster> CasteList = CasteMaster.List<CasteMaster>(Cmd);
                return new SelectList(CasteList, "CasteId", "CasteName");
            }
            set { }
        }
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
    }
}