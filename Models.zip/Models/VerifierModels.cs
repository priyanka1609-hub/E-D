﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.Entities;
using System.ComponentModel.DataAnnotations;
using System.Data;
using Edistrict.Models.CustomClass;
using System.Web.Mvc;

namespace Edistrict.Models
{
    public class VerifierModels
    {
        [Required(ErrorMessage = "Status Required")]
        public virtual string StatusId { get; set; }
        [Required(ErrorMessage = "Service  Required")]
        public virtual string ServiceCode { get; set; }
        [Required(ErrorMessage = "Application No. Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = "Please select one option")]
        public virtual string WhetherAffidavit { get; set; }
        [Required(ErrorMessage = "Please select one option")]
        public virtual string OriginalSeen { get; set; }
        [Required(ErrorMessage = "Please fill in remarks")]
        public virtual string VerifierRemarks { get; set; }
        [Required(ErrorMessage = "Please select one option")]
        public virtual string WhetherSatisfactory { get; set; }

        public List<VerifierVerificationReport> VerifierVerificationReport { get; set; }
        public List<VerifierWitnessMaster> VerifierWitnessMaster { get; set; }

        public virtual ServiceSpecificVerificationDetails ServiceSpecificVerificationDetails { get; set; }
        public virtual ApplicantDetails ApplicantDetails { get; set; }
        public virtual ApplicationDetails ApplicationDetails { get; set; }
        public virtual ApplicationDetailsDomicile ApplicationDetailsDomicile { get; set; }
        public virtual ApplicationHandicappedDetails ApplicationHandicappedDetails { get; set; }
        public virtual ApplicationOldAgeDetails ApplicationOldAgeDetails { get; set; }
        public virtual ApplicationDetailsNationality ApplicationDetailsNationality { get; set; }
        public virtual ApplicationDetailsSolvency ApplicationDetailsSolvency { get; set; }
        public virtual ApplicationDetailsDisability ApplicationDetailsDisability { get; set; }
        public virtual ApplicationDetailsBirth ApplicationDetailsBirth { get; set; }
        public virtual ApplicationDetailsDeath ApplicationDetailsDeath { get; set; }
        public virtual ApplicationDetailsIncome ApplicationDetailsIncome { get; set; }
        public virtual ApplicationDetailsSCST ApplicationDetailsSCST { get; set; }
        public virtual ApplicationDetailsST ApplicationDetailsST { get; set; }
        public virtual ApplicationDetailsOBC ApplicationDetailsOBC { get; set; }
        public virtual ApplicationDetailsLalDora ApplicationDetailsLalDora { get; set; }
        public virtual ApplicationDetailsSurviving ApplicationDetailsSurviving { get; set; }
        public virtual ApplicationLetterDetails ApplicationLetterDetailsModel { get; set; }
        public virtual ApplicationWidowDetails ApplicationWidowDetails { get; set; }
        public virtual ApplicationDetailsNT ApplicationDetailsNT { get; set; }
        public virtual ApplicationDetailsInstallationOfLift ApplicationDetailsInstallationOfLift { get; set; }
        public virtual ApplicationDetailsGrantOfPassengerLift ApplicationDetailsGrantOfPassengerLift { get; set; }
        public virtual ApplicationDetailsCEA1 ApplicationDetailsCEA1 { get; set; }

        public DataTable data { get; set; }
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }   
    }
}