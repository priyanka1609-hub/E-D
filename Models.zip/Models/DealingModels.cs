﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Web.Mvc;
using Edistrict.Models.CustomClass;
using Edistrict.Models.Entities;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.ApplicationService;
using System.Collections.Generic;
using Npgsql;

namespace Edistrict.Models
{
    public class DealingModels
    {
        [Required(ErrorMessage = "Application No. Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicationNo { get; set; }
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicationId { get; set; }
        [Required(ErrorMessage = "Select Value")]
        public virtual string ServiceCode { get; set; }
        [Required(ErrorMessage = "Select Value")]
        public virtual string StatusId { get; set; }
        [Required(ErrorMessage = "Please Select Verification")]
        public virtual string SelectValueId { get; set; }
        [RequiredIf("SelectValueId", "Y", ErrorMessage = "Please Select Verifier")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string VerifierCode { get; set; }
        [Required(ErrorMessage = "Please Capture/Upload Photo")]
        public virtual string PhotoSource { get; set; }
        [RequiredIf("PhotoSource", "C", ErrorMessage = "Plesae Capture Image")]
        public virtual string PhotoData { get; set; }
        [RequiredIf("PhotoSource", "U", ErrorMessage = "Please Upload Scan Photo")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg" }, MaxContentLength = (int)LengthList.AppLength, MaxFileLength = (int)LengthList.AppPhoto, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase ApplicantPhoto { get; set; }
        [Required(ErrorMessage = "File Required")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg", "application/pdf" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg", ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase ApplicantFile { get; set; }
        public virtual string readOnly { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherReligiousMarriage { get; set; }
        [Required(ErrorMessage = "Please Enter Remarks")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Minimum 2 & Maximum 250 character allowed")]
        public virtual string ApplicationDARemarks { get; set; }
        [Required(ErrorMessage = "Upload Verification Letter")]
        public virtual string VerificationLetterData { get; set; }
        public virtual bool WhetherVerificationLetterRequired { get; set; }
        public virtual string IsAlreadyVerified { get; set; }
        public virtual string TotalAmount { get; set; }
        [Required(ErrorMessage = "Please Enter Amount")]
        public virtual string RecAmount { get; set; }
        [Required(ErrorMessage = "Please Enter Amount")]
        public virtual string DisbursedTuitionFee { get; set; }
        [Required(ErrorMessage = "Please Enter Amount")]
        public virtual string DisbursedAdmissionFee { get; set; }
        [Required(ErrorMessage = "Please Enter Amount")]
        public virtual string DisbursedMaintenanceFee { get; set; }
        [Required(ErrorMessage = "Please Enter Amount")]
        public virtual string DisbursedStationaryFee { get; set; }
        [Required(ErrorMessage = "Please Enter Amount")]
        public virtual string DisbursedHostelFee { get; set; }
        [Required(ErrorMessage = "Please Enter Amount")]
        public virtual string DisbursedOtherFee { get; set; }
        public virtual bool WhetherScStwelfateAllowed { get; set; }
        [Required(ErrorMessage = "Please Select Value")]
        public virtual string AcademicSession { get; set; }
        [Required(ErrorMessage = "Select Value")]
        public virtual string EnclosureId { get; set; }
        public virtual string TypeId { get; set; }

        [BooleanMustBeTrue(ErrorMessage = "Please Check the checkbox")]
        public virtual bool check { get; set; }
        public virtual string ConstituencyId { get; set; }
        public virtual string RouteId { get; set; }

        public virtual ApplicantDetails ApplicantDetails { get; set; }
        public virtual ApplicationDetails ApplicationDetails { get; set; }
        public virtual VerifierVerificationDetails VerifierVerificationDetails { get; set; }
        public virtual ApplicationDetailsDomicile ApplicationDetailsDomicile { get; set; }
        public virtual ApplicationMarriageDetails ApplicationMarriageDetails { get; set; }
        public virtual MarriageWitnessMaster MarriageWitnessDetails { get; set; }
        public virtual ApplicationHandicappedDetails ApplicationHandicappedDetails { get; set; }
        public virtual ApplicationOldAgeDetails ApplicationDetailsOldAge { get; set; }
        public virtual ApplicationDetailsNationality ApplicationDetailsNationality { get; set; }
        public virtual ApplicationDetailsSolvency ApplicationDetailsSolvency { get; set; }
        public virtual ApplicationDetailsDisability ApplicationDetailsDisability { get; set; }
        public virtual ApplicationDetailsBirth ApplicationDetailsBirth { get; set; }
        public virtual ApplicationDetailsDeath ApplicationDetailsDeath { get; set; }
        public virtual ApplicationDetailsIncome ApplicationDetailsIncome { get; set; }
        public virtual ApplicationDetailsSCST ApplicationDetailsSCST { get; set; }
        public virtual ApplicationDetailsST ApplicationDetailsST { get; set; }
        public virtual ApplicationDetailsOBC ApplicationDetailsOBC { get; set; }
        public virtual ApplicationDetailsLalDora ApplicationDetailsLalDora { get; set; }
        public virtual ApplicationDetailsSurviving ApplicationDetailsSurviving { get; set; }
        public virtual WitnessDetailsLalDora LalDoraWitnessDetails { get; set; }
        public virtual ApplicationLetterDetails ApplicationLetterDetailsModel { get; set; }
        public virtual ApplicationWidowDetails ApplicationWidowDetails { get; set; }
        public virtual ApplicationEnclosureDetails ApplicationEnclosureDetails { get; set; }
        public virtual ApplicationPhotoMaster ApplicationPhotoMaster { get; set; }
        public virtual MarriageWitnessMaster MarriageWitness1 { get; set; }
        public virtual MarriageWitnessMaster MarriageWitness2 { get; set; }
        public virtual MarriageWitnessMaster MarriageWitness3 { get; set; }
        public virtual ApplicantReciept ApplicantReciept { get; set; }
        public virtual ApplicationDetailsCDV ApplicationDetailsCDV { get; set; }
        public virtual ApplicationDetailsNOC ApplicationDetailsNOC { get; set; }
        public virtual NOCAcquisitionDetails NOCAcquisitionDetails { get; set; }
        public virtual NOCViolationDetails NOCViolationDetails { get; set; }
        public virtual ApplicationDetailsMigration ApplicationDetailsMigration { get; set; }
        public virtual ApplicationDetailsBOCWAct ApplicationDetailsBOCWAct { get; set; }
        public virtual ApplicationDetailsCLAct ApplicationDetailsCLAct { get; set; }
        public virtual ApplicationDetailsContractor ApplicationDetailsContractor { get; set; }
        public virtual ApplicationDetailsLadli ApplicationDetailsLadli { get; set; }
        public virtual ApplicationDetailsDFBScheme ApplicationDetailsDFBScheme { get; set; }
        public virtual ApplicationDetailsNT ApplicationDetailsNT { get; set; }
        public virtual ApplicationDetailsRecovery ApplicationDetailsRecovery { get; set; }
        public virtual ApplicationDetailsSociety ApplicationDetailsSociety { get; set; }
        public virtual ApplicationDetailsFirm ApplicationDetailsFirm { get; set; }
        public virtual ApplicationDetailsMeritProfessional ApplicationDetailsMeritProfessional { get; set; }
        public virtual ApplicationDetailsPostmatOBC ApplicationDetailsPostmatOBC { get; set; }
        public virtual ApplicationDetailsInstallationOfLift ApplicationDetailsInstallationOfLift { get; set; }
        public virtual ApplicationDetailsGrantOfPassengerLift ApplicationDetailsGrantOfPassengerLift { get; set; }
        public virtual ApplicationDetailsRenewalOfPassengerLift ApplicationDetailsRenewalOfPassengerLift { get; set; }
        public virtual ApplicationDetailsRenewalContractor ApplicationDetailsRenewalContractor { get; set; }
        public virtual ApplicationDetailsSRCopy ApplicationDetailsSRCopy { get; set; }
        public virtual ApplicationDetailsConsWorker ApplicationDetailsConsWorker { get; set; }
        public virtual RenewalConsWorker RenewalConsWorker { get; set; }
        public virtual ApplicationDetailsPostmatSCssd ApplicationDetailsPostmatSCssd { get; set; }
        public virtual ApplicationDetailsCEA1 ApplicationDetailsCEA1 { get; set; }
        public virtual ApplicationDetailsCEA2 ApplicationDetailsCEA2 { get; set; }
        public virtual ApplicationDetailsCEA3 ApplicationDetailsCEA3 { get; set; }
        public virtual ApplicationDetailsEC ApplicationDetailsEC { get; set; }
        public virtual ApplicationDetailsCompCertificate ApplicationDetailsCompCertificate { get; set; }
        public virtual ApplicationDetailsDeathBenefits ApplicationDetailsDeathBenefits { get; set; }
        public virtual ApplicationDetailsFuneralBenefit ApplicationDetailsFuneralBenefit { get; set; }
        public virtual ApplicationDetailsFamilyPension ApplicationDetailsFamilyPension { get; set; }
        public virtual ApplicationDetailsMarriageAssistance ApplicationDetailsMarriageAssistance { get; set; }
        public virtual ApplicationDetailsEduScholarship ApplicationDetailsEduScholarship { get; set; }
        public virtual ApplicationDetailsMedicalAssistance ApplicationDetailsMedicalAssistance { get; set; }
        public virtual ApplicationDetailsHBA ApplicationDetailsHBA { get; set; }
        public virtual ApplicationDetailsDisabilityPension ApplicationDetailsDisabilityPension { get; set; }
        public virtual ApplicationDetailsPension ApplicationDetailsPension { get; set; }
        public virtual ApplicationDetailsMaternityBenefit ApplicationDetailsMaternityBenefit { get; set; }
        public virtual ApplicationDetailsGrantofWork ApplicationDetailsGrantofWork { get; set; }
        public virtual ApplicationDetailsInstrumentLoan ApplicationDetailsInstrumentLoan { get; set; }
        public virtual ApplicationDetailsExgratia ApplicationDetailsExgratia { get; set; }
        public virtual ApplicationDetailsTirthYatraYojana ApplicationDetailsTirthYatraYojana { get; set; }
        public virtual EnclosureVerificationMaster EnclosureVerificationMaster { get; set; }

        public virtual List<MarriageWitnessMaster> MarriageWitnessMaster { get; set; }

        public virtual DataTable data { get; set; }
        public DataTable data1 { get; set; }
        public virtual DataTable datab { get; set; }
        public virtual DataTable datac { get; set; }
        public virtual DataTable dtVerificationLetter { get; set; }
        public DataTable dtRegisteredWorkerDetails { get; set; }

        public virtual SelectList VerifierMaster { get; set; }
        public virtual SelectList StatusMaster { get; set; }
        public virtual SelectList VerificationSelectList { get; set; }
        public virtual SelectList LocalityMaster { get; set; }
        public virtual SelectList NationalityList
        {
            get
            {
                List<NationalityMaster> NationalityList = NationalityMaster.List<NationalityMaster>(new Npgsql.NpgsqlCommand("select NationalityId,NationalityName from NationalityMaster order by NationalityId"));
                return new SelectList(NationalityList, "NationalityId", "NationalityName");
            }
            set { }
        }
        public virtual SelectList MaritalStatusList
        {
            get
            {
                List<MaritalStatusMaster> MaritalStatusList = MaritalStatusMaster.List<MaritalStatusMaster>(new Npgsql.NpgsqlCommand("select MaritalStatusId,MaritalStatusName from dbo.MaritalStatusMaster"));
                return new SelectList(MaritalStatusList, "MaritalStatusId", "MaritalStatusName");
            }
            set { }
        }
        public virtual SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "Y" });
                list.Add(new SelectListItem() { Text = "No", Value = "N" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList YesNoListTrueFalse
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList HeAcademicSessionList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valuename as SelectValueId,(s1.valuename::integer ||'-'||s1.valuename::integer + 1)  as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.HigherEduAcadmicSession);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList SCSTAcademicSessionList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int passedyear = 2016;
                //int curryear = 2016;//----------------------Temp comment for 2017-18 session, un-comment when you wants to process for 2017-18
                int curryear = DateTime.Now.Year;

                for (int i = passedyear; i <= curryear; i++)
                {
                    list.Add(new SelectListItem() { Text = passedyear.ToString() + "-" + (passedyear + 1).ToString(), Value = passedyear.ToString() });
                    passedyear = passedyear + 1;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList DocumentVerificationModeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.DocumentVerificationMode);
                List<SelectValueMaster> DocumentVerificationList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(DocumentVerificationList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
    }
}