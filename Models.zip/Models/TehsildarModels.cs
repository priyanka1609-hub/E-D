﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using Edistrict.Models.CustomClass;
using Edistrict.Models.Entities;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.CustomAttribute;
using Npgsql;

namespace Edistrict.Models
{
    public class TehsildarModels
    {
        [Required(ErrorMessage = "Application No. Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        [StringLength(14, MinimumLength = 14, ErrorMessage = "Enter Valid Application No.")]
        public virtual string ApplicationNo { get; set; }
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicationId { get; set; }
        [Required(ErrorMessage = "Enter Remarks")]
        public virtual string ApplicationRemarks { get; set; }
        public virtual bool WhetherVerification { get; set; }
        public virtual string IsAlreadyVerified { get; set; }
        [Required(ErrorMessage = "Select Value")]
        public virtual string StatusId { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual bool WhetherVerificationLetterRequired { get; set; }
        public virtual string Source { get; set; }

        public DataTable data { get; set; }
        public DataTable data2 { get; set; }
        public DataTable data3 { get; set; }
        public DataTable data4 { get; set; }

        public virtual ApplicantDetails ApplicantDetails { get; set; }
        public virtual ApplicationDetails ApplicationDetails { get; set; }
        public virtual ApplicationDetailsDomicile ApplicationDetailsDomicile { get; set; }
        public virtual ApplicationHandicappedDetails ApplicationHandicappedDetails { get; set; }
        public virtual ApplicationOldAgeDetails ApplicationOldAgeDetails { get; set; }
        public virtual ApplicationDetailsNationality ApplicationDetailsNationality { get; set; }
        public virtual ApplicationDetailsDisability ApplicationDetailsDisability { get; set; }
        public virtual ApplicationDetailsSolvency ApplicationDetailsSolvency { get; set; }
        public virtual ApplicationDetailsBirth ApplicationDetailsBirth { get; set; }
        public virtual ApplicationDetailsDeath ApplicationDetailsDeath { get; set; }
        public virtual VerifierVerificationDetails VerifierVerificationDetails { get; set; }
        public virtual ApplicationDetailsIncome ApplicationDetailsIncome { get; set; }
        public virtual ApplicationDetailsSCST ApplicationDetailsSCST { get; set; }
        public virtual ApplicationDetailsST ApplicationDetailsST { get; set; }
        public virtual ApplicationDetailsOBC ApplicationDetailsOBC { get; set; }
        public virtual ApplicationDetailsLalDora ApplicationDetailsLalDora { get; set; }
        public virtual ApplicationDetailsSurviving ApplicationDetailsSurviving { get; set; }
        public virtual VerifierWitnessMaster VerifierWitnessMaster { get; set; }
        public virtual WitnessDetailsLalDora LalDoraWitnessDetails { get; set; }
        public virtual ApplicationLetterDetails ApplicationLetterDetailsModel { get; set; }
        public virtual ApplicationWidowDetails ApplicationWidowDetails { get; set; }
        public ApplicationDetailsNOC ApplicationDetailsNOC { get; set; }
        public NOCAcquisitionDetails NOCAcquisitionDetails { get; set; }
        public NOCViolationDetails NOCViolationDetails { get; set; }
        public ApplicationDetailsNT ApplicationDetailsNT { get; set; }
        public virtual LBRGrievanceDetails LBRGrievanceDetails { get; set; }

        [Required(ErrorMessage = "Please Select Verification")]
        public virtual string SelectValueId { get; set; }
        [RequiredIf("SelectValueId", "Y", ErrorMessage = "Please Select Verifier")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string VerifierCode { get; set; }
        [Required(ErrorMessage = "Please Select Verifier")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string NewVerifierCode { get; set; }
        [Required(ErrorMessage = "Please Upload Document")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg", "application/pdf" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg", ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase VerificationLetter { get; set; }
        public SelectList VerifierMaster { get; set; }
        public SelectList DecisionList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Approve", Value = ((int)Status.TEHSREC).ToString() });
                list.Add(new SelectListItem() { Text = "Reject", Value = ((int)Status.TEHSREJ).ToString() });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "Y" });
                list.Add(new SelectListItem() { Text = "No", Value = "N" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        //public SelectList ReasonMasterList
        //{
        //    get
        //    {
        //        NpgsqlCommand cmd = new NpgsqlCommand("select RM.ReasonCode,RM.ReasonDetail from ReasonMaster RM  inner join  reasontoservicemaster RS on RM.ReasonCode=RS.ReasonCode where RM.whetheractive=@whetheractive and RS.whetheractive=@whetheractive and RS.ServiceCode=@ServiceCode order by RS.DisplaySequence ");
        //        cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
        //        cmd.Parameters.AddWithValue("@ServiceCode", ApplicationDetails.ServiceCode);
        //        List<ReasonMaster> ReasonMasterList = ReasonMaster.List<ReasonMaster>(cmd);
        //        return new SelectList(ReasonMasterList, "ReasonCode", "ReasonDetail");
        //    }
        //    set { }
        //}
    }
}