﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.CustomClass;
using Edistrict.Models.Entities;
using System.ComponentModel.DataAnnotations;
using System.Data;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Npgsql;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.DataService;

namespace Edistrict.Models
{
    public class WindowModels
    {
        [RequiredIf("ApplicationNo", null, ErrorMessage = "Please Enter atleast one Value")]
        public virtual System.Nullable<int> ApplicationId { get; set; }
        [RequiredIf("ApplicationId", null, ErrorMessage = "Please Enter atleast one Value")]
        public virtual System.Nullable<Int64> ApplicationNo { get; set; }
        public virtual System.Nullable<int> UniqueId  { get; set; }
        [Required(ErrorMessage = "Please Check this Box")]
        public virtual bool DocumentCheck { get; set; }
        [Required(ErrorMessage = "Enter Fee")]
        public virtual string FeeAmount { get; set; }
        public virtual string ServiceCode { get; set; }
        [Required(ErrorMessage = "Enter Observation Remarks")]
        public virtual string ObservationRemarks { get; set; }
        [Required(ErrorMessage = "Please Capture/Upload Photo")]
        public virtual string PhotoSource { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Please Check the checkbox")]
        public virtual bool check { get; set; }


        [RequiredIf("PhotoSource", "U", ErrorMessage = "Please Upload Scan Photo")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg" }, MaxContentLength = (int)LengthList.AppLength, MaxFileLength = (int)LengthList.AppPhoto, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase ApplicantPhoto { get; set; }
        [RequiredIf("PhotoSource", "C", ErrorMessage = "Plesae Capture Image")]
        public virtual string PhotoData { get; set; }
        public virtual string ApplicantPhotoData { get; set; }
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public HttpPostedFileBase ApplicantPhotoFile { get; set; }

        public DataTable data { get; set; }
        public DataTable dataa { get; set; }

        public virtual ApplicantDetails ApplicantDetails { get; set; }
        public virtual ApplicationDetails ApplicationDetails { get; set; }
        public virtual VerifierVerificationDetails VerifierVerificationDetails { get; set; }
        public virtual ApplicationDetailsDomicile ApplicationDetailsDomicile { get; set; }
        public virtual ApplicationMarriageDetails ApplicationMarriageDetails { get; set; }
        public virtual ApplicationEnclosureDetails ApplicationEnclosureDetails { get; set; }
        public virtual ApplicationPhotoMaster ApplicationPhotoMaster { get; set; }
        public virtual ApplicationOldAgeDetails ApplicationOldAgeDetails { get; set; }
        public virtual ApplicationDetailsNationality ApplicationDetailsNationality { get; set; }
        public virtual ApplicationDetailsSolvency ApplicationDetailsSolvency { get; set; }
        public virtual ApplicationDetailsDisability ApplicationDetailsDisability { get; set; }
        public virtual ApplicationHandicappedDetails ApplicationHandicappedDetails { get; set; }
        public virtual ApplicationDetailsBirth ApplicationDetailsBirth { get; set; }
        public virtual ApplicationDetailsDeath ApplicationDetailsDeath { get; set; }
        public virtual ApplicationDetailsIncome ApplicationDetailsIncome { get; set; }
        public ApplicationDetailsSCST ApplicationDetailsSCST { get; set; }
        public ApplicationDetailsST ApplicationDetailsST { get; set; }
        public ApplicationDetailsOBC ApplicationDetailsOBC { get; set; }
        public ApplicationDetailsLalDora ApplicationDetailsLalDora { get; set; }
        public ApplicationDetailsSurviving ApplicationDetailsSurviving { get; set; }
        public virtual ApplicationWidowDetails ApplicationWidowDetails { get; set; }
        //public ApplicationRTIQuestionDetail ApplicationRTIQuestionDetail { get; set; }
        //public ApplicationRTIMainDetail ApplicationRTIMainDetail { get; set; }
        //public ApplicationDetailsRTIAns ApplicationDetailsRTIAns { get; set; }
        public virtual MarriageWitnessMaster MarriageWitness1 { get; set; }
        public virtual MarriageWitnessMaster MarriageWitness2 { get; set; }
        public virtual ApplicantReciept ApplicantReciept { get; set; }
        public ApplicationDetailsCDV ApplicationDetailsCDV { get; set; }
        public ApplicationDetailsNOC ApplicationDetailsNOC { get; set; }
        public ApplicationDetailsBOCWAct ApplicationDetailsBOCWAct { get; set; }
        public ApplicationDetailsCLAct ApplicationDetailsCLAct { get; set; }
        public ApplicationDetailsContractor ApplicationDetailsContractor { get; set; }
        public ApplicationDetailsNT ApplicationDetailsNT { get; set; }
        public NfsApplicationDetails NfsApplicationDetails { get; set; }
        public HeSkillDevelopmentScheme HeSkillDevelopmentScheme { get; set; }
        public ApplicationDetailsConsWorker ApplicationDetailsConsWorker { get; set; }
        public RenewalConsWorker RenewalConsWorker { get; set; }

        public RegisterModel RegisterModel { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string LocalityId { get; set; }
        public virtual string ApplicantUserId { get; set; }
        public virtual string ApplicantSubDivCode { get; set; }
        public virtual string ApplicantDistrictCode { get; set; }
        public virtual string SubDivDescription { get; set; }
        public virtual string DistrictName { get; set; }

        public SelectList AllLocalityList
        {
            get
            {
                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.WhetherActive=@WhetherActive and lm.WhetherActive=@WhetherActive ";
                if (Sessions.getEmployeeUser() != null) { if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().SubDivCode)) { Qry += " and LS.SubDivCode=@ParamSubDivCode"; } }
                Qry += " order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@WhetherActive", CustomText.TRUE.ToString());
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
    }
}