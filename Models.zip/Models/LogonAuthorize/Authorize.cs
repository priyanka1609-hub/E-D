﻿using System.Web;
using System.Web.Security;
using Edistrict.Models.ApplicationService;
using Edistrict.Models.Entities;
using Npgsql;
using Edistrict.Models.CustomClass;
using Edistrict.Models.DataService;

namespace Edistrict.Models.LogonAuthorize
{
    public class Authorize
    {
        public static RegistrationMaster ValidateCitizenUser(string UserID, string Password, bool? whethercheck = false)
        {
            string Qry = "select WhetherPasswordChange,RegistrationID,dbo.udf_general_decrypt(DocumentNo) as DocumentNo,ApplicantName,ApplicantGender,AadharApplicantFatherName,ApplicantFatherName,AadharApplicantDOB,ApplicantDOB,AadharApplicantAddress,ApplicantLocalityId,ApplicantMobileNo,ApplicantEmail,ApplicantPassword,ApplicantAccessCode,RegistrationDate,ApplicantIpAddress,LastActionPerformed from web.RegistrationMaster where RegistrationID=@RegistrationID and ParentRegistrationId is null";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@RegistrationID", UserID);
            RegistrationMaster objUser = RegistrationMaster.Get<RegistrationMaster>(new RegistrationMaster(), Cmd);

            if (objUser.RegistrationID.HasValue)
            {
                string Pass = objUser.ApplicantPassword;
                string Salt = HttpContext.Current.Session["salt"].ToString().Trim();
                if (whethercheck == true) { Pass = FormsAuthentication.HashPasswordForStoringInConfigFile(Pass + Salt, "md5").ToString().ToLower(); }
                else { Pass = Utility.GenerateSHA512(Pass + Salt).ToString().ToLower(); }
                if (Password.Equals(Pass))
                    return objUser;
                else
                    return null;
            }
            else
            {
                return null;
            }
        }
        public static UserMaster ValidateDeprtmentUser(string UserID, string Password, bool? IsMd5 = false, bool? IsTransaction = false)
        {
            string Qry = "SELECT UM.UID,UM.UserId,UM.Password,UM.TransactionPassword,UM.userName,UM.Permission,UM.ContactNo,UM.emailid,UM.DeptCode,UM.DistrictCode,UM.CreateDate,UM.WhetherActive,RS.SubDivCode,RS.ServiceCode,UM.whetherpasswordchange,UM.authorizationid,whetherbiometricrequired,UM.AuthenticationTypeId from dbo.UserMaster UM left outer join (select UMS.Uid,array_to_string(array_agg(distinct cast(SDM.SubDivCode as varchar)), ',') as SubDivCode,array_to_string(array_agg(distinct cast(ServiceCode as varchar)), ',') as ServiceCode from dbo.UserMaster UMS left outer join UserToSubDivMaster SDM on SDM.Uid=UMS.Uid left outer join UserToServiceMaster SVC on SVC.Uid=UMS.Uid where UMS.UserID=@UserID group by UMS.Uid) RS on RS.Uid= UM.UID where UM.UserID=@UserID";
            NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
            Cmd.Parameters.AddWithValue("@UserID", UserID);
            UserMaster objUser = UserMaster.Get<UserMaster>(new UserMaster(), Cmd);

            if (objUser.UserId != null && objUser.UserId.Length > 0)
            {
                Cmd = new NpgsqlCommand("select logindatetime from departmentlogintrail where userid=@userid and actionvalueid=@actionvalueid order by 1 desc limit 1");
                Cmd.Parameters.AddWithValue("@userid", UserID);
                Cmd.Parameters.AddWithValue("@actionvalueid", (int)ValueId.LoginSuccess);
                objUser.LastLoginAttempt = new GetData().SelectColumns(Cmd)[0];

                string Pass = string.Empty;
                string Salt = HttpContext.Current.Session["salt"].ToString().Trim();
                if (IsTransaction == true) { Pass = objUser.TransactionPassword; } else { Pass = objUser.Password; }
                
                if (IsMd5 == true) { Pass = FormsAuthentication.HashPasswordForStoringInConfigFile(Pass + Salt, "md5").ToString().ToLower(); } else { Pass = Utility.GenerateSHA512(Pass + Salt).ToString().ToLower(); }
                if (Password.Equals(Pass))
                    return objUser;
                else
                    return null;
            }
            else
            {
                return null;
            }
        }
    }
}