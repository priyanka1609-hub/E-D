﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using Edistrict.Models.Entities;
using Edistrict.Models.CustomClass;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomAttribute;
using System.Web.Mvc;
using Edistrict.Models.ApplicationService;
using Npgsql;

namespace Edistrict.Models
{
    public class SdmModels
    {
        [Required(ErrorMessage = "Application No. Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        [StringLength(14, MinimumLength = 14, ErrorMessage = "Enter Valid Application No.")]
        public virtual string ApplicationNo { get; set; }
        public virtual string ServiceCode { get; set; }
        [Required(ErrorMessage = "Application No. Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        [StringLength(14, MinimumLength = 10, ErrorMessage = "Enter Valid Application No.")]
        public virtual string EppApplicationNo { get; set; }
        [Required(ErrorMessage = "Issuing Authority Required")]
        public virtual string IssuingAuthority { get; set; }
        [Required(ErrorMessage = "Issuing Authority Address Required")]
        public virtual string IssuingAuthorityAddress { get; set; }
        [Required(ErrorMessage = "Telephone No. Required")]
        public virtual string TelephoneNo { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string MobileNo { get; set; }

        [Required(ErrorMessage = "Please Select Marriage Act")]
        public virtual string MarriageActId { get; set; }
        [Required(ErrorMessage = "Enter Remarks")]
        public virtual string ApplicationRemarks { get; set; }
        [Required(ErrorMessage = "Select Value")]
        public virtual string StatusId { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string SolemnizationDate { get; set; }
        public virtual string OldSolemnizationDate { get; set; }
        public virtual string Type { get; set; }

        [Required(ErrorMessage = "Year Required")]
        public string Year { get; set; }
        [Required(ErrorMessage = "Month Required")]
        public string Month { get; set; }
        [Required(ErrorMessage = "Category Required")]
        public virtual string Category { get; set; }

        public DataTable data { get; set; }
        public DataTable data1 { get; set; }

        public ApplicantDetails ApplicantDetails { get; set; }
        public ApplicationDetails ApplicationDetails { get; set; }
        public ApplicationMarriageDetails ApplicationMarriageDetails { get; set; }
        public MarriageWitnessMaster MarriageWitnessDetails { get; set; }
        public virtual LBRGrievanceDetails LBRGrievanceDetails { get; set; }
        public virtual ApplicationDetailsLBRRecovery ApplicationDetailsLBRRecovery { get; set; }

        public SelectList CategoryList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "ST", Value = "ST" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList DecisionList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Approve", Value = ((int)Status.TEHSREC).ToString() });
                list.Add(new SelectListItem() { Text = "Reject", Value = ((int)Status.TEHSREJ).ToString() });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public SelectList ReasonMasterList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select RM.ReasonCode,RM.ReasonDetail from ReasonMaster RM  inner join  reasontoservicemaster RS on RM.ReasonCode=RS.ReasonCode where RM.whetheractive=@whetheractive and RS.whetheractive=@whetheractive and RS.ServiceCode=@ServiceCode order by RS.DisplaySequence ");
                cmd.Parameters.AddWithValue("@whetheractive", CustomText.TRUE.ToString());
                cmd.Parameters.AddWithValue("@ServiceCode", ApplicationDetails.ServiceCode);
                List<ReasonMaster> ReasonMasterList = ReasonMaster.List<ReasonMaster>(cmd);
                return new SelectList(ReasonMasterList, "ReasonCode", "ReasonDetail");
            }
            set { }
        }
        public virtual SelectList MonthList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                DateTime month = Convert.ToDateTime("01/01/2012");
                for (int i = 0; i < 12; i++)
                {
                    DateTime NextMonth = month.AddMonths(i);
                    list.Add(new SelectListItem() { Text = NextMonth.ToString("MMMM"), Value = (i + 1).ToString() });
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList YearList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int varYear = 2015;
                for (int i = varYear; i < DateTime.Now.AddYears(1).Year; i++)
                {
                    list.Add(new SelectListItem() { Text = varYear.ToString(), Value = varYear.ToString() });
                    varYear++;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList LBRDecisionList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Satisfactory", Value = ((int)LBRStatus.Satisfactory).ToString() });
                list.Add(new SelectListItem() { Text = "Imposed Penalty", Value = ((int)LBRStatus.PenaltyImposed).ToString() });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        [CustomProperty]
        public SelectList EppStatusList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId and s1.whetheractive not in (@whetheractive) order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.EppStatusList);
                Cmd.Parameters.AddWithValue("@whetheractive", CustomText.False.ToString());
                List<SelectValueMaster> EppStatusList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(EppStatusList, "SelectValueName", "SelectValueName");
            }
            set { }
        }
    }
}