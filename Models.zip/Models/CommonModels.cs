﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Edistrict.Models.CustomAttribute;
using Edistrict.Models.Entities;
using System.Data;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Edistrict.Models.CustomClass;
using Edistrict.Models.ApplicationService;
using Npgsql;
using Edistrict.Models.DataService;

namespace Edistrict.Models
{
    public class CommonModels
    {
        [Required(ErrorMessage = "Application Id Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicationId { get; set; }
        [Required(ErrorMessage = "Application No. Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        [StringLength(14, MinimumLength = 14, ErrorMessage = "Enter Valid Application No.")]
        public virtual string ApplicationNo { get; set; }
        [Required(ErrorMessage = " Name Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]	
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        public virtual string ApplicantName { get; set; }
        [StringLength(12, MinimumLength = 12, ErrorMessage = "Enter Valid AADHAAR"), Required(ErrorMessage = "AADHAAR No. Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid AADHAAR")]
        public virtual string ApplicantAadhaarNo { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]	
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        public virtual string ApplicantFatherName { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        [DataType(DataType.Date), Required(ErrorMessage = "DOB Required")]
        [RegularExpression(@"^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((1[9]|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((1[9]|[2-9]\d)\d{2}))|(29\/02\/((1[9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|(([2468][048]|[3579][26])00))))$", ErrorMessage = "Date is not valid must be like (DD/MM/YYYY)")]
        public virtual string ApplicantDob { get; set; }
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value"), Required(ErrorMessage = "PinCode required")]
        [RegularExpression(@"^[1-1][1-1][0-9]{4}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string ApplicantPinCode { get; set; }
        public virtual string ApplicationStatusId { get; set; }
        [StringLength(1), Required(ErrorMessage = "Gender Required")]
        public virtual string ApplicantGender { get; set; }
        [Required(ErrorMessage = "Registration Id Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string RegistrationId { get; set; }
        [Required(ErrorMessage = "Select Value")]
        public virtual string StatusId { get; set; }
        [RequiredIf("OtherObjection", null, ErrorMessage = "Please Select at least one from objections")]
        public virtual string ObjectionsList { get; set; }
        [RequiredIf("ObjectionsList", null, ErrorMessage = "Please Select at least one from objections")]
        public virtual string OtherObjection { get; set; }
        [RequiredIf("OtherObjection", "True", ErrorMessage = "Fill Other Remarks")]
        public virtual string OtherRemarks { get; set; }
        public virtual string ObjectionDetailId { get; set; }
        public virtual string ObjectionId { get; set; }
        [StringLength(250, MinimumLength = 5, ErrorMessage = "Enter Valid Value")]
        public virtual string JustifyRemarks { get; set; }
        public virtual string DeptCode { get; set; }
        public virtual string ServiceCode { get; set; }
        public virtual string RequestType { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string LocalityName { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Landmark { get; set; }
        public virtual string WhetherRecommend { get; set; }
        public virtual string type { get; set; }
        [Required(ErrorMessage = "Please Select Marriage Act")]
        public virtual string MarriageActId { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public string Captcha { get; set; }
        [Required(ErrorMessage = "Please Capture/Upload Photo")]
        public virtual string PhotoSource { get; set; }
        [RequiredIf("PhotoSource", "C", ErrorMessage = "Plesae Capture Image")]
        public virtual string PhotoData { get; set; }
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^[1-1][1-1][0-9]{4}$", ErrorMessage = "Enter Valid PinCode")]
        public virtual string PinCode { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Please accept the declaration")]
        public virtual bool checkDeclaration { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Check Box Checked Required")]
        public virtual bool consentcheck { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string consentcheckid { get; set; }
        public virtual string DistrictCode { get; set; }
        public virtual string SubDivCode { get; set; }
        public virtual string OfficeCode { get; set; }
        public virtual string MacAddress { get; set; }
        public virtual string BiosAddress { get; set; }
        public virtual string IpAddress { get; set; }
        public virtual string ApplicantUserId { get; set; }
        public virtual string Description { get; set; }
        public virtual string DmlActionName { get; set; }
        public virtual string UserId { get; set; }
        public virtual string ApplicationDate { get; set; }
        public virtual string LastActionDate { get; set; }
        public virtual string AppointmentId { get; set; }
        public virtual string AppointmentTypeId { get; set; }
        public virtual string HSubDivCode { get; set; }
        public virtual string WSubDivCode { get; set; }
        public virtual string MSubDivCode { get; set; }
        public virtual string HSRCode { get; set; }
        public virtual string WSRCode { get; set; }
        public virtual string MSRCode { get; set; }
        public virtual string Source { get; set; }
        public virtual string IsAlreadyVerified { get; set; }
        public virtual string CustomText { get; set; }
        public virtual System.Nullable<int> CustomId { get; set; }
        public virtual bool WhetherVerification { get; set; }
        public virtual bool WhetherVerificationLetterRequired { get; set; }
        [Required(ErrorMessage = "Enter Remarks")]
        public virtual string ApplicationRemarks { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string WhetherAlreadyApply { get; set; }
        [RequiredIf("WhetherAlreadyApply", "Y", ErrorMessage = "Please Select Service")]
        public virtual string ExistingServiceCode { get; set; }
        [RequiredIf("WhetherAlreadyApply", "Y", ErrorMessage = "Please Select Service")]
        public virtual string ExistingApplicationNo { get; set; }
        [Required(ErrorMessage = "Please Select Verification")]
        public virtual string SelectValueId { get; set; }
        [RequiredIf("SelectValueId", "Y", ErrorMessage = "Please Select Verifier")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string VerifierCode { get; set; }
        [Required(ErrorMessage = "Please Select Verifier")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string NewVerifierCode { get; set; }
        [Required(ErrorMessage = "Please select a Court")]
        public virtual string CourtId { get; set; }
        [Required(ErrorMessage = "Please select a Sub-Court")]
        public virtual string SubCourtId { get; set; }
        [Required(ErrorMessage = "Please enter Date")]
        public virtual string CauseDateOfNextHearing { get; set; }
        public virtual string TrackDateOfNextHearing { get; set; }
        public virtual string CaseNo { get; set; }
        public virtual string Section { get; set; }
        public virtual string CaseTitle { get; set; }
        public virtual string FPartyName { get; set; }
        public virtual bool WhetherView { get; set; }
        [Required(ErrorMessage = "Value Required")]
        [StringLength(250, MinimumLength = 20, ErrorMessage = "Enter Valid Value")]
        public virtual string ReasonOfAppointment { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string AppointmentDate { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Appointmenttime { get; set; }
        [Required(ErrorMessage = "Please Select")]
        public virtual string TransactionType { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PNo { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PAmount { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PDate { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PNo2 { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PAmount2 { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PDate2 { get; set; }
        public virtual string ApplicationIdNo { get; set; }
        public virtual string ServerType { get; set; }
        public virtual string EncId { get; set; }
        public string DocumentNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string OTP { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string UpdateMobileNo { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]	
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Name")]
        public virtual string UpdateName { get; set; }
        [ValidateDateRange(minDate = null, maxDate = null)]
        public virtual string UpdateDOB { get; set; }
        public virtual string UpdateGender { get; set; }
        [RequiredIf("WhetherAlreadyApply", "N", ErrorMessage = "Please Select Value")]
        public virtual string Whethermobileavailable { get; set; }
        [StringLength(12, MinimumLength = 12, ErrorMessage = "Enter Valid AADHAAR")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid AADHAAR")]
        [RequiredIf("WhetherAlreadyApply", "Y", ErrorMessage = "AADHAAR Required")]
        public virtual string AadhaarNo { get; set; }
        [RequiredIf("RegDocNo", "null", ErrorMessage = "Value Required.")]
        public virtual string AppDocNo { get; set; }
        [RequiredIf("AppDocNo", "null", ErrorMessage = "Value Required.")]
        public virtual string RegDocNo { get; set; }
        [RequiredIf("WhetherAlreadyApply", "N", ErrorMessage = "Please Select Value")]
        public virtual string DocId { get; set; }
        [Required(ErrorMessage = "Please fill in remarks")]
        [StringLength(4000, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string VerifierRemarks { get; set; }
        [Required(ErrorMessage = "Please enter additional fee")]
        [Range(1, 999999999, ErrorMessage = "Enter number between 0 to 1000")]
        [StringLength(6, MinimumLength = 1, ErrorMessage = "Enter Valid Value")]
        public virtual string AdditionalFee { get; set; }
        public virtual string LocationofLift { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string ApplicationServiceCode { get; set; }
        [Required(ErrorMessage = "Please select a Village")]
        public virtual string VillageId { get; set; }
        [Required(ErrorMessage = "Please Enter Date.")]
        public virtual string DischargeDate { get; set; }
        [Required(ErrorMessage = "Khasra No. Required")]
        public virtual string KhasraNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string TransactionPassword { get; set; }
        public virtual string ActionType { get; set; }
        public virtual string ApplicantAccountNo { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string FeeAmount { get; set; }
        [Required(ErrorMessage = "Please select Year")]
        public virtual string InstitutedYear { get; set; }
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string MobileNo { get; set; }
        public virtual string RegApplicationNo { get; set; }
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        [StringLength(14, MinimumLength = 14, ErrorMessage = "Enter Valid Application No.")]
        public virtual string PayApplicationNo { get; set; }
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        public virtual string PayApplicationId { get; set; }
        [Required(ErrorMessage = "Payment Order No. Required")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Enter Valid Value")]
        [StringLength(14, MinimumLength = 14, ErrorMessage = "Enter Valid Application No.")]
        public virtual string PaymentOrderNo { get; set; }
        public virtual string PAmount3 { get; set; }
        public virtual string PAmount4 { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PNo3 { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PNo4 { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PDate3 { get; set; }
        [Required(ErrorMessage = "Please Fill")]
        public virtual string PDate4 { get; set; }
        public virtual string WhetherWorkerIncreased { get; set; }
        public virtual string WhetherApplRenewal { get; set; }
        public virtual int PTotalAmount { get; set; }
        [Required(ErrorMessage = " Name Required")]
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]	
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid value")]
        public virtual string SchoolName { get; set; }
        [Required(ErrorMessage = " Name Required")]
        [StringLength(250, MinimumLength = 2, ErrorMessage = "Enter Valid Value")]
        public virtual string SchoolAddress { get; set; }
        [Required(ErrorMessage = "Name Required")]
        public virtual string ZoneId { get; set; }
        [Required(ErrorMessage = " Name Required")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)", ErrorMessage = "Enter Valid Value")]
        public virtual string EmailId { get; set; }
        [Required(ErrorMessage = "Mobile No. Required")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter Valid Value")]
        [RegularExpression(@"^(?!.*([0]{6}|[1]{6}|[2]{6}|[3]{6}|[4]{6}|[5]{6}|[6]{6}|[7]{6}|[8]{6}|[9]{6}).*)([7-9][0-9]{9})$", ErrorMessage = "Enter Valid Mobile No.")]
        public virtual string ApplicantMobileNo { get; set; }
        //[RequiredIf("ApplicantMobileNo", "null", ErrorMessage = "Mobile No. Required")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)", ErrorMessage = "Enter Valid Value")]
        public virtual string ApplicantEmailId { get; set; }
        [Required(ErrorMessage = " Name Required")]
        public virtual string NodalOfficer { get; set; }
        [Required(ErrorMessage = "Please Select Value")]
        public virtual string AcademicSession { get; set; }
        public virtual string AcademicSessionType { get; set; }
        public virtual string SchoolId { get; set; }
        public virtual string readOnly { get; set; }
        public virtual string WhetherApplAmend { get; set; }
        [Required(ErrorMessage = "Required")]
        public virtual string DistrictId { get; set; }
        public virtual string CollegeZone { get; set; }
        public virtual string PAmount5 { get; set; }
        public virtual string Flag { get; set; }
        [Required(ErrorMessage = " Value Required")]
        public virtual string GrievanceId { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]	
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid Father Name")]
        public virtual string UpdateFatherName { get; set; }
        [ValidateStringFromList(ErrorMessage = "Enter Value Name")]	
        [RegularExpression(@"^([A-Za-z]*)+(?:(([A-Za-z].)\s)|([A-Za-z].))*([A-Za-z])+$", ErrorMessage = "Enter valid  Mother Name")]
        public virtual string UpdateMotherName { get; set; }
        [BooleanMustBeTrue(ErrorMessage = "Please Check the checkbox")]
        public virtual bool check { get; set; }
        public virtual string DefId { get; set; }
        public virtual string InspectionId { get; set; }
        public virtual bool WhetherDocVerified { get; set; }
        [Required(ErrorMessage = "Value Required")]
        public virtual string Permission { get; set; }
        public virtual byte[] UserPhoto { get; set; }
        [Required(ErrorMessage = " Value Required")]
        public virtual string CancelReasonCode { get; set; }

        public virtual DataSet dsdata { get; set; }
        public virtual DataTable data { get; set; }
        public virtual DataTable datab { get; set; }
        public virtual DataTable data1 { get; set; }
        public virtual DataTable data2 { get; set; }
        public virtual DataTable data3 { get; set; }
        public virtual DataTable data4 { get; set; }
        public virtual DataTable dtVerificationLetter { get; set; }


        
        

        [Required(ErrorMessage = "Please Upload Document")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg", "application/pdf" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg", ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public virtual HttpPostedFileBase ApplicantFile { get; set; }
        public virtual HttpPostedFileBase CidrFile { get; set; }
        [Required(ErrorMessage = "Please Upload Document")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg", "application/pdf" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg", ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public virtual HttpPostedFileBase VerificationLetter { get; set; }
        [Required(ErrorMessage = "Please Upload Document")]
        [HttpFile(AllowedContentTypes = new string[] { "application/pdf" }, AllowedFileExtensions = new string[] { ".pdf" }, MaxContentLength = (int)LengthList.EncContentMarr, MaxFileLength = (int)LengthList.EncFileMarr, ErrorMessage = "Invalid / Maximum length File")]
        public virtual string EnclosureData { get; set; }
        [RequiredIf("PhotoSource", "U", ErrorMessage = "Please Upload Scan Photo")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg" }, MaxContentLength = (int)LengthList.AppLength, MaxFileLength = (int)LengthList.AppPhoto, ErrorMessage = "Invalid / Maximum length File")]
        public virtual HttpPostedFileBase ApplicantPhoto { get; set; }
        [Required(ErrorMessage = "Document Required")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg", "application/pdf" }, AllowedFileExtensions = new string[] { ".jpg", ".jpeg", ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public virtual HttpPostedFileBase RegistrationDocumentData { get; set; }
        [Required(ErrorMessage = "Please Upload")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg", "application/pdf" }, AllowedFileExtensions = new string[] { ".jpeg", ".jpg", ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public virtual HttpPostedFileBase PFile { get; set; }
        [Required(ErrorMessage = "Please Upload")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg", "application/pdf" }, AllowedFileExtensions = new string[] { ".jpeg", ".jpg", ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public virtual HttpPostedFileBase PFile2 { get; set; }
        [Required(ErrorMessage = "Please Upload")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg", "application/pdf" }, AllowedFileExtensions = new string[] { ".jpeg", ".jpg", ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public virtual HttpPostedFileBase PFile3 { get; set; }
        [Required(ErrorMessage = "Please Upload")]
        [HttpFile(AllowedContentTypes = new string[] { "image/jpeg", "image/jpg", "application/pdf" }, AllowedFileExtensions = new string[] { ".jpeg", ".jpg", ".pdf" }, MaxContentLength = (int)LengthList.EncContent, MaxFileLength = (int)LengthList.EncFile, ErrorMessage = "Invalid / Maximum length File")]
        public virtual HttpPostedFileBase PFile4 { get; set; }

        public virtual ApplicantDetails ApplicantDetails { get; set; }
        public virtual ApplicationDetails ApplicationDetails { get; set; }
        public virtual ApplicationDetailsDomicile ApplicationDetailsDomicile { get; set; }
        public virtual ApplicationHandicappedDetails ApplicationHandicappedDetails { get; set; }
        public virtual ApplicationOldAgeDetails ApplicationOldAgeDetails { get; set; }
        public virtual ApplicationDetailsNationality ApplicationDetailsNationality { get; set; }
        public virtual ApplicationDetailsDisability ApplicationDetailsDisability { get; set; }
        public virtual ApplicationDetailsSolvency ApplicationDetailsSolvency { get; set; }
        public virtual ApplicationDetailsBirth ApplicationDetailsBirth { get; set; }
        public virtual ApplicationDetailsDeath ApplicationDetailsDeath { get; set; }
        public virtual VerifierVerificationDetails VerifierVerificationDetails { get; set; }
        public virtual ApplicationDetailsIncome ApplicationDetailsIncome { get; set; }
        public virtual ApplicationDetailsSCST ApplicationDetailsSCST { get; set; }
        public virtual ApplicationDetailsST ApplicationDetailsST { get; set; }
        public virtual ApplicationDetailsOBC ApplicationDetailsOBC { get; set; }
        public virtual ApplicationDetailsLalDora ApplicationDetailsLalDora { get; set; }
        public virtual ApplicationDetailsSurviving ApplicationDetailsSurviving { get; set; }
        public virtual VerifierWitnessMaster VerifierWitnessMaster { get; set; }
        public virtual WitnessDetailsLalDora LalDoraWitnessDetails { get; set; }
        public virtual ApplicationLetterDetails ApplicationLetterDetailsModel { get; set; }
        public virtual MarriageWitnessMaster MarriageWitnessDetails { get; set; }
        public virtual ApplicationEnclosureDetails ApplicationEnclosureDetails { get; set; }
        public virtual ApplicationMarriageDetails ApplicationMarriageDetails { get; set; }
        public virtual ApplicationOldAgeDetails ApplicationDetailsOldAge { get; set; }
        public virtual ApplicationPhotoMaster ApplicationPhotoMaster { get; set; }
        public virtual SearchApplication SearchApplication { get; set; }
        public virtual ApplicantReciept ApplicantReciept { get; set; }
        public virtual ApplicationDetailsCinematograph ApplicationDetailsCinematograph { get; set; }
        //public virtual ApplicationRTIQuestionDetail ApplicationRTIQuestionDetail { get; set; }
        //public virtual ApplicationRTIMainDetail ApplicationRTIMainDetail { get; set; }
        //public virtual ApplicationDetailsRTIAns ApplicationDetailsRTIAns { get; set; }
        public virtual ApplicationDetailsCDV ApplicationDetailsCDV { get; set; }
        public virtual CDVAwardDetails CDVAwardDetails { get; set; }
        public virtual CDVApplicantTrainingDetails CDVApplicantTrainingDetails { get; set; }
        public virtual CDVDutyDetails CDVDutyDetails { get; set; }
        public virtual ApplicationWidowDetails ApplicationWidowDetails { get; set; }
        public virtual ApplicationInspectionDetails ApplicationInspectionDetails { get; set; }
        public virtual OddEvenApplicationDetails OddEvenApplicationDetails { get; set; }
        public virtual ApplicationDetailsBOCWAct ApplicationDetailsBOCWAct { get; set; }
        public virtual ApplicationDetailsCLAct ApplicationDetailsCLAct { get; set; }
        public virtual ApplicationDetailsContractor ApplicationDetailsContractor { get; set; }
        public virtual ApplicationDetailsNT ApplicationDetailsNT { get; set; }
        public virtual LBRGrievanceDetails LBRGrievanceDetails { get; set; }
        public virtual ApplicationDetailsOldCDV ApplicationDetailsOldCDV { get; set; }
        public virtual ApplicationPaymentDetails ApplicationPaymentDetails { get; set; }
        public virtual GeneralNoticeDetails GeneralNoticeDetails { get; set; }
        public virtual ApplicationDetailsNOC ApplicationDetailsNOC { get; set; }
        public virtual HeSkillDevelopmentScheme HeSkillDevelopmentScheme { get; set; }
        public virtual MenuMaster MenuMaster { get; set; }
        public virtual HeQueryDetails HeQueryDetails { get; set; }
        public virtual ApplicationDetailsLadli ApplicationDetailsLadli { get; set; }
        public virtual ApplicationDetailsDFBScheme ApplicationDetailsDFBScheme { get; set; }
        public virtual NfsApplicationDetails NfsApplicationDetails { get; set; }
        public virtual ApplicationDetailsPrematsSC ApplicationDetailsPrematsSC { get; set; }
        public virtual ApplicationDetailsFinancialAssistance ApplicationDetailsFinancialAssistance { get; set; }
        public virtual ApplicationDetailsMeritscholarshipSchool ApplicationDetailsMeritscholarshipSchool { get; set; }
        public virtual ApplicationDetailsDrbrAmbedkarToppers ApplicationDetailsDrbrAmbedkarToppers { get; set; }
        public virtual ApplicationDetailsMeritProfessional ApplicationDetailsMeritProfessional { get; set; }
        public virtual ApplicationDetailsPrematOBC ApplicationDetailsPrematOBC { get; set; }
        public virtual ApplicationDetailsPostmatOBC ApplicationDetailsPostmatOBC { get; set; }
        public virtual ApplicationDetailsMutation ApplicationDetailsMutation { get; set; }
        public virtual RegistrationMaster RegistrationMaster { get; set; }
        public virtual NGTOrderCopy NGTOrderCopy { get; set; }
        public virtual ApplicationDetailsRecovery ApplicationDetailsRecovery { get; set; }
        public virtual LBRInspectionColumnMaster LBRInspectionColumnMaster { get; set; }
        public virtual ApplicationDetailsInstallationOfLift ApplicationDetailsInstallationOfLift { get; set; }
        public virtual ApplicationDetailsGrantOfPassengerLift ApplicationDetailsGrantOfPassengerLift { get; set; }
        public virtual ApplicationDetailsRenewalOfPassengerLift ApplicationDetailsRenewalOfPassengerLift { get; set; }
        public virtual ApplicationDetailsLBRRecovery ApplicationDetailsLBRRecovery { get; set; }
        public virtual HeUniversityMaster HeUniversityMaster { get; set; }
        public virtual HeCourseMaster HeCourseMaster { get; set; }
        public virtual HeInstitutionMaster HeInstitutionMaster { get; set; }
        public virtual HeFeeClaimDetails HeFeeClaimDetails { get; set; }
        public virtual HeBankBranchMaster HeBankBranchMaster { get; set; }
        public virtual BankMaster BankMaster { get; set; }
        public virtual HeMCMFinancialAssistance HeMCMFinancialAssistance { get; set; }
        public virtual ApplicationDetailsPrematSCssd ApplicationDetailsPrematSCssd { get; set; }
        public virtual ApplicationDetailsPostmatSCssd ApplicationDetailsPostmatSCssd { get; set; }
        public virtual ApplicationDetailsFirm ApplicationDetailsFirm { get; set; }
        public virtual ApplicationDetailsMigration ApplicationDetailsMigration { get; set; }
        public virtual ApplicationDetailsCEA1 ApplicationDetailsCEA1 { get; set; }
        public virtual ApplicationDetailsCEA2 ApplicationDetailsCEA2 { get; set; }
        public virtual ApplicationDetailsCEA3 ApplicationDetailsCEA3 { get; set; }
        public virtual UserMaster UserMaster { get; set; }
        public virtual ApplicationDetailsConsWorker ApplicationDetailsConsWorker { get; set; }
        public virtual UserCreationEnclosureDetails UserCreationEnclosureDetails { get; set; }
        public virtual ApplicationDetailsEC ApplicationDetailsEC { get; set; }
        public virtual ApplicationDetailsCompCertificate ApplicationDetailsCompCertificate { get; set; }
        public virtual RenewalConsWorker RenewalConsWorker { get; set; }
        public virtual ApplicationDetailsMedicalAssistance ApplicationDetailsMedicalAssistance { get; set; }
        public virtual ApplicationDetailsDisabilityPension ApplicationDetailsDisabilityPension { get; set; }
        public virtual ApplicationDetailsMaternityBenefit ApplicationDetailsMaternityBenefit { get; set; }
        public virtual ApplicationDetailsDeathBenefits ApplicationDetailsDeathBenefits { get; set; }
        public virtual ApplicationDetailsEduScholarship ApplicationDetailsEduScholarship { get; set; }
        public virtual ApplicationDetailsFamilyPension ApplicationDetailsFamilyPension { get; set; }
        public virtual ApplicationDetailsFuneralBenefit ApplicationDetailsFuneralBenefit { get; set; }
        public virtual ApplicationDetailsGrantofWork ApplicationDetailsGrantofWork { get; set; }
        public virtual ApplicationDetailsHBA ApplicationDetailsHBA { get; set; }
        public virtual ApplicationDetailsInstrumentLoan ApplicationDetailsInstrumentLoan { get; set; }
        public virtual ApplicationDetailsMarriageAssistance ApplicationDetailsMarriageAssistance { get; set; }
        public virtual ApplicationDetailsPension ApplicationDetailsPension { get; set; }
        public virtual ApplicationDetailsExgratia ApplicationDetailsExgratia { get; set; }
        public virtual ApplicationDetailsTirthYatraYojana ApplicationDetailsTirthYatraYojana { get; set; }
        public virtual ApplicationDetailsRenewalContractor ApplicationDetailsRenewalContractor { get; set; }

        public virtual SelectList LocalityList { get; set; }
        public virtual SelectList AppointmentDateList { get; set; }
        public virtual SelectList VerifierMaster { get; set; }
        public virtual SelectList VerificationSelectList { get; set; }
        public virtual SelectList ServiceMaster { get; set; }
        public virtual SelectList StatusMaster { get; set; }
        public virtual SelectList DocumentName { get; set; }
        public virtual SelectList DocumentTypeName { get; set; }
        public virtual SelectList CourtList { get; set; }
        public virtual SelectList DepartmentName { get; set; }
        public virtual SelectList HeInstitutionList { get; set; }
        public virtual SelectList SCSTDepartmentList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select distinct smvd.valueid,valuename from selectmastervaluedetails smvd inner join selectmastervaluetodetails smvtd on smvtd.valueid=smvd.valueid where mastervalueid=@mastervalueid order by valuename limit 0");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.DepartmentType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public virtual SelectList SCSTSchoolTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valueid as SelectValueId,s1.valuename as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.PostMatSchoolType);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList SubCourtList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "", Value = "" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList YesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "Y" });
                list.Add(new SelectListItem() { Text = "No", Value = "N" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList GenderList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Male", Value = "M" });
                list.Add(new SelectListItem() { Text = "Female", Value = "F" });
                list.Add(new SelectListItem() { Text = "Transgender", Value = "T" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList ObjectionMarriageRelatedList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Husband", Value = "3" });
                list.Add(new SelectListItem() { Text = "Wife", Value = "4" });
                list.Add(new SelectListItem() { Text = "Marriage Ceremony", Value = "5" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList DecisionList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Approve", Value = ((int)Status.TEHSREC).ToString() });
                list.Add(new SelectListItem() { Text = "Reject", Value = ((int)Status.TEHSREJ).ToString() });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList ReasonMasterList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select RM.ReasonCode,RM.ReasonDetail from ReasonMaster RM  inner join  reasontoservicemaster RS on RM.ReasonCode=RS.ReasonCode where RM.whetheractive=@whetheractive and RS.whetheractive=@whetheractive and RS.ServiceCode=@ServiceCode order by RS.DisplaySequence ");
                cmd.Parameters.AddWithValue("@whetheractive", Edistrict.Models.ApplicationService.CustomText.TRUE.ToString());
                cmd.Parameters.AddWithValue("@ServiceCode", ApplicationDetails.ServiceCode);
                List<ReasonMaster> ReasonMasterList = ReasonMaster.List<ReasonMaster>(cmd);
                return new SelectList(ReasonMasterList, "ReasonCode", "ReasonDetail");
            }
            set { }
        }
        public virtual SelectList AllLocalityList
        {
            get
            {
                string DeptCode = Utility.GetDeptCode(ApplicationDetails.ServiceCode);

                string Qry = "select lm.localityid,lm.localityname from localitymaster lm inner join localitytosubdivmaster LS on LS.localityid=LM.localityid inner join subdivmaster sd on sd.subdivcode=ls.subdivcode inner join districtmaster dm on dm.districtcode=sd.districtcode where dm.deptcode=@deptcode and ls.whetheractive=@whetheractive and lm.whetheractive=@whetheractive order by lm.LocalityName";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@deptcode", (int)Department.Dept001);
                Cmd.Parameters.AddWithValue("@whetheractive", Edistrict.Models.ApplicationService.CustomText.TRUE.ToString());
                List<LocalityMaster> LocalityList = LocalityMaster.List<LocalityMaster>(Cmd);
                return new SelectList(LocalityList, "LocalityId", "LocalityName");
            }
            set { }
        }
        public virtual SelectList BusinessList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Factory", Value = "Factory" });
                list.Add(new SelectListItem() { Text = "Establishment", Value = "Establishment" });
                list.Add(new SelectListItem() { Text = "Shop", Value = "Shop" });
                list.Add(new SelectListItem() { Text = "Workshop", Value = "Workshop" });
                list.Add(new SelectListItem() { Text = "Construction", Value = "Construction" });
                list.Add(new SelectListItem() { Text = "Others", Value = "Others" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList PaymentModeList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Cheque", Value = "Cheque" });
                list.Add(new SelectListItem() { Text = "Cash", Value = "Cash" });
                list.Add(new SelectListItem() { Text = "ECS", Value = "ECS" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList SatisUnsatisList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Satisfactory", Value = "Satisfactory" });
                list.Add(new SelectListItem() { Text = "Unsatisfactory", Value = "Unsatisfactory" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList SeasonalPerennialList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Seasonal", Value = "Seasonal" });
                list.Add(new SelectListItem() { Text = "Perennial", Value = "Perennial" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList WagePeriodList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Daily", Value = "Daily" });
                list.Add(new SelectListItem() { Text = "Weekly", Value = "Weekly" });
                list.Add(new SelectListItem() { Text = "Fort Nightly", Value = "Fort Nightly" });
                list.Add(new SelectListItem() { Text = "Monthly", Value = "Monthly" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList DocumentAvailableAtCitizen
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select DocumentId,DocumentName from documentmaster where documentid in (select documentid from servicetovalidateddocumentmaster) order by DocumentName");
                List<DocumentMaster> DocumentMasterList = DocumentMaster.List<DocumentMaster>(Cmd);
                return new SelectList(DocumentMasterList, "DocumentId", "DocumentName");
            }
            set { }
        }
        public virtual SelectList CRYesNoList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                list.Add(new SelectListItem() { Text = "Yes", Value = "True" });
                list.Add(new SelectListItem() { Text = "No", Value = "False" });
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList ServiceList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select ServiceCode,ServiceName from ServiceMaster where whetheractive=@whetheractive and deptcode=@deptcode order by ServiceName ");
                cmd.Parameters.AddWithValue("@whetheractive", ApplicationService.CustomText.TRUE.ToString());
                cmd.Parameters.AddWithValue("@deptcode", Sessions.getEmployeeUser().DeptCode);
                List<ServiceMaster> ServiceList = Edistrict.Models.Entities.ServiceMaster.List<ServiceMaster>(cmd);
                return new SelectList(ServiceList, "ServiceCode", "ServiceName");
            }
            set { }
        }
        public virtual SelectList SCSTSchoolNameList
        {
            get
            {
                string Qry = "select SchoolId as SelectValueId,SchoolName||','||SchoolAddress as SelectValueName from dgen.prematschoolmaster where WhetherActive=@WhetherActive order by SchoolName limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", Edistrict.Models.ApplicationService.CustomText.True.ToString());
                List<SelectValueMaster> SubDivList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(SubDivList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList HeCourseList
        {
            get
            {
                NpgsqlCommand cmd = new NpgsqlCommand("select HeCourseId,CourseName from HeCourseMaster where ServiceCode=3006 order by CourseName ");
                List<HeCourseMaster> ServiceList = Edistrict.Models.Entities.HeCourseMaster.List<HeCourseMaster>(cmd);
                return new SelectList(ServiceList, "HeCourseId", "CourseName");
            }
            set { }
        }
        public virtual SelectList SCSTDistrictList
        {
            get
            {
                string Qry = "select DistrictId as SelectValueId,DistrictName as SelectValueName from dgen.prematdistrictmaster where WhetherActive=@WhetherActive order by DistrictName limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", Edistrict.Models.ApplicationService.CustomText.True.ToString());
                List<SelectValueMaster> SubDivList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(SubDivList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList SCSTZoneList
        {
            get
            {
                string Qry = "select ZoneId as SelectValueId,ZoneName as SelectValueName from dgen.prematzonemaster where WhetherActive=@WhetherActive order by ZoneName limit 0";
                NpgsqlCommand Cmd = new NpgsqlCommand(Qry);
                Cmd.Parameters.AddWithValue("@WhetherActive", Edistrict.Models.ApplicationService.CustomText.True.ToString());
                List<SelectValueMaster> SubDivList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(SubDivList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList HeAcademicSessionList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select s1.valuename as SelectValueId,(s1.valuename::integer ||'-'||s1.valuename::integer + 1)  as SelectValueName from selectmastervaluedetails s1 inner join selectmastervaluetodetails s2 on s2.valueid=s1.valueid inner join selectmastervalue s3 on s3.mastervalueid=s2.mastervalueid where s3.MasterValueId=@MasterValueId order by s1.valuename");
                Cmd.Parameters.AddWithValue("@MasterValueId", (int)MasterValueId.HigherEduAcadmicSession);
                List<SelectValueMaster> CategoryList = SelectValueMaster.List<SelectValueMaster>(Cmd);
                return new SelectList(CategoryList, "SelectValueId", "SelectValueName");
            }
            set { }
        }
        public virtual SelectList SCSTAcademicSessionList
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int passedyear = 2016;
                //int curryear = 2016;   //----------------------Temp comment for 2017-18 session, un-comment when you wants to process for 2017-18
                int curryear = DateTime.Now.Year;

                for (int i = passedyear; i <= curryear; i++)
                {
                    list.Add(new SelectListItem() { Text = passedyear.ToString() + "-" + (passedyear + 1).ToString(), Value = passedyear.ToString() });
                    passedyear = passedyear + 1;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList SCSTAllDepartmentList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select distinct smvd.valueid,valuename from selectmastervaluedetails smvd inner join selectmastervaluetodetails smvtd on smvtd.valueid=smvd.valueid where mastervalueid=@mastervalueid order by valuename ");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.DepartmentType);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        public virtual SelectList PermissionList
        {
            get
            {
                string Qry = "select PM.pcode,pname from dbo.permissionmaster PM inner join DeptToPermissionMaster DPM on DPM.pcode=PM.pcode::int and WhetherEntryAllowed=@WhetherEntryAllowed where deptcode=@ParamDeptCode and PM.pcode not in(@Permission)";
                if (!string.IsNullOrEmpty(Sessions.getEmployeeUser().DistrictCode)) { Qry += " and DPM.whetherdistrequired=TRUE"; }
                Qry += " order by pname";
                NpgsqlCommand cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                cmd.Parameters.AddWithValue("@WhetherEntryAllowed", Edistrict.Models.ApplicationService.CustomText.TRUE.ToString());
                cmd.Parameters.AddWithValue("@Permission", Sessions.getEmployeeUser().Permission);
                List<PermissionMaster> PermissionList = PermissionMaster.List<PermissionMaster>(cmd);
                return new SelectList(PermissionList, "Pcode", "Pname");
            }

            set { }
        }
        public virtual SelectList InstitutedYearList
        {
            get
            {

                List<SelectListItem> list = new List<SelectListItem>();
                for (int i = DateTime.Today.Year; i >= 1974; i--)
                {
                    list.Add(new SelectListItem() { Text = (i).ToString(), Value = (i).ToString() });
                }

                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList SCSTParticularAcademicYear
        {
            get
            {
                List<SelectListItem> list = new List<SelectListItem>();
                int passedyear = 2016;
                int curryear = (int)AllowYear.Y2016;
                for (int i = passedyear; i <= curryear; i++)
                {
                    list.Add(new SelectListItem() { Text = passedyear.ToString() + "-" + (passedyear + 1).ToString(), Value = passedyear.ToString() });
                    passedyear = passedyear + 1;
                }
                return new SelectList(list, "Value", "Text");
            }
            set { }
        }
        public virtual SelectList SCSTParticularServiceList
        {
            get
            {
                string Qry = "select ServiceCode,ServiceName from ServiceMaster where ServiceCode in(@ParamServiceCode) and DeptCode in (@ParamDeptCode) and ServiceCode=@PrematricScholarshipSC";
                NpgsqlCommand Cmd = new NpgsqlCommand(Utility.SqlParameterToValueString(Qry));
                Cmd.Parameters.AddWithValue("@PrematricScholarshipSC", (int)ApplicationService.ServiceList.PrematricScholarshipSC);
                List<ServiceMaster> ServiceList = Edistrict.Models.Entities.ServiceMaster.List<ServiceMaster>(Cmd);
                return new SelectList(ServiceList, "ServiceCode", "ServiceName");
            }
            set { }
        }
        public virtual SelectList SWStopAppReasonList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select distinct smvd.valueid,valuename from selectmastervaluedetails smvd inner join selectmastervaluetodetails smvtd on smvtd.valueid=smvd.valueid where mastervalueid=@mastervalueid order by valuename ");
                Cmd.Parameters.AddWithValue("@mastervalueid", (int)MasterValueId.SWStopPensionReasonList);
                List<ServiceTypeMaster> ServiceTypeMasterList = ServiceTypeMaster.List<ServiceTypeMaster>(Cmd);
                return new SelectList(ServiceTypeMasterList, "ValueId", "ValueName");
            }
            set { }
        }
        #region temp member for temp document update
        [Required(ErrorMessage = "ValueRequired")]
        public virtual string DocumentType { get; set; }
        public SelectList OperationTypeList
        {
            get
            {
                NpgsqlCommand Cmd = new NpgsqlCommand("select DocumentId,DocumentName from dbo.DocumentMaster where DocumentId in (@CopyOfCasteCertificate,@AadhaarCard,@AadhaarCardCopy,@CopyOfIncomeCertificate) order by DocumentName");
                Cmd.Parameters.AddWithValue("@CopyOfCasteCertificate", (int)DocumentId.CopyOfCasteCertificate);
                Cmd.Parameters.AddWithValue("@CopyOfIncomeCertificate", (int)DocumentId.CopyOfIncomeCertificate);
                Cmd.Parameters.AddWithValue("@AadhaarCard", (int)DocumentId.AadhaarCard);
                Cmd.Parameters.AddWithValue("@AadhaarCardCopy", (int)DocumentId.AadhaarCardCopy);
                List<DocumentMaster> DocumentMasterList = DocumentMaster.List<DocumentMaster>(Cmd);
                return new SelectList(DocumentMasterList, "DocumentId", "DocumentName");
            }
            set { }
        }
        #endregion

    }
}