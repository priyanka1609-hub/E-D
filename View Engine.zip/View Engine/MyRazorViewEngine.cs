﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Web.Mvc;

namespace Edistrict.View_Engine
{
    public class MyRazorViewEngine : RazorViewEngine
    {
        public MyRazorViewEngine()
            : base()
        {
                AreaViewLocationFormats = new[] {
                "~/Areas/{2}/Views/{1}/{0}.cshtml",
                "~/Areas/{2}/Views/Shared/{0}.cshtml",
                "~/Areas/{2}/Views/Account/{0}.cshtml",
                "~/Areas/{2}/Views/Admin/{0}.cshtml",
                "~/Areas/{2}/Views/Ajax/{0}.cshtml",
                "~/Areas/{2}/Views/Common/{0}.cshtml",
                "~/Areas/{2}/Views/Dealing/{0}.cshtml",
                "~/Areas/{2}/Views/Epay/{0}.cshtml",
                "~/Areas/{2}/Views/Error/{0}.cshtml",
                "~/Areas/{2}/Views/Home/{0}.cshtml",
                "~/Areas/{2}/Views/Print/{0}.cshtml",
                "~/Areas/{2}/Views/Public/{0}.cshtml",
                "~/Areas/{2}/Views/Receiving/{0}.cshtml",
                "~/Areas/{2}/Views/Report/{0}.cshtml",
                "~/Areas/{2}/Views/Sdm/{0}.cshtml",
                "~/Areas/{2}/Views/Sign/{0}.cshtml",
                "~/Areas/{2}/Views/Tehsildar/{0}.cshtml",
                "~/Areas/{2}/Views/Verifier/{0}.cshtml",
                "~/Areas/{2}/Views/Window/{0}.cshtml",
            };

                AreaMasterLocationFormats = new[] {
                "~/Areas/{2}/Views/{1}/{0}.cshtml",
                "~/Areas/{2}/Views/Shared/{0}.cshtml",
            };

                AreaPartialViewLocationFormats = new[] {
                "~/Areas/{2}/Views/{1}/{0}.cshtml",
                "~/Areas/{2}/Views/Shared/{0}.cshtml",
                "~/Areas/{2}/Views/Shared/PartialService/{0}.cshtml",
            };

                ViewLocationFormats = new[] {
                "~/Views/{1}/{0}.cshtml",
                "~/Views/Shared/{0}.cshtml",
                "~/Views/Admin/{0}.cshtml",
                "~/Views/Ajax/{0}.cshtml",
                "~/Views/Common/{0}.cshtml",
                "~/Views/Dealing/{0}.cshtml",
                "~/Views/Epay/{0}.cshtml",
                "~/Views/Error/{0}.cshtml",
                "~/Views/Home/{0}.cshtml",
                "~/Views/Print/{0}.cshtml",
                "~/Views/Public/{0}.cshtml",
                "~/Views/Receiving/{0}.cshtml",
                "~/Views/Report/{0}.cshtml",
                "~/Views/Sdm/{0}.cshtml",
                "~/Views/Sign/{0}.cshtml",
                "~/Views/Tehsildar/{0}.cshtml",
                "~/Views/Verifier/{0}.cshtml",
                "~/Views/Window/{0}.cshtml",
            };

                MasterLocationFormats = new[] {
                "~/Views/{1}/{0}.cshtml",
                "~/Views/Shared/{0}.cshtml",
            };

                PartialViewLocationFormats = new[] {
                "~/Views/{1}/{0}.cshtml",
                "~/Views/Shared/{0}.cshtml",
                "~/Views/Shared/PartialService/{0}.cshtml",
            };
        }

        protected override IView CreatePartialView(ControllerContext controllerContext, string partialPath)
        {
            return base.CreatePartialView(controllerContext, partialPath);
        }
        protected override IView CreateView(ControllerContext controllerContext, string viewPath, string masterPath)
        {
            return base.CreateView(controllerContext, viewPath, masterPath);
        }
        protected override bool FileExists(ControllerContext controllerContext, string virtualPath)
        {
            return base.FileExists(controllerContext, virtualPath);
        }
    }

}