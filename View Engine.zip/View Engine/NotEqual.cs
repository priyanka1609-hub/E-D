﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Routing;

namespace Edistrict.View_Engine
{
    public class NotEqual : IRouteConstraint
    {
        private string[] _matches = null;

        public NotEqual(params string[] matches)
        {
            _matches = matches;
        }

        public bool Match(HttpContextBase httpContext, Route route,
                          string parameterName, RouteValueDictionary values,
                          RouteDirection routeDirection)
        {
            bool foundMatch = false;
            foreach (string match in _matches)
                if (String.Compare(values[parameterName].ToString(), match, true) == 0)
                    foundMatch = true;

            return !foundMatch;//not matching!
        }
    }
}