﻿using ClassLibrary1;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Modes;
using Org.BouncyCastle.Crypto.Parameters;
using System;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Web;

namespace Morpho_AuthClient
{
    public class EncryptionAgent_new
    {
        public static string returnCode = "00";

        //public static string createEncodedSessionKey_Pid(string pidXML, out string base64EncodedPid, out string base64EncodedSessionKey)
        //{
        //    string ExceptionValue = string.Empty;
        //    base64EncodedPid = string.Empty;
        //    base64EncodedSessionKey = string.Empty;
        //    ASCIIEncoding asciiEncoding = new ASCIIEncoding();
        //    try
        //    {
        //        byte[] sessionKey = EncryptionAgent_new.generateSessionKey();
        //        byte[] inArray1 = EncryptionAgent_new.encryptUsingSessionKey(asciiEncoding.GetBytes(pidXML), sessionKey);
        //        byte[] inArray2 = EncryptionAgent_new.encryptSessionKeyUsingPublicKey(sessionKey);
        //        base64EncodedPid = Convert.ToBase64String(inArray1);
        //        base64EncodedSessionKey = Convert.ToBase64String(inArray2);
        //    }
        //    catch (CryptographicException ex)
        //    {
        //        EncryptionAgent_new.returnCode = EncryptionAgent_new.returnCode.Replace('0', '1'); ExceptionValue = ex.ToString();
        //    }
        //    catch (ArgumentNullException ex)
        //    {
        //        EncryptionAgent_new.returnCode = EncryptionAgent_new.returnCode.Replace('0', '2'); ExceptionValue = ex.ToString();
        //    }
        //    catch (ArgumentOutOfRangeException ex)
        //    {
        //        EncryptionAgent_new.returnCode = EncryptionAgent_new.returnCode.Replace('0', '3'); ExceptionValue = ex.ToString();
        //    }
        //    catch (ArgumentException ex)
        //    {
        //        EncryptionAgent_new.returnCode = EncryptionAgent_new.returnCode.Replace('0', '4'); ExceptionValue = ex.ToString();
        //    }
        //    catch (OverflowException ex)
        //    {
        //        EncryptionAgent_new.returnCode = EncryptionAgent_new.returnCode.Replace('0', '5'); ExceptionValue = ex.ToString();
        //    }
        //    catch (Exception ex)
        //    {
        //        EncryptionAgent_new.returnCode = !EncryptionAgent_new.returnCode.StartsWith("0") ? EncryptionAgent_new.returnCode.Replace('0', '9') : (EncryptionAgent_new.returnCode = "99"); ExceptionValue = ex.ToString();
        //    }
        //    return EncryptionAgent_new.returnCode;
        //}

        public static string readFicate()
        {
            try
            {
                // Read The the certificate  from path
                using (StreamReader reader = File.OpenText(System.Web.HttpContext.Current.Server.MapPath("~/CertificateStore/AuthCert.cer")))
                {
                    String content = reader.ReadToEnd();
                    content = content.Replace("-----BEGIN CERTIFICATE-----", "");
                    content = content.Replace("-----END CERTIFICATE-----", "");
                    content = content.Replace("\r\n", "");
                    return content;
                }
            }
            catch
            {
                return null;
            }
        }

        public static string createEncodedSessionKey_Pid(string pidXML, string StaticTimeStamp, out string base64EncodedPid, out string base64EncodedSessionKey, out string base64EncodedHMac)
        {
            string ExceptionValue = string.Empty;
            base64EncodedPid = string.Empty;
            base64EncodedHMac = string.Empty;
            base64EncodedSessionKey = string.Empty;

            try
            {
                Enc xx = new Enc(Convert.FromBase64String(readFicate()));

                byte[] sessionKey = xx.generateSessionKey();// Generate session key
                byte[] bytes = Encoding.UTF8.GetBytes(pidXML);// Convert PID XML in byte
                ApplicationStore.ExpiryDateOfKeyCertificate = xx.certExpiryDate.ToString();// Get & Set expiry date of certificate

                //Method is new 2.0 to encrypt DATA
                byte[] inArray1 = EncryptionAgent_new.encryptUsingSessionKey(bytes, sessionKey, StaticTimeStamp);

                //Method is new 2.0 to encrypt HMAC
                byte[] hmac = xx.generateSha256Hash(bytes);
                byte[] inArray2 = EncryptionAgent_new.encryptDecryptUsingSessionKey(hmac, sessionKey, StaticTimeStamp);

                // Method is new 2.0 to encrypt SKEY
                byte[] inArray3 = xx.encryptUsingPublicKey(sessionKey);

                base64EncodedPid = Convert.ToBase64String(inArray1); //Get Encoded base64P of encrypt DATA
                base64EncodedHMac = Convert.ToBase64String(inArray2); //Get Encoded base64P of encrypt HMAC
                base64EncodedSessionKey = Convert.ToBase64String(inArray3); //Get Encoded base64P of encrypt SKEY
            }
            catch (CryptographicException ex)
            {
                EncryptionAgent_new.returnCode = EncryptionAgent_new.returnCode.Replace('0', '1'); ExceptionValue = ex.ToString();
            }
            catch (ArgumentNullException ex)
            {
                EncryptionAgent_new.returnCode = EncryptionAgent_new.returnCode.Replace('0', '2'); ExceptionValue = ex.ToString();
            }
            catch (ArgumentOutOfRangeException ex)
            {
                EncryptionAgent_new.returnCode = EncryptionAgent_new.returnCode.Replace('0', '3'); ExceptionValue = ex.ToString();
            }
            catch (ArgumentException ex)
            {
                EncryptionAgent_new.returnCode = EncryptionAgent_new.returnCode.Replace('0', '4'); ExceptionValue = ex.ToString();
            }
            catch (OverflowException ex)
            {
                EncryptionAgent_new.returnCode = EncryptionAgent_new.returnCode.Replace('0', '5'); ExceptionValue = ex.ToString();
            }
            catch (Exception ex)
            {
                EncryptionAgent_new.returnCode = !EncryptionAgent_new.returnCode.StartsWith("0") ? EncryptionAgent_new.returnCode.Replace('0', '9') : (EncryptionAgent_new.returnCode = "99"); ExceptionValue = ex.ToString();
            }
            return EncryptionAgent_new.returnCode;
        }

        //public static byte[] generateSessionKey()
        //{
        //    try
        //    {
        //        RijndaelManaged rijndaelManaged = new RijndaelManaged();
        //        rijndaelManaged.KeySize = 256;
        //        return rijndaelManaged.Key;
        //    }
        //    catch (Exception ex)
        //    {
        //        EncryptionAgent_new.returnCode = "10";
        //        throw ex;
        //    }
        //}

        private static byte[] encryptUsingSessionKey(byte[] data, byte[] skey, string timeStr)
        {
            try
            {
                //RijndaelManaged rijndaelManaged = new RijndaelManaged();
                //rijndaelManaged.Key = sessionKey;
                //rijndaelManaged.Mode = CipherMode.ECB;
                //rijndaelManaged.Padding = PaddingMode.PKCS7;
                //ICryptoTransform encryptor = rijndaelManaged.CreateEncryptor(rijndaelManaged.Key, rijndaelManaged.IV);
                //MemoryStream memoryStream = new MemoryStream();
                //CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, encryptor, CryptoStreamMode.Write);
                //cryptoStream.Write(pidBytes, 0, pidBytes.Length);
                //cryptoStream.FlushFinalBlock();
                //byte[] numArray = memoryStream.ToArray();
                //memoryStream.Close();
                //cryptoStream.Close();
                //return numArray;

                byte[] IV = new byte[12];
                byte[] AuthTag = new byte[16];
                byte[] tmpStmpByytes = System.Text.Encoding.UTF8.GetBytes(timeStr);
                Array.Copy(tmpStmpByytes, tmpStmpByytes.Length - 12, IV, 0, IV.Length);
                Array.Copy(tmpStmpByytes, tmpStmpByytes.Length - 16, AuthTag, 0, AuthTag.Length);
                var cipher = new GcmBlockCipher(new AesFastEngine());
                var parameters = new AeadParameters(new KeyParameter(skey), 128, IV, AuthTag);
                cipher.Init(true, parameters);
                byte[] output = new byte[cipher.GetOutputSize(data.Length)];
                int len = cipher.ProcessBytes(data, 0, data.Length, output, 0);
                cipher.DoFinal(output, len);
                //var tag = Convert.ToBase64String(cipher.GetMac());
                byte[] Final = new byte[output.Length + tmpStmpByytes.Length];
                Array.Copy(tmpStmpByytes, 0, Final, 0, tmpStmpByytes.Length);
                Array.Copy(output, 0, Final, tmpStmpByytes.Length, output.Length);
                return Final;
            }
            catch (Exception ex)
            {
                EncryptionAgent_new.returnCode = "20";
                throw ex;
            }
        }

        public static byte[] encryptDecryptUsingSessionKey(byte[] data, byte[] skey, string timeStr)
        {

            try
            {
                byte[] IV = new byte[12];
                byte[] AuthTag = new byte[16];
                byte[] tmpStmpByytes = System.Text.Encoding.UTF8.GetBytes(timeStr);
                Array.Copy(tmpStmpByytes, tmpStmpByytes.Length - 12, IV, 0, IV.Length);
                Array.Copy(tmpStmpByytes, tmpStmpByytes.Length - 16, AuthTag, 0, AuthTag.Length);
                var cipher = new GcmBlockCipher(new AesFastEngine());
                var parameters = new AeadParameters(new KeyParameter(skey), 128, IV, AuthTag);
                cipher.Init(true, parameters);
                byte[] output = new byte[cipher.GetOutputSize(data.Length)];
                int len = cipher.ProcessBytes(data, 0, data.Length, output, 0);
                cipher.DoFinal(output, len);
                return output;
            }
            catch
            {
                return null;
            }
        }

        //private static byte[] decrypt(byte[] pidBytes, byte[] sessionKey)
        //{
        //    try
        //    {
        //        RijndaelManaged rijndaelManaged = new RijndaelManaged();
        //        rijndaelManaged.Key = sessionKey;
        //        rijndaelManaged.Mode = CipherMode.ECB;
        //        rijndaelManaged.Padding = PaddingMode.None;
        //        ICryptoTransform decryptor = rijndaelManaged.CreateDecryptor(rijndaelManaged.Key, rijndaelManaged.IV);
        //        MemoryStream memoryStream = new MemoryStream();
        //        CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, decryptor, CryptoStreamMode.Write);
        //        cryptoStream.Write(pidBytes, 0, pidBytes.Length);
        //        cryptoStream.FlushFinalBlock();
        //        byte[] numArray = memoryStream.ToArray();
        //        memoryStream.Close();
        //        cryptoStream.Close();
        //        return numArray;
        //    }
        //    catch (Exception ex)
        //    {
        //        EncryptionAgent_new.returnCode = "20";
        //        throw ex;
        //    }
        //}

        //private static byte[] encryptSessionKeyUsingPublicKey(byte[] sessionKey)
        //{
        //    string str = string.Empty;
        //    X509Certificate2 x509Certificate2 = new X509Certificate2(HttpContext.Current.Server.MapPath("~/CertificateStore/AuthCert.cer"));
        //    x509Certificate2.GetPublicKey();
        //    x509Certificate2.GetPublicKeyString();
        //    ApplicationStore.ExpiryDateOfKeyCertificate = x509Certificate2.GetExpirationDateString();
        //    return ((RSACryptoServiceProvider)x509Certificate2.PublicKey.Key).Encrypt(sessionKey, false);
        //}

        //private static byte[] ComputeHash(byte[] plainTextBytes, string hashAlgorithm)
        //{
        //    if (hashAlgorithm == null)
        //        hashAlgorithm = "";
        //    HashAlgorithm hashAlgorithm1;
        //    switch (hashAlgorithm.ToUpper())
        //    {
        //        case "SHA1":
        //            hashAlgorithm1 = (HashAlgorithm)new SHA1Managed();
        //            break;
        //        case "SHA256":
        //            hashAlgorithm1 = (HashAlgorithm)SHA256.Create();
        //            break;
        //        case "SHA384":
        //            hashAlgorithm1 = (HashAlgorithm)new SHA384Managed();
        //            break;
        //        case "SHA512":
        //            hashAlgorithm1 = (HashAlgorithm)new SHA512Managed();
        //            break;
        //        default:
        //            hashAlgorithm1 = (HashAlgorithm)new MD5CryptoServiceProvider();
        //            break;
        //    }
        //    return hashAlgorithm1.ComputeHash(plainTextBytes);
        //}
    }
}
