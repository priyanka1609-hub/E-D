﻿using System;
using System.Collections.Specialized;
using System.Configuration;
using System.Security.Cryptography;
using System.Text;

namespace Morpho_AuthClient
{
  public class ApplicationStore
  {
    public static string Host { get; set; }

    public static string HostBFD { get; set; }

    public static string TelcoServerURL { get; set; }

    public static string TargetURL { get; set; }

    public static string DoFileOperation { get; set; }

    public static string AC { get; set; }

    public static string SA { get; set; }

    public static string Version_Aadhaar { get; set; }

    public static string TerminalID { get; set; }

    public static string TxnIdentifier { get; set; }
    //changeuid20171017
    public static string ResidentConsent { get; set; }
    public static string LicenseKey { get; set; }

    public static string CertificatePassword { get; set; }

    public static string Remote_Addr { get; set; }

    

    public static string UniqueDeviceCode { get; set; }

    public static string FingerprintDeviceCode { get; set; }

    public static string CameraDeviceCode { get; set; }

    public static string IrictDeviceCode { get; set; }

    public static string PublicIPDevice { get; set; }

    public static string LocationType { get; set; }

    public static string LocationValue { get; set; }

    public static string RootFileFolder { get; set; }

    public static string ResponseFolder { get; set; }

    public static string CustomerFolder { get; set; }

    public static string LogFolder { get; set; }

    public static string MorphoLogFolder { get; set; }

    public static string UseRemoteAddr { get; set; }

    public static string UseLicensekey { get; set; }

    public static string ExpiryDateOfKeyCertificate { get; set; }

    public static bool UsePing { get; set; }

    public static string ProxyURL { get; set; }

    public static string RbdVersion { get; set; }

    public static string FileFormat { get; set; }

    public static string DepartmentName { get; set; }

    public static string DepartmentCode { get; set; }

    public static string ProjectName { get; set; }

    public static string AccessId { get; set; }

    public static void ReadConfigurationFile()
    {
      foreach (string index in (NameObjectCollectionBase) ConfigurationManager.AppSettings)
      {
        string cipherString = ConfigurationManager.AppSettings[index];
        switch (index)
        {
          case "host":
            ApplicationStore.Host = cipherString;
            continue;
          case "telcoserver":
            ApplicationStore.TelcoServerURL = cipherString;
            continue;
          case "targetURL":
            ApplicationStore.TargetURL = cipherString;
            continue;
          case "DoFileOperation":
            ApplicationStore.DoFileOperation = cipherString;
            continue;
          case "ac":
            ApplicationStore.AC = cipherString;
            continue;
          case "DepartmentName":
            ApplicationStore.DepartmentName = cipherString;
            continue;
          case "DepartmentCode":
            ApplicationStore.DepartmentCode = cipherString;
            continue;
          case "sa":
            ApplicationStore.SA = cipherString;
            continue;
          case "Version_Aadhaar":
          case "ver":
            ApplicationStore.Version_Aadhaar = cipherString;
            continue;
          case "terminalID":
            ApplicationStore.TerminalID = cipherString;
            continue;
        case "ResidentConsent"://changeuid20171017
        case "rc":
            ApplicationStore.ResidentConsent = cipherString;
            continue;
        case "txnIdentifier":
            ApplicationStore.TxnIdentifier = cipherString;
            continue;
          //case "LKey":
          //  if (!string.IsNullOrEmpty(cipherString))
          //  {
          //    ApplicationStore.LicenseKey = ApplicationStore.Decrypt(cipherString, false);
          //    continue;
          //  }
          //  else
          //    continue;
          case "CetrPassword":
            if (!string.IsNullOrEmpty(cipherString))
            {
              ApplicationStore.CertificatePassword = ApplicationStore.Decrypt(cipherString, false);
              continue;
            }
            else
              continue;
          case "UniqueDeviceCode":
          case "udc":
            ApplicationStore.UniqueDeviceCode = cipherString;
            continue;
          case "FingerprintDeviceCode":
          case "fdc":
            ApplicationStore.FingerprintDeviceCode = cipherString;
            continue;
        case "CameraDeviceCode":
        case "cdc":
            ApplicationStore.CameraDeviceCode = cipherString;
            continue;
        case "IristDeviceCode":
          case "idc":
            ApplicationStore.IrictDeviceCode = cipherString;
            continue;
          case "PublicIPDevice":
          case "pip":
            ApplicationStore.PublicIPDevice = cipherString;
            continue;
          case "LocationType":
          case "lot":
            ApplicationStore.LocationType = cipherString;
            continue;
          case "LocationValue":
          case "lov":
            ApplicationStore.LocationValue = cipherString;
            continue;
          case "RootFileFolder":
            ApplicationStore.RootFileFolder = cipherString;
            continue;
          case "ResponseFolder":
            ApplicationStore.ResponseFolder = cipherString;
            continue;
          case "CustomerFolder":
            ApplicationStore.CustomerFolder = cipherString;
            continue;
          case "LogFolder":
            ApplicationStore.LogFolder = cipherString;
            continue;
          case "MorphoLogFolder":
            ApplicationStore.MorphoLogFolder = cipherString;
            continue;
          case "Remote_Addr":
            ApplicationStore.Remote_Addr = cipherString;
            continue;
          case "UseLKey":
            ApplicationStore.UseLicensekey = cipherString;
            continue;
          case "UseRemoteAddr":
            ApplicationStore.UseRemoteAddr = cipherString;
            continue;
          case "hostBFD":
            ApplicationStore.HostBFD = cipherString;
            continue;
          case "VersionRBD_BFD":
            ApplicationStore.RbdVersion = cipherString;
            continue;
          case "ProxyURL":
            ApplicationStore.ProxyURL = cipherString;
            continue;
          case "ProjectName":
            ApplicationStore.ProjectName = cipherString;
            continue;
          case "AccessId":
            ApplicationStore.AccessId = cipherString;
            continue;
        case "LicenseKey":
            ApplicationStore.LicenseKey = cipherString;
            continue;
        //case "AUALKey":
        //  ApplicationStore.aualkey = cipherString;
        //  continue;
        default:
            continue;
        }
      }
    }

    private static string Decrypt(string cipherString, bool useHashing)
    {
      try
      {
        byte[] inputBuffer = Convert.FromBase64String(cipherString);
        AppSettingsReader appSettingsReader = new AppSettingsReader();
        string s = "NtwHM3AIn1M+MPfnWgiDRtEnYOOG0vgs";
        byte[] numArray;
        if (useHashing)
        {
          MD5CryptoServiceProvider cryptoServiceProvider = new MD5CryptoServiceProvider();
          numArray = cryptoServiceProvider.ComputeHash(Convert.FromBase64String(s));
          cryptoServiceProvider.Clear();
        }
        else
          numArray = Convert.FromBase64String(s);
        TripleDESCryptoServiceProvider cryptoServiceProvider1 = new TripleDESCryptoServiceProvider();
        cryptoServiceProvider1.Key = numArray;
        cryptoServiceProvider1.Mode = CipherMode.ECB;
        cryptoServiceProvider1.Padding = PaddingMode.PKCS7;
        byte[] bytes = cryptoServiceProvider1.CreateDecryptor().TransformFinalBlock(inputBuffer, 0, inputBuffer.Length);
        cryptoServiceProvider1.Clear();
        return Encoding.UTF8.GetString(bytes);
      }
      catch
      {
        return string.Empty;
      }
    }
  }
}
