﻿namespace Morpho_AuthClient.Common
{
  internal class FingerObject
  {
    public string FmrData { get; set; }

    public int NFIQ { get; set; }

    public int NoOfMinutes { get; set; }

    public string FingerPosition { get; set; }
  }
}
