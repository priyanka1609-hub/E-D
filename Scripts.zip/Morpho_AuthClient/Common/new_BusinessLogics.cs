﻿using Api_MorphoAuthClient;
using Morpho_AuthClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using System.Xml;
using System.Xml.Serialization;

namespace Morpho_AuthClient.Common
{
    internal class new_BusinessLogics
    {
        //public static string ExpiryDateOfKeyCertificate { get; set; }

        public static string GetTimeStamp_UTC()
        {
            return DateTime.UtcNow.AddHours(5.0).AddMinutes(30.0).ToString("yyyy-MM-ddTHH:mm:ss");
        }

        //public static string SignAuthXml(string AuthXml, string password)
        //{
        //    string str = string.Empty;
        //    try
        //    {
        //        if (!(AuthXml != string.Empty))
        //            return string.Empty;
        //        XmlDocument document = new XmlDocument();
        //        X509Certificate2 x509Certificate2 = new X509Certificate2(!(ConfigurationManager.AppSettings["ver"] == "1.5") ? "CertificateStore\\public_16.p12" : "CertificateStore\\public_15.p12", password);
        //        RSACryptoServiceProvider cryptoServiceProvider = (RSACryptoServiceProvider)x509Certificate2.PrivateKey;
        //        document.PreserveWhitespace = true;
        //        document.LoadXml(AuthXml);
        //        if (document == null)
        //            throw new ArgumentException("xmlDoc");
        //        if (cryptoServiceProvider == null)
        //            throw new ArgumentException("Key");
        //        SignedXml signedXml = new SignedXml(document);
        //        signedXml.SigningKey = (AsymmetricAlgorithm)cryptoServiceProvider;
        //        Reference reference = new Reference();
        //        reference.Uri = "";
        //        XmlDsigEnvelopedSignatureTransform signatureTransform = new XmlDsigEnvelopedSignatureTransform();
        //        reference.AddTransform((Transform)signatureTransform);
        //        signedXml.AddReference(reference);
        //        KeyInfoX509Data keyInfoX509Data = new KeyInfoX509Data((X509Certificate)x509Certificate2);
        //        keyInfoX509Data.AddSubjectName(x509Certificate2.Subject);
        //        KeyInfo keyInfo = new KeyInfo();
        //        keyInfo.AddClause((KeyInfoClause)keyInfoX509Data);
        //        signedXml.KeyInfo = keyInfo;
        //        signedXml.ComputeSignature();
        //        XmlElement xml = signedXml.GetXml();
        //        document.DocumentElement.AppendChild(document.ImportNode((XmlNode)xml, true));
        //        return document.InnerXml;
        //    }
        //    catch
        //    {
        //        return string.Empty;
        //    }
        //}

        public string GenerateXML_Auth(string xmlPid, string uidNumber, string StaticTimeStamp, Boolean Bio)
        {
            string str1 = string.Empty;
            string base64EncodedPid = string.Empty;
            string base64EncodedSessionKey = string.Empty;
            string base64EncodedHMac = string.Empty;
            string str2 = string.Empty;
            string str3 = string.Empty;
            Auth auth1 = new Auth();
            SKey skey = new SKey();
            Meta meta = new Meta();
            Uses uses = new Uses();
            Data data = new Data();

            try
            {
                if (!string.IsNullOrEmpty(xmlPid))
                {
                    if (EncryptionAgent_new.createEncodedSessionKey_Pid(xmlPid, StaticTimeStamp, out base64EncodedPid, out base64EncodedSessionKey, out base64EncodedHMac) == "00")
                    {
                        ApplicationStore.ReadConfigurationFile();
                        Auth auth2 = new Auth();
                        auth2.UidNumber = uidNumber;
                        auth2.API_Version = ApplicationStore.Version_Aadhaar;
                        //changeuid20171017
                        //auth2.Aua_Code = ApplicationStore.AC;
                        auth2.Aua_Code = string.Empty;
                        auth2.Sub_Aua_Code = ApplicationStore.SA;
                        //changeuid20171017
                        //auth2.Terminal_Id = ApplicationStore.TerminalID;
                        auth2.Terminal_Id = string.Empty;

                        //changeuid20171017
                        auth2.ResidentConsent = ApplicationStore.ResidentConsent;
                        auth2.LicenseKey = ApplicationStore.LicenseKey;

                        //auth2.TransactionId = uidNumber + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("HHmmss") + ApplicationStore.ProjectName;
                        auth2.TransactionId = "DemoAuth:" + StaticTimeStamp;

                        auth2.AccessId = ApplicationStore.AccessId;

                        skey.Certificate_ExpDate = Convert.ToDateTime(ApplicationStore.ExpiryDateOfKeyCertificate).ToString("yyyyMMdd");
                        skey.SessionKey_Base64 = base64EncodedSessionKey;
                        auth2.Skey = skey;

                        //changeuid20171017
                        //if (ApplicationStore.Version_Aadhaar == "1.6")
                        if (ApplicationStore.Version_Aadhaar == "2.0")
                        {
                            meta.Unique_Device_Code = ApplicationStore.UniqueDeviceCode;

                            //changeuid20171017
                            //meta.Unique_iris_Code = ApplicationStore.IrictDeviceCode;
                            //meta.Fingerprint_Device_Code = ApplicationStore.FingerprintDeviceCode;
                            //meta.Camera_Device_Code = ApplicationStore.CameraDeviceCode;

                            //changeuid20171017
                            meta.rdsId = string.Empty;
                            meta.rdsVer = string.Empty;
                            meta.dpId = string.Empty;
                            meta.dc = string.Empty;
                            meta.mi = string.Empty;
                            meta.mc = string.Empty;

                            //changeuid20171017
                            //meta.PublicIP_Device = ApplicationStore.PublicIPDevice;
                            //meta.Location_Type = ApplicationStore.LocationType;
                            //meta.Location_Value = ApplicationStore.LocationValue;

                            auth2.MetaTag = meta;
                        }

                        if (Bio)
                        {
                            uses.pi = "n";
                            uses.pa = "n";
                            uses.Pfa = "n";
                            uses.Bio = "y";
                            uses.Bt = "FMR";
                            uses.pin = "n";
                            uses.otp = "n";
                        }
                        else
                        {
                            uses.pi = "y";
                            uses.pa = "n";
                            uses.Pfa = "n";
                            uses.Bio = "n";
                            //changeuid20171017
                            //uses.Bt = "";
                            uses.pin = "n";
                            uses.otp = "n";
                        }
                        auth2.Uses = uses;

                        //changeuid20171017
                        data.Data_Type = "X";
                        data.EncodedPid_Base64 = base64EncodedPid;
                        auth2.Data = data;

                        auth2.Hmac = base64EncodedHMac;
                        str1 = XML_Methods.SerializeObjectToXml((object)auth2, false);
                    }
                }
            }
            catch
            {
                //code here
            }
            return str1;
        }

        //public string CreateXML_PID(List<FingerObject> l_UserInfo)
        //{
        //    string str = string.Empty;
        //    List<Bio> list = new List<Bio>();
        //    try
        //    {
        //        foreach (FingerObject fingerObject in l_UserInfo)
        //            list.Add(new Bio()
        //            {
        //                FingerPosition = fingerObject.FingerPosition,
        //                Fmr_Base64 = fingerObject.FmrData
        //            });
        //        BiosPID pid = new BiosPID();
        //        pid.Bios = list;
        //        pid.TimeStamp = new_BusinessLogics.GetTimeStamp_UTC();
        //        //changeuid20171017
        //        //pid.Version = "1.0";
        //        pid.Version = "2.0";
        //        str = XML_Methods.SerializeObjectToXml((object)pid, true);
        //    }
        //    catch
        //    {
        //        //code here
        //    }
        //    return str;
        //}

        public string CreateXML_PID(string fullName, string gender, string dob, string phone, string email, string StaticTimeStamp)
        {
            DemoPID pid = new DemoPID();
            List<Pi> list = new List<Pi>();
            string str = string.Empty;

            list.Add(new Pi()
            {
                Name = fullName,
                Gender = gender,
                Dob = dob
                //Phone = phone, // attributes not required if value null
                //Email = email // attributes not required if value null
            });
            pid.Demo = list;
            //pid.TimeStamp = new_BusinessLogics.GetTimeStamp_UTC();
            pid.TimeStamp = StaticTimeStamp;
            //changeuid20171017
            //pid.Version = "1.0";
            pid.Version = "2.0";
            pid.wadh = string.Empty;
            str = XML_Methods.SerializeObjectToXml((object)pid, true);
            return str;
        }
    }
}
